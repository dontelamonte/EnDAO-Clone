'use client';

import { Suspense, useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import {
  Users,
  TrendingUp,
  Vote,
  DollarSign,
  BarChart3,
  Loader2,
} from 'lucide-react';
import { ProtectedRoute } from '@/components/auth/protected-route';
import { useAuth } from '@/lib/auth/auth-context';
import { usePrivyAuth } from '@/lib/auth/privy-auth-context';
import { canUseDevAuth, getDevAuthUserObject } from '@/lib/dev/dev-auth';
// Sidebar is rendered by AppNavigation in root layout
import { useVotingStatistics } from '@/hooks/dashboard/use-voting-statistics';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

// Mock data fallback - used when no real data available
const mockActivityTrend = [
  { week: 'W1', votes: 0 },
  { week: 'W2', votes: 0 },
  { week: 'W3', votes: 0 },
  { week: 'W4', votes: 0 },
];

const mockVotingBehavior = [
  { name: 'For', value: 0, fill: '#10b981' },
  { name: 'Against', value: 0, fill: '#ef4444' },
  { name: 'Abstain', value: 0, fill: '#6b7280' },
];

interface DAOParticipation {
  daoId: string;
  dao: string;
  votes: number;
  passedProposals: number;
  engagement: number;
}

interface WeeklyActivity {
  week: string;
  votes: number;
}

interface VotingBehavior {
  name: string;
  value: number;
  fill: string;
  [key: string]: string | number; // Index signature for recharts compatibility
}

interface UserDAO {
  id: string;
  name: string;
  description: string;
  memberCount: number;
  treasuryValue: string;
}

function AnalyticsContent() {
  const { user } = useAuth();
  const { getAccessToken } = usePrivyAuth();
  const {
    statistics: votingStats,
    isLoading: votingLoading,
    error: votingError,
  } = useVotingStatistics(user?.uid);

  // Additional state for user analytics
  const [userDAOs, setUserDAOs] = useState<UserDAO[]>([]);
  const [daoParticipation, setDaoParticipation] = useState<DAOParticipation[]>(
    []
  );
  const [activityTrend, setActivityTrend] =
    useState<WeeklyActivity[]>(mockActivityTrend);
  const [votingBehavior, setVotingBehavior] =
    useState<VotingBehavior[]>(mockVotingBehavior);
  const [totalTreasuryAccess, setTotalTreasuryAccess] = useState<string>('$0');
  const [loading, setLoading] = useState(true);

  // Fetch user analytics via API route (browser-safe pattern)
  const loadUserAnalytics = useCallback(async () => {
    if (!user?.uid) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      const accessToken = await getAccessToken();
      const isDevAuth = canUseDevAuth() && getDevAuthUserObject() !== null;

      // For dev auth, we don't need an access token - cookies handle auth
      if (!accessToken && !isDevAuth) {
        setLoading(false);
        return;
      }

      const response = await fetch('/api/analytics/user', {
        headers: {
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        },
        credentials: 'include', // Include cookies for dev auth
      });

      const result = await response.json();

      if (result.success && result.data) {
        const data = result.data;

        setUserDAOs(data.userDAOs);
        setDaoParticipation(data.daoParticipation);
        setActivityTrend(data.activityTrend);
        setTotalTreasuryAccess(data.totalTreasuryAccess);

        // Calculate voting behavior percentages for chart
        const totalBehavior = data.votingBehavior.reduce(
          (sum: number, b: VotingBehavior) => sum + b.value,
          0
        );
        if (totalBehavior > 0) {
          setVotingBehavior(
            data.votingBehavior.map((b: VotingBehavior) => ({
              ...b,
              value: Math.round((b.value / totalBehavior) * 100),
            }))
          );
        } else {
          setVotingBehavior(data.votingBehavior);
        }
      }
    } catch (error) {
      console.error('Failed to load user analytics:', error);
    } finally {
      setLoading(false);
    }
  }, [user?.uid, getAccessToken]);

  useEffect(() => {
    if (!votingLoading) {
      loadUserAnalytics();
    }
  }, [loadUserAnalytics, votingLoading]);

  const isLoading = loading || votingLoading;

  const stats = [
    {
      label: 'Groups Joined',
      value: userDAOs.length,
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-500/10',
      change: 'across platform',
    },
    {
      label: 'Total Votes Cast',
      value: votingStats.totalVotesCast,
      icon: Vote,
      color: 'text-green-600',
      bgColor: 'bg-green-500/10',
      change:
        votingStats.votingStreak > 0
          ? `${votingStats.votingStreak} week streak`
          : 'Start voting!',
    },
    {
      label: 'Participation Rate',
      value: `${votingStats.participationRate}%`,
      icon: TrendingUp,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      change: 'avg across groups',
    },
    {
      label: 'Treasury Access',
      value: totalTreasuryAccess,
      icon: DollarSign,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-500/10',
      change: 'across all groups',
    },
  ];

  // Check if user has any real data
  const hasData = votingStats.totalVotesCast > 0 || userDAOs.length > 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar is rendered by AppNavigation in root layout */}
      <main className="pt-16 lg:pt-0 lg:pl-72">
        <div className="p-8 pb-24">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <BarChart3 className="h-6 w-6 text-primary" />
              </div>
              <h1 className="text-3xl font-heading font-bold text-foreground">
                My Analytics
              </h1>
            </div>
            <p className="text-muted-foreground">
              Your cross-DAO participation and voting activity
            </p>
          </motion.div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-3 text-muted-foreground">
                Loading your analytics...
              </span>
            </div>
          ) : votingError ? (
            <Card className="border-red-500/50 bg-red-50 dark:bg-red-950/20">
              <CardContent className="py-6">
                <p className="text-red-600 dark:text-red-400">
                  Failed to load voting statistics: {votingError}
                </p>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Stats Cards */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
                {stats.map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <Card
                      className="border-border/50"
                      data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <CardContent className="pt-6 pb-6">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="text-xs text-muted-foreground">
                              {stat.label}
                            </p>
                            <p className="text-2xl font-bold text-foreground mt-1">
                              {stat.value}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {stat.change}
                            </p>
                          </div>
                          <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                            <stat.icon className={`h-6 w-6 ${stat.color}`} />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {!hasData ? (
                <Card className="border-border/50">
                  <CardContent className="py-12 text-center">
                    <Vote className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">
                      No Activity Yet
                    </h3>
                    <p className="text-muted-foreground max-w-md mx-auto">
                      Join a DAO and start voting on proposals to see your
                      analytics here.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <>
                  {/* Charts Grid */}
                  <div className="grid gap-6 lg:grid-cols-2 mb-8">
                    {/* Activity Trend */}
                    <Card
                      className="border-border/50"
                      data-testid="chart-activity"
                    >
                      <CardHeader>
                        <CardTitle className="text-lg">
                          4-Week Voting Activity
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pb-6">
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={activityTrend}>
                            <CartesianGrid
                              strokeDasharray="3 3"
                              className="stroke-border"
                            />
                            <XAxis
                              dataKey="week"
                              className="text-muted-foreground"
                              tick={{ fill: 'currentColor' }}
                            />
                            <YAxis
                              className="text-muted-foreground"
                              tick={{ fill: 'currentColor' }}
                            />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: 'hsl(var(--card))',
                                border: '1px solid hsl(var(--border))',
                                borderRadius: '8px',
                                color: 'hsl(var(--foreground))',
                              }}
                            />
                            <Line
                              type="monotone"
                              dataKey="votes"
                              stroke="hsl(var(--primary))"
                              strokeWidth={2}
                              dot={{ fill: 'hsl(var(--primary))' }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    {/* Voting Behavior */}
                    <Card
                      className="border-border/50"
                      data-testid="chart-voting-behavior"
                    >
                      <CardHeader>
                        <CardTitle className="text-lg">
                          Your Voting Behavior
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="flex items-center justify-center pb-6">
                        <ResponsiveContainer width="100%" height={300}>
                          <PieChart>
                            <Pie
                              data={votingBehavior}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              paddingAngle={2}
                              dataKey="value"
                              label={({ name, value }) =>
                                value > 0 ? `${name}: ${value}%` : ''
                              }
                            >
                              {votingBehavior.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.fill} />
                              ))}
                            </Pie>
                            <Tooltip
                              formatter={(value) => `${value}%`}
                              contentStyle={{
                                backgroundColor: 'hsl(var(--card))',
                                border: '1px solid hsl(var(--border))',
                                borderRadius: '8px',
                                color: 'hsl(var(--foreground))',
                              }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>
                  </div>

                  {/* DAO Participation Breakdown */}
                  {daoParticipation.length > 0 && (
                    <Card
                      className="border-border/50"
                      data-testid="card-dao-participation"
                    >
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Users className="h-5 w-5 text-primary" />
                          Participation by DAO
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pb-6">
                        <div className="space-y-4">
                          {daoParticipation.map((item, index) => (
                            <motion.div
                              key={item.daoId}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="p-4 rounded-lg border border-border/50 hover:border-primary/30 transition-colors"
                            >
                              <div className="flex items-center justify-between mb-3">
                                <p className="font-medium text-foreground">
                                  {item.dao}
                                </p>
                                <Badge variant="outline">
                                  {item.engagement}% engagement
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
                                <span>{item.votes} votes cast</span>
                                <span>{item.passedProposals} passed</span>
                              </div>
                              <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{
                                    width: `${Math.min(item.engagement, 100)}%`,
                                  }}
                                  transition={{
                                    delay: 0.5 + index * 0.1,
                                    duration: 0.5,
                                  }}
                                  className="h-full bg-gradient-to-r from-primary to-primary/70"
                                />
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

function AnalyticsPageContent() {
  return (
    <ProtectedRoute redirectTo="/signup">
      <AnalyticsContent />
    </ProtectedRoute>
  );
}

export default function AnalyticsPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <AnalyticsPageContent />
    </Suspense>
  );
}
