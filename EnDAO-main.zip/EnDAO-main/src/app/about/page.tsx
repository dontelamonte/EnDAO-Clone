'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Heart, Shield, Users } from 'lucide-react';
import { ThemeToggle } from '@/components/theme/theme-toggle';

const partners = [
  // Row 1
  {
    name: 'Annie E. Casey Foundation',
    logo: '/partners/annie-casey.png',
    url: 'https://www.aecf.org/',
  },
  {
    name: 'Echoing Green',
    logo: '/partners/echoing-green.png',
    url: 'https://echoinggreen.org/',
  },
  {
    name: 'Morehouse College',
    logo: '/partners/morehouse.png',
    url: 'https://www.morehouse.edu/',
  },
  {
    name: 'Russell Innovation Center for Entrepreneurs',
    logo: '/partners/rice.png',
    url: 'https://russellcenter.org/',
  },
  {
    name: 'Atlanta Blockchain Center',
    logo: '/partners/abc.png',
    url: 'https://atlantachain.io/',
  },
  // Row 2 - wider logos
  {
    name: 'Kindred Futures',
    logo: '/partners/kindred-futures.png',
    url: 'https://kindredfutures.org/',
  },
  {
    name: 'Village Micro Fund',
    logo: '/partners/village-micro-fund.png',
    url: 'https://www.villagemicrofund.com/',
  },
];

const values = [
  {
    icon: Shield,
    title: 'Trust Through Transparency',
    description:
      'Every transaction, every vote, every decision — recorded and visible to all members. No hidden movements, no surprises.',
    color: '#20448e',
  },
  {
    icon: Users,
    title: 'Collective Ownership',
    description:
      'Group money should be controlled by the group. Multiple approvals required, no single point of failure.',
    color: '#E41B0C',
  },
  {
    icon: Heart,
    title: 'Accessible to All',
    description:
      'You shouldn\'t need technical expertise to manage shared finances. Simple tools for real communities.',
    color: '#2a5847',
  },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 lg:px-12 py-5 bg-background/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <img
              src="/endao-logo-cropped.png"
              alt="EnDAO"
              className="h-7 md:h-8"
            />
          </Link>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Link
              href="/"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-16 px-6 lg:px-12">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl lg:text-5xl font-heading font-bold mb-6">
              Built from Community,{' '}
              <span style={{ color: '#E41B0C' }}>for Community</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              EnDAO started with a simple question: why is it so hard for groups
              to manage money together without putting it in someone&apos;s personal account?
            </p>
          </motion.div>
        </div>
      </section>

      {/* Origin Story */}
      <section className="py-16 px-6 lg:px-12 bg-secondary/30">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <h2 className="text-2xl font-heading font-bold">Our Story</h2>
            <div className="prose prose-lg dark:prose-invert max-w-none text-muted-foreground">
              <p>
                EnDAO grew out of real work with real communities. Our journey began
                within <strong>Village Micro Fund</strong>, a social impact fund with
                over a decade of experience investing in local businesses and
                community initiatives.
              </p>
              <p>
                Through our partnership with the <strong>Annie E. Casey Foundation</strong> and
                the Changing the Odds Network, we spent two years organizing communities
                and piloting new approaches to collective finance. We saw firsthand how
                groups struggled with the basics: collecting dues, making spending
                decisions, keeping records everyone could trust.
              </p>
              <p>
                The existing options were either too simple (Venmo, where one person
                holds all the money) or too complex (enterprise tools designed for
                corporations). There was nothing in between for the investment clubs,
                cooperatives, student organizations, and community groups that make
                up the fabric of our society.
              </p>
              <p>
                So we built EnDAO — a platform where any group can pool money safely,
                make decisions democratically, and maintain complete transparency.
                No single person controls the funds. Every transaction requires
                approval. Every decision is recorded.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 px-6 lg:px-12">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-heading font-bold mb-4">What We Believe</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we build.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {values.map((value, i) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="p-6 rounded-2xl border border-border bg-card"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${value.color}15` }}
                >
                  <value.icon className="w-6 h-6" style={{ color: value.color }} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                <p className="text-sm text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partners */}
      <section className="py-20 px-6 lg:px-12 bg-secondary/30">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-heading font-bold mb-4">
              Supported By
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We&apos;re grateful to work alongside organizations committed to
              community empowerment.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-wrap justify-center items-center gap-8 lg:gap-12"
          >
            {partners.map((partner) => (
              <a
                key={partner.name}
                href={partner.url}
                target="_blank"
                rel="noopener noreferrer"
                className="opacity-70 hover:opacity-100 transition-all"
                title={partner.name}
              >
                <img
                  src={partner.logo}
                  alt={partner.name}
                  className="h-16 md:h-20 w-auto object-contain max-w-[200px] dark:brightness-150 dark:contrast-125"
                />
              </a>
            ))}
          </motion.div>

        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 lg:px-12">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-heading font-bold mb-4">
              Ready to get started?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join the groups already using EnDAO to manage their money together.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                href="/signup"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-white font-semibold transition-all hover:opacity-90"
                style={{ backgroundColor: '#E41B0C' }}
              >
                Create Your Group
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-border font-semibold transition-all hover:bg-secondary/50"
              >
                Talk to Us
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 lg:px-12 border-t border-border">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <Link href="/security" className="hover:text-foreground transition-colors">
              Security
            </Link>
            <Link href="/terms" className="hover:text-foreground transition-colors">
              Terms
            </Link>
            <Link href="/privacy" className="hover:text-foreground transition-colors">
              Privacy
            </Link>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} EnDAO. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
