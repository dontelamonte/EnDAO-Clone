'use client';

import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';
import { AdminAccessGuard } from '@/components/admin/admin-access-guard';
import { AdminRoleBadge } from '@/components/admin/admin-role-badge';
import { PermissionGrid } from '@/components/admin/permission-grid';
import { AddEditAdminModal } from '@/components/admin/add-edit-admin-modal';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { AdminUser } from '@endao/shared-types';
import { Icon } from '@/components/ui/icon';

export default function AdminUsersPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAdmin, setSelectedAdmin] = useState<AdminUser | null>(null);
  const [showPermissions, setShowPermissions] = useState(false);
  const [showAddEditModal, setShowAddEditModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminUser | null>(null);

  // Load admin users
  useEffect(() => {
    loadAdminUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadAdminUsers = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/users?active=all');
      const result = await response.json();

      if (result.success && result.data?.adminUsers) {
        setAdminUsers(result.data.adminUsers);
      } else {
        toast({
          title: 'Error',
          description: result.error || 'Failed to load admin users',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Failed to load admin users:', error);
      toast({
        title: 'Error',
        description: 'Failed to load admin users',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleViewPermissions = (admin: AdminUser) => {
    setSelectedAdmin(admin);
    setShowPermissions(true);
  };

  const handleAddAdmin = () => {
    setEditingAdmin(null);
    setShowAddEditModal(true);
  };

  const handleEditAdmin = (admin: AdminUser) => {
    setEditingAdmin(admin);
    setShowAddEditModal(true);
  };

  const handleModalSuccess = () => {
    loadAdminUsers(); // Refresh the list
  };

  const handleToggleStatus = async (admin: AdminUser) => {
    try {
      const response = await fetch(`/api/admin/users/${admin.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive: !admin.isActive }),
      });
      const result = await response.json();

      if (result.success) {
        await loadAdminUsers(); // Refresh the list
        toast({
          title: 'Success',
          description: `Admin ${admin.isActive ? 'deactivated' : 'activated'} successfully`,
        });
      } else {
        toast({
          title: 'Error',
          description: result.error || 'Failed to update admin status',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Failed to toggle admin status:', error);
      toast({
        title: 'Error',
        description: 'Failed to update admin status',
        variant: 'destructive',
      });
    }
  };

  // Filter admin users based on search term
  const filteredAdmins = adminUsers.filter(
    (admin) =>
      admin.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      admin.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      admin.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminAccessGuard requireSuperAdmin={true}>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="border-b bg-card">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => router.push('/admin')}
                  className="flex items-center gap-2"
                >
                  <Icon name="ChevronLeft" size={16} />
                  Back to Admin
                </Button>
                <div>
                  <h1 className="text-2xl font-bold flex items-center gap-2">
                    <Icon name="Users" size={24} />
                    Admin Users
                  </h1>
                  <p className="text-muted-foreground mt-1">
                    Manage administrator accounts and permissions
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-sm text-muted-foreground">
                  Total:{' '}
                  <span className="font-medium">{adminUsers.length}</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  Active:{' '}
                  <span className="font-medium text-green-600">
                    {adminUsers.filter((u) => u.isActive).length}
                  </span>
                </div>
                <Button
                  className="flex items-center gap-2"
                  onClick={handleAddAdmin}
                >
                  <Icon name="Plus" size={16} />
                  Add Admin
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Administrator Accounts</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Icon
                      name="Search"
                      size={16}
                      className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
                    />
                    <Input
                      placeholder="Search by name, email, or role..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-80"
                    />
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Icon name="Loader2" className="h-8 w-8 animate-spin" />
                  <span className="ml-2">Loading admin users...</span>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Admin User</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAdmins.map((admin) => (
                      <TableRow key={admin.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                              <Icon
                                name="Users"
                                size={16}
                                className="text-primary"
                              />
                            </div>
                            <div>
                              <div className="font-medium">
                                {admin.displayName || 'N/A'}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {admin.email}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <AdminRoleBadge role={admin.role} size="sm" />
                        </TableCell>
                        <TableCell>
                          {admin.lastLoginAt
                            ? format(
                                new Date(admin.lastLoginAt),
                                'MMM dd, yyyy HH:mm'
                              )
                            : 'Never'}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={admin.isActive ? 'default' : 'secondary'}
                          >
                            {admin.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleViewPermissions(admin)}
                              className="flex items-center gap-1"
                            >
                              <Icon name="Eye" size={14} />
                              Permissions
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditAdmin(admin)}
                              className="flex items-center gap-1"
                            >
                              <Icon name="Edit" size={14} />
                              Edit
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleToggleStatus(admin)}
                              className="flex items-center gap-1"
                            >
                              {admin.isActive ? 'Deactivate' : 'Activate'}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}

              {!loading && filteredAdmins.length === 0 && (
                <div className="text-center py-12">
                  <Icon
                    name="Users"
                    size={48}
                    className="mx-auto text-muted-foreground mb-4"
                  />
                  <h3 className="text-lg font-medium mb-2">
                    No admin users found
                  </h3>
                  <p className="text-muted-foreground">
                    {searchTerm
                      ? 'No admin users match your search criteria.'
                      : 'There are no admin users in the system.'}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Permissions Modal */}
        <Dialog open={showPermissions} onOpenChange={setShowPermissions}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                Permissions for {selectedAdmin?.displayName || 'Unknown User'}
                <AdminRoleBadge
                  role={selectedAdmin?.role || 'admin'}
                  size="sm"
                />
              </DialogTitle>
            </DialogHeader>
            <div className="overflow-y-auto max-h-[60vh] p-6">
              {selectedAdmin && (
                <PermissionGrid permissions={selectedAdmin.permissions} />
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Add/Edit Admin Modal */}
        <AddEditAdminModal
          open={showAddEditModal}
          onOpenChange={setShowAddEditModal}
          adminUser={editingAdmin}
          onSuccess={handleModalSuccess}
        />
      </div>
    </AdminAccessGuard>
  );
}
