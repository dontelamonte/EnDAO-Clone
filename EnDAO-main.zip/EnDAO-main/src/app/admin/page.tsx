'use client';

import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import Skeleton from '@/components/ui/skeleton';
import { AlertTriangle, Shield } from 'lucide-react';
import {
  SystemDashboard,
  SystemDashboardProvider,
} from '@/components/admin/system-dashboard';
import { useAuth } from '@/lib/auth/auth-context';
import { useAdmin } from '@/hooks/use-admin';
// Sidebar is rendered by AppNavigation in root layout
import { PrivyLoginButton } from '@/components/auth/privy-login-button';

interface AdminPageState {
  loading: boolean;
  error: string | null;
}

export default function SystemAdminPage() {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const {
    adminUser,
    isSuperAdmin,
    isLoading: adminLoading,
    error: adminError,
  } = useAdmin();

  const [state, setState] = useState<AdminPageState>({
    loading: true,
    error: null,
  });

  useEffect(() => {
    if (!authLoading && !adminLoading) {
      setState((prev) => ({ ...prev, loading: false, error: adminError }));
    }
  }, [authLoading, adminLoading, adminError]);

  // Loading state
  if (state.loading || authLoading || adminLoading) {
    return (
      <div className="min-h-screen bg-background">
        {/* Sidebar is rendered by AppNavigation in root layout */}
        <main className="pt-16 lg:pt-0 lg:pl-72">
          <div className="container mx-auto px-4 py-8">
            <div className="mb-6">
              <Skeleton className="h-8 w-48" />
            </div>
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <Skeleton className="h-8 w-64" />
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {Array.from({ length: 8 }).map((_, index) => (
                      <Card key={index}>
                        <CardContent className="p-6">
                          <Skeleton className="h-24 w-full" />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Authentication required
  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        {/* Sidebar is rendered by AppNavigation in root layout */}
        <main className="pt-16 lg:pt-0 lg:pl-72 flex items-center justify-center min-h-screen">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="max-w-md border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-destructive/10 rounded-lg">
                    <AlertTriangle className="h-8 w-8 text-destructive" />
                  </div>
                  <div>
                    <CardTitle className="font-heading">
                      Authentication Required
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Alert variant="destructive">
                  <AlertDescription>
                    Please sign in to access the system administration
                    dashboard.
                  </AlertDescription>
                </Alert>
                <div className="mt-4 flex gap-2">
                  <PrivyLoginButton variant="outline" />
                  <Button variant="outline" onClick={() => router.push('/')}>
                    Go Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </main>
      </div>
    );
  }

  // System admin permission check - only super admin can access
  if (!isSuperAdmin) {
    return (
      <div className="min-h-screen bg-background">
        {/* Sidebar is rendered by AppNavigation in root layout */}
        <main className="pt-16 lg:pt-0 lg:pl-72 flex items-center justify-center min-h-screen">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="max-w-md border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-destructive/10 rounded-lg">
                    <Shield className="h-8 w-8 text-destructive" />
                  </div>
                  <div>
                    <CardTitle className="font-heading">
                      Access Denied
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Alert variant="destructive">
                  <AlertDescription>
                    You don&apos;t have permission to access the system
                    administration dashboard. Only authorized administrators can
                    view this page. Contact justin@endao.ai for admin access
                    requests.
                  </AlertDescription>
                </Alert>
                <div className="mt-4 flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => router.push('/dashboard')}
                  >
                    Go to Dashboard
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => router.push('/discover')}
                  >
                    Discover DAOs
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </main>
      </div>
    );
  }

  // Error state
  if (state.error) {
    return (
      <div className="min-h-screen bg-background">
        {/* Sidebar is rendered by AppNavigation in root layout */}
        <main className="pt-16 lg:pt-0 lg:pl-72 flex items-center justify-center min-h-screen">
          <Alert variant="destructive" className="max-w-md">
            <AlertDescription>{state.error}</AlertDescription>
          </Alert>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar is rendered by AppNavigation in root layout */}
      <main className="pt-16 lg:pt-0 lg:pl-72">
        <div className="p-8">
          {/* System Admin Dashboard Component */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <SystemDashboardProvider adminUser={adminUser || null}>
              <SystemDashboard adminUser={adminUser || null} />
            </SystemDashboardProvider>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
