'use client';

import React, { Suspense } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { MembersProvider, MembersPageLayout } from '@/components/admin/members';

function SuperAdminMembersContent() {
  return (
    <MembersProvider>
      <MembersPageLayout />
    </MembersProvider>
  );
}

export default function SuperAdminMembersPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background">
          <div className="container mx-auto px-4 py-8">
            <div className="mb-6">
              <div className="h-8 bg-muted rounded animate-pulse w-48" />
            </div>
            <Card>
              <CardHeader>
                <div className="h-6 bg-muted rounded animate-pulse w-32" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 border rounded"
                    >
                      <div className="space-y-2">
                        <div className="h-4 bg-muted rounded animate-pulse w-48" />
                        <div className="h-3 bg-muted rounded animate-pulse w-32" />
                      </div>
                      <div className="h-8 bg-muted rounded animate-pulse w-20" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      }
    >
      <SuperAdminMembersContent />
    </Suspense>
  );
}
