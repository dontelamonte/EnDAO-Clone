'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  AlertTriangle,
  CreditCard,
  DollarSign,
  ExternalLink,
  MoreVertical,
  RefreshCw,
  Search,
  Shield,
  TrendingUp,
  Users,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import Skeleton from '@/components/ui/skeleton';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useAuth } from '@/lib/auth/auth-context';
import { useAdmin } from '@/hooks/use-admin';
import { useCSRFAPI } from '@/lib/hooks/use-csrf';
import { useToast } from '@/components/ui/use-toast';
import type { SubscriptionTier } from '@endao/shared-types';

interface BillingStats {
  totalSubscriptions: number;
  activeSubscriptions: number;
  trialSubscriptions: number;
  mrr: number;
  arr: number;
  churnRate: number;
}

interface SubscriptionRecord {
  id: string;
  daoId: string;
  daoName: string;
  tier: SubscriptionTier;
  status: string;
  stripeSubscriptionId: string;
  stripeCustomerId: string;
  currentPeriodEnd: string;
  trialEnd: string | null;
  cancelAtPeriodEnd: boolean;
  createdAt: string;
}

export default function AdminBillingPage() {
  const { user, loading: authLoading } = useAuth();
  const { isSuperAdmin, isLoading: adminLoading } = useAdmin();
  const csrfApi = useCSRFAPI();
  const { toast } = useToast();

  const [stats, setStats] = useState<BillingStats | null>(null);
  const [subscriptions, setSubscriptions] = useState<SubscriptionRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch billing data
  const fetchBillingData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await csrfApi.call('/api/admin/billing', {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Failed to fetch billing data');
      }

      const data = await response.json();
      if (data.success) {
        setStats(data.data.stats);
        setSubscriptions(data.data.subscriptions);
      } else {
        throw new Error(data.error || 'Failed to fetch billing data');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  }, [csrfApi]);

  useEffect(() => {
    if (isSuperAdmin) {
      fetchBillingData();
    }
  }, [isSuperAdmin, fetchBillingData]);

  // Handle action on subscription
  const handleAction = async (
    action: string,
    subscriptionId: string,
    daoId: string
  ) => {
    try {
      const response = await csrfApi.call('/api/admin/billing/action', {
        method: 'POST',
        body: JSON.stringify({ action, subscriptionId, daoId }),
      });

      const data = await response.json();
      if (data.success) {
        toast({
          title: 'Action Completed',
          description: data.message || 'Action completed successfully',
        });
        fetchBillingData();
      } else {
        throw new Error(data.error || 'Action failed');
      }
    } catch (err) {
      toast({
        title: 'Action Failed',
        description: err instanceof Error ? err.message : 'Unknown error',
        variant: 'destructive',
      });
    }
  };

  // Loading state
  if (authLoading || adminLoading) {
    return <BillingPageSkeleton />;
  }

  // Auth check
  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <main className="pt-16 lg:pt-0 lg:pl-72 flex items-center justify-center min-h-screen">
          <Alert variant="destructive" className="max-w-md">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Please sign in to access the admin dashboard.
            </AlertDescription>
          </Alert>
        </main>
      </div>
    );
  }

  // Admin check
  if (!isSuperAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <main className="pt-16 lg:pt-0 lg:pl-72 flex items-center justify-center min-h-screen">
          <Alert variant="destructive" className="max-w-md">
            <Shield className="h-4 w-4" />
            <AlertDescription>
              You don&apos;t have permission to access this page. Super admin
              access required.
            </AlertDescription>
          </Alert>
        </main>
      </div>
    );
  }

  // Filter subscriptions by search
  const filteredSubscriptions = subscriptions.filter(
    (sub) =>
      sub.daoName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.stripeSubscriptionId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <main className="pt-16 lg:pt-0 lg:pl-72">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground font-heading">
                  Billing Management
                </h1>
                <p className="text-muted-foreground mt-1">
                  Manage subscriptions, view revenue metrics, and handle billing
                  actions
                </p>
              </div>
              <Button
                onClick={fetchBillingData}
                variant="outline"
                disabled={isLoading}
              >
                <RefreshCw
                  className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`}
                />
                Refresh
              </Button>
            </div>
          </motion.div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Stats Cards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          >
            <StatsCard
              title="Monthly Recurring Revenue"
              value={stats ? `$${(stats.mrr / 100).toLocaleString()}` : '-'}
              icon={DollarSign}
              description="MRR from active subscriptions"
              loading={isLoading}
            />
            <StatsCard
              title="Active Subscriptions"
              value={stats?.activeSubscriptions?.toString() || '0'}
              icon={CreditCard}
              description="Paid subscriptions"
              loading={isLoading}
            />
            <StatsCard
              title="Trial Subscriptions"
              value={stats?.trialSubscriptions?.toString() || '0'}
              icon={Users}
              description="In trial period"
              loading={isLoading}
            />
            <StatsCard
              title="Monthly Churn"
              value={stats ? `${stats.churnRate.toFixed(1)}%` : '-'}
              icon={TrendingUp}
              description="Last 30 days"
              loading={isLoading}
            />
          </motion.div>

          {/* Subscriptions Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Subscriptions</CardTitle>
                    <CardDescription>
                      View and manage all DAO subscriptions
                    </CardDescription>
                  </div>
                  <div className="relative w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by name or ID..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Skeleton key={i} className="h-12 w-full" />
                    ))}
                  </div>
                ) : filteredSubscriptions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    {searchQuery
                      ? 'No subscriptions match your search'
                      : 'No subscriptions found'}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Group</TableHead>
                        <TableHead>Tier</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Period End</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSubscriptions.map((sub) => (
                        <TableRow key={sub.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{sub.daoName}</p>
                              <p className="text-xs text-muted-foreground">
                                {sub.stripeSubscriptionId}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">{sub.tier}</Badge>
                          </TableCell>
                          <TableCell>
                            <StatusBadge
                              status={sub.status}
                              cancelAtPeriodEnd={sub.cancelAtPeriodEnd}
                            />
                          </TableCell>
                          <TableCell>
                            {sub.trialEnd
                              ? `Trial ends ${new Date(sub.trialEnd).toLocaleDateString()}`
                              : new Date(
                                  sub.currentPeriodEnd
                                ).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {new Date(sub.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() =>
                                    window.open(
                                      `https://dashboard.stripe.com/subscriptions/${sub.stripeSubscriptionId}`,
                                      '_blank'
                                    )
                                  }
                                >
                                  <ExternalLink className="h-4 w-4 mr-2" />
                                  View in Stripe
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() =>
                                    handleAction(
                                      'extend_trial',
                                      sub.id,
                                      sub.daoId
                                    )
                                  }
                                >
                                  Extend Trial (7 days)
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() =>
                                    handleAction('upgrade', sub.id, sub.daoId)
                                  }
                                >
                                  Manual Tier Override
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

// Stats card component
function StatsCard({
  title,
  value,
  icon: Icon,
  description,
  loading,
}: {
  title: string;
  value: string;
  icon: React.ElementType;
  description: string;
  loading: boolean;
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            {loading ? (
              <Skeleton className="h-8 w-24 mt-1" />
            ) : (
              <p className="text-2xl font-bold">{value}</p>
            )}
            <p className="text-xs text-muted-foreground">{description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Status badge component
function StatusBadge({
  status,
  cancelAtPeriodEnd,
}: {
  status: string;
  cancelAtPeriodEnd: boolean;
}) {
  if (cancelAtPeriodEnd) {
    return (
      <Badge variant="outline" className="text-amber-600 border-amber-300">
        Canceling
      </Badge>
    );
  }

  switch (status) {
    case 'active':
      return <Badge className="bg-green-100 text-green-800">Active</Badge>;
    case 'trialing':
      return <Badge className="bg-blue-100 text-blue-800">Trial</Badge>;
    case 'past_due':
      return <Badge variant="destructive">Past Due</Badge>;
    case 'canceled':
      return <Badge variant="secondary">Canceled</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

// Loading skeleton
function BillingPageSkeleton() {
  return (
    <div className="min-h-screen bg-background">
      <main className="pt-16 lg:pt-0 lg:pl-72">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-10 w-64 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
