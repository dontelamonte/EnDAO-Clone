'use client';

import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  ReactNode,
} from 'react';
import { DAO, DAOStatus, UpdateDAOFormData } from '@endao/shared-types';
import { DAOService } from '@/lib/services/dao';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/auth/auth-context';

export interface DAOListItem extends Omit<DAO, 'memberCount'> {
  memberCount?: number;
  lastActivity?: Date;
}

interface DAOActionDialog {
  open: boolean;
  action: 'archive' | 'activate' | null;
  loading: boolean;
}

interface DAOManagementState {
  daos: DAOListItem[];
  loading: boolean;
  error: string | null;
  searchTerm: string;
  statusFilter: 'all' | 'active' | 'archived';
  selectedDAO: DAOListItem | null;
  actionDialog: DAOActionDialog;
  // Pagination state
  currentPage: number;
  itemsPerPage: number;
  totalCount: number;
  hasMore: boolean;
  loadingMore: boolean;
}

interface DAOManagementContextValue extends DAOManagementState {
  // Actions
  loadDAOs: (reset?: boolean) => Promise<void>;
  setSearchTerm: (term: string) => void;
  setStatusFilter: (status: 'all' | 'active' | 'archived') => void;
  selectDAO: (dao: DAOListItem | null) => void;
  openActionDialog: (action: 'archive' | 'activate', dao: DAOListItem) => void;
  closeActionDialog: () => void;
  executeAction: () => Promise<void>;
  loadMoreDAOs: () => Promise<void>;
}

const DAOManagementContext = createContext<
  DAOManagementContextValue | undefined
>(undefined);

export const useDAOManagement = () => {
  const context = useContext(DAOManagementContext);
  if (!context) {
    throw new Error(
      'useDAOManagement must be used within DAOManagementProvider'
    );
  }
  return context;
};

interface DAOManagementProviderProps {
  children: ReactNode;
}

export const DAOManagementProvider: React.FC<DAOManagementProviderProps> = ({
  children,
}) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const daoService = DAOService.getInstance();

  const [state, setState] = useState<DAOManagementState>({
    daos: [],
    loading: true,
    error: null,
    searchTerm: '',
    statusFilter: 'all',
    selectedDAO: null,
    actionDialog: {
      open: false,
      action: null,
      loading: false,
    },
    currentPage: 0,
    itemsPerPage: 20,
    totalCount: 0,
    hasMore: false,
    loadingMore: false,
  });

  const loadDAOs = useCallback(
    async (reset = true) => {
      try {
        const loadStartTime = performance.now();
        setState((prev) => ({
          ...prev,
          loading: reset,
          loadingMore: !reset,
          error: null,
        }));

        const offset = reset ? 0 : state.currentPage * state.itemsPerPage;

        const result = await daoService.searchDAOs({
          query: state.searchTerm,
          sortBy: 'createdAt',
          sortOrder: 'desc',
          status: state.statusFilter === 'all' ? undefined : state.statusFilter,
          limit: state.itemsPerPage,
          offset: offset,
        });

        if (result.success && result.data) {
          const enhancedDAOs = result.data.daos.map((dao) => ({
            ...dao,
            memberCount: dao.memberCount || 0,
            lastActivity: dao.updatedAt
              ? new Date(dao.updatedAt)
              : new Date(dao.createdAt),
          }));

          setState((prev) => ({
            ...prev,
            daos: reset ? enhancedDAOs : [...prev.daos, ...enhancedDAOs],
            loading: false,
            loadingMore: false,
            totalCount: result.data?.total || 0,
            hasMore: result.data?.hasMore || false,
            currentPage: reset ? 1 : prev.currentPage + 1,
          }));

          const loadEndTime = performance.now();
          const loadTime = loadEndTime - loadStartTime;
        }

        if (!result.success) {
          throw new Error(result.error || 'Failed to load DAOs');
        }
      } catch (error) {
        console.error('Error loading DAOs:', error);
        setState((prev) => ({
          ...prev,
          loading: false,
          loadingMore: false,
          error: error instanceof Error ? error.message : 'Failed to load DAOs',
        }));
        toast({
          title: 'Error',
          description: 'Failed to load DAOs. Please try again.',
          variant: 'destructive',
        });
      }
    },
    [
      state.currentPage,
      state.itemsPerPage,
      state.searchTerm,
      state.statusFilter,
      daoService,
      toast,
    ]
  );

  const setSearchTerm = useCallback((term: string) => {
    setState((prev) => ({ ...prev, searchTerm: term, currentPage: 0 }));
  }, []);

  const setStatusFilter = useCallback(
    (status: 'all' | 'active' | 'archived') => {
      setState((prev) => ({ ...prev, statusFilter: status, currentPage: 0 }));
    },
    []
  );

  const selectDAO = useCallback((dao: DAOListItem | null) => {
    setState((prev) => ({ ...prev, selectedDAO: dao }));
  }, []);

  const openActionDialog = useCallback(
    (action: 'archive' | 'activate', dao: DAOListItem) => {
      setState((prev) => ({
        ...prev,
        selectedDAO: dao,
        actionDialog: { open: true, action, loading: false },
      }));
    },
    []
  );

  const closeActionDialog = useCallback(() => {
    setState((prev) => ({
      ...prev,
      actionDialog: { open: false, action: null, loading: false },
    }));
  }, []);

  const executeAction = useCallback(async () => {
    if (!state.selectedDAO || !state.actionDialog.action) return;

    setState((prev) => ({
      ...prev,
      actionDialog: { ...prev.actionDialog, loading: true },
    }));

    try {
      const newStatus: DAOStatus =
        state.actionDialog.action === 'archive' ? 'archived' : 'active';
      const result = await daoService.updateDAO(
        state.selectedDAO.id,
        {
          id: state.selectedDAO.id,
          status: newStatus,
        } as UpdateDAOFormData,
        user?.uid || ''
      );

      if (result.success) {
        // Update the DAO in the list
        setState((prev) => ({
          ...prev,
          daos: prev.daos.map((dao) =>
            dao.id === state.selectedDAO?.id
              ? { ...dao, status: newStatus }
              : dao
          ),
          actionDialog: { open: false, action: null, loading: false },
          selectedDAO: null,
        }));

        toast({
          title: 'Success',
          description: `DAO ${state.actionDialog.action}d successfully`,
        });
      } else {
        throw new Error(
          result.error || `Failed to ${state.actionDialog.action} DAO`
        );
      }
    } catch (error) {
      console.error('Error executing action:', error);
      setState((prev) => ({
        ...prev,
        actionDialog: { ...prev.actionDialog, loading: false },
      }));
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Action failed',
        variant: 'destructive',
      });
    }
  }, [state.selectedDAO, state.actionDialog.action, daoService, toast]);

  const loadMoreDAOs = useCallback(async () => {
    if (!state.loadingMore && state.hasMore) {
      await loadDAOs(false);
    }
  }, [state.loadingMore, state.hasMore, loadDAOs]);

  const value: DAOManagementContextValue = {
    ...state,
    loadDAOs,
    setSearchTerm,
    setStatusFilter,
    selectDAO,
    openActionDialog,
    closeActionDialog,
    executeAction,
    loadMoreDAOs,
  };

  return (
    <DAOManagementContext.Provider value={value}>
      {children}
    </DAOManagementContext.Provider>
  );
};
