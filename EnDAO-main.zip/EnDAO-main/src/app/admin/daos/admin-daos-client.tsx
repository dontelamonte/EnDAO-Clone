'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { useToast } from '@/components/ui/use-toast';
import { csrfFetch } from '@/lib/security/csrf-client';

// Simple DAO interface
interface SimpleDAO {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: 'active' | 'archived';
  memberCount: number;
  createdAt: string;
  lastActivity: string;
}

// API DAO interface for typing the unknown object
interface APIDAO {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: 'active' | 'archived';
  createdAt: string;
  updatedAt?: string;
  stats?: {
    memberCount: number;
  };
}

/**
 * Admin DAOs Client Component
 *
 * CRITICAL: This component manages real DAO data only.
 * - Never initializes with mock data
 * - Prevents operations on non-existent DAOs
 * - Shows clear error states when data unavailable
 */
// eslint-disable-next-line max-lines-per-function, max-statements
export function AdminDAOsClient() {
  const router = useRouter();
  const { toast } = useToast();

  // Simple state - initialize with empty array, NO mock data
  const [daos, setDAOs] = useState<SimpleDAO[]>([]);
  const [loading, setLoading] = useState(true); // Start loading to fetch real data
  const [error, setError] = useState('');
  const [dataLoadFailed, setDataLoadFailed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Load real data - show error if fails
  const loadDAOs = async () => {
    try {
      setLoading(true);
      setError('');
      setDataLoadFailed(false);

      const response = await csrfFetch('/api/admin/daos', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.daos) {
        const simpleDAOs: SimpleDAO[] = data.daos.map((dao: APIDAO) => ({
          id: dao.id,
          name: dao.name,
          slug: dao.slug,
          description: dao.description,
          status: dao.status,
          memberCount: dao.stats?.memberCount || 0,
          createdAt: dao.createdAt,
          lastActivity: dao.updatedAt || dao.createdAt,
        }));
        setDAOs(simpleDAOs);
        setDataLoadFailed(false);
      } else {
        throw new Error('Invalid response format');
      }
    } catch (err) {
      console.error('Failed to load DAOs:', err);
      setError(
        'Failed to load DAO data. Please refresh the page to try again.'
      );
      setDataLoadFailed(true);
      setDAOs([]); // Ensure empty array on error
    } finally {
      setLoading(false);
    }
  };

  // Update DAO status - only works with real data
  const updateDAOStatus = async (
    daoId: string,
    newStatus: 'active' | 'archived'
  ) => {
    // Prevent operations if data load failed
    if (dataLoadFailed) {
      toast({
        title: 'Error',
        description: 'Cannot perform operations - real DAO data not loaded',
        variant: 'destructive',
      });
      return;
    }

    try {
      const response = await csrfFetch('/api/admin/daos/update', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: daoId,
          status: newStatus,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        // Update local state
        setDAOs((prevDAOs) =>
          prevDAOs.map((dao) =>
            dao.id === daoId
              ? {
                  ...dao,
                  status: newStatus,
                  lastActivity: new Date().toISOString(),
                }
              : dao
          )
        );

        toast({
          title: 'Success',
          description: `DAO ${newStatus === 'archived' ? 'archived' : 'activated'} successfully`,
        });
      } else {
        throw new Error(data.error || 'Failed to update DAO');
      }
    } catch (err) {
      console.error('Error updating DAO:', err);
      toast({
        title: 'Error',
        description: 'Failed to update DAO',
        variant: 'destructive',
      });
    }
  };

  // Simple event handlers
  const handleViewDAO = (dao: SimpleDAO) => {
    if (dataLoadFailed) {
      toast({
        title: 'Error',
        description: 'Cannot view DAO - real data not loaded',
        variant: 'destructive',
      });
      return;
    }
    router.push(`/dao/${dao.id}`);
  };

  const handleArchiveDAO = (dao: SimpleDAO) => {
    // eslint-disable-next-line no-alert
    if (window.confirm(`Are you sure you want to archive "${dao.name}"?`)) {
      updateDAOStatus(dao.id, 'archived');
    }
  };

  const handleActivateDAO = (dao: SimpleDAO) => {
    // eslint-disable-next-line no-alert
    if (window.confirm(`Are you sure you want to activate "${dao.name}"?`)) {
      updateDAOStatus(dao.id, 'active');
    }
  };

  // Load real data on mount
  useEffect(() => {
    loadDAOs();
  }, []);

  // Filter DAOs
  const filteredDAOs = daos.filter((dao) => {
    const matchesSearch =
      !searchTerm ||
      dao.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dao.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dao.slug.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || dao.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Calculate stats
  const totalDAOs = daos.length;
  const activeDAOs = daos.filter((dao) => dao.status === 'active').length;
  const archivedDAOs = daos.filter((dao) => dao.status === 'archived').length;
  const totalMembers = daos.reduce((sum, dao) => sum + dao.memberCount, 0);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-6">
        <Button
          variant="ghost"
          onClick={() => router.push('/admin')}
          className="mb-4"
        >
          <Icon name="ArrowLeft" className="mr-2 h-4 w-4" />
          Back to Admin
        </Button>
        <h1 className="text-3xl font-bold mb-2">DAO Management</h1>
        <p className="text-muted-foreground">
          Manage and monitor all DAOs in the system
        </p>
      </div>

      {/* Loading indicator */}
      {loading && (
        <Alert className="mb-6">
          <Icon name="Loader2" className="h-4 w-4 animate-spin" />
          <AlertDescription>Loading DAO data...</AlertDescription>
        </Alert>
      )}

      {/* Error Alert - Critical: prevents operations on non-existent data */}
      {dataLoadFailed && (
        <Alert className="mb-6" variant="destructive">
          <Icon name="AlertTriangle" className="h-4 w-4" />
          <AlertDescription>
            <div className="font-semibold mb-1">Failed to Load DAO Data</div>
            <div className="text-sm">{error}</div>
            <div className="text-sm mt-2">
              All operations are disabled until real data is loaded.
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={loadDAOs}
              className="mt-3"
            >
              <Icon name="RotateCcw" className="h-4 w-4 mr-1" />
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total DAOs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDAOs}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active DAOs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeDAOs}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Archived DAOs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{archivedDAOs}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMembers}</div>
          </CardContent>
        </Card>
      </div>

      {/* DAO List */}
      <Card>
        <CardHeader>
          <CardTitle>All DAOs</CardTitle>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              placeholder="Search DAOs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="sm:max-w-sm"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {loading && daos.length === 0 ? (
            <div className="text-center py-12">
              <Icon
                name="Loader2"
                className="h-8 w-8 animate-spin mx-auto mb-4 text-muted-foreground"
              />
              <p className="text-muted-foreground">Loading DAOs...</p>
            </div>
          ) : filteredDAOs.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                {dataLoadFailed
                  ? 'No data available - failed to load DAOs'
                  : searchTerm || statusFilter !== 'all'
                    ? 'No DAOs match your search criteria.'
                    : 'No DAOs found.'}
              </p>
            </div>
          ) : (
            <>
              {/* DAO List */}
              <div className="space-y-2">
                {filteredDAOs.map((dao) => (
                  <div
                    key={dao.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold">{dao.name}</h3>
                        <Badge
                          variant={
                            dao.status === 'active' ? 'default' : 'secondary'
                          }
                        >
                          {dao.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {dao.description}
                      </p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
                        <span>{dao.memberCount} members</span>
                        <span>
                          Created:{' '}
                          {new Date(dao.createdAt).toLocaleDateString()}
                        </span>
                        <span>
                          Last activity:{' '}
                          {new Date(dao.lastActivity).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    {/* Actions - disabled if data load failed */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDAO(dao)}
                        disabled={dataLoadFailed}
                      >
                        <Icon name="Eye" className="h-4 w-4 mr-1" />
                        View
                      </Button>

                      {dao.status === 'active' ? (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleArchiveDAO(dao)}
                          disabled={dataLoadFailed}
                        >
                          <Icon name="Archive" className="h-4 w-4 mr-1" />
                          Archive
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleActivateDAO(dao)}
                          disabled={dataLoadFailed}
                        >
                          <Icon name="RotateCcw" className="h-4 w-4 mr-1" />
                          Activate
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Footer */}
              <div className="mt-6 text-sm text-muted-foreground text-center">
                Showing {filteredDAOs.length} of {totalDAOs} DAOs
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
