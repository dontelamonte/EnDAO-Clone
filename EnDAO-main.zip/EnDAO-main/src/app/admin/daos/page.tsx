import { AdminDAOsClient } from './admin-daos-client';

// Force dynamic rendering - prevents any SSG that could cause recursion
export const dynamic = 'force-dynamic';
export const revalidate = 0;

/**
 * Admin DAOs Page - Minimal Server Component
 *
 * This is the absolute minimal approach to eliminate infinite recursion:
 * 1. Server component does NOTHING except render client component
 * 2. No imports of complex services or components
 * 3. No Suspense boundaries
 * 4. Force dynamic rendering
 * 5. All functionality delegated to client component
 */
export default function AdminDAOsPage() {
  // Minimal server component - no logic, no imports, no complexity
  return <AdminDAOsClient />;
}
