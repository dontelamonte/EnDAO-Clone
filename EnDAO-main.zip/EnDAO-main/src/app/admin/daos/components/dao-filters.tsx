'use client';

import React from 'react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { useDAOManagement } from '../context/dao-management-context';

export const DAOFilters: React.FC = () => {
  const {
    searchTerm,
    statusFilter,
    setSearchTerm,
    setStatusFilter,
    loadDAOs,
    loading,
  } = useDAOManagement();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadDAOs(true);
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSearch} className="flex gap-4">
        <div className="flex-1 flex gap-2">
          <div className="relative flex-1">
            <Icon
              name="Search"
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4"
            />
            <Input
              placeholder="Search DAOs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button type="submit" disabled={loading}>
            Search
          </Button>
        </div>

        <Select
          value={statusFilter}
          onValueChange={(value) => {
            setStatusFilter(value as 'all' | 'active' | 'archived');
            loadDAOs(true);
          }}
        >
          <SelectTrigger className="w-40">
            <Icon name="Filter" className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All DAOs</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>

        <Button
          variant="outline"
          onClick={() => {
            setSearchTerm('');
            setStatusFilter('all');
            loadDAOs(true);
          }}
          disabled={loading}
        >
          <Icon name="RefreshCw" className="w-4 h-4 mr-2" />
          Reset
        </Button>
      </form>
    </div>
  );
};
