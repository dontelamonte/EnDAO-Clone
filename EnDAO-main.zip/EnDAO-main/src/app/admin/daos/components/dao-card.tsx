'use client';

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { formatDistanceToNow } from 'date-fns';
import type { DAOListItem } from '../context/dao-management-context';

interface DAOCardProps {
  dao: DAOListItem;
  onView: (dao: DAOListItem) => void;
  onAction: (action: 'archive' | 'activate', dao: DAOListItem) => void;
}

export const DAOCard: React.FC<DAOCardProps> = ({ dao, onView, onAction }) => {
  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
      active: 'default',
      archived: 'secondary',
      inactive: 'destructive',
    };
    return <Badge variant={variants[status] || 'default'}>{status}</Badge>;
  };

  return (
    <Card className="mb-3">
      <CardContent className="p-4">
        {/* Header: Name + Status */}
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="font-medium text-lg">{dao.name}</p>
            <div className="mt-1">{getStatusBadge(dao.status)}</div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
          <div className="flex items-center gap-2">
            <Icon name="Users" className="h-4 w-4 text-muted-foreground" />
            <span>{dao.memberCount || 0} members</span>
          </div>
          <div className="flex items-center gap-2">
            <Icon name="Clock" className="h-4 w-4 text-muted-foreground" />
            <span>
              {dao.lastActivity
                ? formatDistanceToNow(dao.lastActivity, { addSuffix: true })
                : 'Never active'}
            </span>
          </div>
          <div className="flex items-center gap-2 col-span-2">
            <Icon name="Calendar" className="h-4 w-4 text-muted-foreground" />
            <span>
              Created{' '}
              {formatDistanceToNow(new Date(dao.createdAt as string), {
                addSuffix: true,
              })}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="flex-1"
            onClick={() => onView(dao)}
          >
            <Icon name="Eye" className="w-4 h-4 mr-1" />
            View
          </Button>
          {dao.status === 'active' ? (
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={() => onAction('archive', dao)}
            >
              <Icon name="Archive" className="w-4 h-4 mr-1" />
              Archive
            </Button>
          ) : (
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={() => onAction('activate', dao)}
            >
              <Icon name="RotateCcw" className="w-4 h-4 mr-1" />
              Activate
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
