'use client';

import React, { memo, useMemo } from 'react';
import { FixedSizeList as List } from 'react-window';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import { format } from 'date-fns';

interface DAOListItem {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: 'active' | 'archived';
  memberCount?: number;
  lastActivity?: Date;
  createdAt: unknown;
}

interface DAOListTableVirtualizedProps {
  daos: DAOListItem[];
  onViewDAO: (_dao: DAOListItem) => void;
  onArchiveDAO: (_dao: DAOListItem) => void;
  onActivateDAO: (_dao: DAOListItem) => void;
}

interface RowData {
  daos: DAOListItem[];
  onViewDAO: (_dao: DAOListItem) => void;
  onArchiveDAO: (_dao: DAOListItem) => void;
  onActivateDAO: (_dao: DAOListItem) => void;
}

interface RowProps {
  index: number;
  style: React.CSSProperties;
  data: RowData;
}

// Fixed row height for virtual scrolling
const ROW_HEIGHT = 72;
const HEADER_HEIGHT = 56;

// Memoized row component for optimal performance
const Row = memo(
  ({ index, style, data }: RowProps) => {
    const { daos, onViewDAO, onArchiveDAO, onActivateDAO } = data;
    const dao = daos[index];

    if (!dao) return null;

    return (
      <div
        style={style}
        className="flex items-center px-4 border-b hover:bg-muted/50 transition-colors"
      >
        <div className="flex-1 py-2">
          <div className="font-medium">{dao.name}</div>
          <div className="text-sm text-muted-foreground">{dao.slug}</div>
        </div>

        <div className="w-24 text-center">
          <Badge variant={dao.status === 'active' ? 'default' : 'secondary'}>
            {dao.status}
          </Badge>
        </div>

        <div className="w-20 text-center text-sm">{dao.memberCount || 0}</div>

        <div className="w-32 text-sm text-muted-foreground">
          {dao.lastActivity ? format(dao.lastActivity, 'MMM dd, yyyy') : '-'}
        </div>

        <div className="flex gap-2 w-48 justify-end">
          <Button size="sm" variant="ghost" onClick={() => onViewDAO(dao)}>
            <Icon name="Eye" className="h-4 w-4" />
          </Button>

          {dao.status === 'active' ? (
            <Button size="sm" variant="ghost" onClick={() => onArchiveDAO(dao)}>
              <Icon name="Archive" className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onActivateDAO(dao)}
            >
              <Icon name="CheckCircle" className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    );
  },
  (prevProps, nextProps) => {
    // Custom comparison for memoization
    const prevDao = prevProps.data.daos[prevProps.index];
    const nextDao = nextProps.data.daos[nextProps.index];

    if (!prevDao || !nextDao) return false;

    return (
      prevDao.id === nextDao.id &&
      prevDao.status === nextDao.status &&
      prevDao.memberCount === nextDao.memberCount &&
      prevProps.style === nextProps.style
    );
  }
);

Row.displayName = 'VirtualizedDAORow';

export function DAOListTableVirtualized({
  daos,
  onViewDAO,
  onArchiveDAO,
  onActivateDAO,
}: DAOListTableVirtualizedProps) {
  // Memoize the item data to prevent unnecessary re-renders
  const itemData = useMemo(
    () => ({
      daos,
      onViewDAO,
      onArchiveDAO,
      onActivateDAO,
    }),
    [daos, onViewDAO, onArchiveDAO, onActivateDAO]
  );

  // Calculate optimal height based on viewport
  const listHeight = Math.min(
    ROW_HEIGHT * 12, // Show max 12 rows
    ROW_HEIGHT * daos.length + HEADER_HEIGHT
  );

  return (
    <div className="w-full">
      {/* Table Header */}
      <div
        className="flex items-center px-4 py-3 bg-muted/50 border-b font-medium text-sm"
        style={{ height: HEADER_HEIGHT }}
      >
        <div className="flex-1">DAO Name</div>
        <div className="w-24 text-center">Status</div>
        <div className="w-20 text-center">Members</div>
        <div className="w-32">Last Activity</div>
        <div className="w-48 text-right">Actions</div>
      </div>

      {/* Virtual Scrolling List */}
      {daos.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          No DAOs found
        </div>
      ) : (
        <List
          height={listHeight}
          itemCount={daos.length}
          itemSize={ROW_HEIGHT}
          width="100%"
          itemData={itemData}
          overscanCount={3} // Render 3 extra items above/below viewport
        >
          {Row}
        </List>
      )}
    </div>
  );
}
