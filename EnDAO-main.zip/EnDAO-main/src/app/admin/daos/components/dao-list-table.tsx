'use client';

import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Icon } from '@/components/ui/icon';
import { DAO, DAOStatus } from '@endao/shared-types';

interface DAOListItem extends Omit<DAO, 'memberCount'> {
  memberCount?: number;
  lastActivity?: Date;
}

interface DAOListTableProps {
  daos: DAOListItem[];
  onViewDAO: (_dao: DAOListItem) => void;
  onArchiveDAO: (_dao: DAOListItem) => void;
  onActivateDAO: (_dao: DAOListItem) => void;
}

export const DAOListTable: React.FC<DAOListTableProps> = ({
  daos,
  onViewDAO,
  onArchiveDAO,
  onActivateDAO,
}) => {
  const getStatusBadge = (status: DAOStatus) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'archived':
        return <Badge className="bg-gray-100 text-gray-800">Archived</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatDate = (date: Date | undefined) => {
    if (!date) return 'Unknown';
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  };

  const formatLastActivity = (date: Date | undefined) => {
    if (!date) return 'No activity';

    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return 'Yesterday';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`;
    if (diffInDays < 365) return `${Math.floor(diffInDays / 30)} months ago`;
    return `${Math.floor(diffInDays / 365)} years ago`;
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>DAO Name</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>
              <div className="flex items-center gap-1">
                <Icon name="Users" className="h-4 w-4" />
                Members
              </div>
            </TableHead>
            <TableHead>
              <div className="flex items-center gap-1">
                <Icon name="Calendar" className="h-4 w-4" />
                Created
              </div>
            </TableHead>
            <TableHead>Last Activity</TableHead>
            <TableHead>Visibility</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {daos.map((dao) => (
            <TableRow key={dao.id}>
              <TableCell>
                <div className="flex items-center space-x-3">
                  {dao.logoUrl && (
                    <img
                      src={dao.logoUrl}
                      alt={dao.name}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  )}
                  <div>
                    <div className="font-medium">{dao.name}</div>
                    <div className="text-sm text-muted-foreground truncate max-w-xs">
                      {dao.description || 'No description'}
                    </div>
                  </div>
                </div>
              </TableCell>
              <TableCell>{getStatusBadge(dao.status)}</TableCell>
              <TableCell>
                <div className="flex items-center gap-1">
                  <Icon
                    name="Users"
                    className="h-4 w-4 text-muted-foreground"
                  />
                  {dao.memberCount || 0}
                </div>
              </TableCell>
              <TableCell>
                {formatDate(
                  dao.createdAt ? new Date(dao.createdAt) : undefined
                )}
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">
                {formatLastActivity(dao.lastActivity)}
              </TableCell>
              <TableCell>
                <Badge variant="outline">
                  {dao.visibility === 'private' ? 'Private' : 'Public'}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <Icon name="MoreHorizontal" className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onViewDAO(dao)}>
                      <Icon name="Eye" className="mr-2 h-4 w-4" />
                      View Details
                    </DropdownMenuItem>
                    {dao.status === 'active' ? (
                      <DropdownMenuItem onClick={() => onArchiveDAO(dao)}>
                        <Icon name="Archive" className="mr-2 h-4 w-4" />
                        Archive DAO
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem onClick={() => onActivateDAO(dao)}>
                        <Icon name="RotateCcw" className="mr-2 h-4 w-4" />
                        Activate DAO
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
