'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Icon } from '@/components/ui/icon';
import { DAO } from '@endao/shared-types';

interface DAOListItem extends Omit<DAO, 'memberCount'> {
  memberCount?: number;
  lastActivity?: Date;
}

interface DAOActionDialogProps {
  open: boolean;
  action: 'archive' | 'activate' | null;
  loading: boolean;
  selectedDAO: DAOListItem | null;
  onClose: () => void;
  onConfirm: () => void;
}

export const DAOActionDialog: React.FC<DAOActionDialogProps> = ({
  open,
  action,
  loading,
  selectedDAO,
  onClose,
  onConfirm,
}) => {
  if (!action || !selectedDAO) return null;

  const isArchiving = action === 'archive';
  const title = isArchiving ? 'Archive DAO' : 'Activate DAO';
  const description = isArchiving
    ? `Are you sure you want to archive "${selectedDAO.name}"? This will make the DAO read-only and prevent new members from joining.`
    : `Are you sure you want to activate "${selectedDAO.name}"? This will make the DAO fully functional again.`;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Icon name="AlertTriangle" className="h-5 w-5 text-orange-500" />
            <DialogTitle>{title}</DialogTitle>
          </div>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <div className="bg-muted/50 p-4 rounded-lg">
            <div className="font-medium mb-1">{selectedDAO.name}</div>
            <div className="text-sm text-muted-foreground mb-2">
              {selectedDAO.description}
            </div>
            <div className="text-xs text-muted-foreground">
              Members: {selectedDAO.memberCount || 0} • Status:{' '}
              {selectedDAO.status}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button
            variant={isArchiving ? 'destructive' : 'default'}
            onClick={onConfirm}
            disabled={loading}
          >
            {loading
              ? 'Processing...'
              : isArchiving
                ? 'Archive DAO'
                : 'Activate DAO'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
