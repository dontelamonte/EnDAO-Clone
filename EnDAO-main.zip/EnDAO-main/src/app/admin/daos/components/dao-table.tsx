'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Icon } from '@/components/ui/icon';
import {
  useDAOManagement,
  type DAOListItem,
} from '../context/dao-management-context';
import { DAOCard } from './dao-card';
import { formatDistanceToNow } from 'date-fns';

export const DAOTable: React.FC = () => {
  const { daos, openActionDialog, selectDAO } = useDAOManagement();

  const handleView = (dao: DAOListItem) => {
    // Navigate to DAO detail page
    window.location.href = `/dao/${dao.id}`;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
      active: 'default',
      archived: 'secondary',
      inactive: 'destructive',
    };
    return <Badge variant={variants[status] || 'default'}>{status}</Badge>;
  };

  return (
    <>
      {/* Desktop: Table view */}
      <div className="hidden md:block rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Members</TableHead>
              <TableHead>Last Activity</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {daos.map((dao) => (
              <TableRow key={dao.id}>
                <TableCell className="font-medium">{dao.name}</TableCell>
                <TableCell>{getStatusBadge(dao.status)}</TableCell>
                <TableCell>{dao.memberCount || 0}</TableCell>
                <TableCell>
                  {dao.lastActivity
                    ? formatDistanceToNow(dao.lastActivity, { addSuffix: true })
                    : 'Never'}
                </TableCell>
                <TableCell>
                  {formatDistanceToNow(new Date(dao.createdAt as string), {
                    addSuffix: true,
                  })}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleView(dao)}
                    >
                      <Icon name="Eye" className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    {dao.status === 'active' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openActionDialog('archive', dao)}
                      >
                        <Icon name="Archive" className="w-4 h-4 mr-1" />
                        Archive
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openActionDialog('activate', dao)}
                      >
                        <Icon name="RotateCcw" className="w-4 h-4 mr-1" />
                        Activate
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Mobile: Card view */}
      <div className="block md:hidden">
        {daos.map((dao) => (
          <DAOCard
            key={dao.id}
            dao={dao}
            onView={handleView}
            onAction={openActionDialog}
          />
        ))}
      </div>
    </>
  );
};
