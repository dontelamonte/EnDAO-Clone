'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import Skeleton from '@/components/ui/skeleton';
import { Icon } from '@/components/ui/icon';
import { useAuth } from '@/lib/auth/auth-context';
import { useAdmin } from '@/hooks/use-admin';
import { useToast } from '@/components/ui/use-toast';

interface ProposalWithDAO {
  id: string;
  daoId: string;
  daoName: string;
  title: string;
  description: string;
  type: string;
  status: string;
  createdAt: string;
  createdBy: string;
  startDate: string | null;
  endDate: string | null;
  results: {
    totalVotes: number;
    options?: Record<string, unknown>;
  };
}

export default function AdminProposalsPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { isSuperAdmin, isLoading: adminLoading } = useAdmin();
  const { toast } = useToast();

  const [proposals, setProposals] = useState<ProposalWithDAO[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deleteModal, setDeleteModal] = useState<{
    open: boolean;
    proposal: ProposalWithDAO | null;
  }>({ open: false, proposal: null });
  const [deleting, setDeleting] = useState(false);

  // Fetch all proposals
  useEffect(() => {
    if (!adminLoading && isSuperAdmin) {
      fetchProposals();
    }
  }, [adminLoading, isSuperAdmin]);

  const fetchProposals = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/proposals?limit=200');
      const result = await response.json();

      if (result.success && result.data?.proposals) {
        setProposals(result.data.proposals);
      } else {
        console.error('Failed to fetch proposals:', result.error);
        toast({
          title: 'Error',
          description: result.error || 'Failed to load proposals',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Failed to fetch proposals:', error);
      toast({
        title: 'Error',
        description: 'Failed to load proposals',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProposal = async () => {
    if (!deleteModal.proposal) return;

    try {
      setDeleting(true);
      const proposal = deleteModal.proposal;

      // Use API route to delete the proposal (soft delete via Supabase)
      const response = await fetch(`/api/proposals/${proposal.id}/delete`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete proposal');
      }

      // Remove from local state
      setProposals((prev) =>
        prev.filter((p) => p.id !== deleteModal.proposal?.id)
      );
      setDeleteModal({ open: false, proposal: null });

      // Show success message
      toast({
        title: 'Proposal Deleted',
        description:
          'The proposal has been successfully deleted and DAO stats have been updated.',
      });
    } catch (error) {
      console.error('Failed to delete proposal:', error);
      toast({
        title: 'Error',
        description:
          error instanceof Error
            ? error.message
            : 'Failed to delete proposal. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setDeleting(false);
    }
  };

  // Check permissions
  if (!adminLoading && !isSuperAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Alert variant="destructive">
          <Icon name="AlertTriangle" className="h-4 w-4" />
          <AlertDescription>
            You don&apos;t have permission to access this page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Filter proposals
  const filteredProposals = proposals.filter((proposal) => {
    const matchesSearch =
      proposal.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      proposal.daoName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      proposal.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === 'all' || proposal.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active':
        return 'default';
      case 'passed':
        return 'success';
      case 'rejected':
        return 'destructive';
      case 'draft':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Proposal Management</h1>
        <p className="text-muted-foreground">
          Manage all proposals across all DAOs
        </p>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Icon
                  name="Search"
                  className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"
                />
                <Input
                  placeholder="Search by title, DAO, or ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="passed">Passed</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Proposals Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Icon name="Vote" className="h-5 w-5" />
            All Proposals ({filteredProposals.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredProposals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No proposals found
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>DAO</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Votes</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProposals.map((proposal) => (
                    <TableRow key={proposal.id}>
                      <TableCell className="font-medium max-w-[300px] truncate">
                        {proposal.title}
                      </TableCell>
                      <TableCell>{proposal.daoName}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(proposal.status)}>
                          {proposal.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="capitalize">
                        {proposal.type}
                      </TableCell>
                      <TableCell>{proposal.results.totalVotes}</TableCell>
                      <TableCell>
                        {proposal.createdAt
                          ? new Date(proposal.createdAt).toLocaleDateString()
                          : 'Unknown'}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center gap-2 justify-end">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              router.push(
                                `/dao/${proposal.daoId}/proposals/${proposal.id}`
                              )
                            }
                          >
                            <Icon name="Eye" className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive"
                            onClick={() =>
                              setDeleteModal({ open: true, proposal })
                            }
                          >
                            <Icon name="Trash2" className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Modal */}
      <Dialog
        open={deleteModal.open}
        onOpenChange={(open) =>
          !deleting && setDeleteModal({ open, proposal: null })
        }
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Proposal</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this proposal? This action cannot
              be undone.
            </DialogDescription>
          </DialogHeader>
          {deleteModal.proposal && (
            <div className="space-y-2 my-4">
              <p className="font-medium">{deleteModal.proposal.title}</p>
              <p className="text-sm text-muted-foreground">
                DAO: {deleteModal.proposal.daoName}
              </p>
              <p className="text-sm text-muted-foreground">
                Status: {deleteModal.proposal.status}
              </p>
              <p className="text-sm text-muted-foreground">
                Votes: {deleteModal.proposal.results.totalVotes}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteModal({ open: false, proposal: null })}
              disabled={deleting}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteProposal}
              disabled={deleting}
            >
              {deleting ? 'Deleting...' : 'Delete Proposal'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
