import { NextRequest, NextResponse } from 'next/server';
import { voteDelegationService } from '@/lib/services/delegation';
import { voteDelegationAdminRepository } from '@/lib/data/repositories/supabase';
import { userAdminRepository } from '@/lib/data/repositories/supabase/user.repository';

/**
 * GET /api/delegations/[id]
 * Get a specific delegation by ID
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: delegationId } = await params;

    const delegation =
      await voteDelegationAdminRepository.findById(delegationId);

    if (!delegation) {
      return NextResponse.json(
        { success: false, error: 'Delegation not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: delegation,
    });
  } catch (error) {
    console.error('Error fetching delegation:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch delegation' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/delegations/[id]
 * Revoke a delegation (delegator only)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: delegationId } = await params;

    // Get auth headers
    const privyId = request.headers.get('x-auth-privy-id');
    const userId = request.headers.get('x-auth-uid');

    if (!privyId && !userId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Resolve user ID
    let internalUserId: string | null = userId;
    if (privyId && !userId) {
      const user = await userAdminRepository.findByPrivyId(privyId);
      if (!user) {
        return NextResponse.json(
          { success: false, error: 'User not found' },
          { status: 401 }
        );
      }
      internalUserId = user.id;
    }

    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'Could not resolve user ID' },
        { status: 401 }
      );
    }

    // Revoke the delegation
    const result = await voteDelegationService.revokeDelegation(
      delegationId,
      internalUserId
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to revoke delegation',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    console.error('Error revoking delegation:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to revoke delegation' },
      { status: 500 }
    );
  }
}
