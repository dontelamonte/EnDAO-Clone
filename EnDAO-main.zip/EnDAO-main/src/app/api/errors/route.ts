/**
 * API endpoint for collecting and processing application errors
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// Error validation schema
const errorSchema = z.object({
  error: z.object({
    name: z.string(),
    message: z.string(),
    stack: z.string().optional(),
  }),
  metadata: z.object({
    errorId: z.string(),
    timestamp: z.string(),
    userId: z.string().optional(),
    sessionId: z.string(),
    userAgent: z.string(),
    url: z.string(),
    referrer: z.string(),
    viewport: z.string(),
    component: z.string().optional(),
    action: z.string().optional(),
    severity: z.enum(['low', 'medium', 'high', 'critical']),
    tags: z.array(z.string()),
    breadcrumbs: z.array(
      z.object({
        timestamp: z.string(),
        category: z.string(),
        message: z.string(),
        level: z.string(),
        data: z.record(z.string(), z.unknown()).optional(),
      })
    ),
    context: z.record(z.string(), z.unknown()),
  }),
});

// TypeScript type derived from Zod schema
type ErrorReport = z.infer<typeof errorSchema>;

// Extended error report with server-side enriched data
interface EnrichedErrorReport extends ErrorReport {
  receivedAt: string;
  serverIP: string;
  fingerprint: string;
}

// Rate limiting
const errorRateLimitMap = new Map<
  string,
  { count: number; resetTime: number }
>();

const ERROR_RATE_LIMIT = {
  requests: 50, // errors per window
  windowMs: 15 * 60 * 1000, // 15 minutes
};

function getErrorRateLimitKey(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  const ip = forwarded ? forwarded.split(',')[0] : 'unknown';
  return `errors:${ip}`;
}

function checkErrorRateLimit(key: string): {
  allowed: boolean;
  remaining: number;
} {
  const now = Date.now();
  const record = errorRateLimitMap.get(key);

  if (!record || now > record.resetTime) {
    errorRateLimitMap.set(key, {
      count: 1,
      resetTime: now + ERROR_RATE_LIMIT.windowMs,
    });
    return { allowed: true, remaining: ERROR_RATE_LIMIT.requests - 1 };
  }

  if (record.count >= ERROR_RATE_LIMIT.requests) {
    return { allowed: false, remaining: 0 };
  }

  record.count++;
  return { allowed: true, remaining: ERROR_RATE_LIMIT.requests - record.count };
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const rateLimitKey = getErrorRateLimitKey(request);
    const { allowed, remaining } = checkErrorRateLimit(rateLimitKey);

    if (!allowed) {
      return NextResponse.json(
        { error: 'Error rate limit exceeded' },
        {
          status: 429,
          headers: {
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': String(
              errorRateLimitMap.get(rateLimitKey)?.resetTime || 0
            ),
          },
        }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedError = errorSchema.parse(body);

    // Process the error
    await processError(validatedError, request);

    return NextResponse.json(
      {
        success: true,
        errorId: validatedError.metadata.errorId,
        processed: true,
      },
      {
        headers: {
          'X-RateLimit-Remaining': String(remaining),
        },
      }
    );
  } catch (error) {
    console.error('Error processing error report:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid error report format', details: error.issues },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

async function processError(errorReport: ErrorReport, request: NextRequest) {
  const { error, metadata } = errorReport;

  const enrichedError: EnrichedErrorReport = {
    ...errorReport,
    receivedAt: new Date().toISOString(),
    serverIP: getClientIP(request),
    fingerprint: generateErrorFingerprint(error, metadata),
  };

  // Log to console in development
  if (process.env.NODE_ENV === 'development') {
    console.error('[ERROR]', error.name + ':', error.message, {
      errorId: metadata.errorId,
      severity: metadata.severity,
      component: metadata.component,
      userId: metadata.userId,
      sessionId: metadata.sessionId,
      url: metadata.url,
      stack: error.stack,
    });
  }

  // Send to error tracking services
  await Promise.allSettled([
    sendToSentry(enrichedError),
    sendToBugsnag(enrichedError),
    sendToCustomErrorService(enrichedError),
    storeErrorInDatabase(enrichedError),
  ]);

  // Send alerts for critical errors
  if (metadata.severity === 'critical') {
    await sendCriticalErrorAlerts(enrichedError);
  }

  // Update error analytics
  await updateErrorAnalytics(enrichedError);
}

async function sendToSentry(errorReport: EnrichedErrorReport) {
  try {
    // Sentry integration
    if (process.env.SENTRY_DSN) {
      // In a real implementation, you would use @sentry/node
      console.log('Would send to Sentry:', errorReport.metadata.errorId);

      // Example Sentry payload structure:
      // const sentryPayload = {
      //   exception: {
      //     values: [{
      //       type: errorReport.error.name,
      //       value: errorReport.error.message,
      //       stacktrace: {
      //         frames: parseStackTrace(errorReport.error.stack)
      //       }
      //     }]
      //   },
      //   user: {
      //     id: errorReport.metadata.userId
      //   },
      //   tags: Object.fromEntries(errorReport.metadata.tags.map(tag => [tag, true])),
      //   contexts: {
      //     browser: {
      //       name: parseBrowserFromUserAgent(errorReport.metadata.userAgent),
      //       version: parseVersionFromUserAgent(errorReport.metadata.userAgent)
      //     },
      //     runtime: {
      //       name: 'browser'
      //     }
      //   },
      //   breadcrumbs: errorReport.metadata.breadcrumbs.map(bc => ({
      //     timestamp: bc.timestamp,
      //     category: bc.category,
      //     message: bc.message,
      //     level: bc.level,
      //     data: bc.data
      //   }))
      // }
    }
  } catch (error) {
    console.error('Failed to send to Sentry:', error);
  }
}

async function sendToBugsnag(errorReport: EnrichedErrorReport) {
  try {
    // Bugsnag integration
    if (process.env.BUGSNAG_API_KEY) {
      console.log('Would send to Bugsnag:', errorReport.metadata.errorId);

      // Example Bugsnag API call:
      // await fetch('https://notify.bugsnag.com/', {
      //   method: 'POST',
      //   headers: {
      //     'Bugsnag-Api-Key': process.env.BUGSNAG_API_KEY,
      //     'Content-Type': 'application/json'
      //   },
      //   body: JSON.stringify({
      //     apiKey: process.env.BUGSNAG_API_KEY,
      //     notifier: {
      //       name: 'endao-error-tracking',
      //       version: '1.0.0',
      //       url: 'https://endao.app'
      //     },
      //     events: [{
      //       exceptions: [{
      //         errorClass: errorReport.error.name,
      //         message: errorReport.error.message,
      //         stacktrace: parseStackTrace(errorReport.error.stack)
      //       }],
      //       user: {
      //         id: errorReport.metadata.userId
      //       },
      //       metaData: {
      //         custom: errorReport.metadata.context,
      //         request: {
      //           url: errorReport.metadata.url,
      //           userAgent: errorReport.metadata.userAgent
      //         }
      //       },
      //       breadcrumbs: errorReport.metadata.breadcrumbs
      //     }]
      //   })
      // })
    }
  } catch (error) {
    console.error('Failed to send to Bugsnag:', error);
  }
}

async function sendToCustomErrorService(errorReport: EnrichedErrorReport) {
  try {
    // Custom error service integration
    if (process.env.CUSTOM_ERROR_SERVICE_URL) {
      await fetch(process.env.CUSTOM_ERROR_SERVICE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${process.env.CUSTOM_ERROR_SERVICE_TOKEN}`,
        },
        body: JSON.stringify(errorReport),
      });
    }
  } catch (error) {
    console.error('Failed to send to custom error service:', error);
  }
}

async function storeErrorInDatabase(errorReport: EnrichedErrorReport) {
  try {
    // Store in Supabase or other database
    // This would integrate with your database service
    console.log('Would store in database:', {
      errorId: errorReport.metadata.errorId,
      severity: errorReport.metadata.severity,
      timestamp: errorReport.metadata.timestamp,
    });

    // Example Supabase integration:
    // const supabase = getSupabaseAdmin()
    // await supabase.from('errors').insert({
    //   ...errorReport,
    //   indexed: true,
    //   resolved: false,
    //   assignee: null,
    //   notes: []
    // })
  } catch (error) {
    console.error('Failed to store error in database:', error);
  }
}

async function sendCriticalErrorAlerts(errorReport: EnrichedErrorReport) {
  try {
    const alertData = {
      title: `🚨 Critical Error in ${process.env.NODE_ENV}`,
      message: errorReport.error.message,
      errorId: errorReport.metadata.errorId,
      component: errorReport.metadata.component,
      url: errorReport.metadata.url,
      userId: errorReport.metadata.userId,
      timestamp: errorReport.metadata.timestamp,
    };

    // Send to Slack
    if (process.env.SLACK_ERROR_WEBHOOK_URL) {
      await fetch(process.env.SLACK_ERROR_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: alertData.title,
          blocks: [
            {
              type: 'header',
              text: {
                type: 'plain_text',
                text: '🚨 Critical Error Alert',
              },
            },
            {
              type: 'section',
              fields: [
                {
                  type: 'mrkdwn',
                  text: `*Error:*\n${alertData.message}`,
                },
                {
                  type: 'mrkdwn',
                  text: `*Component:*\n${alertData.component || 'Unknown'}`,
                },
                {
                  type: 'mrkdwn',
                  text: `*URL:*\n${alertData.url}`,
                },
                {
                  type: 'mrkdwn',
                  text: `*Error ID:*\n\`${alertData.errorId}\``,
                },
              ],
            },
            {
              type: 'actions',
              elements: [
                {
                  type: 'button',
                  text: {
                    type: 'plain_text',
                    text: 'View Details',
                  },
                  url: `${process.env.NEXT_PUBLIC_APP_URL}/admin/errors/${alertData.errorId}`,
                },
              ],
            },
          ],
        }),
      });
    }

    // Send to PagerDuty
    if (process.env.PAGERDUTY_INTEGRATION_KEY) {
      await fetch('https://events.pagerduty.com/v2/enqueue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          routing_key: process.env.PAGERDUTY_INTEGRATION_KEY,
          event_action: 'trigger',
          dedup_key: `error-${errorReport.fingerprint}`,
          payload: {
            summary: `Critical Error: ${alertData.message}`,
            severity: 'critical',
            source: alertData.url,
            component: alertData.component,
            custom_details: {
              error_id: alertData.errorId,
              user_id: alertData.userId,
              timestamp: alertData.timestamp,
            },
          },
        }),
      });
    }
  } catch (error) {
    console.error('Failed to send critical error alerts:', error);
  }
}

async function updateErrorAnalytics(errorReport: EnrichedErrorReport) {
  try {
    // Update error analytics and metrics
    // This could integrate with analytics services
    console.log('Updating error analytics for:', {
      errorId: errorReport.metadata.errorId,
      severity: errorReport.metadata.severity,
      component: errorReport.metadata.component,
    });

    // Example: Send to analytics service
    // await fetch('/api/analytics/errors', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({
    //     event: 'error_occurred',
    //     properties: {
    //       error_type: errorReport.error.name,
    //       severity: errorReport.metadata.severity,
    //       component: errorReport.metadata.component,
    //       user_id: errorReport.metadata.userId,
    //       session_id: errorReport.metadata.sessionId,
    //     }
    //   })
    // })
  } catch (error) {
    console.error('Failed to update error analytics:', error);
  }
}

function generateErrorFingerprint(
  error: ErrorReport['error'],
  metadata: ErrorReport['metadata']
): string {
  // Create a fingerprint to group similar errors
  const fingerprintData = [
    error.name,
    error.message,
    metadata.component,
    metadata.url.split('?')[0], // Remove query params
  ]
    .filter(Boolean)
    .join('|');

  // Simple hash function
  let hash = 0;
  for (let i = 0; i < fingerprintData.length; i++) {
    const char = fingerprintData.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32-bit integer
  }

  return Math.abs(hash).toString(36);
}

function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  const realIP = request.headers.get('x-real-ip');

  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }

  if (realIP) {
    return realIP;
  }

  return 'unknown';
}

// Health check endpoint
export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'errors-api',
  });
}
