/**
 * API Route: Validate Invitation Token
 * GET /api/invitations/validate?token=xxx
 *
 * Validates an invitation token without accepting it
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { invitationService } from '@/lib/services/invitation';
import { daoCrudService } from '@/lib/services/dao';

// Query parameter validation schema
const validateQuerySchema = z.object({
  token: z.string().min(1, 'Token is required'),
});

export async function GET(request: NextRequest) {
  try {
    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const rawParams = {
      token: searchParams.get('token'),
    };

    const validatedParams = validateQuerySchema.parse(rawParams);

    // Get client IP and user agent for security validation
    const forwardedFor = request.headers.get('x-forwarded-for');
    const ipAddress =
      forwardedFor?.split(',')[0] ||
      request.headers.get('x-real-ip') ||
      'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    // Validate the invitation token
    const validationResult = await invitationService.validateInvitationToken(
      validatedParams.token,
      ipAddress,
      userAgent
    );

    if (!validationResult.success || !validationResult.data) {
      return NextResponse.json(
        {
          error: {
            code: 'INVALID_TOKEN',
            message: validationResult.error || 'Invalid invitation token',
          },
        },
        { status: 400 }
      );
    }

    const validation = validationResult.data;

    if (!validation.isValid) {
      return NextResponse.json(
        {
          error: {
            code: 'INVALID_TOKEN',
            message: validation.reason || 'Token validation failed',
          },
        },
        { status: 400 }
      );
    }

    // Get DAO information if invitation is valid
    let daoInfo = null;
    if (validation.invitation) {
      const daoResult = await daoCrudService.getDAO(
        validation.invitation.daoId
      );
      if (daoResult.success && daoResult.data) {
        daoInfo = {
          id: daoResult.data.id,
          name: daoResult.data.name,
          description: daoResult.data.description,
          category: daoResult.data.category,
          memberCount: daoResult.data.memberCount || 0,
        };
      }
    }

    // Return validation result
    return NextResponse.json(
      {
        success: true,
        data: {
          isValid: validation.isValid,
          canAccept: validation.canAccept,
          usesRemaining: validation.usesRemaining,
          expiresAt: validation.expiresAt,
          invitation: validation.invitation
            ? {
                id: validation.invitation.id,
                daoId: validation.invitation.daoId,
                targetRole: validation.invitation.targetRole,
                status: validation.invitation.status,
                expiresAt:
                  validation.invitation.expiresAt instanceof Date
                    ? validation.invitation.expiresAt.getTime()
                    : validation.invitation.expiresAt,
                maxUses: validation.invitation.maxUses,
                currentUses: validation.invitation.currentUses,
                createdAt:
                  validation.invitation.createdAt instanceof Date
                    ? validation.invitation.createdAt.getTime()
                    : validation.invitation.createdAt,
                metadata: {
                  source: validation.invitation.metadata.source,
                },
              }
            : null,
          dao: daoInfo,
          validatedAt: validation.metadata?.validatedAt,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Validate invitation error:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid query parameters',
            details: error.errors,
          },
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An unexpected error occurred',
        },
      },
      { status: 500 }
    );
  }
}
