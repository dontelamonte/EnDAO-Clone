/**
 * API Route: Get DAO Invitations
 * GET /api/invitations/dao/[daoId]
 *
 * Gets all invitations for a specific DAO with filtering and pagination
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { invitationService } from '@/lib/services/invitation';
import { daoMembershipService } from '@/lib/services/dao';
import type { InvitationStatus } from '@/lib/services/invitation/types/invitation.types';
import type { MemberRole } from '@endao/shared-types';

// Query parameter validation schema
const getDAOInvitationsSchema = z.object({
  status: z
    .string()
    .optional()
    .transform((val) => val?.split(',').filter(Boolean)),
  targetRole: z
    .string()
    .optional()
    .transform((val) => val?.split(',').filter(Boolean)),
  limit: z
    .string()
    .optional()
    .transform((val) => (val ? parseInt(val, 10) : undefined)),
  orderBy: z.enum(['createdAt', 'expiresAt', 'status']).optional(),
  orderDirection: z.enum(['asc', 'desc']).optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const { daoId } = await params;

    // Validate authentication
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Check if user has permission to view DAO invitations (must be admin)
    const membershipResult = await daoMembershipService.getMembership(
      daoId,
      uid
    );

    if (
      !membershipResult.success ||
      !membershipResult.data ||
      membershipResult.data.role !== 'admin'
    ) {
      return NextResponse.json(
        {
          error: {
            code: 'INSUFFICIENT_PERMISSIONS',
            message: 'Only DAO administrators can view invitations',
          },
        },
        { status: 403 }
      );
    }

    // Extract and validate query parameters
    const { searchParams } = new URL(request.url);
    const rawParams = {
      status: searchParams.get('status'),
      targetRole: searchParams.get('targetRole'),
      limit: searchParams.get('limit'),
      orderBy: searchParams.get('orderBy'),
      orderDirection: searchParams.get('orderDirection'),
    };

    const validatedParams = getDAOInvitationsSchema.parse(rawParams);

    // Get DAO invitations
    const invitationsResult = await invitationService.getDAOInvitations(daoId, {
      status: validatedParams.status as InvitationStatus[],
      targetRole: validatedParams.targetRole as MemberRole[],
      limit: validatedParams.limit,
      orderBy: validatedParams.orderBy,
      orderDirection: validatedParams.orderDirection,
    });

    if (!invitationsResult.success) {
      return NextResponse.json(
        {
          error: {
            code: 'FETCH_FAILED',
            message: invitationsResult.error || 'Failed to fetch invitations',
          },
        },
        { status: 400 }
      );
    }

    // Format response data
    const invitations = invitationsResult.data || [];
    const formattedInvitations = invitations.map((invitation) => ({
      id: invitation.id,
      daoId: invitation.daoId,
      invitedBy: invitation.invitedBy,
      targetRole: invitation.targetRole,
      status: invitation.status,
      maxUses: invitation.maxUses,
      currentUses: invitation.currentUses,
      expiresAt:
        invitation.expiresAt instanceof Date
          ? invitation.expiresAt.getTime()
          : invitation.expiresAt,
      acceptedAt:
        invitation.acceptedAt instanceof Date
          ? invitation.acceptedAt.getTime()
          : invitation.acceptedAt || null,
      acceptedBy: invitation.acceptedBy || null,
      createdAt:
        invitation.createdAt instanceof Date
          ? invitation.createdAt.getTime()
          : invitation.createdAt,
      metadata: {
        source: invitation.metadata.source,
        createdVia: invitation.metadata.createdVia,
      },
      // Include email/wallet info for admins (hashed email won't be useful)
      hasEmail: !!invitation.invitedEmail,
      hasWallet: !!invitation.invitedWallet,
      invitedWallet: invitation.invitedWallet, // Wallet addresses are not sensitive
    }));

    // Calculate summary statistics
    const summary = {
      total: formattedInvitations.length,
      byStatus: formattedInvitations.reduce(
        (acc, inv) => {
          acc[inv.status] = (acc[inv.status] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      ),
      byRole: formattedInvitations.reduce(
        (acc, inv) => {
          acc[inv.targetRole] = (acc[inv.targetRole] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      ),
      bySource: formattedInvitations.reduce(
        (acc, inv) => {
          acc[inv.metadata.source] = (acc[inv.metadata.source] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      ),
    };

    return NextResponse.json(
      {
        success: true,
        data: {
          invitations: formattedInvitations,
          summary,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get DAO invitations error:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid query parameters',
            details: error.errors,
          },
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An unexpected error occurred',
        },
      },
      { status: 500 }
    );
  }
}
