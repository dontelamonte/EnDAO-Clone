/**
 * API Route: Create Invitation
 * POST /api/invitations/create
 *
 * Creates a single invitation with comprehensive validation and security checks
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import {
  invitationService,
  type CreateInvitationRequest,
} from '@/lib/services/invitation';
import { daoCrudService } from '@/lib/services/dao';
import { rateLimiters } from '@/lib/middleware/rate-limit';

// Request validation schema
const createInvitationSchema = z
  .object({
    daoId: z.string().min(1, 'DAO ID is required'),
    invitedEmail: z.string().email().optional(),
    invitedWallet: z
      .string()
      .regex(/^0x[a-fA-F0-9]{40}$/)
      .optional(),
    targetRole: z.enum(['admin', 'member']),
    expirationHours: z.number().min(1).max(720).optional(), // Max 30 days
    ipRestriction: z.string().optional(),
    customMessage: z.string().max(500).optional(),
    sendNotification: z.boolean().default(true),
  })
  .refine((data) => data.invitedEmail || data.invitedWallet, {
    message: 'Either email or wallet address must be provided',
    path: ['invitedEmail'],
  });

export async function POST(request: NextRequest) {
  try {
    // Apply rate limiting for invitation creation (10/min)
    const rateLimitResult = await rateLimiters.invitationCreate(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = createInvitationSchema.parse(body);

    // Validate authentication
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      );
    }

    const { uid, privyUserId } = authContext;

    // Get client IP and user agent for security
    const forwardedFor = request.headers.get('x-forwarded-for');
    const ipAddress =
      forwardedFor?.split(',')[0] ||
      request.headers.get('x-real-ip') ||
      'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    // Get DAO information for notifications
    const daoResult = await daoCrudService.getDAO(validatedData.daoId);
    if (!daoResult.success || !daoResult.data) {
      return NextResponse.json(
        { error: { code: 'DAO_NOT_FOUND', message: 'DAO not found' } },
        { status: 404 }
      );
    }

    const dao = daoResult.data;

    // Create invitation request
    const invitationRequest: CreateInvitationRequest = {
      daoId: validatedData.daoId,
      invitedBy: uid,
      invitedEmail: validatedData.invitedEmail,
      invitedWallet: validatedData.invitedWallet,
      targetRole: validatedData.targetRole,
      expirationHours: validatedData.expirationHours,
      ipRestriction: validatedData.ipRestriction,
      source: 'manual',
      createdVia: 'api',
      customMessage: validatedData.customMessage,
      sendNotification: validatedData.sendNotification,
    };

    // Create invitation
    const result = await invitationService.createInvitation(
      invitationRequest,
      authContext,
      {
        name: dao.name,
        inviterName: 'DAO Admin', // Simplified since we don't have direct member name access here
      }
    );

    if (!result.success) {
      return NextResponse.json(
        {
          error: {
            code: 'INVITATION_CREATION_FAILED',
            message: result.error || 'Failed to create invitation',
          },
        },
        { status: 400 }
      );
    }

    // Return success response
    return NextResponse.json(
      {
        success: true,
        data: {
          invitation: {
            id: result.data!.invitation.id,
            daoId: result.data!.invitation.daoId,
            targetRole: result.data!.invitation.targetRole,
            status: result.data!.invitation.status,
            expiresAt:
              result.data!.invitation.expiresAt instanceof Date
                ? result.data!.invitation.expiresAt.getTime()
                : result.data!.invitation.expiresAt,
            maxUses: result.data!.invitation.maxUses,
            currentUses: result.data!.invitation.currentUses,
            createdAt:
              result.data!.invitation.createdAt instanceof Date
                ? result.data!.invitation.createdAt.getTime()
                : result.data!.invitation.createdAt,
          },
          invitationLink: result.data!.invitationLink,
          notificationSent: result.data!.notificationSent,
        },
        warnings: result.warnings,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create invitation error:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: error.errors,
          },
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An unexpected error occurred',
        },
      },
      { status: 500 }
    );
  }
}
