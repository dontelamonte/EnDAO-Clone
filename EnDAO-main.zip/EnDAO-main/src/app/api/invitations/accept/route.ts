/**
 * API Route: Accept Invitation
 * POST /api/invitations/accept
 *
 * Accepts an invitation and adds user to DAO with proper validation
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import {
  invitationService,
  type AcceptInvitationRequest,
} from '@/lib/services/invitation';
import { daoMembershipService } from '@/lib/services/dao';
import { rateLimiters } from '@/lib/middleware/rate-limit';

// Request validation schema
const acceptInvitationSchema = z.object({
  token: z.string().min(1, 'Invitation token is required'),
  verificationCode: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    // Apply rate limiting for invitation acceptance (10/min)
    const rateLimitResult = await rateLimiters.invitationAccept(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = acceptInvitationSchema.parse(body);

    // Validate authentication
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      );
    }

    const { uid, privyUserId } = authContext;

    // Get client IP and user agent for security validation
    const forwardedFor = request.headers.get('x-forwarded-for');
    const ipAddress =
      forwardedFor?.split(',')[0] ||
      request.headers.get('x-real-ip') ||
      'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    // Create acceptance request
    const acceptRequest: AcceptInvitationRequest = {
      token: validatedData.token,
      acceptedBy: uid,
      verificationCode: validatedData.verificationCode,
      ipAddress,
      userAgent,
    };

    // Step 1: Accept the invitation
    const acceptResult = await invitationService.acceptInvitation(
      acceptRequest,
      authContext
    );

    if (!acceptResult.success) {
      return NextResponse.json(
        {
          error: {
            code: 'INVITATION_ACCEPTANCE_FAILED',
            message: acceptResult.error || 'Failed to accept invitation',
          },
        },
        { status: 400 }
      );
    }

    const { invitation, daoId, targetRole } = acceptResult.data!;

    // Step 2: Add user to DAO with the specified role
    try {
      const membershipResult = await daoMembershipService.addMember(
        daoId,
        uid,
        targetRole,
        invitation.invitedBy
      );

      if (!membershipResult.success) {
        // Log the membership error but don't fail the invitation acceptance
        console.error('Failed to add member to DAO:', membershipResult.error);

        // Return partial success - invitation was accepted but membership failed
        return NextResponse.json(
          {
            success: true,
            data: {
              invitation: {
                id: invitation.id,
                daoId: invitation.daoId,
                targetRole: invitation.targetRole,
                status: invitation.status,
                acceptedAt:
                  invitation.acceptedAt instanceof Date
                    ? invitation.acceptedAt.getTime()
                    : invitation.acceptedAt,
                acceptedBy: invitation.acceptedBy,
              },
              membershipAdded: false,
              membershipError: membershipResult.error,
            },
            warnings: [
              'Invitation accepted but membership setup incomplete. Please contact DAO administrators.',
            ],
          },
          { status: 202 } // Accepted but incomplete
        );
      }

      // Step 3: Success - both invitation accepted and membership added
      return NextResponse.json(
        {
          success: true,
          data: {
            invitation: {
              id: invitation.id,
              daoId: invitation.daoId,
              targetRole: invitation.targetRole,
              status: invitation.status,
              acceptedAt:
                invitation.acceptedAt instanceof Date
                  ? invitation.acceptedAt.getTime()
                  : invitation.acceptedAt,
              acceptedBy: invitation.acceptedBy,
            },
            membershipAdded: true,
            daoId,
            role: targetRole,
          },
        },
        { status: 200 }
      );
    } catch (membershipError) {
      console.error('Membership addition error:', membershipError);

      // Return partial success
      return NextResponse.json(
        {
          success: true,
          data: {
            invitation: {
              id: invitation.id,
              daoId: invitation.daoId,
              targetRole: invitation.targetRole,
              status: invitation.status,
              acceptedAt:
                invitation.acceptedAt instanceof Date
                  ? invitation.acceptedAt.getTime()
                  : invitation.acceptedAt,
              acceptedBy: invitation.acceptedBy,
            },
            membershipAdded: false,
            membershipError: 'Unexpected error during membership setup',
          },
          warnings: [
            'Invitation accepted but membership setup failed. Please try joining the DAO manually.',
          ],
        },
        { status: 202 }
      );
    }
  } catch (error) {
    console.error('Accept invitation error:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: error.errors,
          },
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An unexpected error occurred',
        },
      },
      { status: 500 }
    );
  }
}
