/**
 * API Route: Cancel Invitation
 * DELETE /api/invitations/cancel
 *
 * Cancels an existing invitation with proper authorization
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { invitationService } from '@/lib/services/invitation';
import { daoMembershipService } from '@/lib/services/dao';

// Request validation schema
const cancelInvitationSchema = z.object({
  invitationId: z.string().min(1, 'Invitation ID is required'),
  reason: z.string().max(500).optional(),
});

export async function DELETE(request: NextRequest) {
  try {
    // Parse and validate request body
    const body = await request.json();
    const validatedData = cancelInvitationSchema.parse(body);

    // Validate authentication
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      );
    }

    const { uid, privyUserId } = authContext;

    // Step 1: Get the invitation to validate permissions
    const invitationResult = await invitationService.getInvitation(
      validatedData.invitationId
    );

    if (!invitationResult.success || !invitationResult.data) {
      return NextResponse.json(
        {
          error: {
            code: 'INVITATION_NOT_FOUND',
            message: 'Invitation not found',
          },
        },
        { status: 404 }
      );
    }

    const invitation = invitationResult.data;

    // Step 2: Check if invitation can be cancelled
    if (invitation.status !== 'pending') {
      return NextResponse.json(
        {
          error: {
            code: 'CANNOT_CANCEL',
            message: `Cannot cancel invitation with status: ${invitation.status}`,
          },
        },
        { status: 400 }
      );
    }

    // Step 3: Validate authorization - user must be inviter or DAO admin
    let canCancel = false;

    // Check if user is the original inviter
    if (invitation.invitedBy === uid) {
      canCancel = true;
    } else {
      // Check if user is a DAO admin
      const membershipResult = await daoMembershipService.getMembership(
        invitation.daoId,
        uid
      );

      if (
        membershipResult.success &&
        membershipResult.data &&
        membershipResult.data.role === 'admin'
      ) {
        canCancel = true;
      }
    }

    if (!canCancel) {
      return NextResponse.json(
        {
          error: {
            code: 'INSUFFICIENT_PERMISSIONS',
            message: 'You do not have permission to cancel this invitation',
          },
        },
        { status: 403 }
      );
    }

    // Step 4: Cancel the invitation
    const cancelResult = await invitationService.cancelInvitation(
      validatedData.invitationId,
      uid,
      validatedData.reason,
      authContext
    );

    if (!cancelResult.success) {
      return NextResponse.json(
        {
          error: {
            code: 'CANCELLATION_FAILED',
            message: cancelResult.error || 'Failed to cancel invitation',
          },
        },
        { status: 400 }
      );
    }

    // Return success response
    return NextResponse.json(
      {
        success: true,
        data: {
          invitation: {
            id: cancelResult.data!.id,
            status: cancelResult.data!.status,
            cancelledBy: uid,
            cancelledAt: Date.now(),
            reason: validatedData.reason,
          },
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Cancel invitation error:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: error.errors,
          },
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An unexpected error occurred',
        },
      },
      { status: 500 }
    );
  }
}
