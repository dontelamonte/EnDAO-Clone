/**
 * API Route: Bulk Create Invitations
 * POST /api/invitations/bulk
 *
 * Creates multiple invitations with batch processing and validation
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import {
  invitationService,
  type BulkInvitationRequest,
} from '@/lib/services/invitation';
import { daoCrudService } from '@/lib/services/dao';
import { rateLimiters } from '@/lib/middleware/rate-limit';

// Individual invitation schema
const bulkInvitationItemSchema = z
  .object({
    name: z.string().max(100).optional(),
    email: z.string().email().optional(),
    wallet: z
      .string()
      .regex(/^0x[a-fA-F0-9]{40}$/)
      .optional(),
    role: z.enum(['admin', 'member']),
    customMessage: z.string().max(500).optional(),
  })
  .refine((data) => data.email || data.wallet, {
    message: 'Either email or wallet address must be provided',
    path: ['email'],
  });

// Bulk request validation schema
const bulkInvitationSchema = z.object({
  daoId: z.string().min(1, 'DAO ID is required'),
  invitations: z
    .array(bulkInvitationItemSchema)
    .min(1, 'At least one invitation is required')
    .max(500, 'Maximum 500 invitations per batch'),
  defaultRole: z.enum(['admin', 'member']).default('member'),
  defaultExpirationHours: z.number().min(1).max(720).optional(), // Max 30 days
  sendNotifications: z.boolean().default(true),
  skipDuplicates: z.boolean().default(true),
  maxBatchSize: z.number().min(1).max(500).default(100),
});

export async function POST(request: NextRequest) {
  try {
    // Apply rate limiting for bulk invitation operations (3/min - very restrictive)
    const rateLimitResult = await rateLimiters.invitationBulk(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = bulkInvitationSchema.parse(body);

    // Validate authentication
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: { code: 'UNAUTHORIZED', message: 'Authentication required' } },
        { status: 401 }
      );
    }

    const { uid, privyUserId } = authContext;

    // Get DAO information
    const daoResult = await daoCrudService.getDAO(validatedData.daoId);
    if (!daoResult.success || !daoResult.data) {
      return NextResponse.json(
        { error: { code: 'DAO_NOT_FOUND', message: 'DAO not found' } },
        { status: 404 }
      );
    }

    const dao = daoResult.data;

    // Create bulk invitation request
    const bulkRequest: BulkInvitationRequest = {
      daoId: validatedData.daoId,
      invitedBy: uid,
      source: 'bulk_upload',
      invitations: validatedData.invitations,
      defaultRole: validatedData.defaultRole,
      defaultExpirationHours: validatedData.defaultExpirationHours,
      sendNotifications: validatedData.sendNotifications,
      skipDuplicates: validatedData.skipDuplicates,
      maxBatchSize: validatedData.maxBatchSize,
    };

    // Process bulk invitations
    const result = await invitationService.createBulkInvitations(
      bulkRequest,
      authContext,
      {
        name: dao.name,
        inviterName: 'DAO Admin', // Simplified since we don't have direct member name access here
      }
    );

    if (!result.success) {
      return NextResponse.json(
        {
          error: {
            code: 'BULK_INVITATION_FAILED',
            message: result.error || 'Failed to create bulk invitations',
          },
        },
        { status: 400 }
      );
    }

    // Format response data
    const responseData = {
      summary: {
        total: validatedData.invitations.length,
        created: result.data!.created.length,
        failed: result.data!.failed.length,
        notificationsSent: result.data!.notificationResult?.sent || 0,
        notificationsFailed: result.data!.notificationResult?.failed || 0,
      },
      created: result.data!.created.map((item) => ({
        invitation: {
          id: item.invitation.id,
          daoId: item.invitation.daoId,
          targetRole: item.invitation.targetRole,
          status: item.invitation.status,
          expiresAt:
            item.invitation.expiresAt instanceof Date
              ? item.invitation.expiresAt.getTime()
              : item.invitation.expiresAt,
          maxUses: item.invitation.maxUses,
          currentUses: item.invitation.currentUses,
          createdAt:
            item.invitation.createdAt instanceof Date
              ? item.invitation.createdAt.getTime()
              : item.invitation.createdAt,
        },
        invitationLink: item.invitationLink,
      })),
      failed: result.data!.failed,
      notificationBatches: result.data!.notificationResult?.batchIds || [],
    };

    return NextResponse.json(
      {
        success: true,
        data: responseData,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Bulk invitation error:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: error.errors,
          },
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An unexpected error occurred',
        },
      },
      { status: 500 }
    );
  }
}
