/**
 * Health check endpoint for observability services
 */

import { NextResponse } from 'next/server';
import { health } from '@/lib/observability';

export async function GET() {
  try {
    const healthCheck = health.check();
    const stats = health.stats();

    const response = {
      status: healthCheck.status,
      timestamp: new Date().toISOString(),
      version: process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0',
      environment: process.env.NODE_ENV,
      services: {
        observability: healthCheck.checks,
      },
      statistics: stats,
      uptime: process.uptime ? `${Math.floor(process.uptime())}s` : 'unknown',
    };

    return NextResponse.json(response, {
      status: healthCheck.healthy ? 200 : 503,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    console.error('Health check failed:', error);

    return NextResponse.json(
      {
        status: 'error',
        timestamp: new Date().toISOString(),
        error: 'Health check failed',
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

// Options for CORS
export async function OPTIONS() {
  return NextResponse.json(
    {},
    {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    }
  );
}
