/**
 * Main health check endpoint
 * Provides system-wide health status and metrics
 */

import { NextRequest, NextResponse } from 'next/server';
import { logger } from '@/lib/services/logger.service';
import { errorTrackingService } from '@/lib/services/error-tracking.service';

interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  uptime: number;
  version: string;
  environment: string;
  services: {
    supabase: 'healthy' | 'degraded' | 'unhealthy';
    database: 'healthy' | 'degraded' | 'unhealthy';
    storage: 'healthy' | 'degraded' | 'unhealthy';
  };
  metrics: {
    memoryUsage: {
      used: number;
      total: number;
      percentage: number;
    };
    responseTime: number;
  };
}

/**
 * GET /api/health
 * Main system health check endpoint
 */
export async function GET(request: NextRequest) {
  const startTime = performance.now();

  try {
    // Get memory usage
    const memoryUsage = process.memoryUsage();
    const totalMemory = memoryUsage.heapTotal;
    const usedMemory = memoryUsage.heapUsed;
    const memoryPercentage = (usedMemory / totalMemory) * 100;

    // Get uptime
    const uptime = process.uptime();

    // Check service health status
    const services = await checkServicesHealth();

    // Determine overall system status
    const overallStatus = determineOverallStatus(services, memoryPercentage);

    const responseTime = performance.now() - startTime;

    const healthStatus: HealthStatus = {
      status: overallStatus,
      timestamp: new Date().toISOString(),
      uptime: Math.round(uptime),
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      services,
      metrics: {
        memoryUsage: {
          used: Math.round(usedMemory / 1024 / 1024), // MB
          total: Math.round(totalMemory / 1024 / 1024), // MB
          percentage: Math.round(memoryPercentage),
        },
        responseTime: Math.round(responseTime),
      },
    };

    // Log health check
    logger.info('Health check completed', {
      status: overallStatus,
      responseTime: Math.round(responseTime),
      memoryUsage: Math.round(memoryPercentage),
      uptime: Math.round(uptime),
    });

    return NextResponse.json(healthStatus, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
        Expires: '0',
      },
    });
  } catch (error) {
    const responseTime = performance.now() - startTime;

    const errorMessage = (error as Error).message;
    logger.error(`Health check failed: ${errorMessage}`, error as Error);

    errorTrackingService.trackError(error as Error, {
      context: 'health_check',
      responseTime: Math.round(responseTime),
    });

    // Return unhealthy status on any errors
    const unhealthyStatus: HealthStatus = {
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      uptime: Math.round(process.uptime()),
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      services: {
        supabase: 'unhealthy',
        database: 'unhealthy',
        storage: 'unhealthy',
      },
      metrics: {
        memoryUsage: {
          used: 0,
          total: 0,
          percentage: 0,
        },
        responseTime: Math.round(responseTime),
      },
    };

    return NextResponse.json(unhealthyStatus, {
      status: 503,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
        Expires: '0',
      },
    });
  }
}

/**
 * Check health of individual services
 */
async function checkServicesHealth(): Promise<HealthStatus['services']> {
  const services: HealthStatus['services'] = {
    supabase: 'healthy',
    database: 'healthy',
    storage: 'healthy',
  };

  try {
    // Check Supabase configuration
    if (
      process.env.NEXT_PUBLIC_SUPABASE_URL &&
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
    ) {
      services.supabase = 'healthy';
      services.database = 'healthy';
      services.storage = 'healthy';
    } else {
      services.supabase = 'degraded';
      services.database = 'degraded';
      services.storage = 'degraded';
    }
  } catch (error) {
    logger.warn('Service health check failed', {
      error: (error as Error).message,
    });
    services.supabase = 'unhealthy';
    services.database = 'unhealthy';
    services.storage = 'unhealthy';
  }

  return services;
}

/**
 * Determine overall system status based on service health and metrics
 */
function determineOverallStatus(
  services: HealthStatus['services'],
  memoryPercentage: number
): HealthStatus['status'] {
  // Check if any service is unhealthy
  const unhealthyServices = Object.values(services).filter(
    (status) => status === 'unhealthy'
  );
  if (unhealthyServices.length > 0) {
    return 'unhealthy';
  }

  // Check if any service is degraded
  const degradedServices = Object.values(services).filter(
    (status) => status === 'degraded'
  );
  if (degradedServices.length > 0) {
    return 'degraded';
  }

  // Check memory threshold (>90% is concerning)
  if (memoryPercentage > 90) {
    return 'degraded';
  }

  return 'healthy';
}
