import { NextRequest, NextResponse } from 'next/server';
import { logger } from '@/lib/services/logger.service';

/**
 * CSP violation reporting endpoint
 * Receives and logs Content Security Policy violations for security monitoring
 */
export async function POST(request: NextRequest) {
  try {
    // Parse CSP violation report
    const report = await request.json();

    // Extract relevant violation data without PII
    const violation = {
      documentUri: report['csp-report']?.['document-uri'] || 'unknown',
      violatedDirective:
        report['csp-report']?.['violated-directive'] || 'unknown',
      blockedUri: report['csp-report']?.['blocked-uri'] || 'unknown',
      lineNumber: report['csp-report']?.['line-number'] || 'unknown',
      columnNumber: report['csp-report']?.['column-number'] || 'unknown',
      sourceFile: report['csp-report']?.['source-file'] || 'unknown',
      timestamp: new Date().toISOString(),
      userAgent:
        request.headers.get('user-agent')?.substring(0, 100) || 'unknown',
    };

    // Log violation for security monitoring
    logger.warn('CSP Violation Detected', {
      type: 'csp_violation',
      violation,
      severity: 'medium',
    });

    // In production, you might want to:
    // 1. Store violations in a security monitoring system
    // 2. Alert on suspicious patterns
    // 3. Aggregate violation statistics

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    // Log parsing errors without exposing details
    const errorMessage =
      error instanceof Error ? error.message : 'Unknown error';
    logger.error(
      'CSP Report Processing Error',
      error instanceof Error ? error : new Error(errorMessage),
      {
        reportType: 'csp_report_error',
        errorMessage: errorMessage,
        timestamp: new Date().toISOString(),
      }
    );

    return new NextResponse(null, { status: 400 });
  }
}

// Only accept POST requests
export async function GET() {
  return new NextResponse('Method not allowed', { status: 405 });
}
