/**
 * User Payouts API
 *
 * GET /api/user/payouts - Get payouts received by the current user
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

// Dynamic imports
async function getPayoutService() {
  const { payoutService } =
    await import('@/lib/services/payout/payout.service');
  return payoutService;
}

async function getUserAdminRepository() {
  const { userAdminRepository } =
    await import('@/lib/data/repositories/supabase');
  return userAdminRepository;
}

/**
 * GET /api/user/payouts
 * Get payouts received by the current user
 */
export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    // Look up internal user ID
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(authContext.privyUserId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Parse query params
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || undefined;
    const sourceType = searchParams.get('sourceType') || undefined;
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const service = await getPayoutService();
    const result = await service.getUserPayouts(user.id, {
      status: status as
        | 'pending'
        | 'approved'
        | 'executing'
        | 'completed'
        | 'failed'
        | 'cancelled'
        | undefined,
      sourceType,
      limit: Math.min(limit, 100),
      offset,
    });

    if (!result.success) {
      return NextResponse.json(
        { error: result.error, code: 'FETCH_FAILED' },
        { status: 500 }
      );
    }

    // Get YTD total for tax purposes
    const ytdResult = await service.getUserYTDTotal(user.id);

    return NextResponse.json({
      success: true,
      data: {
        payouts: result.data?.payouts || [],
        total: result.data?.total || 0,
        ytdTotal: ytdResult.success ? ytdResult.data : 0,
      },
    });
  } catch (error) {
    logger.error('Error fetching user payouts', error as Error);
    return NextResponse.json(
      { error: 'Failed to fetch payouts', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}
