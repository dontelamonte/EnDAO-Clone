/**
 * User KYC Status API
 *
 * GET - Get user's KYC verification status for off-ramp
 */

import { NextRequest, NextResponse } from 'next/server';
import { kycStatusService } from '@/lib/services/treasury/kyc-status.service';
import { userAdminRepository } from '@/lib/data/repositories/supabase';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/user/kyc/status
 * Get the current user's KYC verification status
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Get KYC status
    const result = await kycStatusService.getKYCStatus(userId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get KYC status',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching KYC status',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/user/kyc/status', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch KYC status',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
