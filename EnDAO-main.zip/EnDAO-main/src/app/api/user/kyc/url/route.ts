/**
 * User KYC URL API
 *
 * POST - Get URL for user to complete KYC verification with provider
 */

import { NextRequest, NextResponse } from 'next/server';
import { kycStatusService } from '@/lib/services/treasury/kyc-status.service';
import { userAdminRepository } from '@/lib/data/repositories/supabase';
import { logger } from '@/lib/services/logger.service';
import { z } from 'zod';

const requestSchema = z.object({
  returnUrl: z.string().url('Return URL must be a valid URL'),
});

/**
 * POST /api/user/kyc/url
 * Get a URL to redirect user to complete KYC verification
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;
    const email = supabaseUser.email;

    if (!email) {
      return NextResponse.json(
        {
          success: false,
          error: 'User email is required for KYC verification',
          code: 'EMAIL_REQUIRED',
        },
        { status: 400 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const parseResult = requestSchema.safeParse(body);

    if (!parseResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: parseResult.error.errors[0]?.message || 'Invalid request',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    const { returnUrl } = parseResult.data;

    // Get KYC URL from provider
    const result = await kycStatusService.getKYCUrl({
      userId,
      email,
      returnUrl,
    });

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get KYC URL',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        url: result.data,
        provider: 'moonpay',
      },
    });
  } catch (error) {
    logger.error(
      'Error getting KYC URL',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/user/kyc/url', method: 'POST' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to get KYC URL',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
