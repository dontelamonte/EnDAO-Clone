import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import {
  withValidation,
  createValidationErrorResponse,
} from '@/lib/middleware/api-validation';
import { userProfileUpdateSchema } from '@/lib/validations/api';
import { validateAPICSRF } from '@/lib/security/csrf-api';

// Dynamic import to avoid Turbopack bundling issues with singleton
async function getUserProfileService() {
  const { UserProfileCrudService } = await import('@/lib/services/user');
  return UserProfileCrudService.getInstance();
}

async function getUsernameService() {
  const { usernameService } = await import(
    '@/lib/services/user/username.service'
  );
  return usernameService;
}

async function getUserAdminRepository() {
  const { userAdminRepository } = await import(
    '@/lib/data/repositories/supabase'
  );
  return userAdminRepository;
}

async function getSupabaseAdmin() {
  const { getSupabaseAdmin } = await import('@/lib/supabase/admin');
  return getSupabaseAdmin();
}

/**
 * GET /api/user/profile
 * Get the current user's profile including notification settings
 */
export async function GET(request: NextRequest) {
  try {
    // Extract auth context from middleware headers
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Get user profile using the UID
    const userProfileService = await getUserProfileService();
    const profileResponse = await userProfileService.getUserProfile(uid);

    if (!profileResponse.success || !profileResponse.data) {
      logger.warn('Profile not found for authenticated user', { uid });
      return NextResponse.json(
        { error: 'Profile not found', code: 'PROFILE_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Also fetch notification settings from user_preferences table
    let notificationSettings = null;
    try {
      const supabase = await getSupabaseAdmin();
      const { data: prefsData } = await supabase
        .from('user_preferences')
        .select('notification_settings')
        .eq('user_id', profileResponse.data.id)
        .single();

      // Type assertion needed because Supabase types don't include notification_settings
      const prefs = prefsData as { notification_settings?: unknown } | null;
      if (prefs?.notification_settings) {
        notificationSettings = prefs.notification_settings;
      }
    } catch {
      // Log but don't fail - preferences are optional
      logger.debug('No notification settings found for user', { uid });
    }

    return NextResponse.json({
      success: true,
      data: {
        ...profileResponse.data,
        notificationSettings,
      },
    });
  } catch (error) {
    logger.error('Error fetching user profile', error as Error);
    return NextResponse.json(
      { error: 'Failed to fetch profile', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/user/profile
 * Update the current user's profile with enhanced validation and CSRF protection
 */
export const PATCH = withValidation(userProfileUpdateSchema, {
  sanitize: true,
  checkSqlInjection: true,
  checkXss: true,
  logValidation: true,
  rateLimit: {
    requests: 10, // Allow 10 profile updates per 15 minutes
    windowMs: 15 * 60 * 1000,
  },
})(async function patchUserProfile(request: NextRequest, validatedData) {
  try {
    // Validate CSRF token first
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Extract auth context from middleware headers

    const authContext = await getAuthContext(request);

    if (!authContext) {
      return createValidationErrorResponse(
        'Authentication required',
        'UNAUTHENTICATED',
        401
      );
    }

    // Look up internal user ID from Privy ID
    const privyId = authContext.privyUserId;
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(privyId);

    if (!user) {
      return createValidationErrorResponse(
        'User not found',
        'USER_NOT_FOUND',
        404
      );
    }

    const uid = user.id; // Internal UUID

    // Log profile update attempt for security monitoring
    logger.info('Profile update attempt', {
      uid,
      fields: Object.keys(validatedData),
      ip: request.headers.get('x-forwarded-for') || 'unknown',
      userAgent: request.headers.get('user-agent') || undefined,
    });

    // Handle username change separately (requires special service)
    const { username, notificationSettings, ...profileData } = validatedData;

    // Only change username if it's actually different from current
    const currentUsername = user.username?.toLowerCase();
    const newUsername = username?.toLowerCase();
    const usernameChanged = username && currentUsername !== newUsername;

    // Handle granular notification settings (save to user_preferences table)
    if (notificationSettings) {
      try {
        const supabase = await getSupabaseAdmin();

        // Upsert notification settings into user_preferences table
        // Type assertion needed because Supabase types don't include notification_settings
        const { error: prefsError } = await (
          supabase.from('user_preferences') as ReturnType<typeof supabase.from>
        ).upsert(
          {
            user_id: uid,
            notification_settings: notificationSettings,
            updated_at: new Date().toISOString(),
          } as Record<string, unknown>,
          {
            onConflict: 'user_id',
          }
        );

        if (prefsError) {
          logger.error('Failed to update notification settings', prefsError, {
            uid,
            component: 'profile-route',
          });
          // Don't fail the whole request, just log the error
        } else {
          logger.info('Notification settings updated', {
            uid,
            hasEmailSettings: !!notificationSettings.email,
            hasPushSettings: !!notificationSettings.push,
          });
        }
      } catch (error) {
        logger.error('Error saving notification settings', error as Error, {
          uid,
        });
        // Continue with profile update even if preferences fail
      }
    }

    if (usernameChanged) {
      const usernameService = await getUsernameService();
      const usernameResult = await usernameService.changeUsername(
        uid,
        username
      );

      if (!usernameResult.success) {
        logger.warn('Username change failed', {
          uid,
          error: usernameResult.error,
          attemptedUsername: username,
        });

        return createValidationErrorResponse(
          usernameResult.error || 'Failed to change username',
          'USERNAME_CHANGE_FAILED',
          400
        );
      }

      logger.info('Username changed successfully', {
        uid,
        previousUsername: currentUsername,
        newUsername: username,
      });
    }

    // Update remaining profile fields (if any)
    // Note: emailNotifications and pushNotifications are stored in the users table
    // We need to filter them out if that's all we're updating and handle them separately
    let responseData: unknown = null;

    // Filter out the boolean notification flags from profileData for the user table update
    const {
      emailNotifications: emailNotif,
      pushNotifications: pushNotif,
      ...otherProfileData
    } = profileData as {
      emailNotifications?: boolean;
      pushNotifications?: boolean;
      [key: string]: unknown;
    };

    // Only call updateUserProfile if there are non-notification fields to update
    // OR if we have the boolean notification flags (which go in users table)
    const hasOtherProfileFields = Object.keys(otherProfileData).length > 0;
    const hasNotificationFlags =
      emailNotif !== undefined || pushNotif !== undefined;

    if (hasOtherProfileFields || hasNotificationFlags) {
      // Rebuild the data to send - only include what we actually have
      const dataToUpdate = {
        ...otherProfileData,
        ...(emailNotif !== undefined ? { emailNotifications: emailNotif } : {}),
        ...(pushNotif !== undefined ? { pushNotifications: pushNotif } : {}),
      };

      const userProfileService = await getUserProfileService();
      const updateResponse = await userProfileService.updateUserProfile(
        uid,
        dataToUpdate
      );

      if (!updateResponse.success) {
        logger.warn('Profile update failed', {
          uid,
          error: updateResponse.error,
          attemptedFields: Object.keys(dataToUpdate),
        });

        return createValidationErrorResponse(
          updateResponse.error || 'Failed to update profile',
          'UPDATE_FAILED',
          500
        );
      }

      responseData = updateResponse.data;
    }

    logger.info('Profile updated successfully', {
      uid,
      updatedFields: Object.keys(validatedData),
    });

    return NextResponse.json({
      success: true,
      data: responseData,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    const authContext = await getAuthContext(request);
    const errorMessage =
      error instanceof Error ? error.message : 'Unknown error';
    const errorStack = error instanceof Error ? error.stack : undefined;

    logger.error('Error updating user profile', error as Error, {
      uid: authContext?.uid,
      errorMessage,
      errorStack,
    });

    console.error('[Profile Update Error]', {
      message: errorMessage,
      stack: errorStack,
      uid: authContext?.uid,
    });

    return createValidationErrorResponse(
      `Failed to update profile: ${errorMessage}`,
      'INTERNAL_ERROR',
      500
    );
  }
});
