/**
 * User Tax Info API (W-9)
 *
 * GET /api/user/tax-info - Get user's tax information
 * PATCH /api/user/tax-info - Submit or update W-9 information
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { z } from 'zod';

// Dynamic imports
async function getTaxReportingService() {
  const { taxReportingService } = await import('@/lib/services/tax');
  return taxReportingService;
}

async function getUserAdminRepository() {
  const { userAdminRepository } =
    await import('@/lib/data/repositories/supabase');
  return userAdminRepository;
}

// Validation schema for W-9 submission
const taxInfoUpdateSchema = z.object({
  country: z.string().min(2).max(2),
  taxIdType: z.enum(['ssn', 'ein', 'itin']).optional(),
  taxId: z
    .string()
    .regex(/^[\d-]+$/, 'Invalid tax ID format')
    .optional(),
  legalName: z.string().min(1).max(200),
  businessName: z.string().max(200).optional(),
  taxClassification: z.string().max(100).optional(),
  addressLine1: z.string().max(200).optional(),
  addressLine2: z.string().max(200).optional(),
  city: z.string().max(100).optional(),
  state: z.string().max(50).optional(),
  postalCode: z.string().max(20).optional(),
});

/**
 * GET /api/user/tax-info
 * Retrieve user's tax information (SSN/EIN is masked)
 */
export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    // Look up internal user ID
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(authContext.privyUserId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const service = await getTaxReportingService();
    const result = await service.getTaxInfo(user.id);

    if (!result.success) {
      // If no tax info exists, return null (not an error)
      if (result.error?.includes('not found')) {
        return NextResponse.json({
          success: true,
          data: null,
        });
      }

      return NextResponse.json(
        { error: result.error, code: 'FETCH_FAILED' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('Error fetching tax info', error as Error);
    return NextResponse.json(
      { error: 'Failed to fetch tax information', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/user/tax-info
 * Submit or update W-9 information
 */
export async function PATCH(request: NextRequest) {
  try {
    // Validate CSRF token
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    // Parse and validate body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON body', code: 'INVALID_JSON' },
        { status: 400 }
      );
    }

    const parseResult = taxInfoUpdateSchema.safeParse(body);
    if (!parseResult.success) {
      return NextResponse.json(
        {
          error: 'Validation failed',
          code: 'VALIDATION_ERROR',
          details: parseResult.error.errors,
        },
        { status: 400 }
      );
    }

    const validatedData = parseResult.data;

    // Look up internal user ID
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(authContext.privyUserId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    logger.info('Submitting W-9 tax info', {
      userId: user.id,
      hasSSN: Boolean(validatedData.taxId),
    });

    const service = await getTaxReportingService();
    const result = await service.submitW9(user.id, validatedData);

    if (!result.success) {
      logger.warn('Failed to submit W-9', {
        userId: user.id,
        error: result.error,
      });

      return NextResponse.json(
        { error: result.error, code: 'SUBMIT_FAILED' },
        { status: 500 }
      );
    }

    logger.info('W-9 submitted successfully', { userId: user.id });

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('Error submitting W-9', error as Error);
    return NextResponse.json(
      { error: 'Failed to submit W-9', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}
