/**
 * User Payout Preferences API
 *
 * GET /api/user/payout-preference - Get user's payout preferences
 * PUT /api/user/payout-preference - Update user's payout preferences
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { z } from 'zod';

// Dynamic imports
async function getPayoutPreferencesService() {
  const { payoutPreferencesService } =
    await import('@/lib/services/payout/payout-preferences.service');
  return payoutPreferencesService;
}

async function getUserAdminRepository() {
  const { userAdminRepository } =
    await import('@/lib/data/repositories/supabase');
  return userAdminRepository;
}

// Validation schema
const payoutPreferencesUpdateSchema = z.object({
  preferredMethod: z.enum(['crypto_wallet', 'bank_offramp']).optional(),
  walletAddress: z
    .string()
    .regex(/^0x[a-fA-F0-9]{40}$/)
    .nullable()
    .optional(),
  preferredCryptoCurrency: z.enum(['USDC', 'ETH', 'DAI', 'USDT']).optional(),
  billingDisplayName: z.string().max(100).nullable().optional(),
  billingCompanyName: z.string().max(100).nullable().optional(),
  billingAddressLine1: z.string().max(200).nullable().optional(),
  billingAddressLine2: z.string().max(200).nullable().optional(),
  billingCity: z.string().max(100).nullable().optional(),
  billingState: z.string().max(100).nullable().optional(),
  billingPostalCode: z.string().max(20).nullable().optional(),
  billingCountry: z.string().max(100).nullable().optional(),
  defaultInvoicePaymentTerms: z
    .enum(['due_on_receipt', 'net_15', 'net_30', 'net_45', 'net_60'])
    .optional(),
  defaultInvoiceNotes: z.string().max(1000).nullable().optional(),
  defaultInvoiceLateFeePercent: z.number().min(0).max(25).optional(),
  notifyOnPaymentReceived: z.boolean().optional(),
  notifyOnInvoicePaid: z.boolean().optional(),
  notifyWeeklySummary: z.boolean().optional(),
});

/**
 * GET /api/user/payout-preference
 * Get current user's payout preferences
 */
export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    // Look up internal user ID
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(authContext.privyUserId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const service = await getPayoutPreferencesService();
    const result = await service.getOrCreatePreferences(user.id);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error, code: 'FETCH_FAILED' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('Error fetching payout preferences', error as Error);
    return NextResponse.json(
      { error: 'Failed to fetch payout preferences', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/user/payout-preference
 * Update current user's payout preferences
 */
export async function PUT(request: NextRequest) {
  try {
    // Validate CSRF token
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    // Parse and validate body
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON body', code: 'INVALID_JSON' },
        { status: 400 }
      );
    }

    const parseResult = payoutPreferencesUpdateSchema.safeParse(body);
    if (!parseResult.success) {
      return NextResponse.json(
        {
          error: 'Validation failed',
          code: 'VALIDATION_ERROR',
          details: parseResult.error.errors,
        },
        { status: 400 }
      );
    }

    const validatedData = parseResult.data;

    // Look up internal user ID
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(authContext.privyUserId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    logger.info('Updating payout preferences', {
      userId: user.id,
      fields: Object.keys(validatedData),
    });

    const service = await getPayoutPreferencesService();

    // Convert null values to undefined for the service
    const input: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(validatedData)) {
      if (value !== null) {
        input[key] = value;
      } else {
        input[key] = undefined;
      }
    }

    const result = await service.updatePreferences(user.id, input);

    if (!result.success) {
      logger.warn('Failed to update payout preferences', {
        userId: user.id,
        error: result.error,
      });

      return NextResponse.json(
        { error: result.error, code: 'UPDATE_FAILED' },
        { status: 500 }
      );
    }

    logger.info('Payout preferences updated successfully', {
      userId: user.id,
    });

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('Error updating payout preferences', error as Error);
    return NextResponse.json(
      { error: 'Failed to update payout preferences', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}
