/**
 * Bounty API endpoints
 * Handles bounty lifecycle operations: claim, submit, review, payout
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { bountyService } from '@/lib/services/proposal/bounty';
import {
  proposalAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import { z } from 'zod';

// Request validation schemas

// Application-based workflow (primary)
const ApplySchema = z.object({
  action: z.literal('apply'),
  message: z
    .string()
    .min(10, 'Please provide at least 10 characters explaining your fit'),
  portfolioUrl: z.string().url().optional().or(z.literal('')),
});

const SelectSchema = z.object({
  action: z.literal('select'),
  applicationId: z.string().min(1),
});

const WithdrawSchema = z.object({
  action: z.literal('withdraw'),
});

// Legacy claim (deprecated, but kept for backwards compatibility)
const ClaimSchema = z.object({
  action: z.literal('claim'),
});

const SubmitSchema = z.object({
  action: z.literal('submit'),
  submissionUrl: z.string().url(),
  submissionNotes: z.string().optional(),
});

const ReviewSchema = z.object({
  action: z.literal('review'),
  approved: z.boolean(),
  reviewNotes: z.string().optional(),
});

const PayoutSchema = z.object({
  action: z.literal('payout'),
  txHash: z.string().min(1),
});

const CancelSchema = z.object({
  action: z.literal('cancel'),
  reason: z.string().optional(),
});

const ActionSchema = z.discriminatedUnion('action', [
  ApplySchema,
  SelectSchema,
  WithdrawSchema,
  ClaimSchema,
  SubmitSchema,
  ReviewSchema,
  PayoutSchema,
  CancelSchema,
]);

/**
 * GET /api/bounty/[proposalId]
 * Get bounty status for a proposal
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { error: 'Proposal ID is required' },
        { status: 400 }
      );
    }

    const result = await bountyService.getBountyStatus(proposalId);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Failed to get bounty status' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      status: result.data?.status,
      proposal: result.data?.proposal,
    });
  } catch (error) {
    console.error('Error fetching bounty status:', error);
    return NextResponse.json(
      { error: 'Failed to fetch bounty status' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/bounty/[proposalId]
 * Perform bounty action (claim, submit, review, payout, cancel)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    // Get auth context
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;
    const userId = authContext.privyUserId;

    if (!proposalId) {
      return NextResponse.json(
        { error: 'Proposal ID is required' },
        { status: 400 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validationResult = ActionSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json(
        { error: 'Invalid request', details: validationResult.error.errors },
        { status: 400 }
      );
    }

    const action = validationResult.data;

    let result;

    switch (action.action) {
      // Application-based workflow (primary)
      case 'apply':
        result = await bountyService.applyForBounty(proposalId, {
          userId,
          message: action.message,
          portfolioUrl: action.portfolioUrl || undefined,
        });
        break;

      case 'select':
        // Verify user is admin
        const isSelectAdmin = await verifyIsAdmin(proposalId, userId);
        if (!isSelectAdmin) {
          return NextResponse.json(
            { error: 'Admin permission required' },
            { status: 403 }
          );
        }

        result = await bountyService.selectApplicant(proposalId, {
          applicationId: action.applicationId,
          adminId: userId,
        });
        break;

      case 'withdraw':
        result = await bountyService.withdrawApplication(proposalId, userId);
        break;

      // Legacy claim (deprecated)
      case 'claim':
        result = await bountyService.claimBounty(proposalId, {
          userId,
        });
        break;

      case 'submit':
        result = await bountyService.submitWork(proposalId, userId, {
          submissionUrl: action.submissionUrl,
          submissionNotes: action.submissionNotes,
        });
        break;

      case 'review':
        // Verify user is admin
        const isAdmin = await verifyIsAdmin(proposalId, userId);
        if (!isAdmin) {
          return NextResponse.json(
            { error: 'Admin permission required' },
            { status: 403 }
          );
        }

        result = await bountyService.reviewSubmission(proposalId, {
          adminId: userId,
          approved: action.approved,
          reviewNotes: action.reviewNotes,
        });
        break;

      case 'payout':
        // Verify user is admin
        const isPayoutAdmin = await verifyIsAdmin(proposalId, userId);
        if (!isPayoutAdmin) {
          return NextResponse.json(
            { error: 'Admin permission required' },
            { status: 403 }
          );
        }

        result = await bountyService.recordPayout(proposalId, {
          txHash: action.txHash,
          paidBy: userId,
        });
        break;

      case 'cancel':
        // Verify user is admin
        const isCancelAdmin = await verifyIsAdmin(proposalId, userId);
        if (!isCancelAdmin) {
          return NextResponse.json(
            { error: 'Admin permission required' },
            { status: 403 }
          );
        }

        result = await bountyService.cancelBounty(
          proposalId,
          userId,
          action.reason
        );
        break;

      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Operation failed' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      proposal: result.data,
    });
  } catch (error) {
    console.error('Error processing bounty action:', error);
    return NextResponse.json(
      { error: 'Failed to process bounty action' },
      { status: 500 }
    );
  }
}

/**
 * Helper to verify if user is admin of the DAO
 */
async function verifyIsAdmin(
  proposalId: string,
  userId: string
): Promise<boolean> {
  try {
    // Get proposal to find DAO
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) return false;

    const daoId = proposal.daoId;
    if (!daoId) return false;

    // Check if user is admin of the DAO via dao_members table
    const adminUserIds = await daoMemberAdminRepository.getAdminUserIds(daoId);
    return adminUserIds.includes(userId);
  } catch (error) {
    console.error('Error verifying admin status:', error);
    return false;
  }
}
