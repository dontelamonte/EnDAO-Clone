/**
 * Proposal Drafts API Route
 *
 * POST - Create or update a draft
 * GET - Get user's drafts (optional: filter by daoId)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { z } from 'zod';

// Dynamic imports to avoid Turbopack bundling issues
async function getDraftService() {
  const { draftManagementService } = await import(
    '@/lib/services/proposals/draft-management.service'
  );
  return draftManagementService;
}

// Validation schema for draft creation/update
const draftSaveSchema = z.object({
  draftId: z.string().min(1, 'Draft ID is required'),
  daoId: z.string().uuid('Invalid DAO ID'),
  formData: z.record(z.unknown()),
  options: z.array(z.string()).optional(),
  metadata: z
    .object({
      deviceId: z.string().optional(),
      daoName: z.string().optional(),
      autoSaved: z.boolean().optional(),
    })
    .optional(),
});

/**
 * POST /api/drafts
 * Create or update a proposal draft
 */
export async function POST(request: NextRequest) {
  try {
    // Validate CSRF token
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Get auth context
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'UNAUTHENTICATED',
        },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Parse and validate request body
    const body = await request.json();
    const validation = draftSaveSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { draftId, daoId, formData, options, metadata } = validation.data;

    // Save draft using service
    const draftService = await getDraftService();
    const result = await draftService.saveDraft(
      draftId,
      daoId,
      uid,
      formData,
      options,
      metadata
    );

    if (!result.success) {
      logger.error('Failed to save draft', new Error(result.error), {
        uid,
        daoId,
        draftId,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to save draft',
          code: 'SAVE_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error saving draft',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/drafts', method: 'POST' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to save draft', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/drafts
 * Get user's drafts (optionally filtered by daoId)
 */
export async function GET(request: NextRequest) {
  try {
    // Get auth context
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'UNAUTHENTICATED',
        },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Get optional daoId from query params
    const { searchParams } = new URL(request.url);
    const daoId = searchParams.get('daoId') || undefined;
    const limit = parseInt(searchParams.get('limit') || '50', 10);

    // Get drafts using service
    const draftService = await getDraftService();
    const result = await draftService.getUserDrafts(uid, daoId, limit);

    if (!result.success) {
      logger.error('Failed to get drafts', new Error(result.error), {
        uid,
        daoId,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get drafts',
          code: 'FETCH_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching drafts',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/drafts', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch drafts',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
