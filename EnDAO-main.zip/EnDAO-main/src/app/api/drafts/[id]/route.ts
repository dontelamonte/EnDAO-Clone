/**
 * Individual Proposal Draft API Route
 *
 * GET - Fetch a specific draft by ID
 * PATCH - Update a draft
 * DELETE - Delete a draft
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { z } from 'zod';

// Dynamic imports to avoid Turbopack bundling issues
async function getDraftService() {
  const { draftManagementService } = await import(
    '@/lib/services/proposals/draft-management.service'
  );
  return draftManagementService;
}

async function getDraftRepository() {
  const { proposalDraftAdminRepository } = await import(
    '@/lib/data/repositories/supabase'
  );
  return proposalDraftAdminRepository;
}

// Validation schema for draft update
const draftUpdateSchema = z.object({
  daoId: z.string().uuid('Invalid DAO ID'),
  formData: z.record(z.unknown()),
  options: z.array(z.string()).optional(),
  metadata: z
    .object({
      deviceId: z.string().optional(),
      daoName: z.string().optional(),
      autoSaved: z.boolean().optional(),
    })
    .optional(),
});

/**
 * GET /api/drafts/[id]
 * Fetch a specific draft by ID
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: draftId } = await params;

    if (!draftId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Draft ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get auth context
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'UNAUTHENTICATED',
        },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Get draft using service
    const draftService = await getDraftService();
    const result = await draftService.getDraft(draftId);

    if (!result.success) {
      logger.error('Failed to get draft', new Error(result.error), {
        uid,
        draftId,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get draft',
          code: 'FETCH_FAILED',
        },
        { status: 500 }
      );
    }

    // Draft not found
    if (!result.data) {
      return NextResponse.json(
        { success: false, error: 'Draft not found', code: 'DRAFT_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Verify user owns the draft
    if (result.data.userId !== uid) {
      return NextResponse.json(
        { success: false, error: 'Access denied', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching draft',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/drafts/[id]', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch draft',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/drafts/[id]
 * Update a draft
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: draftId } = await params;

    if (!draftId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Draft ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Validate CSRF token
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Get auth context
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'UNAUTHENTICATED',
        },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Verify draft exists and user owns it
    const draftRepository = await getDraftRepository();
    const existingDraft = await draftRepository.findById(draftId);

    if (!existingDraft) {
      return NextResponse.json(
        { success: false, error: 'Draft not found', code: 'DRAFT_NOT_FOUND' },
        { status: 404 }
      );
    }

    if (existingDraft.userId !== uid) {
      return NextResponse.json(
        { success: false, error: 'Access denied', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = draftUpdateSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { daoId, formData, options, metadata } = validation.data;

    // Update draft using service
    const draftService = await getDraftService();
    const result = await draftService.saveDraft(
      draftId,
      daoId,
      uid,
      formData,
      options,
      metadata
    );

    if (!result.success) {
      logger.error('Failed to update draft', new Error(result.error), {
        uid,
        draftId,
        daoId,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to update draft',
          code: 'UPDATE_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error updating draft',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/drafts/[id]', method: 'PATCH' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to update draft',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/drafts/[id]
 * Delete a draft
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: draftId } = await params;

    if (!draftId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Draft ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Validate CSRF token
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Get auth context
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'UNAUTHENTICATED',
        },
        { status: 401 }
      );
    }

    const { uid } = authContext;

    // Verify draft exists and user owns it
    const draftRepository = await getDraftRepository();
    const existingDraft = await draftRepository.findById(draftId);

    if (!existingDraft) {
      // Draft doesn't exist - this is idempotent, return success
      return NextResponse.json({
        success: true,
        data: null,
      });
    }

    if (existingDraft.userId !== uid) {
      return NextResponse.json(
        { success: false, error: 'Access denied', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    // Delete draft using service
    const draftService = await getDraftService();
    const result = await draftService.deleteDraft(draftId);

    if (!result.success) {
      logger.error('Failed to delete draft', new Error(result.error), {
        uid,
        draftId,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to delete draft',
          code: 'DELETE_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: null,
    });
  } catch (error) {
    logger.error(
      'Error deleting draft',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/drafts/[id]', method: 'DELETE' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to delete draft',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
