/**
 * Discussion API Route Validation Tests
 * Tests the actual validation schemas for /api/discussions/* endpoints
 *
 * This file tests real code from:
 * - @/lib/validations/api (createSanitizedString, paginationSchema)
 * - @/lib/validations/common (commonValidations)
 * - @/lib/services/discussion/discussion.service.ts (Discussion, DiscussionListOptions)
 */

import {
  createSanitizedString,
  paginationSchema,
  sortSchema,
  commentCreateSchema,
  documentId,
} from '@/lib/validations/api';
import {
  DiscussionService,
  Discussion,
  DiscussionListOptions,
} from '@/lib/services/discussion/discussion.service';

describe('Discussion Validation Schemas', () => {
  describe('Title Validation', () => {
    const titleValidator = createSanitizedString(3, 200);

    it('should accept valid title', () => {
      expect(() =>
        titleValidator.parse('Valid Discussion Title')
      ).not.toThrow();
    });

    it('should reject title too short', () => {
      expect(() => titleValidator.parse('ab')).toThrow();
    });

    it('should accept title at minimum length', () => {
      expect(() => titleValidator.parse('abc')).not.toThrow();
    });

    it('should reject title too long', () => {
      expect(() => titleValidator.parse('a'.repeat(201))).toThrow();
    });

    it('should accept title at maximum length', () => {
      expect(() => titleValidator.parse('a'.repeat(200))).not.toThrow();
    });

    it('should reject XSS in title', () => {
      expect(() => titleValidator.parse('<script>alert(1)</script>')).toThrow();
    });

    it('should reject SQL injection in title', () => {
      expect(() =>
        titleValidator.parse("'; DROP TABLE discussions; --")
      ).toThrow();
    });
  });

  describe('Description/Content Validation', () => {
    const contentValidator = createSanitizedString(10, 10000);

    it('should accept valid content', () => {
      expect(() =>
        contentValidator.parse(
          'This is a valid discussion description with enough characters.'
        )
      ).not.toThrow();
    });

    it('should reject content too short', () => {
      expect(() => contentValidator.parse('Too short')).toThrow();
    });

    it('should accept content at minimum length', () => {
      expect(() => contentValidator.parse('1234567890')).not.toThrow();
    });

    it('should reject content too long', () => {
      expect(() => contentValidator.parse('a'.repeat(10001))).toThrow();
    });

    it('should reject XSS in content', () => {
      expect(() =>
        contentValidator.parse('<script>alert("xss")</script> some other text')
      ).toThrow();
    });

    it('should reject javascript: protocol', () => {
      expect(() => contentValidator.parse('javascript:void(0)')).toThrow();
    });

    it('should accept normal business text', () => {
      expect(() =>
        contentValidator.parse(
          'We should select the best approach and update our strategy for the project.'
        )
      ).not.toThrow();
    });
  });

  describe('paginationSchema', () => {
    it('should apply default values', () => {
      const result = paginationSchema.parse({});
      expect(result.page).toBe(1);
      expect(result.limit).toBe(20);
    });

    it('should accept valid pagination', () => {
      const result = paginationSchema.parse({ page: 2, limit: 50 });
      expect(result.page).toBe(2);
      expect(result.limit).toBe(50);
    });

    it('should reject invalid page', () => {
      expect(() => paginationSchema.parse({ page: 0 })).toThrow();
      expect(() => paginationSchema.parse({ page: -1 })).toThrow();
    });

    it('should reject limit over 100', () => {
      expect(() => paginationSchema.parse({ limit: 101 })).toThrow();
    });

    it('should reject limit under 1', () => {
      expect(() => paginationSchema.parse({ limit: 0 })).toThrow();
    });

    it('should coerce string values to numbers', () => {
      const result = paginationSchema.parse({ page: '3', limit: '25' });
      expect(result.page).toBe(3);
      expect(result.limit).toBe(25);
    });
  });

  describe('sortSchema', () => {
    it('should default sortOrder to desc', () => {
      const result = sortSchema.parse({});
      expect(result.sortOrder).toBe('desc');
    });

    it('should accept asc sortOrder', () => {
      const result = sortSchema.parse({ sortOrder: 'asc' });
      expect(result.sortOrder).toBe('asc');
    });

    it('should accept valid sortBy field', () => {
      const result = sortSchema.parse({ sortBy: 'createdAt' });
      expect(result.sortBy).toBe('createdAt');
    });

    it('should reject invalid sortBy format', () => {
      expect(() => sortSchema.parse({ sortBy: '123invalid' })).toThrow();
    });
  });

  describe('documentId', () => {
    it('should accept valid document ID', () => {
      expect(() => documentId.parse('disc-123')).not.toThrow();
      expect(() => documentId.parse('discussion_abc-123')).not.toThrow();
    });

    it('should reject empty document ID', () => {
      expect(() => documentId.parse('')).toThrow();
    });

    it('should reject ID starting with hyphen', () => {
      expect(() => documentId.parse('-disc')).toThrow();
    });
  });
});

describe('DiscussionService', () => {
  describe('Singleton Pattern', () => {
    it('should return the same instance', () => {
      const instance1 = DiscussionService.getInstance();
      const instance2 = DiscussionService.getInstance();
      expect(instance1).toBe(instance2);
    });
  });

  describe('Service Methods', () => {
    const service = DiscussionService.getInstance();

    it('should have getDiscussionById method', () => {
      expect(typeof service.getDiscussionById).toBe('function');
    });

    it('should have getDiscussionsByDao method', () => {
      expect(typeof service.getDiscussionsByDao).toBe('function');
    });

    it('should have createDiscussion method', () => {
      expect(typeof service.createDiscussion).toBe('function');
    });

    it('should have updateDiscussion method', () => {
      expect(typeof service.updateDiscussion).toBe('function');
    });

    it('should have deleteDiscussion method', () => {
      expect(typeof service.deleteDiscussion).toBe('function');
    });

    it('should have pinDiscussion method', () => {
      expect(typeof service.pinDiscussion).toBe('function');
    });

    it('should have archiveDiscussion method', () => {
      expect(typeof service.archiveDiscussion).toBe('function');
    });
  });
});

describe('Discussion Data Types', () => {
  describe('Discussion Interface', () => {
    it('should define required fields', () => {
      const discussion: Discussion = {
        id: 'disc-123',
        daoId: 'dao-123',
        authorId: 'user-123',
        title: 'Test Discussion',
        description: 'This is a test discussion.',
        status: 'active',
        isPinned: false,
        commentCount: 0,
        likeCount: 0,
        viewCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      expect(discussion.id).toBe('disc-123');
      expect(discussion.daoId).toBe('dao-123');
      expect(discussion.status).toBe('active');
    });

    it('should allow status values', () => {
      const statuses: Array<Discussion['status']> = [
        'active',
        'archived',
        'converted',
      ];

      statuses.forEach((status) => {
        expect(['active', 'archived', 'converted']).toContain(status);
      });
    });

    it('should track conversion to proposal', () => {
      const converted: Discussion = {
        id: 'disc-123',
        daoId: 'dao-123',
        authorId: 'user-123',
        title: 'Converted Discussion',
        description: 'This was converted.',
        status: 'converted',
        isPinned: false,
        commentCount: 10,
        likeCount: 5,
        viewCount: 100,
        proposalId: 'prop-456',
        convertedAt: new Date(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      expect(converted.status).toBe('converted');
      expect(converted.proposalId).toBe('prop-456');
      expect(converted.convertedAt).toBeDefined();
    });
  });

  describe('DiscussionListOptions Interface', () => {
    it('should support filtering options', () => {
      const options: DiscussionListOptions = {
        status: 'active',
        limit: 20,
        offset: 0,
        sortBy: 'newest',
        includeArchived: false,
      };

      expect(options.status).toBe('active');
      expect(options.sortBy).toBe('newest');
    });

    it('should support all sortBy values', () => {
      const sortValues: Array<DiscussionListOptions['sortBy']> = [
        'newest',
        'oldest',
        'popular',
        'active',
      ];

      sortValues.forEach((sort) => {
        expect(['newest', 'oldest', 'popular', 'active']).toContain(sort);
      });
    });
  });
});

describe('Discussion Comments', () => {
  describe('commentCreateSchema', () => {
    it('should accept valid comment', () => {
      const validComment = { content: 'This is a valid comment.' };
      expect(() => commentCreateSchema.parse(validComment)).not.toThrow();
    });

    it('should reject empty content', () => {
      expect(() => commentCreateSchema.parse({ content: '' })).toThrow();
    });

    it('should reject whitespace-only content', () => {
      expect(() =>
        commentCreateSchema.parse({ content: '   \n\t  ' })
      ).toThrow();
    });

    it('should accept parentId for replies', () => {
      const reply = {
        content: 'This is a reply.',
        parentId: '550e8400-e29b-41d4-a716-446655440000',
      };
      expect(() => commentCreateSchema.parse(reply)).not.toThrow();
    });

    it('should reject invalid parentId format', () => {
      const invalid = {
        content: 'Valid content here.',
        parentId: 'not-a-uuid',
      };
      expect(() => commentCreateSchema.parse(invalid)).toThrow();
    });

    it('should reject XSS in content', () => {
      expect(() =>
        commentCreateSchema.parse({ content: '<script>alert(1)</script>' })
      ).toThrow();
    });

    it('should reject content over 10000 characters', () => {
      expect(() =>
        commentCreateSchema.parse({ content: 'a'.repeat(10001) })
      ).toThrow();
    });
  });
});

describe('Discussion Status Logic', () => {
  it('should not allow updates to converted discussions', () => {
    const discussion = { status: 'converted' };
    const canUpdate = discussion.status !== 'converted';
    expect(canUpdate).toBe(false);
  });

  it('should allow updates to active discussions', () => {
    const discussion = { status: 'active' };
    const canUpdate = discussion.status !== 'converted';
    expect(canUpdate).toBe(true);
  });

  it('should allow updates to archived discussions', () => {
    const discussion = { status: 'archived' };
    const canUpdate = discussion.status !== 'converted';
    expect(canUpdate).toBe(true);
  });
});

describe('Discussion Permissions', () => {
  it('should allow creator to update', () => {
    const discussion = { createdBy: 'user-123' };
    const userId = 'user-123';
    const canUpdate = discussion.createdBy === userId;
    expect(canUpdate).toBe(true);
  });

  it('should allow admin to update any discussion', () => {
    const isAdmin = true;
    const canUpdate = isAdmin;
    expect(canUpdate).toBe(true);
  });

  it('should reject non-creator non-admin from updating', () => {
    const discussion = { createdBy: 'user-123' };
    const userId = 'other-user';
    const isAdmin = false;
    const canUpdate = discussion.createdBy === userId || isAdmin;
    expect(canUpdate).toBe(false);
  });

  it('should allow admin/owner to pin discussions', () => {
    const membership = { role: 'admin' };
    const canPin = membership.role === 'admin';
    expect(canPin).toBe(true);
  });

  it('should not allow regular members to pin', () => {
    const membership = { role: 'member' };
    const canPin = membership.role === 'admin';
    expect(canPin).toBe(false);
  });
});

describe('Discussion Sorting', () => {
  it('should sort by newest (createdAt desc)', () => {
    const discussions = [
      { id: '1', createdAt: '2024-01-01' },
      { id: '2', createdAt: '2024-01-03' },
      { id: '3', createdAt: '2024-01-02' },
    ];

    const sorted = [...discussions].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    expect(sorted[0].id).toBe('2');
    expect(sorted[1].id).toBe('3');
    expect(sorted[2].id).toBe('1');
  });

  it('should prioritize pinned discussions', () => {
    const discussions = [
      { id: '1', isPinned: false },
      { id: '2', isPinned: true },
      { id: '3', isPinned: false },
    ];

    const sorted = [...discussions].sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return 0;
    });

    expect(sorted[0].isPinned).toBe(true);
  });

  it('should sort by popular (likeCount desc)', () => {
    const discussions = [
      { id: '1', likeCount: 10 },
      { id: '2', likeCount: 50 },
      { id: '3', likeCount: 25 },
    ];

    const sorted = [...discussions].sort((a, b) => b.likeCount - a.likeCount);

    expect(sorted[0].id).toBe('2');
    expect(sorted[1].id).toBe('3');
    expect(sorted[2].id).toBe('1');
  });
});

describe('Discussion Filtering', () => {
  it('should filter by status', () => {
    const discussions = [
      { id: '1', status: 'active' },
      { id: '2', status: 'archived' },
      { id: '3', status: 'converted' },
      { id: '4', status: 'active' },
    ];

    const activeOnly = discussions.filter((d) => d.status === 'active');
    expect(activeOnly).toHaveLength(2);
  });

  it('should filter out archived by default', () => {
    const discussions = [
      { id: '1', status: 'active' },
      { id: '2', status: 'archived' },
      { id: '3', status: 'converted' },
    ];

    const nonArchived = discussions.filter((d) => d.status !== 'archived');
    expect(nonArchived).toHaveLength(2);
  });
});

describe('Discussion Conversion to Proposal', () => {
  it('should not allow converting already converted discussion', () => {
    const discussion = { status: 'converted' };
    const canConvert = discussion.status !== 'converted';
    expect(canConvert).toBe(false);
  });

  it('should allow converting active discussion', () => {
    const discussion = { status: 'active' };
    const canConvert = discussion.status !== 'converted';
    expect(canConvert).toBe(true);
  });
});
