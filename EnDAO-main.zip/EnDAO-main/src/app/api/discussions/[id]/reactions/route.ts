/**
 * Discussion Reactions API Route
 *
 * GET: Get all reactions for a discussion (grouped by emoji with counts)
 * POST: Toggle reaction (add/remove emoji reaction)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { userAdminRepository } from '@/lib/data/repositories';

// Limited emoji set for reactions
const ALLOWED_EMOJIS = ['👍', '❤️', '🎉', '🤔', '👀', '🚀'] as const;
type AllowedEmoji = (typeof ALLOWED_EMOJIS)[number];

interface ReactionSummary {
  emoji: AllowedEmoji;
  count: number;
  users: string[]; // User IDs who reacted
}

interface GetReactionsResponse {
  success: boolean;
  data?: {
    reactions: ReactionSummary[];
    userReaction?: AllowedEmoji;
  };
  error?: string;
}

interface ToggleReactionResponse {
  success: boolean;
  data?: {
    reacted: boolean;
    emoji: AllowedEmoji;
    count: number;
  };
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<GetReactionsResponse>> {
  try {
    const { id: discussionId } = await params;
    const supabase = getSupabaseAdmin();

    // Get all reactions for this discussion
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Table not in generated types yet
    const { data: reactions, error } = (await (supabase as any)
      .from('discussion_reactions')
      .select('emoji, user_id')
      .eq('discussion_id', discussionId)) as {
      data: Array<{ emoji: string; user_id: string }> | null;
      error: Error | null;
    };

    if (error) {
      console.error('Error fetching reactions:', error);
      return NextResponse.json(
        { success: false, error: 'Failed to fetch reactions' },
        { status: 500 }
      );
    }

    // Group by emoji and count
    const reactionMap = new Map<AllowedEmoji, string[]>();
    for (const reaction of reactions || []) {
      const emoji = reaction.emoji as AllowedEmoji;
      if (!reactionMap.has(emoji)) {
        reactionMap.set(emoji, []);
      }
      reactionMap.get(emoji)!.push(reaction.user_id);
    }

    // Convert to array format
    const reactionSummary: ReactionSummary[] = Array.from(
      reactionMap.entries()
    ).map(([emoji, users]) => ({
      emoji,
      count: users.length,
      users,
    }));

    // Sort by count descending
    reactionSummary.sort((a, b) => b.count - a.count);

    // Get current user's reaction if authenticated
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    let userReaction: AllowedEmoji | undefined;

    if (privyId) {
      const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
      if (supabaseUser) {
        const userReactionEntry = reactions?.find(
          (r) => r.user_id === supabaseUser.id
        );
        if (userReactionEntry) {
          userReaction = userReactionEntry.emoji as AllowedEmoji;
        }
      }
    }

    return NextResponse.json({
      success: true,
      data: { reactions: reactionSummary, userReaction },
    });
  } catch (error) {
    console.error('Error getting discussion reactions:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get reactions' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<ToggleReactionResponse>> {
  try {
    const { id: discussionId } = await params;

    // Get Privy ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { emoji } = body;

    // Validate emoji
    if (!emoji || !ALLOWED_EMOJIS.includes(emoji as AllowedEmoji)) {
      return NextResponse.json(
        {
          success: false,
          error: `Invalid emoji. Allowed: ${ALLOWED_EMOJIS.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Table not in generated types yet
    const supabase = getSupabaseAdmin() as any;

    // Check if user already reacted with this emoji
    const { data: existingReaction } = (await supabase
      .from('discussion_reactions')
      .select('id')
      .eq('discussion_id', discussionId)
      .eq('user_id', supabaseUser.id)
      .eq('emoji', emoji)
      .single()) as { data: { id: string } | null };

    let reacted = false;

    if (existingReaction) {
      // Remove reaction
      const { error: deleteError } = await supabase
        .from('discussion_reactions')
        .delete()
        .eq('id', existingReaction.id);

      if (deleteError) {
        console.error('Error removing reaction:', deleteError);
        return NextResponse.json(
          { success: false, error: 'Failed to remove reaction' },
          { status: 500 }
        );
      }
      reacted = false;
    } else {
      // Check if user reacted with a different emoji - remove it first
      const { data: otherReaction } = (await supabase
        .from('discussion_reactions')
        .select('id')
        .eq('discussion_id', discussionId)
        .eq('user_id', supabaseUser.id)
        .single()) as { data: { id: string } | null };

      if (otherReaction) {
        await supabase
          .from('discussion_reactions')
          .delete()
          .eq('id', otherReaction.id);
      }

      // Add new reaction
      const { error: insertError } = await supabase
        .from('discussion_reactions')
        .insert({
          discussion_id: discussionId,
          user_id: supabaseUser.id,
          emoji,
        });

      if (insertError) {
        console.error('Error adding reaction:', insertError);
        return NextResponse.json(
          { success: false, error: 'Failed to add reaction' },
          { status: 500 }
        );
      }
      reacted = true;
    }

    // Get updated count for this emoji
    const { count } = await supabase
      .from('discussion_reactions')
      .select('*', { count: 'exact', head: true })
      .eq('discussion_id', discussionId)
      .eq('emoji', emoji);

    return NextResponse.json({
      success: true,
      data: {
        reacted,
        emoji: emoji as AllowedEmoji,
        count: count || 0,
      },
    });
  } catch (error) {
    console.error('Error toggling reaction:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to toggle reaction' },
      { status: 500 }
    );
  }
}
