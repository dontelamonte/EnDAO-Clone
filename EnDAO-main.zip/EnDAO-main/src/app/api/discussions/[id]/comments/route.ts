/**
 * Discussion Comments API Route
 *
 * GET: List comments for a discussion
 * POST: Create a new comment
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  discussionCommentAdminRepository,
  userAdminRepository,
  discussionAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';

interface CommentResponse {
  id: string;
  discussionId: string;
  userId: string;
  content: string;
  parentId: string | null;
  isHidden: boolean;
  createdAt: string;
  updatedAt: string;
  // Enriched author data
  authorUsername?: string;
  authorName: string;
  authorAvatar?: string;
  authorRole?: 'admin' | 'member';
  // Engagement
  likes: string[];
  likeCount: number;
  replyCount: number;
  // Moderation
  hiddenBy?: string;
  hiddenReason?: string;
}

interface GetCommentsResponse {
  success: boolean;
  data?: {
    comments: CommentResponse[];
    lastDoc?: { id: string; createdAt: string };
    hasMore: boolean;
  };
  error?: string;
}

interface CreateCommentResponse {
  success: boolean;
  data?: CommentResponse;
  error?: string;
}

// Enrich comment with author data and like info
async function enrichComment(
  comment: Awaited<
    ReturnType<typeof discussionCommentAdminRepository.findById>
  > &
    object,
  daoId: string,
  likeInfo?: { likeCount: number; userLiked: boolean; likers: string[] }
): Promise<CommentResponse> {
  // Fetch author data
  const author = await userAdminRepository.findById(comment.userId);

  // Check if author is DAO member and get role
  let authorRole: 'admin' | 'member' | undefined;
  try {
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      comment.userId
    );
    if (membership && membership.role === 'admin') {
      authorRole = 'admin';
    } else if (membership) {
      authorRole = 'member';
    }
  } catch {
    // Ignore membership lookup errors
  }

  // Count replies
  const replyCount = await discussionCommentAdminRepository.countReplies(
    comment.id
  );

  return {
    id: comment.id,
    discussionId: comment.discussionId,
    userId: comment.userId,
    content: comment.content,
    parentId: comment.parentId,
    isHidden: comment.isHidden,
    createdAt: comment.createdAt,
    updatedAt: comment.updatedAt,
    // Author metadata from users table
    authorUsername: author?.username || undefined,
    authorName: author?.displayName || 'Anonymous',
    authorAvatar: author?.avatarUrl || undefined,
    authorRole,
    // Engagement - with real like data
    likes: likeInfo?.likers || [],
    likeCount: likeInfo?.likeCount || 0,
    replyCount,
    // Moderation
    hiddenBy: comment.hiddenBy || undefined,
    hiddenReason: comment.hiddenReason || undefined,
  };
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<GetCommentsResponse>> {
  try {
    const { id: discussionId } = await params;
    const { searchParams } = new URL(request.url);

    const parentId = searchParams.get('parentId');
    const sortBy = (searchParams.get('sortBy') || 'newest') as
      | 'newest'
      | 'oldest';
    const limit = parseInt(searchParams.get('limit') || '20', 10);

    if (!discussionId) {
      return NextResponse.json(
        { success: false, error: 'Discussion ID is required' },
        { status: 400 }
      );
    }

    // Validate discussion exists and get daoId for role checks
    const discussion = await discussionAdminRepository.findById(discussionId);
    if (!discussion) {
      return NextResponse.json(
        { success: false, error: 'Discussion not found' },
        { status: 404 }
      );
    }

    // Fetch comments from repository
    const comments = await discussionCommentAdminRepository.findByDiscussion(
      discussionId,
      {
        parentId: parentId === 'null' ? null : parentId || undefined,
        limit: limit + 1, // Fetch one extra to check hasMore
        sortBy,
      }
    );

    // Check if there are more results
    const hasMore = comments.length > limit;
    const resultComments = hasMore ? comments.slice(0, limit) : comments;

    // Get like info for all comments in batch
    const commentIds = resultComments.map((c) => c.id);

    // Get current user ID if authenticated (for checking if user liked)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    let currentUserId: string | undefined;
    if (privyId) {
      const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
      currentUserId = supabaseUser?.id;
    }

    // Batch fetch like info
    const likeInfoBatch =
      await discussionCommentAdminRepository.getLikeInfoBatch(
        commentIds,
        currentUserId
      );

    // Enrich comments with author data and like info
    const enrichedComments = await Promise.all(
      resultComments.map(async (c) => {
        const likeInfo = likeInfoBatch.get(c.id) || {
          likeCount: 0,
          userLiked: false,
        };
        // Get likers list for this comment
        const likers = await discussionCommentAdminRepository.getLikers(c.id);
        return enrichComment(c, discussion.daoId, { ...likeInfo, likers });
      })
    );

    // Return paginated result
    const lastComment = enrichedComments[enrichedComments.length - 1];
    return NextResponse.json({
      success: true,
      data: {
        comments: enrichedComments,
        lastDoc: lastComment
          ? { id: lastComment.id, createdAt: lastComment.createdAt }
          : undefined,
        hasMore,
      },
    });
  } catch (error) {
    console.error('Error fetching discussion comments:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch comments' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<CreateCommentResponse>> {
  try {
    const { id: discussionId } = await params;

    // Get Privy ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Validate discussion exists
    const discussion = await discussionAdminRepository.findById(discussionId);
    if (!discussion) {
      return NextResponse.json(
        { success: false, error: 'Discussion not found' },
        { status: 404 }
      );
    }

    // Check DAO membership
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      discussion.daoId,
      supabaseUser.id
    );
    if (!membership || membership.status !== 'active') {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be an active DAO member to comment',
        },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { content, parentId } = body;

    if (
      !content ||
      typeof content !== 'string' ||
      content.trim().length === 0
    ) {
      return NextResponse.json(
        { success: false, error: 'Comment content is required' },
        { status: 400 }
      );
    }

    if (content.trim().length > 10000) {
      return NextResponse.json(
        { success: false, error: 'Comment must be 10,000 characters or less' },
        { status: 400 }
      );
    }

    // Validate parent comment exists if parentId provided
    if (parentId) {
      const parentComment =
        await discussionCommentAdminRepository.findById(parentId);
      if (!parentComment) {
        return NextResponse.json(
          { success: false, error: 'Parent comment not found' },
          { status: 404 }
        );
      }
      if (parentComment.discussionId !== discussionId) {
        return NextResponse.json(
          {
            success: false,
            error: 'Parent comment belongs to a different discussion',
          },
          { status: 400 }
        );
      }
    }

    // Create comment
    const comment = await discussionCommentAdminRepository.createComment({
      discussionId,
      userId: supabaseUser.id,
      content: content.trim(),
      parentId: parentId || null,
    });

    // Update discussion comment count and last activity
    await discussionAdminRepository.incrementCommentCount(discussionId);

    // Enrich with author data
    const enrichedComment = await enrichComment(comment, discussion.daoId);

    return NextResponse.json({
      success: true,
      data: enrichedComment,
    });
  } catch (error) {
    console.error('Error creating discussion comment:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create comment' },
      { status: 500 }
    );
  }
}
