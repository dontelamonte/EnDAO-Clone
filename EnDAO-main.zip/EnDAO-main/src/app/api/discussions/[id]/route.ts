/**
 * Discussion API Route
 *
 * GET - Fetches a single discussion by ID
 * PATCH - Updates discussion (creator or admin only)
 * DELETE - Archives discussion (creator or admin only)
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  discussionAdminRepository,
  userAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { DiscussionStatus } from '@/lib/data/repositories/supabase/discussion.repository';

interface DiscussionResponse {
  success: boolean;
  data?: unknown;
  error?: string;
  code?: string;
}

/**
 * GET - Fetch a single discussion by ID with creator info
 * Public endpoint with caching
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<DiscussionResponse>> {
  try {
    const { id: discussionId } = await params;

    if (!discussionId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Fetch discussion with creator info (server-side enrichment)
    const discussion =
      await discussionAdminRepository.findByIdWithCreator(discussionId);

    if (!discussion) {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion not found',
          code: 'DISCUSSION_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Add cache headers for public data
    const headers = {
      'Cache-Control': 'public, max-age=30, stale-while-revalidate=15',
    };

    return NextResponse.json(
      {
        success: true,
        data: discussion,
      },
      { headers }
    );
  } catch (error) {
    logger.error('[Discussion API] Error fetching discussion', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch discussion',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH - Update a discussion
 * Only creator or DAO admin can update
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<DiscussionResponse>> {
  try {
    const { id: discussionId } = await params;

    if (!discussionId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get auth from headers (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Get user from Privy ID
    const user = await userAdminRepository.findByPrivyId(privyId);
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get the discussion
    const discussion = await discussionAdminRepository.findById(discussionId);
    if (!discussion) {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion not found',
          code: 'DISCUSSION_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Cannot update converted discussions
    if (discussion.status === 'converted') {
      return NextResponse.json(
        {
          success: false,
          error:
            'Cannot update a discussion that has been converted to a proposal',
          code: 'DISCUSSION_CONVERTED',
        },
        { status: 400 }
      );
    }

    // Check permissions - creator or DAO admin
    const isCreator = discussion.createdBy === user.id;
    const isAdmin = await daoMemberAdminRepository.isAdmin(
      discussion.daoId,
      user.id
    );

    if (!isCreator && !isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Only the creator or DAO admin can update this discussion',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { title, content, status, isPinned } = body;

    // Validate at least one field to update
    if (
      title === undefined &&
      content === undefined &&
      status === undefined &&
      isPinned === undefined
    ) {
      return NextResponse.json(
        {
          success: false,
          error: 'At least one field must be provided for update',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Validate field lengths if provided
    if (title !== undefined) {
      if (typeof title !== 'string' || title.length < 3 || title.length > 200) {
        return NextResponse.json(
          {
            success: false,
            error: 'Title must be between 3 and 200 characters',
            code: 'VALIDATION_ERROR',
          },
          { status: 400 }
        );
      }
    }

    if (content !== undefined) {
      if (
        typeof content !== 'string' ||
        content.length < 10 ||
        content.length > 10000
      ) {
        return NextResponse.json(
          {
            success: false,
            error: 'Content must be between 10 and 10,000 characters',
            code: 'VALIDATION_ERROR',
          },
          { status: 400 }
        );
      }
    }

    // Validate status if provided
    if (status !== undefined) {
      const validStatuses: DiscussionStatus[] = [
        'active',
        'archived',
        'converted',
      ];
      if (!validStatuses.includes(status)) {
        return NextResponse.json(
          {
            success: false,
            error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`,
            code: 'INVALID_STATUS',
          },
          { status: 400 }
        );
      }
    }

    // Only admins can pin/unpin
    if (isPinned !== undefined && !isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Only DAO admins can pin or unpin discussions',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Build update data
    const updateData: Record<string, unknown> = {};
    if (title !== undefined) updateData.title = title.trim();
    if (content !== undefined) updateData.content = content.trim();
    if (status !== undefined) updateData.status = status;
    if (isPinned !== undefined) updateData.isPinned = isPinned;

    // Update the discussion
    const updated = await discussionAdminRepository.update(
      discussionId,
      updateData
    );
    if (!updated) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to update discussion',
          code: 'UPDATE_FAILED',
        },
        { status: 500 }
      );
    }

    logger.info('[Discussion API] Discussion updated', {
      discussionId,
      userId: user.id,
      updates: Object.keys(updateData),
    });

    return NextResponse.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    logger.error('[Discussion API] Error updating discussion', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to update discussion',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * DELETE - Archive a discussion
 * Only creator or DAO admin can delete
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<DiscussionResponse>> {
  try {
    const { id: discussionId } = await params;

    if (!discussionId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get auth from headers (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Get user from Privy ID
    const user = await userAdminRepository.findByPrivyId(privyId);
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get the discussion
    const discussion = await discussionAdminRepository.findById(discussionId);
    if (!discussion) {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion not found',
          code: 'DISCUSSION_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check permissions - creator or DAO admin
    const isCreator = discussion.createdBy === user.id;
    const isAdmin = await daoMemberAdminRepository.isAdmin(
      discussion.daoId,
      user.id
    );

    if (!isCreator && !isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Only the creator or DAO admin can delete this discussion',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Archive instead of hard delete
    await discussionAdminRepository.archive(discussionId, user.id);

    logger.info('[Discussion API] Discussion archived', {
      discussionId,
      userId: user.id,
      daoId: discussion.daoId,
    });

    return NextResponse.json({
      success: true,
      data: null,
    });
  } catch (error) {
    logger.error('[Discussion API] Error deleting discussion', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to delete discussion',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
