/**
 * Discussion Conversion API Route
 *
 * POST: Convert discussion to proposal
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  discussionAdminRepository,
  userAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import { ProposalServiceOrchestrator } from '@/lib/services/proposal';
import { DAOService } from '@/lib/services/dao';
import type { ProposalType } from '@endao/shared-types';

// Minimal proposal data needed for conversion (service fills in defaults from DAO settings)
interface ConversionProposalData {
  title: string;
  description: string;
  type: ProposalType;
  [key: string]: unknown; // Allow additional fields from additionalData
}

interface ConvertResponse {
  success: boolean;
  data?: {
    proposalId: string;
    discussionId: string;
    convertedAt: string;
  };
  error?: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<ConvertResponse>> {
  try {
    const { id: discussionId } = await params;

    // Get Privy ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Fetch discussion
    const discussion = await discussionAdminRepository.findById(discussionId);
    if (!discussion) {
      return NextResponse.json(
        { success: false, error: 'Discussion not found' },
        { status: 404 }
      );
    }

    // Check if already converted
    if (discussion.status === 'converted') {
      return NextResponse.json(
        {
          success: false,
          error: 'Discussion has already been converted to a proposal',
        },
        { status: 400 }
      );
    }

    // Verify user is the author or admin
    const isAuthor = discussion.createdBy === supabaseUser.id;
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      discussion.daoId,
      supabaseUser.id
    );
    const isAdmin = membership?.role === 'admin';

    if (!isAuthor && !isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Only the author or DAO admin can convert this discussion',
        },
        { status: 403 }
      );
    }

    // Check if DAO is frozen
    const daoService = DAOService.getInstance();
    const frozenCheck = await daoService.checkDAONotFrozen(discussion.daoId);
    if (!frozenCheck.success) {
      return NextResponse.json(
        { success: false, error: frozenCheck.error || 'DAO is frozen' },
        { status: 403 }
      );
    }

    // Parse request body for optional overrides
    const body = await request.json();
    const { proposalType = 'general', additionalData = {} } = body as {
      proposalType?: ProposalType;
      additionalData?: Record<string, unknown>;
    };

    // Validate proposal type
    const validTypes: ProposalType[] = [
      'general',
      'governance',
      'funding',
      'bounty',
    ];
    if (!validTypes.includes(proposalType)) {
      return NextResponse.json(
        { success: false, error: `Invalid proposal type: ${proposalType}` },
        { status: 400 }
      );
    }

    // Build proposal data from discussion
    // The service will fill in voting config defaults from DAO settings
    const title =
      typeof additionalData.title === 'string'
        ? additionalData.title
        : discussion.title;
    const description =
      typeof additionalData.description === 'string'
        ? additionalData.description
        : discussion.content;
    const proposalData: ConversionProposalData = {
      title: title.substring(0, 200), // Truncate if needed
      description: description.substring(0, 10000), // Truncate if needed
      type: proposalType,
      ...additionalData, // Allow overriding/adding fields
    };

    // Create proposal using ProposalServiceOrchestrator
    // Cast to any since service accepts broader type but we provide minimal required fields
    const proposalService = ProposalServiceOrchestrator.getInstance();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const createResult = await proposalService.createProposal(
      discussion.daoId,
      supabaseUser.id,
      proposalData as any, // Service fills in defaults from DAO settings
      undefined, // memberData - service will fetch
      undefined, // daoData - service will fetch
      isAdmin
    );

    if (!createResult.success || !createResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: createResult.error || 'Failed to create proposal',
        },
        { status: 500 }
      );
    }

    const proposalId = createResult.data.id;

    // Mark discussion as converted
    await discussionAdminRepository.markConverted(
      discussionId,
      proposalId,
      supabaseUser.id
    );

    return NextResponse.json({
      success: true,
      data: {
        proposalId,
        discussionId,
        convertedAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Error converting discussion:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to convert discussion' },
      { status: 500 }
    );
  }
}
