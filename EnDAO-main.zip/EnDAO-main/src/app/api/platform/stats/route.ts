/**
 * Public Platform Stats API
 * Returns aggregate platform statistics for the landing page
 * No authentication required
 */

import { NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';

export const revalidate = 300; // Cache for 5 minutes

export async function GET() {
  try {
    const supabase = getSupabaseAdmin();

    // Count active, discoverable DAOs
    const { count: daoCount, error } = await supabase
      .from('daos')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active')
      .eq('is_discoverable', true);

    if (error) {
      console.error('Error fetching platform stats:', error);
      return NextResponse.json({ daoCount: 0 }, { status: 200 });
    }

    return NextResponse.json({
      daoCount: daoCount || 0,
    });
  } catch (error) {
    console.error('Platform stats error:', error);
    return NextResponse.json({ daoCount: 0 }, { status: 200 });
  }
}
