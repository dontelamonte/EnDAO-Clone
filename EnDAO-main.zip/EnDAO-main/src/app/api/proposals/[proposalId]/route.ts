/**
 * Proposal API Route
 *
 * GET - Fetches a single proposal by ID
 * PATCH - Updates proposal status (admin only)
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  userAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface ProposalResponse {
  success: boolean;
  data?: unknown;
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<ProposalResponse>> {
  try {
    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Fetch proposal with creator info (Phase 4: Unified Query Interface)
    // Uses proposal_with_creator view when useDbViews flag is enabled
    const proposal =
      await proposalAdminRepository.findByIdWithCreator(proposalId);

    if (!proposal) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Creator info is now included from the unified query
    const createdByName = proposal.createdByName;
    const createdByUsername = proposal.createdByUsername;

    // Map repository fields to shared-types Proposal interface
    // Repository uses votingStartTime/votingEndTime, UI expects startTime/endTime
    const mappedProposal = {
      ...proposal,
      startTime: proposal.votingStartTime,
      endTime: proposal.votingEndTime,
      createdByName,
      createdByUsername,
      // Include results from vote summary (if available from optimized query)
      results: proposal.result,
    };

    return NextResponse.json({
      success: true,
      data: mappedProposal,
    });
  } catch (error) {
    logger.error(
      'Error fetching proposal',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch proposal',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH - Update proposal
 * Supports:
 * - Draft updates (title, description, type, votingConfig) by creator
 * - Status updates (admin finalization)
 * - Publishing drafts (status: 'active')
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<ProposalResponse>> {
  try {
    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get auth from headers (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Get user from Privy ID
    const user = await userAdminRepository.findByPrivyId(privyId);
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get the proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Parse request body
    const body = await request.json();
    const {
      title,
      description,
      type,
      votingSystem,
      quorumPercentage,
      passThreshold,
      allowChangeVote,
      status,
      finalizedAt,
      finalizedBy,
      forceFinalized,
    } = body;

    // Determine if this is a draft update or admin status update
    const isDraftUpdate = proposal.status === 'draft';
    const isCreator = proposal.createdBy === user.id;
    const isAdmin = await daoMemberAdminRepository.isAdmin(
      proposal.daoId,
      user.id
    );

    // Authorization: draft updates require creator OR admin, status updates require admin
    if (isDraftUpdate) {
      if (!isCreator && !isAdmin) {
        return NextResponse.json(
          {
            success: false,
            error: 'Only the proposal creator or admin can update drafts',
            code: 'NOT_AUTHORIZED',
          },
          { status: 403 }
        );
      }
    } else {
      // Non-draft updates require admin
      if (!isAdmin) {
        return NextResponse.json(
          {
            success: false,
            error: 'Only DAO admins can update published proposals',
            code: 'NOT_DAO_ADMIN',
          },
          { status: 403 }
        );
      }
    }

    // Validate status if provided
    const validStatuses = [
      'draft',
      'under_review',
      'active',
      'passed',
      'rejected',
      'executed',
      'cancelled',
    ];
    if (status && !validStatuses.includes(status)) {
      return NextResponse.json(
        { success: false, error: 'Invalid status', code: 'INVALID_STATUS' },
        { status: 400 }
      );
    }

    // Build update data
    const updateData: Record<string, unknown> = {
      updatedAt: new Date().toISOString(),
    };

    // Draft fields (only if in draft status)
    if (isDraftUpdate) {
      if (title !== undefined) updateData.title = title;
      if (description !== undefined) updateData.description = description;
      if (type !== undefined) updateData.type = type;

      // Update voting config if provided
      if (
        votingSystem !== undefined ||
        quorumPercentage !== undefined ||
        passThreshold !== undefined ||
        allowChangeVote !== undefined
      ) {
        const currentVotingConfig = proposal.votingConfig || {};
        updateData.votingConfig = {
          ...currentVotingConfig,
          ...(votingSystem !== undefined && { system: votingSystem }),
          ...(quorumPercentage !== undefined && { quorumPercentage }),
          ...(passThreshold !== undefined && { passThreshold }),
          ...(allowChangeVote !== undefined && { allowChangeVote }),
        };
      }

      // If publishing (status changing to active), set voting times
      if (status === 'active' && proposal.status === 'draft') {
        const now = new Date();
        const votingDurationDays = 7; // Default 7 days
        const endTime = new Date(
          now.getTime() + votingDurationDays * 24 * 3600 * 1000
        );
        updateData.votingStartTime = now.toISOString();
        updateData.votingEndTime = endTime.toISOString();
        updateData.startTime = now.toISOString();
        updateData.endTime = endTime.toISOString();
      }
    }

    // Status fields (admin finalization or publish)
    if (status) updateData.status = status;
    if (finalizedAt) updateData.finalizedAt = finalizedAt;
    if (finalizedBy) updateData.finalizedBy = finalizedBy;
    if (forceFinalized !== undefined)
      updateData.forceFinalized = forceFinalized;

    // Update the proposal
    const updated = await proposalAdminRepository.update(
      proposalId,
      updateData
    );
    if (!updated) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to update proposal',
          code: 'UPDATE_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: updated,
    });
  } catch (error) {
    logger.error(
      'Error updating proposal',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]', method: 'PATCH' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to update proposal',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
