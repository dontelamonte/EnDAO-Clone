/**
 * API Route: Approve Proposal Early (Admin Action)
 * Skips warm-up period and starts voting immediately
 * POST /api/proposals/[proposalId]/approve
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { proposalWarmUpNotificationService } from '@/lib/services/proposal/notifications/proposal-warmup-notification.service';
import { VotingReminderService } from '@/lib/services/notification/email/voting-reminder.service';
import { DAOMembershipService } from '@/lib/services/dao/dao-membership.service';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    const { proposalId } = await params;

    // Get auth context from middleware
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Pre-fetch proposal to check permissions
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Verify user is admin
    const membershipService = DAOMembershipService.getInstance();
    const isAdmin = await membershipService.verifyAdminPermission(
      proposal.daoId,
      authContext.uid
    );

    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Only admins can approve proposals' },
        { status: 403 }
      );
    }

    // Verify proposal is under review (prevents race condition)
    if (proposal.status !== 'under_review') {
      return NextResponse.json(
        { error: 'Proposal is not under review' },
        { status: 400 }
      );
    }

    // Calculate new times
    const now = new Date();
    const votingStartTime = proposal.votingStartTime
      ? new Date(proposal.votingStartTime)
      : now;
    const votingEndTime = proposal.votingEndTime
      ? new Date(proposal.votingEndTime)
      : now;
    const votingDurationMs =
      votingEndTime.getTime() - votingStartTime.getTime();
    const newEndTime = new Date(now.getTime() + votingDurationMs);

    // Update proposal to active status
    await proposalAdminRepository.update(proposalId, {
      status: 'active',
      votingStartTime: now.toISOString(),
      votingEndTime: newEndTime.toISOString(),
      approvedBy: authContext.uid,
      approvedAt: now.toISOString(),
    });

    // Get DAO name for notification
    const dao = await daoAdminRepository.findById(proposal.daoId);
    const daoName = dao?.name || 'Your DAO';

    // Notify proposal creator
    try {
      await proposalWarmUpNotificationService.notifyCreatorOfApproval(
        proposal,
        daoName,
        authContext.uid
      );
    } catch (notificationError) {
      logger.error(
        'Failed to send approval notification',
        notificationError as Error,
        {
          proposalId,
          component: 'approve-route',
        }
      );
      // Don't fail the approval due to notification error
    }

    // Schedule voting reminders for all DAO members
    try {
      const votingReminderService = VotingReminderService.getInstance();
      const reminderResult =
        await votingReminderService.scheduleRemindersForProposal(
          proposalId,
          proposal.daoId,
          newEndTime.toISOString()
        );
      if (reminderResult.success) {
        logger.info('Scheduled voting reminders for approved proposal', {
          proposalId,
          remindersScheduled: reminderResult.data,
          component: 'approve-route',
        });
      }
    } catch (reminderError) {
      logger.error(
        'Failed to schedule voting reminders',
        reminderError as Error,
        {
          proposalId,
          component: 'approve-route',
        }
      );
      // Don't fail the approval due to reminder scheduling error
    }

    return NextResponse.json({
      success: true,
      message: 'Proposal approved and voting started',
      proposal: {
        id: proposalId,
        status: 'active',
        startTime: now.toISOString(),
        endTime: newEndTime.toISOString(),
      },
    });
  } catch (error: unknown) {
    logger.error(
      'Error approving proposal',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/approve', method: 'POST' }
    );
    return NextResponse.json(
      { error: 'Failed to approve proposal' },
      { status: 500 }
    );
  }
}
