/**
 * Proposal Comments API Route
 *
 * GET: List comments for a proposal
 * POST: Create a new comment
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  commentAdminRepository,
  proposalAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { commentCreateSchema } from '@/lib/validations/api';

interface CommentResponse {
  id: string;
  proposalId: string;
  userId: string;
  content: string;
  parentId: string | null;
  isHidden: boolean;
  createdAt: string;
  updatedAt: string;
  // Enriched author data
  authorUsername?: string;
  authorName: string;
  authorAvatar?: string;
  authorRole?: 'admin' | 'member';
  // Engagement (not yet implemented)
  likes: string[];
  likeCount: number;
  replyCount: number;
  // Edit tracking
  isEdited: boolean;
  // Soft delete
  isDeleted: boolean;
}

interface GetCommentsResponse {
  success: boolean;
  data?: {
    comments: CommentResponse[];
    lastDoc?: { id: string; createdAt: string };
    hasMore: boolean;
  };
  error?: string;
}

interface CreateCommentResponse {
  success: boolean;
  data?: CommentResponse;
  error?: string;
}

// Enrich a single comment with pre-fetched data (no additional queries)
function enrichCommentWithData(
  comment: Awaited<ReturnType<typeof commentAdminRepository.findById>> & object,
  authorMap: Map<
    string,
    Awaited<ReturnType<typeof userAdminRepository.findById>>
  >,
  replyCountMap: Map<string, number>,
  likeInfo?: { likeCount: number; userLiked: boolean; likers: string[] }
): CommentResponse {
  const author = authorMap.get(comment.userId);
  const replyCount = replyCountMap.get(comment.id) || 0;

  return {
    id: comment.id,
    proposalId: comment.proposalId,
    userId: comment.userId,
    content: comment.content,
    parentId: comment.parentId,
    isHidden: comment.isHidden,
    createdAt: comment.createdAt,
    updatedAt: comment.updatedAt,
    // Author metadata from users table
    authorUsername: author?.username || undefined,
    authorName: author?.displayName || 'Anonymous',
    authorAvatar: author?.avatarUrl || undefined,
    authorRole: undefined, // TODO: Determine from DAO membership
    // Engagement - now with real like data
    likes: likeInfo?.likers || [],
    likeCount: likeInfo?.likeCount || 0,
    replyCount,
    // Edit tracking (not yet in schema)
    isEdited: false,
    // Soft delete (map isHidden to isDeleted)
    isDeleted: comment.isHidden,
  };
}

// Legacy single-comment enrichment for POST route
async function enrichComment(
  comment: Awaited<ReturnType<typeof commentAdminRepository.findById>> & object,
  likeInfo?: { likeCount: number; userLiked: boolean; likers: string[] }
): Promise<CommentResponse> {
  // Fetch author data
  const author = await userAdminRepository.findById(comment.userId);

  // Count replies
  const replyCount = await commentAdminRepository.countReplies(comment.id);

  const authorMap = new Map([[comment.userId, author]]);
  const replyCountMap = new Map([[comment.id, replyCount]]);

  return enrichCommentWithData(comment, authorMap, replyCountMap, likeInfo);
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<GetCommentsResponse>> {
  try {
    const { proposalId } = await params;
    const { searchParams } = new URL(request.url);

    const parentId = searchParams.get('parentId');
    const sortBy = (searchParams.get('sortBy') || 'newest') as
      | 'newest'
      | 'oldest';
    const limit = parseInt(searchParams.get('limit') || '10', 10);

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID is required' },
        { status: 400 }
      );
    }

    // Fetch comments from repository
    const comments = await commentAdminRepository.findByProposal(proposalId, {
      parentId: parentId === 'null' ? null : parentId || undefined,
      limit: limit + 1, // Fetch one extra to check hasMore
      sortBy,
    });

    // Check if there are more results
    const hasMore = comments.length > limit;
    const resultComments = hasMore ? comments.slice(0, limit) : comments;

    // Get all comment IDs and unique author IDs for batch fetching
    const commentIds = resultComments.map((c) => c.id);
    const uniqueAuthorIds = [...new Set(resultComments.map((c) => c.userId))];

    // Get current user ID if authenticated (for checking if user liked)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    let currentUserId: string | undefined;
    if (privyId) {
      const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
      currentUserId = supabaseUser?.id;
    }

    // Batch fetch all data in parallel - eliminates N+1 queries
    const [likeInfoBatch, likersMap, authors, replyCounts] = await Promise.all([
      // Like counts and user liked status
      commentAdminRepository.getLikeInfoBatch(commentIds, currentUserId),
      // Likers lists for all comments
      commentAdminRepository.getLikersBatch(commentIds),
      // All unique authors
      userAdminRepository.findByIds(uniqueAuthorIds),
      // Reply counts for all comments
      commentAdminRepository.countRepliesBatch(commentIds),
    ]);

    // Build lookup maps for O(1) access
    const authorMap = new Map(authors.map((a) => [a.id, a]));
    const replyCountMap = new Map(Object.entries(replyCounts));

    // Enrich comments with pre-fetched data - no additional queries
    const enrichedComments = resultComments.map((c) => {
      const likeInfo = likeInfoBatch[c.id] || {
        likeCount: 0,
        userLiked: false,
      };
      const likers = likersMap[c.id] || [];
      return enrichCommentWithData(c, authorMap, replyCountMap, {
        ...likeInfo,
        likers,
      });
    });

    // Return paginated result
    const lastComment = enrichedComments[enrichedComments.length - 1];
    return NextResponse.json({
      success: true,
      data: {
        comments: enrichedComments,
        lastDoc: lastComment
          ? { id: lastComment.id, createdAt: lastComment.createdAt }
          : undefined,
        hasMore,
      },
    });
  } catch (error) {
    logger.error(
      'Error fetching comments',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/comments', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch comments' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<CreateCommentResponse>> {
  try {
    const { proposalId } = await params;

    // Get Privy ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Validate proposal exists
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Parse and validate request body using schema
    const body = await request.json();
    const validationResult = commentCreateSchema.safeParse(body);

    if (!validationResult.success) {
      const errors = validationResult.error.errors.map((e) => ({
        path: e.path,
        message: e.message,
      }));
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid comment data',
          code: 'VALIDATION_ERROR',
          details: errors,
        },
        { status: 400 }
      );
    }

    const { content, parentId } = validationResult.data;

    // Create comment
    const comment = await commentAdminRepository.createComment({
      proposalId,
      userId: supabaseUser.id,
      content: content.trim(),
      parentId: parentId || null,
    });

    // Enrich with author data
    const enrichedComment = await enrichComment(comment);

    return NextResponse.json({
      success: true,
      data: enrichedComment,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logger.error(
      'Error creating comment',
      error instanceof Error ? error : new Error(errorMessage),
      {
        url: '/api/proposals/[proposalId]/comments',
        method: 'POST',
      }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create comment',
        code: 'COMMENT_CREATE_ERROR',
        // Include error message in development only
        ...(process.env.NODE_ENV === 'development' && {
          details: errorMessage,
        }),
      },
      { status: 500 }
    );
  }
}
