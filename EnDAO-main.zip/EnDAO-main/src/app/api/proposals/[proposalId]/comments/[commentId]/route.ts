/**
 * Individual Comment API Route
 *
 * GET: Get replies to a comment
 * PATCH: Edit a comment
 * DELETE: Delete (soft) a comment
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  commentAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

const EDIT_WINDOW_MS = 5 * 60 * 1000; // 5 minutes

interface CommentResponse {
  id: string;
  proposalId: string;
  userId: string;
  content: string;
  parentId: string | null;
  isHidden: boolean;
  createdAt: string;
  updatedAt: string;
  authorUsername?: string;
  authorName: string;
  authorAvatar?: string;
  authorRole?: 'admin' | 'member';
  likes: string[];
  likeCount: number;
  replyCount: number;
  isEdited: boolean;
  isDeleted: boolean;
}

interface ApiResponse {
  success: boolean;
  data?: CommentResponse | CommentResponse[];
  error?: string;
}

// Enrich comment with author data
async function enrichComment(
  comment: Awaited<ReturnType<typeof commentAdminRepository.findById>> & object
): Promise<CommentResponse> {
  const author = await userAdminRepository.findById(comment.userId);
  const replyCount = await commentAdminRepository.countReplies(comment.id);

  return {
    id: comment.id,
    proposalId: comment.proposalId,
    userId: comment.userId,
    content: comment.content,
    parentId: comment.parentId,
    isHidden: comment.isHidden,
    createdAt: comment.createdAt,
    updatedAt: comment.updatedAt,
    authorUsername: author?.username || undefined,
    authorName: author?.displayName || 'Anonymous',
    authorAvatar: author?.avatarUrl || undefined,
    authorRole: undefined,
    likes: [],
    likeCount: 0,
    replyCount,
    isEdited: false,
    isDeleted: comment.isHidden,
  };
}

// GET: Get replies to a comment
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string; commentId: string }> }
): Promise<NextResponse<ApiResponse>> {
  try {
    const { commentId } = await params;
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10', 10);

    if (!commentId) {
      return NextResponse.json(
        { success: false, error: 'Comment ID is required' },
        { status: 400 }
      );
    }

    const replies = await commentAdminRepository.findReplies(commentId, {
      limit,
    });
    const enrichedReplies = await Promise.all(
      replies.map((r) => enrichComment(r))
    );

    return NextResponse.json({
      success: true,
      data: enrichedReplies,
    });
  } catch (error) {
    logger.error(
      'Error fetching replies',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/comments/[commentId]', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch replies' },
      { status: 500 }
    );
  }
}

// PATCH: Edit a comment
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string; commentId: string }> }
): Promise<NextResponse<ApiResponse>> {
  try {
    const { commentId } = await params;

    // Get Privy ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Fetch comment to verify ownership and timing
    const comment = await commentAdminRepository.findById(commentId);
    if (!comment) {
      return NextResponse.json(
        { success: false, error: 'Comment not found' },
        { status: 404 }
      );
    }

    // Check ownership
    if (comment.userId !== supabaseUser.id) {
      return NextResponse.json(
        { success: false, error: 'You can only edit your own comments' },
        { status: 403 }
      );
    }

    // Check edit window
    const createdAt = new Date(comment.createdAt);
    const now = new Date();
    if (now.getTime() - createdAt.getTime() > EDIT_WINDOW_MS) {
      return NextResponse.json(
        { success: false, error: 'Edit window has expired (5 minutes)' },
        { status: 400 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { content } = body;

    if (
      !content ||
      typeof content !== 'string' ||
      content.trim().length === 0
    ) {
      return NextResponse.json(
        { success: false, error: 'Comment content is required' },
        { status: 400 }
      );
    }

    // Update content
    const updatedComment = await commentAdminRepository.updateComment(
      commentId,
      content.trim()
    );
    const enrichedComment = await enrichComment(updatedComment);

    return NextResponse.json({
      success: true,
      data: enrichedComment,
    });
  } catch (error) {
    logger.error(
      'Error editing comment',
      error instanceof Error ? error : new Error(String(error)),
      {
        url: '/api/proposals/[proposalId]/comments/[commentId]',
        method: 'PATCH',
      }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to edit comment' },
      { status: 500 }
    );
  }
}

// DELETE: Soft delete a comment
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string; commentId: string }> }
): Promise<NextResponse<ApiResponse>> {
  try {
    const { commentId } = await params;

    // Get Privy ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Fetch comment to verify ownership
    const comment = await commentAdminRepository.findById(commentId);
    if (!comment) {
      return NextResponse.json(
        { success: false, error: 'Comment not found' },
        { status: 404 }
      );
    }

    // Check ownership
    if (comment.userId !== supabaseUser.id) {
      return NextResponse.json(
        { success: false, error: 'You can only delete your own comments' },
        { status: 403 }
      );
    }

    // Soft delete by hiding
    await commentAdminRepository.hideComment(
      commentId,
      supabaseUser.id,
      'Deleted by author'
    );

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    logger.error(
      'Error deleting comment',
      error instanceof Error ? error : new Error(String(error)),
      {
        url: '/api/proposals/[proposalId]/comments/[commentId]',
        method: 'DELETE',
      }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to delete comment' },
      { status: 500 }
    );
  }
}
