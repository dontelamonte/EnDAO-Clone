/**
 * Comment API Routes Tests
 *
 * Integration tests for /api/proposals/[proposalId]/comments endpoint.
 * Tests the ACTUAL validation schema used in production.
 */

import {
  commentCreateSchema,
  commentUpdateSchema,
} from '@/lib/validations/api';

describe('Comment API Routes - Validation', () => {
  describe('commentCreateSchema', () => {
    describe('content field', () => {
      it('should accept valid content', () => {
        const result = commentCreateSchema.safeParse({
          content: 'This is a valid comment',
        });
        expect(result.success).toBe(true);
      });

      it('should reject missing content', () => {
        const result = commentCreateSchema.safeParse({});
        expect(result.success).toBe(false);
      });

      it('should reject empty content', () => {
        const result = commentCreateSchema.safeParse({ content: '' });
        expect(result.success).toBe(false);
      });

      it('should reject whitespace-only content', () => {
        const result = commentCreateSchema.safeParse({ content: '   ' });
        expect(result.success).toBe(false);
      });

      it('should reject content exceeding 10000 characters', () => {
        const longContent = 'a'.repeat(10001);
        const result = commentCreateSchema.safeParse({ content: longContent });
        expect(result.success).toBe(false);
      });

      it('should accept content at exactly 10000 characters', () => {
        const maxContent = 'a'.repeat(10000);
        const result = commentCreateSchema.safeParse({ content: maxContent });
        expect(result.success).toBe(true);
      });

      it('should reject XSS attempts in content', () => {
        const result = commentCreateSchema.safeParse({
          content: '<script>alert("xss")</script>',
        });
        expect(result.success).toBe(false);
      });

      it('should reject SQL injection attempts in content', () => {
        const result = commentCreateSchema.safeParse({
          content: "'; DROP TABLE comments;--",
        });
        expect(result.success).toBe(false);
      });
    });

    describe('parentId field', () => {
      it('should accept valid UUID for parentId', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Valid reply',
          parentId: '123e4567-e89b-12d3-a456-426614174000',
        });
        expect(result.success).toBe(true);
      });

      it('should accept null parentId for top-level comments', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Top level comment',
          parentId: null,
        });
        expect(result.success).toBe(true);
      });

      it('should accept undefined parentId (omitted)', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Comment without parentId',
        });
        expect(result.success).toBe(true);
      });

      it('should reject invalid UUID format for parentId', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Invalid reply',
          parentId: 'not-a-uuid',
        });
        expect(result.success).toBe(false);
        if (!result.success) {
          expect(result.error.errors[0].message).toContain('Invalid');
        }
      });
    });

    describe('optional metadata fields', () => {
      it('should accept daoId as optional UUID', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Comment with daoId',
          daoId: '123e4567-e89b-12d3-a456-426614174000',
        });
        expect(result.success).toBe(true);
      });

      it('should accept authorRole as optional enum', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Comment with role',
          authorRole: 'admin',
        });
        expect(result.success).toBe(true);

        const result2 = commentCreateSchema.safeParse({
          content: 'Comment with role',
          authorRole: 'member',
        });
        expect(result2.success).toBe(true);
      });

      it('should reject invalid authorRole', () => {
        const result = commentCreateSchema.safeParse({
          content: 'Comment with invalid role',
          authorRole: 'superadmin',
        });
        expect(result.success).toBe(false);
      });
    });
  });

  describe('commentUpdateSchema', () => {
    it('should accept valid content update', () => {
      const result = commentUpdateSchema.safeParse({
        content: 'Updated comment content',
      });
      expect(result.success).toBe(true);
    });

    it('should reject empty content update', () => {
      const result = commentUpdateSchema.safeParse({
        content: '',
      });
      expect(result.success).toBe(false);
    });

    it('should reject whitespace-only content update', () => {
      const result = commentUpdateSchema.safeParse({
        content: '   ',
      });
      expect(result.success).toBe(false);
    });
  });
});

describe('Comment Validation - Edge Cases', () => {
  it('should handle unicode content correctly', () => {
    const result = commentCreateSchema.safeParse({
      content: 'Hello! 你好 مرحبا שלום 🎉',
    });
    expect(result.success).toBe(true);
  });

  it('should handle markdown content', () => {
    const result = commentCreateSchema.safeParse({
      content: '**Bold** and _italic_ and [links](https://example.com)',
    });
    expect(result.success).toBe(true);
  });

  it('should handle mentions correctly', () => {
    const result = commentCreateSchema.safeParse({
      content: 'Hey @username, what do you think?',
    });
    expect(result.success).toBe(true);
  });

  it('should handle newlines correctly', () => {
    const result = commentCreateSchema.safeParse({
      content: 'Line 1\nLine 2\n\nLine 4',
    });
    expect(result.success).toBe(true);
  });
});
