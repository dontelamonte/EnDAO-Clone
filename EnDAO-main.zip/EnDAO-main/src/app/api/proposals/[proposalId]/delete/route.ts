/**
 * Delete Proposal API Route
 *
 * DELETE - Delete a draft proposal
 * Browser-safe wrapper around ProposalOperationsService.deleteProposal
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface DeleteResponse {
  success: boolean;
  error?: string;
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<DeleteResponse>> {
  try {
    // Get user auth from middleware headers
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Get proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Check if user is the creator of the proposal
    if (proposal.createdBy !== userId) {
      return NextResponse.json(
        { success: false, error: 'Only the proposal creator can delete it' },
        { status: 403 }
      );
    }

    // Check if proposal is in draft status
    if (proposal.status !== 'draft') {
      return NextResponse.json(
        { success: false, error: 'Only draft proposals can be deleted' },
        { status: 400 }
      );
    }

    // Delete the proposal
    await proposalAdminRepository.delete(proposalId);

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    logger.error(
      '[Delete Proposal API] Error deleting proposal',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to delete proposal' },
      { status: 500 }
    );
  }
}
