import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  daoMemberAdminRepository,
  voteAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export type VoteStatus =
  | 'eligible'
  | 'already_voted'
  | 'not_member'
  | 'voting_ended'
  | 'under_review'
  | 'draft';

export type UserVoteOption = 'for' | 'against' | 'abstain';

export interface CanVoteResponse {
  success: boolean;
  data?: {
    canVote: boolean;
    reason: string | null;
    voteStatus: VoteStatus;
    userVote?: UserVoteOption;
    allowChangeVote?: boolean;
  };
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<CanVoteResponse>> {
  try {
    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy ID from auth header (set by middleware) or query param fallback
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      // User not found in database - can't be a member
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'You must be a DAO member to vote',
          voteStatus: 'not_member',
        },
      });
    }

    const userId = supabaseUser.id;

    // Step 1: Get proposal data
    const proposal = await proposalAdminRepository.findById(proposalId);

    if (!proposal) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Step 2: Check proposal status
    if (proposal.status === 'draft') {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'This proposal is still in draft mode',
          voteStatus: 'draft',
        },
      });
    }

    if (proposal.status === 'under_review') {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'This proposal is under review by admins',
          voteStatus: 'under_review',
        },
      });
    }

    // Step 3: Check if voting period ended
    const now = new Date();
    const endTime = proposal.votingEndTime
      ? new Date(proposal.votingEndTime)
      : null;

    if (endTime && now > endTime) {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'Voting period has ended',
          voteStatus: 'voting_ended',
        },
      });
    }

    // Step 4: Check DAO membership
    const members = await daoMemberAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: proposal.daoId },
        { field: 'userId', operator: '==', value: userId },
        { field: 'status', operator: '==', value: 'active' },
      ],
      limit: 1,
    });

    if (members.length === 0) {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'You must be a DAO member to vote',
          voteStatus: 'not_member',
        },
      });
    }

    // Step 5: Check if user already voted
    const existingVotes = await voteAdminRepository.findMany({
      filters: [
        { field: 'proposalId', operator: '==', value: proposalId },
        { field: 'userId', operator: '==', value: userId },
      ],
      limit: 1,
    });

    if (existingVotes.length > 0) {
      const userVote = existingVotes[0];
      const allowChangeVote = proposal.votingConfig?.allowChangeVote ?? false;

      return NextResponse.json({
        success: true,
        data: {
          canVote: allowChangeVote,
          reason: allowChangeVote
            ? 'You can change your vote'
            : 'You have already voted on this proposal',
          voteStatus: allowChangeVote ? 'eligible' : 'already_voted',
          userVote: userVote.vote as UserVoteOption,
          allowChangeVote,
        },
      });
    }

    // Step 6: All checks passed - user is eligible
    // Add caching headers - 15 sec cache (voting window is time-sensitive)
    return NextResponse.json(
      {
        success: true,
        data: {
          canVote: true,
          reason: null,
          voteStatus: 'eligible',
        },
      },
      {
        headers: {
          'Cache-Control': 'private, max-age=15, stale-while-revalidate=5',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error checking vote eligibility',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/can-vote', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : 'Failed to check vote eligibility',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
