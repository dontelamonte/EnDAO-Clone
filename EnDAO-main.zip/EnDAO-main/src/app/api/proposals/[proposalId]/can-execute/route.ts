/**
 * Can Execute Proposal API Route
 *
 * GET - Check if the authenticated user can execute a specific proposal
 * Browser-safe wrapper around ProposalService.canExecuteProposal
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  userAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface CanExecuteResponse {
  success: boolean;
  data?: {
    canExecute: boolean;
    reason?: string;
  };
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<CanExecuteResponse>> {
  try {
    // Get user auth from middleware headers
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal ID required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Get proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if proposal is in a state that can be executed
    if (proposal.status !== 'passed') {
      return NextResponse.json({
        success: true,
        data: {
          canExecute: false,
          reason: 'Proposal has not passed',
        },
      });
    }

    // Check if already executed
    if (proposal.executedAt) {
      return NextResponse.json({
        success: true,
        data: {
          canExecute: false,
          reason: 'Proposal has already been executed',
        },
      });
    }

    // Check if user is a member of the DAO with admin privileges
    const member = await daoMemberAdminRepository.findByDaoAndUser(
      proposal.daoId,
      userId
    );

    if (!member) {
      return NextResponse.json({
        success: true,
        data: {
          canExecute: false,
          reason: 'User is not a member of this DAO',
        },
      });
    }

    // Check if member has admin or owner role
    const canExecute = member.role === 'admin';

    // Add caching headers - 30 sec cache (proposal status changes infrequently)
    return NextResponse.json(
      {
        success: true,
        data: {
          canExecute,
          reason: canExecute
            ? undefined
            : 'User does not have admin privileges',
        },
      },
      {
        headers: {
          'Cache-Control': 'private, max-age=30, stale-while-revalidate=10',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error checking execution permission',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/can-execute', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to check execution permission',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
