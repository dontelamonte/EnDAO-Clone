/**
 * API Route: Request Changes to Proposal (Admin Action)
 * Sends proposal back to draft with change request reason
 * POST /api/proposals/[proposalId]/request-changes
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { proposalWarmUpNotificationService } from '@/lib/services/proposal/notifications/proposal-warmup-notification.service';
import { DAOMembershipService } from '@/lib/services/dao/dao-membership.service';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    const { proposalId } = await params;
    const body = await request.json();
    const { reason } = body;

    if (!reason || reason.trim() === '') {
      return NextResponse.json(
        { error: 'Change reason is required' },
        { status: 400 }
      );
    }

    // Get auth context from middleware
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const proposal = await proposalAdminRepository.findById(proposalId);

    if (!proposal) {
      return NextResponse.json(
        { error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Verify proposal is under review
    if (proposal.status !== 'under_review') {
      return NextResponse.json(
        { error: 'Proposal is not under review' },
        { status: 400 }
      );
    }

    // Verify user is admin
    const membershipService = DAOMembershipService.getInstance();
    const isAdmin = await membershipService.verifyAdminPermission(
      proposal.daoId,
      authContext.uid
    );

    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Only admins can request changes' },
        { status: 403 }
      );
    }

    // Update proposal to draft status with change request
    const now = new Date().toISOString();
    await proposalAdminRepository.update(proposalId, {
      status: 'draft',
      // Store change request info in metadata JSONB field
      metadata: {
        ...proposal.metadata,
        changesRequestedBy: authContext.uid,
        changesRequestedAt: now,
        changesRequestedReason: reason,
      },
    });

    // Get DAO name for notification
    const dao = await daoAdminRepository.findById(proposal.daoId);
    const daoName = dao?.name || 'Your DAO';

    // Notify proposal creator
    try {
      await proposalWarmUpNotificationService.notifyCreatorOfChangeRequest(
        proposal,
        daoName,
        authContext.uid,
        reason
      );
    } catch (notificationError) {
      logger.error(
        'Failed to send change request notification',
        notificationError instanceof Error
          ? notificationError
          : new Error(String(notificationError)),
        {
          url: '/api/proposals/[proposalId]/request-changes',
          method: 'POST',
          proposalId,
        }
      );
      // Don't fail the change request due to notification error
    }

    return NextResponse.json({
      success: true,
      message: 'Changes requested, proposal returned to draft',
      proposal: {
        id: proposalId,
        status: 'draft',
        changesRequestedReason: reason,
      },
    });
  } catch (error) {
    logger.error(
      'Error requesting changes',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/request-changes', method: 'POST' }
    );
    return NextResponse.json(
      { error: 'Failed to request changes' },
      { status: 500 }
    );
  }
}
