/**
 * Proposal Permissions API Route
 *
 * GET - Check all permissions for a user on a specific proposal
 * Consolidates can-vote and can-execute checks into a single endpoint
 * Reduces API round-trips when both permissions are needed
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  userAdminRepository,
  daoMemberAdminRepository,
  voteAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export type VoteStatus =
  | 'eligible'
  | 'already_voted'
  | 'not_member'
  | 'voting_ended'
  | 'under_review'
  | 'draft';

export type UserVoteOption = 'for' | 'against' | 'abstain';

interface PermissionsResponse {
  success: boolean;
  data?: {
    vote: {
      canVote: boolean;
      reason: string | null;
      voteStatus: VoteStatus;
      userVote?: UserVoteOption;
      allowChangeVote?: boolean;
    };
    execute: {
      canExecute: boolean;
      reason?: string;
    };
  };
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<PermissionsResponse>> {
  try {
    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      // User not found in database - can't be a member
      return NextResponse.json({
        success: true,
        data: {
          vote: {
            canVote: false,
            reason: 'You must be a DAO member to vote',
            voteStatus: 'not_member',
          },
          execute: {
            canExecute: false,
            reason: 'User not found',
          },
        },
      });
    }

    const userId = supabaseUser.id;

    // Get proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Get membership info
    const member = await daoMemberAdminRepository.findByDaoAndUser(
      proposal.daoId,
      userId
    );

    // Check vote permission
    const votePermission = await checkVotePermission(proposal, userId, member);

    // Check execute permission
    const executePermission = checkExecutePermission(proposal, member);

    // Add caching headers - 15 sec cache (permissions are time-sensitive)
    return NextResponse.json(
      {
        success: true,
        data: {
          vote: votePermission,
          execute: executePermission,
        },
      },
      {
        headers: {
          'Cache-Control': 'private, max-age=15, stale-while-revalidate=5',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error checking permissions',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/permissions', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : 'Failed to check permissions',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

interface Proposal {
  id: string;
  daoId: string;
  status: string;
  votingEndTime?: string | null;
  executedAt?: string | null;
  votingConfig?: {
    allowChangeVote?: boolean;
  } | null;
}

interface Member {
  id: string;
  role: string;
  status: string;
}

async function checkVotePermission(
  proposal: Proposal,
  userId: string,
  member: Member | null
): Promise<{
  canVote: boolean;
  reason: string | null;
  voteStatus: VoteStatus;
  userVote?: UserVoteOption;
  allowChangeVote?: boolean;
}> {
  // Check proposal status
  if (proposal.status === 'draft') {
    return {
      canVote: false,
      reason: 'This proposal is still in draft mode',
      voteStatus: 'draft',
    };
  }

  if (proposal.status === 'under_review') {
    return {
      canVote: false,
      reason: 'This proposal is under review by admins',
      voteStatus: 'under_review',
    };
  }

  // Check if voting period ended
  const now = new Date();
  const endTime = proposal.votingEndTime
    ? new Date(proposal.votingEndTime)
    : null;

  if (endTime && now > endTime) {
    return {
      canVote: false,
      reason: 'Voting period has ended',
      voteStatus: 'voting_ended',
    };
  }

  // Check DAO membership
  if (!member || member.status !== 'active') {
    return {
      canVote: false,
      reason: 'You must be a DAO member to vote',
      voteStatus: 'not_member',
    };
  }

  // Check if user already voted
  const existingVotes = await voteAdminRepository.findMany({
    filters: [
      { field: 'proposalId', operator: '==', value: proposal.id },
      { field: 'userId', operator: '==', value: userId },
    ],
    limit: 1,
  });

  if (existingVotes.length > 0) {
    const userVote = existingVotes[0];
    const allowChangeVote = proposal.votingConfig?.allowChangeVote ?? false;

    return {
      canVote: allowChangeVote,
      reason: allowChangeVote
        ? 'You can change your vote'
        : 'You have already voted on this proposal',
      voteStatus: allowChangeVote ? 'eligible' : 'already_voted',
      userVote: userVote.vote as UserVoteOption,
      allowChangeVote,
    };
  }

  // All checks passed - user is eligible
  return {
    canVote: true,
    reason: null,
    voteStatus: 'eligible',
  };
}

function checkExecutePermission(
  proposal: Proposal,
  member: Member | null
): { canExecute: boolean; reason?: string } {
  // Check if proposal is in a state that can be executed
  if (proposal.status !== 'passed') {
    return {
      canExecute: false,
      reason: 'Proposal has not passed',
    };
  }

  // Check if already executed
  if (proposal.executedAt) {
    return {
      canExecute: false,
      reason: 'Proposal has already been executed',
    };
  }

  // Check if user is a member
  if (!member) {
    return {
      canExecute: false,
      reason: 'User is not a member of this DAO',
    };
  }

  // Check if member has admin or owner role
  const canExecute = member.role === 'admin';

  return {
    canExecute,
    reason: canExecute ? undefined : 'User does not have admin privileges',
  };
}
