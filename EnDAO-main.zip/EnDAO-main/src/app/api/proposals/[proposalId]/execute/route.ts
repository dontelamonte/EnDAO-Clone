/**
 * Execute Proposal API Route
 *
 * POST - Execute a passed proposal
 * Browser-safe wrapper around ProposalService.executeProposal
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  userAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import { ExecutionEngineService } from '@/lib/services/proposal/execution/execution-engine.service';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';

interface ExecuteResponse {
  success: boolean;
  data?: {
    message: string;
  };
  error?: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<ExecuteResponse>> {
  try {
    // Apply rate limiting for critical operations (5 per minute per IP)
    const rateLimitResult = await rateLimiters.critical(request);
    if (rateLimitResult) {
      return rateLimitResult as NextResponse<ExecuteResponse>; // Rate limit exceeded, return 429 response
    }

    // Get user auth from middleware headers
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    const uid = request.headers.get('x-auth-uid');

    if (!privyId || !uid) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Get proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Check if proposal is in a state that can be executed
    if (proposal.status !== 'passed') {
      return NextResponse.json(
        { success: false, error: 'Only passed proposals can be executed' },
        { status: 400 }
      );
    }

    // Check if already executed
    if (proposal.executedAt) {
      return NextResponse.json(
        { success: false, error: 'Proposal has already been executed' },
        { status: 400 }
      );
    }

    // Check if user is a member of the DAO with admin privileges
    const member = await daoMemberAdminRepository.findByDaoAndUser(
      proposal.daoId,
      userId
    );

    if (!member || (member.role !== 'admin')) {
      return NextResponse.json(
        {
          success: false,
          error: 'User does not have admin privileges to execute proposals',
        },
        { status: 403 }
      );
    }

    // Execute the proposal using the execution service
    const executionService = ExecutionEngineService.getInstance();
    const result = await executionService.executeProposal(proposalId, userId, {
      uid,
      privyUserId: privyId,
    });

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to execute proposal' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        message: result.data?.message || 'Proposal executed successfully',
      },
    });
  } catch (error) {
    logger.error(
      '[Execute Proposal API] Error executing proposal',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to execute proposal' },
      { status: 500 }
    );
  }
}
