/**
 * User Vote API Route
 * GET - Fetches current user's vote on a proposal
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  voteAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface UserVoteResponse {
  success: boolean;
  data?: {
    id: string;
    option: string;
    userId: string;
    proposalId: string;
  } | null;
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<UserVoteResponse>> {
  try {
    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json({
        success: true,
        data: null,
      });
    }

    // Find user's vote on this proposal
    const votes = await voteAdminRepository.findMany({
      filters: [
        { field: 'proposalId', operator: '==', value: proposalId },
        { field: 'userId', operator: '==', value: supabaseUser.id },
      ],
      limit: 1,
    });

    if (votes.length === 0) {
      return NextResponse.json({
        success: true,
        data: null,
      });
    }

    const vote = votes[0];
    // Add caching - 15 sec cache (vote status is time-sensitive during voting)
    return NextResponse.json(
      {
        success: true,
        data: {
          id: vote.id,
          option: vote.vote,
          userId: vote.userId,
          proposalId: vote.proposalId,
        },
      },
      {
        headers: {
          'Cache-Control': 'private, max-age=15, stale-while-revalidate=5',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching user vote',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/user-vote', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch user vote',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}
