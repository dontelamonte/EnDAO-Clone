import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  voteAdminRepository,
} from '@/lib/data/repositories/supabase';
import { VoteSignatureService } from '@/lib/services/voting/vote-signature.service';
import type { VoteMessage } from '@endao/shared-types';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/proposals/[proposalId]/votes/verify
 *
 * Public endpoint for vote signature verification and audit.
 * No authentication required - anyone can verify vote integrity.
 *
 * Returns detailed verification results for all signed votes on a proposal.
 */
export async function GET(
  request: NextRequest,
  context: { params: Promise<{ proposalId: string }> }
) {
  try {
    const { proposalId } = await context.params;

    // Get proposal details
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Get all votes for this proposal
    const votes = await voteAdminRepository.findByProposal(proposalId);

    // Separate signed and unsigned votes
    const signedVotes = votes.filter(
      (vote) => vote.signature && vote.walletAddress
    );
    const unsignedVotes = votes.filter(
      (vote) => !vote.signature || !vote.walletAddress
    );

    // Verify each signed vote
    const verificationResults = await Promise.all(
      signedVotes.map(async (vote) => {
        let signatureValid = false;
        let errorMessage: string | undefined;

        try {
          // Check if we have the required nonce for verification
          if (!vote.signatureNonce) {
            // Legacy vote without stored nonce - cannot fully verify
            // We can only confirm the signature format is valid
            signatureValid = false;
            errorMessage = 'Legacy vote: nonce not stored for verification';
          } else {
            // Reconstruct vote message for verification using stored data
            const signedTimestamp = vote.signedAt
              ? Math.floor(new Date(vote.signedAt).getTime() / 1000)
              : Math.floor(new Date(vote.createdAt).getTime() / 1000);

            const voteMessage: VoteMessage = {
              proposalId: vote.proposalId,
              daoId: proposal.daoId,
              choice: vote.vote, // Use 'vote' field not 'choice'
              voter: vote.walletAddress!,
              strength: vote.voteStrength || 1,
              timestamp: signedTimestamp,
              nonce: vote.signatureNonce,
            };

            // Verify signature using the appropriate method
            const signatureType = (vote.signatureType || 'eip712') as
              | 'eip712'
              | 'personal_sign';
            signatureValid = VoteSignatureService.verifySignature(
              vote.signature!,
              voteMessage,
              vote.walletAddress!,
              signatureType
            );
          }
        } catch (error) {
          signatureValid = false;
          errorMessage =
            error instanceof Error ? error.message : 'Verification failed';
        }

        return {
          id: vote.id,
          voter: vote.walletAddress!,
          choice: vote.vote,
          strength: vote.voteStrength || 1,
          signedAt: vote.signedAt || vote.createdAt,
          signatureType: vote.signatureType || 'eip712',
          signatureValid,
          signaturePrefix: vote.signature!.substring(0, 20) + '...',
          ...(errorMessage && { error: errorMessage }),
        };
      })
    );

    // Calculate summary statistics
    const validSignatures = verificationResults.filter(
      (r) => r.signatureValid
    ).length;
    const invalidSignatures = verificationResults.filter(
      (r) => !r.signatureValid
    ).length;

    return NextResponse.json({
      proposalId: proposal.id,
      proposalTitle: proposal.title,
      daoId: proposal.daoId,
      summary: {
        totalVotes: votes.length,
        signedVotes: signedVotes.length,
        unsignedVotes: unsignedVotes.length,
        validSignatures,
        invalidSignatures,
        verificationRate:
          signedVotes.length > 0
            ? ((validSignatures / signedVotes.length) * 100).toFixed(1) + '%'
            : 'N/A',
      },
      votes: verificationResults,
      verifiedAt: new Date().toISOString(),
    });
  } catch (error) {
    logger.error(
      'Vote verification error',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/[proposalId]/votes/verify', method: 'GET' }
    );
    return NextResponse.json(
      { error: 'Failed to verify votes' },
      { status: 500 }
    );
  }
}
