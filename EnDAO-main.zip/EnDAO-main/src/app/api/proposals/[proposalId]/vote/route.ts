/**
 * Vote Submission API Route
 *
 * Server-side endpoint for casting or changing votes on proposals.
 * Browser-safe wrapper around VotingEngineService.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoMemberAdminRepository,
  proposalAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { VotingEngineService } from '@/lib/services/proposal/voting/voting-engine.service';
import { VoteSignatureService } from '@/lib/services/voting/vote-signature.service';
import { WalletVerificationService } from '@/lib/services/user/wallet-verification.service';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import type { VoteMessage } from '@endao/shared-types';

interface VoteRequestBody {
  option: 'for' | 'against' | 'abstain';
  reason?: string;
  // Signature fields are optional for off-chain voting
  // When provided, votes are cryptographically verified
  signature?: string;
  walletAddress?: string;
  signatureType?: 'eip712' | 'personal_sign';
  voteMessage?: VoteMessage;
  confidence?: number;
  rankedOptions?: string[];
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    // Apply rate limiting for voting operations (10 votes per minute per IP)
    const rateLimitResult = await rateLimiters.voting(request);
    if (rateLimitResult) {
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    // Get user auth from middleware headers
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Parse request body
    const body: VoteRequestBody = await request.json();

    if (!body.option || !['for', 'against', 'abstain'].includes(body.option)) {
      return NextResponse.json(
        {
          success: false,
          error: 'Valid vote option required (for, against, abstain)',
        },
        { status: 400 }
      );
    }

    // Signature fields are optional - when provided, votes are verified
    const hasSignature =
      body.signature && body.walletAddress && body.voteMessage;

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Variables for signed votes (optional)
    let messageHash: string | undefined;

    // Only validate signatures when provided (signed voting)
    if (hasSignature) {
      // Validate vote message structure
      const messageValidation = VoteSignatureService.validateVoteMessage(
        body.voteMessage!,
        proposalId
      );
      if (!messageValidation.isValid) {
        return NextResponse.json(
          {
            success: false,
            error: messageValidation.error || 'Invalid vote message',
          },
          { status: 400 }
        );
      }

      // Verify wallet ownership and ensure it's linked to the user
      const isOwned = await WalletVerificationService.verifyWalletOwnership(
        userId,
        body.walletAddress!
      );

      if (!isOwned) {
        // Wallet not linked - attempt to link it
        const linkResult = await WalletVerificationService.ensureWalletLinked(
          userId,
          body.walletAddress!
        );
        if (!linkResult) {
          return NextResponse.json(
            { success: false, error: 'Wallet ownership verification failed' },
            { status: 400 }
          );
        }
      }

      // Verify the signature (synchronous operation)
      const signatureValid = VoteSignatureService.verifySignature(
        body.signature!,
        body.voteMessage!,
        body.walletAddress!,
        body.signatureType!
      );

      if (!signatureValid) {
        return NextResponse.json(
          { success: false, error: 'Invalid signature' },
          { status: 400 }
        );
      }

      // Generate message hash for storage
      messageHash =
        body.signatureType === 'eip712'
          ? VoteSignatureService.hashVoteMessageEIP712(body.voteMessage!)
          : VoteSignatureService.hashVoteMessage(body.voteMessage!);
    }

    // Get proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Check if proposal is still open for voting
    const now = new Date();
    const endTime = proposal.endTime ? new Date(proposal.endTime) : null;
    if (proposal.status !== 'active' || (endTime && now > endTime)) {
      return NextResponse.json(
        {
          success: false,
          error: 'Voting is closed for this proposal',
        },
        { status: 400 }
      );
    }

    // Get member data and verify membership
    const member = await daoMemberAdminRepository.findByDaoAndUser(
      proposal.daoId,
      userId
    );
    if (!member || member.status !== 'active') {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be a member of this DAO to vote',
        },
        { status: 403 }
      );
    }

    const memberData = {
      id: member.id,
      votingWeight: 1, // Default voting weight (schema doesn't track this yet)
      tokenBalance: 0, // Default token balance (schema doesn't track this yet)
    };

    // Cast or change vote using the service
    const votingService = VotingEngineService.getInstance();
    const result = await votingService.castOrChangeVote(
      proposalId,
      userId,
      {
        option: body.option,
        reason: body.reason,
        confidence: body.confidence,
        rankedOptions: body.rankedOptions,
        // Signature fields only included when signature was provided
        signature: hasSignature ? body.signature : undefined,
        walletAddress: hasSignature ? body.walletAddress : undefined,
        signatureType: hasSignature ? body.signatureType : undefined,
        messageHash: hasSignature ? messageHash : undefined,
        signatureNonce: hasSignature ? body.voteMessage!.nonce : undefined,
        signedAt: hasSignature
          ? new Date(body.voteMessage!.timestamp * 1000)
          : undefined,
      },
      // Cast through unknown to expected type - repository returns compatible shape
      proposal as unknown as Parameters<
        typeof votingService.castOrChangeVote
      >[3],
      memberData
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to submit vote' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[Vote API] Error submitting vote', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to submit vote' },
      { status: 500 }
    );
  }
}
