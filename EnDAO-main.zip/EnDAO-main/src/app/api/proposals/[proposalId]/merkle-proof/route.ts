/**
 * Merkle Proof API Route
 *
 * POST - Generate Merkle proof for a voter's participation in a proposal
 * Browser-safe wrapper around MerkleProofService.generateProof
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { MerkleProofService } from '@/lib/services/proposal/voting/merkle-proof.service';
import {
  proposalAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';

/**
 * Request validation schema
 */
const requestSchema = z.object({
  userId: z.string().uuid('Invalid user ID format'),
});

/**
 * Response type for Merkle proof generation
 */
interface MerkleProofResponse {
  success: boolean;
  data?: {
    proof: string[];
    leaf: string;
    root: string;
    index: number;
    vote: {
      userId: string;
      choice: string;
      votingPower: number;
    };
  };
  error?: string;
}

/**
 * POST /api/proposals/[proposalId]/merkle-proof
 *
 * Generate a Merkle proof for a specific voter's participation
 * in a finalized proposal.
 *
 * @param proposalId - The proposal ID from the URL
 * @param userId - The user ID in the request body
 * @returns Merkle proof data including proof array, leaf hash, root, and vote details
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<MerkleProofResponse>> {
  try {
    // Apply rate limiting for proof generation (10 per minute per IP)
    const rateLimitResult = await rateLimiters.api(request);
    if (rateLimitResult) {
      return rateLimitResult as NextResponse<MerkleProofResponse>;
    }

    // Get user auth from middleware headers
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    const uid = request.headers.get('x-auth-uid');

    if (!privyId || !uid) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validationResult = requestSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
        },
        { status: 400 }
      );
    }

    const { userId } = validationResult.data;

    // Verify the proposal exists
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Check if Merkle tree has been built for this proposal
    if (!proposal.merkleTreeData) {
      return NextResponse.json(
        {
          success: false,
          error:
            'Merkle tree not yet built for this proposal. Trees are built when voting ends.',
        },
        { status: 400 }
      );
    }

    // Generate the Merkle proof
    const merkleProofService = MerkleProofService.getInstance();
    const result = await merkleProofService.generateProof(proposalId, userId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to generate Merkle proof',
        },
        { status: 400 }
      );
    }

    // Convert choice number to string for API response
    const choiceMap: Record<number, string> = {
      0: 'abstain',
      1: 'for',
      2: 'against',
    };

    return NextResponse.json({
      success: true,
      data: {
        proof: result.data.proof,
        leaf: result.data.leaf,
        root: result.data.root,
        index: result.data.index,
        vote: {
          userId: result.data.vote.userId,
          choice: choiceMap[result.data.vote.choice] || 'unknown',
          votingPower: Number(result.data.vote.votingPower),
        },
      },
    });
  } catch (error) {
    logger.error(
      '[Merkle Proof API] Error generating proof',
      error as Error,
      {
        url: '/api/proposals/[proposalId]/merkle-proof',
        method: 'POST',
      }
    );

    // Check for specific error types
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request format',
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: 'Failed to generate Merkle proof' },
      { status: 500 }
    );
  }
}
