/**
 * API Route: Auto-Finalize Proposals After Voting Ends
 * Should be called by a cron job or scheduled task every hour
 * POST /api/proposals/auto-finalize
 *
 * This handles transitioning proposals from 'active' to 'passed'/'rejected'/'expired'
 * when the voting period ends.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  proposalAdminRepository,
} from '@/lib/data/repositories';
import { proposalFinalizationNotificationService } from '@/lib/services/proposal/notifications/proposal-finalization-notification.service';
import { logger } from '@/lib/services/logger.service';

// Type for reading existing vote results from the proposal
interface ExistingVoteResults {
  forVotes?: number;
  againstVotes?: number;
  abstainVotes?: number;
  totalVotes?: number;
}

export async function POST(request: NextRequest) {
  try {
    // Verify request is from authorized source (cron job, etc.)
    const authHeader = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (!expectedSecret) {
      console.error('CRON_SECRET not configured');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    if (authHeader !== `Bearer ${expectedSecret}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const now = new Date();

    // Query for active proposals where voting has ended
    const allActiveProposals = await proposalAdminRepository.findMany({
      filters: [{ field: 'status', operator: '==', value: 'active' }],
    });

    // Filter in-memory for proposals where voting period has ended
    const proposalsToFinalize = allActiveProposals.filter((p) => {
      const endTime = p.votingEndTime || p.endTime;
      if (!endTime) return false;
      const votingEnds = new Date(endTime);
      return votingEnds <= now;
    });

    const finalizedProposals: Array<{
      proposalId: string;
      outcome: string;
    }> = [];
    const skippedProposals: Array<{ proposalId: string; reason: string }> = [];
    const errors: Array<{ proposalId: string; error: string }> = [];

    // Finalize each proposal
    for (const proposal of proposalsToFinalize) {
      try {
        // Get DAO for voting config
        const dao = await daoAdminRepository.findById(proposal.daoId);

        if (!dao) {
          skippedProposals.push({
            proposalId: proposal.id,
            reason: 'DAO not found',
          });
          continue;
        }

        // Get voting config from proposal or DAO defaults
        // Note: voting config fields are directly on dao.settings, not nested under .voting
        const votingConfig = proposal.votingConfig || dao.settings || {};
        const quorumPercentage = votingConfig.quorumPercentage ?? 20;
        const passThreshold = votingConfig.passThreshold ?? 50;

        // Get vote counts from proposal result
        const existingResult = (proposal.result as ExistingVoteResults) || {};
        const forVotes = existingResult.forVotes || 0;
        const againstVotes = existingResult.againstVotes || 0;
        const abstainVotes = existingResult.abstainVotes || 0;
        const totalVotes = forVotes + againstVotes + abstainVotes;

        // Calculate participation rate
        const membersResult =
          await daoMemberAdminRepository.findMembersPaginated(proposal.daoId, {
            activeOnly: true,
            limit: 1,
          });
        const totalMembers = membersResult.total || 1;
        const participationRate = (totalVotes / totalMembers) * 100;

        // Determine outcome
        let outcome: 'passed' | 'failed' | 'expired';

        if (participationRate < quorumPercentage) {
          // Quorum not met - proposal expires
          outcome = 'expired';
          logger.info('Proposal expired due to insufficient quorum', {
            proposalId: proposal.id,
            participationRate,
            quorumPercentage,
            totalVotes,
            totalMembers,
            component: 'auto-finalize',
          });
        } else {
          // Quorum met - check pass threshold
          // Pass threshold is calculated as percentage of for/(for+against)
          // Abstains don't count against
          const votesForThreshold = forVotes + againstVotes;
          const passPercentage =
            votesForThreshold > 0 ? (forVotes / votesForThreshold) * 100 : 0;

          if (passPercentage >= passThreshold) {
            outcome = 'passed';
          } else {
            outcome = 'failed';
          }

          logger.info('Proposal finalized with voting results', {
            proposalId: proposal.id,
            outcome,
            forVotes,
            againstVotes,
            abstainVotes,
            passPercentage,
            passThreshold,
            component: 'auto-finalize',
          });
        }

        // Calculate winning percentage (for votes out of for+against)
        const votesForThresholdCalc = forVotes + againstVotes;
        const winningPercentage =
          votesForThresholdCalc > 0
            ? (forVotes / votesForThresholdCalc) * 100
            : 0;

        // Update proposal status with proper ProposalResult structure
        await proposalAdminRepository.update(proposal.id, {
          status: outcome,
          result: {
            totalVotes,
            totalEligibleVoters: totalMembers,
            quorumReached: participationRate >= quorumPercentage,
            passed: outcome === 'passed',
            forVotes,
            againstVotes,
            abstainVotes,
            participationRate,
            quorumPercentage,
            winningPercentage,
          },
          metadata: {
            ...proposal.metadata,
            customFields: {
              ...proposal.metadata?.customFields,
              autoFinalizedAt: now.toISOString(),
            },
          },
        });

        finalizedProposals.push({
          proposalId: proposal.id,
          outcome,
        });

        // Send finalization notifications (non-blocking)
        try {
          await proposalFinalizationNotificationService.sendFinalizationNotifications(
            proposal.id
          );
        } catch (notificationError) {
          logger.error(
            'Failed to send finalization notifications',
            notificationError as Error,
            {
              proposalId: proposal.id,
              component: 'auto-finalize',
            }
          );
          // Continue with other proposals even if notification fails
        }
      } catch (error) {
        logger.error(
          `Failed to finalize proposal ${proposal.id}`,
          error as Error,
          {
            component: 'auto-finalize',
          }
        );
        errors.push({
          proposalId: proposal.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    // Summary logging
    logger.info('Auto-finalize job completed', {
      finalized: finalizedProposals.length,
      skipped: skippedProposals.length,
      errors: errors.length,
      component: 'auto-finalize',
    });

    return NextResponse.json({
      success: true,
      message: `Finalized ${finalizedProposals.length} proposal(s), skipped ${skippedProposals.length}`,
      finalized: finalizedProposals,
      skipped: skippedProposals.length > 0 ? skippedProposals : undefined,
      errors: errors.length > 0 ? errors : undefined,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error(
      'Error in auto-finalize',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/auto-finalize', method: 'POST' }
    );
    return NextResponse.json(
      { error: 'Failed to auto-finalize proposals' },
      { status: 500 }
    );
  }
}

// Also support GET for health checks
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Auto-finalize endpoint is available',
    timestamp: new Date().toISOString(),
  });
}
