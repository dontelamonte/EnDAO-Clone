/**
 * Proposal API Route Validation Tests
 * Tests the actual validation schemas for /api/proposals/* endpoints
 *
 * This file tests real code from:
 * - @/lib/validations/api (proposalCreateSchema, proposalVoteSchema, proposalUpdateSchema)
 * - @/lib/validations/common (commonValidations)
 */

import {
  proposalCreateSchema,
  proposalVoteSchema,
  proposalUpdateSchema,
  commentCreateSchema,
  commentUpdateSchema,
  createSanitizedString,
  documentId,
} from '@/lib/validations/api';
import { commonValidations } from '@/lib/validations/common';

describe('Proposal Validation Schemas', () => {
  describe('proposalCreateSchema', () => {
    const validProposal = {
      title: 'Proposal for DAO Treasury Allocation',
      description:
        'This is a detailed proposal describing how we should allocate treasury funds for the upcoming quarter.',
      type: 'funding' as const,
      daoId: 'dao-123',
      votingDuration: 7,
      options: ['Approve allocation', 'Reject allocation'],
      requiredQuorum: 0.2,
    };

    describe('Required Fields', () => {
      it('should accept valid proposal', () => {
        expect(() => proposalCreateSchema.parse(validProposal)).not.toThrow();
      });

      it('should require title', () => {
        const { title: _, ...withoutTitle } = validProposal;
        expect(() => proposalCreateSchema.parse(withoutTitle)).toThrow();
      });

      it('should require description', () => {
        const { description: _, ...withoutDescription } = validProposal;
        expect(() => proposalCreateSchema.parse(withoutDescription)).toThrow();
      });

      it('should require type', () => {
        const { type: _, ...withoutType } = validProposal;
        expect(() => proposalCreateSchema.parse(withoutType)).toThrow();
      });

      it('should require daoId', () => {
        const { daoId: _, ...withoutDaoId } = validProposal;
        expect(() => proposalCreateSchema.parse(withoutDaoId)).toThrow();
      });

      it('should require votingDuration', () => {
        const { votingDuration: _, ...withoutVotingDuration } = validProposal;
        expect(() =>
          proposalCreateSchema.parse(withoutVotingDuration)
        ).toThrow();
      });

      it('should require options', () => {
        const { options: _, ...withoutOptions } = validProposal;
        expect(() => proposalCreateSchema.parse(withoutOptions)).toThrow();
      });
    });

    describe('Title Validation', () => {
      it('should require title at least 5 characters', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, title: 'abcd' })
        ).toThrow();
      });

      it('should accept title with exactly 5 characters', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, title: 'abcde' })
        ).not.toThrow();
      });

      it('should reject title over 200 characters', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            title: 'a'.repeat(201),
          })
        ).toThrow();
      });

      it('should reject XSS in title', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            title: '<script>alert(1)</script>',
          })
        ).toThrow();
      });
    });

    describe('Description Validation', () => {
      it('should require description at least 20 characters', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            description: 'Too short',
          })
        ).toThrow();
      });

      it('should accept description at minimum length', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            description: '12345678901234567890',
          })
        ).not.toThrow();
      });

      it('should reject description over 10000 characters', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            description: 'a'.repeat(10001),
          })
        ).toThrow();
      });

      it('should reject SQL injection in description', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            description: "'; DROP TABLE proposals; -- more text here to pass",
          })
        ).toThrow();
      });
    });

    describe('Type Validation', () => {
      it('should accept governance type', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, type: 'governance' })
        ).not.toThrow();
      });

      it('should accept funding type', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, type: 'funding' })
        ).not.toThrow();
      });

      it('should accept membership type', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, type: 'membership' })
        ).not.toThrow();
      });

      it('should accept other type', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, type: 'other' })
        ).not.toThrow();
      });

      it('should reject invalid type', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, type: 'invalid' })
        ).toThrow();
      });
    });

    describe('Voting Duration Validation', () => {
      it('should accept duration of 1 day', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, votingDuration: 1 })
        ).not.toThrow();
      });

      it('should accept duration of 30 days', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, votingDuration: 30 })
        ).not.toThrow();
      });

      it('should reject duration less than 1 day', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, votingDuration: 0 })
        ).toThrow();
      });

      it('should reject duration over 30 days', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, votingDuration: 31 })
        ).toThrow();
      });

      it('should require integer duration', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, votingDuration: 7.5 })
        ).toThrow();
      });
    });

    describe('Options Validation', () => {
      it('should require at least 2 options', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            options: ['Only one'],
          })
        ).toThrow();
      });

      it('should accept exactly 2 options', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            options: ['Yes', 'No'],
          })
        ).not.toThrow();
      });

      it('should accept up to 10 options', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            options: Array(10).fill('Option'),
          })
        ).not.toThrow();
      });

      it('should reject more than 10 options', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            options: Array(11).fill('Option'),
          })
        ).toThrow();
      });

      it('should reject XSS in options', () => {
        expect(() =>
          proposalCreateSchema.parse({
            ...validProposal,
            options: ['<script>alert(1)</script>', 'Safe option'],
          })
        ).toThrow();
      });
    });

    describe('Required Quorum Validation', () => {
      it('should accept quorum of 0', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, requiredQuorum: 0 })
        ).not.toThrow();
      });

      it('should accept quorum of 1 (100%)', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, requiredQuorum: 1 })
        ).not.toThrow();
      });

      it('should accept quorum of 0.5 (50%)', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, requiredQuorum: 0.5 })
        ).not.toThrow();
      });

      it('should reject quorum over 1', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, requiredQuorum: 1.5 })
        ).toThrow();
      });

      it('should reject negative quorum', () => {
        expect(() =>
          proposalCreateSchema.parse({ ...validProposal, requiredQuorum: -0.1 })
        ).toThrow();
      });

      it('should default quorum to 0.1 if not provided', () => {
        const { requiredQuorum: _, ...withoutQuorum } = validProposal;
        const result = proposalCreateSchema.parse(withoutQuorum);
        expect(result.requiredQuorum).toBe(0.1);
      });
    });

    describe('Attachments Validation', () => {
      it('should accept valid attachments', () => {
        const withAttachments = {
          ...validProposal,
          attachments: [
            {
              name: 'document.pdf',
              url: 'https://example.com/doc.pdf',
              size: 1024,
              type: 'application/pdf',
            },
          ],
        };
        expect(() => proposalCreateSchema.parse(withAttachments)).not.toThrow();
      });

      it('should accept empty attachments array', () => {
        const withEmptyAttachments = {
          ...validProposal,
          attachments: [],
        };
        expect(() =>
          proposalCreateSchema.parse(withEmptyAttachments)
        ).not.toThrow();
      });

      it('should reject more than 5 attachments', () => {
        const tooManyAttachments = {
          ...validProposal,
          attachments: Array(6).fill({
            name: 'doc.pdf',
            url: 'https://example.com/doc.pdf',
            size: 1024,
            type: 'application/pdf',
          }),
        };
        expect(() => proposalCreateSchema.parse(tooManyAttachments)).toThrow();
      });

      it('should require valid URL for attachment', () => {
        const invalidUrl = {
          ...validProposal,
          attachments: [
            {
              name: 'doc.pdf',
              url: 'not-a-url',
              size: 1024,
              type: 'application/pdf',
            },
          ],
        };
        expect(() => proposalCreateSchema.parse(invalidUrl)).toThrow();
      });
    });
  });

  describe('proposalVoteSchema', () => {
    const validVote = {
      proposalId: 'prop-123',
      optionIndex: 0,
    };

    it('should accept valid vote', () => {
      expect(() => proposalVoteSchema.parse(validVote)).not.toThrow();
    });

    it('should require proposalId', () => {
      const { proposalId: _, ...withoutProposalId } = validVote;
      expect(() => proposalVoteSchema.parse(withoutProposalId)).toThrow();
    });

    it('should require optionIndex', () => {
      const { optionIndex: _, ...withoutOptionIndex } = validVote;
      expect(() => proposalVoteSchema.parse(withoutOptionIndex)).toThrow();
    });

    it('should accept optionIndex 0-9', () => {
      for (let i = 0; i <= 9; i++) {
        expect(() =>
          proposalVoteSchema.parse({ ...validVote, optionIndex: i })
        ).not.toThrow();
      }
    });

    it('should reject optionIndex over 9', () => {
      expect(() =>
        proposalVoteSchema.parse({ ...validVote, optionIndex: 10 })
      ).toThrow();
    });

    it('should reject negative optionIndex', () => {
      expect(() =>
        proposalVoteSchema.parse({ ...validVote, optionIndex: -1 })
      ).toThrow();
    });

    it('should require integer optionIndex', () => {
      expect(() =>
        proposalVoteSchema.parse({ ...validVote, optionIndex: 1.5 })
      ).toThrow();
    });

    it('should accept optional walletAddress', () => {
      const voteWithWallet = {
        ...validVote,
        walletAddress: '0x1234567890123456789012345678901234567890',
      };
      expect(() => proposalVoteSchema.parse(voteWithWallet)).not.toThrow();
    });

    it('should reject invalid walletAddress', () => {
      const invalidWallet = {
        ...validVote,
        walletAddress: 'not-valid',
      };
      expect(() => proposalVoteSchema.parse(invalidWallet)).toThrow();
    });

    it('should accept optional comment', () => {
      const voteWithComment = {
        ...validVote,
        comment: 'I support this proposal because...',
      };
      expect(() => proposalVoteSchema.parse(voteWithComment)).not.toThrow();
    });

    it('should reject comment over 500 characters', () => {
      const longComment = {
        ...validVote,
        comment: 'a'.repeat(501),
      };
      expect(() => proposalVoteSchema.parse(longComment)).toThrow();
    });
  });

  describe('proposalUpdateSchema', () => {
    it('should accept valid update', () => {
      const validUpdate = {
        proposalId: 'prop-123',
        updates: {
          title: 'Updated Proposal Title',
        },
      };
      expect(() => proposalUpdateSchema.parse(validUpdate)).not.toThrow();
    });

    it('should require proposalId', () => {
      const withoutProposalId = {
        updates: { title: 'Updated Title' },
      };
      expect(() => proposalUpdateSchema.parse(withoutProposalId)).toThrow();
    });

    it('should accept partial updates', () => {
      const partialUpdate = {
        proposalId: 'prop-123',
        updates: {
          description: 'Updated description that is long enough.',
        },
      };
      expect(() => proposalUpdateSchema.parse(partialUpdate)).not.toThrow();
    });

    it('should not allow daoId in updates', () => {
      const updateWithDaoId = {
        proposalId: 'prop-123',
        updates: {
          title: 'Updated Title',
          daoId: 'new-dao-id',
        },
      };
      const result = proposalUpdateSchema.parse(updateWithDaoId);
      expect(result.updates).not.toHaveProperty('daoId');
    });

    it('should not allow options in updates', () => {
      const updateWithOptions = {
        proposalId: 'prop-123',
        updates: {
          title: 'Updated Title',
          options: ['New option 1', 'New option 2'],
        },
      };
      const result = proposalUpdateSchema.parse(updateWithOptions);
      expect(result.updates).not.toHaveProperty('options');
    });

    it('should not allow votingDuration in updates', () => {
      const updateWithDuration = {
        proposalId: 'prop-123',
        updates: {
          title: 'Updated Title',
          votingDuration: 14,
        },
      };
      const result = proposalUpdateSchema.parse(updateWithDuration);
      expect(result.updates).not.toHaveProperty('votingDuration');
    });
  });
});

describe('Proposal Comment Schemas', () => {
  describe('commentCreateSchema', () => {
    it('should accept valid comment', () => {
      const validComment = { content: 'This is a valid proposal comment.' };
      expect(() => commentCreateSchema.parse(validComment)).not.toThrow();
    });

    it('should reject empty content', () => {
      expect(() => commentCreateSchema.parse({ content: '' })).toThrow();
    });

    it('should reject whitespace-only content', () => {
      expect(() =>
        commentCreateSchema.parse({ content: '   \n\t  ' })
      ).toThrow();
    });

    it('should accept parentId for replies', () => {
      const reply = {
        content: 'This is a reply.',
        parentId: '550e8400-e29b-41d4-a716-446655440000',
      };
      expect(() => commentCreateSchema.parse(reply)).not.toThrow();
    });

    it('should reject invalid parentId format', () => {
      const invalidParent = {
        content: 'This is a comment.',
        parentId: 'not-a-uuid',
      };
      expect(() => commentCreateSchema.parse(invalidParent)).toThrow();
    });

    it('should reject XSS in content', () => {
      expect(() =>
        commentCreateSchema.parse({ content: '<script>alert(1)</script>' })
      ).toThrow();
    });
  });

  describe('commentUpdateSchema', () => {
    it('should accept valid update', () => {
      const validUpdate = { content: 'Updated comment content.' };
      expect(() => commentUpdateSchema.parse(validUpdate)).not.toThrow();
    });

    it('should reject empty update', () => {
      expect(() => commentUpdateSchema.parse({ content: '' })).toThrow();
    });
  });
});

describe('Document ID Validation', () => {
  it('should accept valid document ID', () => {
    expect(() => documentId.parse('prop-123')).not.toThrow();
    expect(() => documentId.parse('proposal_abc-123')).not.toThrow();
  });

  it('should reject empty document ID', () => {
    expect(() => documentId.parse('')).toThrow();
  });

  it('should reject ID starting with hyphen', () => {
    expect(() => documentId.parse('-prop')).toThrow();
  });

  it('should reject ID starting with underscore', () => {
    expect(() => documentId.parse('_prop')).toThrow();
  });
});

describe('Security Validation', () => {
  const contentValidator = createSanitizedString(1, 1000);

  it('should reject XSS script tags', () => {
    expect(() => contentValidator.parse('<script>alert(1)</script>')).toThrow();
  });

  it('should reject javascript: protocol', () => {
    expect(() => contentValidator.parse('javascript:void(0)')).toThrow();
  });

  it('should reject UNION SELECT injection', () => {
    expect(() =>
      contentValidator.parse('1 UNION SELECT * FROM proposals')
    ).toThrow();
  });

  it('should reject DROP TABLE injection', () => {
    expect(() => contentValidator.parse('; DROP TABLE proposals;')).toThrow();
  });

  it('should accept normal business text', () => {
    expect(() =>
      contentValidator.parse(
        'We should select the best option and update our governance'
      )
    ).not.toThrow();
  });
});

describe('Wallet Address Validation', () => {
  const walletSchema = commonValidations.walletAddress;

  it('should accept valid Ethereum address', () => {
    expect(() =>
      walletSchema.parse('0x1234567890123456789012345678901234567890')
    ).not.toThrow();
  });

  it('should reject address without 0x prefix', () => {
    expect(() =>
      walletSchema.parse('1234567890123456789012345678901234567890')
    ).toThrow();
  });

  it('should reject address with wrong length', () => {
    expect(() => walletSchema.parse('0x123')).toThrow();
  });
});
