/**
 * API Route: Auto-Activate Proposals After Warm-Up Period
 * Should be called by a cron job or scheduled task every hour
 * POST /api/proposals/auto-activate
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  proposalAdminRepository,
} from '@/lib/data/repositories';
import { proposalWarmUpNotificationService } from '@/lib/services/proposal/notifications/proposal-warmup-notification.service';
import { VotingReminderService } from '@/lib/services/notification/email/voting-reminder.service';
import { logger } from '@/lib/services/logger.service';

export async function POST(request: NextRequest) {
  try {
    // Verify request is from authorized source (cron job, etc.)
    const authHeader = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (!expectedSecret) {
      console.error('CRON_SECRET not configured');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    if (authHeader !== `Bearer ${expectedSecret}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const now = new Date();
    const nowISO = now.toISOString();

    // Query for proposals under review where warm-up period has ended
    // Note: This excludes manual_approval proposals (they have warmUpEndsAt = null)
    const allUnderReviewProposals = await proposalAdminRepository.findMany({
      filters: [{ field: 'status', operator: '==', value: 'under_review' }],
    });

    // Filter in-memory for proposals where warm-up period has ended
    const proposalsToActivate = allUnderReviewProposals.filter((p) => {
      if (!p.warmUpEndsAt) return false;
      const warmUpEnds = new Date(p.warmUpEndsAt);
      return warmUpEnds <= now;
    });

    const activatedProposals: string[] = [];
    const skippedProposals: Array<{ proposalId: string; reason: string }> = [];
    const errors: Array<{ proposalId: string; error: string }> = [];

    // Activate each proposal
    for (const proposal of proposalsToActivate) {
      try {
        // Fetch DAO to check approval configuration
        const dao = await daoAdminRepository.findById(proposal.daoId);

        if (!dao) {
          skippedProposals.push({
            proposalId: proposal.id,
            reason: 'DAO not found',
          });
          continue;
        }

        const approvalConfig = dao.settings.proposalApproval || {
          mode: 'timed_review' as const,
          reviewDurationHours: 24 as const,
        };

        // Only auto-activate if DAO is in timed_review mode
        if (approvalConfig.mode !== 'timed_review') {
          skippedProposals.push({
            proposalId: proposal.id,
            reason: `DAO approval mode is ${approvalConfig.mode}, not timed_review`,
          });
          continue;
        }

        // Update to active status
        await proposalAdminRepository.update(proposal.id, {
          status: 'active',
          votingStartTime: nowISO,
          metadata: {
            ...proposal.metadata,
            autoActivatedAt: nowISO,
          },
        });

        activatedProposals.push(proposal.id);

        // Get DAO name for notification
        const daoName = dao.name || 'Your DAO';

        // Notify proposal creator that voting has started
        try {
          await proposalWarmUpNotificationService.notifyCreatorOfApproval(
            proposal,
            daoName,
            'system' // Auto-activated by system
          );
        } catch (notificationError) {
          logger.error(
            'Failed to send auto-activation notification',
            notificationError as Error,
            {
              proposalId: proposal.id,
              component: 'auto-activate',
            }
          );
          // Continue with other proposals even if notification fails
        }

        // Schedule voting reminders for all DAO members
        try {
          const votingReminderService = VotingReminderService.getInstance();
          const votingEndTime = proposal.votingEndTime || proposal.endTime;
          if (votingEndTime) {
            const reminderResult =
              await votingReminderService.scheduleRemindersForProposal(
                proposal.id,
                proposal.daoId,
                votingEndTime
              );
            if (reminderResult.success) {
              logger.info(
                'Scheduled voting reminders for auto-activated proposal',
                {
                  proposalId: proposal.id,
                  remindersScheduled: reminderResult.data,
                  component: 'auto-activate',
                }
              );
            }
          }
        } catch (reminderError) {
          logger.error(
            'Failed to schedule voting reminders',
            reminderError as Error,
            {
              proposalId: proposal.id,
              component: 'auto-activate',
            }
          );
          // Continue with other proposals even if reminder scheduling fails
        }
      } catch (error) {
        logger.error(
          `Failed to activate proposal ${proposal.id}`,
          error as Error,
          {
            component: 'auto-activate',
          }
        );
        errors.push({
          proposalId: proposal.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    return NextResponse.json({
      success: true,
      message: `Activated ${activatedProposals.length} proposal(s), skipped ${skippedProposals.length}`,
      activated: activatedProposals,
      skipped: skippedProposals.length > 0 ? skippedProposals : undefined,
      errors: errors.length > 0 ? errors : undefined,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error(
      'Error in auto-activate',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/proposals/auto-activate', method: 'POST' }
    );
    return NextResponse.json(
      { error: 'Failed to auto-activate proposals' },
      { status: 500 }
    );
  }
}

// Also support GET for health checks
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Auto-activate endpoint is available',
    timestamp: new Date().toISOString(),
  });
}
