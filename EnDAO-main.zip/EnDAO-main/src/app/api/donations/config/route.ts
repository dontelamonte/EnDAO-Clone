/**
 * Donation Config API endpoint
 * GET - Get donation config for a DAO (requires membership)
 * PATCH - Update donation config (requires admin)
 */

import { NextRequest, NextResponse } from 'next/server';
import { userAdminRepository } from '@/lib/data/repositories';
import { donationConfigService } from '@/lib/services/donation';
import { logger } from '@/lib/services/logger.service';
import type { DonationConfigInput } from '@endao/shared-types';

/**
 * GET /api/donations/config?daoId={daoId}
 * Returns donation config for a DAO
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const daoId = searchParams.get('daoId');

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Get config (service handles membership verification internally via RLS)
    const result = await donationConfigService.getConfig(daoId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get donation config',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching donation config',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/config', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch donation config',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/donations/config
 * Update donation config (admin only)
 */
export async function PATCH(request: NextRequest): Promise<NextResponse> {
  try {
    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Parse request body
    const body = await request.json();
    const { daoId, ...updates } = body as {
      daoId: string;
    } & DonationConfigInput;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    if (!updates || Object.keys(updates).length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'No updates provided',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Update config (service handles admin verification)
    const result = await donationConfigService.updateConfig(
      daoId,
      userId,
      updates
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to update donation config',
          code: 'UPDATE_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error updating donation config',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/config', method: 'PATCH' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to update donation config',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
