/**
 * Donation Stats API endpoint
 * GET - Get donation statistics for a DAO (requires membership)
 */

import { NextRequest, NextResponse } from 'next/server';
import { donationService } from '@/lib/services/donation';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/donations/{daoId}/stats
 * Get donation statistics for a DAO
 * Requires DAO membership
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
): Promise<NextResponse> {
  try {
    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Get stats (RLS handles membership verification)
    const result = await donationService.getStats(daoId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get donation stats',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching donation stats',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/[daoId]/stats', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch donation stats',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
