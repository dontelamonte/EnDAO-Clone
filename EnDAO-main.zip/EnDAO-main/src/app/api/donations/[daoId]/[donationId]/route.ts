/**
 * Single Donation API endpoint
 * GET - Get a single donation by ID
 */

import { NextRequest, NextResponse } from 'next/server';
import { donationService } from '@/lib/services/donation';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/donations/{daoId}/{donationId}
 * Get a single donation by ID
 * Public endpoint - returns limited info for non-authenticated users
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string; donationId: string }> }
): Promise<NextResponse> {
  try {
    const { daoId, donationId } = await params;

    if (!daoId || !donationId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and Donation ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get donation
    const result = await donationService.getDonation(donationId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Donation not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Donation not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Verify donation belongs to the specified DAO
    if (result.data.daoId !== daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Donation not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // For public access, return limited info (status, amount for success page)
    const donation = result.data;
    const publicData = {
      id: donation.id,
      daoId: donation.daoId,
      status: donation.status,
      fiatAmount: donation.fiatAmount,
      fiatCurrency: donation.fiatCurrency,
      cryptoAmount: donation.cryptoAmount,
      cryptoCurrency: donation.cryptoCurrency,
      createdAt: donation.createdAt,
      // Only include donor name if visibility allows
      donorName:
        donation.visibility !== 'anonymous' ? donation.donorName : null,
    };

    return NextResponse.json({
      success: true,
      data: publicData,
    });
  } catch (error) {
    logger.error(
      'Error fetching donation',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/[daoId]/[donationId]', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch donation',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
