/**
 * Donation API endpoint
 * POST - Initiate a new donation (public, no auth required for anonymous)
 * GET - Get public donations list
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { donationService } from '@/lib/services/donation';
import { logger } from '@/lib/services/logger.service';
import type { CreateDonationInput } from '@endao/shared-types';

// UUID v4 pattern for detecting if param is UUID or slug
const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Resolve a DAO identifier (UUID or slug) to the actual DAO ID
 */
async function resolveDaoId(daoIdOrSlug: string): Promise<string | null> {
  // If it looks like a UUID, try to find by ID first
  if (UUID_PATTERN.test(daoIdOrSlug)) {
    const dao = await daoAdminRepository.findById(daoIdOrSlug);
    return dao?.id || null;
  }
  // Otherwise, try to find by slug
  const dao = await daoAdminRepository.findBySlug(daoIdOrSlug);
  return dao?.id || null;
}

/**
 * POST /api/donations/{daoId}
 * Initiate a new donation
 * Public endpoint - no auth required for anonymous donations
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
): Promise<NextResponse> {
  try {
    const { daoId: daoIdOrSlug } = await params;

    if (!daoIdOrSlug) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Resolve slug or ID to actual DAO ID
    const daoId = await resolveDaoId(daoIdOrSlug);
    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { amount, donorName, donorEmail, visibility } = body as {
      amount: number;
      donorName?: string;
      donorEmail?: string;
      visibility?: 'anonymous' | 'name_only' | 'full';
    };

    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'Valid donation amount is required',
          code: 'INVALID_AMOUNT',
        },
        { status: 400 }
      );
    }

    // Optional: Get user ID if authenticated
    let userId: string | undefined;
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (privyId) {
      const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
      if (supabaseUser) {
        userId = supabaseUser.id;
      }
    }

    // Build donation input
    const input: CreateDonationInput = {
      daoId,
      amount,
      donorName,
      donorEmail,
      visibility,
    };

    // Initiate donation
    const result = await donationService.initiateDonation(input, userId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to initiate donation',
          code: 'DONATION_FAILED',
        },
        { status: 400 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to initiate donation',
          code: 'DONATION_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error initiating donation',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/[daoId]', method: 'POST' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to initiate donation',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * GET /api/donations/{daoId}
 * Get public donations list (completed, non-anonymous)
 * Public endpoint
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
): Promise<NextResponse> {
  try {
    const { daoId: daoIdOrSlug } = await params;

    if (!daoIdOrSlug) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Resolve slug or ID to actual DAO ID
    const daoId = await resolveDaoId(daoIdOrSlug);
    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Get limit from query params
    const { searchParams } = new URL(request.url);
    const limitParam = searchParams.get('limit');
    const limit = limitParam ? parseInt(limitParam, 10) : 20;

    // Get public donations
    const result = await donationService.getPublicDonations(daoId, limit);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get donations',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    // Add caching headers for public data
    return NextResponse.json(
      {
        success: true,
        data: result.data,
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=60, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching public donations',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/[daoId]', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch donations',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
