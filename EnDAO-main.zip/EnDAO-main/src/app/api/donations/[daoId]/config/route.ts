/**
 * Public Donation Config API endpoint
 * GET - Get public donation config for a DAO (no auth required)
 */

import { NextRequest, NextResponse } from 'next/server';
import { donationConfigService } from '@/lib/services/donation/donation-config.service';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/donations/{daoId}/config
 * Get public donation config for a DAO
 * Returns null if donations are disabled
 * Public endpoint - no auth required
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
): Promise<NextResponse> {
  try {
    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get public config (returns null if donations disabled)
    const result = await donationConfigService.getPublicConfig(daoId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get donation config',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    // Add caching headers for public data
    return NextResponse.json(
      {
        success: true,
        data: result.data,
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=60, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching public donation config',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/[daoId]/config', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch donation config',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
