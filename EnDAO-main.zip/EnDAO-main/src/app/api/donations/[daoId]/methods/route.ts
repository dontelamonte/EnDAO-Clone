/**
 * Donation Payment Methods API Route
 *
 * GET - Get available payment methods for a DAO
 *
 * Public endpoint - returns available payment methods based on DAO's treasury configuration
 */

import { NextRequest, NextResponse } from 'next/server';
import { daoAdminRepository } from '@/lib/data/repositories';
import { hybridTreasuryService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';
import {
  type AvailablePaymentMethod,
  PLATFORM_FEE_RATES,
  type PaymentMethodsResponse,
} from '@endao/shared-types';

// UUID v4 pattern for detecting if param is UUID or slug
const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Resolve a DAO identifier (UUID or slug) to the actual DAO ID
 */
async function resolveDaoId(daoIdOrSlug: string): Promise<string | null> {
  // If it looks like a UUID, try to find by ID first
  if (UUID_PATTERN.test(daoIdOrSlug)) {
    const dao = await daoAdminRepository.findById(daoIdOrSlug);
    return dao?.id || null;
  }
  // Otherwise, try to find by slug
  const dao = await daoAdminRepository.findBySlug(daoIdOrSlug);
  return dao?.id || null;
}

/**
 * GET /api/donations/{daoId}/methods
 * Get available payment methods for a DAO
 * Public endpoint
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
): Promise<NextResponse> {
  try {
    const { daoId: daoIdOrSlug } = await params;

    if (!daoIdOrSlug) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Resolve slug or ID to actual DAO ID
    const daoId = await resolveDaoId(daoIdOrSlug);
    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Get DAO details
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Get rail status from hybrid treasury service
    const railStatusResult = await hybridTreasuryService.getRailStatus(daoId);

    const methods: AvailablePaymentMethod[] = [];
    let defaultMethod: 'card' | 'crypto' = 'card';

    // Check if card payments are available (fiat rail active)
    const fiatActive =
      railStatusResult.success &&
      railStatusResult.data?.fiat.status === 'active';

    if (fiatActive) {
      methods.push({
        method: 'card',
        enabled: true,
        displayName: 'Pay with Card',
        description: 'Credit or debit card payment via Stripe',
        processingTime: 'Instant',
        fees: {
          platformFeePercent: PLATFORM_FEE_RATES.DEPOSIT * 100, // Convert to percentage
          processorFeePercent: 2.9,
          processorFeeFixed: 0.3,
        },
      });
    } else {
      methods.push({
        method: 'card',
        enabled: false,
        displayName: 'Pay with Card',
        description: 'Card payments not configured for this DAO',
        processingTime: 'N/A',
        fees: {
          platformFeePercent: 0,
          processorFeePercent: 0,
        },
      });
    }

    // Check if crypto payments are available (crypto rail active)
    const cryptoActive =
      railStatusResult.success &&
      railStatusResult.data?.crypto.status === 'active';

    if (cryptoActive) {
      methods.push({
        method: 'crypto',
        enabled: true,
        displayName: 'Pay with Digital Currency',
        description: 'Direct digital transfer',
        processingTime: '1-2 minutes (verification)',
        fees: {
          platformFeePercent: PLATFORM_FEE_RATES.DEPOSIT * 100,
          processorFeePercent: 0, // No processor fee for direct crypto
          networkFeeEstimate: 0.5, // Approximate gas cost in USD
        },
      });
    } else {
      methods.push({
        method: 'crypto',
        enabled: false,
        displayName: 'Pay with Digital Currency',
        description: 'Digital payments not configured for this group',
        processingTime: 'N/A',
        fees: {
          platformFeePercent: 0,
          processorFeePercent: 0,
        },
      });
    }

    // Determine default method
    // Prefer card if available, otherwise crypto
    if (fiatActive) {
      defaultMethod = 'card';
    } else if (cryptoActive) {
      defaultMethod = 'crypto';
    }

    const response: PaymentMethodsResponse = {
      daoId,
      methods,
      defaultMethod,
    };

    // Add caching headers for public data
    return NextResponse.json(
      {
        success: true,
        data: response,
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=60, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching payment methods',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/[daoId]/methods', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch payment methods',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
