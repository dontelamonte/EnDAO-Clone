/**
 * Stripe Webhook Handler for Donations
 * POST - Handle Stripe webhook events
 *
 * This endpoint must be configured in Stripe dashboard to receive:
 * - checkout.session.completed
 * - checkout.session.expired
 * - payment_intent.succeeded
 * - payment_intent.payment_failed
 * - charge.refunded
 */

import { NextRequest, NextResponse } from 'next/server';
import { donationService, stripeOnrampService } from '@/lib/services/donation';
import { logger } from '@/lib/services/logger.service';

/**
 * POST /api/donations/webhook
 * Handle Stripe webhook events
 * No authentication - uses Stripe signature verification
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    // Get the raw body for signature verification
    const body = await request.text();

    // Get the Stripe signature header
    const signature = request.headers.get('stripe-signature');

    if (!signature) {
      logger.warn('Webhook received without Stripe signature');
      return NextResponse.json(
        {
          success: false,
          error: 'Missing Stripe signature',
          code: 'MISSING_SIGNATURE',
        },
        { status: 400 }
      );
    }

    // Verify the webhook signature and construct the event
    let event;
    try {
      event = stripeOnrampService.verifyWebhookSignature(body, signature);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      logger.error('Webhook signature verification failed', err as Error);
      return NextResponse.json(
        {
          success: false,
          error: `Webhook signature verification failed: ${message}`,
          code: 'INVALID_SIGNATURE',
        },
        { status: 400 }
      );
    }

    // Log the event type for monitoring
    logger.info('Received Stripe webhook', {
      eventId: event.id,
      eventType: event.type,
    });

    // Handle the webhook event
    const result = await donationService.handleStripeWebhook(event);

    if (!result.success) {
      // Log but still return 200 to Stripe to prevent retries for business logic errors
      logger.error(
        'Webhook processing failed',
        new Error(result.error || 'Unknown error'),
        {
          eventId: event.id,
          eventType: event.type,
        }
      );
    }

    // Always return 200 to acknowledge receipt
    // Stripe will retry if we return non-2xx
    return NextResponse.json({
      success: true,
      received: true,
      eventId: event.id,
    });
  } catch (error) {
    logger.error(
      'Error processing Stripe webhook',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/donations/webhook', method: 'POST' }
    );

    // Return 500 so Stripe will retry
    return NextResponse.json(
      {
        success: false,
        error: 'Webhook processing error',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

// Disable body parsing for webhooks - we need the raw body for signature verification
export const config = {
  api: {
    bodyParser: false,
  },
};
