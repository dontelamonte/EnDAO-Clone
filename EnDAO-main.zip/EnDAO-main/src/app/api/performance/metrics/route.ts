import { NextRequest, NextResponse } from 'next/server';
import { performanceMonitor } from '@/lib/utils/performance-monitor';

/**
 * Performance metrics endpoint for monitoring and debugging
 */
export async function GET(request: NextRequest) {
  try {
    const insights = performanceMonitor.getInsights();

    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      insights,
    });
  } catch (error) {
    console.error('Failed to get performance insights:', error);
    return NextResponse.json(
      {
        error: 'Failed to get performance metrics',
        timestamp: new Date().toISOString(),
      },
      { status: 500 }
    );
  }
}

/**
 * Clear performance metrics (for development/testing)
 */
export async function DELETE(request: NextRequest) {
  try {
    performanceMonitor.clear();

    return NextResponse.json({
      success: true,
      message: 'Performance metrics cleared',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Failed to clear performance metrics:', error);
    return NextResponse.json(
      {
        error: 'Failed to clear performance metrics',
        timestamp: new Date().toISOString(),
      },
      { status: 500 }
    );
  }
}
