/**
 * Conversion Provider Webhook Handler
 *
 * Receives callbacks from crypto conversion providers (MoonPay, Ramp, etc.)
 * to update donation/conversion status after:
 * - On-ramp: fiat-to-crypto conversion (donations)
 * - Off-ramp: crypto-to-fiat conversion (treasury payouts)
 */

import { NextRequest, NextResponse } from 'next/server';
import { cryptoConversionService, moonPayProvider } from '@/lib/services/conversion';
import { conversionEventAdminRepository } from '@/lib/data/repositories/supabase';
import { financialAuditService } from '@/lib/services/audit';
import { logger } from '@/lib/services/logger.service';
import crypto from 'crypto';

/**
 * Verify MoonPay webhook signature
 */
function verifyMoonPaySignature(
  payload: string,
  signature: string,
  secret: string
): boolean {
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

/**
 * POST /api/conversion/webhook
 * Handle conversion provider webhooks
 */
export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    const rawBody = await request.text();
    const provider = request.headers.get('x-provider') || 'unknown';

    logger.info('Received conversion webhook', {
      component: 'ConversionWebhook',
      provider,
      contentLength: rawBody.length,
    });

    // Verify signature based on provider
    if (provider === 'moonpay') {
      const signature = request.headers.get('moonpay-signature');
      const secret = process.env.MOONPAY_WEBHOOK_SECRET;

      if (!signature || !secret) {
        logger.warn('Missing MoonPay webhook signature or secret', {
          component: 'ConversionWebhook',
        });
        return NextResponse.json(
          { error: 'Missing signature' },
          { status: 401 }
        );
      }

      if (!verifyMoonPaySignature(rawBody, signature, secret)) {
        logger.warn('Invalid MoonPay webhook signature', {
          component: 'ConversionWebhook',
        });
        return NextResponse.json(
          { error: 'Invalid signature' },
          { status: 401 }
        );
      }
    }

    // Parse the payload
    const payload = JSON.parse(rawBody);

    // Normalize to our internal format
    const normalizedPayload = normalizeWebhookPayload(provider, payload);

    if (!normalizedPayload) {
      logger.warn('Could not normalize webhook payload', {
        component: 'ConversionWebhook',
        provider,
      });
      return NextResponse.json({ received: true });
    }

    // Check for duplicate event (idempotency)
    const eventExists = await conversionEventAdminRepository.exists(
      normalizedPayload.eventId
    );

    if (eventExists) {
      logger.info('Duplicate conversion event received', {
        component: 'ConversionWebhook',
        eventId: normalizedPayload.eventId,
      });
      return NextResponse.json({ received: true, duplicate: true });
    }

    // Record the event
    await conversionEventAdminRepository.create({
      provider: normalizedPayload.provider,
      providerEventId: normalizedPayload.eventId,
      eventType: normalizedPayload.eventType,
      data: payload,
    });

    // Process the webhook
    const result = await cryptoConversionService.handleWebhook(normalizedPayload);

    if (!result.success) {
      logger.error(
        'Failed to process conversion webhook',
        new Error(result.error || 'Unknown error'),
        { eventId: normalizedPayload.eventId }
      );
    }

    // Log financial audit event for completed conversions
    if (normalizedPayload.status === 'completed' || normalizedPayload.status === 'failed') {
      const direction = determineConversionDirection(normalizedPayload);
      await financialAuditService.logConversionEvent(
        normalizedPayload.status === 'completed' ? 'completed' : 'failed',
        {
          conversionId: normalizedPayload.conversionId || normalizedPayload.eventId,
          daoId: '', // Will be filled from donation/offramp lookup
          direction,
          sourceAmount: normalizedPayload.cryptoAmount || 0,
          sourceCurrency: normalizedPayload.cryptoCurrency || 'USDC',
          targetAmount: normalizedPayload.cryptoAmount,
          targetCurrency: normalizedPayload.cryptoCurrency || 'USDC',
          provider: normalizedPayload.provider,
          txHash: normalizedPayload.txHash,
        },
        { actorId: 'system' }
      );
    }

    // Mark event as processed
    await conversionEventAdminRepository.markProcessed(normalizedPayload.eventId);

    const duration = Date.now() - startTime;
    logger.info('Conversion webhook processed', {
      component: 'ConversionWebhook',
      provider,
      eventType: normalizedPayload.eventType,
      duration,
    });

    return NextResponse.json({ received: true, processed: true });
  } catch (error) {
    logger.error(
      'Conversion webhook error',
      error instanceof Error ? error : new Error('Unknown error')
    );

    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    );
  }
}

/**
 * Normalize provider-specific webhook payloads to our internal format
 */
function normalizeWebhookPayload(
  provider: string,
  payload: Record<string, unknown>
) {
  switch (provider) {
    case 'moonpay':
      return normalizeMoonPayPayload(payload);

    case 'ramp':
      return normalizeRampPayload(payload);

    default:
      // Generic format for manual or unknown providers
      return {
        provider,
        eventId: (payload.id as string) || `${provider}_${Date.now()}`,
        eventType: (payload.type as string) || 'unknown',
        conversionId: (payload.conversionId as string) || (payload.externalTransactionId as string),
        status: (payload.status as string) || 'unknown',
        txHash: payload.txHash as string | undefined,
        cryptoAmount: payload.cryptoAmount as number | undefined,
        cryptoCurrency: payload.cryptoCurrency as string | undefined,
        error: payload.error as string | undefined,
      };
  }
}

/**
 * Normalize MoonPay webhook payload
 * https://dev.moonpay.com/docs/webhooks
 */
function normalizeMoonPayPayload(payload: Record<string, unknown>) {
  const data = payload.data as Record<string, unknown> | undefined;
  const type = payload.type as string;

  if (!data) return null;

  // Map MoonPay status to our status
  const statusMap: Record<string, string> = {
    pending: 'pending',
    waitingPayment: 'pending',
    waitingAuthorization: 'pending',
    completed: 'completed',
    failed: 'failed',
  };

  return {
    provider: 'moonpay',
    eventId: payload.id as string,
    eventType: type,
    conversionId: (data.externalTransactionId as string) || (data.id as string),
    status: statusMap[data.status as string] || 'unknown',
    txHash: data.cryptoTransactionId as string | undefined,
    cryptoAmount: data.quoteCurrencyAmount as number | undefined,
    cryptoCurrency: data.currency as string | undefined,
    error: data.failureReason as string | undefined,
  };
}

/**
 * Normalize Ramp Network webhook payload
 * https://docs.ramp.network/webhooks
 */
function normalizeRampPayload(payload: Record<string, unknown>) {
  // Map Ramp status to our status
  const statusMap: Record<string, string> = {
    INITIALIZED: 'pending',
    PENDING: 'pending',
    RELEASED: 'completed',
    EXPIRED: 'failed',
    CANCELLED: 'cancelled',
  };

  return {
    provider: 'ramp',
    eventId: (payload.id as string) || `ramp_${Date.now()}`,
    eventType: payload.type as string,
    conversionId: payload.purchaseViewToken as string,
    status: statusMap[payload.status as string] || 'unknown',
    txHash: (payload.finalTxHash as string) || undefined,
    cryptoAmount: payload.cryptoAmount as number | undefined,
    cryptoCurrency: payload.asset as string | undefined,
    error: payload.error as string | undefined,
  };
}

/**
 * Determine conversion direction based on event type
 */
function determineConversionDirection(
  payload: { eventType: string; provider: string }
): 'fiat_to_crypto' | 'crypto_to_fiat' {
  const eventType = payload.eventType.toLowerCase();

  // Off-ramp indicators
  if (
    eventType.includes('sell') ||
    eventType.includes('offramp') ||
    eventType.includes('off_ramp') ||
    eventType.includes('withdraw')
  ) {
    return 'crypto_to_fiat';
  }

  // Default to on-ramp (buy/deposit)
  return 'fiat_to_crypto';
}
