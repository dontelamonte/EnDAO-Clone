/**
 * Voting Statistics API Route
 *
 * Fetches user voting statistics including:
 * - Total votes cast
 * - Participation rate
 * - Voting streak
 * - Per-DAO breakdown
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  voteAdminRepository,
  daoAdminRepository,
  userAdminRepository,
  proposalAdminRepository,
} from '@/lib/data/repositories';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { featureFlagService } from '@/lib/features/feature-flag.service';

interface VotesByDAO {
  daoName: string;
  voteCount: number;
  participationRate: number;
}

interface VotingStatisticsResponse {
  success: boolean;
  data?: {
    totalVotesCast: number;
    participationRate: number;
    votingStreak: number;
    lastVoteTimestamp: string | null;
    votesByDAO: Record<string, VotesByDAO>;
  };
  error?: string;
}

export async function GET(
  request: NextRequest
): Promise<NextResponse<VotingStatisticsResponse>> {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'User ID required', code: 'AUTH_REQUIRED' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json({
        success: true,
        data: {
          totalVotesCast: 0,
          participationRate: 0,
          votingStreak: 0,
          lastVoteTimestamp: null,
          votesByDAO: {},
        },
      });
    }

    const userId = supabaseUser.id;

    // Try using materialized views if enabled (Phase 5)
    if (featureFlagService.isEnabled('useMaterializedViews')) {
      try {
        const materializedResult =
          await getVotingStatsFromMaterializedView(userId);
        if (materializedResult) {
          console.log(
            '[VotingStats] Using materialized views for user activity'
          );
          return NextResponse.json(materializedResult);
        }
      } catch (error) {
        console.warn(
          '[VotingStats] Materialized view query failed, falling back to computed:',
          error
        );
        // Fall through to computed queries
      }
    }

    // Fetch all votes by this user
    const votes = await voteAdminRepository.findByUser(userId);

    // Get unique DAO IDs and filter out deleted/archived DAOs
    const uniqueDaoIds = [
      ...new Set(votes.map((v) => v.daoId).filter(Boolean)),
    ];
    const activeDaoIds = new Set<string>();
    const daoNames: Record<string, string> = {};

    for (const daoId of uniqueDaoIds) {
      if (!daoId) continue;
      const dao = await daoAdminRepository.findById(daoId);
      if (dao && dao.status !== 'deleted' && dao.status !== 'archived') {
        activeDaoIds.add(daoId);
        daoNames[daoId] = dao.name;
      }
    }

    // Filter votes to active DAOs only
    const filteredVotes = votes.filter(
      (v) => v.daoId && activeDaoIds.has(v.daoId)
    );

    // Sort by createdAt descending
    const sortedVotes = [...filteredVotes].sort((a, b) => {
      const aTime = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const bTime = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return bTime - aTime;
    });

    const totalVotesCast = sortedVotes.length;

    // Get last vote timestamp
    const lastVoteTimestamp =
      sortedVotes.length > 0 && sortedVotes[0].createdAt
        ? new Date(sortedVotes[0].createdAt).toISOString()
        : null;

    // Calculate voting streak
    const votingStreak = calculateVotingStreak(
      sortedVotes.map((v) => ({ createdAt: v.createdAt }))
    );

    // Calculate per-DAO statistics with real participation rates
    const votesByDAO: Record<string, VotesByDAO> = {};
    const votesByDaoMap = new Map<string, number>();

    for (const vote of sortedVotes) {
      if (!vote.daoId) continue;
      const count = votesByDaoMap.get(vote.daoId) || 0;
      votesByDaoMap.set(vote.daoId, count + 1);
    }

    // Calculate actual participation rate per DAO
    let totalUserVotes = 0;
    let totalVotableProposals = 0;

    for (const [daoId, voteCount] of votesByDaoMap.entries()) {
      // Get proposals user could have voted on (active, passed, failed, executed - excludes draft/deleted)
      const allProposals = await proposalAdminRepository.findByDao(daoId);
      const votableProposals = allProposals.filter(
        (p) => p.status !== 'draft' && p.status !== 'deleted'
      );
      const votableCount = votableProposals.length;

      // Calculate participation rate for this DAO
      const daoParticipationRate =
        votableCount > 0 ? Math.round((voteCount / votableCount) * 100) : 0;

      votesByDAO[daoId] = {
        daoName: daoNames[daoId] || 'Unknown DAO',
        voteCount,
        participationRate: Math.min(daoParticipationRate, 100), // Cap at 100%
      };

      totalUserVotes += voteCount;
      totalVotableProposals += votableCount;
    }

    // Calculate overall participation rate (weighted by total proposals, not average)
    const participationRate =
      totalVotableProposals > 0
        ? Math.min(
            Math.round((totalUserVotes / totalVotableProposals) * 100),
            100
          )
        : 0;

    return NextResponse.json({
      success: true,
      data: {
        totalVotesCast,
        participationRate,
        votingStreak,
        lastVoteTimestamp,
        votesByDAO,
      },
    });
  } catch (error) {
    console.error('Error fetching voting statistics:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch voting statistics',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * Calculate voting streak - consecutive weeks where user voted
 */
function calculateVotingStreak(
  votes: Array<{ createdAt?: string | Date | null }>
): number {
  if (votes.length === 0) return 0;

  // Group votes by week
  const votesByWeek = new Map<string, number>();

  for (const vote of votes) {
    if (!vote.createdAt) continue;
    const voteDate = new Date(vote.createdAt);
    const weekKey = getWeekKey(voteDate);
    votesByWeek.set(weekKey, (votesByWeek.get(weekKey) || 0) + 1);
  }

  // Calculate streak starting from current week
  let streak = 0;
  const currentDate = new Date();

  while (true) {
    const weekKey = getWeekKey(currentDate);
    if (votesByWeek.has(weekKey)) {
      streak++;
      // Move to previous week
      currentDate.setDate(currentDate.getDate() - 7);
    } else {
      break;
    }
  }

  return streak;
}

/**
 * Get a week key in format YYYY-WW (year-week)
 */
function getWeekKey(date: Date): string {
  const year = date.getFullYear();
  const startOfYear = new Date(year, 0, 1);
  const daysSinceStart = Math.floor(
    (date.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24)
  );
  const weekNumber = Math.ceil((daysSinceStart + startOfYear.getDay() + 1) / 7);
  return `${year}-${String(weekNumber).padStart(2, '0')}`;
}

/**
 * Get voting statistics from user_activity_summary materialized view (Phase 5)
 * @see supabase/migrations/011_materialized_views.sql
 */
async function getVotingStatsFromMaterializedView(
  userId: string
): Promise<VotingStatisticsResponse | null> {
  const supabase = getSupabaseAdmin();

  // Define user activity summary type
  type UserActivitySummaryRow = {
    user_id: string;
    display_name: string | null;
    username: string | null;
    avatar_url: string | null;
    profile_setup_complete: boolean;
    active_dao_count: number;
    admin_dao_count: number;
    total_proposals_created: number;
    passed_proposals: number;
    proposals_30d: number;
    total_votes_cast: number;
    votes_30d: number;
    last_activity_at: string | null;
    refreshed_at: string;
  };

  try {
    // Query materialized view
    const result = await supabase
      .from('user_activity_summary' as 'users')
      .select('*')
      .eq('user_id', userId)
      .single()
      .then(
        (result) =>
          result as {
            data: UserActivitySummaryRow | null;
            error: { code: string; message: string } | null;
          }
      );

    if (result.error || !result.data) {
      return null;
    }

    const userData = result.data;

    // Get per-DAO breakdown using computed query (materialized view doesn't have this detail)
    const votes = await voteAdminRepository.findByUser(userId);
    const votesByDAO: Record<string, VotesByDAO> = {};
    const votesByDaoMap = new Map<string, number>();

    for (const vote of votes) {
      if (!vote.daoId) continue;
      const count = votesByDaoMap.get(vote.daoId) || 0;
      votesByDaoMap.set(vote.daoId, count + 1);
    }

    // Get DAO names and filter to active DAOs
    const activeDaoIds = new Set<string>();
    const daoNames: Record<string, string> = {};
    for (const daoId of votesByDaoMap.keys()) {
      const dao = await daoAdminRepository.findById(daoId);
      if (dao && dao.status !== 'deleted' && dao.status !== 'archived') {
        activeDaoIds.add(daoId);
        daoNames[daoId] = dao.name;
      }
    }

    // Build per-DAO stats
    for (const [daoId, voteCount] of votesByDaoMap.entries()) {
      if (activeDaoIds.has(daoId)) {
        votesByDAO[daoId] = {
          daoName: daoNames[daoId] || 'Unknown DAO',
          voteCount,
          participationRate: 0, // Could calculate from proposal analytics if needed
        };
      }
    }

    // Sort votes for streak calculation
    const filteredVotes = votes.filter(
      (v) => v.daoId && activeDaoIds.has(v.daoId)
    );
    const sortedVotes = [...filteredVotes].sort((a, b) => {
      const aTime = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const bTime = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return bTime - aTime;
    });

    return {
      success: true,
      data: {
        totalVotesCast: userData.total_votes_cast,
        participationRate: Math.round(
          (userData.votes_30d / Math.max(userData.proposals_30d, 1)) * 100
        ),
        votingStreak: calculateVotingStreak(
          sortedVotes.map((v) => ({ createdAt: v.createdAt }))
        ),
        lastVoteTimestamp: userData.last_activity_at,
        votesByDAO,
      },
    };
  } catch (error) {
    console.warn('[VotingStats] Error querying materialized view:', error);
    return null;
  }
}
