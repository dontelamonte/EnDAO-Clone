/**
 * Dashboard API Route
 *
 * Server-side endpoint for fetching all dashboard data.
 * This consolidates multiple data fetches into a single API call
 * to avoid using admin repositories in the browser.
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import { userActivityService } from '@/lib/services/user';
import { ProposalServiceOrchestrator } from '@/lib/services/proposal';
import {
  userAdminRepository,
  voteAdminRepository,
} from '@/lib/data/repositories';
import { getComputedProposalStatus } from '@/lib/utils/proposal-status';
import { logger } from '@/lib/services/logger.service';

// Response types
interface DashboardDAO {
  id: string;
  name: string;
  description: string;
  logoUrl?: string | null;
  members: number;
  treasury: string;
  activeProposals: number;
  role: string;
}

interface ActionItem {
  id: string;
  type: string;
  title: string;
  dao: string;
  daoId: string;
  deadline: string;
  priority: 'high' | 'medium' | 'normal';
}

interface ActivityItem {
  id: string;
  type: string;
  details?: {
    daoName?: string;
  };
  timestamp: string;
}

interface DashboardData {
  daos: DashboardDAO[];
  stats: {
    daosJoined: number;
    proposalsVoted: number;
    pendingVotes: number;
  };
  actionItems: ActionItem[];
  recentActivity: ActivityItem[];
}

export async function GET(request: NextRequest) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'User ID required', code: 'AUTH_REQUIRED' },
        { status: 401 }
      );
    }

    logger.debug('[Dashboard API] Fetching data for user', {
      privyId: privyId.substring(0, 15) + '...',
    });

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      logger.warn('[Dashboard API] No Supabase user found for Privy ID', {
        privyId: privyId.substring(0, 15) + '...',
      });
      return NextResponse.json({
        success: true,
        data: {
          daos: [],
          stats: { daosJoined: 0, proposalsVoted: 0, pendingVotes: 0 },
          actionItems: [],
          recentActivity: [],
        } as DashboardData,
      });
    }

    const userId = supabaseUser.id;
    logger.debug('[Dashboard API] Mapped Privy ID to Supabase UUID', {
      userId: userId.substring(0, 10) + '...',
    });

    // Fetch user's DAOs
    const daoService = DAOService.getInstance();
    const userDAOsResult = await daoService.getUserDAOs(userId);

    if (!userDAOsResult.success || !userDAOsResult.data) {
      return NextResponse.json({
        success: true,
        data: {
          daos: [],
          stats: { daosJoined: 0, proposalsVoted: 0, pendingVotes: 0 },
          actionItems: [],
          recentActivity: [],
        } as DashboardData,
      });
    }

    const userDAOs = userDAOsResult.data;
    const proposalService = ProposalServiceOrchestrator.getInstance();

    // Cache active proposals per DAO to avoid duplicate fetches
    // Maps daoId -> array of active proposals
    const activeProposalsCache = new Map<
      string,
      Awaited<ReturnType<typeof proposalService.getProposalsByStatus>>['data']
    >();

    // Build formatted DAOs with live active proposal counts
    const formattedDAOs: DashboardDAO[] = await Promise.all(
      userDAOs.map(async (dao) => {
        let activeCount = 0;
        try {
          const activeResult = await proposalService.getProposalsByStatus(
            dao.id,
            'active',
            1000
          );
          if (activeResult.success && activeResult.data) {
            const activeProposals = activeResult.data.filter(
              (p) => getComputedProposalStatus(p) === 'active'
            );
            activeCount = activeProposals.length;
            // Cache for later use - avoids N+1 query pattern
            activeProposalsCache.set(dao.id, activeProposals);
          }
        } catch {
          activeCount = dao.stats?.activeProposals || 0;
        }

        // Get treasury info from DAO fields
        let treasuryDisplay = '$0';
        if (dao.safeAddress && dao.treasuryEnabled) {
          // Has a treasury - show cached value or $0 if no cached value
          const cachedValue = dao.treasuryValue || 0;
          if (cachedValue >= 1000000) {
            treasuryDisplay = `$${(cachedValue / 1000000).toFixed(1)}M`;
          } else if (cachedValue >= 1000) {
            treasuryDisplay = `$${(cachedValue / 1000).toFixed(1)}K`;
          } else if (cachedValue > 0) {
            treasuryDisplay = `$${cachedValue.toFixed(2)}`;
          } else {
            treasuryDisplay = '$0';
          }
        } else {
          treasuryDisplay = 'N/A';
        }

        return {
          id: dao.id,
          name: dao.name,
          description: dao.description,
          logoUrl: dao.logoUrl || null,
          members: dao.stats?.memberCount || dao.memberCount || 0,
          treasury: treasuryDisplay,
          activeProposals: activeCount,
          role: (dao as { role?: string }).role || 'Member',
        };
      })
    );

    // Get vote counts using repository - single query for all user votes
    const currentDaoIds = formattedDAOs.map((d) => d.id);
    let proposalsVotedCount = 0;
    let pendingVotesCount = 0;
    const pendingActions: ActionItem[] = [];

    // Create Set of proposal IDs user has voted on for O(1) lookup
    const votedProposalIds = new Set<string>();

    try {
      // Get all user votes in a single query
      const userVotes = await voteAdminRepository.findByUser(userId);

      // Build lookup set and count votes from current DAOs
      for (const vote of userVotes) {
        votedProposalIds.add(vote.proposalId);
        if (vote.daoId && currentDaoIds.includes(vote.daoId)) {
          proposalsVotedCount++;
        }
      }
    } catch (err) {
      logger.error('[Dashboard API] Error counting user votes', err as Error);
    }

    // Calculate pending votes and action items using cached data
    // This eliminates the N+1 pattern - no additional queries needed
    for (const dao of formattedDAOs) {
      if (dao.activeProposals > 0) {
        // Use cached proposals instead of re-fetching
        const cachedProposals = activeProposalsCache.get(dao.id);
        if (cachedProposals) {
          for (const proposal of cachedProposals) {
            // O(1) lookup instead of API call per proposal
            const hasVoted = votedProposalIds.has(proposal.id);
            if (!hasVoted) {
              pendingVotesCount++;

              // Calculate time until deadline
              const endTime = new Date(proposal.endTime as unknown as string);
              const now = new Date();
              const diffMs = endTime.getTime() - now.getTime();
              const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

              pendingActions.push({
                id: proposal.id,
                type: 'vote',
                title: proposal.title,
                dao: dao.name,
                daoId: dao.id,
                deadline:
                  diffDays > 0
                    ? `${diffDays} day${diffDays !== 1 ? 's' : ''} left`
                    : 'Ending soon',
                priority:
                  diffDays <= 1 ? 'high' : diffDays <= 3 ? 'medium' : 'normal',
              });
            }
          }
        }
      }
    }

    // Load recent activity
    let recentActivityItems: ActivityItem[] = [];
    try {
      const activityResult = await userActivityService.getRecentActivity(
        userId,
        10
      );
      if (activityResult.success && activityResult.data) {
        recentActivityItems = activityResult.data
          .filter((act) => act.type !== 'login' && act.type !== 'logout')
          .slice(0, 3)
          .map((act) => ({
            id: act.id,
            type: act.type,
            details: act.details as { daoName?: string } | undefined,
            timestamp: act.timestamp.toISOString(),
          }));
      }
    } catch (err) {
      logger.error(
        '[Dashboard API] Error loading recent activity',
        err as Error
      );
    }

    const dashboardData: DashboardData = {
      daos: formattedDAOs,
      stats: {
        daosJoined: formattedDAOs.length,
        proposalsVoted: proposalsVotedCount,
        pendingVotes: pendingVotesCount,
      },
      actionItems: pendingActions.slice(0, 5),
      recentActivity: recentActivityItems,
    };

    return NextResponse.json({ success: true, data: dashboardData });
  } catch (error) {
    logger.error(
      '[Dashboard API] Error fetching dashboard data',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch dashboard data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
