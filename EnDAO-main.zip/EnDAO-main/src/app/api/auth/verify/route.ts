import { NextRequest, NextResponse } from 'next/server';
import { verifyAuthToken } from '@/lib/privy-server';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import {
  enforceMinimumTiming,
  TIMING_DELAYS,
} from '@/lib/security/timing-protection';
import { logger } from '@/lib/services/logger.service';

// Example API route demonstrating secure Privy token verification
// SECURITY: Uses timing attack protection to prevent user enumeration
export async function POST(request: NextRequest) {
  const startTime = Date.now(); // Capture start time for timing protection

  try {
    // Apply rate limiting for token verification attempts (5 attempts per 15 minutes per IP)
    const rateLimitResult = await rateLimiters.auth(request);
    if (rateLimitResult) {
      // Enforce timing even on rate limit failures to prevent timing analysis
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }
    // Get the authorization header
    const authHeader = request.headers.get('authorization');

    if (!authHeader) {
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        { error: 'Missing authorization header' },
        { status: 401 }
      );
    }

    // Verify the token
    const { success, claims, error } = await verifyAuthToken(authHeader);

    if (!success) {
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        { error: error || 'Invalid token' },
        { status: 401 }
      );
    }

    // Successful auth: use base delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_SUCCESS, startTime);

    // Token is valid - return user info
    // Never return sensitive information in the response
    return NextResponse.json({
      valid: true,
      userId: claims!.userId,
      // Add any other non-sensitive claims you need
    });
  } catch (error) {
    logger.error(
      'Token verification error',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/auth/verify', method: 'POST' }
    );

    // Error path: use failure delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);

    // Don't expose internal errors
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Only allow POST requests
export async function GET() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}
