/**
 * CSRF Token API Endpoint
 * Provides CSRF tokens for client-side requests
 */

import { NextRequest, NextResponse } from 'next/server';
import { generateCSRFToken, setCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';

/**
 * GET /api/auth/csrf
 * Generate and return a new CSRF token
 * Rate limited to 100 successful requests per minute
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  // Apply rate limiting (100/min, failed requests don't count)
  const rateLimitResult = await rateLimiters.api(request);
  if (rateLimitResult) return rateLimitResult;

  try {
    // Generate new CSRF token
    const token = generateCSRFToken();

    // Create response with token
    const response = NextResponse.json({
      token,
      expires: Date.now() + 1000 * 60 * 60 * 24, // 24 hours
    });

    // Set CSRF token in secure cookie and header
    setCSRFToken(response, token);

    // Cache control headers
    response.headers.set(
      'Cache-Control',
      'no-store, no-cache, must-revalidate'
    );
    response.headers.set('Pragma', 'no-cache');

    return response;
  } catch (error) {
    logger.error(
      'CSRF token generation failed',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/auth/csrf', method: 'GET' }
    );

    return NextResponse.json(
      {
        error: 'Unable to generate CSRF token',
        code: 'CSRF_GENERATION_FAILED',
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/auth/csrf
 * Refresh CSRF token (for token rotation)
 * Rate limited to 100 successful requests per minute
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  // Apply rate limiting (100/min, failed requests don't count)
  const rateLimitResult = await rateLimiters.api(request);
  if (rateLimitResult) return rateLimitResult;

  try {
    // Generate new token for rotation
    const newToken = generateCSRFToken();

    const response = NextResponse.json({
      token: newToken,
      expires: Date.now() + 1000 * 60 * 60 * 24,
      message: 'CSRF token refreshed successfully',
    });

    // Set new token in cookie and header
    setCSRFToken(response, newToken);

    // Security headers
    response.headers.set(
      'Cache-Control',
      'no-store, no-cache, must-revalidate'
    );
    response.headers.set('Pragma', 'no-cache');

    return response;
  } catch (error) {
    logger.error(
      'CSRF token refresh failed',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/auth/csrf', method: 'POST' }
    );

    return NextResponse.json(
      {
        error: 'Unable to refresh CSRF token',
        code: 'CSRF_REFRESH_FAILED',
      },
      { status: 500 }
    );
  }
}
