/**
 * Auth Profile API Route
 *
 * Server-side endpoint for managing user profiles by Privy ID.
 * SECURITY: Requires authentication - caller's privyId must match target privyId.
 * Called by auth-context during authentication.
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { userProfileCrudService } from '@/lib/services/user';
import { logger } from '@/lib/services/logger.service';
import { createSanitizedString } from '@/lib/validations/api';
import {
  enforceMinimumTiming,
  TIMING_DELAYS,
} from '@/lib/security/timing-protection';
import { rateLimiters } from '@/lib/middleware/rate-limit';

// Schema for POST body validation
const profileCreateSchema = z.object({
  privyId: z.string().min(1, 'privyId is required').max(128),
  email: z.string().email().max(255).optional(),
  displayName: createSanitizedString(1, 100).optional(),
  primaryWallet: z.string().max(100).optional(),
  wallets: z.array(z.string().max(100)).max(10).optional(),
});

// Dynamic import to avoid Turbopack bundling issues with singleton
async function getSupabaseAdmin() {
  const { getSupabaseAdmin } = await import('@/lib/supabase/admin');
  return getSupabaseAdmin();
}

/**
 * Validates that the authenticated user can access the target privyId
 * Returns the validated privyId or an error response
 *
 * NOTE: This route is in the public routes list for auth bootstrap.
 * When auth headers are present, we validate they match.
 * When auth headers are absent (bootstrap), we allow the request
 * but the caller can only access by exact privyId match.
 */
function validateAuthAndPrivyId(
  request: NextRequest,
  targetPrivyId: string | null
):
  | { success: true; validatedPrivyId: string }
  | { success: false; response: NextResponse } {
  // Get authenticated user's privyId from middleware headers (if present)
  const authPrivyId = request.headers.get('x-auth-privy-id');

  if (!targetPrivyId) {
    return {
      success: false,
      response: NextResponse.json(
        {
          success: false,
          error: 'privyId is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      ),
    };
  }

  // If auth headers are present, validate they match the target
  // This prevents users from accessing other users' profiles
  if (authPrivyId && authPrivyId !== targetPrivyId) {
    logger.warn('[API] Profile access denied - privyId mismatch', {
      authPrivyId: authPrivyId.slice(0, 8) + '...',
      targetPrivyId: targetPrivyId.slice(0, 8) + '...',
    });
    return {
      success: false,
      response: NextResponse.json(
        { success: false, error: 'Access denied', code: 'FORBIDDEN' },
        { status: 403 }
      ),
    };
  }

  // Either auth matches target, or no auth (bootstrap case)
  // In bootstrap case, caller provides their own privyId which is safe
  return { success: true, validatedPrivyId: targetPrivyId };
}

export async function GET(request: NextRequest) {
  const startTime = Date.now(); // Capture start time for timing protection

  try {
    // Apply rate limiting for profile fetches (100 requests per minute per IP)
    const rateLimitResult = await rateLimiters.api(request);
    if (rateLimitResult) {
      // Enforce timing even on rate limit failures to prevent timing analysis
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const privyId = request.nextUrl.searchParams.get('privyId');

    // Validate authentication and authorization
    const authResult = validateAuthAndPrivyId(request, privyId);
    if (!authResult.success) {
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return authResult.response;
    }

    // Use the validated privyId (guaranteed non-null after validation)
    const validatedPrivyId = authResult.validatedPrivyId;

    logger.debug('[API] Fetching profile for Privy ID', {
      privyId: validatedPrivyId.slice(0, 8) + '...',
    });

    const result =
      await userProfileCrudService.getProfileByPrivyId(validatedPrivyId);

    if (!result.success) {
      // User not found: enforce timing to prevent user enumeration
      await enforceMinimumTiming(TIMING_DELAYS.USER_LOOKUP, startTime);
      return NextResponse.json(
        { success: false, error: result.error, code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Also fetch notification settings from user_preferences table
    let notificationSettings = null;
    if (result.data?.id) {
      try {
        const supabase = await getSupabaseAdmin();
        const { data: prefsData } = await supabase
          .from('user_preferences')
          .select('notification_settings')
          .eq('user_id', result.data.id)
          .single();

        // Type assertion needed because Supabase types don't include notification_settings
        const prefs = prefsData as { notification_settings?: unknown } | null;
        if (prefs?.notification_settings) {
          notificationSettings = prefs.notification_settings;
        }
      } catch {
        // Log but don't fail - preferences are optional
        logger.debug('No notification settings found for user', { privyId });
      }
    }

    // Enforce minimum timing for successful lookup to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.USER_LOOKUP, startTime);

    return NextResponse.json({
      success: true,
      data: {
        ...result.data,
        notificationSettings,
      },
    });
  } catch (error) {
    logger.error('[API] Error fetching profile', error as Error);
    // Error path: use failure delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch profile',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now(); // Capture start time for timing protection

  try {
    // Apply strict rate limiting for profile creation (5 attempts per 15 minutes per IP)
    const rateLimitResult = await rateLimiters.auth(request);
    if (rateLimitResult) {
      // Enforce timing even on rate limit failures to prevent timing analysis
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const body = await request.json();

    // Validate request body with schema
    const parseResult = profileCreateSchema.safeParse(body);
    if (!parseResult.success) {
      // Failed validation: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          code: 'VALIDATION_ERROR',
          details: parseResult.error.errors,
        },
        { status: 400 }
      );
    }

    const { privyId, email, displayName, primaryWallet, wallets } =
      parseResult.data;

    // Validate authentication and authorization
    const authResult = validateAuthAndPrivyId(request, privyId);
    if (!authResult.success) {
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return authResult.response;
    }

    logger.debug('[API] Creating/updating profile for Privy ID', {
      privyId: privyId.slice(0, 8) + '...',
    });

    const result = await userProfileCrudService.createProfileWithUid(privyId, {
      email,
      displayName,
      privyUserId: privyId,
      primaryWallet,
      wallets,
    });

    if (!result.success) {
      // If profile already exists, try to fetch it
      if (result.error === 'PROFILE_ALREADY_EXISTS') {
        const existingResult =
          await userProfileCrudService.getProfileByPrivyId(privyId);
        if (existingResult.success) {
          // Successful operation: use base delay to prevent timing analysis
          await enforceMinimumTiming(TIMING_DELAYS.AUTH_SUCCESS, startTime);
          return NextResponse.json({
            success: true,
            data: existingResult.data,
          });
        }
      }

      // Failed operation: use failure delay to prevent timing analysis
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        { success: false, error: result.error, code: 'VALIDATION_ERROR' },
        { status: 400 }
      );
    }

    // Successful creation: use base delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_SUCCESS, startTime);
    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[API] Error creating profile', error as Error);
    // Error path: use failure delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create profile',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  const startTime = Date.now(); // Capture start time for timing protection

  try {
    // Apply strict rate limiting for profile deletion (5 attempts per 15 minutes per IP)
    const rateLimitResult = await rateLimiters.auth(request);
    if (rateLimitResult) {
      // Enforce timing even on rate limit failures to prevent timing analysis
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const privyId = request.nextUrl.searchParams.get('privyId');
    const hardDelete =
      request.nextUrl.searchParams.get('hardDelete') === 'true';

    // Validate authentication and authorization
    const authResult = validateAuthAndPrivyId(request, privyId);
    if (!authResult.success) {
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return authResult.response;
    }

    // Use the validated privyId (guaranteed non-null after validation)
    const validatedPrivyId = authResult.validatedPrivyId;

    logger.debug('[API] Deleting profile for Privy ID', {
      privyId: validatedPrivyId.slice(0, 8) + '...',
      hardDelete,
    });

    const result = await userProfileCrudService.deleteProfile(
      validatedPrivyId,
      hardDelete
    );

    if (!result.success) {
      // Failed operation: use failure delay to prevent timing analysis
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        { success: false, error: result.error, code: 'VALIDATION_ERROR' },
        { status: 400 }
      );
    }

    // Successful deletion: use base delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_SUCCESS, startTime);
    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[API] Error deleting profile', error as Error);
    // Error path: use failure delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to delete profile',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
