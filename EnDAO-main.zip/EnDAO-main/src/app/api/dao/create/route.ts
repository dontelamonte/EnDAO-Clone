/**
 * DAO Creation API Route
 *
 * POST - Create a new DAO
 * Browser-safe wrapper for DAOService.createDAO
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { DAOService } from '@/lib/services/dao';
import { userAdminRepository } from '@/lib/data/repositories';
import { CreateDAOFormData } from '@endao/shared-types';
import { logger } from '@/lib/services/logger.service';
import { withValidation } from '@/lib/middleware/api-validation';
import { daoCreateSchema } from '@/lib/validations/api';
import { rateLimiters } from '@/lib/middleware/rate-limit';

interface CreateDAOResponse {
  success: boolean;
  data?: { id: string };
  error?: string;
}

// Wrap the schema in a data property to match the request body structure
const requestSchema = z.object({
  data: daoCreateSchema,
});

export const POST = withValidation(requestSchema)(async (
  request: NextRequest,
  validatedData: { data: CreateDAOFormData }
): Promise<NextResponse<CreateDAOResponse>> => {
  try {
    // Apply rate limiting for critical operations (5 per minute per IP)
    const rateLimitResult = await rateLimiters.critical(request);
    if (rateLimitResult) {
      return rateLimitResult as NextResponse<CreateDAOResponse>; // Rate limit exceeded, return 429 response
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Extract validated data
    const { data } = validatedData;

    // Create DAO using the service
    const daoService = DAOService.getInstance();
    const result = await daoService.createDAO(userId, data);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to create DAO' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[DAO Create API] Error creating DAO', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to create DAO' },
      { status: 500 }
    );
  }
});
