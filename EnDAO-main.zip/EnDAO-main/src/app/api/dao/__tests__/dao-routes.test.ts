/**
 * DAO API Route Validation Tests
 * Tests the actual validation schemas for /api/dao/* endpoints
 *
 * This file tests real code from:
 * - @/lib/validations/api (daoCreateSchema, daoUpdateSchema, daoJoinSchema, etc.)
 * - @/lib/validations/common (commonValidations)
 */

import {
  daoCreateSchema,
  daoUpdateSchema,
  daoJoinSchema,
  daoMemberManagementSchema,
  daoArchiveSchema,
  paginationSchema,
  sortSchema,
  documentId,
  userId,
  createSanitizedString,
} from '@/lib/validations/api';
import { commonValidations } from '@/lib/validations/common';

describe('DAO Validation Schemas', () => {
  describe('daoCreateSchema', () => {
    const validDAO = {
      name: 'Test DAO Organization',
      description:
        'This is a test DAO with a longer description that meets the minimum requirement.',
      slug: 'test-dao',
      category: 'Community' as const,
      isDiscoverable: true,
      joinPermission: 'open' as const,
      tags: ['test', 'community'],
      socialLinks: {},
      settings: {},
    };

    describe('Required Fields', () => {
      it('should accept valid DAO data', () => {
        expect(() => daoCreateSchema.parse(validDAO)).not.toThrow();
      });

      it('should require name', () => {
        const { name: _, ...withoutName } = validDAO;
        expect(() => daoCreateSchema.parse(withoutName)).toThrow();
      });

      it('should require description', () => {
        const { description: _, ...withoutDescription } = validDAO;
        expect(() => daoCreateSchema.parse(withoutDescription)).toThrow();
      });

      it('should require slug', () => {
        const { slug: _, ...withoutSlug } = validDAO;
        expect(() => daoCreateSchema.parse(withoutSlug)).toThrow();
      });

      it('should require category', () => {
        const { category: _, ...withoutCategory } = validDAO;
        expect(() => daoCreateSchema.parse(withoutCategory)).toThrow();
      });

      it('should require isDiscoverable', () => {
        const { isDiscoverable: _, ...withoutDiscoverable } = validDAO;
        expect(() => daoCreateSchema.parse(withoutDiscoverable)).toThrow();
      });

      it('should require joinPermission', () => {
        const { joinPermission: _, ...withoutJoinPermission } = validDAO;
        expect(() => daoCreateSchema.parse(withoutJoinPermission)).toThrow();
      });
    });

    describe('Name Validation', () => {
      it('should require name to be at least 3 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, name: 'ab' })
        ).toThrow();
      });

      it('should accept name with exactly 3 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, name: 'abc' })
        ).not.toThrow();
      });

      it('should reject name with 100+ characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, name: 'a'.repeat(101) })
        ).toThrow();
      });

      it('should reject XSS in name', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            name: '<script>alert(1)</script>',
          })
        ).toThrow();
      });

      it('should reject SQL injection in name', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, name: "'; DROP TABLE daos; --" })
        ).toThrow();
      });
    });

    describe('Description Validation', () => {
      it('should require description to be at least 10 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, description: 'Too short' })
        ).toThrow();
      });

      it('should accept description with exactly 10 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, description: '1234567890' })
        ).not.toThrow();
      });

      it('should reject description over 5000 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, description: 'a'.repeat(5001) })
        ).toThrow();
      });
    });

    describe('Slug Validation', () => {
      it('should accept valid slug', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'valid-slug' })
        ).not.toThrow();
      });

      it('should accept slug with numbers', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'my-dao-123' })
        ).not.toThrow();
      });

      it('should reject slug with uppercase letters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'Invalid-Slug' })
        ).toThrow();
      });

      it('should reject slug with spaces', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'has space' })
        ).toThrow();
      });

      it('should reject slug with underscores', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'has_underscore' })
        ).toThrow();
      });

      it('should reject slug with double hyphens', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'double--hyphen' })
        ).toThrow();
      });

      it('should reject slug with leading hyphen', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: '-leading' })
        ).toThrow();
      });

      it('should reject slug with trailing hyphen', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'trailing-' })
        ).toThrow();
      });

      it('should reject slug shorter than 3 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'ab' })
        ).toThrow();
      });

      it('should reject slug longer than 50 characters', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, slug: 'a'.repeat(51) })
        ).toThrow();
      });
    });

    describe('Category Validation', () => {
      it('should accept Community category', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, category: 'Community' })
        ).not.toThrow();
      });

      it('should accept Commerce category', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, category: 'Commerce' })
        ).not.toThrow();
      });

      it('should reject invalid category', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, category: 'InvalidCategory' })
        ).toThrow();
      });
    });

    describe('joinPermission Validation', () => {
      it('should accept open permission', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, joinPermission: 'open' })
        ).not.toThrow();
      });

      it('should accept request permission', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, joinPermission: 'request' })
        ).not.toThrow();
      });

      it('should accept invite-only permission', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, joinPermission: 'invite-only' })
        ).not.toThrow();
      });

      it('should reject invalid permission', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, joinPermission: 'closed' })
        ).toThrow();
      });
    });

    describe('Social Links Validation', () => {
      it('should accept valid Discord URL', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            socialLinks: { discord: 'https://discord.gg/test' },
          })
        ).not.toThrow();
      });

      it('should reject invalid Discord URL', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            socialLinks: { discord: 'https://example.com/not-discord' },
          })
        ).toThrow();
      });

      it('should accept valid Twitter URL', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            socialLinks: { twitter: 'https://twitter.com/test' },
          })
        ).not.toThrow();
      });

      it('should accept valid X.com URL', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            socialLinks: { twitter: 'https://x.com/test' },
          })
        ).not.toThrow();
      });

      it('should accept empty social link strings', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            socialLinks: { discord: '', twitter: '' },
          })
        ).not.toThrow();
      });

      it('should accept valid website URL', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            socialLinks: { website: 'https://example.com' },
          })
        ).not.toThrow();
      });
    });

    describe('Tags Validation', () => {
      it('should accept empty tags array', () => {
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, tags: [] })
        ).not.toThrow();
      });

      it('should accept valid tags', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            tags: ['tech', 'community', 'governance'],
          })
        ).not.toThrow();
      });

      it('should reject more than 20 tags', () => {
        const tooManyTags = Array(21).fill('tag');
        expect(() =>
          daoCreateSchema.parse({ ...validDAO, tags: tooManyTags })
        ).toThrow();
      });

      it('should reject tags with XSS', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            tags: ['<script>alert(1)</script>'],
          })
        ).toThrow();
      });
    });

    describe('Settings Validation', () => {
      it('should accept valid governance settings', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            settings: {
              votingPeriodDays: 7,
              quorumPercentage: 20,
              passThreshold: 50,
            },
          })
        ).not.toThrow();
      });

      it('should reject voting period over 30 days', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            settings: { votingPeriodDays: 31 },
          })
        ).toThrow();
      });

      it('should reject voting period under 1 day', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            settings: { votingPeriodDays: 0 },
          })
        ).toThrow();
      });

      it('should reject quorum percentage over 100', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            settings: { quorumPercentage: 101 },
          })
        ).toThrow();
      });

      it('should accept proposal approval settings', () => {
        expect(() =>
          daoCreateSchema.parse({
            ...validDAO,
            settings: {
              proposalApproval: {
                mode: 'auto',
                reviewDurationHours: 24,
              },
            },
          })
        ).not.toThrow();
      });
    });
  });

  describe('daoUpdateSchema', () => {
    it('should accept valid update', () => {
      const validUpdate = {
        daoId: 'valid-dao-id-123',
        updates: {
          name: 'Updated DAO Name',
          description: 'Updated description that is long enough',
        },
      };
      expect(() => daoUpdateSchema.parse(validUpdate)).not.toThrow();
    });

    it('should require daoId', () => {
      const withoutDaoId = {
        updates: { name: 'Updated Name' },
      };
      expect(() => daoUpdateSchema.parse(withoutDaoId)).toThrow();
    });

    it('should not allow slug in updates', () => {
      // Slug is omitted from the partial schema
      const withSlugAttempt = {
        daoId: 'valid-dao-id-123',
        updates: {
          name: 'Updated Name',
          slug: 'new-slug', // This should be stripped/ignored, not cause an error
        },
      };
      // The schema omits slug, so it should parse but slug won't be in result
      const result = daoUpdateSchema.parse(withSlugAttempt);
      expect(result.updates).not.toHaveProperty('slug');
    });

    it('should accept partial updates', () => {
      const partialUpdate = {
        daoId: 'valid-dao-id-123',
        updates: {
          isDiscoverable: false,
        },
      };
      expect(() => daoUpdateSchema.parse(partialUpdate)).not.toThrow();
    });
  });

  describe('daoJoinSchema', () => {
    it('should accept valid join request', () => {
      const validJoin = {
        daoId: 'valid-dao-id-123',
      };
      expect(() => daoJoinSchema.parse(validJoin)).not.toThrow();
    });

    it('should accept join request with wallet address', () => {
      const joinWithWallet = {
        daoId: 'valid-dao-id-123',
        walletAddress: '0x1234567890123456789012345678901234567890',
      };
      expect(() => daoJoinSchema.parse(joinWithWallet)).not.toThrow();
    });

    it('should accept join request with message', () => {
      const joinWithMessage = {
        daoId: 'valid-dao-id-123',
        message: 'I would like to join this DAO because I support the mission.',
      };
      expect(() => daoJoinSchema.parse(joinWithMessage)).not.toThrow();
    });

    it('should reject invalid wallet address', () => {
      const invalidWallet = {
        daoId: 'valid-dao-id-123',
        walletAddress: 'not-a-valid-address',
      };
      expect(() => daoJoinSchema.parse(invalidWallet)).toThrow();
    });

    it('should reject message over 1000 characters', () => {
      const longMessage = {
        daoId: 'valid-dao-id-123',
        message: 'a'.repeat(1001),
      };
      expect(() => daoJoinSchema.parse(longMessage)).toThrow();
    });
  });

  describe('daoMemberManagementSchema', () => {
    it('should accept valid promote action', () => {
      const promoteAction = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'promote' as const,
        role: 'admin' as const,
      };
      expect(() =>
        daoMemberManagementSchema.parse(promoteAction)
      ).not.toThrow();
    });

    it('should accept valid demote action', () => {
      const demoteAction = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'demote' as const,
        role: 'member' as const,
      };
      expect(() => daoMemberManagementSchema.parse(demoteAction)).not.toThrow();
    });

    it('should accept valid remove action', () => {
      const removeAction = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'remove' as const,
        reason: 'Inactive for 90 days',
      };
      expect(() => daoMemberManagementSchema.parse(removeAction)).not.toThrow();
    });

    it('should accept valid ban action', () => {
      const banAction = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'ban' as const,
        reason: 'Violation of community guidelines',
      };
      expect(() => daoMemberManagementSchema.parse(banAction)).not.toThrow();
    });

    it('should accept valid unban action', () => {
      const unbanAction = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'unban' as const,
      };
      expect(() => daoMemberManagementSchema.parse(unbanAction)).not.toThrow();
    });

    it('should reject invalid action', () => {
      const invalidAction = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'delete',
      };
      expect(() => daoMemberManagementSchema.parse(invalidAction)).toThrow();
    });

    it('should reject invalid role', () => {
      const invalidRole = {
        daoId: 'valid-dao-id-123',
        memberId: 'user-123',
        action: 'promote' as const,
        role: 'superadmin',
      };
      expect(() => daoMemberManagementSchema.parse(invalidRole)).toThrow();
    });
  });

  describe('daoArchiveSchema', () => {
    it('should accept valid archive request', () => {
      const validArchive = {
        daoId: 'valid-dao-id-123',
        reason: 'inactive' as const,
      };
      expect(() => daoArchiveSchema.parse(validArchive)).not.toThrow();
    });

    it('should accept all valid reason values', () => {
      const reasons = ['inactive', 'completed', 'violation', 'other'] as const;
      reasons.forEach((reason) => {
        expect(() =>
          daoArchiveSchema.parse({
            daoId: 'valid-dao-id-123',
            reason,
          })
        ).not.toThrow();
      });
    });

    it('should accept optional notes', () => {
      const archiveWithNotes = {
        daoId: 'valid-dao-id-123',
        reason: 'other' as const,
        notes: 'Additional context for archiving this DAO.',
      };
      expect(() => daoArchiveSchema.parse(archiveWithNotes)).not.toThrow();
    });

    it('should reject invalid reason', () => {
      const invalidReason = {
        daoId: 'valid-dao-id-123',
        reason: 'deleted',
      };
      expect(() => daoArchiveSchema.parse(invalidReason)).toThrow();
    });
  });
});

describe('Common Validation Schemas', () => {
  describe('documentId', () => {
    it('should accept valid document ID', () => {
      expect(() => documentId.parse('dao-123')).not.toThrow();
      expect(() => documentId.parse('user_abc-123')).not.toThrow();
    });

    it('should reject empty document ID', () => {
      expect(() => documentId.parse('')).toThrow();
    });

    it('should reject document ID starting with special char', () => {
      expect(() => documentId.parse('_invalid')).toThrow();
      expect(() => documentId.parse('-invalid')).toThrow();
    });

    it('should accept document ID starting with letter or number', () => {
      expect(() => documentId.parse('abc123')).not.toThrow();
      expect(() => documentId.parse('123abc')).not.toThrow();
    });
  });

  describe('userId', () => {
    it('should accept valid user ID', () => {
      expect(() => userId.parse('user-123')).not.toThrow();
      expect(() => userId.parse('abc_123')).not.toThrow();
    });

    it('should reject empty user ID', () => {
      expect(() => userId.parse('')).toThrow();
    });

    it('should reject user ID with invalid characters', () => {
      expect(() => userId.parse('user@123')).toThrow();
      expect(() => userId.parse('user.123')).toThrow();
    });
  });

  describe('paginationSchema', () => {
    it('should accept valid pagination', () => {
      const validPagination = { page: 1, limit: 20 };
      expect(() => paginationSchema.parse(validPagination)).not.toThrow();
    });

    it('should apply default values', () => {
      const result = paginationSchema.parse({});
      expect(result.page).toBe(1);
      expect(result.limit).toBe(20);
    });

    it('should reject page less than 1', () => {
      expect(() => paginationSchema.parse({ page: 0 })).toThrow();
    });

    it('should reject limit over 100', () => {
      expect(() => paginationSchema.parse({ limit: 101 })).toThrow();
    });

    it('should coerce string values to numbers', () => {
      const result = paginationSchema.parse({ page: '2', limit: '50' });
      expect(result.page).toBe(2);
      expect(result.limit).toBe(50);
    });
  });

  describe('sortSchema', () => {
    it('should accept valid sort options', () => {
      const validSort = { sortBy: 'createdAt', sortOrder: 'desc' as const };
      expect(() => sortSchema.parse(validSort)).not.toThrow();
    });

    it('should default sortOrder to desc', () => {
      const result = sortSchema.parse({});
      expect(result.sortOrder).toBe('desc');
    });

    it('should accept asc sort order', () => {
      const result = sortSchema.parse({ sortOrder: 'asc' });
      expect(result.sortOrder).toBe('asc');
    });

    it('should reject invalid sortBy format', () => {
      expect(() => sortSchema.parse({ sortBy: '123invalid' })).toThrow();
      expect(() => sortSchema.parse({ sortBy: 'has-hyphen' })).toThrow();
    });
  });

  describe('commonValidations.slug', () => {
    const slugSchema = commonValidations.slug;

    it('should accept valid slug', () => {
      expect(() => slugSchema.parse('valid-slug')).not.toThrow();
      expect(() => slugSchema.parse('my-dao-123')).not.toThrow();
    });

    it('should reject double hyphens', () => {
      expect(() => slugSchema.parse('invalid--slug')).toThrow();
    });

    it('should reject leading hyphen', () => {
      expect(() => slugSchema.parse('-invalid')).toThrow();
    });

    it('should reject trailing hyphen', () => {
      expect(() => slugSchema.parse('invalid-')).toThrow();
    });

    it('should reject uppercase', () => {
      expect(() => slugSchema.parse('Invalid')).toThrow();
    });
  });

  describe('commonValidations.walletAddress', () => {
    const walletSchema = commonValidations.walletAddress;

    it('should accept valid Ethereum address', () => {
      expect(() =>
        walletSchema.parse('0x1234567890123456789012345678901234567890')
      ).not.toThrow();
    });

    it('should reject address without 0x prefix', () => {
      expect(() =>
        walletSchema.parse('1234567890123456789012345678901234567890')
      ).toThrow();
    });

    it('should reject address with wrong length', () => {
      expect(() => walletSchema.parse('0x123')).toThrow();
      expect(() =>
        walletSchema.parse('0x12345678901234567890123456789012345678901234')
      ).toThrow();
    });

    it('should reject address with invalid characters', () => {
      expect(() =>
        walletSchema.parse('0xGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG')
      ).toThrow();
    });
  });

  describe('commonValidations.email', () => {
    const emailSchema = commonValidations.email;

    it('should accept valid email', () => {
      expect(() => emailSchema.parse('test@example.com')).not.toThrow();
    });

    it('should reject invalid email', () => {
      expect(() => emailSchema.parse('invalid-email')).toThrow();
    });

    it('should reject empty email', () => {
      expect(() => emailSchema.parse('')).toThrow();
    });
  });

  describe('commonValidations.url', () => {
    const urlSchema = commonValidations.url;

    it('should accept valid URL', () => {
      expect(() => urlSchema.parse('https://example.com')).not.toThrow();
    });

    it('should accept HTTP URL', () => {
      expect(() => urlSchema.parse('http://example.com')).not.toThrow();
    });

    it('should reject invalid URL', () => {
      expect(() => urlSchema.parse('not-a-url')).toThrow();
    });
  });
});

describe('Security Validation Patterns', () => {
  describe('createSanitizedString', () => {
    const sanitizedString = createSanitizedString(1, 100);

    it('should reject XSS script tags', () => {
      expect(() =>
        sanitizedString.parse('<script>alert(1)</script>')
      ).toThrow();
    });

    it('should reject javascript: protocol', () => {
      expect(() => sanitizedString.parse('javascript:void(0)')).toThrow();
    });

    it('should reject vbscript: protocol', () => {
      expect(() => sanitizedString.parse('vbscript:msgbox(1)')).toThrow();
    });

    it('should reject onload handlers', () => {
      expect(() => sanitizedString.parse('onload=alert(1)')).toThrow();
    });

    it('should reject onerror handlers', () => {
      expect(() => sanitizedString.parse('onerror=alert(1)')).toThrow();
    });

    it('should reject UNION SELECT injection', () => {
      expect(() =>
        sanitizedString.parse('1 UNION SELECT * FROM users')
      ).toThrow();
    });

    it('should reject DROP TABLE injection', () => {
      expect(() => sanitizedString.parse('; DROP TABLE users;')).toThrow();
    });

    it('should reject DELETE injection', () => {
      expect(() => sanitizedString.parse('; DELETE FROM users;')).toThrow();
    });

    it('should accept normal business text', () => {
      expect(() =>
        sanitizedString.parse('We select the best candidates')
      ).not.toThrow();
      expect(() =>
        sanitizedString.parse('Update your profile settings')
      ).not.toThrow();
    });
  });
});
