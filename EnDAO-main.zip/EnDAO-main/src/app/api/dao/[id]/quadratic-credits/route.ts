/**
 * Quadratic Credits API Route
 * GET - Get user's quadratic voting credits
 * POST - Initialize credits for a proposal
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { quadraticCreditService } from '@/lib/services/voting';
import { userAdminRepository } from '@/lib/data/repositories/supabase';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;
    const authContext = await getAuthContext(request);

    if (!authContext?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Resolve Privy ID to internal UUID if needed
    let userId = authContext.uid;
    if (
      authContext.privyUserId &&
      authContext.privyUserId.startsWith('did:privy:')
    ) {
      const user = await userAdminRepository.findByPrivyId(
        authContext.privyUserId
      );
      if (user) {
        userId = user.id;
      }
    }

    // Get optional proposalId from query params
    const { searchParams } = new URL(request.url);
    const proposalId = searchParams.get('proposalId') || undefined;

    const result = await quadraticCreditService.getCredits(
      daoId,
      userId,
      proposalId
    );

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 });
    }

    // If no credits exist yet, return default values
    if (!result.data) {
      return NextResponse.json({
        totalCredits: 100,
        usedCredits: 0,
        remainingCredits: 100,
        initialized: false,
      });
    }

    return NextResponse.json({
      ...result.data,
      initialized: true,
    });
  } catch (error) {
    logger.error(
      'Error fetching quadratic credits',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/quadratic-credits', method: 'GET' }
    );
    return NextResponse.json(
      { error: 'Failed to fetch credits' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;
    const authContext = await getAuthContext(request);

    if (!authContext?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Resolve Privy ID to internal UUID if needed
    let userId = authContext.uid;
    if (
      authContext.privyUserId &&
      authContext.privyUserId.startsWith('did:privy:')
    ) {
      const user = await userAdminRepository.findByPrivyId(
        authContext.privyUserId
      );
      if (user) {
        userId = user.id;
      }
    }

    const body = await request.json();
    const { proposalId, defaultCredits } = body;

    const result = await quadraticCreditService.initializeCredits({
      daoId,
      userId,
      proposalId,
      defaultCredits,
    });

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: result.error?.includes('active member') ? 403 : 500 }
      );
    }

    return NextResponse.json(result.data);
  } catch (error) {
    logger.error(
      'Error initializing quadratic credits',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/quadratic-credits', method: 'POST' }
    );
    return NextResponse.json(
      { error: 'Failed to initialize credits' },
      { status: 500 }
    );
  }
}
