/**
 * Quadratic Vote Cost API Route
 * GET - Calculate vote cost info for a given strength
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { quadraticCreditService } from '@/lib/services/voting';
import { userAdminRepository } from '@/lib/data/repositories/supabase';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;
    const authContext = await getAuthContext(request);

    if (!authContext?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Resolve Privy ID to internal UUID if needed
    let userId = authContext.uid;
    if (
      authContext.privyUserId &&
      authContext.privyUserId.startsWith('did:privy:')
    ) {
      const user = await userAdminRepository.findByPrivyId(
        authContext.privyUserId
      );
      if (user) {
        userId = user.id;
      }
    }

    // Get query params
    const { searchParams } = new URL(request.url);
    const voteStrength = parseInt(searchParams.get('strength') || '1', 10);
    const proposalId = searchParams.get('proposalId') || undefined;

    if (voteStrength < 1) {
      return NextResponse.json(
        { error: 'Vote strength must be at least 1' },
        { status: 400 }
      );
    }

    const result = await quadraticCreditService.getVoteCostInfo(
      daoId,
      userId,
      voteStrength,
      proposalId
    );

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 });
    }

    return NextResponse.json(result.data);
  } catch (error) {
    logger.error(
      'Error calculating vote cost',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/quadratic-credits/vote-cost', method: 'GET' }
    );
    return NextResponse.json(
      { error: 'Failed to calculate vote cost' },
      { status: 500 }
    );
  }
}
