/**
 * DAO Discussions API Route
 *
 * GET - Fetch discussions for a DAO with creator info
 * POST - Create a new discussion
 * Server-side endpoint to avoid browser-safety violations
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  userAdminRepository,
  daoAdminRepository,
  daoMemberAdminRepository,
  discussionAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { DiscussionStatus } from '@/lib/data/repositories/supabase/discussion.repository';

interface DiscussionCreateResponse {
  success: boolean;
  data?: { id: string };
  error?: string;
  code?: string;
}

interface DiscussionListResponse {
  success: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Discussion data varies
  data?: any[];
  error?: string;
  code?: string;
}

/**
 * GET - Fetch discussions for a DAO with creator info
 * Uses server-side admin repository for enrichment
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<DiscussionListResponse>> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Get optional filters from query params
    const { searchParams } = new URL(request.url);
    const statusParam = searchParams.get('status');
    const limitParam = searchParams.get('limit');
    const offsetParam = searchParams.get('offset');

    const status = statusParam as DiscussionStatus | undefined;
    const limit = limitParam ? parseInt(limitParam, 10) : 20;
    const offset = offsetParam ? parseInt(offsetParam, 10) : 0;

    // Validate limit and offset
    if (isNaN(limit) || limit < 1 || limit > 100) {
      return NextResponse.json(
        {
          success: false,
          error: 'Limit must be between 1 and 100',
          code: 'INVALID_PARAMETER',
        },
        { status: 400 }
      );
    }

    if (isNaN(offset) || offset < 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'Offset must be 0 or greater',
          code: 'INVALID_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Fetch discussions with creator info using admin repository (server-side)
    const discussions = await discussionAdminRepository.findByDaoWithCreator(
      daoId,
      {
        status,
        limit,
        offset,
      }
    );

    // Add cache headers for public data
    const headers = {
      'Cache-Control': 'public, max-age=30, stale-while-revalidate=15',
    };

    return NextResponse.json(
      {
        success: true,
        data: discussions,
      },
      { headers }
    );
  } catch (error) {
    logger.error(
      '[DAO Discussions API] Error fetching discussions',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch discussions',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}

/**
 * POST - Create a new discussion
 * Requires authentication and DAO membership
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<DiscussionCreateResponse>> {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { title, content, isPinned } = body;

    // Validate required fields
    if (!title || typeof title !== 'string') {
      return NextResponse.json(
        {
          success: false,
          error: 'Title is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    if (!content || typeof content !== 'string') {
      return NextResponse.json(
        {
          success: false,
          error: 'Content is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Validate field lengths
    if (title.length < 3 || title.length > 200) {
      return NextResponse.json(
        {
          success: false,
          error: 'Title must be between 3 and 200 characters',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    if (content.length < 10 || content.length > 10000) {
      return NextResponse.json(
        {
          success: false,
          error: 'Content must be between 10 and 10,000 characters',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Check if user is a member of the DAO
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      supabaseUser.id
    );
    if (!membership || membership.status !== 'active') {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be a member of this DAO to create discussions',
          code: 'NOT_DAO_MEMBER',
        },
        { status: 403 }
      );
    }

    // Only admins/owners can pin discussions on creation
    const canPin = membership.role === 'admin';
    const shouldPin = isPinned === true && canPin;

    // Create discussion via repository
    const discussion = await discussionAdminRepository.createDiscussion({
      daoId,
      createdBy: supabaseUser.id,
      title: title.trim(),
      content: content.trim(),
      status: 'active',
      isPinned: shouldPin,
    });

    logger.info('[DAO Discussions API] Discussion created', {
      discussionId: discussion.id,
      daoId,
      userId: supabaseUser.id,
      title: discussion.title,
    });

    return NextResponse.json({
      success: true,
      data: {
        id: discussion.id,
      },
    });
  } catch (error) {
    logger.error(
      '[DAO Discussions API] Error creating discussion',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create discussion',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
