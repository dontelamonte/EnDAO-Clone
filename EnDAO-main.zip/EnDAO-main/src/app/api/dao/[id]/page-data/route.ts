/**
 * DAO Page Data API Route
 *
 * Batched endpoint that combines all data needed for the DAO overview page.
 * Reduces multiple API calls to a single request.
 *
 * Returns:
 * - DAO details
 * - User permissions
 * - Member count
 * - Active proposals count
 * - Treasury balance (if enabled)
 * - Recent activity summary
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import { MemberPermissionsService } from '@/lib/services/dao/member-permissions';
import { ProposalServiceOrchestrator } from '@/lib/services/proposal';
import { userAdminRepository } from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { getComputedProposalStatus } from '@/lib/utils/proposal-status';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import type { DAO } from '@endao/shared-types';

// Lazy import to avoid browser bundling issues
async function getVerifyAuthToken() {
  const { verifyAuthToken } = await import('@/lib/privy-server');
  return verifyAuthToken;
}

interface UserPermissions {
  isAdmin: boolean;
  isMember: boolean;
  canVote: boolean;
  canPropose: boolean;
  canComment: boolean;
  canViewTreasury: boolean;
  canManageMembers: boolean;
  votingPower: number;
}

interface DAOPageData {
  dao: DAO;
  permissions: UserPermissions;
  memberCount: number;
  activeProposalCount: number;
  treasuryBalance: string | null;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get optional user ID from auth context or Bearer token
    // This route is public (middleware doesn't inject auth headers), so we verify the token directly
    let privyId: string | null = null;
    let internalUserId: string | null = null;

    // First try middleware-set headers (in case route becomes protected)
    const authContext = await getAuthContext(request);
    if (authContext) {
      privyId = authContext.privyUserId;
      internalUserId = authContext.uid;
    }

    // Fall back to Bearer token verification (public route with optional auth)
    if (!privyId) {
      const authHeader = request.headers.get('authorization');
      if (authHeader?.startsWith('Bearer ')) {
        try {
          const verifyAuthToken = await getVerifyAuthToken();
          const tokenResult = await verifyAuthToken(authHeader);

          if (tokenResult.success && tokenResult.claims?.userId) {
            privyId = tokenResult.claims.userId;
            // Look up internal user ID from Privy ID
            const user = await userAdminRepository.findByPrivyId(privyId);
            if (user) {
              internalUserId = user.id;
            }
          }
        } catch (err) {
          // Token verification failed - treat as unauthenticated
          logger.debug('[DAO Page Data API] Token verification failed', {
            error: err instanceof Error ? err.message : 'Unknown error',
          });
        }
      }
    }

    // Fall back to dev auth cookie (for localhost development)
    if (!internalUserId && process.env.NODE_ENV === 'development') {
      const devAuthCookie = request.cookies.get('dev_auth_user');
      if (devAuthCookie?.value) {
        try {
          const decodedValue = decodeURIComponent(devAuthCookie.value);
          const devUser = JSON.parse(decodedValue);
          if (devUser?.uid) {
            internalUserId = devUser.uid;
            privyId = devUser.privyUserId || null;
            logger.debug('[DAO Page Data API] Using dev auth', {
              uid: devUser.uid,
            });
          }
        } catch (err) {
          logger.debug('[DAO Page Data API] Failed to parse dev auth cookie', {
            error: err instanceof Error ? err.message : 'Unknown error',
          });
        }
      }
    }

    // Resolve slug to UUID if needed
    const isUUID =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        daoId
      );

    logger.debug('[DAO Page Data API] Fetching data for DAO', {
      daoId: daoId.substring(0, 15) + '...',
      hasAuth: Boolean(privyId),
      isUUID,
    });

    // Fetch DAO details (use getDAOBySlug for slugs)
    const daoService = DAOService.getInstance();
    const daoResult = isUUID
      ? await daoService.getDAO(daoId)
      : await daoService.getDAOBySlug(daoId);

    if (!daoResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: daoResult.error || 'DAO not found',
          code: 'DAO_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (!daoResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'DAO_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const dao = daoResult.data;

    // Initialize default permissions (for unauthenticated users)
    let permissions: UserPermissions = {
      isAdmin: false,
      isMember: false,
      canVote: false,
      canPropose: false,
      canComment: false,
      canViewTreasury: false,
      canManageMembers: false,
      votingPower: 0,
    };

    // If authenticated, fetch user permissions (use resolved dao.id, not the slug)
    if (internalUserId) {
      // Get comprehensive user permissions
      const permissionsService = MemberPermissionsService.getInstance();
      const permissionsResult = await permissionsService.getUserPermissions(
        dao.id,
        internalUserId
      );

      if (permissionsResult.success && permissionsResult.data) {
        permissions = {
          isAdmin: permissionsResult.data.isAdmin,
          isMember: permissionsResult.data.isActive,
          canVote: permissionsResult.data.canVote,
          canPropose: permissionsResult.data.canCreateProposals,
          canComment: permissionsResult.data.canComment,
          canViewTreasury: permissionsResult.data.canViewTreasury,
          canManageMembers: permissionsResult.data.canManageMembers,
          votingPower: permissionsResult.data.votingPower,
        };
      }
    }

    // Get member count from DAO stats
    const memberCount = dao.stats?.memberCount || dao.memberCount || 0;

    // Get active proposals count (use resolved dao.id, not the slug)
    let activeProposalsCount = 0;
    try {
      const proposalService = ProposalServiceOrchestrator.getInstance();
      const activeResult = await proposalService.getProposalsByStatus(
        dao.id,
        'active',
        1000
      );

      if (activeResult.success && activeResult.data) {
        // Filter to ensure we only count truly active proposals
        const activeProposals = activeResult.data.filter(
          (p) => getComputedProposalStatus(p) === 'active'
        );
        activeProposalsCount = activeProposals.length;
      }
    } catch (err) {
      logger.error(
        '[DAO Page Data API] Error fetching active proposals',
        err as Error
      );
      // Use cached value if available
      activeProposalsCount = dao.stats?.activeProposals || 0;
    }

    // Get treasury balance if treasury is enabled
    let treasuryBalance: string | null = null;
    if (dao.safeAddress && dao.treasuryEnabled) {
      // Use cached value from DAO
      const cachedValue = dao.treasuryValue || 0;
      if (cachedValue >= 1000000) {
        treasuryBalance = `$${(cachedValue / 1000000).toFixed(1)}M`;
      } else if (cachedValue >= 1000) {
        treasuryBalance = `$${(cachedValue / 1000).toFixed(1)}K`;
      } else if (cachedValue > 0) {
        treasuryBalance = `$${cachedValue.toFixed(2)}`;
      } else {
        treasuryBalance = '$0';
      }
    }

    const pageData: DAOPageData = {
      dao,
      permissions,
      memberCount,
      activeProposalCount: activeProposalsCount,
      treasuryBalance,
    };

    return NextResponse.json(
      {
        success: true,
        data: pageData,
      },
      {
        headers: {
          // Cache for 30 seconds (DAO data changes infrequently)
          'Cache-Control': 'public, max-age=30, stale-while-revalidate=15',
        },
      }
    );
  } catch (error) {
    logger.error(
      '[DAO Page Data API] Error fetching page data',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch DAO page data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
