/**
 * DAO Recovery API Route
 *
 * POST - Recover a DAO during grace period
 * Server-side endpoint to avoid browser-safety violations
 */

import { NextRequest, NextResponse } from 'next/server';
import { userAdminRepository } from '@/lib/data/repositories';
import {
  daoSoftDeleteService,
  type RecoveryResult,
} from '@/lib/services/dao/dao-soft-delete.service';
import { logger } from '@/lib/services/logger.service';

interface RecoveryResponse {
  success: boolean;
  data?: RecoveryResult;
  error?: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<RecoveryResponse>> {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Parse request body for optional recovery reason
    let recoveryReason: string | undefined;
    try {
      const body = await request.json();
      recoveryReason = body.recoveryReason;
    } catch {
      // No body or invalid JSON - that's fine, recovery reason is optional
    }

    // Execute recovery
    const result = await daoSoftDeleteService.recoverDAO(
      daoId,
      supabaseUser.id,
      undefined, // authContext
      recoveryReason
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to recover DAO',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to recover DAO',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[DAO Recovery API] Error recovering DAO', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to recover DAO',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
