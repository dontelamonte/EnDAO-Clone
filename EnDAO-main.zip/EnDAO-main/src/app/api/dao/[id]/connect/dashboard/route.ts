/**
 * Stripe Connect Dashboard API
 *
 * POST - Generate Express dashboard login link
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { stripeConnectService } from '@/lib/services/stripe/stripe-connect.service';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories/supabase';
import { logger } from '@/lib/services/logger.service';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * POST /api/dao/[id]/connect/dashboard
 * Generate a login link to the Stripe Express dashboard
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
): Promise<NextResponse> {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    // Verify user is admin of DAO
    const isAdmin = await daoMemberAdminRepository.isAdmin(
      daoId,
      authContext.uid
    );
    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      );
    }

    // Get DAO
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    // Check for Connect account
    if (!dao.stripeConnectAccountId) {
      return NextResponse.json(
        { error: 'No Stripe Connect account found' },
        { status: 400 }
      );
    }

    // Generate dashboard login link
    logger.info('[POST /api/dao/[id]/connect/dashboard] Creating link', {
      daoId,
      accountId: dao.stripeConnectAccountId,
    });

    const result = await stripeConnectService.createDashboardLink(
      dao.stripeConnectAccountId
    );

    if (!result.success) {
      logger.error(
        '[POST /api/dao/[id]/connect/dashboard] Service error',
        new Error(result.error || 'Unknown error'),
        {
          daoId,
          accountId: dao.stripeConnectAccountId,
        }
      );
      return NextResponse.json({ error: result.error }, { status: 500 });
    }

    logger.info('[POST /api/dao/[id]/connect/dashboard] Generated link', {
      daoId,
      userId: authContext.uid,
    });

    return NextResponse.json({
      success: true,
      data: {
        url: result.data,
      },
    });
  } catch (error) {
    logger.error(
      '[POST /api/dao/[id]/connect/dashboard] Error',
      error as Error
    );
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
