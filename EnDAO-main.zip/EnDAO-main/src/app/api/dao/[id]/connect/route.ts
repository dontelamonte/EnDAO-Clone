/**
 * DAO Stripe Connect API
 *
 * POST - Start Connect onboarding
 * GET - Get Connect status
 * DELETE - Disconnect account (admin only)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { stripeConnectService } from '@/lib/services/stripe/stripe-connect.service';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories/supabase';
import { logger } from '@/lib/services/logger.service';
import {
  STRIPE_CONNECT_COUNTRIES,
  type StripeConnectCountry,
} from '@endao/shared-types';

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * POST /api/dao/[id]/connect
 * Start Stripe Connect onboarding
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
): Promise<NextResponse> {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Verify user is admin of DAO
    const isAdmin = await daoMemberAdminRepository.isAdmin(
      daoId,
      supabaseUser.id
    );
    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      );
    }

    // Get DAO
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    // Check if already has Connect account
    if (dao.stripeConnectAccountId && dao.stripeConnectStatus === 'active') {
      return NextResponse.json(
        { error: 'DAO already has an active Stripe Connect account' },
        { status: 400 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { returnUrl, refreshUrl, country } = body;

    if (!returnUrl || !refreshUrl) {
      return NextResponse.json(
        { error: 'returnUrl and refreshUrl are required' },
        { status: 400 }
      );
    }

    // Validate country if provided
    const requestedCountry = country || dao.country || 'US';
    if (
      !(STRIPE_CONNECT_COUNTRIES as readonly string[]).includes(
        requestedCountry
      )
    ) {
      return NextResponse.json(
        {
          error: `Country '${requestedCountry}' is not supported for Stripe Connect`,
        },
        { status: 400 }
      );
    }
    const selectedCountry = requestedCountry as StripeConnectCountry;

    // Create Connect account or get onboarding link for existing
    let result;
    if (dao.stripeConnectAccountId) {
      // Resume onboarding for existing account
      result = await stripeConnectService.createOnboardingLink({
        accountId: dao.stripeConnectAccountId,
        returnUrl,
        refreshUrl,
      });

      if (!result.success) {
        return NextResponse.json({ error: result.error }, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        accountId: dao.stripeConnectAccountId,
        onboardingUrl: result.data,
      });
    } else {
      // Create new Connect account
      result = await stripeConnectService.createConnectAccount({
        daoId,
        daoName: dao.name,
        adminEmail: authContext.email || '',
        returnUrl,
        refreshUrl,
        country: selectedCountry,
      });

      // Update DAO with country if not already set
      if (!dao.country && selectedCountry) {
        await daoAdminRepository.update(daoId, { country: selectedCountry });
      }

      if (!result.success) {
        return NextResponse.json({ error: result.error }, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        accountId: result.data?.accountId,
        onboardingUrl: result.data?.onboardingUrl,
      });
    }
  } catch (error) {
    logger.error('[POST /api/dao/[id]/connect] Error', error as Error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/dao/[id]/connect
 * Get Connect account status
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
): Promise<NextResponse> {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Verify user is member of DAO
    const isMember = await daoMemberAdminRepository.isMember(
      daoId,
      supabaseUser.id
    );
    if (!isMember) {
      return NextResponse.json(
        { error: 'Member access required' },
        { status: 403 }
      );
    }

    // Get DAO
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    // If no Connect account, return not started status
    if (!dao.stripeConnectAccountId) {
      return NextResponse.json({
        success: true,
        data: {
          status: 'not_started',
          hasAccount: false,
        },
      });
    }

    // Get live status from Stripe
    const result = await stripeConnectService.getAccountStatus(
      dao.stripeConnectAccountId
    );

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 });
    }

    // Sync status if changed
    if (result.data?.status !== dao.stripeConnectStatus) {
      await stripeConnectService.syncAccountStatus(
        daoId,
        dao.stripeConnectAccountId
      );
    }

    // For active accounts, fetch additional stats
    let stats = null;
    if (result.data?.status === 'active') {
      const statsResult = await stripeConnectService.getAccountStats(
        dao.stripeConnectAccountId
      );
      if (statsResult.success) {
        stats = statsResult.data;
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        ...result.data,
        hasAccount: true,
        stats,
      },
    });
  } catch (error) {
    logger.error('[GET /api/dao/[id]/connect] Error', error as Error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/dao/[id]/connect
 * Disconnect Stripe Connect account (does not delete from Stripe)
 */
export async function DELETE(
  request: NextRequest,
  { params }: RouteParams
): Promise<NextResponse> {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Verify user is admin of DAO
    const isAdmin = await daoMemberAdminRepository.isAdmin(
      daoId,
      supabaseUser.id
    );
    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      );
    }

    // Update DAO to remove Connect association
    await daoAdminRepository.update(daoId, {
      stripeConnectAccountId: null,
      stripeConnectStatus: 'not_started',
    });

    logger.info('[DELETE /api/dao/[id]/connect] Disconnected account', {
      daoId,
      userId: supabaseUser.id,
    });

    return NextResponse.json({
      success: true,
      message: 'Stripe Connect account disconnected',
    });
  } catch (error) {
    logger.error('[DELETE /api/dao/[id]/connect] Error', error as Error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
