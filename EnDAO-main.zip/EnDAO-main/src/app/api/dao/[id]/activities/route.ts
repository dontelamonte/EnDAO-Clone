/**
 * DAO Activities API Route
 *
 * Server-side endpoint for fetching DAO activities.
 * Public endpoint - no authentication required for viewing activities.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  activityAdminRepository,
  toSharedActivity,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Get query params for date range (default: last 30 days)
    const { searchParams } = new URL(request.url);
    const daysParam = searchParams.get('days');
    const days = daysParam ? parseInt(daysParam, 10) : 30;
    const limitParam = searchParams.get('limit');
    const limit = limitParam ? parseInt(limitParam, 10) : 10;

    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Fetch activities
    const activities = await activityAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: daoId },
        { field: 'createdAt', operator: '>=', value: startDate.toISOString() },
        { field: 'createdAt', operator: '<=', value: endDate.toISOString() },
      ],
      orderBy: [{ field: 'createdAt', direction: 'desc' }],
      limit,
    });

    return NextResponse.json({
      success: true,
      data: activities.map(toSharedActivity),
    });
  } catch (error) {
    logger.error(
      '[DAO Activities API] Error fetching activities',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch activities' },
      { status: 500 }
    );
  }
}
