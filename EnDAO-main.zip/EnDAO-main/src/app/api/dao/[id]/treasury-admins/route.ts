/**
 * Treasury Admins API Route
 *
 * Server-side endpoint for fetching treasury admins for a DAO.
 * Maps Privy ID to Supabase UUID before querying.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  treasuryAdminAdminRepository,
  treasuryConfigAdminRepository,
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface TreasuryAdmin {
  userId: string;
  privyUserId?: string;
  walletAddress?: string;
  displayName: string;
  email?: string;
  canSign: boolean;
  canExecute: boolean;
  canInitiate: boolean;
  canAddAdmin: boolean;
  canRemoveAdmin: boolean;
  order: number;
  role: string;
  status: string;
  signatureCount?: number;
  lastActivity?: string;
  addedBy?: string;
  addedAt: string;
}

interface TreasuryConfig {
  daoId: string;
  safeAddress?: string;
  chainId: number;
  treasuryAdmins: string[];
  requiredSignatures: number;
  allowSingleAdminAddition: boolean;
  removalRequiresProposal: boolean;
  emergencyPauseEnabled: boolean;
  adminRotationCooldown: number;
  lastRotationAt?: string;
  createdAt: string;
  updatedAt: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Get treasury admins
    let admins: TreasuryAdmin[] = [];
    const repoAdmins = await treasuryAdminAdminRepository.findByDao(daoId);

    if (repoAdmins.length > 0) {
      admins = await Promise.all(
        repoAdmins.map(async (repoAdmin, index) => {
          // Enrich with user profile data if missing
          let privyUserId = repoAdmin.privyUserId;
          let walletAddress = repoAdmin.walletAddress;
          let displayName = repoAdmin.displayName;

          if (!privyUserId || !walletAddress || !displayName) {
            try {
              const user = await userAdminRepository.findById(repoAdmin.userId);
              if (user) {
                privyUserId = privyUserId || user.privyId;
                walletAddress = walletAddress || user.primaryWallet || '';
                displayName =
                  displayName ||
                  user.displayName ||
                  user.username ||
                  'Unknown Admin';
              }
            } catch (err) {
              logger.warn('Failed to fetch user profile for treasury admin', {
                userId: repoAdmin.userId,
              });
            }
          }

          return {
            userId: repoAdmin.userId,
            privyUserId,
            walletAddress,
            displayName: displayName || 'Unknown Admin',
            email: repoAdmin.email,
            canSign: repoAdmin.canSign,
            canInitiate: repoAdmin.canInitiate,
            canExecute: repoAdmin.canExecute,
            canAddAdmin: repoAdmin.canAddAdmin,
            canRemoveAdmin: repoAdmin.canRemoveAdmin,
            order: repoAdmin.order || index + 1,
            role: repoAdmin.role || 'admin',
            status: repoAdmin.status || 'active',
            signatureCount: repoAdmin.signatureCount,
            lastActivity: repoAdmin.lastActivity
              ? repoAdmin.lastActivity instanceof Date
                ? repoAdmin.lastActivity.toISOString()
                : repoAdmin.lastActivity
              : undefined,
            addedBy: repoAdmin.addedBy || undefined,
            addedAt:
              repoAdmin.addedAt instanceof Date
                ? repoAdmin.addedAt.toISOString()
                : repoAdmin.addedAt,
          } as TreasuryAdmin;
        })
      );

      // Sort by order
      admins.sort((a, b) => a.order - b.order);
    } else {
      // Fallback: get DAO admins from membership table
      const adminUserIds =
        await daoMemberAdminRepository.getAdminUserIds(daoId);

      admins = await Promise.all(
        adminUserIds.map(async (adminId: string, index: number) => {
          let privyUserId: string | undefined;
          let walletAddress = '';
          let displayName = 'Unknown Admin';

          try {
            const user = await userAdminRepository.findById(adminId);
            if (user) {
              privyUserId = user.privyId;
              walletAddress = user.primaryWallet || '';
              displayName =
                user.displayName || user.username || 'Unknown Admin';
            }
          } catch (err) {
            logger.warn('Failed to fetch user profile for DAO admin', {
              userId: adminId,
            });
          }

          return {
            userId: adminId,
            privyUserId,
            walletAddress,
            displayName,
            canSign: true,
            canInitiate: true,
            canExecute: true,
            canAddAdmin: true,
            canRemoveAdmin: true,
            order: index + 1,
            role: 'admin',
            status: 'active',
            addedAt: dao.createdAt,
          } as TreasuryAdmin;
        })
      );
    }

    // Find current user's admin status
    const currentUserAdmin =
      admins.find((a) => a.userId === userId || a.privyUserId === privyId) ||
      null;

    // Check if current user is a treasury admin
    const isCurrentUserAdmin = currentUserAdmin !== null;

    // Get treasury config
    let config: TreasuryConfig | null = null;
    const repoConfig = await treasuryConfigAdminRepository.findByDao(daoId);

    if (repoConfig) {
      config = {
        daoId: repoConfig.daoId,
        safeAddress: repoConfig.safeAddress,
        chainId: repoConfig.chainId,
        treasuryAdmins: repoConfig.treasuryAdminIds,
        requiredSignatures: repoConfig.requiredSignatures,
        allowSingleAdminAddition: repoConfig.allowSingleAdminAddition,
        removalRequiresProposal: repoConfig.removalRequiresProposal,
        emergencyPauseEnabled: repoConfig.emergencyPauseEnabled,
        adminRotationCooldown: repoConfig.adminRotationCooldown,
        lastRotationAt: repoConfig.lastRotationAt
          ? repoConfig.lastRotationAt instanceof Date
            ? repoConfig.lastRotationAt.toISOString()
            : repoConfig.lastRotationAt
          : undefined,
        createdAt:
          repoConfig.createdAt instanceof Date
            ? repoConfig.createdAt.toISOString()
            : repoConfig.createdAt,
        updatedAt:
          repoConfig.updatedAt instanceof Date
            ? repoConfig.updatedAt.toISOString()
            : repoConfig.updatedAt,
      };
    } else {
      // Default config
      const now = new Date().toISOString();
      config = {
        daoId,
        chainId: 8453,
        treasuryAdmins: [],
        requiredSignatures: 1,
        allowSingleAdminAddition: true,
        removalRequiresProposal: false,
        emergencyPauseEnabled: true,
        adminRotationCooldown: 24,
        createdAt: now,
        updatedAt: now,
      };
    }

    return NextResponse.json({
      success: true,
      data: {
        admins,
        currentUserAdmin,
        isCurrentUserAdmin,
        config,
      },
    });
  } catch (error) {
    logger.error('[Treasury Admins API] Error fetching admins', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch treasury admins' },
      { status: 500 }
    );
  }
}
