/**
 * Join Requests API Route
 *
 * Server-side endpoint for managing DAO join requests.
 * Includes getting pending requests, approving, and rejecting.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  joinRequestAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';

// Type for user profile summary
interface UserProfileSummary {
  id: string;
  displayName: string | null;
  username: string | null;
  email: string | null;
  avatarUrl: string | null;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Apply rate limiting for join request operations (10/min)
    const rateLimitResult = await rateLimiters.daoJoinLeave(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    const { id: daoId } = await params;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'pending';

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Get join requests
    const requests = await joinRequestAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: daoId },
        { field: 'status', operator: '==', value: status },
      ],
      orderBy: [{ field: 'createdAt', direction: 'desc' }],
    });

    // Get user profiles for all requests
    const userIds = requests.map((r) => r.userId);
    const users =
      userIds.length > 0
        ? await userAdminRepository.findMany({
            filters: [{ field: 'id', operator: 'in', value: userIds }],
          })
        : [];

    const usersMap: Record<string, UserProfileSummary> = {};
    for (const user of users) {
      usersMap[user.id] = {
        id: user.id,
        displayName: user.displayName,
        username: user.username,
        email: user.email,
        avatarUrl: user.avatarUrl,
      };
    }

    // Combine requests with user profiles
    const requestsWithProfiles = requests.map((request) => ({
      ...request,
      userProfile: usersMap[request.userId] || null,
    }));

    return NextResponse.json({
      success: true,
      data: requestsWithProfiles,
    });
  } catch (error) {
    logger.error(
      '[Join Requests API] Error fetching join requests',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch join requests' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Apply rate limiting for join request operations (10/min)
    const rateLimitResult = await rateLimiters.daoJoinLeave(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    const { id: daoId } = await params;
    const body = await request.json();
    const { action, requestId } = body;

    // Get auth context from headers (set by middleware)
    const adminId = request.headers.get('x-auth-uid');
    if (!adminId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    if (!daoId || !requestId || !action) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    if (!['approve', 'reject'].includes(action)) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid action. Must be "approve" or "reject"',
        },
        { status: 400 }
      );
    }

    // Verify the join request exists and is pending
    const joinRequest = await joinRequestAdminRepository.findById(requestId);
    if (!joinRequest) {
      return NextResponse.json(
        { success: false, error: 'Join request not found' },
        { status: 404 }
      );
    }

    if (joinRequest.daoId !== daoId) {
      return NextResponse.json(
        { success: false, error: 'Join request does not belong to this DAO' },
        { status: 400 }
      );
    }

    if (joinRequest.status !== 'pending') {
      return NextResponse.json(
        { success: false, error: 'Join request has already been processed' },
        { status: 400 }
      );
    }

    if (action === 'approve') {
      // Get user info for member creation
      const user = await userAdminRepository.findById(joinRequest.userId);

      // Create member record
      await daoMemberAdminRepository.create({
        daoId,
        userId: joinRequest.userId,
        role: 'member',
        status: 'active',
        isActive: true,
        displayName: user?.displayName || user?.username || null,
        bio: null,
        avatarUrl: user?.avatarUrl || null,
        preferences: {},
        joinedAt: new Date().toISOString(),
      });

      // Update join request status
      await joinRequestAdminRepository.update(requestId, {
        status: 'approved',
        reviewedBy: adminId,
        reviewedAt: new Date().toISOString(),
      });

      return NextResponse.json({
        success: true,
        data: { action: 'approved', requestId },
      });
    } else {
      // Reject the request
      await joinRequestAdminRepository.update(requestId, {
        status: 'rejected',
        reviewedBy: adminId,
        reviewedAt: new Date().toISOString(),
      });

      return NextResponse.json({
        success: true,
        data: { action: 'rejected', requestId },
      });
    }
  } catch (error) {
    logger.error(
      '[Join Requests API] Error processing join request',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to process join request' },
      { status: 500 }
    );
  }
}
