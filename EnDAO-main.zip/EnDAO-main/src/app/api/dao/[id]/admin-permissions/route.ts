/**
 * Admin Permissions API Route
 *
 * Server-side endpoint for checking user's admin permissions in a DAO.
 * Handles both DAO membership and treasury admin permissions.
 * Maps Privy ID to Supabase UUID before querying.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  treasuryAdminAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface AdminPermissions {
  // Core permissions
  canEditDAO: boolean;
  canManageMembers: boolean;
  canCreateProposals: boolean;
  canModerateContent: boolean;
  canManageSettings: boolean;
  canInviteMembers: boolean;
  canRemoveMembers: boolean;

  // Advanced permissions
  canChangeRoles: boolean;
  canManageTreasury: boolean;
  canDeleteDAO: boolean;

  // Governance permissions
  canEnableMultiSig: boolean;
  canProposeGovernanceChange: boolean;
  canApproveProposals: boolean;
  requiresMultiSig: boolean;

  // Computed properties
  isAdmin: boolean;
  isMember: boolean;

  // Member data
  memberRole: string | null;
  membershipId: string | null;
}

interface MembershipInfo {
  id: string;
  userId: string;
  daoId: string;
  role: string;
  status: string;
  displayName?: string;
  joinedAt: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      // Return default (no permissions) for users not in our system
      return NextResponse.json({
        success: true,
        data: {
          permissions: getDefaultPermissions(),
          membership: null,
          isTreasuryAdmin: false,
        },
      });
    }

    const userId = supabaseUser.id;

    // Verify DAO exists and get settings
    // Support both UUID and slug lookups
    const UUID_REGEX =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    let dao = UUID_REGEX.test(daoId)
      ? await daoAdminRepository.findById(daoId)
      : await daoAdminRepository.findBySlug(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Use the resolved DAO ID (UUID) for subsequent queries
    const resolvedDaoId = dao.id;

    // Get user's membership
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      resolvedDaoId,
      userId
    );

    // Check if user is a treasury admin
    const isTreasuryAdmin = await treasuryAdminAdminRepository.isAdmin(
      resolvedDaoId,
      userId
    );

    // Calculate permissions - transform DAO to the expected format
    const daoForPermissions = {
      governanceSettings: dao.governanceSettings as Record<string, unknown>,
      settings: dao.settings as Record<string, unknown>,
      treasuryEnabled: dao.safeAddress != null,
    };
    const permissions = calculatePermissions(
      daoForPermissions,
      membership,
      isTreasuryAdmin
    );

    // Prepare membership info for response
    let membershipInfo: MembershipInfo | null = null;
    if (membership) {
      membershipInfo = {
        id: membership.id,
        userId: membership.userId,
        daoId: membership.daoId,
        role: membership.role,
        status: membership.status,
        displayName: membership.displayName ?? undefined,
        joinedAt: membership.joinedAt,
      };
    }

    return NextResponse.json({
      success: true,
      data: {
        permissions,
        membership: membershipInfo,
        isTreasuryAdmin,
      },
    });
  } catch (error) {
    logger.error(
      '[Admin Permissions API] Error checking permissions',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to check permissions' },
      { status: 500 }
    );
  }
}

function getDefaultPermissions(): AdminPermissions {
  return {
    canEditDAO: false,
    canManageMembers: false,
    canCreateProposals: false,
    canModerateContent: false,
    canManageSettings: false,
    canInviteMembers: false,
    canRemoveMembers: false,
    canChangeRoles: false,
    canManageTreasury: false,
    canDeleteDAO: false,
    canEnableMultiSig: false,
    canProposeGovernanceChange: false,
    canApproveProposals: false,
    requiresMultiSig: false,
    isAdmin: false,
    isMember: false,
    memberRole: null,
    membershipId: null,
  };
}

function calculatePermissions(
  dao: {
    governanceSettings?: Record<string, unknown>;
    settings?: Record<string, unknown>;
    admins?: string[];
    treasuryEnabled?: boolean;
  },
  membership: { id: string; role: string; status?: string } | null,
  isTreasuryAdmin: boolean
): AdminPermissions {
  // No membership - check for treasury admin only
  if (!membership || membership.status !== 'active') {
    return {
      ...getDefaultPermissions(),
      canManageTreasury: isTreasuryAdmin,
      requiresMultiSig:
        (dao.governanceSettings?.requireMultiSigForCritical as boolean) ||
        false,
    };
  }

  const role = membership.role;
  // Owner and admin roles both have full admin permissions
  const isAdmin = role === 'admin';
  const isMember = isAdmin || role === 'member';

  const governanceSettings = dao.governanceSettings || {};
  const settings = dao.settings || {};
  const requiresMultiSig =
    (governanceSettings.requireMultiSigForCritical as boolean) || false;

  // Base permissions
  const basePermissions = {
    isAdmin,
    isMember,
    memberRole: role,
    membershipId: membership.id,
    requiresMultiSig,
  };

  // Admin permissions (full access)
  if (isAdmin) {
    const admins = dao.admins || [];
    return {
      ...basePermissions,
      canEditDAO: true,
      canManageMembers: true,
      canCreateProposals: true,
      canModerateContent: true,
      canManageSettings: true,
      canInviteMembers: true,
      canRemoveMembers: true,
      canChangeRoles: true,
      canManageTreasury: isTreasuryAdmin || (!!dao.treasuryEnabled && isAdmin),
      canDeleteDAO: true,
      canEnableMultiSig: isAdmin && !requiresMultiSig && admins.length >= 2,
      canProposeGovernanceChange: true,
      canApproveProposals: true,
    };
  }

  // Member permissions
  if (isMember) {
    return {
      ...basePermissions,
      canEditDAO: false,
      canManageMembers: false,
      canCreateProposals: (settings.allowPublicProposals as boolean) || false,
      canModerateContent: false,
      canManageSettings: false,
      canInviteMembers: (settings.allowMemberInvites as boolean) || false,
      canRemoveMembers: false,
      canChangeRoles: false,
      canManageTreasury: isTreasuryAdmin,
      canDeleteDAO: false,
      canEnableMultiSig: false,
      canProposeGovernanceChange: false,
      canApproveProposals: false,
    };
  }

  // Default (observer or unknown role)
  return {
    ...getDefaultPermissions(),
    memberRole: role,
    membershipId: membership.id,
    canManageTreasury: isTreasuryAdmin,
    requiresMultiSig,
  };
}
