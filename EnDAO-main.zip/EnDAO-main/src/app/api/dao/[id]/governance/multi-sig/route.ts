/**
 * Multi-sig Governance API Route
 *
 * Handles multi-signature governance operations for DAOs.
 * Requires authentication and admin permissions.
 *
 * POST - Enable multi-sig protection
 * DELETE - Disable multi-sig protection (creates proposal)
 * PATCH - Change multi-sig threshold
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { daoGovernanceUpdateService } from '@/lib/services/dao/dao-governance-update.service';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import { z } from 'zod';
import type { DAO } from '@endao/shared-types';

// Validation schemas
const enableMultiSigSchema = z.object({
  adminName: z.string().optional(),
});

const disableMultiSigSchema = z.object({
  adminName: z.string().optional(),
  reason: z.string().min(10, 'Reason must be at least 10 characters').max(500),
});

const changeThresholdSchema = z.object({
  threshold: z.number().int().min(1),
  adminName: z.string().optional(),
  reason: z.string().min(10, 'Reason must be at least 10 characters').max(500),
});

/**
 * Helper to get authenticated user and validate admin permissions
 */
async function getAuthenticatedAdmin(
  request: NextRequest,
  daoId: string
): Promise<{ userId: string; adminName: string; dao: DAO } | NextResponse> {
  // Get Privy user ID from auth header (set by middleware)
  const privyId =
    request.headers.get('x-auth-privy-id') || request.headers.get('x-auth-uid');

  if (!privyId) {
    return NextResponse.json(
      {
        success: false,
        error: 'Authentication required',
        code: 'AUTH_REQUIRED',
      },
      { status: 401 }
    );
  }

  // Look up Supabase user by Privy ID
  const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
  if (!supabaseUser) {
    return NextResponse.json(
      { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
      { status: 404 }
    );
  }

  const userId = supabaseUser.id;
  const adminName =
    supabaseUser.displayName || supabaseUser.email || 'Unknown Admin';

  // Verify DAO exists
  const daoRepo = await daoAdminRepository.findById(daoId);
  if (!daoRepo) {
    return NextResponse.json(
      { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
      { status: 404 }
    );
  }

  // Get admin members
  const adminMembers = await daoMemberAdminRepository.findAdmins(daoId);
  const adminIds = adminMembers.map((m) => m.userId);

  // Verify user is an admin
  if (!adminIds.includes(userId)) {
    return NextResponse.json(
      {
        success: false,
        error: 'Admin permission required',
        code: 'PERMISSION_DENIED',
      },
      { status: 403 }
    );
  }

  // Build DAO object
  const dao: DAO = {
    id: daoRepo.id,
    admins: adminIds,
    governanceSettings: daoRepo.governanceSettings || {},
  } as DAO;

  return { userId, adminName, dao };
}

/**
 * POST - Enable multi-sig protection
 * Security upgrade - executes immediately
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    // Apply rate limiting for governance operations (5 per minute per IP)
    const rateLimitResult = await rateLimiters.governance(request);
    if (rateLimitResult) {
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }
    const { userId, adminName } = authResult;

    // Parse and validate request body
    const body = await request.json();
    const validation = enableMultiSigSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { adminName: providedAdminName } = validation.data;

    // Enable multi-sig
    const result = await daoGovernanceUpdateService.enableMultiSig(
      daoId,
      userId,
      providedAdminName || adminName
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to enable multi-sig',
          code: 'ENABLE_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Multi-sig protection enabled successfully',
    });
  } catch (error) {
    logger.error('[Multi-sig API] Error enabling multi-sig', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to enable multi-sig',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * DELETE - Disable multi-sig protection
 * Security downgrade - requires unanimous approval, creates proposal
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    // Apply rate limiting for governance operations (5 per minute per IP)
    const rateLimitResult = await rateLimiters.governance(request);
    if (rateLimitResult) {
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }
    const { userId, adminName, dao } = authResult;

    // Parse and validate request body
    const body = await request.json();
    const validation = disableMultiSigSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { reason, adminName: providedAdminName } = validation.data;

    // Disable multi-sig (creates proposal)
    const result = await daoGovernanceUpdateService.disableMultiSig(
      dao,
      userId,
      providedAdminName || adminName,
      reason
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to create proposal',
          code: 'DISABLE_FAILED',
        },
        { status: 400 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to create proposal',
          code: 'DISABLE_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Proposal created to disable multi-sig protection',
      proposalId: result.data,
    });
  } catch (error) {
    logger.error('[Multi-sig API] Error disabling multi-sig', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to disable multi-sig',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH - Change multi-sig threshold
 * Lowering = requires approval (creates proposal)
 * Raising = immediate (security upgrade)
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    // Apply rate limiting for governance operations (5 per minute per IP)
    const rateLimitResult = await rateLimiters.governance(request);
    if (rateLimitResult) {
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }
    const { userId, adminName, dao } = authResult;

    // Parse and validate request body
    const body = await request.json();
    const validation = changeThresholdSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { threshold, reason, adminName: providedAdminName } = validation.data;

    // Change threshold
    const result = await daoGovernanceUpdateService.changeMultiSigThreshold(
      dao,
      userId,
      providedAdminName || adminName,
      threshold,
      reason
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to change threshold',
          code: 'THRESHOLD_CHANGE_FAILED',
        },
        { status: 400 }
      );
    }

    // If data is a string, it's a proposalId (lowering threshold)
    // If void, it was immediate (raising threshold)
    const proposalId =
      typeof result.data === 'string' ? result.data : undefined;

    if (proposalId) {
      return NextResponse.json({
        success: true,
        message: 'Proposal created to lower multi-sig threshold',
        proposalId,
      });
    } else {
      return NextResponse.json({
        success: true,
        message: 'Multi-sig threshold increased successfully',
      });
    }
  } catch (error) {
    logger.error('[Multi-sig API] Error changing threshold', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to change threshold',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
