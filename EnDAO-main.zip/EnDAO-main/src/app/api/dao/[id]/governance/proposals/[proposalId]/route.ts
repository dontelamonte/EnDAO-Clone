/**
 * Proposal Actions API Route
 *
 * Handles actions on individual proposals (approve, cancel, get details).
 * Requires authentication and admin permissions.
 *
 * GET - Get proposal details
 * POST - Perform action on proposal (approve or cancel)
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { adminActionProposalService } from '@/lib/services/admin/admin-action-proposal.service';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import { z } from 'zod';
import type { DAO } from '@endao/shared-types';

// Validation schema for proposal actions
const proposalActionSchema = z.object({
  action: z.enum(['approve', 'cancel']),
  reason: z.string().min(10).max(500).optional(), // Required for cancel, optional for approve
});

/**
 * Helper to get authenticated user and validate admin permissions
 */
async function getAuthenticatedAdmin(
  request: NextRequest,
  daoId: string
): Promise<{ userId: string; adminName: string; dao: DAO } | NextResponse> {
  // Get Privy user ID from auth header (set by middleware)
  const privyId =
    request.headers.get('x-auth-privy-id') || request.headers.get('x-auth-uid');

  if (!privyId) {
    return NextResponse.json(
      {
        success: false,
        error: 'Authentication required',
        code: 'AUTH_REQUIRED',
      },
      { status: 401 }
    );
  }

  // Look up Supabase user by Privy ID
  const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
  if (!supabaseUser) {
    return NextResponse.json(
      { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
      { status: 404 }
    );
  }

  const userId = supabaseUser.id;
  const adminName =
    supabaseUser.displayName || supabaseUser.email || 'Unknown Admin';

  // Verify DAO exists
  const daoRepo = await daoAdminRepository.findById(daoId);
  if (!daoRepo) {
    return NextResponse.json(
      { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
      { status: 404 }
    );
  }

  // Get admin members
  const adminMembers = await daoMemberAdminRepository.findAdmins(daoId);
  const adminIds = adminMembers.map((m) => m.userId);

  // Verify user is an admin
  if (!adminIds.includes(userId)) {
    return NextResponse.json(
      {
        success: false,
        error: 'Admin permission required',
        code: 'PERMISSION_DENIED',
      },
      { status: 403 }
    );
  }

  // Build DAO object
  const dao: DAO = {
    id: daoRepo.id,
    admins: adminIds,
    governanceSettings: daoRepo.governanceSettings || {},
  } as DAO;

  return { userId, adminName, dao };
}

/**
 * GET - Get proposal details
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; proposalId: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId, proposalId } = await params;

    if (!daoId || !proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and Proposal ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }

    // Get proposal
    const result = await adminActionProposalService.getProposal(proposalId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Verify proposal belongs to this DAO
    if (result.data.daoId !== daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal does not belong to this DAO',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      '[Proposal Actions API] Error fetching proposal',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch proposal',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * POST - Perform action on proposal (approve or cancel)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; proposalId: string }> }
): Promise<NextResponse> {
  try {
    // Apply rate limiting for proposal operations (10 per minute per IP)
    const rateLimitResult = await rateLimiters.proposals(request);
    if (rateLimitResult) {
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const { id: daoId, proposalId } = await params;

    if (!daoId || !proposalId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and Proposal ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }
    const { userId, adminName, dao } = authResult;

    // Parse and validate request body
    const body = await request.json();
    const validation = proposalActionSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { action, reason } = validation.data;

    // Get proposal to verify it belongs to this DAO
    const proposalResult =
      await adminActionProposalService.getProposal(proposalId);
    if (!proposalResult.success || !proposalResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal not found',
          code: 'PROPOSAL_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (proposalResult.data.daoId !== daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal does not belong to this DAO',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Perform action
    if (action === 'approve') {
      // Get IP address for audit trail
      const ipAddress =
        request.headers.get('x-forwarded-for') ||
        request.headers.get('x-real-ip') ||
        undefined;

      const result = await adminActionProposalService.approveProposal(dao, {
        proposalId,
        adminId: userId,
        adminName,
        ipAddress,
      });

      if (!result.success) {
        return NextResponse.json(
          {
            success: false,
            error: result.error || 'Failed to approve proposal',
            code: 'APPROVE_FAILED',
          },
          { status: 400 }
        );
      }

      return NextResponse.json({
        success: true,
        message: 'Proposal approved successfully',
      });
    } else if (action === 'cancel') {
      // Validate reason is provided for cancel
      if (!reason) {
        return NextResponse.json(
          {
            success: false,
            error: 'Reason is required for cancellation',
            code: 'VALIDATION_ERROR',
          },
          { status: 400 }
        );
      }

      const result = await adminActionProposalService.cancelProposal(
        dao,
        proposalId,
        userId,
        adminName,
        reason
      );

      if (!result.success) {
        return NextResponse.json(
          {
            success: false,
            error: result.error || 'Failed to cancel proposal',
            code: 'CANCEL_FAILED',
          },
          { status: 400 }
        );
      }

      return NextResponse.json({
        success: true,
        message: 'Proposal cancelled successfully',
      });
    }

    // Should never reach here due to Zod validation
    return NextResponse.json(
      {
        success: false,
        error: 'Invalid action',
        code: 'INVALID_ACTION',
      },
      { status: 400 }
    );
  } catch (error) {
    logger.error(
      '[Proposal Actions API] Error performing action',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to perform action',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
