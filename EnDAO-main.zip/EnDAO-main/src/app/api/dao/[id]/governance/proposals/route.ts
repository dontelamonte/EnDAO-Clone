/**
 * Admin Action Proposals API Route
 *
 * Handles creation and retrieval of admin action proposals.
 * Requires authentication and admin permissions.
 *
 * POST - Create a new proposal for a critical admin action
 * GET - Get pending proposals for the DAO
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { adminActionProposalService } from '@/lib/services/admin/admin-action-proposal.service';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import { z } from 'zod';
import type { DAO } from '@endao/shared-types';
import { AdminActionType } from '@/lib/services/admin/types/audit.types';

// Validation schema for creating a proposal
const createProposalSchema = z.object({
  actionType: z.nativeEnum(AdminActionType),
  actionData: z
    .object({
      targetId: z.string().optional(),
      targetName: z.string().optional(),
      metadata: z.record(z.any()).optional(),
    })
    .optional(),
  justification: z
    .string()
    .min(10, 'Justification must be at least 10 characters')
    .max(1000),
});

/**
 * Helper to get authenticated user and validate admin permissions
 */
async function getAuthenticatedAdmin(
  request: NextRequest,
  daoId: string
): Promise<{ userId: string; adminName: string; dao: DAO } | NextResponse> {
  // Get Privy user ID from auth header (set by middleware)
  const privyId =
    request.headers.get('x-auth-privy-id') || request.headers.get('x-auth-uid');

  if (!privyId) {
    return NextResponse.json(
      {
        success: false,
        error: 'Authentication required',
        code: 'AUTH_REQUIRED',
      },
      { status: 401 }
    );
  }

  // Look up Supabase user by Privy ID
  const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
  if (!supabaseUser) {
    return NextResponse.json(
      { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
      { status: 404 }
    );
  }

  const userId = supabaseUser.id;
  const adminName =
    supabaseUser.displayName || supabaseUser.email || 'Unknown Admin';

  // Verify DAO exists
  const daoRepo = await daoAdminRepository.findById(daoId);
  if (!daoRepo) {
    return NextResponse.json(
      { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
      { status: 404 }
    );
  }

  // Get admin members
  const adminMembers = await daoMemberAdminRepository.findAdmins(daoId);
  const adminIds = adminMembers.map((m) => m.userId);

  // Verify user is an admin
  if (!adminIds.includes(userId)) {
    return NextResponse.json(
      {
        success: false,
        error: 'Admin permission required',
        code: 'PERMISSION_DENIED',
      },
      { status: 403 }
    );
  }

  // Build DAO object
  const dao: DAO = {
    id: daoRepo.id,
    admins: adminIds,
    governanceSettings: daoRepo.governanceSettings || {},
  } as DAO;

  return { userId, adminName, dao };
}

/**
 * POST - Create a new proposal
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    // Apply rate limiting for proposal operations (10 per minute per IP)
    const rateLimitResult = await rateLimiters.proposals(request);
    if (rateLimitResult) {
      return rateLimitResult; // Rate limit exceeded, return 429 response
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }
    const { userId, adminName, dao } = authResult;

    // Parse and validate request body
    const body = await request.json();
    const validation = createProposalSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          code: 'VALIDATION_ERROR',
          details: validation.error.errors,
        },
        { status: 400 }
      );
    }

    const { actionType, actionData, justification } = validation.data;

    // Create proposal
    const result = await adminActionProposalService.proposeAction(dao, {
      daoId,
      initiatorId: userId,
      initiatorName: adminName,
      action: actionType,
      targetId: actionData?.targetId,
      targetName: actionData?.targetName,
      reason: justification,
      metadata: actionData?.metadata,
    });

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to create proposal',
          code: 'PROPOSAL_CREATE_FAILED',
        },
        { status: 400 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to create proposal',
          code: 'PROPOSAL_CREATE_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Proposal created successfully',
      proposalId: result.data,
    });
  } catch (error) {
    logger.error('[Proposals API] Error creating proposal', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create proposal',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * GET - Get pending proposals for the DAO
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Authenticate and validate admin
    const authResult = await getAuthenticatedAdmin(request, daoId);
    if (authResult instanceof NextResponse) {
      return authResult;
    }

    // Get limit from query params (default 20)
    const { searchParams } = request.nextUrl;
    const limit = parseInt(searchParams.get('limit') || '20', 10);

    // Get pending proposals
    const result = await adminActionProposalService.getPendingProposals(
      daoId,
      limit
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to fetch proposals',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data || [],
    });
  } catch (error) {
    logger.error('[Proposals API] Error fetching proposals', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch proposals',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
