/**
 * Pending Approvals API Route
 *
 * Server-side endpoint for fetching pending admin action proposals for a DAO.
 * Only accessible by DAO admins with appropriate permissions.
 */

import { NextRequest, NextResponse } from 'next/server';
import { adminActionProposalService } from '@/lib/services/admin/admin-action-proposal.service';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

const UUID_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Validate and parse limit query parameter
 */
function parseLimit(url: string): { limit: number; error?: string } {
  const urlObj = new URL(url);
  const limitParam = urlObj.searchParams.get('limit');
  const limit = limitParam ? parseInt(limitParam, 10) : 20;

  if (isNaN(limit) || limit < 1 || limit > 100) {
    return { limit: 20, error: 'Invalid limit. Must be between 1 and 100' };
  }

  return { limit };
}

/**
 * Verify user is admin of the DAO
 */
async function verifyAdminAccess(daoId: string, userId: string) {
  const membership = await daoMemberAdminRepository.findByDaoAndUser(
    daoId,
    userId
  );

  if (!membership || membership.status !== 'active') {
    return { isAdmin: false, error: 'Not a member of this DAO', status: 403 };
  }

  const isAdmin = membership.role === 'admin';
  if (!isAdmin) {
    return { isAdmin: false, error: 'Admin permissions required', status: 403 };
  }

  return { isAdmin: true };
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Verify DAO exists - support both UUID and slug lookups
    const dao = UUID_REGEX.test(daoId)
      ? await daoAdminRepository.findById(daoId)
      : await daoAdminRepository.findBySlug(daoId);

    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Verify user is an admin
    const adminCheck = await verifyAdminAccess(dao.id, supabaseUser.id);
    if (!adminCheck.isAdmin) {
      return NextResponse.json(
        { success: false, error: adminCheck.error },
        { status: adminCheck.status }
      );
    }

    // Parse and validate limit parameter
    const { limit, error: limitError } = parseLimit(request.url);
    if (limitError) {
      return NextResponse.json(
        { success: false, error: limitError },
        { status: 400 }
      );
    }

    // Fetch pending proposals using the service
    const result = await adminActionProposalService.getPendingProposals(
      dao.id,
      limit
    );

    if (!result.success) {
      logger.error(
        '[Pending Approvals API] Failed to fetch proposals',
        new Error(result.error || 'Unknown error'),
        {
          daoId: dao.id,
        }
      );
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to fetch pending proposals',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      '[Pending Approvals API] Error fetching pending approvals',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch pending approvals' },
      { status: 500 }
    );
  }
}
