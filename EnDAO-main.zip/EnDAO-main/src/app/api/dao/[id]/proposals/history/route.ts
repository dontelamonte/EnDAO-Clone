/**
 * Proposal History API Route
 *
 * Fetches completed proposals (passed, rejected, executed) for a DAO.
 * Supports filtering by status and pagination.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  type Proposal,
  type ProposalStatus,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

// Completed statuses for history (repository uses 'failed' not 'rejected')
const COMPLETED_STATUSES: ProposalStatus[] = ['passed', 'failed', 'executed'];

interface ProposalHistoryResponse {
  success: boolean;
  data?: {
    proposals: Array<{
      id: string;
      title: string;
      description?: string;
      status: string;
      type: string;
      createdAt: string;
      endTime: string | null;
      results?: {
        totalVotes?: number;
        participationRate?: number;
        forVotes?: number;
        againstVotes?: number;
        abstainVotes?: number;
      };
    }>;
    totalCount: number;
  };
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<ProposalHistoryResponse>> {
  try {
    const { id: daoId } = await params;
    const { searchParams } = new URL(request.url);
    const statusFilter = searchParams.get('status') || 'all';

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Fetch proposals based on filter
    let proposals: Proposal[] = [];
    if (statusFilter === 'all') {
      // Fetch all completed proposals
      const allProposals = await Promise.all(
        COMPLETED_STATUSES.map((status) =>
          proposalAdminRepository.findByDao(daoId, status)
        )
      );
      proposals = allProposals.flat();
    } else if (COMPLETED_STATUSES.includes(statusFilter as ProposalStatus)) {
      // Fetch specific status
      proposals = await proposalAdminRepository.findByDao(
        daoId,
        statusFilter as ProposalStatus
      );
    } else {
      // Invalid status filter - return empty
      proposals = [];
    }

    // Sort by endTime descending (most recent first)
    proposals.sort((a, b) => {
      const aTime = a.votingEndTime ? new Date(a.votingEndTime).getTime() : 0;
      const bTime = b.votingEndTime ? new Date(b.votingEndTime).getTime() : 0;
      return bTime - aTime;
    });

    // Map to response format
    const formattedProposals = proposals.map((p) => ({
      id: p.id,
      title: p.title,
      description: p.description ?? undefined,
      status: p.status,
      type: p.type,
      createdAt: p.createdAt || new Date().toISOString(),
      endTime: p.votingEndTime || null,
      results: p.result
        ? {
            totalVotes: p.result.totalVotes,
            participationRate: p.result.participationRate,
            forVotes: p.result.forVotes,
            againstVotes: p.result.againstVotes,
            abstainVotes: p.result.abstainVotes,
          }
        : undefined,
    }));

    return NextResponse.json({
      success: true,
      data: {
        proposals: formattedProposals,
        totalCount: formattedProposals.length,
      },
    });
  } catch (error) {
    logger.error(
      'Error fetching proposal history',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/proposals/history', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch proposal history' },
      { status: 500 }
    );
  }
}
