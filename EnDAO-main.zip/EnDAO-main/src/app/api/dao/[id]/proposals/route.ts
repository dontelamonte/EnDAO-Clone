/**
 * DAO Proposals API Route
 *
 * GET - Fetch proposals for a DAO with creator info
 * POST - Create a new proposal
 * Server-side endpoint to avoid browser-safety violations
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  proposalAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { ProposalOperationsService } from '@/lib/services/proposal/crud/proposal-operations.service';
import { logger } from '@/lib/services/logger.service';
import type { CreateProposalFormData } from '@endao/shared-types';
import type { ProposalStatus } from '@/lib/data/repositories/supabase/proposal.repository';

interface ProposalCreateResponse {
  success: boolean;
  data?: { id: string };
  error?: string;
}

interface ProposalListResponse {
  success: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Proposal data varies
  data?: any[];
  error?: string;
}

/**
 * GET - Fetch proposals for a DAO with creator info and vote counts
 * Uses server-side admin repository for enrichment
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<ProposalListResponse>> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Resolve slug to UUID if needed
    const isUUID =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        daoId
      );
    let resolvedDaoId = daoId;

    if (!isUUID) {
      // daoId is a slug, resolve to UUID
      const dao = await daoAdminRepository.findBySlug(daoId);
      if (!dao) {
        return NextResponse.json(
          { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
          { status: 404 }
        );
      }
      resolvedDaoId = dao.id;
    }

    // Get optional status filter from query params
    const { searchParams } = new URL(request.url);
    const statusParam = searchParams.get('status');
    const status = statusParam as ProposalStatus | undefined;

    // Fetch proposals with creator info using admin repository (server-side)
    const proposals = await proposalAdminRepository.findByDaoWithCreator(
      resolvedDaoId,
      status
    );

    // Map to API response format
    const mappedProposals = proposals.map((proposal) => ({
      ...proposal,
      // Map repository fields to shared-types interface
      startTime: proposal.votingStartTime,
      endTime: proposal.votingEndTime,
      results: proposal.result,
    }));

    return NextResponse.json({
      success: true,
      data: mappedProposals,
    });
  } catch (error) {
    logger.error(
      '[DAO Proposals API] Error fetching proposals',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch proposals',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<ProposalCreateResponse>> {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Parse request body
    const body = await request.json();
    const proposalData: CreateProposalFormData = body.proposalData || body;

    if (!proposalData.title) {
      return NextResponse.json(
        {
          success: false,
          error: 'Proposal title is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Resolve slug to UUID if needed
    const isUUID =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        daoId
      );

    // Parallelize user and DAO lookups for faster response
    const [supabaseUser, dao] = await Promise.all([
      userAdminRepository.findByPrivyId(privyId),
      isUUID
        ? daoAdminRepository.findById(daoId)
        : daoAdminRepository.findBySlug(daoId),
    ]);

    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Check if user is a member of the DAO
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      supabaseUser.id
    );
    if (!membership || membership.status !== 'active') {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be a member of this DAO to create proposals',
          code: 'NOT_DAO_MEMBER',
        },
        { status: 403 }
      );
    }

    // Prepare member and DAO data for the service
    const memberData = {
      id: membership.id,
      role: membership.role,
      name:
        membership.displayName ||
        supabaseUser.displayName ||
        supabaseUser.username ||
        undefined,
    };

    const daoData = {
      id: dao.id,
      name: dao.name,
      memberCount: dao.memberCount,
      settings: dao.settings as Record<string, unknown> | undefined,
      stats: undefined,
    };

    // Create proposal via service
    const proposalService = ProposalOperationsService.getInstance();
    const result = await proposalService.createProposal(
      daoId,
      supabaseUser.id,
      proposalData,
      memberData,
      daoData
    );

    if (result.success && result.data) {
      return NextResponse.json({
        success: true,
        data: {
          id: result.data.id,
        },
      });
    } else {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to create proposal',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }
  } catch (error) {
    logger.error('[DAO Proposals API] Error creating proposal', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create proposal',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
