/**
 * DAO Stats API Route
 *
 * Server-side endpoint for fetching DAO statistics including member count,
 * participation rate, and health score. Public endpoint for basic stats.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoMemberAdminRepository,
  proposalAdminRepository,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { DAOStatisticsService } from '@/lib/services/dao/dao-statistics.service';
import { logger } from '@/lib/services/logger.service';

/**
 * Calculate participation rate based on recent proposals
 */
async function calculateParticipationRate(
  daoId: string,
  daysPeriod: number = 90
): Promise<number> {
  const thresholdDate = new Date();
  thresholdDate.setDate(thresholdDate.getDate() - daysPeriod);

  const proposals = await proposalAdminRepository.findMany({
    filters: [
      { field: 'daoId', operator: '==', value: daoId },
      {
        field: 'createdAt',
        operator: '>=',
        value: thresholdDate.toISOString(),
      },
    ],
  });

  if (proposals.length === 0) return 0;

  // Filter by status
  const validStatuses = ['active', 'passed', 'failed', 'executed'];
  const filteredProposals = proposals.filter((p) =>
    validStatuses.includes(p.status)
  );

  if (filteredProposals.length === 0) return 0;

  // Filter proposals that have results data
  const proposalsWithResults = filteredProposals.filter(
    (p) => p.result && typeof p.result.participationRate === 'number'
  );

  if (proposalsWithResults.length === 0) return 0;

  // Calculate weighted average participation rate
  let totalVotes = 0;
  let totalEligibleVoters = 0;

  for (const proposal of proposalsWithResults) {
    const votes = proposal.result?.totalVotes || 0;
    const eligible = proposal.result?.totalEligibleVoters || 0;
    totalVotes += votes;
    totalEligibleVoters += eligible;
  }

  return totalEligibleVoters > 0
    ? Math.round((totalVotes / totalEligibleVoters) * 100)
    : 0;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get query params
    const { searchParams } = new URL(request.url);
    const participationDays = parseInt(
      searchParams.get('participationDays') || '90',
      10
    );
    const includeHealthScore = searchParams.get('includeHealthScore') === 'true';

    // Get statistics in parallel
    const [memberCount, adminCount, activeProposalCount, participationRate] =
      await Promise.all([
        daoMemberAdminRepository.countActiveMembers(daoId),
        daoMemberAdminRepository.countAdmins(daoId),
        (async () => {
          const proposals = await proposalAdminRepository.findMany({
            filters: [
              { field: 'daoId', operator: '==', value: daoId },
              { field: 'status', operator: '==', value: 'active' },
            ],
          });
          return proposals.length;
        })(),
        calculateParticipationRate(daoId, participationDays),
      ]);

    // Optionally fetch health score (more expensive calculation)
    let healthScore: {
      score: number;
      breakdown: {
        memberActivity: number;
        proposalActivity: number;
        treasuryHealth: number;
        governance: number;
      };
      recommendations: string[];
    } | null = null;

    if (includeHealthScore) {
      const statisticsService = DAOStatisticsService.getInstance();
      const healthResult = await statisticsService.calculateDAOHealthScore(daoId);
      if (healthResult.success && healthResult.data) {
        healthScore = healthResult.data;
      }
    }

    // Calculate recent joins (last 7 days)
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const recentMembers = await daoMemberAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: daoId },
        { field: 'status', operator: '==', value: 'active' },
        { field: 'joinedAt', operator: '>=', value: oneWeekAgo.toISOString() },
      ],
    });

    // Add caching headers - 2 min cache with stale-while-revalidate
    return NextResponse.json(
      {
        success: true,
        data: {
          memberCount,
          adminCount,
          activeProposalCount,
          recentJoins: recentMembers.length,
          participationRate,
          ...(healthScore && { healthScore }),
        },
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=120, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error('[DAO Stats API] Error fetching stats', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch DAO stats',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}
