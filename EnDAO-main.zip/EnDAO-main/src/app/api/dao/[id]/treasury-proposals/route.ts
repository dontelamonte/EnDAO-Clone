/**
 * Treasury Proposals API Route
 *
 * Server-side endpoint for fetching treasury (funding) proposals with execution states.
 * Maps Privy ID to Supabase UUID before querying.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  daoAdminRepository,
  daoMemberAdminRepository,
  treasuryExecutionAdminRepository,
  treasuryExecutionSignatureAdminRepository,
  treasuryAdminAdminRepository,
  treasuryConfigAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { Proposal } from '@endao/shared-types';

interface TreasuryAdmin {
  userId: string;
  privyUserId?: string;
  walletAddress?: string;
  displayName: string;
  canSign: boolean;
  canExecute: boolean;
  canInitiate: boolean;
  order: number;
  role: string;
  status: string;
}

interface ExecutionSignature {
  signerId: string;
  signerName?: string;
  signedAt: string;
}

interface TreasuryExecutionState {
  id: string;
  proposalId: string;
  daoId: string;
  safeAddress?: string;
  status:
    | 'pending_signatures'
    | 'ready_to_execute'
    | 'executing'
    | 'executed'
    | 'failed'
    | 'cancelled';
  signatures: ExecutionSignature[];
  requiredSignatures: number;
  safeTxHash?: string;
  blockchainTxHash?: string;
  executedAt?: string;
  executedBy?: string;
  createdAt: string;
  updatedAt: string;
}

interface ProposalWithExecution {
  id: string;
  daoId: string;
  type: string;
  status: string;
  title: string;
  description?: string;
  createdBy: string;
  createdAt: string;
  endTime?: string;
  results?: {
    totalVotes: number;
    forVotes: number;
    againstVotes: number;
    abstainVotes: number;
    quorumReached: boolean;
    passed: boolean;
    participationRate: number;
  };
  metadata?: Record<string, unknown>;
  votingConfig?: {
    quorumPercentage?: number;
    passThreshold?: number;
  };
  executionState: TreasuryExecutionState | null;
  signaturesNeeded: number;
  canSign: boolean;
  canExecute: boolean;
  needsInitiation: boolean;
  signaturesCount: number;
  requiredSignatures: number;
  buttonState: 'initiate' | 'sign' | 'waiting' | 'execute' | 'completed';
  statusText: string;
  progressStep: 1 | 2 | 3 | 4;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Get current user's treasury admin status
    let currentUserAdmin: TreasuryAdmin | null = null;
    const repoAdmins = await treasuryAdminAdminRepository.findByDao(daoId);

    if (repoAdmins.length > 0) {
      const userAdmin = repoAdmins.find(
        (a) => a.userId === userId || a.privyUserId === privyId
      );
      if (userAdmin) {
        currentUserAdmin = {
          userId: userAdmin.userId,
          privyUserId: userAdmin.privyUserId,
          walletAddress: userAdmin.walletAddress,
          displayName: userAdmin.displayName || 'Admin',
          canSign: userAdmin.canSign,
          canExecute: userAdmin.canExecute,
          canInitiate: userAdmin.canInitiate,
          order: userAdmin.order || 1,
          role: userAdmin.role || 'admin',
          status: userAdmin.status || 'active',
        };
      }
    } else {
      // Fallback: check if user is a DAO admin
      const adminUserIds =
        await daoMemberAdminRepository.getAdminUserIds(daoId);
      if (adminUserIds.includes(userId)) {
        currentUserAdmin = {
          userId,
          privyUserId: privyId,
          displayName:
            supabaseUser.displayName || supabaseUser.username || 'Admin',
          canSign: true,
          canExecute: true,
          canInitiate: true,
          order: 1,
          role: 'admin',
          status: 'active',
        };
      }
    }

    // Get treasury config for required signatures
    const treasuryConfig = await treasuryConfigAdminRepository.findByDao(daoId);
    const defaultRequiredSignatures = treasuryConfig?.requiredSignatures || 2;

    // Get funding proposals
    const proposals = await proposalAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: daoId },
        { field: 'type', operator: '==', value: 'funding' },
      ],
      orderBy: [{ field: 'createdAt', direction: 'desc' }],
    });

    // Process each proposal with execution state
    const proposalsWithExecutionMaybeNull = await Promise.all(
      proposals.map(async (proposal) => {
        try {
          // Check if proposal is ready for execution
          const isReadyForExecution = checkIsReadyForExecution(proposal);

          // Skip proposals that aren't ready or are already executed
          if (!isReadyForExecution || proposal.executedAt) {
            return null;
          }

          // Get execution state
          const executionRepo =
            await treasuryExecutionAdminRepository.findByProposalId(
              proposal.id
            );

          let executionState: TreasuryExecutionState | null = null;
          if (executionRepo) {
            // Get signatures from separate table
            const signatureRecords =
              await treasuryExecutionSignatureAdminRepository.findByExecutionId(
                executionRepo.id
              );
            const signatures: ExecutionSignature[] = signatureRecords.map(
              (s) => ({
                signerId: s.signerId,
                signerName: undefined,
                signedAt:
                  s.signedAt instanceof Date
                    ? s.signedAt.toISOString()
                    : String(s.signedAt),
              })
            );

            executionState = {
              id: executionRepo.id,
              proposalId: executionRepo.proposalId,
              daoId: executionRepo.daoId,
              safeAddress: executionRepo.safeAddress ?? undefined,
              status: executionRepo.status as TreasuryExecutionState['status'],
              signatures,
              requiredSignatures: executionRepo.requiredSignatures,
              safeTxHash: executionRepo.safeTransactionHash,
              blockchainTxHash: executionRepo.blockchainTxHash ?? undefined,
              executedAt: executionRepo.executedAt
                ? executionRepo.executedAt instanceof Date
                  ? executionRepo.executedAt.toISOString()
                  : String(executionRepo.executedAt)
                : undefined,
              executedBy: executionRepo.executedBy ?? undefined,
              createdAt:
                executionRepo.createdAt instanceof Date
                  ? executionRepo.createdAt.toISOString()
                  : String(executionRepo.createdAt),
              updatedAt:
                executionRepo.updatedAt instanceof Date
                  ? executionRepo.updatedAt.toISOString()
                  : String(executionRepo.updatedAt),
            };
          }

          // Calculate button state
          const signaturesCount = executionState?.signatures?.length || 0;
          const requiredSignatures =
            executionState?.requiredSignatures || defaultRequiredSignatures;

          let needsInitiation = false;
          let canSign = false;
          let canExecute = false;
          let buttonState: ProposalWithExecution['buttonState'] = 'waiting';
          let statusText = 'Processing...';
          let progressStep: ProposalWithExecution['progressStep'] = 1;

          if (executionState) {
            // Check if current user has signed
            const hasUserSigned = executionState.signatures.some(
              (s) => s.signerId === userId || s.signerId === privyId
            );

            if (executionState.status === 'executed') {
              buttonState = 'completed';
              statusText = 'Completed';
              progressStep = 4;
            } else if (executionState.status === 'ready_to_execute') {
              canExecute = !!currentUserAdmin?.canExecute;
              buttonState = 'execute';
              statusText = 'Ready to execute';
              progressStep = 4;
            } else if (
              signaturesCount > 0 &&
              signaturesCount < requiredSignatures
            ) {
              if (hasUserSigned) {
                buttonState = 'waiting';
                statusText = 'Waiting for co-admin';
                progressStep = 3;
              } else if (currentUserAdmin?.canSign) {
                canSign = true;
                buttonState = 'sign';
                statusText = 'Needs your signature';
                progressStep = 3;
              } else {
                buttonState = 'waiting';
                statusText = 'Waiting for signatures';
                progressStep = 3;
              }
            } else if (signaturesCount === 0) {
              if (currentUserAdmin?.canSign) {
                canSign = true;
                buttonState = 'sign';
                statusText = 'Needs signatures';
                progressStep = 2;
              } else {
                buttonState = 'waiting';
                statusText = 'Waiting for signatures';
                progressStep = 2;
              }
            }
          } else {
            needsInitiation = true;
            buttonState = 'initiate';
            statusText = 'Needs initiation';
            progressStep = 1;
          }

          return {
            id: proposal.id,
            daoId: proposal.daoId,
            type: proposal.type,
            status: proposal.status,
            title: proposal.title,
            description: proposal.description,
            createdBy: proposal.createdBy,
            createdAt: proposal.createdAt,
            endTime: proposal.votingEndTime ?? undefined,
            results: proposal.result,
            metadata: proposal.metadata,
            votingConfig: proposal.votingConfig,
            executionState,
            signaturesNeeded: Math.max(0, requiredSignatures - signaturesCount),
            canSign,
            canExecute,
            needsInitiation,
            signaturesCount,
            requiredSignatures,
            buttonState,
            statusText,
            progressStep,
          } as ProposalWithExecution;
        } catch (error) {
          logger.error('Error processing proposal', error as Error, {
            proposalId: proposal.id,
          });
          return null;
        }
      })
    );

    // Filter out null values
    const validProposals = proposalsWithExecutionMaybeNull.filter(
      (p): p is ProposalWithExecution => p !== null
    );

    // Calculate summary
    const summary = {
      pendingValue: validProposals
        .filter(
          (p) => !p.executionState || p.executionState.status !== 'executed'
        )
        .reduce((total, p) => {
          const amount = parseFloat(String(p.metadata?.treasuryAmount || 0));
          return total + (isNaN(amount) ? 0 : amount);
        }, 0),
      needingSignatures: validProposals.filter((p) => p.canSign).length,
      readyToExecute: validProposals.filter((p) => p.canExecute).length,
      totalProposals: validProposals.length,
      needingInitiation: validProposals.filter((p) => p.needsInitiation).length,
    };

    return NextResponse.json({
      success: true,
      data: {
        proposals: validProposals,
        summary,
        currentUserAdmin,
      },
    });
  } catch (error) {
    logger.error(
      '[Treasury Proposals API] Error fetching proposals',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch treasury proposals' },
      { status: 500 }
    );
  }
}

/**
 * Check if a proposal is ready for execution
 */
function checkIsReadyForExecution(proposal: {
  status: string;
  results?: {
    totalVotes?: number;
    forVotes?: number;
    againstVotes?: number;
    passed?: boolean;
    quorumReached?: boolean;
    participationRate?: number;
  };
  votingConfig?: {
    quorumPercentage?: number;
    passThreshold?: number;
  };
  endTime?: Date | string | null;
}): boolean {
  // Already marked as passed
  if (proposal.status === 'passed') {
    return true;
  }

  // For active proposals, check voting results
  if (proposal.status === 'active') {
    if (!proposal.results || typeof proposal.results !== 'object') {
      return false;
    }

    const results = proposal.results;
    const totalVotes = results.totalVotes || 0;
    const forVotes = results.forVotes || 0;
    const againstVotes = results.againstVotes || 0;
    const quorumPercentage = proposal.votingConfig?.quorumPercentage || 51;
    const passThreshold = proposal.votingConfig?.passThreshold || 51;

    if (totalVotes === 0) {
      return false;
    }

    // Check if explicitly marked as passed
    if (results.passed === true && results.quorumReached === true) {
      return true;
    }

    // Additional safety check
    if (results.passed === true && totalVotes > 0 && forVotes > againstVotes) {
      return true;
    }

    // For continuous voting (no end time)
    const now = new Date();
    const endTime =
      proposal.endTime instanceof Date
        ? proposal.endTime
        : proposal.endTime
          ? new Date(proposal.endTime)
          : null;
    const hasNoEndTime =
      !endTime || endTime.getTime() - now.getTime() > 365 * 24 * 60 * 60 * 1000;

    if (hasNoEndTime) {
      const participationRate = results.participationRate || 0;
      const approvalRate = totalVotes > 0 ? (forVotes / totalVotes) * 100 : 0;

      const quorumMet = participationRate >= quorumPercentage;
      const approvalMet = approvalRate >= passThreshold;

      return quorumMet && approvalMet;
    }
  }

  return false;
}
