/**
 * DAO Leave API endpoint
 * Allows authenticated users to leave a DAO
 * Maps Privy ID to Supabase UUID for database operations
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoMemberAdminRepository,
  daoAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Apply rate limiting for DAO leave operations (10/min)
    const rateLimitResult = await rateLimiters.daoJoinLeave(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Get membership
    const member = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      supabaseUser.id
    );
    if (!member || member.status !== 'active') {
      return NextResponse.json(
        { success: false, error: 'Not a member of this DAO' },
        { status: 400 }
      );
    }

    // Can't leave if you're the only admin
    if (member.role === 'admin') {
      const adminCount = await daoMemberAdminRepository.countAdmins(daoId);
      if (adminCount <= 1) {
        return NextResponse.json(
          {
            success: false,
            error: 'Cannot leave DAO - you are the only admin',
          },
          { status: 400 }
        );
      }
    }

    // Soft delete membership
    await daoMemberAdminRepository.softDelete(member.id);

    // Update DAO member count and lastActivityAt
    const activeMemberCount =
      await daoMemberAdminRepository.countActiveMembers(daoId);
    await daoAdminRepository.update(daoId, {
      memberCount: activeMemberCount,
      lastActivityAt: new Date().toISOString(),
    });

    return NextResponse.json({
      success: true,
      data: { success: true },
    });
  } catch (error) {
    logger.error(
      'Error leaving DAO',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/leave', method: 'POST' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to leave DAO' },
      { status: 500 }
    );
  }
}
