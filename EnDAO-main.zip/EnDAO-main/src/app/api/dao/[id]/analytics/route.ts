/**
 * DAO Analytics API Route
 *
 * Server-side endpoint for fetching DAO analytics data including:
 * - Top contributors
 * - Proposal breakdown by type
 * - Voting patterns
 *
 * Used by the analytics context on DAO detail pages.
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { DAOStatisticsService } from '@/lib/services/dao/dao-statistics.service';
import { daoAdminRepository } from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface TopContributor {
  id: string;
  name: string;
  address: string;
  avatar?: string;
  proposalsCreated: number;
  votesCast: number;
  votingPower: number;
  contributionScore: number;
}

interface VotingPatternData {
  status: string;
  value: number;
  fill: string;
}

interface ProposalBreakdownData {
  type: string;
  count: number;
  passed: number;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required', code: 'MISSING_PARAMETER' },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'DAO_NOT_FOUND' },
        { status: 404 }
      );
    }

    logger.debug('[DAO Analytics API] Loading analytics', { daoId });

    const supabase = getSupabaseAdmin();
    const statisticsService = DAOStatisticsService.getInstance();

    // Fetch data in parallel
    const [memberStatsResult, proposalsData, votesData, usersData] =
      await Promise.all([
        // Get member activity stats (includes top contributors)
        statisticsService.getMemberActivityStats(daoId),

        // Get all proposals for this DAO
        supabase
          .from('proposals')
          .select('id, type, status')
          .eq('dao_id', daoId)
          .neq('status', 'deleted'),

        // Get all votes for this DAO
        supabase
          .from('votes')
          .select('id, option')
          .eq('dao_id', daoId),

        // We'll fetch user data separately for contributors
        Promise.resolve(null),
      ]);

    // Process top contributors
    const topContributors: TopContributor[] = [];
    if (memberStatsResult.success && memberStatsResult.data?.topContributors) {
      // Get user IDs from contributors
      const userIds = memberStatsResult.data.topContributors
        .slice(0, 5)
        .map((c) => c.userId);

      // Fetch user data if we have contributors
      let usersMap = new Map<
        string,
        { displayName?: string; email?: string; photoURL?: string }
      >();
      if (userIds.length > 0) {
        const { data: users } = await supabase
          .from('users')
          .select('id, display_name, email, photo_url')
          .in('id', userIds);

        if (users) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Supabase generated types may not include all columns
          usersMap = new Map(
            (users as Array<{ id: string; display_name?: string; email?: string; photo_url?: string }>).map((u) => [
              u.id,
              {
                displayName: u.display_name,
                email: u.email,
                photoURL: u.photo_url,
              },
            ])
          );
        }
      }

      // Build contributors list
      for (const contrib of memberStatsResult.data.topContributors.slice(
        0,
        5
      )) {
        const userData = usersMap.get(contrib.userId);
        topContributors.push({
          id: contrib.userId,
          name: userData?.displayName || userData?.email || 'Anonymous',
          address: (contrib.userId || '').slice(0, 8) + '...',
          avatar: userData?.photoURL,
          proposalsCreated: contrib.proposalsCreated,
          votesCast: contrib.votesSubmitted,
          votingPower: contrib.score * 100,
          contributionScore: contrib.score,
        });
      }
    }

    // Process proposal breakdown by type
    const proposalBreakdown: ProposalBreakdownData[] = [];
    if (proposalsData.data && proposalsData.data.length > 0) {
      const typeMap = new Map<string, { count: number; passed: number }>();

      // Cast to known shape for type safety
      const proposals = proposalsData.data as Array<{ id: string; type?: string; status?: string }>;
      for (const p of proposals) {
        const type = p.type || 'General';
        const existing = typeMap.get(type) || { count: 0, passed: 0 };
        existing.count++;
        if (p.status === 'passed' || p.status === 'executed') {
          existing.passed++;
        }
        typeMap.set(type, existing);
      }

      const breakdown = Array.from(typeMap.entries())
        .map(([type, data]) => ({
          type: type.charAt(0).toUpperCase() + type.slice(1),
          count: data.count,
          passed: data.passed,
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 4);

      proposalBreakdown.push(...breakdown);
    }

    // Process voting patterns
    let votingPatterns: VotingPatternData[] = [
      { status: 'For', value: 65, fill: '#10b981' },
      { status: 'Against', value: 25, fill: '#ef4444' },
      { status: 'Abstain', value: 10, fill: '#6b7280' },
    ];

    if (votesData.data && votesData.data.length > 0) {
      let forVotes = 0;
      let againstVotes = 0;
      let abstainVotes = 0;

      // Cast to known shape for type safety
      const votes = votesData.data as Array<{ id: string; option?: string }>;
      for (const vote of votes) {
        const option = (vote.option || '').toLowerCase();
        if (option === 'for' || option === 'yes') forVotes++;
        else if (option === 'against' || option === 'no') againstVotes++;
        else abstainVotes++;
      }

      const total = forVotes + againstVotes + abstainVotes;
      if (total > 0) {
        votingPatterns = [
          {
            status: 'For',
            value: Math.round((forVotes / total) * 100),
            fill: '#10b981',
          },
          {
            status: 'Against',
            value: Math.round((againstVotes / total) * 100),
            fill: '#ef4444',
          },
          {
            status: 'Abstain',
            value: Math.round((abstainVotes / total) * 100),
            fill: '#6b7280',
          },
        ];
      }
    }

    // Add caching headers - 2 min cache with stale-while-revalidate
    return NextResponse.json(
      {
        success: true,
        data: {
          topContributors,
          proposalBreakdown,
          votingPatterns,
        },
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=120, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error('[DAO Analytics API] Error fetching analytics', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch DAO analytics',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}
