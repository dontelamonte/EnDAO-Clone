/**
 * API Routes: DAO Recurring Payouts
 *
 * GET  /api/dao/[id]/recurring-payouts - List recurring payouts
 * POST /api/dao/[id]/recurring-payouts - Create recurring payout
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { recurringPayoutService } from '@/lib/services/payout';
import { validateCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';
import type { RecurringPayoutStatus } from '@endao/shared-types';

// Validation schema for creating recurring payout
const createRecurringPayoutSchema = z.object({
  recipientUserId: z.string().uuid().optional(),
  recipientWalletAddress: z.string().optional(),
  recipientEmail: z.string().email().optional(),
  amount: z.number().positive(),
  currency: z.string().min(1),
  payoutMethod: z.enum(['crypto_wallet', 'bank_offramp']).optional(),
  frequency: z.enum(['weekly', 'biweekly', 'monthly', 'quarterly']),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  endDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional(),
  title: z.string().min(1).max(200),
  description: z.string().max(1000).optional(),
  category: z.enum(['salary', 'grant', 'vendor', 'other']).optional(),
  payoutsRemaining: z.number().int().positive().optional(),
  requiresApprovalEachTime: z.boolean().optional(),
  autoExecute: z.boolean().optional(),
});

/**
 * GET /api/dao/[id]/recurring-payouts
 * List recurring payouts for a DAO
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse query params
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') as RecurringPayoutStatus | null;
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const result = await recurringPayoutService.listRecurringPayouts(daoId, {
      status: status || undefined,
      limit,
      offset,
    });

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to list recurring payouts', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

/**
 * POST /api/dao/[id]/recurring-payouts
 * Create a new recurring payout
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const validation = createRecurringPayoutSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    // Must have at least one recipient identifier
    const { recipientUserId, recipientWalletAddress, recipientEmail } =
      validation.data;
    if (!recipientUserId && !recipientWalletAddress && !recipientEmail) {
      return NextResponse.json(
        {
          success: false,
          error:
            'At least one recipient identifier required (userId, wallet, or email)',
        },
        { status: 400 }
      );
    }

    const result = await recurringPayoutService.createRecurring(
      {
        daoId,
        ...validation.data,
      },
      userId
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: true, data: result.data },
      { status: 201 }
    );
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to create recurring payout', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
