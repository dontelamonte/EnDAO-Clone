/**
 * API Routes: Individual Recurring Payout
 *
 * GET   /api/dao/[id]/recurring-payouts/[recurringId] - Get recurring payout details
 * PATCH /api/dao/[id]/recurring-payouts/[recurringId] - Pause, resume, or cancel
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { recurringPayoutService } from '@/lib/services/payout';
import { validateCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';

// Validation schema for actions
const actionSchema = z.object({
  action: z.enum(['pause', 'resume', 'cancel']),
  reason: z.string().max(500).optional(),
});

/**
 * GET /api/dao/[id]/recurring-payouts/[recurringId]
 * Get recurring payout details with execution history
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; recurringId: string }> }
) {
  try {
    const { recurringId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get recurring payout
    const result = await recurringPayoutService.getRecurringPayout(recurringId);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Not found' },
        { status: 404 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        { success: false, error: 'Not found' },
        { status: 404 }
      );
    }

    // Get execution history
    const historyResult = await recurringPayoutService.getExecutionHistory(
      recurringId,
      10
    );

    return NextResponse.json({
      success: true,
      data: {
        recurringPayout: result.data,
        executionHistory: historyResult.success ? historyResult.data : [],
      },
    });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to get recurring payout', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/dao/[id]/recurring-payouts/[recurringId]
 * Pause, resume, or cancel a recurring payout
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; recurringId: string }> }
) {
  try {
    const { recurringId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const validation = actionSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { action, reason } = validation.data;
    let result;

    switch (action) {
      case 'pause':
        result = await recurringPayoutService.pauseRecurring(
          recurringId,
          userId
        );
        break;
      case 'resume':
        result = await recurringPayoutService.resumeRecurring(
          recurringId,
          userId
        );
        break;
      case 'cancel':
        result = await recurringPayoutService.cancelRecurring(
          recurringId,
          userId,
          reason
        );
        break;
    }

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to update recurring payout', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
