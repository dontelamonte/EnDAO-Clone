/**
 * DAO Join API Route
 *
 * Server-side endpoint for joining a DAO.
 * Handles both direct joins and join requests based on DAO settings.
 * - If DAO requires approval: creates a JoinRequest
 * - If DAO allows direct join: creates a DAOMember directly
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  joinRequestAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Apply rate limiting for DAO join operations (10/min)
    const rateLimitResult = await rateLimiters.daoJoinLeave(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Check if already a member
    const existingMember = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      supabaseUser.id
    );
    if (existingMember && existingMember.status === 'active') {
      return NextResponse.json(
        { success: false, error: 'Already a member of this DAO' },
        { status: 400 }
      );
    }

    // Check for existing pending join request
    const existingRequest = await joinRequestAdminRepository.findByDaoAndUser(
      daoId,
      supabaseUser.id
    );
    if (existingRequest && existingRequest.status === 'pending') {
      return NextResponse.json(
        {
          success: false,
          error: 'You already have a pending join request for this DAO',
        },
        { status: 400 }
      );
    }

    // Determine if approval is required
    const requiresApproval = dao.settings?.requireApprovalToJoin ?? false;

    if (requiresApproval) {
      // Create a join request for admin approval
      const joinRequestData = {
        daoId,
        userId: supabaseUser.id,
        status: 'pending' as const,
        message: null,
        reviewedBy: null,
        reviewedAt: null,
        reviewNote: null,
      };

      const newRequest =
        await joinRequestAdminRepository.create(joinRequestData);

      return NextResponse.json({
        success: true,
        data: {
          id: newRequest.id,
          requiresApproval: true,
          status: 'pending',
        },
      });
    } else {
      // Direct join - create member record
      const memberData = {
        daoId,
        userId: supabaseUser.id,
        role: 'member' as const,
        status: 'active' as const,
        isActive: true,
        displayName: supabaseUser.username || supabaseUser.email || null,
        bio: null,
        avatarUrl: null,
        preferences: {},
        joinedAt: new Date().toISOString(),
      };

      const newMember = await daoMemberAdminRepository.create(memberData);

      return NextResponse.json({
        success: true,
        data: {
          id: newMember.id,
          requiresApproval: false,
          status: 'active',
        },
      });
    }
  } catch (error) {
    logger.error('[DAO Join API] Error joining DAO', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to join DAO' },
      { status: 500 }
    );
  }
}
