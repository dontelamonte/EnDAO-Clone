/**
 * QR Join API Route
 * Handles DAO joining via QR code invitations
 */

import { NextRequest, NextResponse } from 'next/server';
import { qrServices } from '@/lib/services/invitation/qr';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { MemberCrudService } from '@/lib/services/dao/member-crud';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories';
import type { DAO } from '@endao/shared-types';
import { logger } from '@/lib/services/logger.service';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    // Get request data
    const { qrToken, role, userId } = await request.json();

    if (!qrToken || !role || !userId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Validate user authentication
    const authContext = await getAuthContext();
    if (!authContext || authContext.uid !== userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get DAO data
    const dao = await daoAdminRepository.findById(id);

    if (!dao) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    // Check DAO status
    if (dao.status !== 'active') {
      return NextResponse.json(
        { error: 'DAO is not accepting new members' },
        { status: 400 }
      );
    }

    // Check if user is already a member
    const existingMembers = await daoMemberAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: id },
        { field: 'userId', operator: '==', value: userId },
      ],
      limit: 1,
    });
    if (existingMembers.length > 0) {
      return NextResponse.json(
        { error: 'User is already a member of this DAO' },
        { status: 400 }
      );
    }

    // Validate QR code
    // Note: In a real implementation, you would decode the QR data and validate the token
    // For now, we'll assume the token is valid if it matches the expected format
    if (!qrToken || qrToken.length < 16) {
      return NextResponse.json(
        { error: 'Invalid invitation token' },
        { status: 400 }
      );
    }

    // Use MemberCrudService to join the DAO
    const memberService = MemberCrudService.getInstance();
    const result = await memberService.joinDAO(id, userId);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Failed to join DAO' },
        { status: 400 }
      );
    }

    // Update the member document with QR-specific metadata
    const members = await daoMemberAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: id },
        { field: 'userId', operator: '==', value: userId },
      ],
      limit: 1,
    });

    if (members.length > 0) {
      const member = members[0];
      // Update role - note: metadata is stored in a separate field or not used
      await daoMemberAdminRepository.update(member.id, {
        role: role as 'admin' | 'member',
      });
    }

    return NextResponse.json({
      success: true,
      message: `Successfully joined ${dao.name} as ${role}`,
      member: result.data,
    });
  } catch (error) {
    logger.error(
      'QR join error',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/join/qr', method: 'POST' }
    );
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    // This endpoint could be used to validate QR codes without joining
    const { searchParams } = new URL(request.url);
    const qrData = searchParams.get('data');

    if (!qrData) {
      return NextResponse.json(
        { error: 'No QR data provided' },
        { status: 400 }
      );
    }

    // Validate QR code
    const validation = await qrServices.validator.validateQRCode(
      qrData,
      request.headers.get('user-agent') || undefined
    );

    if (!validation.isValid) {
      return NextResponse.json(
        { error: validation.error, isValid: false },
        { status: 400 }
      );
    }

    // Check if QR is for this DAO
    if (validation.payload?.daoId !== id) {
      return NextResponse.json(
        { error: 'QR code is for a different DAO', isValid: false },
        { status: 400 }
      );
    }

    return NextResponse.json({
      isValid: true,
      payload: validation.payload,
      warnings: validation.warnings,
    });
  } catch (error) {
    logger.error(
      'QR validation error',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/join/qr', method: 'GET' }
    );
    return NextResponse.json(
      { error: 'Failed to validate QR code' },
      { status: 500 }
    );
  }
}
