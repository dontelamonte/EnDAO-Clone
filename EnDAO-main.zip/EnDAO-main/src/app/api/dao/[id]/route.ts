/**
 * DAO API endpoint
 * GET - Fetches a single DAO by ID (supports public access)
 * PATCH - Updates a DAO (requires authentication and admin permission)
 */

import { NextRequest, NextResponse } from 'next/server';
import { userAdminRepository } from '@/lib/data/repositories';
import { DAOService } from '@/lib/services/dao';
import { UpdateDAOFormData } from '@endao/shared-types';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoIdOrSlug } = await params;

    if (!daoIdOrSlug) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Use DAOService.getDAO() which properly populates admins and memberIds
    // from the dao_members table (required for DAO type compatibility)
    const daoService = DAOService.getInstance();

    // Check if the identifier is a UUID or a slug
    const isUUID =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        daoIdOrSlug
      );
    const result = isUUID
      ? await daoService.getDAO(daoIdOrSlug)
      : await daoService.getDAOBySlug(daoIdOrSlug);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'DAO not found',
          code: 'DAO_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'DAO_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // For public DAOs, allow unauthenticated access
    // For private DAOs, membership checks can be added here if needed

    // Add caching headers - 1 min cache (DAO data rarely changes)
    return NextResponse.json(
      {
        success: true,
        data: result.data,
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=60, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching DAO',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch DAO', code: 'FETCH_FAILED' },
      { status: 500 }
    );
  }
}

/**
 * PATCH - Update a DAO
 * Requires authentication and admin permission
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Parse request body
    const updates: UpdateDAOFormData = await request.json();

    if (!updates || Object.keys(updates).length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'No updates provided',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Update DAO using the service (includes admin permission check)
    const daoService = DAOService.getInstance();
    const result = await daoService.updateDAO(daoId, updates, userId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to update DAO',
          code: 'UPDATE_FAILED',
        },
        { status: 400 }
      );
    }

    // Fetch the updated DAO to return (with admins and memberIds populated)
    const updatedResult = await daoService.getDAO(daoId);

    if (!updatedResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: updatedResult.error || 'Failed to fetch updated DAO',
          code: 'FETCH_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: updatedResult.data,
    });
  } catch (error) {
    logger.error('[DAO API] Error updating DAO', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to update DAO', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}
