/**
 * Treasury Off-ramp Execute API Route
 *
 * POST - Execute an approved off-ramp request
 *
 * Requires authentication and admin permission
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { offrampService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';

/**
 * POST /api/dao/{id}/treasury/offramp/{requestId}/execute
 * Execute an approved off-ramp request
 * Requires admin permission
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; requestId: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId, requestId } = await params;

    if (!daoId || !requestId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and request ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists and user is admin
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO admin
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isAdmin =
      membership?.role === 'admin' ||
      membership?.role === 'admin' ||
      dao.creatorId === userId;
    if (!isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Admin permission required to execute off-ramp',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Get the off-ramp request first to verify it belongs to this DAO
    const existingRequest = await offrampService.getOfframpRequest(requestId);
    if (!existingRequest.success || !existingRequest.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Off-ramp request not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (existingRequest.data.daoId !== daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Off-ramp request not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Verify request is approved
    if (existingRequest.data.status !== 'approved') {
      return NextResponse.json(
        {
          success: false,
          error: `Cannot execute off-ramp in status: ${existingRequest.data.status}`,
          code: 'INVALID_STATUS',
        },
        { status: 400 }
      );
    }

    // Execute off-ramp request
    const result = await offrampService.executeOfframp(requestId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to execute off-ramp request',
          code: 'EXECUTE_FAILED',
        },
        { status: 400 }
      );
    }

    logger.info('Off-ramp execution triggered', {
      requestId,
      daoId,
      executedBy: userId,
    });

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error executing off-ramp request',
      error instanceof Error ? error : new Error(String(error)),
      {
        url: '/api/dao/[id]/treasury/offramp/[requestId]/execute',
        method: 'POST',
      }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to execute off-ramp request',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
