/**
 * Treasury Unified Balance API Route
 *
 * GET - Get combined fiat + crypto balance for a DAO
 *
 * Requires authentication (member of DAO or public DAO)
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { hybridTreasuryService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/dao/{id}/treasury/unified-balance
 * Get combined balance across fiat and crypto rails
 * Requires authentication for private DAOs
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if DAO is private - require authentication
    if (dao.visibility === 'private') {
      const privyId =
        request.headers.get('x-auth-privy-id') ||
        request.headers.get('x-auth-uid');

      if (!privyId) {
        return NextResponse.json(
          {
            success: false,
            error: 'Authentication required',
            code: 'AUTH_REQUIRED',
          },
          { status: 401 }
        );
      }

      // Verify user exists
      const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
      if (!supabaseUser) {
        return NextResponse.json(
          { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
          { status: 404 }
        );
      }

      // Check membership for private DAOs
      const membership = await daoMemberAdminRepository.findByDaoAndUser(
        daoId,
        supabaseUser.id
      );
      const isMember = !!membership || dao.creatorId === supabaseUser.id;

      if (!isMember) {
        return NextResponse.json(
          {
            success: false,
            error: 'Member access required',
            code: 'PERMISSION_DENIED',
          },
          { status: 403 }
        );
      }
    }

    // Get unified balance
    const result = await hybridTreasuryService.getUnifiedBalance(daoId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get unified balance',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    // Short cache time since balance can change frequently
    return NextResponse.json(
      {
        success: true,
        data: result.data,
      },
      {
        headers: {
          'Cache-Control': 'private, max-age=15, stale-while-revalidate=10',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching unified balance',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/unified-balance', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch unified balance',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
