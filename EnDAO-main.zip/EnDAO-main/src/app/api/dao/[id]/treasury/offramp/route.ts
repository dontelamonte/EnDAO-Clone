/**
 * Treasury Off-ramp API Route
 *
 * POST - Initiate a new off-ramp request (crypto-to-fiat)
 * GET - List off-ramp requests for a DAO
 *
 * Requires authentication and admin permission
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { offrampService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';
import type { OfframpRequestStatus } from '@endao/shared-types';

/**
 * POST /api/dao/{id}/treasury/offramp
 * Initiate a new off-ramp request
 * Requires admin permission
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO admin
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isAdmin =
      membership?.role === 'admin' ||
      membership?.role === 'admin' ||
      dao.creatorId === userId;
    if (!isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Admin permission required',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { amountCrypto, cryptoCurrency, chainId, sourceAddress } = body as {
      amountCrypto: number;
      cryptoCurrency: string;
      chainId: number;
      sourceAddress: string;
    };

    // Validate required fields
    if (!amountCrypto || amountCrypto <= 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'Valid amount is required',
          code: 'INVALID_AMOUNT',
        },
        { status: 400 }
      );
    }

    if (!cryptoCurrency) {
      return NextResponse.json(
        {
          success: false,
          error: 'Crypto currency is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    if (!chainId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Chain ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    if (!sourceAddress) {
      return NextResponse.json(
        {
          success: false,
          error: 'Source address is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Initiate off-ramp request
    const result = await offrampService.initiateOfframp({
      daoId,
      amountCrypto,
      cryptoCurrency,
      chainId,
      sourceAddress,
      requestedBy: userId,
    });

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to initiate off-ramp',
          code: 'INITIATE_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error initiating off-ramp',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/offramp', method: 'POST' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to initiate off-ramp',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * GET /api/dao/{id}/treasury/offramp
 * List off-ramp requests for a DAO
 * Requires authentication (member of DAO)
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO member
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isMember = !!membership || dao.creatorId === userId;

    if (!isMember) {
      return NextResponse.json(
        {
          success: false,
          error: 'Member access required',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Parse query params
    const { searchParams } = new URL(request.url);
    const statusParam = searchParams.get('status');
    const limitParam = searchParams.get('limit');

    const options: { status?: OfframpRequestStatus; limit?: number } = {};
    if (statusParam) {
      options.status = statusParam as OfframpRequestStatus;
    }
    if (limitParam) {
      options.limit = parseInt(limitParam, 10);
    }

    // Get off-ramp requests
    const result = await offrampService.getOfframpRequests(daoId, options);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get off-ramp requests',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching off-ramp requests',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/offramp', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch off-ramp requests',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
