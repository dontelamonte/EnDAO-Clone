/**
 * Treasury Off-ramp Sign API Route
 *
 * POST - Add a signature to an off-ramp request (multi-sig approval)
 *
 * Requires authentication and admin permission
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { offrampService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';

/**
 * POST /api/dao/{id}/treasury/offramp/{requestId}/sign
 * Add a signature to an off-ramp request
 * Requires admin permission (multi-sig signer)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; requestId: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId, requestId } = await params;

    if (!daoId || !requestId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and request ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists and user is admin
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO admin (multi-sig signer)
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isAdmin =
      membership?.role === 'admin' ||
      membership?.role === 'admin' ||
      dao.creatorId === userId;
    if (!isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Admin permission required to sign off-ramp requests',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Get the off-ramp request first to verify it belongs to this DAO
    const existingRequest = await offrampService.getOfframpRequest(requestId);
    if (!existingRequest.success || !existingRequest.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Off-ramp request not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (existingRequest.data.daoId !== daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Off-ramp request not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { signature } = body as { signature: string };

    if (!signature) {
      return NextResponse.json(
        {
          success: false,
          error: 'Signature is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Add signature to off-ramp request
    const result = await offrampService.signOfframp({
      requestId,
      signerId: userId,
      signature,
    });

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to sign off-ramp request',
          code: 'SIGN_FAILED',
        },
        { status: 400 }
      );
    }

    // If request is now approved, check if we should auto-execute
    if (result.data?.status === 'approved') {
      // Log that request is now approved
      logger.info('Off-ramp request fully approved', {
        requestId,
        daoId,
        signaturesCollected: result.data.signaturesCollected.length,
        signaturesRequired: result.data.signaturesRequired,
      });

      // Note: Auto-execution can be triggered here if desired
      // For now, we return the approved status and let the admin execute manually
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error signing off-ramp request',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/offramp/[requestId]/sign', method: 'POST' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to sign off-ramp request',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
