/**
 * Treasury Off-ramp Request Detail API Route
 *
 * GET - Get details of a specific off-ramp request
 * DELETE - Cancel an off-ramp request
 *
 * Requires authentication and DAO membership
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { offrampService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/dao/{id}/treasury/offramp/{requestId}
 * Get details of a specific off-ramp request
 * Requires DAO membership
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; requestId: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId, requestId } = await params;

    if (!daoId || !requestId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and request ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO member
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isMember = !!membership || dao.creatorId === userId;

    if (!isMember) {
      return NextResponse.json(
        {
          success: false,
          error: 'Member access required',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Get off-ramp request
    const result = await offrampService.getOfframpRequest(requestId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get off-ramp request',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'Off-ramp request not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Verify request belongs to this DAO
    if (result.data.daoId !== daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Off-ramp request not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching off-ramp request',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/offramp/[requestId]', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch off-ramp request',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/dao/{id}/treasury/offramp/{requestId}
 * Cancel an off-ramp request
 * Requires admin permission
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; requestId: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId, requestId } = await params;

    if (!daoId || !requestId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID and request ID are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO admin
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isAdmin =
      membership?.role === 'admin' ||
      membership?.role === 'admin' ||
      dao.creatorId === userId;
    if (!isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Admin permission required',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Get reason from body
    let reason = 'Cancelled by admin';
    try {
      const body = await request.json();
      if (body.reason) {
        reason = body.reason;
      }
    } catch {
      // No body provided, use default reason
    }

    // Cancel off-ramp request
    const result = await offrampService.cancelOfframp(
      requestId,
      userId,
      reason
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to cancel off-ramp request',
          code: 'CANCEL_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error cancelling off-ramp request',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/offramp/[requestId]', method: 'DELETE' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to cancel off-ramp request',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
