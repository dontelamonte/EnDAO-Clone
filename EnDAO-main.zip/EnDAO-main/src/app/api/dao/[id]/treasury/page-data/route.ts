/**
 * Treasury Page Data API Route
 *
 * Batched endpoint that combines all data needed for the treasury page.
 * Reduces multiple API calls to a single request.
 *
 * Returns:
 * - DAO details
 * - User permissions
 * - Treasury access status
 * - Freeze records (if any)
 * - Safe balance and tokens (if treasury enabled)
 * - Recent transactions
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import { MemberPermissionsService } from '@/lib/services/dao/member-permissions';
import { TreasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';
import {
  userAdminRepository,
  daoAdminRepository,
  treasuryFreezeAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { DAO, DAOStatus } from '@endao/shared-types';

interface TreasuryAccessStatus {
  accessible: boolean;
  reason?:
    | 'dao_deleted'
    | 'dao_archived'
    | 'dao_pending_deletion'
    | 'treasury_frozen'
    | 'dao_not_found';
  details?: string;
  daoStatus?: DAOStatus;
  frozenAt?: string;
  frozenBy?: string;
  frozenReason?: string;
}

interface TreasuryFreezeRecord {
  daoId: string;
  frozenAt: string;
  frozenBy: string;
  reason: string;
  unfrozenAt?: string;
  unfrozenBy?: string;
  isActive: boolean;
}

interface UserPermissions {
  isAdmin: boolean;
  isMember: boolean;
  canVote: boolean;
  canPropose: boolean;
  canComment: boolean;
  canViewTreasury: boolean;
  canManageMembers: boolean;
  votingPower: number;
}

interface SafeBalance {
  totalValue: number;
  formattedTotal: string;
  tokens: Array<{
    symbol: string;
    balance: string;
    value: number;
    formattedValue: string;
  }>;
}

interface TreasuryTransaction {
  id: string;
  type: string;
  amount: string;
  token: string;
  timestamp: string;
  description: string;
  status: string;
}

interface TreasuryPageData {
  dao: DAO;
  permissions: UserPermissions;
  accessStatus: TreasuryAccessStatus;
  freezeRecord: TreasuryFreezeRecord | null;
  safeBalance: SafeBalance | null;
  recentTransactions: TreasuryTransaction[];
  treasuryEnabled: boolean;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header (required for treasury access)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    logger.debug('[Treasury Page Data API] Fetching data for DAO', {
      daoId: daoId.substring(0, 15) + '...',
    });

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        {
          success: false,
          error: 'User not found',
          code: 'USER_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Fetch DAO details
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: daoResult.error || 'DAO not found',
          code: 'DAO_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    if (!daoResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'DAO_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const dao = daoResult.data;

    // Get user permissions
    const permissionsService = MemberPermissionsService.getInstance();
    const permissionsResult = await permissionsService.getUserPermissions(
      daoId,
      userId
    );

    const permissions: UserPermissions =
      permissionsResult.success && permissionsResult.data
        ? {
            isAdmin: permissionsResult.data.isAdmin,
            isMember: permissionsResult.data.isActive,
            canVote: permissionsResult.data.canVote,
            canPropose: permissionsResult.data.canCreateProposals,
            canComment: permissionsResult.data.canComment,
            canViewTreasury: permissionsResult.data.canViewTreasury,
            canManageMembers: permissionsResult.data.canManageMembers,
            votingPower: permissionsResult.data.votingPower,
          }
        : {
            isAdmin: false,
            isMember: false,
            canVote: false,
            canPropose: false,
            canComment: false,
            canViewTreasury: false,
            canManageMembers: false,
            votingPower: 0,
          };

    // Check treasury access status
    let accessStatus: TreasuryAccessStatus = {
      accessible: true,
    };
    let freezeRecord: TreasuryFreezeRecord | null = null;

    // Get DAO from Supabase for status check
    const daoRecord = await daoAdminRepository.findById(daoId);
    if (!daoRecord) {
      accessStatus = {
        accessible: false,
        reason: 'dao_not_found',
        details: 'DAO does not exist',
      };
    } else {
      const daoStatus = daoRecord.status as DAOStatus;

      // Check DAO status - block access for problematic states
      const blockedStatuses: DAOStatus[] = [
        'deleted',
        'archived',
        'pending_deletion',
      ];
      if (blockedStatuses.includes(daoStatus)) {
        accessStatus = {
          accessible: false,
          reason: `dao_${daoStatus}` as TreasuryAccessStatus['reason'],
          details: `DAO is currently ${daoStatus}`,
          daoStatus,
        };
      } else {
        // Check if treasury is frozen
        const freeze =
          await treasuryFreezeAdminRepository.findActiveByDao(daoId);

        if (freeze) {
          const frozenAt =
            freeze.frozenAt instanceof Date
              ? freeze.frozenAt.toISOString()
              : freeze.frozenAt;

          accessStatus = {
            accessible: false,
            reason: 'treasury_frozen',
            details: `Treasury frozen: ${freeze.reason}`,
            daoStatus,
            frozenAt,
            frozenBy: freeze.frozenBy,
            frozenReason: freeze.reason || undefined,
          };

          freezeRecord = {
            daoId: freeze.daoId,
            frozenAt,
            frozenBy: freeze.frozenBy,
            reason: freeze.reason || '',
            unfrozenAt: freeze.unfrozenAt
              ? freeze.unfrozenAt instanceof Date
                ? freeze.unfrozenAt.toISOString()
                : freeze.unfrozenAt
              : undefined,
            unfrozenBy: freeze.unfrozenBy || undefined,
            isActive:
              !freeze.unfrozenAt &&
              (!freeze.expiresAt || new Date(freeze.expiresAt) > new Date()),
          };
        } else {
          accessStatus = {
            accessible: true,
            daoStatus,
          };
        }
      }
    }

    // Get Safe balance if treasury enabled and accessible
    let safeBalance: SafeBalance | null = null;
    if (dao.safeAddress && dao.treasuryEnabled && permissions.canViewTreasury) {
      // Use cached treasury value from DAO
      const cachedValue = dao.treasuryValue || 0;

      // Format as SafeBalance
      safeBalance = {
        totalValue: cachedValue,
        formattedTotal:
          cachedValue >= 1000000
            ? `$${(cachedValue / 1000000).toFixed(1)}M`
            : cachedValue >= 1000
              ? `$${(cachedValue / 1000).toFixed(1)}K`
              : `$${cachedValue.toFixed(2)}`,
        tokens: [
          {
            symbol: 'USDC',
            balance: cachedValue.toString(),
            value: cachedValue,
            formattedValue:
              cachedValue >= 1000000
                ? `$${(cachedValue / 1000000).toFixed(1)}M`
                : cachedValue >= 1000
                  ? `$${(cachedValue / 1000).toFixed(1)}K`
                  : `$${cachedValue.toFixed(2)}`,
          },
        ],
      };
    }

    // Get recent transactions (placeholder - implement when transaction history is available)
    const recentTransactions: TreasuryTransaction[] = [];

    const pageData: TreasuryPageData = {
      dao,
      permissions,
      accessStatus,
      freezeRecord,
      safeBalance,
      recentTransactions,
      treasuryEnabled: Boolean(dao.safeAddress && dao.treasuryEnabled),
    };

    return NextResponse.json(
      {
        success: true,
        data: pageData,
      },
      {
        headers: {
          // Cache for 15 seconds (treasury data changes moderately)
          'Cache-Control': 'public, max-age=15, stale-while-revalidate=10',
        },
      }
    );
  } catch (error) {
    logger.error(
      '[Treasury Page Data API] Error fetching page data',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch treasury page data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
