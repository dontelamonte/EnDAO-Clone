/**
 * Treasury Rails API Route
 *
 * GET - Get hybrid treasury rail status for a DAO
 * PATCH - Enable/disable rails or hybrid mode
 *
 * Requires authentication and admin permission for PATCH
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { hybridTreasuryService } from '@/lib/services/treasury';
import { logger } from '@/lib/services/logger.service';
import type { TreasuryRailStatus } from '@endao/shared-types';

/**
 * GET /api/dao/{id}/treasury/rails
 * Get the status of treasury rails (fiat + crypto)
 * Public endpoint - returns rail availability info
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Get rail status
    const result = await hybridTreasuryService.getRailStatus(daoId);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to get rail status',
          code: 'FETCH_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        success: true,
        data: result.data,
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=30, stale-while-revalidate=15',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching treasury rails',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/rails', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch treasury rails',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/dao/{id}/treasury/rails
 * Enable/disable rails or hybrid mode
 * Requires admin permission
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Parse request body
    const body = await request.json();
    const { action, railType, status } = body as {
      action:
        | 'enableHybrid'
        | 'disableHybrid'
        | 'enableRail'
        | 'updateRailStatus';
      railType?: 'fiat' | 'crypto';
      status?: TreasuryRailStatus;
    };

    if (!action) {
      return NextResponse.json(
        {
          success: false,
          error: 'Action is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Verify DAO exists
    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    // Check if user is DAO admin
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      userId
    );
    const isAdmin =
      membership?.role === 'admin' ||
      membership?.role === 'admin' ||
      dao.creatorId === userId;
    if (!isAdmin) {
      return NextResponse.json(
        {
          success: false,
          error: 'Admin permission required',
          code: 'PERMISSION_DENIED',
        },
        { status: 403 }
      );
    }

    // Execute action based on type
    let result;
    switch (action) {
      case 'enableHybrid':
        result = await hybridTreasuryService.enableHybridTreasury(
          daoId,
          userId
        );
        break;

      case 'disableHybrid':
        result = await hybridTreasuryService.disableHybridTreasury(
          daoId,
          userId
        );
        break;

      case 'enableRail':
        if (!railType) {
          return NextResponse.json(
            {
              success: false,
              error: 'railType is required for enableRail action',
              code: 'MISSING_PARAMETER',
            },
            { status: 400 }
          );
        }
        result =
          railType === 'fiat'
            ? await hybridTreasuryService.enableFiatRail(daoId)
            : await hybridTreasuryService.enableCryptoRail(daoId);
        break;

      case 'updateRailStatus':
        if (!railType || !status) {
          return NextResponse.json(
            {
              success: false,
              error:
                'railType and status are required for updateRailStatus action',
              code: 'MISSING_PARAMETER',
            },
            { status: 400 }
          );
        }
        result = await hybridTreasuryService.updateRailStatus(
          daoId,
          railType,
          status
        );
        break;

      default:
        return NextResponse.json(
          {
            success: false,
            error: 'Invalid action',
            code: 'INVALID_ACTION',
          },
          { status: 400 }
        );
    }

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to update treasury rails',
          code: 'UPDATE_FAILED',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error updating treasury rails',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/treasury/rails', method: 'PATCH' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to update treasury rails',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
