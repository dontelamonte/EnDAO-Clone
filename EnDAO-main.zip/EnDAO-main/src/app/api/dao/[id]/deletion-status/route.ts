/**
 * DAO Deletion Status API Route
 *
 * GET - Get grace period status and recovery eligibility
 * Server-side endpoint to avoid browser-safety violations
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoSoftDeleteService,
  type GracePeriodStatus,
} from '@/lib/services/dao/dao-soft-delete.service';
import { logger } from '@/lib/services/logger.service';

interface DeletionStatusResponse {
  success: boolean;
  data?: {
    gracePeriodStatus: GracePeriodStatus | null;
    canRecover: boolean;
  };
  error?: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse<DeletionStatusResponse>> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Get grace period status
    const statusResult =
      await daoSoftDeleteService.checkGracePeriodStatus(daoId);

    // Get recovery eligibility
    const canRecoverResult = await daoSoftDeleteService.canRecover(daoId);

    return NextResponse.json({
      success: true,
      data: {
        gracePeriodStatus: statusResult.success
          ? (statusResult.data ?? null)
          : null,
        canRecover: canRecoverResult.success
          ? (canRecoverResult.data ?? false)
          : false,
      },
    });
  } catch (error) {
    logger.error(
      '[DAO Deletion Status API] Error fetching deletion status',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch deletion status' },
      { status: 500 }
    );
  }
}
