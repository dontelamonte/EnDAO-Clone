import { NextRequest, NextResponse } from 'next/server';
import { voteDelegationService } from '@/lib/services/delegation';
import { userAdminRepository } from '@/lib/data/repositories/supabase/user.repository';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/dao/[id]/voting-power
 * Get effective voting power for the authenticated user
 * Query params:
 *   - proposalId: Optional proposal ID for proposal-specific delegation filtering
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    // Get auth headers
    const privyId = request.headers.get('x-auth-privy-id');
    const userId = request.headers.get('x-auth-uid');

    if (!privyId && !userId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Resolve user ID
    let internalUserId: string | null = userId;
    if (privyId && !userId) {
      const user = await userAdminRepository.findByPrivyId(privyId);
      if (!user) {
        return NextResponse.json(
          { success: false, error: 'User not found' },
          { status: 401 }
        );
      }
      internalUserId = user.id;
    }

    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'Could not resolve user ID' },
        { status: 401 }
      );
    }

    // Parse query params
    const searchParams = request.nextUrl.searchParams;
    const proposalId = searchParams.get('proposalId') || undefined;

    // Get effective voting power
    const result = await voteDelegationService.getEffectiveVotingPower(
      internalUserId,
      daoId,
      proposalId
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to get voting power' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error fetching voting power',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/voting-power', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch voting power' },
      { status: 500 }
    );
  }
}
