import { NextRequest, NextResponse } from 'next/server';
import {
  DAOReportsService,
  ReportType,
  ExportFormat,
} from '@/lib/services/dao/dao-reports.service';
import { daoMemberAdminRepository } from '@/lib/data/repositories';
import { userAdminRepository } from '@/lib/data/repositories/supabase/user.repository';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/dao/[id]/reports
 * Get available report types
 *
 * POST /api/dao/[id]/reports
 * Generate a report
 * Body: { type: ReportType, format: ExportFormat, startDate?: string, endDate?: string }
 */

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    // Check admin permission
    const permissionCheck = await checkAdminPermission(request, daoId);
    if (permissionCheck.error) {
      return permissionCheck.error;
    }

    const reportsService = DAOReportsService.getInstance();
    const availableReports = reportsService.getAvailableReports();

    return NextResponse.json({
      success: true,
      data: availableReports,
    });
  } catch (error) {
    logger.error(
      'Error fetching available reports',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/reports', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch available reports' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    // Check admin permission
    const permissionCheck = await checkAdminPermission(request, daoId);
    if (permissionCheck.error) {
      return permissionCheck.error;
    }

    // Parse request body
    const body = await request.json();
    const { type, format, startDate, endDate } = body as {
      type: ReportType;
      format: ExportFormat;
      startDate?: string;
      endDate?: string;
    };

    // Validate required fields
    if (!type || !format) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields: type and format' },
        { status: 400 }
      );
    }

    // Validate type
    const validTypes: ReportType[] = [
      'members',
      'treasury',
      'activity',
      'proposals',
      'summary',
    ];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        {
          success: false,
          error: `Invalid report type. Must be one of: ${validTypes.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // Validate format
    const validFormats: ExportFormat[] = ['csv', 'json', 'pdf'];
    if (!validFormats.includes(format)) {
      return NextResponse.json(
        {
          success: false,
          error: `Invalid format. Must be one of: ${validFormats.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // Parse dates
    const options = {
      format,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
    };

    // Generate report
    const reportsService = DAOReportsService.getInstance();
    const result = await reportsService.generateReport(daoId, type, options);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to generate report' },
        { status: 500 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        { success: false, error: 'Failed to generate report' },
        { status: 500 }
      );
    }

    // Return report content with download headers
    const { content, filename, mimeType, metadata } = result.data;

    // For direct download, return file content
    if (request.headers.get('Accept')?.includes('application/octet-stream')) {
      return new NextResponse(content, {
        headers: {
          'Content-Type': mimeType,
          'Content-Disposition': `attachment; filename="${filename}"`,
        },
      });
    }

    // Otherwise return JSON with content
    return NextResponse.json({
      success: true,
      data: {
        content,
        filename,
        mimeType,
        metadata,
      },
    });
  } catch (error) {
    logger.error(
      'Error generating report',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/reports', method: 'POST' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to generate report' },
      { status: 500 }
    );
  }
}

/**
 * Check if user has admin permission for the DAO
 */
async function checkAdminPermission(
  request: NextRequest,
  daoId: string
): Promise<{ error?: NextResponse }> {
  // Get auth headers
  const privyId = request.headers.get('x-auth-privy-id');
  const userId = request.headers.get('x-auth-uid');

  if (!privyId && !userId) {
    return {
      error: NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      ),
    };
  }

  // Resolve Privy ID to internal user ID if needed
  let internalUserId = userId;
  if (privyId && !userId) {
    const user = await userAdminRepository.findByPrivyId(privyId);
    if (!user) {
      return {
        error: NextResponse.json(
          { success: false, error: 'User not found' },
          { status: 401 }
        ),
      };
    }
    internalUserId = user.id;
  }

  if (!internalUserId) {
    return {
      error: NextResponse.json(
        { success: false, error: 'Could not resolve user ID' },
        { status: 401 }
      ),
    };
  }

  // Check if user is admin/owner of the DAO
  const membership = await daoMemberAdminRepository.findByDaoAndUser(
    daoId,
    internalUserId
  );

  if (!membership) {
    return {
      error: NextResponse.json(
        { success: false, error: 'You are not a member of this DAO' },
        { status: 403 }
      ),
    };
  }

  if (membership.role !== 'admin') {
    return {
      error: NextResponse.json(
        { success: false, error: 'Admin access required to generate reports' },
        { status: 403 }
      ),
    };
  }

  return {};
}
