/**
 * Membership API endpoint
 * Uses Supabase Admin to query membership, bypassing RLS policies
 * Maps Privy ID to Supabase UUID for database queries
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      // User doesn't exist in Supabase yet - not a member
      return NextResponse.json({
        success: true,
        data: { membership: null },
      });
    }

    // Query membership using Supabase UUID
    // The repository returns a properly typed DAOMember or null
    const membership = await daoMemberAdminRepository.findByDaoAndUser(
      daoId,
      supabaseUser.id
    );

    return NextResponse.json({
      success: true,
      data: { membership },
    });
  } catch (error) {
    logger.error(
      'Error fetching membership',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/membership', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch membership' },
      { status: 500 }
    );
  }
}
