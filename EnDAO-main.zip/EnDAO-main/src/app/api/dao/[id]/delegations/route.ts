import { NextRequest, NextResponse } from 'next/server';
import { voteDelegationService } from '@/lib/services/delegation';
import {
  voteDelegationAdminRepository,
  daoMemberAdminRepository,
} from '@/lib/data/repositories/supabase';
import { userAdminRepository } from '@/lib/data/repositories/supabase/user.repository';
import { z } from 'zod';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/dao/[id]/delegations
 * Get all delegations in a DAO (with user info)
 * Query params:
 *   - userId: Filter by delegator or delegatee
 *   - type: 'given' | 'received' | 'all'
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    // Get auth headers
    const privyId = request.headers.get('x-auth-privy-id');
    const userId = request.headers.get('x-auth-uid');

    // Resolve user ID
    let internalUserId: string | null = userId;
    if (privyId && !userId) {
      const user = await userAdminRepository.findByPrivyId(privyId);
      if (user) {
        internalUserId = user.id;
      }
    }

    // Check if user is member of DAO
    if (internalUserId) {
      const membership = await daoMemberAdminRepository.findByDaoAndUser(
        daoId,
        internalUserId
      );
      if (!membership || membership.status !== 'active') {
        return NextResponse.json(
          { success: false, error: 'Must be a DAO member to view delegations' },
          { status: 403 }
        );
      }
    }

    // Parse query params
    const searchParams = request.nextUrl.searchParams;
    const filterUserId = searchParams.get('userId');
    const type = searchParams.get('type') || 'all';

    let delegations;

    if (filterUserId) {
      if (type === 'given') {
        const result = await voteDelegationService.getDelegationsGiven(
          filterUserId,
          daoId
        );
        delegations = result.data || [];
      } else if (type === 'received') {
        const result = await voteDelegationService.getDelegationsReceived(
          filterUserId,
          daoId
        );
        delegations = result.data || [];
      } else {
        // Get both
        const given = await voteDelegationService.getDelegationsGiven(
          filterUserId,
          daoId
        );
        const received = await voteDelegationService.getDelegationsReceived(
          filterUserId,
          daoId
        );
        delegations = {
          given: given.data || [],
          received: received.data || [],
        };
      }
    } else {
      // Get all delegations in DAO with user info
      const result = await voteDelegationService.getDelegationsWithUsers(daoId);
      delegations = result.data || [];
    }

    return NextResponse.json({
      success: true,
      data: delegations,
    });
  } catch (error) {
    logger.error(
      'Error fetching delegations',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/delegations', method: 'GET' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch delegations' },
      { status: 500 }
    );
  }
}

// Validation schema for creating delegation
const createDelegationSchema = z.object({
  delegateeId: z.string().uuid('Invalid delegatee ID'),
  proposalIds: z.array(z.string().uuid()).optional(),
  proposalTypes: z.array(z.string()).optional(),
  percentage: z.number().min(1).max(100).optional(),
  expiresAt: z.string().datetime().optional(),
});

/**
 * POST /api/dao/[id]/delegations
 * Create a new delegation
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    // Get auth headers
    const privyId = request.headers.get('x-auth-privy-id');
    const userId = request.headers.get('x-auth-uid');

    if (!privyId && !userId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Resolve user ID
    let internalUserId: string | null = userId;
    if (privyId && !userId) {
      const user = await userAdminRepository.findByPrivyId(privyId);
      if (!user) {
        return NextResponse.json(
          { success: false, error: 'User not found' },
          { status: 401 }
        );
      }
      internalUserId = user.id;
    }

    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'Could not resolve user ID' },
        { status: 401 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const parseResult = createDelegationSchema.safeParse(body);

    if (!parseResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request body',
          details: parseResult.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { delegateeId, proposalIds, proposalTypes, percentage, expiresAt } =
      parseResult.data;

    // Create delegation via service
    const result = await voteDelegationService.delegateVotingPower({
      daoId,
      delegatorId: internalUserId,
      delegateeId,
      proposalIds,
      proposalTypes,
      percentage,
      expiresAt,
    });

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to create delegation',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Error creating delegation',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/delegations', method: 'POST' }
    );
    return NextResponse.json(
      { success: false, error: 'Failed to create delegation' },
      { status: 500 }
    );
  }
}
