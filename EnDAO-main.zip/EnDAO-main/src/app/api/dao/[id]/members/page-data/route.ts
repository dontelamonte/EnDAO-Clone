/**
 * Members Page Data API Route
 *
 * Batched endpoint that combines all data needed for the members page.
 * Reduces multiple API calls to a single request.
 *
 * Returns:
 * - DAO details
 * - User permissions
 * - Full member list with roles and activity
 * - Member statistics
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import { MemberPermissionsService } from '@/lib/services/dao/member-permissions';
import { userAdminRepository } from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { DAO, MemberRole } from '@endao/shared-types';

interface UserPermissions {
  isAdmin: boolean;
  isMember: boolean;
  canVote: boolean;
  canPropose: boolean;
  canComment: boolean;
  canViewTreasury: boolean;
  canManageMembers: boolean;
  votingPower: number;
}

interface MemberStats {
  totalMembers: number;
  activeMembers: number;
  adminCount: number;
  recentJoins: number;
}

/**
 * Member data enriched with user profile information
 */
interface MemberWithProfile {
  userId: string;
  role: MemberRole;
  joinedAt: string;
  displayName: string | null;
  username: string | null;
  avatarUrl: string | null;
  email: string | null;
  walletAddress: string | null;
}

interface MembersPageData {
  dao: DAO;
  permissions: UserPermissions;
  members: MemberWithProfile[];
  stats: MemberStats;
  hasMore: boolean;
  total: number;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header (required for member management)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Get pagination params from query string
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit') || '50', 10);
    const offset = parseInt(url.searchParams.get('offset') || '0', 10);
    const sortBy = (url.searchParams.get('sortBy') || 'joinedAt') as
      | 'joinedAt'
      | 'lastActivityAt'
      | 'proposalsCreated'
      | 'votesCount';
    const sortOrder = (url.searchParams.get('sortOrder') || 'desc') as
      | 'asc'
      | 'desc';

    logger.debug('[Members Page Data API] Fetching data for DAO', {
      daoId: daoId.substring(0, 15) + '...',
      limit,
      offset,
      sortBy,
      sortOrder,
    });

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        {
          success: false,
          error: 'User not found',
          code: 'USER_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Fetch DAO details
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: daoResult.error,
          code: daoResult.code,
        },
        { status: 404 }
      );
    }

    if (!daoResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO not found',
          code: 'NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const dao = daoResult.data;

    // Get user permissions
    const permissionsService = MemberPermissionsService.getInstance();
    const permissionsResult = await permissionsService.getUserPermissions(
      daoId,
      userId
    );

    const permissions: UserPermissions =
      permissionsResult.success && permissionsResult.data
        ? {
            isAdmin: permissionsResult.data.isAdmin,
            isMember: permissionsResult.data.isActive,
            canVote: permissionsResult.data.canVote,
            canPropose: permissionsResult.data.canCreateProposals,
            canComment: permissionsResult.data.canComment,
            canViewTreasury: permissionsResult.data.canViewTreasury,
            canManageMembers: permissionsResult.data.canManageMembers,
            votingPower: permissionsResult.data.votingPower,
          }
        : {
            isAdmin: false,
            isMember: false,
            canVote: false,
            canPropose: false,
            canComment: false,
            canViewTreasury: false,
            canManageMembers: false,
            votingPower: 0,
          };

    // Only allow member viewing if user is a member
    if (!permissions.isMember) {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be a member to view the member list',
          code: 'INSUFFICIENT_PERMISSIONS',
        },
        { status: 403 }
      );
    }

    // Get members with pagination
    const membersResult = await daoService.getDAOMembers(daoId, {
      limit,
      offset,
      sortBy,
      sortOrder,
      isActive: true, // Only show active members by default
    });

    if (!membersResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: membersResult.error,
          code: membersResult.code,
        },
        { status: 500 }
      );
    }

    if (!membersResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'No members data returned',
          code: 'NOT_FOUND',
        },
        { status: 500 }
      );
    }

    const { members: rawMembers, total, hasMore } = membersResult.data;

    // Fetch user profiles for all members to enrich with displayName, username, etc.
    const userIds = rawMembers.map((m) => m.userId);
    const userProfiles = await userAdminRepository.findByIds(userIds);
    const userProfileMap = new Map(userProfiles.map((u) => [u.id, u]));

    // Enrich members with profile data
    const members = rawMembers.map((member) => {
      const profile = userProfileMap.get(member.userId);
      return {
        userId: member.userId,
        role: member.role,
        joinedAt: member.joinedAt,
        displayName: profile?.displayName ?? null,
        username: profile?.username ?? null,
        avatarUrl: profile?.avatarUrl ?? null,
        email: profile?.email ?? null,
        walletAddress: null, // Not stored in user profile, would need separate wallet lookup
      };
    });

    // Calculate member statistics
    const activeMembers = rawMembers.filter((m) => m.isActive).length;
    const adminCount = rawMembers.filter(
      (m) => m.role === 'admin' && m.isActive
    ).length;

    // Calculate recent joins (members who joined in the last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentJoins = members.filter((m) => {
      const joinDate = new Date(m.joinedAt);
      return joinDate >= thirtyDaysAgo;
    }).length;

    const stats: MemberStats = {
      totalMembers: total,
      activeMembers,
      adminCount,
      recentJoins,
    };

    const pageData: MembersPageData = {
      dao,
      permissions,
      members,
      stats,
      hasMore,
      total,
    };

    return NextResponse.json(
      {
        success: true,
        data: pageData,
      },
      {
        headers: {
          // Cache for 30 seconds (member data changes moderately)
          'Cache-Control': 'public, max-age=30, stale-while-revalidate=15',
        },
      }
    );
  } catch (error) {
    logger.error(
      '[Members Page Data API] Error fetching page data',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch members page data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
