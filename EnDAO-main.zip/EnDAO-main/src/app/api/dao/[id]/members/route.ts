/**
 * DAO Members API endpoint
 * GET - Query members with pagination and filtering
 * POST - Member management actions (add, remove, promote, demote)
 * Uses Supabase Admin to query/modify members, bypassing RLS policies
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import {
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { DAOService } from '@/lib/services/dao';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import type { MemberRole } from '@endao/shared-types';

// Validation schema for member actions
const memberActionSchema = z.object({
  action: z.enum(['add', 'remove', 'promote', 'demote']),
  memberId: z.string().uuid('Invalid member ID format'),
  role: z.enum(['member', 'admin']).optional(),
  reason: z.string().optional(),
});

type MemberActionRequest = z.infer<typeof memberActionSchema>;

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Apply rate limiting for member reads (50/min)
    const rateLimitResult = await rateLimiters.memberRead(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Verify user exists (authentication check)
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);
    const sortBy = searchParams.get('sortBy') || 'joinedAt';
    const sortOrder = (searchParams.get('sortOrder') || 'desc') as
      | 'asc'
      | 'desc';
    const role = searchParams.get('role') as MemberRole | null;

    // Map sortBy to repository-compatible field
    let repoSortBy: 'joinedAt' | 'role' | 'displayName' = 'joinedAt';
    if (sortBy === 'joinedAt') {
      repoSortBy = 'joinedAt';
    } else if (sortBy === 'role') {
      repoSortBy = 'role';
    } else if (sortBy === 'displayName') {
      repoSortBy = 'displayName';
    }
    // Note: 'lastActivityAt', 'proposalsCreated', 'votesCount' not directly supported
    // Default to joinedAt for these cases

    // Query members with pagination
    const result = await daoMemberAdminRepository.findMembersPaginated(daoId, {
      limit,
      offset,
      sortBy: repoSortBy,
      sortOrder,
      roles: role ? [role] : undefined,
    });

    // Calculate hasMore based on pagination
    const hasMore = offset + result.members.length < result.total;

    // Add caching headers - 30 sec cache (member list can change)
    return NextResponse.json(
      {
        success: true,
        data: {
          members: result.members,
          total: result.total,
          hasMore,
        },
      },
      {
        headers: {
          'Cache-Control': 'private, max-age=30, stale-while-revalidate=15',
        },
      }
    );
  } catch (error) {
    logger.error(
      'Error fetching DAO members',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/dao/[id]/members', method: 'GET' }
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch members',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}

/**
 * POST - Member management actions
 * Supports: add, remove, promote, demote
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    // Apply rate limiting for member privilege operations (10/min)
    const rateLimitResult = await rateLimiters.memberWrite(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Parse and validate request body
    const rawBody = await request.json();
    const validationResult = memberActionSchema.safeParse(rawBody);

    if (!validationResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request data',
          code: 'VALIDATION_ERROR',
          details: validationResult.error.errors,
        },
        { status: 400 }
      );
    }

    const { action, memberId, role, reason } = validationResult.data;
    const daoService = DAOService.getInstance();

    // Prevent users from modifying their own membership
    if (
      userId === memberId &&
      (action === 'remove' || action === 'promote' || action === 'demote')
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            'You cannot modify your own membership role or remove yourself',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    switch (action) {
      case 'add': {
        // Verify admin permission for adding members
        const isAdmin = await daoService.isUserAdmin(daoId, userId);
        if (!isAdmin.success || !isAdmin.data) {
          return NextResponse.json(
            {
              success: false,
              error: 'Insufficient permissions. Only admins can add members',
              code: 'FORBIDDEN',
            },
            { status: 403 }
          );
        }

        // Only super admins can add members as admins
        if (role === 'admin') {
          // For now, we'll allow any admin to add admin members
          // If we need super admin check, we can add it here
        }

        const result = await daoService.addMember(
          daoId,
          memberId,
          role || 'member',
          userId
        );
        if (!result.success) {
          return NextResponse.json(
            {
              success: false,
              error: result.error || 'Failed to add member',
              code: 'VALIDATION_ERROR',
            },
            { status: 400 }
          );
        }
        return NextResponse.json({ success: true, data: result.data });
      }

      case 'remove': {
        const result = await daoService.removeMember(
          daoId,
          memberId,
          userId,
          reason
        );
        if (!result.success) {
          return NextResponse.json(
            {
              success: false,
              error: result.error || 'Failed to remove member',
              code: 'VALIDATION_ERROR',
            },
            { status: 400 }
          );
        }
        return NextResponse.json({ success: true, data: { removed: true } });
      }

      case 'promote': {
        const result = await daoService.promoteMember(daoId, memberId, userId);
        if (!result.success) {
          return NextResponse.json(
            {
              success: false,
              error: result.error || 'Failed to promote member',
              code: 'VALIDATION_ERROR',
            },
            { status: 400 }
          );
        }
        return NextResponse.json({ success: true, data: result.data });
      }

      case 'demote': {
        const result = await daoService.demoteMember(daoId, memberId, userId);
        if (!result.success) {
          return NextResponse.json(
            {
              success: false,
              error: result.error || 'Failed to demote member',
              code: 'VALIDATION_ERROR',
            },
            { status: 400 }
          );
        }
        return NextResponse.json({ success: true, data: result.data });
      }

      default:
        return NextResponse.json(
          {
            success: false,
            error: 'Invalid action. Supported: add, remove, promote, demote',
            code: 'INVALID_REQUEST',
          },
          { status: 400 }
        );
    }
  } catch (error) {
    logger.error(
      '[Members API] Error processing member action',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to process member action',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
