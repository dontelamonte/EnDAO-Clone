/**
 * Treasury Access API Route
 *
 * Server-side endpoint for checking treasury access status.
 * Maps Privy ID to Supabase UUID before querying.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoAdminRepository,
  treasuryFreezeAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { DAOStatus } from '@endao/shared-types';

export interface TreasuryAccessStatus {
  accessible: boolean;
  reason?:
    | 'dao_deleted'
    | 'dao_archived'
    | 'dao_pending_deletion'
    | 'treasury_frozen'
    | 'dao_not_found';
  details?: string;
  daoStatus?: DAOStatus;
  frozenAt?: string;
  frozenBy?: string;
  frozenReason?: string;
}

export interface TreasuryFreezeRecord {
  daoId: string;
  frozenAt: string;
  frozenBy: string;
  reason: string;
  unfrozenAt?: string;
  unfrozenBy?: string;
  isActive: boolean;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Get DAO from Supabase
    const dao = await daoAdminRepository.findById(daoId);

    if (!dao) {
      const accessStatus: TreasuryAccessStatus = {
        accessible: false,
        reason: 'dao_not_found',
        details: 'DAO does not exist',
      };
      return NextResponse.json({
        success: true,
        data: { accessStatus, freezeRecord: null },
      });
    }

    const daoStatus = dao.status as DAOStatus;

    // Check DAO status - block access for problematic states
    const blockedStatuses: DAOStatus[] = [
      'deleted',
      'archived',
      'pending_deletion',
    ];
    if (blockedStatuses.includes(daoStatus)) {
      const accessStatus: TreasuryAccessStatus = {
        accessible: false,
        reason: `dao_${daoStatus}` as TreasuryAccessStatus['reason'],
        details: `DAO is currently ${daoStatus}`,
        daoStatus,
      };
      return NextResponse.json({
        success: true,
        data: { accessStatus, freezeRecord: null },
      });
    }

    // Check if treasury is frozen
    const freeze = await treasuryFreezeAdminRepository.findActiveByDao(daoId);

    if (freeze) {
      const frozenAt =
        freeze.frozenAt instanceof Date
          ? freeze.frozenAt.toISOString()
          : freeze.frozenAt;

      const accessStatus: TreasuryAccessStatus = {
        accessible: false,
        reason: 'treasury_frozen',
        details: `Treasury frozen: ${freeze.reason}`,
        daoStatus,
        frozenAt,
        frozenBy: freeze.frozenBy,
        frozenReason: freeze.reason || undefined,
      };

      const freezeRecord: TreasuryFreezeRecord = {
        daoId: freeze.daoId,
        frozenAt,
        frozenBy: freeze.frozenBy,
        reason: freeze.reason || '',
        unfrozenAt: freeze.unfrozenAt
          ? freeze.unfrozenAt instanceof Date
            ? freeze.unfrozenAt.toISOString()
            : freeze.unfrozenAt
          : undefined,
        unfrozenBy: freeze.unfrozenBy || undefined,
        isActive:
          !freeze.unfrozenAt &&
          (!freeze.expiresAt || new Date(freeze.expiresAt) > new Date()),
      };

      return NextResponse.json({
        success: true,
        data: { accessStatus, freezeRecord },
      });
    }

    // Access allowed
    const accessStatus: TreasuryAccessStatus = {
      accessible: true,
      daoStatus,
    };

    return NextResponse.json({
      success: true,
      data: { accessStatus, freezeRecord: null },
    });
  } catch (error) {
    logger.error('[Treasury Access API] Error checking access', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to check treasury access' },
      { status: 500 }
    );
  }
}
