/**
 * DAO Search API Route
 *
 * GET - Search DAOs with filtering and pagination
 * Browser-safe wrapper around DAOQueryService.searchDAOs
 *
 * Query params:
 * - query: Search text (name, description, tags)
 * - category: Filter by category
 * - status: Filter by status (default: active)
 * - limit: Max results (default: 20, max: 100)
 * - offset: Pagination offset
 * - sortBy: Sort field (createdAt, memberCount, etc.)
 * - sortOrder: asc or desc
 * - isFeatured: true/false
 * - isVerified: true/false
 * - isDiscoverable: 'all' | 'true' | 'false' (default: true for public search, 'all' for admin dashboard)
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import { logger } from '@/lib/services/logger.service';
import type { DAOSearchFilters, DAO } from '@endao/shared-types';

interface SearchResponse {
  success: boolean;
  data?: {
    daos: DAO[];
    total: number;
    hasMore: boolean;
  };
  error?: string;
}

export async function GET(
  request: NextRequest
): Promise<NextResponse<SearchResponse>> {
  try {
    const { searchParams } = new URL(request.url);

    // Build filters from query params
    const filters: DAOSearchFilters = {};

    const query = searchParams.get('query');
    if (query) {
      filters.query = query;
    }

    const category = searchParams.get('category');
    if (category) {
      filters.category = category as DAOSearchFilters['category'];
    }

    const status = searchParams.get('status');
    if (status) {
      filters.status = status as DAOSearchFilters['status'];
    }

    const limit = searchParams.get('limit');
    if (limit) {
      filters.limit = Math.min(parseInt(limit, 10) || 20, 100);
    }

    const offset = searchParams.get('offset');
    if (offset) {
      filters.offset = parseInt(offset, 10) || 0;
    }

    const sortBy = searchParams.get('sortBy');
    if (sortBy) {
      filters.sortBy = sortBy as DAOSearchFilters['sortBy'];
    }

    const sortOrder = searchParams.get('sortOrder');
    if (sortOrder) {
      filters.sortOrder = sortOrder as 'asc' | 'desc';
    }

    const isFeatured = searchParams.get('isFeatured');
    if (isFeatured !== null) {
      filters.isFeatured = isFeatured === 'true';
    }

    const isVerified = searchParams.get('isVerified');
    if (isVerified !== null) {
      filters.isVerified = isVerified === 'true';
    }

    // Handle isDiscoverable filter
    // 'all' = show all DAOs regardless of discoverability (for admin dashboard)
    // 'true' = only discoverable (default for public search)
    // 'false' = only non-discoverable
    const isDiscoverable = searchParams.get('isDiscoverable');
    if (isDiscoverable === 'all') {
      // Explicitly set to undefined to skip the default filter in the service
      filters.isDiscoverable = undefined;
    } else if (isDiscoverable !== null) {
      filters.isDiscoverable = isDiscoverable === 'true';
    }

    // Search using the service
    const daoService = DAOService.getInstance();
    const result = await daoService.searchDAOs(filters);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Search failed',
          code: 'FETCH_FAILED',
        },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        daos: result.data?.daos || [],
        total: result.data?.total || 0,
        hasMore: result.data?.hasMore || false,
      },
    });
  } catch (error) {
    logger.error('[DAO Search API] Error searching DAOs', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to search DAOs',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
