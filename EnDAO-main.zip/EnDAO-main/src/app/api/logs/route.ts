/**
 * API endpoint for collecting and processing application logs
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// Log entry validation schema
const logEntrySchema = z.object({
  level: z.number().min(0).max(4),
  message: z.string().min(1).max(1000),
  timestamp: z.string(),
  context: z.record(z.string(), z.unknown()).optional(),
  environment: z.string(),
  version: z.string(),
  source: z.enum(['client', 'server']),
  traceId: z.string().optional(),
  spanId: z.string().optional(),
});

// Rate limiting map (in production, use Redis or similar)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();

const RATE_LIMIT = {
  requests: 100, // requests per window
  windowMs: 15 * 60 * 1000, // 15 minutes
};

function getRateLimitKey(request: NextRequest): string {
  // Use IP address or user ID for rate limiting
  const forwarded = request.headers.get('x-forwarded-for');
  const ip = forwarded ? forwarded.split(',')[0] : 'unknown';
  return `logs:${ip}`;
}

function checkRateLimit(key: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = rateLimitMap.get(key);

  if (!record || now > record.resetTime) {
    // Create new record or reset expired one
    rateLimitMap.set(key, {
      count: 1,
      resetTime: now + RATE_LIMIT.windowMs,
    });
    return { allowed: true, remaining: RATE_LIMIT.requests - 1 };
  }

  if (record.count >= RATE_LIMIT.requests) {
    return { allowed: false, remaining: 0 };
  }

  record.count++;
  return { allowed: true, remaining: RATE_LIMIT.requests - record.count };
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const rateLimitKey = getRateLimitKey(request);
    const { allowed, remaining } = checkRateLimit(rateLimitKey);

    if (!allowed) {
      return NextResponse.json(
        { error: 'Rate limit exceeded' },
        {
          status: 429,
          headers: {
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': String(
              rateLimitMap.get(rateLimitKey)?.resetTime || 0
            ),
          },
        }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedLog = logEntrySchema.parse(body);

    // Process the log entry
    await processLogEntry(validatedLog, request);

    return NextResponse.json(
      { success: true, id: generateLogId() },
      {
        headers: {
          'X-RateLimit-Remaining': String(remaining),
        },
      }
    );
  } catch (error) {
    console.error('Error processing log entry:', error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid log entry format', details: error.issues },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

async function processLogEntry(
  logEntry: z.infer<typeof logEntrySchema>,
  request: NextRequest
) {
  const enrichedLog = {
    ...logEntry,
    receivedAt: new Date().toISOString(),
    ip: getClientIP(request),
    userAgent: request.headers.get('user-agent'),
    referer: request.headers.get('referer'),
  };

  // Log to console in development
  if (process.env.NODE_ENV === 'development') {
    const levelNames = ['DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL'];
    const level = levelNames[logEntry.level] || 'UNKNOWN';
    console.log('[%s]', level, logEntry.message, {
      context: logEntry.context,
      timestamp: logEntry.timestamp,
      traceId: logEntry.traceId,
    });
  }

  // In production, send to external logging service
  if (process.env.NODE_ENV === 'production') {
    await sendToLoggingService(enrichedLog);
  }

  // Store critical errors for immediate attention
  if (logEntry.level >= 3) {
    // ERROR or FATAL
    await storeCriticalError(enrichedLog);
  }
}

async function sendToLoggingService(logEntry: Record<string, unknown>) {
  try {
    // Example integrations:
    // Send to DataDog
    // await fetch('https://http-intake.logs.datadoghq.com/v1/input/' + process.env.DATADOG_API_KEY, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(logEntry)
    // })
    // Send to Logtail (BetterStack)
    // await fetch('https://in.logtail.com/', {
    //   method: 'POST',
    //   headers: {
    //     'Authorization': `Bearer ${process.env.LOGTAIL_TOKEN}`,
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify(logEntry)
    // })
    // Send to LogRocket
    // if (process.env.LOGROCKET_APP_ID) {
    //   // LogRocket server-side logging
    // }
  } catch (error) {
    console.error('Failed to send log to external service:', error);
  }
}

async function storeCriticalError(logEntry: Record<string, unknown>) {
  try {
    // Store in database or send to alerting system
    // This could integrate with:
    // - Supabase for persistence
    // - Slack/Discord webhooks for alerts
    // - PagerDuty for incident management

    console.error('CRITICAL ERROR STORED:', {
      message: logEntry.message,
      context: logEntry.context,
      timestamp: logEntry.timestamp,
      ip: logEntry.ip,
    });

    // Send alert for fatal errors
    if (logEntry.level === 4) {
      // FATAL
      await sendFatalErrorAlert(logEntry);
    }
  } catch (error) {
    console.error('Failed to store critical error:', error);
  }
}

async function sendFatalErrorAlert(logEntry: Record<string, unknown>) {
  try {
    // Send to Slack webhook
    if (process.env.SLACK_WEBHOOK_URL) {
      await fetch(process.env.SLACK_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: `🚨 FATAL ERROR in ${logEntry.environment}`,
          blocks: [
            {
              type: 'section',
              text: {
                type: 'mrkdwn',
                text: `*Fatal Error Detected*\n\`\`\`${logEntry.message}\`\`\``,
              },
            },
            {
              type: 'section',
              fields: [
                {
                  type: 'mrkdwn',
                  text: `*Environment:*\n${logEntry.environment}`,
                },
                {
                  type: 'mrkdwn',
                  text: `*Version:*\n${logEntry.version}`,
                },
                {
                  type: 'mrkdwn',
                  text: `*Timestamp:*\n${logEntry.timestamp}`,
                },
                {
                  type: 'mrkdwn',
                  text: `*Trace ID:*\n${logEntry.traceId || 'N/A'}`,
                },
              ],
            },
          ],
        }),
      });
    }

    // Send to Discord webhook
    if (process.env.DISCORD_WEBHOOK_URL) {
      await fetch(process.env.DISCORD_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [
            {
              title: '🚨 Fatal Error Alert',
              description: logEntry.message,
              color: 0xff0000, // Red
              fields: [
                {
                  name: 'Environment',
                  value: logEntry.environment,
                  inline: true,
                },
                { name: 'Version', value: logEntry.version, inline: true },
                { name: 'Timestamp', value: logEntry.timestamp, inline: true },
              ],
              timestamp: new Date().toISOString(),
            },
          ],
        }),
      });
    }
  } catch (error) {
    console.error('Failed to send fatal error alert:', error);
  }
}

function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  const realIP = request.headers.get('x-real-ip');

  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }

  if (realIP) {
    return realIP;
  }

  return 'unknown';
}

function generateLogId(): string {
  return `log_${Date.now()}_${Math.random().toString(36).substring(2)}`;
}

// Health check endpoint
export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'logs-api',
  });
}
