/**
 * Admin Tax Reporting API
 *
 * GET /api/admin/tax - Get tax reporting summary
 * GET /api/admin/tax?year=2025 - Get 1099s for specific year
 * GET /api/admin/tax?export=true&year=2025 - Export 1099s for filing
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

// Dynamic imports
async function getTaxReportingService() {
  const { taxReportingService } = await import('@/lib/services/tax');
  return taxReportingService;
}

async function getUserAdminRepository() {
  const { userAdminRepository } =
    await import('@/lib/data/repositories/supabase');
  return userAdminRepository;
}

async function getAdminRoleService() {
  const { AdminRoleService } = await import('@/lib/services/admin/admin-role.service');
  return AdminRoleService.getInstance();
}

/**
 * GET /api/admin/tax
 * Get tax reporting summary or 1099s for a year
 */
export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required', code: 'UNAUTHENTICATED' },
        { status: 401 }
      );
    }

    // Look up internal user ID
    const userRepo = await getUserAdminRepository();
    const user = await userRepo.findByPrivyId(authContext.privyUserId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Check admin status
    const adminRoleService = await getAdminRoleService();
    const adminUserResult = await adminRoleService.getAdminById(user.id);
    const isAdmin = adminUserResult.success && adminUserResult.data && adminRoleService.isAdmin(adminUserResult.data);

    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    const searchParams = request.nextUrl.searchParams;
    const year = searchParams.get('year');
    const exportData = searchParams.get('export') === 'true';
    const yearNum = year ? parseInt(year, 10) : new Date().getFullYear();

    const service = await getTaxReportingService();

    // Export 1099s for filing
    if (exportData && year) {
      const result = await service.export1099sForFiling(yearNum);

      if (!result.success) {
        return NextResponse.json(
          { error: result.error, code: 'EXPORT_FAILED' },
          { status: 500 }
        );
      }

      return NextResponse.json({
        success: true,
        data: result.data,
      });
    }

    // Get all 1099s for year
    if (year) {
      const result = await service.getAll1099sForYear(yearNum);

      if (!result.success) {
        return NextResponse.json(
          { error: result.error, code: 'FETCH_FAILED' },
          { status: 500 }
        );
      }

      return NextResponse.json({
        success: true,
        data: result.data,
      });
    }

    // Get summary (users requiring 1099)
    const currentYear = new Date().getFullYear();
    const usersResult = await service.getUsersRequiring1099(currentYear);
    const formsResult = await service.getAll1099sForYear(currentYear);

    const pendingCount = formsResult.success
      ? (formsResult.data || []).filter((f) => f.status === 'pending').length
      : 0;
    const generatedCount = formsResult.success
      ? (formsResult.data || []).filter((f) => f.status !== 'pending').length
      : 0;

    return NextResponse.json({
      success: true,
      data: {
        currentYear,
        usersRequiring1099: usersResult.success
          ? (usersResult.data || []).length
          : 0,
        pendingForms: pendingCount,
        generatedForms: generatedCount,
        users: usersResult.success ? usersResult.data : [],
      },
    });
  } catch (error) {
    logger.error('Error fetching tax data', error as Error);
    return NextResponse.json(
      { error: 'Failed to fetch tax data', code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }
}
