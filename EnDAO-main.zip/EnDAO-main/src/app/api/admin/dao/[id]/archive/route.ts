/**
 * Admin DAO Archive API Route
 * POST - Archives (dissolves) a DAO
 *
 * Only super admins can archive DAOs from the system dashboard
 */

import { NextRequest, NextResponse } from 'next/server';
import { userAdminRepository } from '@/lib/data/repositories';
import { DAOCrudService } from '@/lib/services/dao/dao-crud.service';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { logger } from '@/lib/services/logger.service';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const { id: daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        {
          success: false,
          error: 'DAO ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Get Privy user ID from auth header
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Check if user is a super admin via AdminRoleService
    const adminRoleService = AdminRoleService.getInstance();
    const adminResult = await adminRoleService.getAdminByEmail(
      supabaseUser.email || ''
    );
    if (
      !adminResult.success ||
      !adminResult.data ||
      !adminRoleService.isSuperAdmin(adminResult.data)
    ) {
      return NextResponse.json(
        {
          success: false,
          error: 'Super admin access required',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    const userId = supabaseUser.id;

    // Parse request body for reason
    const body = await request.json().catch(() => ({}));
    const reason = body.reason || 'Archived by super admin';

    // Archive the DAO using dissolveDAO (which sets status to dissolved)
    const daoCrudService = DAOCrudService.getInstance();
    const result = await daoCrudService.dissolveDAO(daoId, userId, reason);

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to archive DAO',
          code: 'ARCHIVE_FAILED',
        },
        { status: 400 }
      );
    }

    logger.info('[Admin DAO Archive] DAO archived successfully', {
      daoId,
      archivedBy: userId,
      reason,
    });

    return NextResponse.json({
      success: true,
      message: 'DAO has been archived successfully',
    });
  } catch (error) {
    logger.error('[Admin DAO Archive] Error archiving DAO', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to archive DAO',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
