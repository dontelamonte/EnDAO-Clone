/**
 * Admin Proposals API Route
 *
 * Server-side endpoint for fetching all proposals across all DAOs.
 * Used by admin proposals management page.
 *
 * Query params:
 *   - status: Filter by status (optional)
 *   - limit: Maximum number of proposals to return (default: 100)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { logger } from '@/lib/services/logger.service';

interface ProposalRow {
  id: string;
  dao_id: string;
  title: string;
  description: string;
  type: string;
  status: string;
  created_at: string;
  created_by: string;
  start_date: string | null;
  end_date: string | null;
  results: Record<string, unknown>;
}

interface DAORow {
  id: string;
  name: string;
}

export async function GET(request: NextRequest) {
  try {
    // Extract auth from headers
    const authEmail = request.headers.get('x-auth-email');

    if (!authEmail) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Check admin access
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const statusFilter = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '100', 10);

    logger.debug('[API] Loading admin proposals', { statusFilter, limit });

    const supabase = getSupabaseAdmin();

    // Build query for proposals
    let proposalsQuery = supabase
      .from('proposals')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (statusFilter && statusFilter !== 'all') {
      proposalsQuery = proposalsQuery.eq('status', statusFilter);
    }

    const { data: proposalsData, error: proposalsError } = await proposalsQuery;

    if (proposalsError) {
      logger.error('[API] Failed to fetch proposals', proposalsError);
      throw proposalsError;
    }

    const proposals = proposalsData as ProposalRow[] | null;

    if (!proposals || proposals.length === 0) {
      return NextResponse.json({
        success: true,
        data: { proposals: [] },
      });
    }

    // Get unique DAO IDs
    const daoIds = [...new Set(proposals.map((p) => p.dao_id).filter(Boolean))];

    // Fetch DAO names in a single query
    const { data: daosData, error: daosError } = await supabase
      .from('daos')
      .select('id, name')
      .in('id', daoIds);

    if (daosError) {
      logger.error('[API] Failed to fetch DAOs', daosError);
      // Continue without DAO names rather than failing
    }

    const daos = daosData as DAORow[] | null;

    // Create DAO ID to name mapping
    const daoNameMap = new Map<string, string>();
    daos?.forEach((dao) => {
      daoNameMap.set(dao.id, dao.name);
    });

    // Map proposals with DAO names (snake_case to camelCase)
    const proposalsWithDAOs = proposals.map((proposal) => ({
      id: proposal.id,
      daoId: proposal.dao_id,
      daoName: daoNameMap.get(proposal.dao_id) || 'Unknown DAO',
      title: proposal.title,
      description: proposal.description,
      type: proposal.type,
      status: proposal.status,
      createdAt: proposal.created_at,
      createdBy: proposal.created_by,
      startDate: proposal.start_date,
      endDate: proposal.end_date,
      results: proposal.results || { totalVotes: 0, options: {} },
    }));

    // Add caching headers - 1 min cache
    return NextResponse.json(
      {
        success: true,
        data: { proposals: proposalsWithDAOs },
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=60, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error('[API] Error loading admin proposals', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to load proposals',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
