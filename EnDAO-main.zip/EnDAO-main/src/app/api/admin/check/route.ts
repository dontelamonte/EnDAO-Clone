/**
 * Admin Check API Route
 *
 * Server-side endpoint for checking admin status.
 * SECURITY: Requires authentication - users can only check their own admin status.
 * Called by useAdmin hook to avoid using admin Supabase client in the browser.
 */

import { NextRequest, NextResponse } from 'next/server';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { logger } from '@/lib/services/logger.service';
import {
  enforceMinimumTiming,
  TIMING_DELAYS,
} from '@/lib/security/timing-protection';
import { rateLimiters } from '@/lib/middleware/rate-limit';

const adminService = AdminRoleService.getInstance();

/**
 * GET /api/admin/check
 * Rate limited to 100 requests per minute (standard API tier)
 * This is a read-only check - users can only check their own status
 */
export async function GET(request: NextRequest) {
  // Apply standard API rate limiting (100/min) - this is a read-only self-check
  const rateLimitResult = await rateLimiters.api(request);
  if (rateLimitResult) return rateLimitResult;

  const startTime = Date.now(); // Capture start time for timing protection

  try {
    // Get email from either auth headers (if authenticated) or query param (bootstrap)
    const authEmail = request.headers.get('x-auth-email');
    const authPrivyId = request.headers.get('x-auth-privy-id');
    const requestedEmail = request.nextUrl.searchParams.get('email');

    // Determine which email to check
    // Priority: auth header > query param
    const emailToCheck = authEmail || requestedEmail;

    if (!emailToCheck) {
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        {
          success: false,
          error: 'Email required for admin check',
          code: 'EMAIL_REQUIRED',
        },
        { status: 400 }
      );
    }

    // If both auth header and query param are present, validate they match
    // This prevents users from checking other users' admin status when authenticated
    if (
      authPrivyId &&
      requestedEmail &&
      authEmail &&
      requestedEmail.toLowerCase() !== authEmail.toLowerCase()
    ) {
      logger.warn('[API] Admin check denied - email mismatch', {
        authEmail: authEmail.split('@')[1], // Log domain only
        requestedDomain: requestedEmail.split('@')[1],
      });
      // Failed auth: use 2x delay to slow brute force attempts
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json(
        {
          success: false,
          error: 'Can only check your own admin status',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    logger.debug('[API] Checking admin status for email', {
      email: emailToCheck.split('@')[1],
    }); // Log domain only

    // Initialize core admin accounts if needed (runs once)
    await adminService.initializeCoreAdminAccounts();

    // Check admin access using the validated email
    const result = await adminService.checkAdminAccess(emailToCheck);

    // Enforce minimum timing for admin check to prevent timing analysis
    // This prevents leaking admin status through response time differences
    await enforceMinimumTiming(TIMING_DELAYS.ADMIN_CHECK, startTime);

    return NextResponse.json(result);
  } catch (error) {
    logger.error('[API] Error checking admin status', error as Error);
    // Error path: use failure delay to prevent timing analysis
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
    return NextResponse.json(
      { success: false, error: 'Failed to check admin status' },
      { status: 500 }
    );
  }
}
