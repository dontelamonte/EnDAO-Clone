/**
 * System Stats API Route
 *
 * Server-side endpoint for fetching system statistics.
 * Called by system dashboard hooks to avoid using admin Supabase client in the browser.
 */

import { NextRequest, NextResponse } from 'next/server';
import { SystemStatsService } from '@/lib/services/system-stats.service';
import { logger } from '@/lib/services/logger.service';

const systemStatsService = SystemStatsService.getInstance();

export async function GET(request: NextRequest) {
  try {
    // Extract auth from headers (set by middleware)
    const privyId = request.headers.get('x-auth-privy-id');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', code: 'UNAUTHORIZED' },
        { status: 401 }
      );
    }

    logger.debug('[API] Loading system stats');

    // Load system stats using admin repositories
    const result = await systemStatsService.loadSystemStats();

    if (!result.success) {
      throw new Error(result.error || 'Failed to load system stats');
    }

    // Add caching headers - 5 min cache with stale-while-revalidate
    return NextResponse.json(result, {
      headers: {
        'Cache-Control': 'public, max-age=300, stale-while-revalidate=60',
      },
    });
  } catch (error) {
    logger.error('[API] Error loading system stats', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to load system stats',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
