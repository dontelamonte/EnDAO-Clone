/**
 * Data Integrity API Route
 *
 * Server-side endpoint for running data integrity checks and repairs.
 * Called by system dashboard hooks to avoid using admin Supabase client in the browser.
 */

import { NextRequest, NextResponse } from 'next/server';
import { DataIntegrityService } from '@/lib/services/data-integrity';
import { logger } from '@/lib/services/logger.service';

const dataIntegrityService = DataIntegrityService.getInstance();

/**
 * GET /api/admin/integrity
 * Run a full data integrity check
 */
export async function GET(request: NextRequest) {
  try {
    const privyId = request.headers.get('x-auth-privy-id');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', code: 'UNAUTHORIZED' },
        { status: 401 }
      );
    }

    logger.debug('[API] Running data integrity check');

    const result = await dataIntegrityService.runFullIntegrityCheck();

    if (!result.success) {
      throw new Error(result.error || 'Failed to run integrity check');
    }

    return NextResponse.json(result);
  } catch (error) {
    logger.error('[API] Error running integrity check', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to run integrity check',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/integrity
 * Repair orphaned data
 */
export async function POST(request: NextRequest) {
  try {
    const privyId = request.headers.get('x-auth-privy-id');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', code: 'UNAUTHORIZED' },
        { status: 401 }
      );
    }

    const body = await request.json();

    // Validate request body
    const orphanedData = {
      orphanedMemberships: body.orphanedMemberships || [],
      orphanedActivities: body.orphanedActivities || [],
      orphanedInvitations: body.orphanedInvitations || [],
    };

    logger.info('[API] Repairing orphaned data', {
      memberships: orphanedData.orphanedMemberships.length,
      activities: orphanedData.orphanedActivities.length,
      invitations: orphanedData.orphanedInvitations.length,
    });

    const result = await dataIntegrityService.repairOrphanedData(orphanedData);

    if (!result.success) {
      throw new Error(result.error || 'Failed to repair orphaned data');
    }

    return NextResponse.json(result);
  } catch (error) {
    logger.error('[API] Error repairing orphaned data', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to repair orphaned data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
