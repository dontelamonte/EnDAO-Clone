/**
 * Admin Members Search API Route
 *
 * POST - Search members across all DAOs (super admin only)
 * Browser-safe wrapper for SuperAdminMemberSearchService.searchMembersAcrossDAOs
 */

import { NextRequest, NextResponse } from 'next/server';
import { userAdminRepository } from '@/lib/data/repositories';
import { SuperAdminMemberSearchService } from '@/lib/services/super-admin';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { logger } from '@/lib/services/logger.service';
import type { MemberSearchFilters } from '@endao/shared-types';

interface SearchMembersRequest {
  filters: MemberSearchFilters;
  limit?: number;
}

export async function POST(request: NextRequest) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Verify super admin permissions
    const adminRoleService = AdminRoleService.getInstance();
    const adminUser = await adminRoleService.getAdminById(userId);

    if (!adminUser.success || !adminUser.data) {
      return NextResponse.json(
        { success: false, error: 'Super admin access required' },
        { status: 403 }
      );
    }

    // Parse request body
    const body: SearchMembersRequest = await request.json();
    const { filters, limit = 50 } = body;

    // Search members using the admin service
    const memberSearchService = SuperAdminMemberSearchService.getInstance();
    const result = await memberSearchService.searchMembersAcrossDAOs(
      filters || {},
      userId,
      limit
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to search members' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      '[Admin Members Search API] Error searching members',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to search members' },
      { status: 500 }
    );
  }
}
