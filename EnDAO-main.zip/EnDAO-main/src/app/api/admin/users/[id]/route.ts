/**
 * Admin User Management API - Individual User Operations
 *
 * PATCH /api/admin/users/[id] - Update admin user
 * DELETE /api/admin/users/[id] - Deactivate admin user
 *
 * SECURITY:
 * - Extracts updatedBy from x-auth-uid header (authenticated user ID)
 * - Validates requester is super_admin via AdminRoleService
 * - Never trusts client-provided user IDs for audit trails
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { SecurityValidator } from '@/lib/security/validation';
import { logger } from '@/lib/services/logger.service';

/**
 * Validation schema for updating admin users
 */
const updateAdminSchema = z.object({
  role: z.enum(['admin', 'super_admin']).optional(),
  displayName: z.string().optional(),
  isActive: z.boolean().optional(),
  notes: z.string().optional(),
});

/**
 * PATCH /api/admin/users/[id] - Update an admin user (super admin only)
 *
 * Body: { role?, displayName?, isActive?, notes? }
 *
 * SECURITY:
 * - Extracts updatedBy from x-auth-uid header (authenticated user ID)
 * - Validates requester is super_admin
 * - Never trusts client-provided user IDs for audit trails
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: adminId } = await params;

    // Extract authenticated user ID from headers
    const authUid = request.headers.get('x-auth-uid');
    const authEmail = request.headers.get('x-auth-email');

    if (!authUid || !authEmail) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Validate requester is super admin
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      logger.warn('[API] Non-admin attempted to update admin user', {
        authEmail,
        authUid,
        targetAdminId: adminId,
      });
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    if (accessResult.data.role !== 'super_admin') {
      logger.warn('[API] Non-super-admin attempted to update admin user', {
        authEmail,
        role: accessResult.data.role,
        targetAdminId: adminId,
      });
      return NextResponse.json(
        {
          success: false,
          error: 'Only super administrators can update admin users',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = await SecurityValidator.validate(
      updateAdminSchema,
      body,
      {
        sanitize: true,
        checkSqlInjection: true,
        checkXss: true,
        context: 'update-admin-user',
      }
    );

    // Validate that at least one field is being updated
    if (Object.keys(validatedData).length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'At least one field must be provided for update',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    // Update admin user using the service
    // CRITICAL: Use authUid from headers, NOT from request body
    const result = await adminService.updateAdminUser(
      adminId,
      validatedData,
      authUid // Use authenticated user ID from headers
    );

    if (!result.success) {
      logger.error('[API] Failed to update admin user', undefined, {
        error: result.error,
        targetAdminId: adminId,
        updatedBy: authUid,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to update admin user',
          code: 'UPDATE_FAILED',
        },
        { status: 400 }
      );
    }

    logger.info('[API] Admin user updated successfully', {
      targetAdminId: adminId,
      updatedFields: Object.keys(validatedData),
      updatedBy: authUid,
      updatedByEmail: authEmail,
    });

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[API] Error updating admin user', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/admin/users/[id] - Deactivate an admin user (super admin only)
 *
 * SECURITY:
 * - Extracts updatedBy from x-auth-uid header (authenticated user ID)
 * - Validates requester is super_admin
 * - Prevents deletion of the last super admin
 * - Sets isActive to false rather than hard-deleting the record
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: adminId } = await params;

    // Extract authenticated user ID from headers
    const authUid = request.headers.get('x-auth-uid');
    const authEmail = request.headers.get('x-auth-email');

    if (!authUid || !authEmail) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Validate requester is super admin
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      logger.warn('[API] Non-admin attempted to deactivate admin user', {
        authEmail,
        authUid,
        targetAdminId: adminId,
      });
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    if (accessResult.data.role !== 'super_admin') {
      logger.warn('[API] Non-super-admin attempted to deactivate admin user', {
        authEmail,
        role: accessResult.data.role,
        targetAdminId: adminId,
      });
      return NextResponse.json(
        {
          success: false,
          error: 'Only super administrators can deactivate admin users',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Prevent self-deactivation
    if (authUid === adminId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Cannot deactivate your own admin account',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Deactivate the admin user (soft delete by setting isActive = false)
    // CRITICAL: Use authUid from headers, NOT from request body
    const result = await adminService.updateAdminUser(
      adminId,
      { isActive: false },
      authUid // Use authenticated user ID from headers
    );

    if (!result.success) {
      logger.error('[API] Failed to deactivate admin user', undefined, {
        error: result.error,
        targetAdminId: adminId,
        deactivatedBy: authUid,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to deactivate admin user',
          code: 'DELETE_FAILED',
        },
        { status: 400 }
      );
    }

    logger.info('[API] Admin user deactivated successfully', {
      targetAdminId: adminId,
      deactivatedBy: authUid,
      deactivatedByEmail: authEmail,
    });

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[API] Error deactivating admin user', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
