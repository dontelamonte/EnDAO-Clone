import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { AdminUser } from '@endao/shared-types';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { SecurityValidator } from '@/lib/security/validation';
import { logger } from '@/lib/services/logger.service';

/**
 * Validation schema for creating admin users
 */
const createAdminSchema = z.object({
  email: z.string().email('Invalid email address'),
  displayName: z.string().optional(),
  role: z.enum(['admin', 'super_admin']),
  notes: z.string().optional(),
});

/**
 * GET /api/admin/users - Fetch admin users (admin-only endpoint)
 *
 * Query params:
 * - active: 'true' | 'false' | 'all' (default: 'true')
 *
 * Returns list of admin users with proper camelCase mapping
 */
export async function GET(request: NextRequest) {
  try {
    // Use database-based admin check (same as /api/admin/roles)
    const authEmail = request.headers.get('x-auth-email');

    if (!authEmail) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Check admin access via database (not middleware env var)
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const activeFilter = searchParams.get('active') || 'true';

    const supabase = getSupabaseAdmin();

    // Build query
    let query = supabase.from('admin_users').select('*');

    // Apply active filter
    if (activeFilter === 'true') {
      query = query.eq('is_active', true);
    } else if (activeFilter === 'false') {
      query = query.eq('is_active', false);
    }
    // 'all' = no filter

    const { data, error } = await query.order('created_at', {
      ascending: false,
    });

    if (error) {
      console.error('Failed to fetch admin users:', error);
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to fetch admin users',
          code: 'FETCH_FAILED',
        },
        { status: 500 }
      );
    }

    // Map snake_case to camelCase
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- admin_users table not in generated types
    const adminUsers: AdminUser[] = ((data || []) as any[]).map((row) => ({
      id: row.id,
      email: row.email,
      displayName: row.display_name,
      role: row.role,
      permissions: row.permissions || {},
      createdAt: row.created_at,
      createdBy: row.created_by,
      lastLoginAt: row.last_login_at,
      isActive: row.is_active,
      notes: row.notes,
    }));

    return NextResponse.json({
      success: true,
      data: { adminUsers },
    });
  } catch (error) {
    console.error('Error in admin users endpoint:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/users - Create a new admin user (super admin only)
 *
 * Body: { email, displayName?, role, notes? }
 *
 * SECURITY:
 * - Extracts createdBy from x-auth-uid header (authenticated user ID)
 * - Validates requester is super_admin via AdminRoleService
 * - Never trusts client-provided user IDs for audit trails
 */
export async function POST(request: NextRequest) {
  try {
    // Extract authenticated user ID from headers
    const authUid = request.headers.get('x-auth-uid');
    const authEmail = request.headers.get('x-auth-email');

    if (!authUid || !authEmail) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Validate requester is super admin
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      logger.warn('[API] Non-admin attempted to create admin user', {
        authEmail,
        authUid,
      });
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    if (accessResult.data.role !== 'super_admin') {
      logger.warn('[API] Non-super-admin attempted to create admin user', {
        authEmail,
        role: accessResult.data.role,
      });
      return NextResponse.json(
        {
          success: false,
          error: 'Only super administrators can create admin users',
          code: 'FORBIDDEN',
        },
        { status: 403 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validatedData = await SecurityValidator.validate(
      createAdminSchema,
      body,
      {
        sanitize: true,
        checkSqlInjection: true,
        checkXss: true,
        context: 'create-admin-user',
      }
    );

    // Create admin user using the service
    // CRITICAL: Use authUid from headers, NOT from request body
    const result = await adminService.createAdminUser(
      {
        email: validatedData.email,
        displayName: validatedData.displayName,
        role: validatedData.role,
        notes: validatedData.notes,
      },
      authUid // Use authenticated user ID from headers
    );

    if (!result.success) {
      logger.error('[API] Failed to create admin user', undefined, {
        error: result.error,
        requestedEmail: validatedData.email,
        createdBy: authUid,
      });
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to create admin user',
          code: 'CREATE_FAILED',
        },
        { status: 400 }
      );
    }

    logger.info('[API] Admin user created successfully', {
      createdEmail: validatedData.email,
      createdRole: validatedData.role,
      createdBy: authUid,
      createdByEmail: authEmail,
    });

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[API] Error creating admin user', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
