import { NextRequest, NextResponse } from 'next/server';
import { AdminUserManagementService } from '@/lib/services/admin';
import { AdminRoleService } from '@/lib/services/admin/admin-role.service';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import {
  getPermissionsForRole,
  type AdminRole,
  type AdminPermissions,
} from '@endao/shared-types';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/admin/roles
 * Fetch role statistics including:
 * - System admin counts (super_admin, admin)
 * - DAO admin aggregation (total DAO admins across platform)
 *
 * Requires: super_admin or admin access
 */
export async function GET(request: NextRequest) {
  try {
    const authEmail = request.headers.get('x-auth-email');

    if (!authEmail) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Check admin access
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    const supabase = getSupabaseAdmin();

    // Get system admin counts
    const adminResult = await supabase
      .from('admin_users')
      .select('role, is_active')
      .eq('is_active', true);

    const adminUsers = adminResult.data as
      | { role: string; is_active: boolean }[]
      | null;
    const adminError = adminResult.error;

    if (adminError) {
      logger.error('Failed to fetch admin users', adminError);
      throw adminError;
    }

    const systemAdminCounts = {
      super_admin:
        adminUsers?.filter((a) => a.role === 'super_admin').length || 0,
      admin: adminUsers?.filter((a) => a.role === 'admin').length || 0,
    };

    // Get DAO admin aggregation (distinct users who are admins in any DAO)
    const daoAdminResult = await supabase
      .from('dao_members')
      .select('user_id, dao_id')
      .eq('role', 'admin')
      .eq('status', 'active');

    const daoAdmins = daoAdminResult.data as
      | { user_id: string; dao_id: string }[]
      | null;
    const daoAdminError = daoAdminResult.error;

    if (daoAdminError) {
      logger.error('Failed to fetch DAO admins', daoAdminError);
      // Continue with zero counts rather than failing
    }

    // Count unique DAO admins and total DAO admin assignments
    const uniqueDaoAdminUserIds = new Set(
      daoAdmins?.map((d) => d.user_id) || []
    );
    const uniqueDaoIds = new Set(daoAdmins?.map((d) => d.dao_id) || []);

    const daoAdminStats = {
      uniqueAdmins: uniqueDaoAdminUserIds.size, // Distinct users who are admin in at least one DAO
      totalAssignments: daoAdmins?.length || 0, // Total DAO admin roles (user can be admin in multiple DAOs)
      daosWithAdmins: uniqueDaoIds.size, // Number of DAOs that have at least one admin
    };

    // Define role hierarchy with descriptions
    const roleDefinitions = [
      {
        id: 'super_admin',
        name: 'Super Admin',
        description:
          'Platform-level control. Full system access including admin management, system logs, and all DAO operations.',
        scope: 'platform',
        permissions: Object.keys(getPermissionsForRole('super_admin')).filter(
          (k) =>
            getPermissionsForRole('super_admin')[k as keyof AdminPermissions]
        ),
        count: systemAdminCounts.super_admin,
        isSystem: true,
      },
      {
        id: 'admin',
        name: 'Platform Admin',
        description:
          'Platform-level moderation. Can manage users, DAOs, and content but cannot manage other admins or access system logs.',
        scope: 'platform',
        permissions: Object.keys(getPermissionsForRole('admin')).filter(
          (k) => getPermissionsForRole('admin')[k as keyof AdminPermissions]
        ),
        count: systemAdminCounts.admin,
        isSystem: true,
      },
      {
        id: 'dao_admin',
        name: 'DAO Admin',
        description:
          'DAO-level control. Can manage members, proposals, and settings for specific DAOs they administer.',
        scope: 'dao',
        permissions: [
          'canEditDAO',
          'canManageMembers',
          'canRemoveMembers',
          'canChangeRoles',
          'canManageSettings',
          'canDeleteDAO',
          'canApproveProposals',
          'canModerateContent',
        ],
        count: daoAdminStats.uniqueAdmins,
        isSystem: false, // DAO-level role, not system role
        stats: daoAdminStats,
      },
    ];

    return NextResponse.json({
      success: true,
      data: {
        roles: roleDefinitions,
        systemAdminCounts,
        daoAdminStats,
      },
    });
  } catch (error) {
    logger.error(
      'Failed to fetch role statistics',
      error instanceof Error ? error : new Error(String(error))
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch role statistics',
        code: 'FETCH_FAILED',
      },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/roles/users
 * Add a new admin user
 *
 * Requires: super_admin access (only super admins can add platform admins)
 */
export async function POST(request: NextRequest) {
  try {
    const authEmail = request.headers.get('x-auth-email');
    const authUid = request.headers.get('x-auth-uid');

    if (!authEmail || !authUid) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Only super_admin can add platform admins
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    // Check if current user is super_admin
    if (accessResult.data.role !== 'super_admin') {
      return NextResponse.json(
        {
          success: false,
          error: 'Only Super Admins can add Platform Admins',
          code: 'INSUFFICIENT_PERMISSIONS',
        },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { email, role } = body as { email: string; role: AdminRole };

    if (!email || !role) {
      return NextResponse.json(
        {
          success: false,
          error: 'Email and role are required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Validate role - only allow 'admin' to be added (super_admin is protected)
    if (role !== 'admin') {
      return NextResponse.json(
        {
          success: false,
          error: 'Can only add Platform Admin role via this endpoint',
          code: 'INVALID_REQUEST',
        },
        { status: 400 }
      );
    }

    const adminUserService = AdminUserManagementService.getInstance();
    const result = await adminUserService.createAdminUser(
      email.trim().toLowerCase(),
      role,
      getPermissionsForRole(role),
      authUid,
      { userAgent: request.headers.get('user-agent') || 'unknown' }
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to create admin user',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Failed to create admin user',
      error instanceof Error ? error : new Error(String(error))
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create admin user',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/admin/roles/users
 * Update an admin user (deactivate, change permissions)
 *
 * Requires: super_admin access
 */
export async function PATCH(request: NextRequest) {
  try {
    const authEmail = request.headers.get('x-auth-email');
    const authUid = request.headers.get('x-auth-uid');

    if (!authEmail || !authUid) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    // Only super_admin can modify platform admins
    const adminService = AdminRoleService.getInstance();
    const accessResult = await adminService.checkAdminAccess(authEmail);

    if (!accessResult.success || !accessResult.data?.isActive) {
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    if (accessResult.data.role !== 'super_admin') {
      return NextResponse.json(
        {
          success: false,
          error: 'Only Super Admins can modify Platform Admins',
          code: 'INSUFFICIENT_PERMISSIONS',
        },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { adminId, updates: rawUpdates } = body as {
      adminId: string;
      updates: { isActive?: boolean; permissions?: AdminPermissions };
    };

    // Type assertion for Partial<AdminUser> - only pass defined properties
    const updates: Partial<{
      isActive: boolean;
      permissions: AdminPermissions;
    }> = {};
    if (rawUpdates.isActive !== undefined)
      updates.isActive = rawUpdates.isActive;
    if (rawUpdates.permissions !== undefined)
      updates.permissions = rawUpdates.permissions;

    if (!adminId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Admin ID is required',
          code: 'MISSING_PARAMETER',
        },
        { status: 400 }
      );
    }

    // Prevent super_admin from deactivating themselves
    if (rawUpdates.isActive === false && accessResult.data.id === adminId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Cannot deactivate your own admin account',
          code: 'INVALID_REQUEST',
        },
        { status: 400 }
      );
    }

    const adminUserService = AdminUserManagementService.getInstance();
    const result = await adminUserService.updateAdminUser(
      adminId,
      updates,
      authUid,
      { userAgent: request.headers.get('user-agent') || 'unknown' }
    );

    if (!result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to update admin user',
          code: 'VALIDATION_ERROR',
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      'Failed to update admin user',
      error instanceof Error ? error : new Error(String(error))
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to update admin user',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
