/**
 * Admin Audit Logs API
 * Secure endpoint for accessing audit logs and statistics
 *
 * GET /api/admin/audit-logs - Query audit logs
 * POST /api/admin/audit-logs/export - Export audit logs
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  getAuthContext,
  requireAuthContext,
} from '@/lib/auth/get-auth-context';
import {
  auditLogService,
  type AuditLogQueryOptions,
  type AuditSeverity,
  type AuditResult,
  type AuditEventType,
} from '@/lib/services/audit';
import { adminAuditService } from '@/lib/services/admin-audit.service';
import { z } from 'zod';

// Query parameters validation schema
const QueryParamsSchema = z.object({
  // Pagination
  limit: z
    .string()
    .optional()
    .transform((val) => (val ? parseInt(val) : undefined)),
  offset: z
    .string()
    .optional()
    .transform((val) => (val ? parseInt(val) : undefined)),

  // Filters
  eventTypes: z
    .string()
    .optional()
    .transform((val) =>
      val ? (val.split(',') as AuditEventType[]) : undefined
    ),
  severity: z
    .string()
    .optional()
    .transform((val) =>
      val ? (val.split(',') as AuditSeverity[]) : undefined
    ),
  result: z
    .string()
    .optional()
    .transform((val) => (val ? (val.split(',') as AuditResult[]) : undefined)),
  userId: z.string().optional(),
  resourceType: z.string().optional(),
  resourceId: z.string().optional(),

  // Date range
  startDate: z
    .string()
    .optional()
    .transform((val) => (val ? new Date(val) : undefined)),
  endDate: z
    .string()
    .optional()
    .transform((val) => (val ? new Date(val) : undefined)),

  // Ordering
  orderBy: z.enum(['timestamp', 'severity']).optional(),
  orderDirection: z.enum(['asc', 'desc']).optional(),

  // Special queries
  statsOnly: z
    .string()
    .optional()
    .transform((val) => val === 'true'),
});

/**
 * GET /api/admin/audit-logs
 * Query audit logs with filtering and pagination
 */
export async function GET(request: NextRequest) {
  try {
    // Extract request context for audit logging
    const userAgent = request.headers.get('user-agent') || undefined;
    const origin = request.headers.get('origin') || undefined;
    const forwarded = request.headers.get('x-forwarded-for');
    const realIp = request.headers.get('x-real-ip');
    const ipAddress = forwarded?.split(',')[0]?.trim() || realIp || undefined;

    const requestContext = {
      ipAddress,
      userAgent,
      origin,
      method: request.method,
      url: request.url,
    };

    // Verify authentication
    const authContext = await requireAuthContext(request);

    // Check admin access
    const adminCheck = await adminAuditService.checkAdminAccess(
      authContext.email || '',
      undefined,
      requestContext
    );

    if (!adminCheck.hasAccess || !adminCheck.admin) {
      // Log unauthorized access attempt
      await auditLogService.logAuthzEvent(
        'authz.permission.denied',
        'failure',
        authContext,
        'audit_logs_api',
        undefined,
        requestContext,
        {
          reason: 'not_admin',
          endpoint: '/api/admin/audit-logs',
          attemptedEmail: authContext.email,
        }
      );

      return NextResponse.json(
        { error: 'Access denied. Admin privileges required.' },
        { status: 403 }
      );
    }

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const queryParams = QueryParamsSchema.parse(
      Object.fromEntries(searchParams.entries())
    );

    // Log admin audit log access
    await auditLogService.logEvent(
      {
        eventType: 'data_export',
        result: 'success',
        severity: 'medium',
        userId: authContext.uid,
        resourceId: 'audit_logs',
        resourceType: 'system',
        action: 'Audit logs accessed',
        description: 'Audit logs accessed',
        details: {
          privyUserId: authContext.privyUserId,
          email: authContext.email,
          queryParams: {
            ...queryParams,
            // Don't log actual date values for privacy
            hasDateFilter: !!(queryParams.startDate || queryParams.endDate),
            hasUserFilter: !!queryParams.userId,
            eventTypes: queryParams.eventTypes?.length || 0,
            limit: queryParams.limit,
          },
          adminRole: adminCheck.admin?.role,
        },
      },
      requestContext
    );

    // Handle statistics request
    if (queryParams.statsOnly) {
      const stats = await auditLogService.getStatistics(
        queryParams.startDate,
        queryParams.endDate
      );

      return NextResponse.json({
        success: true,
        data: stats,
      });
    }

    // Build query options
    const options: AuditLogQueryOptions = {
      limit: Math.min(queryParams.limit || 50, 1000), // Cap at 1000
      offset: queryParams.offset || 0,
      eventType: queryParams.eventTypes?.[0] as AuditEventType | undefined,
      severity: queryParams.severity,
      result: queryParams.result,
      userId: queryParams.userId,
      resourceId: queryParams.resourceId,
      startDate: queryParams.startDate,
      endDate: queryParams.endDate,
      orderBy: queryParams.orderBy || 'timestamp',
      orderDirection: queryParams.orderDirection || 'desc',
    };

    // Query audit logs
    const result = await auditLogService.queryLogs(options);

    // Remove sensitive information from response
    const sanitizedEvents = result.events.map((event) => ({
      ...event,
      // Keep stackTrace out of API responses for security
      stackTrace: undefined,
      // Truncate long details for performance
      details: event.details
        ? JSON.stringify(event.details).length > 1000
          ? { ...event.details, _truncated: true }
          : event.details
        : undefined,
    }));

    return NextResponse.json({
      success: true,
      data: {
        events: sanitizedEvents,
        total: result.total,
        hasMore: result.hasMore,
        pagination: {
          limit: options.limit,
          offset: options.offset,
          total: result.total,
        },
      },
    });
  } catch (error) {
    console.error('Audit logs API error:', error);

    // Log API error
    try {
      const authContext = await getAuthContext(request);
      await auditLogService.logSystemError('system.error', error as Error, {
        context: 'audit_logs_api',
        endpoint: '/api/admin/audit-logs',
        userId: authContext?.uid,
      });
    } catch (logError) {
      console.error('Failed to log API error:', logError);
    }

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          error: 'Invalid query parameters',
          details: error.errors,
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/audit-logs/export
 * Export audit logs in various formats
 */
export async function POST(request: NextRequest) {
  try {
    // Extract request context
    const userAgent = request.headers.get('user-agent') || undefined;
    const origin = request.headers.get('origin') || undefined;
    const forwarded = request.headers.get('x-forwarded-for');
    const realIp = request.headers.get('x-real-ip');
    const ipAddress = forwarded?.split(',')[0]?.trim() || realIp || undefined;

    const requestContext = {
      ipAddress,
      userAgent,
      origin,
      method: request.method,
      url: request.url,
    };

    // Verify authentication and admin access
    const authContext = await requireAuthContext(request);

    const adminCheck = await adminAuditService.checkAdminAccess(
      authContext.email || '',
      undefined,
      requestContext
    );

    if (!adminCheck.hasAccess || !adminCheck.admin) {
      return NextResponse.json(
        { error: 'Access denied. Admin privileges required.' },
        { status: 403 }
      );
    }

    // Parse request body
    const body = await request.json();
    const exportOptions = z
      .object({
        format: z.enum(['json', 'csv']).default('json'),
        filters: z
          .object({
            eventTypes: z.array(z.string()).optional(),
            severity: z.array(z.string()).optional(),
            result: z.array(z.string()).optional(),
            startDate: z.string().optional(),
            endDate: z.string().optional(),
            userId: z.string().optional(),
          })
          .optional(),
        maxRecords: z.number().max(10000).default(1000),
      })
      .parse(body);

    // Log export request
    await auditLogService.logEvent(
      {
        eventType: 'data_export',
        result: 'success',
        severity: 'high', // Data export is sensitive
        userId: authContext.uid,
        resourceId: 'audit_logs',
        resourceType: 'system',
        action: 'Audit logs export requested',
        description: 'Audit logs export requested',
        details: {
          privyUserId: authContext.privyUserId,
          email: authContext.email,
          format: exportOptions.format,
          maxRecords: exportOptions.maxRecords,
          hasFilters: !!exportOptions.filters,
          adminRole: adminCheck.admin?.role,
        },
      },
      requestContext
    );

    // Build query options from filters
    const queryOptions: AuditLogQueryOptions = {
      limit: exportOptions.maxRecords,
      eventType:
        (exportOptions.filters?.eventTypes?.[0] as AuditEventType) || undefined,
      severity:
        (exportOptions.filters?.severity?.[0] as AuditSeverity) || undefined,
      result: (exportOptions.filters?.result?.[0] as AuditResult) || undefined,
      userId: exportOptions.filters?.userId,
      startDate: exportOptions.filters?.startDate
        ? new Date(exportOptions.filters.startDate)
        : undefined,
      endDate: exportOptions.filters?.endDate
        ? new Date(exportOptions.filters.endDate)
        : undefined,
      orderBy: 'timestamp',
      orderDirection: 'desc',
    };

    // Query audit logs
    const result = await auditLogService.queryLogs(queryOptions);

    // Format data based on requested format
    if (exportOptions.format === 'csv') {
      // Convert to CSV format
      const csvHeaders = [
        'Timestamp',
        'Type',
        'Severity',
        'Result',
        'User Email',
        'User ID',
        'Action',
        'Resource',
        'Resource ID',
        'IP Address',
        'Risk Score',
        'Details',
      ];

      const csvRows = result.events.map((event) => [
        event.timestamp ? new Date(event.timestamp).toISOString() : '',
        event.eventType || '',
        event.severity || '',
        event.result || '',
        event.details?.email || '',
        event.userId || '',
        event.action || '',
        event.resourceType || '',
        event.resourceId || '',
        event.requestContext?.ip || '',
        event.riskAssessment?.score
          ? (event.riskAssessment.score / 100).toFixed(1)
          : '',
        event.details ? JSON.stringify(event.details) : '',
      ]);

      const csvContent = [
        csvHeaders.join(','),
        ...csvRows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
      ].join('\n');

      return new NextResponse(csvContent, {
        status: 200,
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="audit-logs-${new Date().toISOString().split('T')[0]}.csv"`,
        },
      });
    } else {
      // Return JSON format
      return NextResponse.json({
        success: true,
        data: {
          exportedAt: new Date().toISOString(),
          format: exportOptions.format,
          totalRecords: result.events.length,
          filters: exportOptions.filters,
          events: result.events.map((event) => ({
            ...event,
            stackTrace: undefined, // Remove sensitive data
          })),
        },
      });
    }
  } catch (error) {
    console.error('Audit logs export error:', error);

    // Log export error
    try {
      const authContext = await getAuthContext(request);
      await auditLogService.logSystemError('system.error', error as Error, {
        context: 'audit_logs_export',
        endpoint: '/api/admin/audit-logs/export',
        userId: authContext?.uid,
      });
    } catch (logError) {
      console.error('Failed to log export error:', logError);
    }

    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
