/**
 * Admin Billing API
 *
 * Provides billing stats and subscription data for platform admins.
 * Requires super admin authentication.
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase';
import { TIER_FEATURES } from '@endao/shared-types';

export async function GET(request: NextRequest) {
  try {
    // Get auth headers
    const userId = request.headers.get('x-auth-uid');
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Verify super admin
    const supabase = getSupabaseAdmin();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: adminUser } = await (supabase as any)
      .from('super_admins')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (!adminUser) {
      return NextResponse.json(
        { success: false, error: 'Super admin access required' },
        { status: 403 }
      );
    }

    // Get subscription stats
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: allSubscriptions } = await (supabase as any)
      .from('subscriptions')
      .select(
        `
        id,
        dao_id,
        tier,
        status,
        stripe_subscription_id,
        stripe_customer_id,
        stripe_price_id,
        current_period_end,
        trial_end,
        cancel_at_period_end,
        created_at,
        daos (
          name
        )
      `
      )
      .order('created_at', { ascending: false });

    const subscriptions = allSubscriptions || [];

    // Calculate stats
    const activeSubscriptions = subscriptions.filter(
      (s: { status: string }) => s.status === 'active'
    );
    const trialSubscriptions = subscriptions.filter(
      (s: { status: string }) => s.status === 'trialing'
    );

    // Calculate MRR (simplified - actual calculation would use Stripe prices)
    let mrr = 0;
    for (const sub of activeSubscriptions) {
      const tierConfig = TIER_FEATURES[sub.tier as keyof typeof TIER_FEATURES];
      if (tierConfig) {
        mrr += tierConfig.priceMonthly;
      }
    }

    // Calculate churn (simplified - last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { count: canceledCount } = await (supabase as any)
      .from('subscriptions')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'canceled')
      .gte('canceled_at', thirtyDaysAgo.toISOString());

    const churnRate =
      activeSubscriptions.length > 0
        ? ((canceledCount || 0) /
            (activeSubscriptions.length + (canceledCount || 0))) *
          100
        : 0;

    // Format subscriptions for response
    const formattedSubscriptions = subscriptions.map(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (sub: any) => ({
        id: sub.id,
        daoId: sub.dao_id,
        daoName: sub.daos?.name || 'Unknown',
        tier: sub.tier,
        status: sub.status,
        stripeSubscriptionId: sub.stripe_subscription_id,
        stripeCustomerId: sub.stripe_customer_id,
        currentPeriodEnd: sub.current_period_end,
        trialEnd: sub.trial_end,
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        createdAt: sub.created_at,
      })
    );

    return NextResponse.json({
      success: true,
      data: {
        stats: {
          totalSubscriptions: subscriptions.length,
          activeSubscriptions: activeSubscriptions.length,
          trialSubscriptions: trialSubscriptions.length,
          mrr,
          arr: mrr * 12,
          churnRate,
        },
        subscriptions: formattedSubscriptions,
      },
    });
  } catch (error) {
    console.error('[Admin Billing API] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch billing data' },
      { status: 500 }
    );
  }
}
