/**
 * Admin Billing Action API
 *
 * Handles admin actions on subscriptions like trial extensions and tier overrides.
 * Requires super admin authentication.
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import Stripe from 'stripe';
import { getSupabaseAdmin } from '@/lib/supabase';
import { SecurityValidator, ValidationError } from '@/lib/security/validation';
import { logger } from '@/lib/services/logger.service';

// Lazy-initialized Stripe client
let stripe: Stripe | null = null;

function getStripe(): Stripe {
  if (!stripe) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error('STRIPE_SECRET_KEY environment variable is not set.');
    }
    stripe = new Stripe(apiKey);
  }
  return stripe;
}

const actionSchema = z.object({
  action: z.enum(['extend_trial', 'upgrade', 'downgrade', 'cancel', 'refund']),
  subscriptionId: z.string().uuid(),
  daoId: z.string().uuid(),
  newTier: z.string().optional(),
  days: z.number().optional(),
  reason: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    // Get auth headers
    const userId = request.headers.get('x-auth-uid');
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Verify super admin
    const supabase = getSupabaseAdmin();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: adminUser } = await (supabase as any)
      .from('super_admins')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (!adminUser) {
      return NextResponse.json(
        { success: false, error: 'Super admin access required' },
        { status: 403 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const { action, subscriptionId, daoId, newTier, days, reason } =
      await SecurityValidator.validate(actionSchema, body, {
        sanitize: true,
        context: 'admin-billing-action',
      });

    // Get subscription
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: subscription, error: subError } = await (supabase as any)
      .from('subscriptions')
      .select('*')
      .eq('id', subscriptionId)
      .single();

    if (subError || !subscription) {
      return NextResponse.json(
        { success: false, error: 'Subscription not found' },
        { status: 404 }
      );
    }

    let message = '';

    switch (action) {
      case 'extend_trial': {
        const trialDays = days || 7;
        const stripeClient = getStripe();

        // Extend trial in Stripe
        const newTrialEnd =
          Math.floor(Date.now() / 1000) + trialDays * 24 * 60 * 60;
        await stripeClient.subscriptions.update(
          subscription.stripe_subscription_id,
          {
            trial_end: newTrialEnd,
          }
        );

        // Update in database
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await (supabase as any)
          .from('subscriptions')
          .update({
            trial_end: new Date(newTrialEnd * 1000).toISOString(),
          })
          .eq('id', subscriptionId);

        // Log audit
        await logBillingAudit(supabase, {
          adminUserId: userId,
          daoId,
          action: 'trial_extended',
          details: { days: trialDays },
          previousValue: subscription.trial_end,
          newValue: new Date(newTrialEnd * 1000).toISOString(),
          reason,
        });

        message = `Trial extended by ${trialDays} days`;
        break;
      }

      case 'upgrade': {
        if (!newTier) {
          return NextResponse.json(
            { success: false, error: 'newTier required for upgrade action' },
            { status: 400 }
          );
        }

        // Update tier in database (Stripe update would require price change)
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await (supabase as any)
          .from('subscriptions')
          .update({ tier: newTier })
          .eq('id', subscriptionId);

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await (supabase as any)
          .from('daos')
          .update({ subscription_tier: newTier })
          .eq('id', daoId);

        // Log audit
        await logBillingAudit(supabase, {
          adminUserId: userId,
          daoId,
          action: 'tier_override',
          details: { newTier },
          previousValue: subscription.tier,
          newValue: newTier,
          reason,
        });

        message = `Tier changed to ${newTier}`;
        break;
      }

      case 'cancel': {
        const stripeClient = getStripe();

        // Cancel in Stripe at period end
        await stripeClient.subscriptions.update(
          subscription.stripe_subscription_id,
          {
            cancel_at_period_end: true,
          }
        );

        // Update in database
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await (supabase as any)
          .from('subscriptions')
          .update({ cancel_at_period_end: true })
          .eq('id', subscriptionId);

        // Log audit
        await logBillingAudit(supabase, {
          adminUserId: userId,
          daoId,
          action: 'subscription_canceled',
          details: {},
          reason,
        });

        message = 'Subscription will be canceled at period end';
        break;
      }

      default:
        return NextResponse.json(
          { success: false, error: 'Unsupported action' },
          { status: 400 }
        );
    }

    logger.info('[Admin Billing Action]', {
      action,
      subscriptionId,
      daoId,
      adminUserId: userId,
    });

    return NextResponse.json({
      success: true,
      message,
    });
  } catch (error) {
    if (error instanceof ValidationError) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      );
    }
    console.error('[Admin Billing Action] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to perform action' },
      { status: 500 }
    );
  }
}

async function logBillingAudit(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  params: {
    adminUserId: string;
    daoId: string;
    action: string;
    details: Record<string, unknown>;
    previousValue?: string;
    newValue?: string;
    reason?: string;
  }
) {
  try {
    await supabase.from('billing_audit_log').insert({
      admin_user_id: params.adminUserId,
      dao_id: params.daoId,
      action: params.action,
      details: params.details,
      previous_value: params.previousValue,
      new_value: params.newValue,
      reason: params.reason,
    });
  } catch (error) {
    // Don't fail the action if audit logging fails
    console.error('[Admin Billing Action] Audit log failed:', error);
  }
}
