/**
 * Proposal Statistics API Route (Consolidated)
 *
 * Server-side endpoint for fetching proposal statistics.
 * Combines global status counts and per-DAO counts into a single endpoint.
 * Uses SQL aggregation for efficiency.
 *
 * Query params:
 *   - scope=global: Returns counts by status (default)
 *   - scope=per-dao: Returns counts per DAO
 *   - scope=all: Returns both
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { logger } from '@/lib/services/logger.service';

interface StatusCounts {
  active: number;
  passed: number;
  rejected: number;
  draft: number;
  under_review: number;
}

interface ProposalStatistics {
  global?: StatusCounts;
  perDao?: Record<string, number>;
}

export async function GET(request: NextRequest) {
  try {
    // Extract auth from headers (set by middleware)
    const privyId = request.headers.get('x-auth-privy-id');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', code: 'UNAUTHORIZED' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const scope = searchParams.get('scope') || 'global';

    logger.debug('[API] Loading proposal statistics', { scope });

    const supabase = getSupabaseAdmin();
    const result: ProposalStatistics = {};

    // Global counts by status
    if (scope === 'global' || scope === 'all') {
      const { data: statusData, error: statusError } = await supabase
        .from('proposals')
        .select('status')
        .neq('status', 'deleted');

      if (statusError) throw statusError;

      const counts: StatusCounts = {
        active: 0,
        passed: 0,
        rejected: 0,
        draft: 0,
        under_review: 0,
      };

      statusData?.forEach((proposal: { status: string }) => {
        const status = proposal.status;
        if (status in counts) {
          counts[status as keyof StatusCounts]++;
        }
      });

      result.global = counts;
    }

    // Per-DAO counts
    if (scope === 'per-dao' || scope === 'all') {
      const { data: daoData, error: daoError } = await supabase
        .from('proposals')
        .select('dao_id')
        .neq('status', 'deleted');

      if (daoError) throw daoError;

      const perDao: Record<string, number> = {};

      daoData?.forEach((proposal: { dao_id: string | null }) => {
        const daoId = proposal.dao_id;
        if (daoId) {
          perDao[daoId] = (perDao[daoId] || 0) + 1;
        }
      });

      result.perDao = perDao;
    }

    // Add caching headers - 2 min cache with stale-while-revalidate
    return NextResponse.json(
      { success: true, data: result },
      {
        headers: {
          'Cache-Control': 'public, max-age=120, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error('[API] Error loading proposal statistics', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to load proposal statistics',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
