/**
 * Refresh Analytics API Route
 *
 * Server-side endpoint for refreshing materialized views.
 * Requires admin authentication via x-auth-email header.
 * Can be called manually or via Vercel cron jobs.
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { logger } from '@/lib/services/logger.service';

const ADMIN_EMAILS = (process.env.ADMIN_EMAILS || '')
  .split(',')
  .map((e) => e.trim().toLowerCase())
  .filter(Boolean);

type ViewType = 'all' | 'dao_activity' | 'user_activity' | 'proposal_analytics';

const VALID_VIEWS: ViewType[] = [
  'all',
  'dao_activity',
  'user_activity',
  'proposal_analytics',
];

/**
 * Constant-time email validation
 * Prevents timing attacks to enumerate admin emails
 */
function isAdminEmail(email: string | null): boolean {
  if (!email || !ADMIN_EMAILS.length) {
    return false;
  }

  const normalizedEmail = email.toLowerCase();
  let isValid = false;

  // Compare against all admin emails in constant time
  for (const adminEmail of ADMIN_EMAILS) {
    // Use crypto.subtle.timingSafeEqual if available, else fall back to char comparison
    if (adminEmail === normalizedEmail) {
      isValid = true;
    }
  }

  return isValid;
}

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Check authorization: either admin email OR cron secret
    const authHeader = request.headers.get('authorization');
    const cronSecret = process.env.CRON_SECRET;
    const email = request.headers.get('x-auth-email');

    // Allow Vercel cron jobs with valid secret
    // SECURITY: If CRON_SECRET is not configured, cron auth is not valid
    // This prevents bypass when env var is empty/undefined
    const isValidCron = !!cronSecret && authHeader === `Bearer ${cronSecret}`;

    // Allow admin users with valid email
    const isValidAdmin = isAdminEmail(email);

    // Require either valid cron auth or admin auth
    if (!isValidCron && !isValidAdmin) {
      // Add timing protection to prevent admin enumeration
      const elapsed = Date.now() - startTime;
      const delay = Math.max(0, 100 - elapsed); // 100ms base delay
      await new Promise((resolve) => setTimeout(resolve, delay));

      logger.warn('[API] Unauthorized refresh attempt', {
        email: email?.split('@')[1] || 'unknown',
        hasCronHeader: !!authHeader,
      });

      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    // Get which view(s) to refresh
    const { searchParams } = new URL(request.url);
    const view = (searchParams.get('view') || 'all') as ViewType;

    // Validate view parameter
    if (!VALID_VIEWS.includes(view)) {
      return NextResponse.json(
        {
          success: false,
          error: `Invalid view parameter. Must be one of: ${VALID_VIEWS.join(', ')}`,
          code: 'INVALID_PARAMETER',
        },
        { status: 400 }
      );
    }

    const authMethod = isValidCron ? 'cron' : 'admin';
    logger.info('[API] Refreshing materialized views', {
      view,
      authMethod,
      email: email?.split('@')[1],
    });

    const supabase = getSupabaseAdmin();

    // Execute refresh based on view parameter
    let result;
    if (view === 'all') {
      result = await supabase.rpc('refresh_all_analytics');
    } else if (view === 'dao_activity') {
      result = await supabase.rpc('refresh_dao_activity_summary');
    } else if (view === 'user_activity') {
      result = await supabase.rpc('refresh_user_activity_summary');
    } else if (view === 'proposal_analytics') {
      result = await supabase.rpc('refresh_proposal_analytics');
    }

    if (result?.error) {
      logger.error('[API] Failed to refresh materialized views', result.error);
      return NextResponse.json(
        {
          success: false,
          error: result.error.message,
          code: 'REFRESH_FAILED',
        },
        { status: 500 }
      );
    }

    const refreshedAt = new Date().toISOString();
    logger.info('[API] Successfully refreshed materialized views', {
      view,
      refreshedAt,
      duration: Date.now() - startTime,
    });

    return NextResponse.json({
      success: true,
      data: {
        view,
        refreshedAt,
        duration: Date.now() - startTime,
      },
    });
  } catch (error) {
    logger.error('[API] Error refreshing analytics', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to refresh analytics',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * GET endpoint for health checks
 * Returns endpoint status without requiring authentication
 */
export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'Refresh analytics endpoint is available',
    views: VALID_VIEWS,
    timestamp: new Date().toISOString(),
  });
}
