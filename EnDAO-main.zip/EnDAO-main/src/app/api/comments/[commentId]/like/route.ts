/**
 * Comment Like API Route
 *
 * POST: Toggle like on a comment (like if not liked, unlike if already liked)
 * GET: Get like status for a comment
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  commentAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { commentLikesService } from '@/lib/services/interaction/interaction.service';

interface LikeResponse {
  success: boolean;
  data?: {
    liked: boolean;
    likeCount: number;
  };
  error?: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ commentId: string }> }
): Promise<NextResponse<LikeResponse>> {
  try {
    const { commentId } = await params;

    // Get Privy ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Validate comment exists
    const comment = await commentAdminRepository.findById(commentId);
    if (!comment) {
      return NextResponse.json(
        { success: false, error: 'Comment not found' },
        { status: 404 }
      );
    }

    // Toggle like using generic service
    const result = await commentLikesService.toggleInteraction(
      commentId,
      supabaseUser.id
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to toggle like' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    console.error('Error toggling comment like:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to toggle like' },
      { status: 500 }
    );
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ commentId: string }> }
): Promise<NextResponse<LikeResponse>> {
  try {
    const { commentId } = await params;

    // Get Privy ID from auth header (optional for GET)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    // Get user ID if authenticated
    let userId: string | undefined;
    if (privyId) {
      const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
      if (supabaseUser) {
        userId = supabaseUser.id;
      }
    }

    // Get interaction status using generic service
    const result = await commentLikesService.getInteractionStatus(
      commentId,
      userId
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to get like status' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    console.error('Error getting comment like status:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get like status' },
      { status: 500 }
    );
  }
}
