/**
 * Cache Health Check Endpoint
 * Quick health status for monitoring systems
 */

import { NextRequest } from 'next/server';
import { createCacheHealthCheck } from '@/lib/cache/cache-middleware';

// Use the middleware's health check function
export async function GET(req: NextRequest) {
  const healthCheck = createCacheHealthCheck();
  return await healthCheck(req);
}
