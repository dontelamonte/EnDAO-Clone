/**
 * Cache Metrics API Endpoint
 * Provides comprehensive cache performance metrics
 */

import { NextRequest } from 'next/server';
import { createCacheHealthCheck } from '@/lib/cache/cache-middleware';
import { getRoleCacheManager, CacheMetrics } from '@/lib/cache/role-cache';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { hasSystemRole, SystemRoles } from '@/lib/auth/rbac';
import { logger } from '@/lib/services/logger.service';

export async function GET(req: NextRequest) {
  try {
    // Only allow system admins to access cache metrics
    const authContext = await getAuthContext();
    if (!authContext) {
      return Response.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const isSuperAdmin = await hasSystemRole(
      authContext.uid,
      SystemRoles.SUPER_ADMIN
    );
    if (!isSuperAdmin) {
      return Response.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    // Get comprehensive cache metrics
    const metrics = CacheMetrics.getMetrics();
    const healthStatus = CacheMetrics.getHealthStatus();

    const response = {
      timestamp: new Date().toISOString(),
      health: healthStatus,
      metrics: {
        overall: metrics.overall,
        breakdown: {
          systemRoles: {
            hitRate: metrics.systemRoles.hitRate,
            hits: metrics.systemRoles.hits,
            misses: metrics.systemRoles.misses,
            totalRequests: metrics.systemRoles.totalRequests,
            size: metrics.systemRoles.size,
            evictions: metrics.systemRoles.evictions,
            averageResponseTime: metrics.systemRoles.averageResponseTime,
          },
          daoRoles: {
            hitRate: metrics.daoRoles.hitRate,
            hits: metrics.daoRoles.hits,
            misses: metrics.daoRoles.misses,
            totalRequests: metrics.daoRoles.totalRequests,
            size: metrics.daoRoles.size,
            evictions: metrics.daoRoles.evictions,
            averageResponseTime: metrics.daoRoles.averageResponseTime,
          },
          permissions: {
            hitRate: metrics.permissions.hitRate,
            hits: metrics.permissions.hits,
            misses: metrics.permissions.misses,
            totalRequests: metrics.permissions.totalRequests,
            size: metrics.permissions.size,
            evictions: metrics.permissions.evictions,
            averageResponseTime: metrics.permissions.averageResponseTime,
          },
          userContext: {
            hitRate: metrics.userContext.hitRate,
            hits: metrics.userContext.hits,
            misses: metrics.userContext.misses,
            totalRequests: metrics.userContext.totalRequests,
            size: metrics.userContext.size,
            evictions: metrics.userContext.evictions,
            averageResponseTime: metrics.userContext.averageResponseTime,
          },
        },
      },
      performance: {
        targetHitRate: 90,
        meetsTarget: metrics.overall.hitRate >= 90,
        efficiency: {
          cacheUtilization: (metrics.overall.totalSize / 15000) * 100, // Percentage of max cache size
          memoryEfficiency: metrics.overall.hitRate > 0 ? 'optimal' : 'poor',
        },
      },
    };

    logger.info('Cache metrics accessed', {
      uid: authContext.uid,
      hitRate: metrics.overall.hitRate,
      totalRequests: metrics.overall.totalRequests,
    });

    return Response.json(response);
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : 'Unknown error';
    logger.error(
      'Error generating cache metrics',
      error instanceof Error ? error : new Error(errorMessage),
      { errorMessage }
    );
    return Response.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    // Only allow super admins to reset cache metrics
    const authContext = await getAuthContext();
    if (!authContext) {
      return Response.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const isSuperAdmin = await hasSystemRole(
      authContext.uid,
      SystemRoles.SUPER_ADMIN
    );
    if (!isSuperAdmin) {
      return Response.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    const { action } = await req.json();

    switch (action) {
      case 'reset-metrics':
        CacheMetrics.resetMetrics();
        logger.warn('Cache metrics reset', { uid: authContext.uid });
        return Response.json({ success: true, message: 'Cache metrics reset' });

      case 'clear-cache':
        const cache = getRoleCacheManager();
        cache.clearAll();
        logger.warn('All caches cleared', { uid: authContext.uid });
        return Response.json({ success: true, message: 'All caches cleared' });

      default:
        return Response.json(
          {
            error:
              'Invalid action. Supported actions: reset-metrics, clear-cache',
          },
          { status: 400 }
        );
    }
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : 'Unknown error';
    logger.error(
      'Error processing cache management request',
      error instanceof Error ? error : new Error(errorMessage),
      { errorMessage }
    );
    return Response.json({ error: 'Internal server error' }, { status: 500 });
  }
}
