/**
 * Mobile Notification Preferences API
 *
 * GET /api/mobile/v1/notifications/prefs - Get notification preferences
 * PATCH /api/mobile/v1/notifications/prefs - Update notification preferences
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { deviceService } from '@/lib/services/mobile/device.service';
import { logger } from '@/lib/services/logger.service';
import { getInternalUserId } from '../../_lib/get-internal-user';

export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const result = await deviceService.getNotificationPrefs(internalUserId);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      '[GET /api/mobile/v1/notifications/prefs] Error',
      error as Error
    );
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      enabled,
      proposalCreated,
      voteReminders,
      votingEnded,
      membershipUpdates,
    } = body;

    // Validate that at least one preference is being updated
    if (
      enabled === undefined &&
      proposalCreated === undefined &&
      voteReminders === undefined &&
      votingEnded === undefined &&
      membershipUpdates === undefined
    ) {
      return NextResponse.json(
        { error: 'At least one preference must be provided' },
        { status: 400 }
      );
    }

    // Validate boolean types
    const booleanFields = {
      enabled,
      proposalCreated,
      voteReminders,
      votingEnded,
      membershipUpdates,
    };

    for (const [key, value] of Object.entries(booleanFields)) {
      if (value !== undefined && typeof value !== 'boolean') {
        return NextResponse.json(
          { error: `${key} must be a boolean` },
          { status: 400 }
        );
      }
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const result = await deviceService.updateNotificationPrefs(
      internalUserId,
      {
        enabled,
        proposalCreated,
        voteReminders,
        votingEnded,
        membershipUpdates,
      }
    );

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error(
      '[PATCH /api/mobile/v1/notifications/prefs] Error',
      error as Error
    );
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
