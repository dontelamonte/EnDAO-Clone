/**
 * Mobile Discussion Comments API Route
 *
 * GET - Fetch comments for a discussion
 * POST - Create a new comment
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  discussionCommentAdminRepository,
  discussionAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { z } from 'zod';
import { getInternalUserId } from '../../../_lib/get-internal-user';

const createCommentSchema = z.object({
  content: z.string().min(1, 'Content is required').max(10000),
  parentId: z.string().uuid().nullable().optional(),
});

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ discussionId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { discussionId } = await params;

    if (!discussionId) {
      return NextResponse.json(
        { success: false, error: 'Discussion ID required' },
        { status: 400 }
      );
    }

    // Parse query params
    const { searchParams } = new URL(request.url);
    const sortBy = searchParams.get('sortBy') as 'newest' | 'oldest' | null;

    // Fetch comments
    const comments = await discussionCommentAdminRepository.findByDiscussion(
      discussionId,
      {
        parentId: null,
        sortBy: sortBy || 'oldest',
      }
    );

    // Get unique user IDs from comments
    const userIds = new Set<string>();
    for (const comment of comments) {
      userIds.add(comment.userId);
    }

    // Batch fetch user info
    const userMap = new Map<
      string,
      { displayName: string | null; username: string | null }
    >();

    for (const userId of userIds) {
      try {
        const user = await userAdminRepository.findById(userId);
        if (user) {
          userMap.set(userId, {
            displayName: user.displayName || null,
            username: user.username || null,
          });
        }
      } catch {
        // Ignore lookup errors, will use fallback display
      }
    }

    // Map comments to mobile-friendly format
    const mappedComments = comments.map((comment) => {
      const userInfo = userMap.get(comment.userId);
      return {
        id: comment.id,
        content: comment.content,
        authorId: comment.userId,
        authorName: userInfo?.displayName || userInfo?.username || null,
        parentId: comment.parentId,
        createdAt: comment.createdAt,
        isEdited: comment.updatedAt !== comment.createdAt,
      };
    });

    return NextResponse.json({
      success: true,
      data: mappedComments,
    });
  } catch (error) {
    logger.error(
      '[Mobile Discussion Comments API] Error fetching comments',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch comments' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ discussionId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { discussionId } = await params;

    if (!discussionId) {
      return NextResponse.json(
        { success: false, error: 'Discussion ID required' },
        { status: 400 }
      );
    }

    // Verify discussion exists
    const discussion = await discussionAdminRepository.findById(discussionId);
    if (!discussion) {
      return NextResponse.json(
        { success: false, error: 'Discussion not found' },
        { status: 404 }
      );
    }

    // Verify discussion is not archived or converted
    if (discussion.status !== 'active') {
      return NextResponse.json(
        {
          success: false,
          error: 'Cannot comment on archived or converted discussions',
        },
        { status: 400 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validationResult = createCommentSchema.safeParse(body);

    if (!validationResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid request data',
          details: validationResult.error.errors,
        },
        { status: 400 }
      );
    }

    const { content, parentId } = validationResult.data;

    // If parentId is provided, verify the parent comment exists
    if (parentId) {
      const parentComment =
        await discussionCommentAdminRepository.findById(parentId);
      if (!parentComment || parentComment.discussionId !== discussionId) {
        return NextResponse.json(
          { success: false, error: 'Parent comment not found' },
          { status: 404 }
        );
      }
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Create the comment
    const comment = await discussionCommentAdminRepository.createComment({
      discussionId,
      userId: internalUserId,
      content,
      parentId: parentId || null,
    });

    // Update discussion comment count and last activity
    await discussionAdminRepository.incrementCommentCount(discussionId);

    // Fetch user info for the response
    let authorName: string | null = null;
    try {
      const user = await userAdminRepository.findById(internalUserId);
      if (user) {
        authorName = user.displayName || user.username || null;
      }
    } catch {
      // Ignore lookup errors
    }

    return NextResponse.json(
      {
        success: true,
        data: {
          id: comment.id,
          content: comment.content,
          authorId: comment.userId,
          authorName,
          parentId: comment.parentId,
          createdAt: comment.createdAt,
          isEdited: false,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    logger.error(
      '[Mobile Discussion Comments API] Error creating comment',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to create comment' },
      { status: 500 }
    );
  }
}
