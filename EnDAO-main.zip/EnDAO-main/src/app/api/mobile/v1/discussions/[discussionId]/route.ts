/**
 * Mobile Discussion Detail API Route
 *
 * GET - Fetch a single discussion with comments
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  discussionAdminRepository,
  discussionCommentAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ discussionId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { discussionId } = await params;

    if (!discussionId) {
      return NextResponse.json(
        { success: false, error: 'Discussion ID required' },
        { status: 400 }
      );
    }

    // Fetch discussion with creator info
    const discussion =
      await discussionAdminRepository.findByIdWithCreator(discussionId);

    if (!discussion) {
      return NextResponse.json(
        { success: false, error: 'Discussion not found' },
        { status: 404 }
      );
    }

    // Fetch comments for this discussion
    const comments = await discussionCommentAdminRepository.findByDiscussion(
      discussionId,
      { parentId: null, sortBy: 'oldest' }
    );

    // Get unique user IDs from comments
    const userIds = new Set<string>();
    for (const comment of comments) {
      userIds.add(comment.userId);
    }

    // Batch fetch user info
    const userMap = new Map<
      string,
      { displayName: string | null; username: string | null }
    >();

    for (const userId of userIds) {
      try {
        const user = await userAdminRepository.findById(userId);
        if (user) {
          userMap.set(userId, {
            displayName: user.displayName || null,
            username: user.username || null,
          });
        }
      } catch {
        // Ignore lookup errors, will use fallback display
      }
    }

    // Map comments to mobile-friendly format with author info
    const mappedComments = comments.map((comment) => {
      const userInfo = userMap.get(comment.userId);
      return {
        id: comment.id,
        content: comment.content,
        authorId: comment.userId,
        authorName: userInfo?.displayName || userInfo?.username || null,
        parentId: comment.parentId,
        createdAt: comment.createdAt,
        isEdited: comment.updatedAt !== comment.createdAt,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        discussion: {
          id: discussion.id,
          title: discussion.title,
          content: discussion.content,
          authorId: discussion.createdBy,
          authorName: discussion.createdByName,
          commentCount: discussion.commentCount,
          isPinned: discussion.isPinned,
          status: discussion.status,
          createdAt: discussion.createdAt,
          lastActivityAt: discussion.lastActivityAt,
        },
        comments: mappedComments,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Discussion API] Error fetching discussion',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch discussion' },
      { status: 500 }
    );
  }
}
