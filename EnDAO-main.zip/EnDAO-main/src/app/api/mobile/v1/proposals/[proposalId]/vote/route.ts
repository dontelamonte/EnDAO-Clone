/**
 * Mobile Vote Submission API Route
 *
 * Mobile-specific endpoint for casting or changing votes on proposals.
 * Uses getAuthContext for mobile auth pattern.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  daoMemberAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { VotingEngineService } from '@/lib/services/proposal/voting/voting-engine.service';
import { VoteSignatureService } from '@/lib/services/voting/vote-signature.service';
import { WalletVerificationService } from '@/lib/services/user/wallet-verification.service';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import type { VoteMessage } from '@endao/shared-types';

interface MobileVoteRequestBody {
  option: 'for' | 'against' | 'abstain';
  reason?: string;
  signature: string;
  walletAddress: string;
  signatureType: 'eip712' | 'personal_sign';
  voteMessage: VoteMessage;
  confidence?: number;
  rankedOptions?: string[];
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    // Apply rate limiting for voting operations
    const rateLimitResult = await rateLimiters.voting(request);
    if (rateLimitResult) {
      return rateLimitResult;
    }

    // Mobile auth pattern
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Parse request body
    const body: MobileVoteRequestBody = await request.json();

    if (!body.option || !['for', 'against', 'abstain'].includes(body.option)) {
      return NextResponse.json(
        {
          success: false,
          error: 'Valid vote option required (for, against, abstain)',
        },
        { status: 400 }
      );
    }

    // Validate signature fields
    if (!body.signature || !body.walletAddress || !body.voteMessage) {
      return NextResponse.json(
        {
          success: false,
          error: 'Signature, wallet address, and vote message are required',
        },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Validate vote message structure
    const messageValidation = VoteSignatureService.validateVoteMessage(
      body.voteMessage,
      proposalId
    );
    if (!messageValidation.isValid) {
      return NextResponse.json(
        {
          success: false,
          error: messageValidation.error || 'Invalid vote message',
        },
        { status: 400 }
      );
    }

    // Verify wallet ownership
    const isOwned = await WalletVerificationService.verifyWalletOwnership(
      userId,
      body.walletAddress
    );

    if (!isOwned) {
      const linkResult = await WalletVerificationService.ensureWalletLinked(
        userId,
        body.walletAddress
      );
      if (!linkResult) {
        return NextResponse.json(
          { success: false, error: 'Wallet ownership verification failed' },
          { status: 400 }
        );
      }
    }

    // Verify the signature
    const signatureValid = VoteSignatureService.verifySignature(
      body.signature,
      body.voteMessage,
      body.walletAddress,
      body.signatureType
    );

    if (!signatureValid) {
      return NextResponse.json(
        { success: false, error: 'Invalid signature' },
        { status: 400 }
      );
    }

    // Generate message hash for storage
    const messageHash =
      body.signatureType === 'eip712'
        ? VoteSignatureService.hashVoteMessageEIP712(body.voteMessage)
        : VoteSignatureService.hashVoteMessage(body.voteMessage);

    // Get proposal
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Get member data for voting weight
    const member = await daoMemberAdminRepository.findByDaoAndUser(
      proposal.daoId,
      userId
    );
    const memberData = {
      id: member?.id,
      votingWeight: 1,
      tokenBalance: 0,
    };

    // Cast or change vote
    const votingService = VotingEngineService.getInstance();
    const result = await votingService.castOrChangeVote(
      proposalId,
      userId,
      {
        option: body.option,
        reason: body.reason,
        confidence: body.confidence,
        rankedOptions: body.rankedOptions,
        signature: body.signature,
        walletAddress: body.walletAddress,
        signatureType: body.signatureType,
        messageHash,
        signatureNonce: body.voteMessage.nonce,
        signedAt: new Date(body.voteMessage.timestamp * 1000),
      },
      proposal as unknown as Parameters<
        typeof votingService.castOrChangeVote
      >[3],
      memberData
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to submit vote' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[Mobile Vote API] Error submitting vote', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to submit vote' },
      { status: 500 }
    );
  }
}
