/**
 * Mobile Can Vote API Route
 *
 * GET - Check if user can vote on a proposal
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  proposalAdminRepository,
  daoMemberAdminRepository,
  voteAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

export type VoteStatus =
  | 'eligible'
  | 'already_voted'
  | 'not_member'
  | 'voting_ended'
  | 'under_review'
  | 'draft';

export type UserVoteOption = 'for' | 'against' | 'abstain';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'You must be a DAO member to vote',
          voteStatus: 'not_member' as VoteStatus,
        },
      });
    }

    const userId = supabaseUser.id;

    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Check proposal status
    if (proposal.status === 'draft') {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'This proposal is still in draft mode',
          voteStatus: 'draft' as VoteStatus,
        },
      });
    }

    if (proposal.status === 'under_review') {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'This proposal is under review by admins',
          voteStatus: 'under_review' as VoteStatus,
        },
      });
    }

    // Check if voting period ended
    const now = new Date();
    const endTime = proposal.votingEndTime
      ? new Date(proposal.votingEndTime)
      : null;

    if (endTime && now > endTime) {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'Voting period has ended',
          voteStatus: 'voting_ended' as VoteStatus,
        },
      });
    }

    // Check DAO membership
    const members = await daoMemberAdminRepository.findMany({
      filters: [
        { field: 'daoId', operator: '==', value: proposal.daoId },
        { field: 'userId', operator: '==', value: userId },
        { field: 'status', operator: '==', value: 'active' },
      ],
      limit: 1,
    });

    if (members.length === 0) {
      return NextResponse.json({
        success: true,
        data: {
          canVote: false,
          reason: 'You must be a DAO member to vote',
          voteStatus: 'not_member' as VoteStatus,
        },
      });
    }

    // Check if user already voted
    const existingVotes = await voteAdminRepository.findMany({
      filters: [
        { field: 'proposalId', operator: '==', value: proposalId },
        { field: 'userId', operator: '==', value: userId },
      ],
      limit: 1,
    });

    if (existingVotes.length > 0) {
      const userVote = existingVotes[0];
      const allowChangeVote = proposal.votingConfig?.allowChangeVote ?? false;

      return NextResponse.json({
        success: true,
        data: {
          canVote: allowChangeVote,
          hasVoted: true,
          reason: allowChangeVote
            ? 'You can change your vote'
            : 'You have already voted on this proposal',
          voteStatus: allowChangeVote
            ? ('eligible' as VoteStatus)
            : ('already_voted' as VoteStatus),
          currentVote: {
            choice: userVote.vote,
            voteStrength: userVote.voteStrength,
            isSigned: !!userVote.signature,
          },
        },
      });
    }

    // User is eligible to vote
    return NextResponse.json({
      success: true,
      data: {
        canVote: true,
        hasVoted: false,
        reason: null,
        voteStatus: 'eligible' as VoteStatus,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Can Vote API] Error checking eligibility',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to check vote eligibility' },
      { status: 500 }
    );
  }
}
