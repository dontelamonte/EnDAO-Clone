/**
 * Mobile Proposal Detail API Route
 *
 * GET - Fetch a single proposal by ID
 */

import { NextRequest, NextResponse } from 'next/server';
import { proposalAdminRepository } from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    const proposal =
      await proposalAdminRepository.findByIdWithCreator(proposalId);

    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        id: proposal.id,
        title: proposal.title,
        description: proposal.description,
        status: proposal.status,
        votingStartTime: proposal.votingStartTime,
        votingEndTime: proposal.votingEndTime,
        creatorId: proposal.createdBy,
        votingType: proposal.votingConfig?.system,
        daoId: proposal.daoId,
        results: proposal.result,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Proposal API] Error fetching proposal',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch proposal' },
      { status: 500 }
    );
  }
}
