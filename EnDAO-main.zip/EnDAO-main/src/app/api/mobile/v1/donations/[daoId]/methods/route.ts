/**
 * Mobile Payment Methods API Route
 *
 * GET - Get available payment methods for a DAO based on hybrid treasury config
 */

import { NextRequest, NextResponse } from 'next/server';
import { logger } from '@/lib/services/logger.service';
import { hybridTreasuryService } from '@/lib/services/treasury';
import { DAOService } from '@/lib/services/dao';
import type {
  AvailablePaymentMethod,
  DonationPaymentMethod,
} from '@endao/shared-types';

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Validate DAO exists
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success) {
      return NextResponse.json(
        { success: false, error: daoResult.error, code: daoResult.code },
        { status: 404 }
      );
    }
    if (!daoResult.data) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get available payment methods from hybrid treasury service
    const methodsResult =
      await hybridTreasuryService.getAvailablePaymentMethods(daoId);

    if (!methodsResult.success) {
      logger.warn(`[Mobile Payment Methods] Failed to fetch for DAO ${daoId}`, {
        error: methodsResult.error,
      });
      return NextResponse.json(
        {
          success: false,
          error: methodsResult.error,
          code: methodsResult.code,
        },
        { status: 500 }
      );
    }
    if (!methodsResult.data) {
      logger.warn(`[Mobile Payment Methods] No data for DAO ${daoId}`);
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to fetch payment methods',
          code: 'NOT_FOUND',
        },
        { status: 500 }
      );
    }

    const availableMethods = methodsResult.data;

    // Build detailed method information
    const methods: AvailablePaymentMethod[] = [];

    if (availableMethods.includes('card')) {
      methods.push({
        method: 'card',
        enabled: true,
        displayName: 'Card Payment',
        description: 'Pay with credit or debit card via Stripe',
        processingTime: 'Instant',
        fees: {
          platformFeePercent: 5,
          processorFeePercent: 2.9,
          processorFeeFixed: 0.3,
        },
      });
    }

    if (availableMethods.includes('crypto')) {
      methods.push({
        method: 'crypto',
        enabled: true,
        displayName: 'Digital Payment',
        description: 'Pay with digital currency',
        processingTime: '1-2 minutes (verification)',
        fees: {
          platformFeePercent: 5,
          processorFeePercent: 0,
          networkFeeEstimate: 0.5,
        },
      });
    }

    // Determine default method
    const defaultMethod: DonationPaymentMethod = availableMethods.includes(
      'card'
    )
      ? 'card'
      : 'crypto';

    return NextResponse.json({
      success: true,
      data: {
        daoId,
        methods,
        defaultMethod,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Payment Methods] Error fetching payment methods',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch payment methods' },
      { status: 500 }
    );
  }
}
