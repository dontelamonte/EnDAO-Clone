/**
 * Mobile Treasury Execution Signing API Route
 *
 * POST - Sign a treasury execution transaction
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';
import { treasurySignatureCollectionService } from '@/lib/services/treasury/treasury-signature-collection.service';
import { treasuryExecutionAdminRepository } from '@/lib/data/repositories/supabase/treasury-execution.repository';
import { daoAdminRepository } from '@/lib/data/repositories';
import { safeService } from '@/lib/services/safe.service';
import { getInternalUserId } from '../../../../_lib/get-internal-user';

interface SignRequestBody {
  signature: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ executionId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { executionId } = await params;

    if (!executionId) {
      return NextResponse.json(
        { success: false, error: 'Execution ID required' },
        { status: 400 }
      );
    }

    // Parse request body
    const body = (await request.json()) as SignRequestBody;
    const { signature } = body;

    if (!signature) {
      return NextResponse.json(
        { success: false, error: 'Signature required' },
        { status: 400 }
      );
    }

    // Validate signature format
    const formatValidation =
      treasurySignatureCollectionService.validateSignatureFormat(signature);

    if (!formatValidation.isValid) {
      return NextResponse.json(
        {
          success: false,
          error: formatValidation.error || 'Invalid signature format',
        },
        { status: 400 }
      );
    }

    // Get execution
    const execution =
      await treasuryExecutionAdminRepository.findById(executionId);

    if (!execution) {
      return NextResponse.json(
        { success: false, error: 'Execution not found' },
        { status: 404 }
      );
    }

    const daoId = execution.daoId;

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Validate treasury access
    const validation =
      await treasuryAccessControlService.validateTreasuryOperation(
        daoId,
        internalUserId,
        'sign_transaction',
        authContext
      );

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: validation.error || 'Treasury access validation failed',
          code: validation.code,
        },
        { status: 403 }
      );
    }

    if (!validation.data.isValid) {
      const errors = validation.data.errors || ['Access denied'];
      const status = validation.data.accessStatus;

      let errorMessage = 'Treasury access denied';
      let statusCode = 403;

      if (status?.reason === 'dao_not_found') {
        errorMessage = 'DAO not found';
        statusCode = 404;
      } else if (status?.reason === 'treasury_frozen') {
        errorMessage = `Treasury is frozen: ${status.details}`;
      } else if (status?.details) {
        errorMessage = status.details;
      }

      return NextResponse.json(
        {
          success: false,
          error: errorMessage,
          reason: status?.reason,
          details: errors.join(', '),
        },
        { status: statusCode }
      );
    }

    // Get DAO to verify Safe address
    const dao = await daoAdminRepository.findById(daoId);

    if (!dao || !dao.safeAddress) {
      return NextResponse.json(
        { success: false, error: 'DAO treasury not configured' },
        { status: 400 }
      );
    }

    // Verify user is a Safe owner
    if (!authContext.primaryWallet) {
      return NextResponse.json(
        { success: false, error: 'Wallet address required' },
        { status: 400 }
      );
    }

    const isOwner = await safeService.isOwner(
      dao.safeAddress,
      authContext.primaryWallet
    );

    if (!isOwner) {
      return NextResponse.json(
        { success: false, error: 'Not authorized - not a Safe owner' },
        { status: 403 }
      );
    }

    // Add signature
    const signResult = await treasurySignatureCollectionService.addSignature(
      executionId,
      internalUserId,
      signature,
      authContext
    );

    if (!signResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: signResult.message || 'Failed to add signature',
        },
        { status: signResult.alreadySigned ? 400 : 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        message: signResult.message,
        currentSignatures: signResult.signatureCount,
        requiredSignatures: signResult.requiredSignatures,
        hasEnoughSignatures: signResult.hasEnoughSignatures,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Treasury Sign API] Error signing execution',
      error as Error
    );

    // Handle specific error messages
    const errorMessage =
      error instanceof Error ? error.message : 'Failed to sign transaction';

    if (errorMessage.includes('Already signed')) {
      return NextResponse.json(
        { success: false, error: 'You have already signed this transaction' },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, error: errorMessage },
      { status: 500 }
    );
  }
}
