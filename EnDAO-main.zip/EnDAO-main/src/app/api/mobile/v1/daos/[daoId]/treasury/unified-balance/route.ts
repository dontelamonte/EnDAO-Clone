/**
 * Mobile Unified Treasury Balance API Route
 *
 * GET - Fetch combined fiat + crypto balance for a DAO (hybrid treasury)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { hybridTreasuryService } from '@/lib/services/treasury';
import { DAOService } from '@/lib/services/dao';
import { getInternalUserId } from '../../../../_lib/get-internal-user';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Validate DAO exists and user is a member
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success) {
      return NextResponse.json(
        { success: false, error: daoResult.error, code: daoResult.code },
        { status: 404 }
      );
    }
    if (!daoResult.data) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get internal user ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Check membership
    const membershipResult = await daoService.getMembership(
      daoId,
      internalUserId
    );
    if (!membershipResult.success || !membershipResult.data) {
      return NextResponse.json(
        { success: false, error: 'Access denied - not a DAO member' },
        { status: 403 }
      );
    }

    // Get unified balance from hybrid treasury service
    const balanceResult = await hybridTreasuryService.getUnifiedBalance(daoId);

    if (!balanceResult.success) {
      logger.warn(`[Mobile Unified Balance] Failed to fetch for DAO ${daoId}`, {
        error: balanceResult.error,
      });
      return NextResponse.json(
        {
          success: false,
          error: balanceResult.error,
          code: balanceResult.code,
        },
        { status: 500 }
      );
    }
    if (!balanceResult.data) {
      logger.warn(`[Mobile Unified Balance] No data for DAO ${daoId}`);
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to fetch unified balance',
          code: 'NOT_FOUND',
        },
        { status: 500 }
      );
    }

    // Get rail status
    const railsResult = await hybridTreasuryService.getRailStatus(daoId);

    return NextResponse.json({
      success: true,
      data: {
        balance: balanceResult.data,
        rails: railsResult.success ? railsResult.data : null,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Unified Balance] Error fetching unified balance',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch unified balance' },
      { status: 500 }
    );
  }
}
