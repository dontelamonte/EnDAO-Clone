/**
 * Mobile Admin Stats API Route
 *
 * GET /api/mobile/v1/daos/[daoId]/admin/stats
 *
 * Returns admin-specific statistics for a DAO.
 * Only accessible to admin/owner users.
 */

import { NextRequest, NextResponse } from 'next/server';
import { daoMemberAdminRepository } from '@/lib/data/repositories/supabase/dao-member.repository';
import { proposalAdminRepository } from '@/lib/data/repositories/supabase/proposal.repository';
import { treasuryDeploymentAdminRepository } from '@/lib/data/repositories/supabase/treasury-deployment.repository';
import { logger } from '@/lib/services/logger.service';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { getInternalUserId } from '../../../../_lib/get-internal-user';
import { getSupabaseAdmin } from '@/lib/supabase';

interface AdminStatsResponse {
  memberCount: number;
  adminCount: number;
  proposalCount: number;
  activeProposalCount: number;
  passedProposalCount: number;
  rejectedProposalCount: number;
  recentMemberJoins: number;
  recentProposalCount: number;
  treasuryBalance: string | null;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    // Await params as required by Next.js 15
    const { daoId } = await params;

    // Authenticate the request
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized', code: 'UNAUTHORIZED' },
        { status: 401 }
      );
    }

    // Get internal user ID from Privy ID
    const userId = await getInternalUserId(authContext);
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    // Verify user is admin/owner of the DAO
    const isAdmin = await daoMemberAdminRepository.isAdmin(daoId, userId);
    if (!isAdmin) {
      return NextResponse.json(
        { success: false, error: 'Admin access required', code: 'FORBIDDEN' },
        { status: 403 }
      );
    }

    logger.debug(`[API] Loading admin stats for DAO ${daoId}`);

    // Calculate date for "last 7 days" metrics
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const sevenDaysAgoISO = sevenDaysAgo.toISOString();

    // Get admin Supabase client for direct queries
    const supabase = getSupabaseAdmin();

    // Fetch stats in parallel
    const [
      memberCount,
      adminCount,
      proposalCount,
      activeProposalCount,
      passedProposalCount,
      rejectedProposalCount,
      recentMembers,
      recentProposals,
      primaryDeployment,
    ] = await Promise.all([
      // Member counts
      daoMemberAdminRepository.countActiveMembers(daoId),
      daoMemberAdminRepository.countAdmins(daoId),

      // Proposal counts
      supabase
        .from('proposals')
        .select('id', { count: 'exact', head: true })
        .eq('dao_id', daoId)
        .neq('status', 'deleted')
        .then((r: { count: number | null }) => r.count || 0),

      proposalAdminRepository.countByStatus(daoId, 'active'),
      proposalAdminRepository.countByStatus(daoId, 'passed'),
      proposalAdminRepository.countByStatus(daoId, 'failed'),

      // Recent joins (last 7 days)
      supabase
        .from('dao_members')
        .select('id', { count: 'exact', head: true })
        .eq('dao_id', daoId)
        .eq('status', 'active')
        .gte('joined_at', sevenDaysAgoISO)
        .then((r: { count: number | null }) => r.count || 0),

      // Recent proposals (last 7 days)
      supabase
        .from('proposals')
        .select('id', { count: 'exact', head: true })
        .eq('dao_id', daoId)
        .neq('status', 'deleted')
        .gte('created_at', sevenDaysAgoISO)
        .then((r: { count: number | null }) => r.count || 0),

      // Treasury balance (if configured)
      treasuryDeploymentAdminRepository.findPrimaryByDAO(daoId),
    ]);

    // Calculate total treasury balance if configured
    let treasuryBalance: string | null = null;
    if (primaryDeployment) {
      const balances =
        await treasuryDeploymentAdminRepository.getBalances(
          primaryDeployment.id
        );
      const totalUsd = balances.reduce((sum, b) => sum + b.usdValue, 0);
      treasuryBalance = totalUsd.toFixed(2);
    }

    const stats: AdminStatsResponse = {
      memberCount,
      adminCount,
      proposalCount,
      activeProposalCount,
      passedProposalCount,
      rejectedProposalCount,
      recentMemberJoins: recentMembers,
      recentProposalCount: recentProposals,
      treasuryBalance,
    };

    // Cache for 5 minutes
    return NextResponse.json(
      { success: true, data: stats },
      {
        headers: {
          'Cache-Control':
            'private, max-age=300, stale-while-revalidate=60',
        },
      }
    );
  } catch (error) {
    logger.error('[API] Error loading admin stats', error as Error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to load admin stats',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
