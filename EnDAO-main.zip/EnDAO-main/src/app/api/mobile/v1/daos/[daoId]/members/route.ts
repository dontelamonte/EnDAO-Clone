/**
 * Mobile DAO Members API Route
 *
 * GET - Fetch members for a DAO with pagination and filtering
 */

import { NextRequest, NextResponse } from 'next/server';
import { daoMemberAdminRepository, userAdminRepository } from '@/lib/data/repositories';
import { MemberQueriesService } from '@/lib/services/dao/member-queries';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import type { MemberRole } from '@endao/shared-types';
import { getInternalUserId } from '../../../_lib/get-internal-user';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    // Authenticate the request
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Verify user is a member of the DAO
    const memberQueriesService = MemberQueriesService.getInstance();
    const membershipResult = await memberQueriesService.checkMemberExists(
      daoId,
      internalUserId
    );

    if (!membershipResult.success || !membershipResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be a member of this DAO to view its members',
        },
        { status: 403 }
      );
    }

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const limit = Math.min(
      parseInt(searchParams.get('limit') || '50', 10),
      100
    ); // Max 100
    const offset = Math.max(parseInt(searchParams.get('offset') || '0', 10), 0);
    const roleParam = searchParams.get('role') as MemberRole | null;

    // Fetch members with pagination
    const result = await daoMemberAdminRepository.findMembersPaginated(daoId, {
      limit,
      offset,
      sortBy: 'joinedAt',
      sortOrder: 'desc',
      roles: roleParam
        ? [roleParam as 'admin' | 'member']
        : undefined,
      activeOnly: true,
    });

    // Get user IDs for members with null displayName to fetch from user profile
    const membersWithNullNames = result.members.filter((m) => !m.displayName);
    const userIds = membersWithNullNames.map((m) => m.userId);

    // Fetch user profiles for members with null displayName
    let userProfiles: Map<string, { displayName: string | null; username: string | null }> = new Map();
    if (userIds.length > 0) {
      const users = await userAdminRepository.findByIds(userIds);
      userProfiles = new Map(
        users.map((u) => [u.id, { displayName: u.displayName, username: u.username }])
      );
    }

    // Map to mobile-friendly format with user profile fallback
    const members = result.members.map((member) => {
      // Use member displayName, or fall back to user profile displayName/username
      let displayName = member.displayName;
      if (!displayName && userProfiles.has(member.userId)) {
        const userProfile = userProfiles.get(member.userId);
        displayName = userProfile?.displayName || userProfile?.username || null;
      }

      return {
        id: member.id,
        userId: member.userId,
        role: member.role,
        joinedAt: member.joinedAt,
        displayName,
        bio: member.bio,
        avatarUrl: member.avatarUrl,
      };
    });

    // Calculate hasMore
    const hasMore = offset + members.length < result.total;

    return NextResponse.json({
      success: true,
      data: {
        members,
        total: result.total,
        hasMore,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile DAO Members API] Error fetching members',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch members' },
      { status: 500 }
    );
  }
}
