/**
 * Mobile Treasury Overview API Route
 *
 * GET - Fetch treasury overview for a DAO (balance, tokens, configuration)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { TreasuryService } from '@/lib/services/treasury';
import { DAOService } from '@/lib/services/dao';
import { getInternalUserId } from '../../../_lib/get-internal-user';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Validate DAO exists and user is a member
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success) {
      return NextResponse.json(
        { success: false, error: daoResult.error, code: daoResult.code },
        { status: 404 }
      );
    }
    if (!daoResult.data) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get internal user ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Check membership
    const membershipResult = await daoService.getMembership(
      daoId,
      internalUserId
    );
    if (!membershipResult.success || !membershipResult.data) {
      return NextResponse.json(
        { success: false, error: 'Access denied - not a DAO member' },
        { status: 403 }
      );
    }

    // Get treasury balance
    const treasuryService = TreasuryService.getInstance();
    logger.debug(`[Mobile Treasury API] Fetching balance for DAO ${daoId}`);
    const balanceResult = await treasuryService.getBalance(daoId);

    if (!balanceResult.success) {
      logger.debug(
        `[Mobile Treasury API] Balance result: success=false`,
        { error: balanceResult.error }
      );
      logger.warn(`[Mobile Treasury API] Balance fetch failed for DAO ${daoId}`, {
        error: balanceResult.error,
      });
      return NextResponse.json(
        {
          success: false,
          error: balanceResult.error,
          code: balanceResult.code,
        },
        { status: 500 }
      );
    }

    const balance = balanceResult.data;
    const dao = daoResult.data;

    // Format response for mobile
    const response = {
      address: dao.safeAddress || null,
      balance: balance?.totalValue.toString() || '0',
      balanceUsd:
        balance?.totalValue && balance.totalValue > 0
          ? balance.totalValue.toString()
          : null,
      tokens: (balance?.assets || []).map((asset) => ({
        symbol: asset.symbol,
        balance: asset.balance.toString(),
        balanceUsd:
          asset.value && asset.value > 0 ? asset.value.toString() : null,
      })),
      isConfigured: !!dao.safeAddress,
    };

    return NextResponse.json({
      success: true,
      data: response,
    });
  } catch (error) {
    logger.error(
      '[Mobile Treasury API] Error fetching treasury overview',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch treasury overview' },
      { status: 500 }
    );
  }
}
