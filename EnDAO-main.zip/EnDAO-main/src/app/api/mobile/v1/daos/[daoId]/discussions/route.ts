/**
 * Mobile DAO Discussions API Route
 *
 * GET - Fetch discussions for a DAO
 */

import { NextRequest, NextResponse } from 'next/server';
import { discussionAdminRepository } from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import type { DiscussionStatus } from '@/lib/data/repositories/supabase/discussion.repository';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    const { searchParams } = new URL(request.url);
    const statusParam = searchParams.get('status');
    const status = statusParam as DiscussionStatus | undefined;

    const discussions = await discussionAdminRepository.findByDaoWithCreator(
      daoId,
      { status }
    );

    // Map to mobile-friendly format
    const mappedDiscussions = discussions.map((discussion) => ({
      id: discussion.id,
      title: discussion.title,
      content: discussion.content,
      authorId: discussion.createdBy,
      authorName: discussion.createdByName,
      commentCount: discussion.commentCount,
      isPinned: discussion.isPinned,
      status: discussion.status,
      createdAt: discussion.createdAt,
      lastActivityAt: discussion.lastActivityAt,
    }));

    return NextResponse.json({
      success: true,
      data: mappedDiscussions,
    });
  } catch (error) {
    logger.error(
      '[Mobile DAO Discussions API] Error fetching discussions',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch discussions' },
      { status: 500 }
    );
  }
}
