/**
 * Mobile DAOs API Route
 *
 * GET - Fetch user's DAOs
 * POST - Create a new DAO
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { userAdminRepository } from '@/lib/data/repositories';
import { DAOService } from '@/lib/services/dao';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import type { CreateDAOFormData } from '@endao/shared-types';

// Validation schema for mobile DAO creation
const mobileDAOCreateSchema = z.object({
  // Required fields
  name: z
    .string()
    .min(3, 'DAO name must be at least 3 characters')
    .max(100, 'DAO name must be less than 100 characters')
    .refine(
      (str) => !/<script|javascript:|vbscript:|onload=|onerror=/i.test(str),
      'Name contains potentially dangerous content'
    ),
  description: z
    .string()
    .min(10, 'Description must be at least 10 characters')
    .max(1000, 'Description must be less than 1000 characters')
    .refine(
      (str) => !/<script|javascript:|vbscript:|onload=|onerror=/i.test(str),
      'Description contains potentially dangerous content'
    ),
  category: z.enum(['Community', 'Commerce'], {
    errorMap: () => ({ message: 'Category must be either Community or Commerce' }),
  }),
  organizationType: z
    .enum([
      'nonprofit',
      'cooperative',
      'business',
      'community_org',
      'social_org',
      'general',
    ])
    .default('general'),

  // Optional fields
  tags: z
    .array(
      z
        .string()
        .min(1)
        .max(50)
        .refine(
          (str) => !/<script|javascript:|vbscript:|onload=|onerror=/i.test(str),
          'Tag contains potentially dangerous content'
        )
    )
    .max(20, 'Maximum 20 tags allowed')
    .optional()
    .default([]),
  joinPermission: z
    .enum(['open', 'request', 'invite-only'])
    .optional()
    .default('open'),
  governanceType: z
    .enum(['token', 'member', 'hybrid'])
    .optional()
    .default('member'),
});

type MobileDAOCreateInput = z.infer<typeof mobileDAOCreateSchema>;

export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const daoService = DAOService.getInstance();
    const result = await daoService.getUserDAOs(supabaseUser.id);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error || 'Failed to fetch DAOs' },
        { status: 400 }
      );
    }

    // Map to mobile-friendly format
    const daos = (result.data || []).map((dao) => ({
      id: dao.id,
      name: dao.name,
      slug: dao.slug,
      description: dao.description,
      logoUrl: dao.logoUrl,
      memberCount: dao.memberCount,
      category: dao.category,
    }));

    return NextResponse.json({
      success: true,
      data: daos,
    });
  } catch (error) {
    logger.error('[Mobile DAOs API] Error fetching DAOs', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch DAOs' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // Authenticate the request
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get Supabase user
    const supabaseUser = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validationResult = mobileDAOCreateSchema.safeParse(body);

    if (!validationResult.success) {
      const firstError = validationResult.error.errors[0];
      logger.warn('[Mobile DAOs API] Validation error', {
        error: firstError,
        body,
      });
      return NextResponse.json(
        {
          success: false,
          error: firstError.message || 'Invalid input data',
        },
        { status: 400 }
      );
    }

    const validatedData = validationResult.data;

    // Generate slug from name
    const slug = validatedData.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    // Map mobile input to CreateDAOFormData
    const daoData: CreateDAOFormData = {
      name: validatedData.name,
      description: validatedData.description,
      slug,
      category: validatedData.category,
      organizationType: validatedData.organizationType,
      tags: validatedData.tags,
      isDiscoverable: validatedData.joinPermission !== 'invite-only',
      joinPermission: validatedData.joinPermission,
      visibility: 'public', // Default for mobile
      socialLinks: {},
      settings: {
        isPublic: true,
        requireApprovalToJoin: validatedData.joinPermission === 'request',
        allowPublicProposals: true,
        allowMemberInvites: true,
        enableProposalDrafts: true,
        votingPeriodDays: 7,
        minimumVotingPeriod: 24,
        maximumVotingPeriod: 720,
        quorumPercentage: 51,
        passThreshold: 50,
        allowAnonymousVoting: false,
        minDaysToCreateProposal: 0,
        minDaysToVote: 0,
        minDaysToDelegate: 30,
      },
    };

    // Create DAO using service
    const daoService = DAOService.getInstance();
    const result = await daoService.createDAO(supabaseUser.id, daoData);

    if (!result.success) {
      logger.error(
        '[Mobile DAOs API] DAO creation failed',
        undefined,
        {
          error: result.error,
          errorCode: result.code,
          userId: supabaseUser.id,
        }
      );
      return NextResponse.json(
        { success: false, error: result.error, code: result.code },
        { status: 400 }
      );
    }

    // Fetch the created DAO to get full details
    const newDaoId = result.data.id;
    const createdDAO = await daoService.getDAO(newDaoId);
    if (!createdDAO.success) {
      logger.error(
        '[Mobile DAOs API] Failed to fetch created DAO',
        undefined,
        {
          daoId: newDaoId,
          error: createdDAO.error,
          errorCode: createdDAO.code,
        }
      );
      return NextResponse.json(
        {
          success: false,
          error: createdDAO.error,
          code: createdDAO.code,
        },
        { status: 500 }
      );
    }
    if (!createdDAO.data) {
      logger.error('[Mobile DAOs API] No data for created DAO', undefined, {
        daoId: newDaoId,
      });
      return NextResponse.json(
        {
          success: false,
          error: 'DAO created but failed to fetch details',
          code: 'NOT_FOUND',
        },
        { status: 500 }
      );
    }

    // Return mobile-friendly response
    return NextResponse.json(
      {
        success: true,
        data: {
          id: createdDAO.data.id,
          name: createdDAO.data.name,
          slug: createdDAO.data.slug,
          description: createdDAO.data.description,
          category: createdDAO.data.category,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    logger.error('[Mobile DAOs API] Error creating DAO', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to create DAO' },
      { status: 500 }
    );
  }
}
