/**
 * Mobile DAO Activities API Route
 *
 * GET - Fetch activity feed for a DAO with pagination
 */

import { NextRequest, NextResponse } from 'next/server';
import { activityAdminRepository } from '@/lib/data/repositories';
import { MemberQueriesService } from '@/lib/services/dao/member-queries';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { getInternalUserId } from '../../../_lib/get-internal-user';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    // Authenticate the request
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Verify user is a member of the DAO
    const memberQueriesService = MemberQueriesService.getInstance();
    const membershipResult = await memberQueriesService.checkMemberExists(
      daoId,
      internalUserId
    );

    if (!membershipResult.success || !membershipResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: 'You must be a member of this DAO to view its activities',
        },
        { status: 403 }
      );
    }

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const limit = Math.min(
      parseInt(searchParams.get('limit') || '20', 10),
      100
    ); // Max 100
    const offset = Math.max(parseInt(searchParams.get('offset') || '0', 10), 0);

    // Fetch activities
    const activities = await activityAdminRepository.findByDaoId(daoId, {
      limit,
      offset,
    });

    // Map to mobile-friendly format
    const mappedActivities = activities.map((activity) => ({
      id: activity.id,
      type: activity.type,
      title: activity.title,
      description: activity.description,
      userId: activity.userId,
      createdAt: activity.createdAt,
      data: activity.data,
    }));

    // Calculate hasMore (if we got the limit, there might be more)
    const hasMore = activities.length === limit;

    return NextResponse.json({
      success: true,
      data: {
        activities: mappedActivities,
        hasMore,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile DAO Activities API] Error fetching activities',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch activities' },
      { status: 500 }
    );
  }
}
