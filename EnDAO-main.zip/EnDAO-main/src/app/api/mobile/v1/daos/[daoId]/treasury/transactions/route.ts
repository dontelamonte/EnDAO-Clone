/**
 * Mobile Treasury Transactions API Route
 *
 * GET - Fetch transaction history for a DAO treasury
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { TreasuryService } from '@/lib/services/treasury';
import { DAOService } from '@/lib/services/dao';
import { getInternalUserId } from '../../../../_lib/get-internal-user';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Parse query parameters
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    // Validate limit and offset
    if (limit < 1 || limit > 100) {
      return NextResponse.json(
        { success: false, error: 'Limit must be between 1 and 100' },
        { status: 400 }
      );
    }

    if (offset < 0) {
      return NextResponse.json(
        { success: false, error: 'Offset must be non-negative' },
        { status: 400 }
      );
    }

    // Validate DAO exists and user is a member
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success || !daoResult.data) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Check membership
    const membershipResult = await daoService.getMembership(
      daoId,
      internalUserId
    );
    if (!membershipResult.success || !membershipResult.data) {
      return NextResponse.json(
        { success: false, error: 'Access denied - not a DAO member' },
        { status: 403 }
      );
    }

    // Get transaction history
    const treasuryService = TreasuryService.getInstance();
    const historyResult = await treasuryService.getTransactionHistory(daoId, {
      limit: limit + 1, // Fetch one extra to check if there are more
    });

    if (!historyResult.success) {
      return NextResponse.json(
        {
          success: false,
          error:
            historyResult.error || 'Failed to fetch transaction history',
        },
        { status: 500 }
      );
    }

    const allTransactions = historyResult.data || [];

    // Apply offset manually (since we can't pass it to service directly)
    const paginatedTransactions = allTransactions.slice(
      offset,
      offset + limit
    );
    const hasMore = allTransactions.length > offset + limit;

    // Map transactions to mobile format
    const transactions = paginatedTransactions.map((tx) => {
      // Determine transaction type
      let type: 'incoming' | 'outgoing' = 'outgoing';
      if (
        tx.type === 'proposal_execution' ||
        tx.type === 'direct_transfer'
      ) {
        type = 'outgoing';
      } else if (tx.type === 'admin_action') {
        type = 'incoming';
      }

      // Map status
      let status: 'pending' | 'confirmed' | 'failed' = 'pending';
      if (tx.status === 'completed') {
        status = 'confirmed';
      } else if (tx.status === 'failed') {
        status = 'failed';
      } else if (
        tx.status === 'pending' ||
        tx.status === 'signing' ||
        tx.status === 'executing'
      ) {
        status = 'pending';
      }

      return {
        id: tx.id,
        type,
        amount: tx.amount,
        tokenSymbol: tx.asset,
        from: tx.from || '',
        to: tx.to || '',
        status,
        timestamp: tx.timestamp
          ? tx.timestamp.toISOString()
          : tx.createdAt.toISOString(),
        txHash: tx.txHash || tx.blockchainTxHash || null,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        transactions,
        hasMore,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Treasury API] Error fetching transaction history',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch transaction history' },
      { status: 500 }
    );
  }
}
