/**
 * Mobile DAO Detail API Route
 *
 * GET - Fetch a single DAO by ID
 * PATCH - Update DAO settings (admin only)
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { userAdminRepository } from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Look up user by Privy ID to get internal user ID
    const user = await userAdminRepository.findByPrivyId(authContext.privyUserId);
    const internalUserId = user?.id;

    const daoService = DAOService.getInstance();
    const isUUID =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        daoId
      );
    const result = isUUID
      ? await daoService.getDAO(daoId)
      : await daoService.getDAOBySlug(daoId);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error, code: result.code },
        { status: 404 }
      );
    }
    if (!result.data) {
      return NextResponse.json(
        { success: false, error: 'DAO not found', code: 'NOT_FOUND' },
        { status: 404 }
      );
    }

    // Get user's role in this DAO (only if user exists in our system)
    let userRole: string | undefined;
    if (internalUserId) {
      const membershipResult = await daoService.getMembership(
        result.data.id,
        internalUserId
      );
      userRole = membershipResult.success ? membershipResult.data?.role : undefined;
    }

    return NextResponse.json({
      success: true,
      data: {
        ...result.data,
        userRole,
      },
    });
  } catch (error) {
    logger.error('[Mobile DAO API] Error fetching DAO', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch DAO' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { name, description, logoUrl } = body;

    // Validate at least one field is being updated
    if (!name && !description && !logoUrl) {
      return NextResponse.json(
        { success: false, error: 'No fields to update' },
        { status: 400 }
      );
    }

    // Look up user by Privy ID to get internal user ID
    const user = await userAdminRepository.findByPrivyId(authContext.privyUserId);
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const daoService = DAOService.getInstance();

    // Build update data object - using any for flexibility since UpdateDAOFormData schema is limited
    const updateData: any = {};
    if (name) updateData.name = name;
    if (description) updateData.description = description;
    if (logoUrl) updateData.logoUrl = logoUrl;

    // Update DAO (service will check admin permissions)
    const result = await daoService.updateDAO(daoId, updateData, user.id);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error, code: result.code },
        { status: result.error.includes('permission') ? 403 : 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[Mobile DAO API] Error updating DAO', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to update DAO' },
      { status: 500 }
    );
  }
}
