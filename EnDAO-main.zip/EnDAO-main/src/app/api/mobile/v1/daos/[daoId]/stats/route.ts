/**
 * Mobile DAO Stats API Route
 *
 * GET - Fetch DAO statistics
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  daoMemberAdminRepository,
  proposalAdminRepository,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    const dao = await daoAdminRepository.findById(daoId);
    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    const [memberCount, activeProposals] = await Promise.all([
      daoMemberAdminRepository.countActiveMembers(daoId),
      proposalAdminRepository.findMany({
        filters: [
          { field: 'daoId', operator: '==', value: daoId },
          { field: 'status', operator: '==', value: 'active' },
        ],
      }),
    ]);

    // Get total proposal count
    const allProposals = await proposalAdminRepository.findMany({
      filters: [{ field: 'daoId', operator: '==', value: daoId }],
    });

    // Calculate participation rate from recent proposals
    const validStatuses = ['active', 'passed', 'failed', 'executed'];
    const proposalsWithVotes = allProposals.filter(
      (p) =>
        validStatuses.includes(p.status) &&
        p.result &&
        typeof p.result.participationRate === 'number'
    );

    let participationRate = 0;
    if (proposalsWithVotes.length > 0) {
      const rates = proposalsWithVotes.map(
        (p) => p.result?.participationRate || 0
      );
      participationRate = Math.round(
        rates.reduce((a, b) => a + b, 0) / rates.length
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        memberCount,
        proposalCount: allProposals.length,
        activeProposalCount: activeProposals.length,
        participationRate,
      },
    });
  } catch (error) {
    logger.error('[Mobile DAO Stats API] Error fetching stats', error as Error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch DAO stats' },
      { status: 500 }
    );
  }
}
