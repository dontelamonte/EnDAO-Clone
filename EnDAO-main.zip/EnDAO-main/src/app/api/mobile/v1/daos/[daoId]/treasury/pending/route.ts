/**
 * Mobile Treasury Pending Executions API Route
 *
 * GET - Fetch pending treasury executions that need signatures
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { DAOService } from '@/lib/services/dao';
import { treasuryExecutionAdminRepository } from '@/lib/data/repositories/supabase/treasury-execution.repository';
import { treasuryExecutionSignatureAdminRepository } from '@/lib/data/repositories/supabase/treasury-execution.repository';
import { daoMemberAdminRepository } from '@/lib/data/repositories';
import { safeService } from '@/lib/services/safe.service';
import { getInternalUserId } from '../../../../_lib/get-internal-user';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    // Validate DAO exists and user is a member
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success || !daoResult.data) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    const dao = daoResult.data;

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if user is a member
    const membershipResult = await daoService.getMembership(
      daoId,
      internalUserId
    );
    if (!membershipResult.success || !membershipResult.data) {
      return NextResponse.json(
        { success: false, error: 'Access denied - not a DAO member' },
        { status: 403 }
      );
    }

    // Check if treasury is configured
    if (!dao.safeAddress) {
      return NextResponse.json({
        success: true,
        data: {
          executions: [],
          isOwner: false,
        },
      });
    }

    // Check if user is a Safe owner
    const isOwner = authContext.primaryWallet
      ? await safeService.isOwner(dao.safeAddress, authContext.primaryWallet)
      : false;

    // Get pending executions for this DAO
    const pendingExecutions =
      await treasuryExecutionAdminRepository.findPendingByDao(daoId);

    // For each execution, get signature info
    const executionsWithSignatures = await Promise.all(
      pendingExecutions.map(async (execution) => {
        const signatures =
          await treasuryExecutionSignatureAdminRepository.findByExecutionId(
            execution.id
          );

        const currentSignatures = signatures.length;
        const hasUserSigned = signatures.some(
          (sig) => sig.signerId === internalUserId
        );

        // Get proposal info if available
        const proposalSnapshot = execution.proposalSnapshot;

        return {
          executionId: execution.id,
          proposalId: execution.proposalId,
          amount: execution.amount,
          recipient: execution.recipient,
          currency: execution.currency,
          requiredSignatures: execution.requiredSignatures,
          currentSignatures,
          hasUserSigned,
          safeTransactionHash: execution.safeTransactionHash,
          status: execution.status,
          proposalTitle: proposalSnapshot?.title || 'Treasury Transaction',
          createdAt: execution.createdAt.toISOString(),
        };
      })
    );

    return NextResponse.json({
      success: true,
      data: {
        executions: executionsWithSignatures,
        isOwner,
      },
    });
  } catch (error) {
    logger.error(
      '[Mobile Treasury Pending API] Error fetching pending executions',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch pending executions' },
      { status: 500 }
    );
  }
}
