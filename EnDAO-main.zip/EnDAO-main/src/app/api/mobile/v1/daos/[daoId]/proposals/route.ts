/**
 * Mobile DAO Proposals API Route
 *
 * GET - Fetch proposals for a DAO
 */

import { NextRequest, NextResponse } from 'next/server';
import { proposalAdminRepository } from '@/lib/data/repositories';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import type { ProposalStatus } from '@/lib/data/repositories/supabase/proposal.repository';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ daoId: string }> }
) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { daoId } = await params;

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'DAO ID required' },
        { status: 400 }
      );
    }

    const { searchParams } = new URL(request.url);
    const statusParam = searchParams.get('status');
    const status = statusParam as ProposalStatus | undefined;

    const proposals = await proposalAdminRepository.findByDaoWithCreator(
      daoId,
      status
    );

    // Map to mobile-friendly format
    const mappedProposals = proposals.map((proposal) => ({
      id: proposal.id,
      title: proposal.title,
      description: proposal.description,
      status: proposal.status,
      votingStartTime: proposal.votingStartTime,
      votingEndTime: proposal.votingEndTime,
      creatorId: proposal.createdBy,
      votingType: proposal.votingConfig?.system,
      results: proposal.result,
    }));

    return NextResponse.json({
      success: true,
      data: mappedProposals,
    });
  } catch (error) {
    logger.error(
      '[Mobile DAO Proposals API] Error fetching proposals',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch proposals' },
      { status: 500 }
    );
  }
}
