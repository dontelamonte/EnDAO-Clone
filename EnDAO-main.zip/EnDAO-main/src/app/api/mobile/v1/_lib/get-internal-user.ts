/**
 * Mobile API Helper - Get Internal User
 *
 * Looks up the internal user by Privy ID from the auth context.
 * Mobile auth passes Privy DID as uid, but service layer expects internal UUID.
 */

import { AuthContext } from '@/lib/auth/get-auth-context';
import { userAdminRepository } from '@/lib/data/repositories';

interface InternalUser {
  id: string;
  username?: string;
  displayName?: string;
  email?: string;
}

/**
 * Get the internal user from auth context
 * @param authContext - Auth context from getAuthContext()
 * @returns Internal user or null if not found
 */
export async function getInternalUser(
  authContext: AuthContext
): Promise<InternalUser | null> {
  try {
    const user = await userAdminRepository.findByPrivyId(
      authContext.privyUserId
    );
    if (!user) return null;

    // Map to InternalUser interface
    return {
      id: user.id,
      username: user.username ?? undefined,
      displayName: user.displayName ?? undefined,
      email: user.email ?? undefined,
    };
  } catch (error) {
    console.error('Failed to get internal user:', error);
    return null;
  }
}

/**
 * Get the internal user ID from auth context
 * Convenience wrapper that just returns the ID
 */
export async function getInternalUserId(
  authContext: AuthContext
): Promise<string | null> {
  const user = await getInternalUser(authContext);
  return user?.id ?? null;
}
