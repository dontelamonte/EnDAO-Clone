/**
 * Mobile Device Registration API
 *
 * POST /api/mobile/v1/devices - Register a device for push notifications
 * GET /api/mobile/v1/devices - Get user's registered devices
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { deviceService } from '@/lib/services/mobile/device.service';
import { logger } from '@/lib/services/logger.service';
import { getInternalUserId } from '../_lib/get-internal-user';

export async function POST(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { pushToken, platform, deviceName, appVersion } = body;

    if (!pushToken) {
      return NextResponse.json(
        { error: 'pushToken is required' },
        { status: 400 }
      );
    }

    if (!platform || !['ios', 'android'].includes(platform)) {
      return NextResponse.json(
        { error: 'platform must be ios or android' },
        { status: 400 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const result = await deviceService.registerDevice(internalUserId, {
      pushToken,
      platform,
      deviceName,
      appVersion,
    });

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      deviceId: result.data?.id,
      data: result.data,
    });
  } catch (error) {
    logger.error('[POST /api/mobile/v1/devices] Error', error as Error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const result = await deviceService.getUserDevices(internalUserId);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    logger.error('[GET /api/mobile/v1/devices] Error', error as Error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
