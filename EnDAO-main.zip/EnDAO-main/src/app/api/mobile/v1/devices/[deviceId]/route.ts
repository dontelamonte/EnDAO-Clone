/**
 * Mobile Device Management API
 *
 * DELETE /api/mobile/v1/devices/[deviceId] - Unregister a device
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { deviceService } from '@/lib/services/mobile/device.service';
import { logger } from '@/lib/services/logger.service';
import { getInternalUserId } from '../../_lib/get-internal-user';

interface RouteParams {
  params: Promise<{ deviceId: string }>;
}

export async function DELETE(request: NextRequest, { params }: RouteParams) {
  try {
    const authContext = await getAuthContext(request);

    if (!authContext) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { deviceId } = await params;

    if (!deviceId) {
      return NextResponse.json(
        { error: 'deviceId is required' },
        { status: 400 }
      );
    }

    // Get internal user ID from Privy ID
    const internalUserId = await getInternalUserId(authContext);
    if (!internalUserId) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const result = await deviceService.unregisterDevice(
      internalUserId,
      deviceId
    );

    if (!result.success) {
      // Determine appropriate status code from error message
      const status = result.error?.includes('not found')
        ? 404
        : result.error?.includes('Unauthorized')
          ? 403
          : 500;

      return NextResponse.json(
        { error: result.error },
        { status }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Device unregistered successfully',
    });
  } catch (error) {
    logger.error(
      '[DELETE /api/mobile/v1/devices/[deviceId]] Error',
      error as Error
    );
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
