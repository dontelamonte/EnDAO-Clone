/**
 * Contact Form Submission API
 * Public endpoint for lead capture from contact page
 * Rate limited to prevent spam
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { rateLimiters } from '@/lib/middleware/rate-limit';
import { logger } from '@/lib/services/logger.service';
import { emailDeliveryService } from '@/lib/services/email/email-delivery.service';

// Validation schema
const contactSchema = z.object({
  name: z.string().min(1, 'Name is required').max(100),
  email: z.string().email('Valid email is required').max(255),
  phone: z.string().max(30).optional().nullable(),
  message: z.string().min(10, 'Message must be at least 10 characters').max(5000),
  preferCall: z.boolean().optional().default(false),
  source: z.string().max(50).optional().default('contact_page'),
});

export async function POST(request: NextRequest): Promise<NextResponse> {
  // Rate limit: 5 submissions per minute per IP to prevent spam
  const rateLimitResult = await rateLimiters.api(request);
  if (rateLimitResult) return rateLimitResult;

  try {
    const body = await request.json();

    // Validate input
    const parsed = contactSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error: 'Invalid form data',
          details: parsed.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { name, email, phone, message, preferCall, source } = parsed.data;

    // Insert into database
    const supabase = getSupabaseAdmin();
    const { data, error } = await supabase
      .from('contact_submissions')
      .insert({
        name,
        email,
        phone: phone || null,
        message,
        prefer_call: preferCall,
        source,
        status: 'new',
      })
      .select('id')
      .single();

    if (error) {
      logger.error('Failed to save contact submission', error, {
        email,
        source,
      });
      return NextResponse.json(
        { error: 'Failed to submit form. Please try again.' },
        { status: 500 }
      );
    }

    logger.info('Contact form submission received', {
      id: data.id,
      email,
      source,
    });

    // Send notification email to team
    const notificationEmail = process.env.CONTACT_NOTIFICATION_EMAIL || 'justin@endao.ai';
    await emailDeliveryService.sendEmail({
      to: notificationEmail,
      subject: `New Contact Form Submission from ${name}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
        ${phone ? `<p><strong>Phone:</strong> ${phone}${preferCall ? ' <span style="background: #22c55e; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px;">PREFERS CALL</span>' : ''}</p>` : ''}
        <p><strong>Message:</strong></p>
        <blockquote style="border-left: 3px solid #ccc; padding-left: 12px; margin: 12px 0;">
          ${message.replace(/\n/g, '<br>')}
        </blockquote>
        <hr>
        <p style="color: #666; font-size: 12px;">
          Submitted via ${source} on ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })} ET
        </p>
      `,
      text: `New Contact Form Submission\n\nName: ${name}\nEmail: ${email}\n${phone ? `Phone: ${phone}${preferCall ? ' [PREFERS CALL]' : ''}\n` : ''}\nMessage:\n${message}`,
      replyTo: email,
    });

    return NextResponse.json({
      success: true,
      message: 'Thank you for your message. We will be in touch soon.',
    });
  } catch (error) {
    logger.error(
      'Contact form error',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/contact', method: 'POST' }
    );

    return NextResponse.json(
      { error: 'An unexpected error occurred. Please try again.' },
      { status: 500 }
    );
  }
}
