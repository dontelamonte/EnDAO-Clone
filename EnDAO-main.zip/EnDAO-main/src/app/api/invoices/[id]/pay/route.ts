/**
 * API Route: Pay Invoice
 *
 * POST /api/invoices/[id]/pay - Mark invoice as paid
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { invoiceService } from '@/lib/services/invoice';
import { validateCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';

// Validation schema
const payInvoiceSchema = z.object({
  paymentReference: z.string().min(1),
  paymentMethod: z.string().min(1),
  paidAmount: z.number().positive().optional(),
});

/**
 * POST /api/invoices/[id]/pay
 * Mark invoice as paid
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: invoiceId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const validation = payInvoiceSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const { paymentReference, paymentMethod, paidAmount } = validation.data;

    const result = await invoiceService.markAsPaid(
      invoiceId,
      paymentReference,
      paymentMethod,
      paidAmount
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true, data: result.data });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to mark invoice as paid', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
