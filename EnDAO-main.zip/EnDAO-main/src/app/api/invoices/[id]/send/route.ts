/**
 * API Route: Send Invoice
 *
 * POST /api/invoices/[id]/send - Send a draft invoice to recipient
 */

import { NextRequest, NextResponse } from 'next/server';
import { invoiceService } from '@/lib/services/invoice';
import { validateCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';

/**
 * POST /api/invoices/[id]/send
 * Send a draft invoice
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: invoiceId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    const result = await invoiceService.sendInvoice(invoiceId, userId);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true, data: result.data });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to send invoice', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
