/**
 * API Routes: Individual Invoice
 *
 * GET   /api/invoices/[id] - Get invoice details
 * PATCH /api/invoices/[id] - Update invoice (draft only)
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { invoiceService } from '@/lib/services/invoice';
import { validateCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';

// Validation schema for updating invoice
const updateInvoiceSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  description: z.string().max(2000).optional(),
  lineItems: z
    .array(
      z.object({
        description: z.string().min(1),
        quantity: z.number().positive(),
        unit: z.enum(['hours', 'days', 'units', 'flat']),
        rate: z.number().nonnegative(),
      })
    )
    .min(1)
    .optional(),
  taxAmount: z.number().nonnegative().optional(),
  dueDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional(),
  notes: z.string().max(2000).optional(),
  terms: z.string().max(2000).optional(),
});

/**
 * GET /api/invoices/[id]
 * Get invoice details
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: invoiceId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const result = await invoiceService.getInvoice(invoiceId);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error, code: result.code },
        { status: 404 }
      );
    }

    if (!result.data) {
      return NextResponse.json(
        { success: false, error: 'Invoice not found', code: 'NOT_FOUND' },
        { status: 404 }
      );
    }

    // Mark as viewed if recipient is viewing
    const invoice = result.data;
    if (
      invoice.status === 'sent' &&
      (invoice.recipientUserId === userId || invoice.recipientDaoId === userId)
    ) {
      await invoiceService.markViewed(invoiceId);
    }

    return NextResponse.json({ success: true, data: invoice });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to get invoice', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/invoices/[id]
 * Update invoice (draft only)
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: invoiceId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const validation = updateInvoiceSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    const result = await invoiceService.updateInvoice(
      invoiceId,
      validation.data as any,
      userId
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true, data: result.data });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to update invoice', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/invoices/[id]
 * Cancel invoice
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: invoiceId } = await params;
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    const result = await invoiceService.cancelInvoice(invoiceId, userId);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true, data: result.data });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to cancel invoice', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
