/**
 * API Routes: Invoices
 *
 * GET  /api/invoices - List user's invoices
 * POST /api/invoices - Create a new invoice
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { invoiceService } from '@/lib/services/invoice';
import { validateCSRFToken } from '@/lib/security/csrf';
import { logger } from '@/lib/services/logger.service';
import type { InvoiceFilters, InvoiceStatus } from '@endao/shared-types';

// Validation schema for creating invoice
const createInvoiceSchema = z.object({
  recipientType: z.enum(['user', 'dao', 'external']),
  recipientUserId: z.string().uuid().optional(),
  recipientDaoId: z.string().uuid().optional(),
  recipientEmail: z.string().email().optional(),
  recipientName: z.string().optional(),
  title: z.string().min(1).max(200),
  description: z.string().max(2000).optional(),
  lineItems: z
    .array(
      z.object({
        description: z.string().min(1),
        quantity: z.number().positive(),
        unit: z.enum(['hours', 'days', 'units', 'flat']),
        rate: z.number().nonnegative(),
      })
    )
    .min(1),
  taxAmount: z.number().nonnegative().optional(),
  currency: z.string().min(1).default('USD'),
  dueDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional(),
  notes: z.string().max(2000).optional(),
  terms: z.string().max(2000).optional(),
  paymentTerms: z
    .enum(['due_on_receipt', 'net_15', 'net_30', 'net_45', 'net_60'])
    .optional(),
});

/**
 * GET /api/invoices
 * List user's invoices (as issuer or recipient)
 */
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse query params
    const { searchParams } = new URL(request.url);
    const role = (searchParams.get('role') || 'issuer') as
      | 'issuer'
      | 'recipient';
    const status = searchParams.get('status') as InvoiceStatus | null;
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const filters: InvoiceFilters = {};
    if (status) filters.status = status;

    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');
    if (dateFrom) filters.dateFrom = dateFrom;
    if (dateTo) filters.dateTo = dateTo;

    const result = await invoiceService.getUserInvoices(
      userId,
      role,
      filters,
      limit,
      offset
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to list invoices', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

/**
 * POST /api/invoices
 * Create a new invoice
 */
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get('x-auth-uid');

    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Validate CSRF token
    const csrfResult = await validateCSRFToken(request);
    if (!csrfResult.valid) {
      return NextResponse.json(
        { error: csrfResult.error || 'Invalid CSRF token' },
        { status: 403 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const validation = createInvoiceSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        {
          success: false,
          error: 'Validation failed',
          details: validation.error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    // Must have at least one recipient identifier
    const { recipientUserId, recipientDaoId, recipientEmail, recipientName } =
      validation.data;
    if (
      !recipientUserId &&
      !recipientDaoId &&
      !recipientEmail &&
      !recipientName
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            'At least one recipient identifier required (userId, daoId, email, or name)',
        },
        { status: 400 }
      );
    }

    const result = await invoiceService.createInvoice(
      {
        ...validation.data,
        dueDate: validation.data.dueDate || new Date().toISOString().split('T')[0],
      } as any,
      userId,
      'user'
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: true, data: result.data },
      { status: 201 }
    );
  } catch (error) {
    const err = error instanceof Error ? error : new Error('Unknown error');
    logger.error('Failed to create invoice', err);

    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
