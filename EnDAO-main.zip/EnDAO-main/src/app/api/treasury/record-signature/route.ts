import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { signatureTrackingService } from '@/lib/services/treasury/treasury-signature.service';
import { logger } from '@/lib/services/logger.service';
import { z } from 'zod';

/**
 * POST /api/treasury/record-signature
 *
 * Records a signature in the database after a user has signed a Safe transaction.
 * This is called AFTER the wallet signing has completed successfully.
 *
 * Request Body:
 * - proposalId: ID of the treasury proposal
 * - safeTxHash: Safe transaction hash (for verification/logging)
 *
 * Returns:
 * - success: boolean
 *
 * Security:
 * - Requires authentication
 * - Uses authenticated user ID from context
 * - CSRF protected (POST request)
 * - Records audit trail with user ID
 */

// Validation schema
const recordSignatureSchema = z.object({
  proposalId: z.string().min(1, 'Proposal ID is required'),
  safeTxHash: z
    .string()
    .regex(/^0x[a-fA-F0-9]{64}$/, 'Invalid Safe transaction hash format'),
});

export async function POST(request: NextRequest) {
  try {
    // Authenticate user
    const auth = await getAuthContext(request);

    if (!auth?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = recordSignatureSchema.safeParse(body);

    if (!validation.success) {
      const errors = validation.error.errors.map((e) => e.message).join(', ');
      return NextResponse.json(
        { error: `Validation failed: ${errors}` },
        { status: 400 }
      );
    }

    const { proposalId, safeTxHash } = validation.data;

    logger.info('Recording signature', {
      proposalId,
      safeTxHash,
      userId: auth.uid,
    });

    // Record signature in database
    // Note: The service uses the authenticated user ID from the request context
    const result = await signatureTrackingService.recordSignature(
      proposalId,
      auth.uid
    );

    if (!result.success) {
      logger.error(
        'Failed to record signature',
        new Error(result.error || 'Unknown error'),
        { proposalId, userId: auth.uid }
      );

      return NextResponse.json(
        { error: result.error || 'Failed to record signature' },
        { status: 500 }
      );
    }

    logger.info('Signature recorded successfully', {
      proposalId,
      safeTxHash,
      userId: auth.uid,
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    // Handle JSON parse errors
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      );
    }

    logger.error(
      'Error recording signature',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/record-signature', method: 'POST' }
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Failed to record signature',
      },
      { status: 500 }
    );
  }
}
