import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { safeTreasuryService } from '@/lib/services/safe-treasury';
import { biconomyMEE7579Service } from '@/lib/services/biconomy-mee-7579.service';
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';
import {
  proposalAdminRepository,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

// Schema for treasury execution request validation
// Supports two modes: proposal-based or direct execution
const treasuryExecuteSchema = z
  .object({
    // Proposal-based execution
    proposalId: z.string().uuid().optional(),

    // Direct execution fields
    safeTxHash: z
      .string()
      .regex(/^0x[a-fA-F0-9]{64}$/, 'Invalid Safe transaction hash format')
      .optional(),
    safeAddress: z
      .string()
      .regex(/^0x[a-fA-F0-9]{40}$/, 'Invalid Ethereum address format')
      .optional(),
    // Signatures are hex strings - the concatenated signature data from Safe signers
    signatures: z
      .array(
        z.string().regex(/^0x[a-fA-F0-9]+$/, 'Invalid signature hex format')
      )
      .max(20)
      .optional(), // Safe supports up to 20 signers

    // Execution mode
    useGasless: z.boolean().default(true),
  })
  .refine(
    (data) =>
      data.proposalId ||
      (data.safeTxHash && data.safeAddress && data.signatures),
    {
      message:
        'Either proposalId or (safeTxHash, safeAddress, signatures) is required',
    }
  );

export async function POST(request: NextRequest) {
  try {
    // The middleware has already verified the token, so we can get auth from request headers
    const uid = request.headers.get('x-auth-uid');
    const privyUserId = request.headers.get('x-auth-privy-id');

    if (!uid || !privyUserId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const auth = { uid, privyUserId };

    // Parse and validate request body with schema
    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      );
    }

    const parseResult = treasuryExecuteSchema.safeParse(body);
    if (!parseResult.success) {
      return NextResponse.json(
        {
          error: 'Invalid request format',
          details: parseResult.error.errors.map((e) => ({
            field: e.path.join('.'),
            message: e.message,
          })),
        },
        { status: 400 }
      );
    }

    const { proposalId, safeTxHash, safeAddress, signatures, useGasless } =
      parseResult.data;

    // SECURITY: Always validate treasury access for ALL execution paths
    let daoId: string;

    if (proposalId) {
      // Get daoId from proposal
      const proposal = await proposalAdminRepository.findById(proposalId);

      if (!proposal) {
        return NextResponse.json(
          { error: 'Proposal not found' },
          { status: 404 }
        );
      }

      daoId = proposal.daoId;
    } else {
      // For direct execution, lookup DAO by Safe address
      // This ensures we can validate authorization even without a proposalId
      // Note: Filter uses 'treasuryAddress' because toSnakeCase converts it to 'treasury_address' (the DB column)
      const dao = await daoAdminRepository.findOne({
        filters: [
          { field: 'treasuryAddress', operator: '==', value: safeAddress },
        ],
        limit: 1,
      });

      if (!dao) {
        return NextResponse.json(
          {
            error:
              'DAO not found for Safe address. Direct execution requires a registered DAO treasury.',
          },
          { status: 404 }
        );
      }

      daoId = dao.id;
    }

    // Validate treasury access before execution (REQUIRED for all paths)
    const validation =
      await treasuryAccessControlService.validateTreasuryOperation(
        daoId,
        uid,
        'execute_transaction',
        auth
      );

    if (!validation.success) {
      return NextResponse.json(
        {
          error: validation.error || 'Treasury access validation failed',
          code: validation.code,
        },
        { status: 403 }
      );
    }

    if (!validation.data.isValid) {
      const errors = validation.data.errors || ['Access denied'];
      const status = validation.data.accessStatus;

      let errorMessage = 'Treasury access denied';
      let statusCode = 403;

      if (status?.reason === 'dao_not_found') {
        errorMessage = 'DAO not found';
        statusCode = 404;
      } else if (status?.reason === 'treasury_frozen') {
        errorMessage = `Treasury is frozen: ${status.details}`;
      } else if (status?.details) {
        errorMessage = status.details;
      }

      return NextResponse.json(
        {
          error: errorMessage,
          reason: status?.reason,
          details: errors.join(', '),
        },
        { status: statusCode }
      );
    }

    let txHash: string;
    let executionMethod = 'traditional';

    // Check if gasless execution is requested and available
    if (useGasless && safeAddress) {
      try {
        // Check MEE compatibility first
        const isCompatible =
          await biconomyMEE7579Service.isMEECompatible(safeAddress);

        if (isCompatible) {
          // Get proposal details for gasless execution
          let proposalData: {
            recipient?: string;
            amount?: string;
            daoId?: string;
            to?: string;
            value?: string;
          };
          if (proposalId) {
            // Fetch proposal to get execution details
            const proposal = await proposalAdminRepository.findById(proposalId);
            if (!proposal) {
              throw new Error('Proposal not found');
            }
            proposalData = {
              recipient: proposal.metadata?.treasuryRecipient || '',
              amount: String(proposal.metadata?.treasuryAmount || '0'),
              daoId: proposal.daoId || '',
            };
          } else {
            // For direct execution without proposal, use Safe address as fallback
            // The actual transaction details are encoded in the safeTxHash
            proposalData = {
              recipient:
                safeAddress || '0x0000000000000000000000000000000000000000',
              amount: '0',
            };
          }

          // Execute via MEE + Safe7579
          const result =
            await biconomyMEE7579Service.executeTreasuryTransactionWithSafe7579(
              {
                safeAddress,
                to: proposalData.recipient || proposalData.to || '',
                value: proposalData.amount || proposalData.value || '0',
                daoId: proposalData.daoId || 'unknown',
                proposalId: proposalId || 'direct-execution',
                executionId: `exec-${Date.now()}`,
                useERC7579: true,
              }
            );

          if (result.success && result.txHash) {
            txHash = result.txHash;
            executionMethod = 'gasless_mee_safe7579';
          } else {
            throw new Error(result.error || 'Gasless execution failed');
          }
        } else {
          throw new Error('Safe not compatible with gasless execution');
        }
      } catch (_gaslessError) {
        // Fallback to traditional execution
        if (proposalId) {
          txHash = await safeTreasuryService.executeProposalTransaction(
            proposalId,
            uid,
            auth
          );
        } else {
          // Schema refine guarantees these exist when no proposalId
          const result = await safeTreasuryService.executeTransactionDirect(
            safeTxHash!,
            safeAddress!,
            signatures!
          );
          if (!result.success || !result.txHash) {
            throw new Error(result.error || 'Direct execution failed');
          }
          txHash = result.txHash;
        }
        executionMethod = 'traditional_fallback';
      }
    } else {
      // Traditional execution path
      if (proposalId) {
        txHash = await safeTreasuryService.executeProposalTransaction(
          proposalId,
          uid,
          auth
        );
      } else {
        // Schema refine guarantees these exist when no proposalId
        const result = await safeTreasuryService.executeTransactionDirect(
          safeTxHash!,
          safeAddress!,
          signatures!
        );
        if (!result.success || !result.txHash) {
          throw new Error(result.error || 'Direct execution failed');
        }
        txHash = result.txHash;
      }
    }

    return NextResponse.json({
      success: true,
      txHash,
      executionMethod,
      gasless: executionMethod.includes('gasless'),
      message: executionMethod.includes('gasless')
        ? '🎉 Treasury transaction executed gaslessly! No gas fees charged to user.'
        : 'Treasury transaction executed successfully',
    });
  } catch (error) {
    logger.error(
      'Failed to execute treasury transaction',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/execute', method: 'POST' }
    );
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : 'Failed to execute transaction',
      },
      { status: 500 }
    );
  }
}
