import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { safeTreasuryService } from '@/lib/services/safe-treasury';
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';
import { logger } from '@/lib/services/logger.service';

export async function GET(request: NextRequest) {
  try {
    const auth = await getAuthContext(request);
    if (!auth || !auth.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const daoId = searchParams.get('daoId');

    if (!daoId) {
      return NextResponse.json(
        { error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Validate treasury access
    const validation =
      await treasuryAccessControlService.validateTreasuryOperation(
        daoId,
        auth.uid,
        'view_history',
        auth
      );

    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error || 'Treasury access validation failed' },
        { status: 403 }
      );
    }

    if (!validation.data?.isValid) {
      const status = validation.data.accessStatus;

      let errorMessage = 'Treasury access denied';
      let statusCode = 403;

      if (status?.reason === 'dao_not_found') {
        errorMessage = 'DAO not found';
        statusCode = 404;
      } else if (status?.reason === 'treasury_frozen') {
        errorMessage = `Treasury is frozen: ${status.details}`;
      } else if (status?.details) {
        errorMessage = status.details;
      }

      return NextResponse.json(
        { error: errorMessage, reason: status?.reason },
        { status: statusCode }
      );
    }

    // Get transaction history from Safe
    const transactions = await safeTreasuryService.getTransactionHistory(
      daoId,
      auth.uid,
      auth
    );

    return NextResponse.json({
      success: true,
      transactions,
    });
  } catch (error) {
    logger.error(
      'Failed to get transaction history',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/transactions', method: 'GET' }
    );
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Failed to get transactions',
      },
      { status: 500 }
    );
  }
}
