/**
 * Treasury Execution State API Route
 *
 * Server-side endpoint for fetching treasury execution state by proposal ID.
 * Maps Privy ID to Supabase UUID before querying.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  treasuryExecutionAdminRepository,
  treasuryExecutionSignatureAdminRepository,
  userAdminRepository,
  proposalAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

interface ExecutionSignature {
  signerId: string;
  signerName?: string;
  signature: string;
  signedAt: string;
}

interface TreasuryExecutionState {
  id: string;
  proposalId: string;
  daoId: string;
  safeTransactionHash?: string;
  safeAddress?: string;
  status:
    | 'pending_signatures'
    | 'ready_to_execute'
    | 'executing'
    | 'executed'
    | 'failed'
    | 'cancelled';
  amount?: string;
  recipient?: string;
  currency?: string;
  proposalSnapshot?: Record<string, unknown>;
  signatures: ExecutionSignature[];
  requiredSignatures: number;
  initiatedBy?: string;
  executedBy?: string;
  cancelledBy?: string;
  createdAt: string;
  updatedAt: string;
  executedAt?: string;
  cancelledAt?: string;
  executingStartedAt?: string;
  executingBy?: string;
  blockchainTxHash?: string;
  safeTxHash?: string;
  cancellationReason?: string;
  errorMessage?: string;
  retryCount?: number;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Verify proposal exists
    const proposal = await proposalAdminRepository.findById(proposalId);
    if (!proposal) {
      return NextResponse.json(
        { success: false, error: 'Proposal not found' },
        { status: 404 }
      );
    }

    // Get execution state
    const execution =
      await treasuryExecutionAdminRepository.findByProposalId(proposalId);

    if (!execution) {
      return NextResponse.json({
        success: true,
        data: null,
      });
    }

    // Get signatures
    let signatures: ExecutionSignature[] = [];
    try {
      const repoSignatures =
        await treasuryExecutionSignatureAdminRepository.findByExecutionId(
          execution.id
        );
      signatures = repoSignatures.map((sig) => ({
        signerId: sig.signerId,
        signerName: undefined,
        signature: sig.signature,
        signedAt:
          sig.signedAt instanceof Date
            ? sig.signedAt.toISOString()
            : String(sig.signedAt),
      }));
    } catch (err) {
      // Signatures might not exist yet
      logger.warn('Failed to load signatures', { executionId: execution.id });
    }

    const executionState: TreasuryExecutionState = {
      id: execution.id,
      proposalId: execution.proposalId,
      daoId: execution.daoId,
      safeTransactionHash: execution.safeTransactionHash,
      safeAddress: execution.safeAddress,
      status: execution.status as TreasuryExecutionState['status'],
      amount: execution.amount,
      recipient: execution.recipient,
      currency: execution.currency,
      proposalSnapshot: execution.proposalSnapshot as unknown as Record<
        string,
        unknown
      >,
      signatures,
      requiredSignatures: execution.requiredSignatures,
      initiatedBy: execution.initiatedBy,
      executedBy: execution.executedBy ?? undefined,
      cancelledBy: execution.cancelledBy ?? undefined,
      createdAt:
        execution.createdAt instanceof Date
          ? execution.createdAt.toISOString()
          : String(execution.createdAt),
      updatedAt:
        execution.updatedAt instanceof Date
          ? execution.updatedAt.toISOString()
          : String(execution.updatedAt),
      executedAt: execution.executedAt
        ? execution.executedAt instanceof Date
          ? execution.executedAt.toISOString()
          : String(execution.executedAt)
        : undefined,
      cancelledAt: execution.cancelledAt
        ? execution.cancelledAt instanceof Date
          ? execution.cancelledAt.toISOString()
          : String(execution.cancelledAt)
        : undefined,
      executingStartedAt: execution.executingStartedAt
        ? execution.executingStartedAt instanceof Date
          ? execution.executingStartedAt.toISOString()
          : String(execution.executingStartedAt)
        : undefined,
      executingBy: execution.executingBy ?? undefined,
      blockchainTxHash: execution.blockchainTxHash ?? undefined,
      safeTxHash: execution.safeTransactionHash,
      cancellationReason: execution.cancellationReason ?? undefined,
      errorMessage: execution.errorMessage ?? undefined,
      retryCount: execution.retryCount,
    };

    return NextResponse.json({
      success: true,
      data: executionState,
    });
  } catch (error) {
    logger.error(
      '[Treasury Execution API] Error fetching execution state',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch execution state' },
      { status: 500 }
    );
  }
}
