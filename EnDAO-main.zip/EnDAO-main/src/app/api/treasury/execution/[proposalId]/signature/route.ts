/**
 * Treasury Execution Signature API Route
 *
 * POST - Record a client-side signature for a treasury execution
 * Browser-safe wrapper around treasurySignatureService.addSignature
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  treasuryExecutionAdminRepository,
  treasuryExecutionSignatureAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { treasurySignatureService } from '@/lib/services/treasury/treasury-signature.service';
import { logger } from '@/lib/services/logger.service';

interface SignatureResponse {
  success: boolean;
  data?: {
    message: string;
    signatureCount?: number;
    requiredSignatures?: number;
    isReadyToExecute?: boolean;
  };
  error?: string;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proposalId: string }> }
): Promise<NextResponse<SignatureResponse>> {
  try {
    // Get user auth from middleware headers
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');
    const uid = request.headers.get('x-auth-uid');

    if (!privyId || !uid) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { proposalId } = await params;

    if (!proposalId) {
      return NextResponse.json(
        { success: false, error: 'Proposal ID required' },
        { status: 400 }
      );
    }

    // Get request body
    const { signature } = await request.json();

    if (!signature) {
      return NextResponse.json(
        { success: false, error: 'Signature required' },
        { status: 400 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Get execution by proposal ID to verify it exists and get current state
    const execution =
      await treasuryExecutionAdminRepository.findByProposalId(proposalId);
    if (!execution) {
      return NextResponse.json(
        { success: false, error: 'Execution not found for proposal' },
        { status: 404 }
      );
    }

    const executionId = execution.id;

    // Verify execution is in a signable state
    if (
      execution.status !== 'pending_signatures' &&
      execution.status !== 'ready_to_execute'
    ) {
      return NextResponse.json(
        {
          success: false,
          error: `Cannot sign execution in status: ${execution.status}`,
        },
        { status: 400 }
      );
    }

    // Add signature using the signature service
    const result = await treasurySignatureService.addSignature(
      executionId,
      userId,
      signature,
      { uid, privyUserId: privyId }
    );

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.message || 'Failed to add signature' },
        { status: 400 }
      );
    }

    // Get updated execution state and signature count
    const [updatedExecution, signatures] = await Promise.all([
      treasuryExecutionAdminRepository.findById(executionId),
      treasuryExecutionSignatureAdminRepository.findByExecutionId(executionId),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        message: result.message,
        signatureCount: signatures.length,
        requiredSignatures: updatedExecution?.requiredSignatures,
        isReadyToExecute: updatedExecution?.status === 'ready_to_execute',
      },
    });
  } catch (error) {
    logger.error(
      '[Treasury Signature API] Error adding signature',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to add signature' },
      { status: 500 }
    );
  }
}
