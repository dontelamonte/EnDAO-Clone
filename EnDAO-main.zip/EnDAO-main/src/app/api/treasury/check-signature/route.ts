import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { safeSigningService } from '@/lib/services/treasury/safe-signing.service';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/treasury/check-signature
 *
 * Checks if a user has already signed a Safe transaction.
 *
 * Query Parameters:
 * - safeTxHash: Safe transaction hash to check
 * - userAddress: User's wallet address to verify
 *
 * Returns:
 * - hasSigned: boolean indicating if user has signed the transaction
 *
 * Security:
 * - Requires authentication
 * - Validates user owns the wallet address
 * - Uses Safe API to check signature status
 */
export async function GET(request: NextRequest) {
  try {
    // Authenticate user
    const auth = await getAuthContext(request);

    if (!auth?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get query parameters
    const { searchParams } = new URL(request.url);
    const safeTxHash = searchParams.get('safeTxHash');
    const userAddress = searchParams.get('userAddress');

    // Validate required parameters
    if (!safeTxHash) {
      return NextResponse.json(
        { error: 'Safe transaction hash is required' },
        { status: 400 }
      );
    }

    if (!userAddress) {
      return NextResponse.json(
        { error: 'User address is required' },
        { status: 400 }
      );
    }

    // Validate Safe transaction hash format (0x + 64 hex chars)
    const txHashRegex = /^0x[a-fA-F0-9]{64}$/;
    if (!txHashRegex.test(safeTxHash)) {
      return NextResponse.json(
        { error: 'Invalid Safe transaction hash format' },
        { status: 400 }
      );
    }

    // Validate Ethereum address format
    const addressRegex = /^0x[a-fA-F0-9]{40}$/;
    if (!addressRegex.test(userAddress)) {
      return NextResponse.json(
        { error: 'Invalid user address format' },
        { status: 400 }
      );
    }

    // Security: Verify the user owns this wallet address
    const userWallet = auth.primaryWallet?.toLowerCase();
    const requestedWallet = userAddress.toLowerCase();

    if (userWallet !== requestedWallet) {
      return NextResponse.json(
        { error: 'Cannot check signature status for wallet you do not own' },
        { status: 403 }
      );
    }

    logger.info('Checking signature status', {
      safeTxHash,
      userAddress,
      userId: auth.uid,
    });

    // Check if user has signed using Safe API
    const result = await safeSigningService.hasUserSigned(
      safeTxHash,
      userAddress
    );

    if (!result.success) {
      logger.error(
        'Failed to check signature status',
        new Error(result.error || 'Unknown error'),
        { safeTxHash, userAddress }
      );

      return NextResponse.json(
        { error: result.error || 'Failed to check signature status' },
        { status: 500 }
      );
    }

    const hasSigned = result.data || false;

    logger.info('Signature check complete', {
      safeTxHash,
      userAddress,
      hasSigned,
    });

    return NextResponse.json({
      hasSigned,
    });
  } catch (error) {
    logger.error(
      'Error checking signature status',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/check-signature', method: 'GET' }
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : 'Failed to check signature status',
      },
      { status: 500 }
    );
  }
}
