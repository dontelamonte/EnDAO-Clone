import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { DAOService } from '@/lib/services/dao';
import {
  daoAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { multiChainSafeService } from '@/lib/services/treasury/multichain-safe.service';
import { ethers } from 'ethers';
import { logger } from '@/lib/services/logger.service';

export async function POST(request: NextRequest) {
  try {
    const auth = await getAuthContext();
    if (!auth) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const {
      daoId,
      adminWallets: providedWallets,
      primaryChainId = 8453, // Default to Base
      additionalChainIds = [],
    } = await request.json();
    let adminWallets = providedWallets;

    if (!daoId) {
      return NextResponse.json(
        { error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Map Privy ID to Supabase user UUID
    const supabaseUser = await userAdminRepository.findByPrivyId(
      auth.privyUserId
    );
    if (!supabaseUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get DAO and verify user is admin
    const daoService = DAOService.getInstance();
    const daoResult = await daoService.getDAO(daoId);

    if (!daoResult.success || !daoResult.data) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    const membershipResult = await daoService.getMembership(
      daoId,
      supabaseUser.id
    );

    if (!membershipResult.success || membershipResult.data?.role !== 'admin') {
      return NextResponse.json(
        { error: 'Only admins can create treasury' },
        { status: 403 }
      );
    }

    // Get admin wallet addresses
    if (!adminWallets || adminWallets.length === 0) {
      // For testing: use the deployer wallet as the sole owner
      const testWallet = process.env.SAFE_DEPLOYER_PRIVATE_KEY
        ? new ethers.Wallet(process.env.SAFE_DEPLOYER_PRIVATE_KEY).address
        : null;

      if (!testWallet) {
        return NextResponse.json(
          { error: 'No admin wallets provided and no test wallet configured' },
          { status: 400 }
        );
      }

      adminWallets = [testWallet];
    }

    // Use simple majority threshold (half + 1)
    const threshold = Math.ceil(adminWallets.length / 2);

    // Deploy to primary chain (and optionally additional chains)
    const deployResult = await multiChainSafeService.deployMultiChain({
      daoId,
      owners: adminWallets,
      threshold,
      primaryChainId,
      additionalChainIds,
      deployedBy: supabaseUser.id,
    });

    if (!deployResult.success) {
      return NextResponse.json(
        {
          error: 'Failed to deploy Safe',
          deployments: deployResult.deployments,
        },
        { status: 500 }
      );
    }

    // Update DAO with primary Safe address
    await daoAdminRepository.update(daoId, {
      safeAddress: deployResult.safeAddress,
    });

    // Find primary deployment status
    const primaryDeployment = deployResult.deployments.find(
      (d) => d.chainId === primaryChainId
    );

    return NextResponse.json({
      success: true,
      safeAddress: deployResult.safeAddress,
      owners: adminWallets,
      threshold,
      saltNonce: deployResult.saltNonce,
      deployments: deployResult.deployments,
      primaryChain: {
        chainId: primaryChainId,
        isDeployed: primaryDeployment?.isDeployed ?? false,
      },
      message: primaryDeployment?.isDeployed
        ? 'Multi-chain Treasury Safe created and deployed successfully'
        : 'Multi-chain Treasury Safe configured (will deploy on first transaction)',
      version: '1.4.1+L2',
      multiChainEnabled: true,
    });
  } catch (error) {
    logger.error(
      'Failed to create Safe',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/v2/create-safe', method: 'POST' }
    );
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Failed to create treasury',
      },
      { status: 500 }
    );
  }
}

/**
 * GET: Fetch supported chains for treasury deployment
 */
export async function GET() {
  try {
    const chains = await multiChainSafeService.getSupportedChains();

    return NextResponse.json({
      success: true,
      chains: chains.map((chain) => ({
        chainId: chain.chainId,
        name: chain.name,
        shortName: chain.shortName,
        nativeCurrency: chain.nativeCurrency,
        blockExplorer: chain.blockExplorer,
        isTestnet: chain.isTestnet,
      })),
    });
  } catch (error) {
    logger.error(
      'Failed to fetch supported chains',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/v2/create-safe', method: 'GET' }
    );
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Failed to fetch chains',
      },
      { status: 500 }
    );
  }
}
