import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { signerNotificationService } from '@/lib/services/treasury/signer-notification.service';
import { MemberQueriesService } from '@/lib/services/dao/member-queries';
import { logger } from '@/lib/services/logger.service';
import { z } from 'zod';

/**
 * POST /api/treasury/send-reminders
 *
 * Sends reminder notifications to pending signers for a treasury proposal.
 * This is an admin/creator operation.
 *
 * Request Body:
 * - proposalId: ID of the treasury proposal
 * - daoId: ID of the DAO (for authorization check)
 *
 * Returns:
 * - remindersSent: number of reminders sent
 *
 * Security:
 * - Requires authentication
 * - Validates user is DAO admin or proposal creator
 * - CSRF protected (POST request)
 * - Rate limited (should not spam signers)
 */

// Validation schema
const sendRemindersSchema = z.object({
  proposalId: z.string().min(1, 'Proposal ID is required'),
  daoId: z.string().min(1, 'DAO ID is required'),
});

export async function POST(request: NextRequest) {
  try {
    // Authenticate user
    const auth = await getAuthContext(request);

    if (!auth?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Parse and validate request body
    const body = await request.json();
    const validation = sendRemindersSchema.safeParse(body);

    if (!validation.success) {
      const errors = validation.error.errors.map((e) => e.message).join(', ');
      return NextResponse.json(
        { error: `Validation failed: ${errors}` },
        { status: 400 }
      );
    }

    const { proposalId, daoId } = validation.data;

    // Verify user is admin of the DAO
    const memberQueriesService = MemberQueriesService.getInstance();
    const adminCheckResult = await memberQueriesService.isUserAdmin(
      daoId,
      auth.uid
    );

    if (!adminCheckResult.success || !adminCheckResult.data) {
      return NextResponse.json(
        { error: 'Only DAO admins can send signer reminders' },
        { status: 403 }
      );
    }

    logger.info('Sending signer reminders', {
      proposalId,
      daoId,
      userId: auth.uid,
    });

    // Send reminders via service
    const result =
      await signerNotificationService.sendSignerReminders(proposalId);

    if (!result.success) {
      logger.error(
        'Failed to send reminders',
        new Error(result.error || 'Unknown error'),
        { proposalId, daoId }
      );

      return NextResponse.json(
        { error: result.error || 'Failed to send reminders' },
        { status: 500 }
      );
    }

    const remindersSent = result.data?.remindersSent || 0;

    logger.info('Reminders sent successfully', {
      proposalId,
      daoId,
      remindersSent,
    });

    return NextResponse.json({
      success: true,
      remindersSent,
    });
  } catch (error) {
    // Handle JSON parse errors
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      );
    }

    logger.error(
      'Error sending reminders',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/send-reminders', method: 'POST' }
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Failed to send reminders',
      },
      { status: 500 }
    );
  }
}
