import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';
import { safeService } from '@/lib/services/safe.service';
import { cryptoPriceService } from '@/lib/services/crypto-price.service';
import { daoAdminRepository } from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export interface TokenBalance {
  symbol: string;
  name: string;
  balance: string;
  balanceNumber: number;
  usdValue: number;
  usdPrice: number;
  tokenAddress: string | null;
}

export interface TreasuryBalanceResponse {
  success: boolean;
  totalUsdValue: number;
  tokens: TokenBalance[];
  // Legacy field for backward compatibility
  balance: string;
  currency: string;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const daoId = searchParams.get('daoId');

    if (!daoId) {
      return NextResponse.json(
        { error: 'DAO ID is required' },
        { status: 400 }
      );
    }

    // Try to get auth context (may be null for public balance viewing)
    const auth = await getAuthContext(request);

    // If authenticated, validate treasury access
    if (auth?.uid) {
      const validation =
        await treasuryAccessControlService.validateTreasuryOperation(
          daoId,
          auth.uid,
          'view_balance',
          auth
        );

      if (!validation.success) {
        return NextResponse.json(
          { error: validation.error || 'Treasury access validation failed' },
          { status: 403 }
        );
      }

      if (!validation.data?.isValid) {
        const status = validation.data.accessStatus;

        let errorMessage = 'Treasury access denied';
        let statusCode = 403;

        if (status?.reason === 'dao_not_found') {
          errorMessage = 'DAO not found';
          statusCode = 404;
        } else if (status?.reason === 'treasury_frozen') {
          errorMessage = `Treasury is frozen: ${status.details}`;
        } else if (status?.details) {
          errorMessage = status.details;
        }

        return NextResponse.json(
          { error: errorMessage, reason: status?.reason },
          { status: statusCode }
        );
      }
    }
    // Note: If not authenticated, we still allow viewing balance (read-only public data)

    // Get DAO's Safe address using Supabase repository
    const dao = await daoAdminRepository.findById(daoId);

    if (!dao) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    if (!dao.safeAddress) {
      // No Safe deployed yet
      return NextResponse.json({
        success: true,
        totalUsdValue: 0,
        tokens: [],
        balance: '0',
        currency: 'ETH',
      } as TreasuryBalanceResponse);
    }

    // Get all token balances from Safe
    const rawBalances = await safeService.getAllBalances(dao.safeAddress);

    // Get USD prices for all tokens
    const symbols = rawBalances.map((b) => b.symbol);
    const prices = await cryptoPriceService.getPrices(symbols);

    // Calculate USD values
    const tokens: TokenBalance[] = rawBalances.map((token) => {
      const balanceNumber = parseFloat(token.balance) || 0;
      const usdPrice = prices[token.symbol] || 0;
      const usdValue = balanceNumber * usdPrice;

      return {
        symbol: token.symbol,
        name: token.name,
        balance: token.balance,
        balanceNumber,
        usdValue,
        usdPrice,
        tokenAddress: token.tokenAddress,
      };
    });

    // Sort by USD value (highest first)
    tokens.sort((a, b) => b.usdValue - a.usdValue);

    // Calculate total USD value
    const totalUsdValue = tokens.reduce((sum, t) => sum + t.usdValue, 0);

    // Find ETH balance for legacy field
    const ethToken = tokens.find((t) => t.symbol === 'ETH');

    return NextResponse.json({
      success: true,
      totalUsdValue,
      tokens,
      balance: ethToken?.balance || '0',
      currency: 'ETH',
    } as TreasuryBalanceResponse);
  } catch (error) {
    logger.error(
      'Failed to get Safe balance',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/balance', method: 'GET' }
    );
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Failed to get balance',
      },
      { status: 500 }
    );
  }
}
