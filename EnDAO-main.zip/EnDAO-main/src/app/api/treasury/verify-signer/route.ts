import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { safeSigningService } from '@/lib/services/treasury/safe-signing.service';
import { logger } from '@/lib/services/logger.service';

/**
 * GET /api/treasury/verify-signer
 *
 * Verifies if the authenticated user is a signer (owner) of a Gnosis Safe.
 *
 * Query Parameters:
 * - safeAddress: Gnosis Safe address to check
 * - userAddress: User's wallet address to verify
 *
 * Returns:
 * - isSigner: boolean indicating if user is a Safe owner
 *
 * Security:
 * - Requires authentication
 * - Validates user owns the wallet address
 * - Uses Safe API to verify ownership
 */
export async function GET(request: NextRequest) {
  try {
    // Authenticate user
    const auth = await getAuthContext(request);

    if (!auth?.uid) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Get query parameters
    const { searchParams } = new URL(request.url);
    const safeAddress = searchParams.get('safeAddress');
    const userAddress = searchParams.get('userAddress');

    // Validate required parameters
    if (!safeAddress) {
      return NextResponse.json(
        { error: 'Safe address is required' },
        { status: 400 }
      );
    }

    if (!userAddress) {
      return NextResponse.json(
        { error: 'User address is required' },
        { status: 400 }
      );
    }

    // Validate Ethereum address format
    const addressRegex = /^0x[a-fA-F0-9]{40}$/;
    if (!addressRegex.test(safeAddress)) {
      return NextResponse.json(
        { error: 'Invalid Safe address format' },
        { status: 400 }
      );
    }

    if (!addressRegex.test(userAddress)) {
      return NextResponse.json(
        { error: 'Invalid user address format' },
        { status: 400 }
      );
    }

    // Security: Verify the user owns this wallet address
    // This prevents checking arbitrary wallets
    const userWallet = auth.primaryWallet?.toLowerCase();
    const requestedWallet = userAddress.toLowerCase();

    if (userWallet !== requestedWallet) {
      return NextResponse.json(
        { error: 'Cannot verify signer status for wallet you do not own' },
        { status: 403 }
      );
    }

    logger.info('Verifying signer status', {
      safeAddress,
      userAddress,
      userId: auth.uid,
    });

    // Check if user is a signer using Safe API
    const result = await safeSigningService.isUserSigner(
      safeAddress,
      userAddress
    );

    if (!result.success) {
      logger.error(
        'Failed to verify signer status',
        new Error(result.error || 'Unknown error'),
        { safeAddress, userAddress }
      );

      return NextResponse.json(
        { error: result.error || 'Failed to verify signer status' },
        { status: 500 }
      );
    }

    const isSigner = result.data || false;

    logger.info('Signer verification complete', {
      safeAddress,
      userAddress,
      isSigner,
    });

    return NextResponse.json({
      isSigner,
    });
  } catch (error) {
    logger.error(
      'Error verifying signer status',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/verify-signer', method: 'GET' }
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : 'Failed to verify signer status',
      },
      { status: 500 }
    );
  }
}
