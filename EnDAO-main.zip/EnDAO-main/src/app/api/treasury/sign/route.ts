import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { safeTreasuryService } from '@/lib/services/safe-treasury';
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';
import {
  proposalAdminRepository,
  daoAdminRepository,
} from '@/lib/data/repositories';
import { safeService } from '@/lib/services/safe.service';
import { parseEther } from 'ethers';
import { AddressValidationService } from '@/lib/services/safe-treasury/address-validation.service';
import { logger } from '@/lib/services/logger.service';

export async function POST(request: NextRequest) {
  try {
    const auth = await getAuthContext();
    if (!auth) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { proposalId, walletProvider } = await request.json();

    if (!proposalId) {
      return NextResponse.json(
        { error: 'Proposal ID is required' },
        { status: 400 }
      );
    }

    // Get proposal to extract DAO ID for validation
    const proposal = await proposalAdminRepository.findById(proposalId);

    if (!proposal) {
      return NextResponse.json(
        { error: 'Proposal not found' },
        { status: 404 }
      );
    }

    const daoId = proposal.daoId;

    // Validate treasury access before signing
    const validation =
      await treasuryAccessControlService.validateTreasuryOperation(
        daoId,
        auth.uid,
        'sign_transaction',
        auth
      );

    if (!validation.success) {
      return NextResponse.json(
        {
          error: validation.error || 'Treasury access validation failed',
          code: validation.code,
        },
        { status: 403 }
      );
    }

    if (!validation.data.isValid) {
      const errors = validation.data.errors || ['Access denied'];
      const status = validation.data.accessStatus;

      let errorMessage = 'Treasury access denied';
      let statusCode = 403;

      if (status?.reason === 'dao_not_found') {
        errorMessage = 'DAO not found';
        statusCode = 404;
      } else if (status?.reason === 'treasury_frozen') {
        errorMessage = `Treasury is frozen: ${status.details}`;
      } else if (status?.details) {
        errorMessage = status.details;
      }

      return NextResponse.json(
        {
          error: errorMessage,
          reason: status?.reason,
          details: errors.join(', '),
        },
        { status: statusCode }
      );
    }

    // ✅ SECURITY: Verify transaction hash matches proposal parameters
    // This prevents signing a malicious transaction that was tampered with in the database
    const storedSafeTxHash = proposal.treasuryTransaction?.safeTxHash;

    if (!storedSafeTxHash) {
      return NextResponse.json(
        { error: 'No treasury transaction found for this proposal' },
        { status: 400 }
      );
    }

    // Get DAO Safe address to reconstruct the transaction
    const dao = await daoAdminRepository.findById(daoId);

    if (!dao) {
      return NextResponse.json({ error: 'DAO not found' }, { status: 404 });
    }

    if (!dao.safeAddress) {
      return NextResponse.json(
        { error: 'DAO does not have a treasury Safe' },
        { status: 400 }
      );
    }

    // Reconstruct expected transaction from proposal metadata
    const recipient = proposal.metadata?.treasuryRecipient;
    const amount = proposal.metadata?.treasuryAmount;

    if (!recipient || !amount) {
      return NextResponse.json(
        { error: 'Invalid proposal metadata - missing recipient or amount' },
        { status: 400 }
      );
    }

    // Checksum addresses for consistency
    const checksummedSafeAddress = AddressValidationService.safeChecksumAddress(
      dao.safeAddress,
      'Safe treasury'
    );
    const checksummedRecipient = AddressValidationService.safeChecksumAddress(
      recipient,
      'recipient'
    );

    // Convert amount to wei for comparison
    const valueWei = parseEther(amount.toString()).toString();

    // Reconstruct the expected transaction hash using Safe SDK
    const expectedTxResult = await safeService.createTransaction(
      checksummedSafeAddress,
      checksummedRecipient,
      valueWei
    );

    if (!expectedTxResult.success || !expectedTxResult.data) {
      return NextResponse.json(
        {
          error: 'Failed to verify transaction hash',
          details:
            expectedTxResult.error?.detail || 'Transaction verification failed',
        },
        { status: 500 }
      );
    }

    const expectedSafeTxHash = expectedTxResult.data.safeTxHash;

    // Compare stored hash with reconstructed hash
    if (storedSafeTxHash !== expectedSafeTxHash) {
      logger.error(
        'Transaction hash mismatch detected',
        new Error('Transaction hash verification failed - possible tampering'),
        {
          url: '/api/treasury/sign',
          method: 'POST',
          proposalId,
          storedHash: storedSafeTxHash,
          expectedHash: expectedSafeTxHash,
        }
      );

      return NextResponse.json(
        {
          error: 'Transaction hash verification failed',
          details:
            'The transaction parameters do not match the stored transaction. This could indicate tampering.',
        },
        { status: 400 }
      );
    }

    logger.info('Transaction hash verified successfully', {
      url: '/api/treasury/sign',
      method: 'POST',
      proposalId,
      safeTxHash: storedSafeTxHash,
    });

    // Sign the treasury transaction with user's Privy wallet
    // Note: In production, walletProvider would come from Privy
    await safeTreasuryService.signTransaction(
      proposalId,
      walletProvider,
      auth.uid,
      auth
    );

    return NextResponse.json({
      success: true,
      message: 'Transaction signed successfully',
    });
  } catch (error) {
    logger.error(
      'Failed to sign treasury transaction',
      error instanceof Error ? error : new Error(String(error)),
      { url: '/api/treasury/sign', method: 'POST' }
    );
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Failed to sign transaction',
      },
      { status: 500 }
    );
  }
}
