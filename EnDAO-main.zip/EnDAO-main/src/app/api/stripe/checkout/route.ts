/**
 * Stripe Checkout Session API
 *
 * Creates checkout sessions for subscription purchases.
 * Requires DAO owner authentication.
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { subscriptionService } from '@/lib/services/stripe/subscription.service';
import { SecurityValidator, ValidationError } from '@/lib/security/validation';
import { getSupabaseAdmin } from '@/lib/supabase';
import { STRIPE_PRICE_LOOKUP_KEYS } from '@endao/shared-types';

const checkoutSchema = z.object({
  daoId: z.string().uuid(),
  priceLookupKey: z.enum([
    STRIPE_PRICE_LOOKUP_KEYS.community_monthly,
    STRIPE_PRICE_LOOKUP_KEYS.community_yearly,
    STRIPE_PRICE_LOOKUP_KEYS.organization_monthly,
    STRIPE_PRICE_LOOKUP_KEYS.organization_yearly,
    STRIPE_PRICE_LOOKUP_KEYS.enterprise_monthly,
    STRIPE_PRICE_LOOKUP_KEYS.enterprise_yearly,
  ]),
  successUrl: z.string().url(),
  cancelUrl: z.string().url(),
  trialDays: z.number().int().min(0).max(30).optional(),
});

export async function POST(request: NextRequest) {
  try {
    // Get auth headers
    const userId = request.headers.get('x-auth-uid');
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const { daoId, priceLookupKey, successUrl, cancelUrl, trialDays } =
      await SecurityValidator.validate(checkoutSchema, body, {
        sanitize: true,
        checkSqlInjection: true,
        context: 'stripe-checkout',
      });

    // Verify user is DAO owner or admin
    const supabase = getSupabaseAdmin();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: membership } = await (supabase as any)
      .from('dao_members')
      .select('role')
      .eq('dao_id', daoId)
      .eq('user_id', userId)
      .single();

    if (!membership || membership.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Only group admins can manage subscriptions' },
        { status: 403 }
      );
    }

    // Get DAO details
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: dao } = await (supabase as any)
      .from('daos')
      .select('name')
      .eq('id', daoId)
      .single();

    if (!dao) {
      return NextResponse.json(
        { success: false, error: 'DAO not found' },
        { status: 404 }
      );
    }

    // Get user email
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: user } = await (supabase as any)
      .from('users')
      .select('email')
      .eq('id', userId)
      .single();

    if (!user?.email) {
      return NextResponse.json(
        { success: false, error: 'User email required for billing' },
        { status: 400 }
      );
    }

    // Create checkout session
    const result = await subscriptionService.createCheckoutSession({
      daoId,
      daoName: dao.name,
      adminEmail: user.email,
      priceLookupKey,
      successUrl,
      cancelUrl,
      trialDays,
    });

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    if (error instanceof ValidationError) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      );
    }
    console.error('[Checkout API] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create checkout session' },
      { status: 500 }
    );
  }
}
