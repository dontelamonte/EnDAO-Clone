/**
 * Manual Subscription Sync API
 *
 * POST: Manually sync a subscription from Stripe to database
 * Used when webhooks aren't working or for manual fixes
 */

import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { getSupabaseAdmin } from '@/lib/supabase';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import type { SubscriptionTier, SubscriptionStatus } from '@endao/shared-types';

let stripe: Stripe | null = null;

function getStripe(): Stripe {
  if (!stripe) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error('STRIPE_SECRET_KEY not set');
    }
    stripe = new Stripe(apiKey);
  }
  return stripe;
}

function getTierFromLookupKey(lookupKey: string): SubscriptionTier {
  if (lookupKey.startsWith('enterprise')) return 'enterprise';
  if (lookupKey.startsWith('organization')) return 'organization';
  if (lookupKey.startsWith('community')) return 'community';
  return 'community';
}

function mapStatus(status: string): string {
  switch (status) {
    case 'active': return 'active';
    case 'trialing': return 'trialing';
    case 'past_due':
    case 'unpaid': return 'past_due';
    case 'canceled':
    case 'incomplete_expired': return 'canceled';
    default: return 'active';
  }
}

export async function POST(request: NextRequest) {
  try {
    // Get auth context
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = await request.json();
    const { daoId, stripeSubscriptionId } = body;

    if (!daoId && !stripeSubscriptionId) {
      return NextResponse.json(
        { error: 'daoId or stripeSubscriptionId required' },
        { status: 400 }
      );
    }

    const supabase = getSupabaseAdmin();
    const stripeClient = getStripe();

    // Get subscription ID from customer if only daoId provided
    let subscriptionId = stripeSubscriptionId;
    if (!subscriptionId && daoId) {
      // Look up customer for this DAO
      const { data: customer } = await (supabase as any)
        .from('stripe_customers')
        .select('stripe_customer_id')
        .eq('dao_id', daoId)
        .single();

      if (!customer?.stripe_customer_id) {
        return NextResponse.json(
          { error: 'No Stripe customer found for this DAO' },
          { status: 404 }
        );
      }

      // Get active subscription for customer
      const subscriptions = await stripeClient.subscriptions.list({
        customer: customer.stripe_customer_id,
        status: 'all',
        limit: 1,
      });

      if (subscriptions.data.length === 0) {
        return NextResponse.json(
          { error: 'No subscription found for this customer' },
          { status: 404 }
        );
      }

      subscriptionId = subscriptions.data[0].id;
    }

    // Fetch subscription from Stripe
    const subscription = await stripeClient.subscriptions.retrieve(subscriptionId);

    const daoIdFromMetadata = subscription.metadata.dao_id || daoId;
    if (!daoIdFromMetadata) {
      return NextResponse.json(
        { error: 'Subscription has no dao_id in metadata' },
        { status: 400 }
      );
    }

    // Get tier from lookup key
    const price = subscription.items.data[0]?.price;
    const lookupKey = price?.lookup_key || '';
    const tier = getTierFromLookupKey(lookupKey);

    // Get period dates
    const firstItem = subscription.items.data[0];
    const currentPeriodStart = firstItem?.current_period_start;
    const currentPeriodEnd = firstItem?.current_period_end;

    // Upsert subscription
    const { error: upsertError } = await (supabase as any)
      .from('subscriptions')
      .upsert(
        {
          dao_id: daoIdFromMetadata,
          stripe_subscription_id: subscription.id,
          stripe_customer_id: subscription.customer as string,
          stripe_price_id: price?.id || '',
          status: subscription.status as SubscriptionStatus,
          tier,
          current_period_start: currentPeriodStart
            ? new Date(currentPeriodStart * 1000).toISOString()
            : null,
          current_period_end: currentPeriodEnd
            ? new Date(currentPeriodEnd * 1000).toISOString()
            : null,
          cancel_at_period_end: subscription.cancel_at_period_end,
          canceled_at: subscription.canceled_at
            ? new Date(subscription.canceled_at * 1000).toISOString()
            : null,
          trial_start: subscription.trial_start
            ? new Date(subscription.trial_start * 1000).toISOString()
            : null,
          trial_end: subscription.trial_end
            ? new Date(subscription.trial_end * 1000).toISOString()
            : null,
        },
        { onConflict: 'stripe_subscription_id' }
      );

    if (upsertError) {
      console.error('[Manual Sync] Upsert error:', upsertError);
      return NextResponse.json(
        { error: 'Failed to upsert subscription', details: upsertError },
        { status: 500 }
      );
    }

    // Update DAO
    const { error: daoError } = await (supabase as any)
      .from('daos')
      .update({
        subscription_tier: tier,
        subscription_status: mapStatus(subscription.status),
      })
      .eq('id', daoIdFromMetadata);

    if (daoError) {
      console.error('[Manual Sync] DAO update error:', daoError);
      return NextResponse.json(
        { error: 'Failed to update DAO', details: daoError },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        subscriptionId: subscription.id,
        daoId: daoIdFromMetadata,
        tier,
        status: subscription.status,
      },
    });
  } catch (error) {
    console.error('[Manual Sync] Error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
