/**
 * Stripe Subscription Status API
 *
 * Get subscription status for a DAO.
 * Requires DAO member authentication.
 */

import { NextRequest, NextResponse } from 'next/server';
import { subscriptionService } from '@/lib/services/stripe/subscription.service';
import { tierEnforcementService } from '@/lib/services/billing/tier-enforcement.service';
import { getSupabaseAdmin } from '@/lib/supabase';
import { TIER_FEATURES } from '@endao/shared-types';

export async function GET(request: NextRequest) {
  try {
    // Get auth headers
    const userId = request.headers.get('x-auth-uid');
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get daoId from query params
    const { searchParams } = new URL(request.url);
    const daoId = searchParams.get('daoId');

    if (!daoId) {
      return NextResponse.json(
        { success: false, error: 'daoId query parameter required' },
        { status: 400 }
      );
    }

    // Verify user is DAO member
    const supabase = getSupabaseAdmin();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: membership } = await (supabase as any)
      .from('dao_members')
      .select('role')
      .eq('dao_id', daoId)
      .eq('user_id', userId)
      .single();

    if (!membership) {
      return NextResponse.json(
        { success: false, error: 'Not a member of this DAO' },
        { status: 403 }
      );
    }

    // Get subscription
    const result = await subscriptionService.getSubscription(daoId);

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 500 }
      );
    }

    // Get usage data
    const usageResult = await tierEnforcementService.getUsage(daoId);

    // Get tier features
    const tier = result.data?.tier || 'starter';
    const features = TIER_FEATURES[tier];

    return NextResponse.json({
      success: true,
      data: {
        subscription: result.data,
        tier,
        features,
        usage: usageResult.success ? usageResult.data : null,
        canManage: membership.role === 'admin', // Admins can manage billing
      },
    });
  } catch (error) {
    console.error('[Subscription API] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to get subscription' },
      { status: 500 }
    );
  }
}
