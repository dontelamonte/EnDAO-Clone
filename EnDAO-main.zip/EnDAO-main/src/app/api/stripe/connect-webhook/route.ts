/**
 * Stripe Connect Webhook Handler
 *
 * Handles Stripe Connect account events:
 * - account.updated: Account status changes
 * - payout.created: Payout initiated
 * - payout.paid: Payout completed
 * - payout.failed: Payout failed
 */

import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { stripeConnectService } from '@/lib/services/stripe/stripe-connect.service';
import { logger } from '@/lib/services/logger.service';
import { getSupabaseAdmin } from '@/lib/supabase';

// Lazy-initialized Stripe client
let _stripe: Stripe | null = null;

function getStripe(): Stripe {
  if (!_stripe) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error('STRIPE_SECRET_KEY not set');
    }
    _stripe = new Stripe(apiKey);
  }
  return _stripe;
}

/**
 * POST /api/stripe/connect-webhook
 * Handle Stripe Connect webhook events
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.text();
    const signature = request.headers.get('stripe-signature');

    if (!signature) {
      logger.warn('[StripeConnectWebhook] Missing signature');
      return NextResponse.json(
        { error: 'Missing Stripe signature' },
        { status: 400 }
      );
    }

    // Verify webhook signature
    const webhookSecret = process.env.STRIPE_CONNECT_WEBHOOK_SECRET;
    if (!webhookSecret) {
      logger.error('[StripeConnectWebhook] Webhook secret not configured');
      return NextResponse.json(
        { error: 'Webhook not configured' },
        { status: 500 }
      );
    }

    let event: Stripe.Event;
    try {
      event = getStripe().webhooks.constructEvent(body, signature, webhookSecret);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      logger.error('[StripeConnectWebhook] Signature verification failed', err as Error);
      return NextResponse.json(
        { error: `Signature verification failed: ${message}` },
        { status: 400 }
      );
    }

    logger.info('[StripeConnectWebhook] Received event', {
      eventId: event.id,
      eventType: event.type,
    });

    // Store event for idempotency
    const supabase = getSupabaseAdmin();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error: insertError } = await (supabase as any)
      .from('stripe_connect_events')
      .insert({
        stripe_event_id: event.id,
        event_type: event.type,
        connect_account_id: (event.data.object as { account?: string }).account || null,
        data: event.data.object,
      });

    if (insertError?.code === '23505') {
      // Duplicate event - already processed
      logger.info('[StripeConnectWebhook] Duplicate event, skipping', {
        eventId: event.id,
      });
      return NextResponse.json({ received: true, duplicate: true });
    }

    // Handle event types
    switch (event.type) {
      case 'account.updated': {
        const account = event.data.object as Stripe.Account;
        await stripeConnectService.handleAccountUpdated(account.id);
        break;
      }

      case 'payout.created':
      case 'payout.paid':
      case 'payout.failed': {
        const payout = event.data.object as Stripe.Payout;
        await handlePayoutEvent(event.type, payout);
        break;
      }

      default:
        logger.debug('[StripeConnectWebhook] Unhandled event type', {
          eventType: event.type,
        });
    }

    return NextResponse.json({ received: true, eventId: event.id });
  } catch (error) {
    logger.error('[StripeConnectWebhook] Error processing webhook', error as Error);
    return NextResponse.json(
      { error: 'Webhook processing error' },
      { status: 500 }
    );
  }
}

/**
 * Handle payout events
 */
async function handlePayoutEvent(
  eventType: string,
  payout: Stripe.Payout
): Promise<void> {
  const supabase = getSupabaseAdmin();

  // Map Stripe status to our status
  let status: string;
  switch (payout.status) {
    case 'pending':
      status = 'pending';
      break;
    case 'in_transit':
      status = 'in_transit';
      break;
    case 'paid':
      status = 'paid';
      break;
    case 'failed':
      status = 'failed';
      break;
    case 'canceled':
      status = 'canceled';
      break;
    default:
      status = 'pending';
  }

  // Upsert payout record
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { error } = await (supabase as any)
    .from('stripe_payouts')
    .upsert(
      {
        stripe_payout_id: payout.id,
        stripe_connect_account_id: payout.destination as string,
        amount_cents: payout.amount,
        currency: payout.currency,
        status,
        arrival_date: payout.arrival_date
          ? new Date(payout.arrival_date * 1000).toISOString()
          : null,
        failure_message:
          payout.failure_message || (payout.failure_code ? String(payout.failure_code) : null),
      },
      { onConflict: 'stripe_payout_id' }
    );

  if (error) {
    logger.error('[StripeConnectWebhook] Failed to upsert payout', error);
  }
}
