/**
 * Stripe Subscription Webhook Handler
 *
 * Handles subscription lifecycle events from Stripe.
 * Endpoint: POST /api/stripe/subscription-webhook
 *
 * Required env: STRIPE_SUBSCRIPTION_WEBHOOK_SECRET
 */

import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { subscriptionService } from '@/lib/services/stripe/subscription.service';
import { billingNotificationService } from '@/lib/services/billing/billing-notification.service';
import { getSupabaseAdmin } from '@/lib/supabase';
import { logger } from '@/lib/services/logger.service';
import type { SubscriptionTier } from '@endao/shared-types';

// Lazy-initialized Stripe client
let stripe: Stripe | null = null;

function getStripe(): Stripe {
  if (!stripe) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error('STRIPE_SECRET_KEY environment variable is not set.');
    }
    stripe = new Stripe(apiKey);
  }
  return stripe;
}

// Subscription events we care about
const SUBSCRIPTION_EVENTS = [
  'customer.subscription.created',
  'customer.subscription.updated',
  'customer.subscription.deleted',
  'customer.subscription.paused',
  'customer.subscription.resumed',
  'customer.subscription.trial_will_end',
  'invoice.payment_succeeded',
  'invoice.payment_failed',
  'entitlements.active_entitlement_summary.updated',
];

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get('stripe-signature');

    if (!signature) {
      return NextResponse.json(
        { error: 'Missing stripe-signature header' },
        { status: 400 }
      );
    }

    const webhookSecret = process.env.STRIPE_SUBSCRIPTION_WEBHOOK_SECRET;
    if (!webhookSecret) {
      logger.error(
        '[Subscription Webhook] Missing STRIPE_SUBSCRIPTION_WEBHOOK_SECRET'
      );
      return NextResponse.json(
        { error: 'Webhook not configured' },
        { status: 500 }
      );
    }

    // Verify webhook signature
    let event: Stripe.Event;
    try {
      event = getStripe().webhooks.constructEvent(
        body,
        signature,
        webhookSecret
      );
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      logger.error(
        '[Subscription Webhook] Signature verification failed',
        err as Error
      );
      return NextResponse.json(
        { error: `Invalid signature: ${message}` },
        { status: 400 }
      );
    }

    // Log event for debugging
    await logSubscriptionEvent(event);

    // Handle subscription events
    if (SUBSCRIPTION_EVENTS.includes(event.type)) {
      await handleSubscriptionEvent(event);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    logger.error('[Subscription Webhook] Unhandled error', error as Error);
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 500 }
    );
  }
}

// Helper to determine tier from Stripe price
async function getTierFromPrice(priceId?: string): Promise<SubscriptionTier> {
  if (!priceId) return 'community';

  try {
    const price = await getStripe().prices.retrieve(priceId);
    const lookupKey = price.lookup_key || '';

    if (lookupKey.startsWith('enterprise')) return 'enterprise';
    if (lookupKey.startsWith('organization')) return 'organization';
    if (lookupKey.startsWith('community')) return 'community';

    // Check metadata as fallback
    const tierFromMetadata = price.metadata?.tier as
      | SubscriptionTier
      | undefined;
    if (
      tierFromMetadata &&
      ['community', 'organization', 'enterprise'].includes(tierFromMetadata)
    ) {
      return tierFromMetadata;
    }

    return 'community';
  } catch {
    return 'community';
  }
}

// Helper to safely get subscription ID from invoice
function getSubscriptionIdFromInvoice(
  invoice: Stripe.Invoice
): string | undefined {
  // Access subscription via the raw object to avoid type issues
  // Stripe Invoice has subscription as string | Stripe.Subscription | null
  const rawInvoice = invoice as unknown as {
    subscription?: string | { id: string } | null;
  };

  if (!rawInvoice.subscription) {
    return undefined;
  }

  if (typeof rawInvoice.subscription === 'string') {
    return rawInvoice.subscription;
  }

  if (
    typeof rawInvoice.subscription === 'object' &&
    rawInvoice.subscription.id
  ) {
    return rawInvoice.subscription.id;
  }

  return undefined;
}

async function handleSubscriptionEvent(event: Stripe.Event) {
  const eventType = event.type;

  switch (eventType) {
    case 'customer.subscription.created': {
      const subscription = event.data.object as Stripe.Subscription;
      const syncResult = await subscriptionService.syncSubscription(subscription);

      if (!syncResult.success) {
        logger.error('[Subscription Webhook] Failed to sync subscription', {
          subscriptionId: subscription.id,
          daoId: subscription.metadata.dao_id,
          error: syncResult.error,
        });
      }

      // Send welcome email for new subscriptions
      const daoId = subscription.metadata.dao_id;
      if (daoId) {
        const tier = await getTierFromPrice(
          subscription.items.data[0]?.price.id
        );
        await billingNotificationService.sendSubscriptionCreatedEmail({
          daoId,
          tier,
          trialEndDate: subscription.trial_end
            ? new Date(subscription.trial_end * 1000)
            : undefined,
        });
      }
      break;
    }

    case 'customer.subscription.updated':
    case 'customer.subscription.resumed': {
      const subscription = event.data.object as Stripe.Subscription;
      const syncResult = await subscriptionService.syncSubscription(subscription);

      if (!syncResult.success) {
        logger.error('[Subscription Webhook] Failed to sync subscription update', {
          subscriptionId: subscription.id,
          daoId: subscription.metadata.dao_id,
          error: syncResult.error,
        });
      }
      break;
    }

    case 'customer.subscription.deleted':
    case 'customer.subscription.paused': {
      const subscription = event.data.object as Stripe.Subscription;
      await subscriptionService.handleSubscriptionDeleted(subscription);

      // Send cancellation email
      const daoId = subscription.metadata.dao_id;
      if (daoId) {
        await billingNotificationService.sendSubscriptionCanceledEmail({
          daoId,
        });
      }
      break;
    }

    case 'customer.subscription.trial_will_end': {
      const subscription = event.data.object as Stripe.Subscription;
      logger.info('[Subscription Webhook] Trial ending soon', {
        subscriptionId: subscription.id,
        daoId: subscription.metadata.dao_id,
        trialEnd: subscription.trial_end,
      });

      // Send trial ending email
      const daoId = subscription.metadata.dao_id;
      if (daoId) {
        const tier = await getTierFromPrice(
          subscription.items.data[0]?.price.id
        );
        await billingNotificationService.sendTrialEndingSoonEmail({
          daoId,
          tier,
          trialEndDate: subscription.trial_end
            ? new Date(subscription.trial_end * 1000)
            : undefined,
        });
      }
      break;
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object as Stripe.Invoice;
      const subscriptionId = getSubscriptionIdFromInvoice(invoice);
      if (subscriptionId) {
        // Fetch and sync the subscription
        const subscription =
          await getStripe().subscriptions.retrieve(subscriptionId);
        await subscriptionService.syncSubscription(subscription);

        // Send payment receipt email (skip for $0 invoices like trial starts)
        const daoId = subscription.metadata.dao_id;
        if (daoId && invoice.amount_paid > 0) {
          await billingNotificationService.sendPaymentSucceededEmail({
            daoId,
            invoiceAmount: invoice.amount_paid,
            invoiceCurrency: invoice.currency,
            invoiceUrl: invoice.hosted_invoice_url || undefined,
          });
        }
      }
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice;
      const subscriptionId = getSubscriptionIdFromInvoice(invoice);
      logger.warn('[Subscription Webhook] Payment failed', {
        invoiceId: invoice.id,
        customerId: invoice.customer,
        subscriptionId,
      });

      // Send payment failed email
      if (subscriptionId) {
        const subscription =
          await getStripe().subscriptions.retrieve(subscriptionId);
        const daoId = subscription.metadata.dao_id;
        if (daoId) {
          await billingNotificationService.sendPaymentFailedEmail({
            daoId,
            invoiceAmount: invoice.amount_due,
            invoiceCurrency: invoice.currency,
          });
        }
      }
      break;
    }

    case 'entitlements.active_entitlement_summary.updated': {
      // Entitlements changed - sync features for the customer
      const summary = event.data.object as {
        customer?: string;
        entitlements?: { data: Array<{ lookup_key: string }> };
      };
      if (summary.customer) {
        await subscriptionService.syncEntitlements(
          summary.customer as string,
          summary.entitlements?.data?.map((e) => e.lookup_key) || []
        );
      }
      break;
    }

    default:
      logger.info('[Subscription Webhook] Unhandled event type', { eventType });
  }
}

async function logSubscriptionEvent(event: Stripe.Event) {
  try {
    const supabase = getSupabaseAdmin();

    // Extract subscription/customer info if available
    let stripeSubscriptionId: string | undefined;
    let stripeCustomerId: string | undefined;
    let daoId: string | undefined;

    // Cast to unknown first, then to Record<string, unknown> for safe property access
    const obj = event.data.object as unknown as Record<string, unknown>;

    if (
      'id' in obj &&
      typeof obj.id === 'string' &&
      obj.id.startsWith('sub_')
    ) {
      stripeSubscriptionId = obj.id;
    }
    if ('subscription' in obj) {
      const sub = obj.subscription;
      if (typeof sub === 'string') {
        stripeSubscriptionId = sub;
      } else if (
        sub &&
        typeof sub === 'object' &&
        'id' in (sub as Record<string, unknown>)
      ) {
        stripeSubscriptionId = (sub as Record<string, unknown>).id as string;
      }
    }
    if ('customer' in obj && typeof obj.customer === 'string') {
      stripeCustomerId = obj.customer;
    }
    if (
      'metadata' in obj &&
      typeof obj.metadata === 'object' &&
      obj.metadata !== null
    ) {
      const metadata = obj.metadata as Record<string, string>;
      daoId = metadata.dao_id;
    }

    // If we have a customer but no DAO, look it up
    if (stripeCustomerId && !daoId) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data: customer } = await (supabase as any)
        .from('stripe_customers')
        .select('dao_id')
        .eq('stripe_customer_id', stripeCustomerId)
        .single();

      if (customer) {
        daoId = customer.dao_id;
      }
    }

    // Log event
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase as any).from('subscription_events').insert({
      stripe_event_id: event.id,
      event_type: event.type,
      stripe_subscription_id: stripeSubscriptionId,
      stripe_customer_id: stripeCustomerId,
      dao_id: daoId,
      data: obj,
    });
  } catch (error) {
    // Don't fail the webhook if logging fails
    logger.error('[Subscription Webhook] Failed to log event', error as Error);
  }
}
