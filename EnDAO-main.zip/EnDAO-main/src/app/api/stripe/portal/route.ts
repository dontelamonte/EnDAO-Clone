/**
 * Stripe Customer Portal API
 *
 * Creates portal sessions for subscription management.
 * Requires DAO owner/admin authentication.
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { subscriptionService } from '@/lib/services/stripe/subscription.service';
import { SecurityValidator, ValidationError } from '@/lib/security/validation';
import { getSupabaseAdmin } from '@/lib/supabase';

const portalSchema = z.object({
  daoId: z.string().uuid(),
  returnUrl: z.string().url(),
});

export async function POST(request: NextRequest) {
  try {
    // Get auth headers
    const userId = request.headers.get('x-auth-uid');
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Parse and validate body
    const body = await request.json();
    const { daoId, returnUrl } = await SecurityValidator.validate(
      portalSchema,
      body,
      {
        sanitize: true,
        checkSqlInjection: true,
        context: 'stripe-portal',
      }
    );

    // Verify user is DAO owner or admin
    const supabase = getSupabaseAdmin();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: membership } = await (supabase as any)
      .from('dao_members')
      .select('role')
      .eq('dao_id', daoId)
      .eq('user_id', userId)
      .single();

    if (!membership || membership.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Only group admins can access billing' },
        { status: 403 }
      );
    }

    // Create portal session
    const result = await subscriptionService.createPortalSession({
      daoId,
      returnUrl,
    });

    if (!result.success) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    if (error instanceof ValidationError) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 400 }
      );
    }
    console.error('[Portal API] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create portal session' },
      { status: 500 }
    );
  }
}
