/**
 * Cron Job: Process Recurring Payouts
 *
 * Processes all due recurring payouts (salaries, grants, subscriptions).
 * Should run daily at midnight UTC.
 *
 * POST /api/cron/process-recurring-payouts
 *
 * Vercel Cron config (vercel.json):
 * {
 *   "crons": [{
 *     "path": "/api/cron/process-recurring-payouts",
 *     "schedule": "0 0 * * *"
 *   }]
 * }
 */

import { NextRequest, NextResponse } from 'next/server';
import { recurringPayoutService } from '@/lib/services/payout';
import { logger } from '@/lib/services/logger.service';

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Verify request is from authorized source (cron job, Vercel Cron)
    const authHeader = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (!expectedSecret) {
      logger.error('[RecurringPayoutsCron] CRON_SECRET not configured');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    if (authHeader !== `Bearer ${expectedSecret}`) {
      logger.warn('[RecurringPayoutsCron] Unauthorized request attempt');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    logger.info('[RecurringPayoutsCron] Starting recurring payout processing');

    const result = await recurringPayoutService.processDuePayouts();

    const duration = Date.now() - startTime;

    if (!result.success) {
      logger.error(
        '[RecurringPayoutsCron] Processing failed',
        new Error(result.error || 'Unknown error')
      );

      return NextResponse.json(
        {
          success: false,
          error: result.error,
          duration,
        },
        { status: 500 }
      );
    }

    logger.info('[RecurringPayoutsCron] Processing complete', {
      ...result.data,
      duration,
    });

    return NextResponse.json({
      success: true,
      data: result.data,
      duration,
    });
  } catch (error) {
    const duration = Date.now() - startTime;
    const err = error instanceof Error ? error : new Error('Unknown error');

    logger.error('[RecurringPayoutsCron] Unexpected error', err);

    return NextResponse.json(
      {
        success: false,
        error: err.message,
        duration,
      },
      { status: 500 }
    );
  }
}

// Disable body parsing for cron routes
export const config = {
  api: {
    bodyParser: false,
  },
};
