/**
 * Merkle Finalization Cron API Route
 *
 * Endpoint for the Merkle finalization cron job.
 * Finds completed proposals without Merkle roots and finalizes them.
 *
 * NOT YET ACTIVATED - To activate:
 * 1. Add CRON_SECRET to .env.local
 * 2. Add to vercel.json:
 *    {
 *      "crons": [{
 *        "path": "/api/cron/merkle-finalization",
 *        "schedule": "0 * * * *"
 *      }]
 *    }
 *
 * Security: Requires CRON_SECRET header or Vercel cron signature
 */

import { NextRequest, NextResponse } from 'next/server';
import { merkleFinalizationCronService } from '@/lib/services/proposal/voting/merkle-finalization-cron.service';
import { logger } from '@/lib/services/logger.service';

/**
 * Verify the request is from an authorized source
 */
function isAuthorized(request: NextRequest): boolean {
  // Check for Vercel Cron signature (automatic in production)
  const authHeader = request.headers.get('authorization');
  if (authHeader === `Bearer ${process.env.CRON_SECRET}`) {
    return true;
  }

  // Check for manual trigger with secret
  const cronSecret = request.headers.get('x-cron-secret');
  if (cronSecret && cronSecret === process.env.CRON_SECRET) {
    return true;
  }

  // In development, allow if CRON_SECRET is not set
  if (process.env.NODE_ENV === 'development' && !process.env.CRON_SECRET) {
    return true;
  }

  return false;
}

/**
 * POST /api/cron/merkle-finalization
 *
 * Trigger the Merkle finalization cron job manually or via scheduled cron.
 */
export async function POST(request: NextRequest) {
  // Verify authorization
  if (!isAuthorized(request)) {
    logger.warn('Unauthorized cron attempt', {
      ip: request.headers.get('x-forwarded-for') ?? undefined,
    });
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // Parse options from request body (optional)
    let options = {};
    try {
      const body = await request.json();
      options = {
        batchSize: body.batchSize,
        daoIds: body.daoIds,
        dryRun: body.dryRun,
      };
    } catch {
      // No body or invalid JSON - use defaults
    }

    logger.info('Merkle finalization cron triggered', { options });

    // Run the cron job
    const result = await merkleFinalizationCronService.run(options);

    if (result.success) {
      return NextResponse.json({
        success: true,
        data: result.data,
      });
    } else {
      const errorMsg = 'error' in result ? result.error : 'Unknown error';
      logger.error('Merkle finalization cron failed', new Error(errorMsg));
      return NextResponse.json(
        {
          success: false,
          error: errorMsg,
        },
        { status: 500 }
      );
    }
  } catch (error) {
    logger.error(
      'Merkle finalization cron exception',
      error instanceof Error ? error : new Error(String(error))
    );
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

/**
 * GET /api/cron/merkle-finalization
 *
 * Also support GET for Vercel Cron (which uses GET by default)
 */
export async function GET(request: NextRequest) {
  // Verify authorization
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Check for dry-run query param
  const dryRun = request.nextUrl.searchParams.get('dryRun') === 'true';

  try {
    const result = await merkleFinalizationCronService.run({ dryRun });

    if (result.success) {
      return NextResponse.json({
        success: true,
        data: result.data,
      });
    } else {
      const errorMsg = 'error' in result ? result.error : 'Unknown error';
      return NextResponse.json(
        {
          success: false,
          error: errorMsg,
        },
        { status: 500 }
      );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
