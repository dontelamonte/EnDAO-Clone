import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase';

/**
 * Cron Job: Snapshot DAO Stats
 *
 * Runs daily to capture DAO statistics snapshots for time-series analytics.
 *
 * Schedule: Daily at 00:00 UTC
 *
 * Vercel Cron: Add to vercel.json:
 * {
 *   "crons": [{
 *     "path": "/api/cron/snapshot-dao-stats",
 *     "schedule": "0 0 * * *"
 *   }]
 * }
 */
export async function GET(request: NextRequest) {
  try {
    // Verify cron secret (Vercel adds this header)
    const authHeader = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (!expectedSecret) {
      console.error('CRON_SECRET not configured');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    if (authHeader !== `Bearer ${expectedSecret}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const supabase = getSupabaseAdmin();
    const snapshotDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

    // Get all active DAOs
    const { data: daos, error: daosError } = await supabase
      .from('daos')
      .select(
        'id, member_count, total_proposals, active_proposals, total_votes, treasury_balance, treasury_currency'
      )
      .eq('status', 'active');

    if (daosError) {
      throw new Error(`Failed to fetch DAOs: ${daosError.message}`);
    }

    if (!daos || daos.length === 0) {
      return NextResponse.json({
        success: true,
        message: 'No active DAOs to snapshot',
        snapshotDate,
        daoCount: 0,
      });
    }

    interface DAORow {
      id: string;
      member_count: number;
      total_proposals: number;
      active_proposals: number;
      total_votes: number;
      treasury_balance: number;
      treasury_currency: string;
    }

    // Calculate stats for each DAO
    const snapshots = await Promise.all(
      daos.map(async (dao: DAORow) => {
        // Get active members (members with activity in last 30 days)
        // Uses member_activity_stats table which tracks actual activity (proposals, votes, comments)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        // eslint-disable-next-line @typescript-eslint/no-explicit-any -- member_activity_stats not in generated types yet
        const { count: activeMembers } = await (supabase as any)
          .from('member_activity_stats')
          .select('*', { count: 'exact', head: true })
          .eq('dao_id', dao.id)
          .gte('updated_at', thirtyDaysAgo.toISOString());

        // Get new members this month
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const { count: newMembers } = await supabase
          .from('dao_members')
          .select('*', { count: 'exact', head: true })
          .eq('dao_id', dao.id)
          .gte('joined_at', startOfMonth.toISOString());

        // Get proposal stats
        // eslint-disable-next-line @typescript-eslint/no-explicit-any -- proposal_stats_by_dao view not in generated types yet
        const { data: proposalStats } = await (supabase as any)
          .from('proposal_stats_by_dao')
          .select('*')
          .eq('dao_id', dao.id)
          .single();

        const pStats = proposalStats as {
          passed_proposals?: number;
          rejected_proposals?: number;
          avg_participation_rate?: string | number;
        } | null;

        // Get treasury stats
        // eslint-disable-next-line @typescript-eslint/no-explicit-any -- treasury_stats_by_dao view not in generated types yet
        const { data: treasuryStats } = await (supabase as any)
          .from('treasury_stats_by_dao')
          .select('*')
          .eq('dao_id', dao.id)
          .single();

        const tStats = treasuryStats as {
          total_inflows?: string | number;
          total_outflows?: string | number;
          transactions_this_month?: number;
        } | null;

        // Get proposals created today
        const today = new Date().toISOString().split('T')[0];
        const { count: proposalsCreated } = await supabase
          .from('proposals')
          .select('*', { count: 'exact', head: true })
          .eq('dao_id', dao.id)
          .gte('created_at', today);

        // Get votes cast today
        const { count: votesCast } = await supabase
          .from('votes')
          .select('*, proposals!inner(dao_id)', { count: 'exact', head: true })
          .eq('proposals.dao_id', dao.id)
          .gte('voted_at', today);

        return {
          dao_id: dao.id,
          snapshot_date: snapshotDate,
          member_count: dao.member_count,
          active_members: activeMembers || 0,
          new_members_count: newMembers || 0,
          total_proposals: dao.total_proposals,
          active_proposals: dao.active_proposals,
          passed_proposals: pStats?.passed_proposals || 0,
          rejected_proposals: pStats?.rejected_proposals || 0,
          proposals_created_count: proposalsCreated || 0,
          total_votes: dao.total_votes,
          votes_cast_count: votesCast || 0,
          average_participation_rate: parseFloat(
            String(pStats?.avg_participation_rate || '0')
          ),
          treasury_balance: dao.treasury_balance,
          treasury_currency: dao.treasury_currency,
          treasury_inflows: parseFloat(String(tStats?.total_inflows || '0')),
          treasury_outflows: parseFloat(String(tStats?.total_outflows || '0')),
          transactions_count: tStats?.transactions_this_month || 0,
        };
      })
    );

    // Insert snapshots (upsert to handle re-runs)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- dao_stats_history not in generated types yet
    const { error: insertError } = await (supabase as any)
      .from('dao_stats_history')
      .upsert(snapshots, {
        onConflict: 'dao_id,snapshot_date',
      });

    if (insertError) {
      throw new Error(`Failed to insert snapshots: ${insertError.message}`);
    }

    return NextResponse.json({
      success: true,
      message: 'DAO stats snapshot completed',
      snapshotDate,
      daoCount: daos.length,
    });
  } catch (error) {
    console.error('Error in snapshot-dao-stats cron job:', error);
    return NextResponse.json(
      {
        error: 'Failed to snapshot DAO stats',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
