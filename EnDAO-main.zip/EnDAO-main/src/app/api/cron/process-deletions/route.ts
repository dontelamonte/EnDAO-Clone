/**
 * Cron Job: Process DAO Deletions
 * Automatically processes deletion workflow stages:
 * 1. Check notification periods → Start objection period or grace period
 * 2. Check grace periods → Execute deletions
 * 3. Check proposals → Process results
 *
 * Should run every hour
 * POST /api/cron/process-deletions
 */

import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { daoDeleteService } from '@/lib/services/dao/dao-deletion.service';
import {
  daoAdminRepository,
  proposalAdminRepository,
} from '@/lib/data/repositories';

// Local types for dao_deletions table
interface DAODeletion {
  id: string;
  dao_id: string;
  status: string;
  notification_ends_at: string;
  grace_period_ends_at: string | null;
  objection_count: number;
  objection_threshold: number;
  proposal_id: string | null;
}

export async function POST(request: NextRequest) {
  try {
    // Verify request is from authorized source (cron job, Vercel Cron)
    const authHeader = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (!expectedSecret) {
      console.error('CRON_SECRET not configured');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    if (authHeader !== `Bearer ${expectedSecret}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const supabase = getSupabaseAdmin();
    const now = new Date();

    const results = {
      notificationPeriodsEnded: 0,
      gracePeriodsEnded: 0,
      proposalsProcessed: 0,
      errors: [] as Array<{ id: string; error: string }>,
    };

    // 1. Check notification periods that have ended
    const { data: notificationDeletions, error: notificationError } =
      await supabase
        .from('dao_deletions')
        .select('*')
        .eq('status', 'pending_notification')
        .lte('notification_ends_at', now.toISOString());

    if (notificationError) {
      console.error(
        'Error fetching notification deletions:',
        notificationError
      );
    }

    const typedNotificationDeletions = (notificationDeletions ||
      []) as DAODeletion[];

    for (const deletion of typedNotificationDeletions) {
      try {
        // Check if objections reached threshold
        if (deletion.objection_count >= deletion.objection_threshold) {
          // Proposal will be created by objectToDeletion method
          // Just update status here
          results.notificationPeriodsEnded++;
        } else {
          // No objections or below threshold → Go straight to grace period
          const gracePeriodEndsAt = new Date(
            now.getTime() + 7 * 24 * 3600 * 1000
          );

          // Update deletion record status
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          await (supabase as any)
            .from('dao_deletions')
            .update({
              status: 'grace_period',
              grace_period_ends_at: gracePeriodEndsAt.toISOString(),
            })
            .eq('id', deletion.id);

          // Update DAO status
          await daoAdminRepository.update(deletion.dao_id, {
            status: 'deleted', // Using 'deleted' since 'deletion_grace_period' may not exist
            scheduledDeletionAt: gracePeriodEndsAt.toISOString(),
          });

          results.notificationPeriodsEnded++;
        }
      } catch (error) {
        console.error(
          `Failed to process notification period for ${deletion.id}:`,
          error
        );
        results.errors.push({
          id: deletion.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    // 2. Check grace periods that have ended
    const { data: gracePeriodDeletions, error: gracePeriodError } =
      await supabase
        .from('dao_deletions')
        .select('*')
        .eq('status', 'grace_period')
        .lte('grace_period_ends_at', now.toISOString());

    if (gracePeriodError) {
      console.error('Error fetching grace period deletions:', gracePeriodError);
    }

    const typedGracePeriodDeletions = (gracePeriodDeletions ||
      []) as DAODeletion[];

    for (const deletion of typedGracePeriodDeletions) {
      try {
        const result = await daoDeleteService.executeDeletion(deletion.id);
        if (result.success) {
          results.gracePeriodsEnded++;
        } else {
          results.errors.push({
            id: deletion.id,
            error: result.error || 'Failed to execute deletion',
          });
        }
      } catch (error) {
        console.error(`Failed to execute deletion for ${deletion.id}:`, error);
        results.errors.push({
          id: deletion.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    // 3. Check proposals that have ended (awaiting processing)
    const { data: proposalDeletions, error: proposalError } = await supabase
      .from('dao_deletions')
      .select('*')
      .eq('status', 'awaiting_proposal');

    if (proposalError) {
      console.error('Error fetching proposal deletions:', proposalError);
    }

    const typedProposalDeletions = (proposalDeletions || []) as DAODeletion[];

    for (const deletion of typedProposalDeletions) {
      try {
        if (!deletion.proposal_id) continue;

        // Get proposal status
        const proposal = await proposalAdminRepository.findById(
          deletion.proposal_id
        );

        if (!proposal) continue;

        // Only process if proposal has ended
        if (!proposal.votingEndTime) continue;
        const endTime = new Date(proposal.votingEndTime);
        if (proposal.status !== 'active' && endTime <= now) {
          const result = await daoDeleteService.processDeletionProposal(
            deletion.proposal_id
          );

          if (result.success) {
            results.proposalsProcessed++;
          } else {
            results.errors.push({
              id: deletion.id,
              error: result.error || 'Failed to process proposal',
            });
          }
        }
      } catch (error) {
        console.error(`Failed to process proposal for ${deletion.id}:`, error);
        results.errors.push({
          id: deletion.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }

    return NextResponse.json({
      success: true,
      message: `Processed ${results.notificationPeriodsEnded + results.gracePeriodsEnded + results.proposalsProcessed} deletion operations`,
      details: results,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error in process-deletions cron:', error);
    return NextResponse.json(
      {
        error: 'Failed to process deletions',
        details: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

// GET for health check
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Process deletions cron endpoint is available',
    timestamp: new Date().toISOString(),
  });
}
