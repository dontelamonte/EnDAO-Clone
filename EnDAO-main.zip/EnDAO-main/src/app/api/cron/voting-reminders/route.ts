/**
 * Cron Job: Process Voting Reminders & Email Retries
 *
 * 1. Sends email reminders for upcoming proposal voting deadlines
 *    - Checks for due reminders (24h, 6h, 1h before voting ends)
 *    - Sends emails to users who haven't voted yet
 *
 * 2. Retries failed email deliveries
 *    - Processes emails that failed with transient errors
 *    - Uses exponential backoff (5, 10, 20, 40, 80, 120 minutes)
 *    - Marks permanent failures (hard bounces, invalid emails)
 *
 * Should run every hour
 * POST /api/cron/voting-reminders
 */

import { NextRequest, NextResponse } from 'next/server';
import { votingReminderService } from '@/lib/services/notification/email/voting-reminder.service';
import { emailRetryService } from '@/lib/services/notification/email/email-retry.service';
import { logger } from '@/lib/services/logger.service';

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Verify request is from authorized source (cron job, Vercel Cron)
    const authHeader = request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (!expectedSecret) {
      console.error('CRON_SECRET not configured');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    if (authHeader !== `Bearer ${expectedSecret}`) {
      logger.warn('[VotingRemindersCron] Unauthorized request attempt');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    logger.info(
      '[VotingRemindersCron] Starting voting reminders and email retry processing'
    );

    // Step 1: Process all due voting reminders
    const reminderResult = await votingReminderService.processDueReminders();

    if (!reminderResult.success) {
      logger.error(
        '[VotingRemindersCron] Failed to process reminders',
        new Error(reminderResult.error)
      );
      // Continue to retry processing even if reminders fail
    }

    // Step 2: Process email retries for failed deliveries
    const retryResult = await emailRetryService.processRetries();

    if (!retryResult.success) {
      logger.error(
        '[VotingRemindersCron] Failed to process email retries',
        new Error(retryResult.error)
      );
    }

    const duration = Date.now() - startTime;

    // Log combined results
    logger.info('[VotingRemindersCron] Completed processing', {
      reminders: reminderResult.success ? reminderResult.data : null,
      retries: retryResult.success ? retryResult.data : null,
      durationMs: duration,
    });

    // Return combined results - success if at least one operation succeeded
    const overallSuccess = reminderResult.success || retryResult.success;

    const reminderData = reminderResult.success ? reminderResult.data : null;
    const retryData = retryResult.success ? retryResult.data : null;

    return NextResponse.json({
      success: overallSuccess,
      message: `Reminders: ${reminderData?.processed || 0} processed (${reminderData?.sent || 0} sent). Retries: ${retryData?.processed || 0} processed (${retryData?.succeeded || 0} succeeded).`,
      details: {
        reminders: reminderResult.success
          ? reminderResult.data
          : { error: reminderResult.error },
        retries: retryResult.success
          ? retryResult.data
          : { error: retryResult.error },
      },
      durationMs: duration,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    const duration = Date.now() - startTime;
    logger.error(
      '[VotingRemindersCron] Error processing voting reminders',
      error as Error
    );

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to process voting reminders',
        details: error instanceof Error ? error.message : 'Unknown error',
        durationMs: duration,
      },
      { status: 500 }
    );
  }
}

// GET for health check with retry stats
export async function GET() {
  try {
    const retryStats = await emailRetryService.getRetryStats();

    const stats = retryStats.success ? retryStats.data : null;

    return NextResponse.json({
      status: 'ok',
      message: 'Voting reminders & email retry cron endpoint is available',
      retryStats: stats,
      timestamp: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json({
      status: 'ok',
      message: 'Voting reminders & email retry cron endpoint is available',
      timestamp: new Date().toISOString(),
    });
  }
}
