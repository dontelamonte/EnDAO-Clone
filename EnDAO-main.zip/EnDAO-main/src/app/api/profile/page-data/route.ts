/**
 * Profile Page Data API Route
 *
 * Batched endpoint that combines all data needed for the user profile page.
 * Reduces multiple API calls to a single request.
 *
 * Returns:
 * - User profile
 * - Notification preferences
 * - User's DAOs with roles
 * - Activity summary
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  userProfileCrudService,
  userPreferencesService,
  userActivityService,
} from '@/lib/services/user';
import { DAOService } from '@/lib/services/dao';
import { userAdminRepository } from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import type { UserProfile, DAO } from '@endao/shared-types';

interface NotificationPreferences {
  emailNotifications: boolean;
  pushNotifications: boolean;
  proposalUpdates: boolean;
  votingReminders: boolean;
  treasuryAlerts: boolean;
  membershipChanges: boolean;
}

interface UserDAO {
  id: string;
  name: string;
  description: string;
  logoUrl: string | null;
  role: string;
  joinedAt: string;
  memberCount: number;
  activeProposals: number;
}

interface ActivitySummary {
  totalDAOs: number;
  proposalsCreated: number;
  votesCount: number;
  commentsCount: number;
  lastActiveAt: string | null;
}

interface ProfilePageData {
  profile: UserProfile;
  notificationPreferences: NotificationPreferences;
  daos: UserDAO[];
  activitySummary: ActivitySummary;
}

export async function GET(request: NextRequest) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Authentication required',
          code: 'AUTH_REQUIRED',
        },
        { status: 401 }
      );
    }

    logger.debug('[Profile Page Data API] Fetching data for user', {
      privyId: privyId.substring(0, 15) + '...',
    });

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        {
          success: false,
          error: 'User not found',
          code: 'USER_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;

    // Fetch user profile
    const profileResult = await userProfileCrudService.getUserProfile(userId);
    if (!profileResult.success || !profileResult.data) {
      return NextResponse.json(
        {
          success: false,
          error: profileResult.error || 'Profile not found',
          code: 'PROFILE_NOT_FOUND',
        },
        { status: 404 }
      );
    }

    const profile = profileResult.data;

    // Fetch notification preferences
    let notificationPreferences: NotificationPreferences = {
      emailNotifications: true,
      pushNotifications: true,
      proposalUpdates: true,
      votingReminders: true,
      treasuryAlerts: true,
      membershipChanges: true,
    };

    try {
      const preferencesResult =
        await userPreferencesService.getPreferences(userId);
      if (preferencesResult.success && preferencesResult.data) {
        const prefs = preferencesResult.data;
        const notifSettings = prefs.notificationSettings;
        notificationPreferences = {
          emailNotifications: prefs.emailNotifications ?? true,
          pushNotifications: prefs.pushNotifications ?? true,
          proposalUpdates: notifSettings?.proposalCreated ?? true,
          votingReminders: notifSettings?.votingStarted ?? true,
          treasuryAlerts: notifSettings?.securityAlerts ?? true,
          membershipChanges: notifSettings?.membershipApproved ?? true,
        };
      }
    } catch (err) {
      logger.warn(
        '[Profile Page Data API] Failed to fetch preferences, using defaults',
        {
          userId,
          error: err instanceof Error ? err.message : String(err),
        }
      );
    }

    // Fetch user's DAOs
    const daoService = DAOService.getInstance();
    const userDAOsResult = await daoService.getUserDAOs(userId);

    const daos: UserDAO[] = [];
    if (userDAOsResult.success && userDAOsResult.data) {
      for (const dao of userDAOsResult.data) {
        // Get user's role in this DAO
        const membershipResult = await daoService.getMembership(dao.id, userId);
        const role =
          membershipResult.success && membershipResult.data
            ? membershipResult.data.role
            : 'member';

        daos.push({
          id: dao.id,
          name: dao.name,
          description: dao.description,
          logoUrl: dao.logoUrl || null,
          role,
          joinedAt:
            membershipResult.success && membershipResult.data
              ? membershipResult.data.joinedAt
              : new Date().toISOString(),
          memberCount: dao.stats?.memberCount || dao.memberCount || 0,
          activeProposals: dao.stats?.activeProposals || 0,
        });
      }
    }

    // Fetch activity summary
    let activitySummary: ActivitySummary = {
      totalDAOs: daos.length,
      proposalsCreated: 0,
      votesCount: 0,
      commentsCount: 0,
      lastActiveAt: null,
    };

    try {
      // Get recent activity to determine last active time
      const activityResult = await userActivityService.getRecentActivity(
        userId,
        1
      );
      if (
        activityResult.success &&
        activityResult.data &&
        activityResult.data.length > 0
      ) {
        activitySummary.lastActiveAt =
          activityResult.data[0].timestamp.toISOString();
      }

      // Get activity stats from profile if available
      if (profile.stats) {
        const stats = profile.stats as Record<string, unknown>;
        activitySummary.proposalsCreated =
          (stats.proposalsCreated as number) || 0;
        activitySummary.votesCount = (stats.votesCount as number) || 0;
        activitySummary.commentsCount = (stats.commentsCount as number) || 0;
      }
    } catch (err) {
      logger.warn('[Profile Page Data API] Failed to fetch activity summary', {
        userId,
        error: err instanceof Error ? err.message : String(err),
      });
    }

    const pageData: ProfilePageData = {
      profile,
      notificationPreferences,
      daos,
      activitySummary,
    };

    return NextResponse.json(
      {
        success: true,
        data: pageData,
      },
      {
        headers: {
          // Cache for 1 minute (profile data changes infrequently)
          'Cache-Control': 'private, max-age=60, stale-while-revalidate=30',
        },
      }
    );
  } catch (error) {
    logger.error(
      '[Profile Page Data API] Error fetching page data',
      error as Error
    );
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch profile page data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}
