/**
 * User Analytics API Route
 *
 * GET - Fetch comprehensive analytics data for the authenticated user
 * Browser-safe wrapper for analytics data aggregation
 */

import { NextRequest, NextResponse } from 'next/server';
import { DAOService } from '@/lib/services/dao';
import {
  proposalAdminRepository,
  voteAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';
import { safeService } from '@/lib/services/safe.service';
import { cryptoPriceService } from '@/lib/services/crypto-price.service';

interface DAOParticipation {
  daoId: string;
  dao: string;
  votes: number;
  passedProposals: number;
  engagement: number;
  treasuryValue: number;
}

interface WeeklyActivity {
  week: string;
  votes: number;
}

interface VotingBehavior {
  name: string;
  value: number;
  fill: string;
}

interface UserAnalyticsData {
  userDAOs: Array<{
    id: string;
    name: string;
    description: string;
    memberCount: number;
    treasuryValue: string;
  }>;
  daoParticipation: DAOParticipation[];
  activityTrend: WeeklyActivity[];
  votingBehavior: VotingBehavior[];
  totalTreasuryAccess: string;
  totalVotes: number;
  averageParticipation: number;
}

interface AnalyticsResponse {
  success: boolean;
  data?: UserAnalyticsData;
  error?: string;
}

export async function GET(
  request: NextRequest
): Promise<NextResponse<AnalyticsResponse>> {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json({
        success: true,
        data: {
          userDAOs: [],
          daoParticipation: [],
          activityTrend: [
            { week: 'W1', votes: 0 },
            { week: 'W2', votes: 0 },
            { week: 'W3', votes: 0 },
            { week: 'W4', votes: 0 },
          ],
          votingBehavior: [
            { name: 'For', value: 0, fill: '#10b981' },
            { name: 'Against', value: 0, fill: '#ef4444' },
            { name: 'Abstain', value: 0, fill: '#6b7280' },
          ],
          totalTreasuryAccess: '$0',
          totalVotes: 0,
          averageParticipation: 0,
        },
      });
    }

    const userId = supabaseUser.id;
    const daoService = DAOService.getInstance();

    // Get user's DAOs
    const daosResult = await daoService.getUserDAOs(userId);
    const userDAOs =
      daosResult.success && daosResult.data ? daosResult.data : [];

    // Get all user's votes
    const userVotes = await voteAdminRepository.findByUser(userId);
    const activeDaoIds = new Set(userDAOs.map((d) => d.id));

    // Filter votes to only active DAOs
    const activeVotes = userVotes.filter(
      (v) => v.daoId && activeDaoIds.has(v.daoId)
    );

    // Calculate voting behavior
    let forCount = 0;
    let againstCount = 0;
    let abstainCount = 0;

    for (const vote of activeVotes) {
      if (vote.vote === 'yes' || vote.vote === 'for') {
        forCount++;
      } else if (vote.vote === 'no' || vote.vote === 'against') {
        againstCount++;
      } else if (vote.vote === 'abstain') {
        abstainCount++;
      }
    }

    // Calculate DAO participation and treasury
    let totalTreasury = 0;
    const participation: DAOParticipation[] = [];

    // Collect all Safe addresses to fetch balances in parallel
    // Note: safeAddress is the Safe address from the database
    const daoTreasuryMap = new Map<
      string,
      { daoId: string; safeAddress: string }
    >();
    for (const dao of userDAOs) {
      const safeAddr = dao.safeAddress;
      if (safeAddr) {
        daoTreasuryMap.set(dao.id, {
          daoId: dao.id,
          safeAddress: safeAddr,
        });
      }
    }

    // Fetch treasury balances in parallel for all DAOs with Safe addresses
    const treasuryValues = new Map<string, number>();
    if (daoTreasuryMap.size > 0) {
      try {
        const balancePromises = Array.from(daoTreasuryMap.values()).map(
          async ({ daoId, safeAddress }) => {
            try {
              const rawBalances = await safeService.getAllBalances(safeAddress);
              const symbols = rawBalances.map((b) => b.symbol);
              const prices = await cryptoPriceService.getPrices(symbols);

              const totalUsd = rawBalances.reduce((sum, token) => {
                const balanceNum = parseFloat(token.balance) || 0;
                const price = prices[token.symbol] || 0;
                return sum + balanceNum * price;
              }, 0);

              return { daoId, totalUsd };
            } catch (err) {
              logger.warn(
                `[User Analytics] Failed to fetch treasury for DAO ${daoId}`,
                { error: err }
              );
              return { daoId, totalUsd: 0 };
            }
          }
        );

        const results = await Promise.all(balancePromises);
        for (const { daoId, totalUsd } of results) {
          treasuryValues.set(daoId, totalUsd);
        }
      } catch (err) {
        logger.warn('[User Analytics] Failed to fetch treasury balances', {
          error: err,
        });
      }
    }

    for (const dao of userDAOs) {
      // Count votes for this DAO
      const daoVotes = activeVotes.filter((v) => v.daoId === dao.id);
      const voteCount = daoVotes.length;

      // Get passed proposals for this DAO
      const passedProposals = await proposalAdminRepository.findByDao(
        dao.id,
        'passed'
      );
      const passedCount = passedProposals.length;

      // Get total proposals for participation calculation
      const allProposals = await proposalAdminRepository.findByDao(dao.id);
      const activeProposals = allProposals.filter(
        (p: { status: string }) =>
          p.status !== 'draft' && p.status !== 'deleted'
      );
      const participationRate =
        activeProposals.length > 0
          ? Math.round((voteCount / activeProposals.length) * 100)
          : 0;

      // Get treasury value from fetched data
      const treasuryValue = treasuryValues.get(dao.id) || 0;
      totalTreasury += treasuryValue;

      participation.push({
        daoId: dao.id,
        dao: dao.name,
        votes: voteCount,
        passedProposals: passedCount,
        engagement: participationRate,
        treasuryValue,
      });
    }

    // Calculate weekly activity trend (last 4 weeks)
    const now = new Date();
    const activityTrend: WeeklyActivity[] = [];

    for (let i = 3; i >= 0; i--) {
      const weekStart = new Date(now);
      weekStart.setDate(weekStart.getDate() - (i + 1) * 7);
      const weekEnd = new Date(now);
      weekEnd.setDate(weekEnd.getDate() - i * 7);

      const weekVotes = activeVotes.filter((v) => {
        const voteDate = new Date(v.createdAt);
        return voteDate >= weekStart && voteDate < weekEnd;
      }).length;

      activityTrend.push({
        week: `W${4 - i}`,
        votes: weekVotes,
      });
    }

    // Calculate average participation
    const averageParticipation =
      participation.length > 0
        ? Math.round(
            participation.reduce((sum, p) => sum + p.engagement, 0) /
              participation.length
          )
        : 0;

    // Format USD value for display
    const formatUSD = (value: number): string => {
      if (value === 0) return '$0';
      if (value >= 1000000) return `$${(value / 1000000).toFixed(2)}M`;
      if (value >= 1000) return `$${(value / 1000).toFixed(2)}K`;
      return `$${value.toFixed(2)}`;
    };

    const analyticsData: UserAnalyticsData = {
      userDAOs: userDAOs.map((dao) => ({
        id: dao.id,
        name: dao.name,
        description: dao.description,
        memberCount: dao.memberCount || 0,
        treasuryValue: formatUSD(treasuryValues.get(dao.id) || 0),
      })),
      daoParticipation: participation,
      activityTrend,
      votingBehavior: [
        { name: 'For', value: forCount, fill: '#10b981' },
        { name: 'Against', value: againstCount, fill: '#ef4444' },
        { name: 'Abstain', value: abstainCount, fill: '#6b7280' },
      ],
      totalTreasuryAccess: formatUSD(totalTreasury),
      totalVotes: activeVotes.length,
      averageParticipation,
    };

    return NextResponse.json({ success: true, data: analyticsData });
  } catch (error) {
    logger.error(
      '[User Analytics API] Error fetching analytics',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}
