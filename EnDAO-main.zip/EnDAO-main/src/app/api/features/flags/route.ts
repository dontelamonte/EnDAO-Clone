/**
 * Feature Flags API - Dynamic feature flag management
 * Phase 6.3: Feature Flag System
 */

import { NextRequest, NextResponse } from 'next/server';
import { PrivyClient } from '@privy-io/server-auth';
import { userAdminRepository } from '@/lib/data/repositories';
import {
  featureFlagService,
  FEATURE_FLAG_METADATA,
} from '@/lib/features/feature-flag.service';
import {
  withAdminValidation,
  createValidationErrorResponse,
} from '@/lib/middleware/api-validation';
import { featureFlagUpdateSchema } from '@/lib/validations/api';
import { logger } from '@/lib/services/logger.service';

// Using enhanced feature flag schema from validations/api.ts
// The imported featureFlagUpdateSchema includes comprehensive security validation

/**
 * Verify Privy token and get user
 */
async function verifyAuth(
  authHeader: string | null
): Promise<{ userId: string; userEmail?: string } | null> {
  if (!authHeader?.startsWith('Bearer ')) {
    return null;
  }

  try {
    const token = authHeader.substring(7);
    const appId = process.env.NEXT_PUBLIC_PRIVY_APP_ID;
    const appSecret = process.env.PRIVY_APP_SECRET;

    if (!appId || !appSecret) {
      return null;
    }

    const privyClient = new PrivyClient(appId, appSecret);
    const verifiedUser = await privyClient.verifyAuthToken(token);

    if (!verifiedUser || !verifiedUser.userId) {
      return null;
    }

    // Map Privy ID to Supabase user
    const supabaseUser = await userAdminRepository.findByPrivyId(
      verifiedUser.userId
    );
    if (!supabaseUser) {
      return null;
    }

    return {
      userId: supabaseUser.id,
      userEmail: supabaseUser.email ?? undefined,
    };
  } catch {
    return null;
  }
}

/**
 * GET /api/features/flags
 * Get current feature flags and metadata
 */
export async function GET(request: NextRequest) {
  try {
    // Optional: Verify authentication for sensitive flags
    const authHeader = request.headers.get('authorization');
    let userId: string | undefined = undefined;
    let userRole: 'member' | 'admin' | null = null;

    const authResult = await verifyAuth(authHeader);
    if (authResult) {
      userId = authResult.userId;
      // In production, fetch user role from database
      // For now, we'll use a simple check
      userRole = 'member'; // Default role
    }

    // Get flags based on user role
    const flags = userRole
      ? featureFlagService.getUserFeatures(userRole)
      : featureFlagService.getFlags();

    // Filter metadata based on what user can see
    const visibleMetadata: Record<string, unknown> = {};
    for (const [key, metadata] of Object.entries(FEATURE_FLAG_METADATA)) {
      if (
        !metadata.minRole ||
        (userRole &&
          featureFlagService.hasAccess(
            key as keyof typeof FEATURE_FLAG_METADATA,
            userRole
          ))
      ) {
        visibleMetadata[key] = metadata;
      }
    }

    // Add caching headers - 5 min cache (flags rarely change)
    return NextResponse.json(
      {
        flags,
        metadata: visibleMetadata,
        userRole,
        timestamp: new Date().toISOString(),
      },
      {
        headers: {
          'Cache-Control': 'public, max-age=300, stale-while-revalidate=60',
        },
      }
    );
  } catch (error) {
    console.error('Failed to get feature flags:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve feature flags' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/features/flags
 * Update feature flags with enhanced security validation (admin only)
 */
export const POST = withAdminValidation(featureFlagUpdateSchema, {
  sanitize: true,
  checkSqlInjection: true,
  checkXss: true,
  logValidation: true,
  rateLimit: {
    requests: 10, // Very restrictive for admin feature flag changes
    windowMs: 15 * 60 * 1000,
  },
})(async function postFeatureFlags(request: NextRequest, validatedData) {
  const clientIP = request.headers.get('x-forwarded-for') || 'unknown';
  const userAgent = request.headers.get('user-agent') ?? undefined;

  try {
    // Verify authentication
    const authHeader = request.headers.get('authorization');
    const authResult = await verifyAuth(authHeader);

    if (!authResult) {
      return createValidationErrorResponse(
        'Authentication required',
        'UNAUTHENTICATED',
        401
      );
    }

    const { userId, userEmail } = authResult;

    // Admin verification with enhanced logging
    const isAdmin =
      userEmail?.includes('admin') || userEmail?.endsWith('@endao.ai');

    if (!isAdmin) {
      logger.warn('Unauthorized feature flag access attempt', {
        userId,
        userEmail,
        ip: clientIP,
        userAgent,
        attemptedFlags: Object.keys(validatedData.flags),
      });

      return createValidationErrorResponse(
        'Admin access required',
        'INSUFFICIENT_PERMISSIONS',
        403
      );
    }

    const { flags, daoId, environment } = validatedData;

    // Validate flag keys against metadata
    const updatedFlags: Record<string, boolean> = {};
    const invalidFlags: string[] = [];

    for (const [key, value] of Object.entries(flags)) {
      if (key in FEATURE_FLAG_METADATA) {
        updatedFlags[key] = value;
      } else {
        invalidFlags.push(key);
      }
    }

    if (invalidFlags.length > 0) {
      logger.warn('Invalid feature flags attempted', {
        userId,
        invalidFlags,
        ip: clientIP,
      });

      return createValidationErrorResponse(
        `Invalid feature flags: ${invalidFlags.join(', ')}`,
        'INVALID_FLAGS',
        400
      );
    }

    // Log the critical admin action
    logger.info('Feature flags update', {
      userId,
      userEmail,
      daoId,
      environment,
      updatedFlags,
      ip: clientIP,
      userAgent,
      timestamp: new Date().toISOString(),
    });

    // In production, this would:
    // 1. Update database/config service
    // 2. Invalidate caches
    // 3. Notify other services
    // 4. Create audit trail

    return NextResponse.json({
      success: true,
      updatedFlags,
      environment,
      message: 'Feature flags updated successfully',
      timestamp: new Date().toISOString(),
      audit: {
        userId,
        updatedCount: Object.keys(updatedFlags).length,
      },
    });
  } catch (error) {
    logger.error('Feature flags update error', error as Error, {
      ip: clientIP,
      userAgent,
      flagCount: Object.keys(validatedData.flags).length,
    });

    return createValidationErrorResponse(
      'Failed to update feature flags',
      'UPDATE_ERROR',
      500
    );
  }
});

/**
 * OPTIONS /api/features/flags
 * CORS preflight
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
}
