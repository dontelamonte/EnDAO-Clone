/**
 * Secure file upload endpoint with comprehensive validation
 * Implements OWASP file upload security guidelines
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { errorTrackingService } from '@/lib/services/error-tracking.service';
import {
  validateFileUpload,
  createValidationErrorResponse,
} from '@/lib/middleware/api-validation';
import { fileUploadSchema } from '@/lib/validations/api';
import { z } from 'zod';

// File upload configuration
const UPLOAD_CONFIG = {
  MAX_FILE_SIZE: 50 * 1024 * 1024, // 50MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  ALLOWED_DOCUMENT_TYPES: ['application/pdf', 'text/plain', 'text/markdown'],
  ALLOWED_EXTENSIONS: {
    image: ['.jpg', '.jpeg', '.png', '.webp', '.gif'],
    document: ['.pdf', '.txt', '.md'],
    avatar: ['.jpg', '.jpeg', '.png', '.webp'],
    dao_logo: ['.jpg', '.jpeg', '.png', '.webp', '.gif'],
    proposal_attachment: ['.pdf', '.txt', '.md', '.jpg', '.jpeg', '.png'],
  },
  VIRUS_SCAN_ENABLED: process.env.NODE_ENV === 'production',
  QUARANTINE_SUSPICIOUS: true,
} as const;

/**
 * POST /api/upload
 * Secure file upload with comprehensive validation and security checks
 */
export async function POST(request: NextRequest) {
  const startTime = performance.now();
  const clientIP = request.headers.get('x-forwarded-for') || 'unknown';
  const userAgent = request.headers.get('user-agent');

  try {
    // Authentication required for file uploads
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return createValidationErrorResponse(
        'Authentication required',
        'UNAUTHENTICATED',
        401
      );
    }

    const { uid } = authContext;

    logger.info('File upload attempt', {
      uid: uid || undefined,
      ip: clientIP || undefined,
      userAgent: userAgent || undefined,
      timestamp: new Date().toISOString(),
    });

    // Validate Content-Type header for multipart/form-data
    const contentType = request.headers.get('content-type') || '';
    if (!contentType.startsWith('multipart/form-data')) {
      return createValidationErrorResponse(
        'Invalid content type. Expected multipart/form-data for file uploads',
        'INVALID_CONTENT_TYPE',
        400
      );
    }

    // Parse multipart form data
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const purpose = formData.get('purpose') as string;
    const checksum = (formData.get('checksum') as string | null) || undefined;

    if (!file) {
      return createValidationErrorResponse(
        'No file provided',
        'NO_FILE_PROVIDED',
        400
      );
    }

    // Validate file metadata
    const fileMetadata = {
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size,
      purpose: purpose || 'other',
      checksum,
    };

    const metadataValidation = fileUploadSchema.safeParse(fileMetadata);
    if (!metadataValidation.success) {
      logger.warn('File metadata validation failed', {
        uid,
        errors: metadataValidation.error.issues,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
      });

      return createValidationErrorResponse(
        'Invalid file metadata',
        'INVALID_FILE_METADATA',
        400,
        metadataValidation.error.issues
      );
    }

    const validatedMetadata = metadataValidation.data;

    // Enhanced file validation
    const allowedExtensions =
      UPLOAD_CONFIG.ALLOWED_EXTENSIONS[
        validatedMetadata.purpose as keyof typeof UPLOAD_CONFIG.ALLOWED_EXTENSIONS
      ] || [];
    const fileValidationResult = await validateFileUpload(file, {
      maxSize: UPLOAD_CONFIG.MAX_FILE_SIZE,
      allowedTypes: getAllowedTypes(validatedMetadata.purpose),
      allowedExtensions: [...allowedExtensions],
    });

    if (!fileValidationResult.success) {
      logger.warn('File validation failed', {
        uid,
        error: fileValidationResult.error,
        code: fileValidationResult.code,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
      });

      return createValidationErrorResponse(
        fileValidationResult.error,
        fileValidationResult.code,
        fileValidationResult.status
      );
    }

    // Perform security scans
    const securityScanResult = await performSecurityScan(file, uid);
    if (!securityScanResult.safe) {
      securityMetrics.threatsBlocked++;

      logger.error('File security scan failed', undefined, {
        uid: uid || undefined,
        fileName: file.name,
        fileType: file.type,
        threats: securityScanResult.threats,
        ip: clientIP || undefined,
      });

      errorTrackingService.trackError(
        new Error(
          `File security scan failed: ${securityScanResult.threats.join(', ')}`
        ),
        {
          context: 'file_upload_security',
          uid: uid || undefined,
          fileName: file.name,
          fileType: file.type,
          threats: securityScanResult.threats,
          ip: clientIP || undefined,
          severity: 'high',
        }
      );

      return createValidationErrorResponse(
        'File failed security scan',
        'FILE_SECURITY_FAILED',
        400
      );
    }

    // Checksum verification (if provided)
    if (validatedMetadata.checksum) {
      const calculatedChecksum = await calculateFileChecksum(file);
      if (calculatedChecksum !== validatedMetadata.checksum) {
        logger.warn('File checksum mismatch', {
          uid,
          fileName: file.name,
          expected: validatedMetadata.checksum,
          actual: calculatedChecksum,
        });

        return createValidationErrorResponse(
          'File checksum verification failed',
          'CHECKSUM_MISMATCH',
          400
        );
      }
    }

    // Process and store the file
    const uploadResult = await processFileUpload(file, validatedMetadata, uid);
    if (!uploadResult.success) {
      logger.error('File processing failed', undefined, {
        uid: uid || undefined,
        error: uploadResult.error,
        fileName: file.name,
      });

      return createValidationErrorResponse(
        uploadResult.error || 'Failed to process file',
        'FILE_PROCESSING_FAILED',
        500
      );
    }

    const processingTime = performance.now() - startTime;
    securityMetrics.successful++;

    logger.info('File upload successful', {
      uid,
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      purpose: validatedMetadata.purpose,
      uploadId: uploadResult.uploadId,
      processingTime: Math.round(processingTime),
      ip: clientIP,
    });

    return NextResponse.json({
      success: true,
      data: {
        uploadId: uploadResult.uploadId,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        url: uploadResult.url,
        cdnUrl: uploadResult.cdnUrl,
      },
      timestamp: new Date().toISOString(),
      processingTime: Math.round(processingTime),
    });
  } catch (error) {
    const errorTime = performance.now() - startTime;
    securityMetrics.failed++;

    logger.error('File upload error', error as Error, {
      uid: (await getAuthContext(request))?.uid || undefined,
      processingTime: errorTime,
      ip: clientIP || undefined,
      userAgent: userAgent || undefined,
    });

    errorTrackingService.trackError(error as Error, {
      context: 'file_upload',
      ip: clientIP || undefined,
      processingTime: errorTime,
    });

    return createValidationErrorResponse(
      'File upload failed',
      'UPLOAD_ERROR',
      500
    );
  }
}

/**
 * GET /api/upload
 * Get upload status and configuration
 */
export async function GET(request: NextRequest) {
  try {
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return createValidationErrorResponse(
        'Authentication required',
        'UNAUTHENTICATED',
        401
      );
    }

    return NextResponse.json({
      config: {
        maxFileSize: UPLOAD_CONFIG.MAX_FILE_SIZE,
        allowedTypes: {
          image: UPLOAD_CONFIG.ALLOWED_IMAGE_TYPES,
          document: UPLOAD_CONFIG.ALLOWED_DOCUMENT_TYPES,
        },
        allowedExtensions: UPLOAD_CONFIG.ALLOWED_EXTENSIONS,
        virusScanEnabled: UPLOAD_CONFIG.VIRUS_SCAN_ENABLED,
      },
      metrics: getUploadMetrics(),
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('Error getting upload config', error as Error);

    return createValidationErrorResponse(
      'Failed to get upload configuration',
      'CONFIG_ERROR',
      500
    );
  }
}

// ============================================================================
// SECURITY SCAN FUNCTIONS
// ============================================================================

interface SecurityScanResult {
  safe: boolean;
  threats: string[];
  scanTime: number;
}

async function performSecurityScan(
  file: File,
  uid: string
): Promise<SecurityScanResult> {
  const startTime = performance.now();
  const threats: string[] = [];

  try {
    // 1. File signature validation (magic bytes)
    const signatureValidation = await validateFileSignature(file);
    if (!signatureValidation.valid) {
      threats.push(`Invalid file signature: ${signatureValidation.reason}`);
    }

    // 2. Embedded content scan
    const embeddedContentScan = await scanForEmbeddedContent(file);
    if (embeddedContentScan.suspicious) {
      threats.push(
        `Suspicious embedded content: ${embeddedContentScan.reason}`
      );
    }

    // 3. Metadata scan
    const metadataScan = await scanFileMetadata(file);
    if (metadataScan.suspicious) {
      threats.push(`Suspicious metadata: ${metadataScan.reason}`);
    }

    // 4. Content analysis (for text files)
    if (
      file.type.startsWith('text/') ||
      file.type.includes('json') ||
      file.type.includes('xml')
    ) {
      const contentScan = await scanTextContent(file);
      if (contentScan.suspicious) {
        threats.push(`Suspicious text content: ${contentScan.reason}`);
      }
    }

    const scanTime = performance.now() - startTime;
    const safe = threats.length === 0;

    logger.debug('File security scan completed', {
      uid,
      fileName: file.name,
      fileType: file.type,
      safe,
      threatCount: threats.length,
      scanTime: Math.round(scanTime),
    });

    return { safe, threats, scanTime };
  } catch (error) {
    logger.error('Security scan error', error as Error, {
      uid,
      fileName: file.name,
    });

    // In case of scan error, err on the side of caution
    return {
      safe: false,
      threats: ['Security scan failed'],
      scanTime: performance.now() - startTime,
    };
  }
}

async function validateFileSignature(
  file: File
): Promise<{ valid: boolean; reason?: string }> {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer.slice(0, 16)); // First 16 bytes

  const signatures = {
    'image/jpeg': [0xff, 0xd8, 0xff],
    'image/png': [0x89, 0x50, 0x4e, 0x47],
    'image/gif': [0x47, 0x49, 0x46],
    'image/webp': [0x52, 0x49, 0x46, 0x46],
    'application/pdf': [0x25, 0x50, 0x44, 0x46],
  };

  const expectedSignature = signatures[file.type as keyof typeof signatures];
  if (!expectedSignature) {
    return { valid: true }; // No signature check for this file type
  }

  const matches = expectedSignature.every(
    (byte, index) => bytes[index] === byte
  );
  if (!matches) {
    return {
      valid: false,
      reason: `File signature doesn't match declared type ${file.type}`,
    };
  }

  return { valid: true };
}

async function scanForEmbeddedContent(
  file: File
): Promise<{ suspicious: boolean; reason?: string }> {
  if (!file.type.startsWith('image/')) {
    return { suspicious: false };
  }

  const text = await file.text();

  // Look for embedded scripts or suspicious content in image files
  const suspiciousPatterns = [
    /<script/i,
    /javascript:/i,
    /vbscript:/i,
    /on\w+\s*=/i,
    /data:.*base64/i,
    /<iframe/i,
    /<object/i,
    /<embed/i,
  ];

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(text)) {
      return {
        suspicious: true,
        reason: `Embedded content detected: ${pattern.source}`,
      };
    }
  }

  return { suspicious: false };
}

async function scanFileMetadata(
  file: File
): Promise<{ suspicious: boolean; reason?: string }> {
  // Check for suspicious file names
  const suspiciousNamePatterns = [
    /\.(exe|bat|cmd|scr|pif|com|vbs|jar|php|asp|jsp)$/i,
    /\x00/,
    /<script/i,
    /[<>:"|?*]/,
  ];

  for (const pattern of suspiciousNamePatterns) {
    if (pattern.test(file.name)) {
      return {
        suspicious: true,
        reason: `Suspicious file name pattern: ${pattern.source}`,
      };
    }
  }

  return { suspicious: false };
}

async function scanTextContent(
  file: File
): Promise<{ suspicious: boolean; reason?: string }> {
  const content = await file.text();

  const suspiciousPatterns = [
    /(eval|exec|system|cmd)\s*\(/i,
    /(union|select|insert|delete|drop)\s+/i,
    /<script/i,
    /javascript:/i,
    /vbscript:/i,
    /onload\s*=/i,
    /\x00/,
  ];

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(content)) {
      return {
        suspicious: true,
        reason: `Suspicious text pattern: ${pattern.source}`,
      };
    }
  }

  return { suspicious: false };
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function getAllowedTypes(purpose: string): string[] {
  switch (purpose) {
    case 'avatar':
    case 'dao_logo':
      return [...UPLOAD_CONFIG.ALLOWED_IMAGE_TYPES];
    case 'proposal_attachment':
      return [
        ...UPLOAD_CONFIG.ALLOWED_IMAGE_TYPES,
        ...UPLOAD_CONFIG.ALLOWED_DOCUMENT_TYPES,
      ];
    default:
      return [
        ...UPLOAD_CONFIG.ALLOWED_IMAGE_TYPES,
        ...UPLOAD_CONFIG.ALLOWED_DOCUMENT_TYPES,
      ];
  }
}

async function calculateFileChecksum(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function processFileUpload(
  file: File,
  metadata: z.infer<typeof fileUploadSchema>,
  uid: string
): Promise<{
  success: boolean;
  error?: string;
  uploadId?: string;
  url?: string;
  cdnUrl?: string;
}> {
  try {
    // Generate unique upload ID
    const uploadId = `upload_${Date.now()}_${Math.random().toString(36).substring(2)}`;

    // In a real implementation, this would:
    // 1. Upload to cloud storage (S3, GCS, etc.)
    // 2. Generate CDN URLs
    // 3. Store metadata in database
    // 4. Run virus scanning if enabled
    // 5. Generate thumbnails for images

    logger.info('File processing started', {
      uploadId,
      fileName: metadata.fileName,
      fileSize: metadata.fileSize,
      purpose: metadata.purpose,
      uid,
    });

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 100));

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://endao.ai';
    const url = `${baseUrl}/api/files/${uploadId}`;
    const cdnUrl = `${baseUrl}/cdn/files/${uploadId}`;

    return {
      success: true,
      uploadId,
      url,
      cdnUrl,
    };
  } catch (error) {
    logger.error('File processing error', error as Error, {
      fileName: metadata.fileName,
      uid,
    });

    return {
      success: false,
      error: 'Failed to process file upload',
    };
  }
}

// ============================================================================
// METRICS AND MONITORING
// ============================================================================

interface UploadMetrics {
  successful: number;
  failed: number;
  threatsBlocked: number;
  totalSize: number;
  averageProcessingTime: number;
}

const securityMetrics: UploadMetrics = {
  successful: 0,
  failed: 0,
  threatsBlocked: 0,
  totalSize: 0,
  averageProcessingTime: 0,
};

function getUploadMetrics(): UploadMetrics & { timestamp: string } {
  return {
    ...securityMetrics,
    timestamp: new Date().toISOString(),
  };
}
