/**
 * Optimized Avatar Upload API
 *
 * Security & Performance Features:
 * - Server-side MIME validation (magic bytes)
 * - UUID filenames (unpredictable paths)
 * - WebP conversion (25-35% smaller)
 * - Multiple responsive sizes
 * - Supabase Storage integration
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { logger } from '@/lib/services/logger.service';
import { createValidationErrorResponse } from '@/lib/middleware/api-validation';
import { v4 as uuidv4 } from 'uuid';

// Lazy imports to avoid browser bundling issues
async function getSupabaseAdmin() {
  const { getSupabaseAdmin } = await import('@/lib/supabase/admin');
  return getSupabaseAdmin();
}

async function getVerifyAuthToken() {
  const { verifyAuthToken } = await import('@/lib/privy-server');
  return verifyAuthToken;
}

async function getUserAdminRepository() {
  const { userAdminRepository } = await import(
    '@/lib/data/repositories/supabase'
  );
  return userAdminRepository;
}

async function getSharp() {
  const sharpModule = await import('sharp');
  return sharpModule.default;
}

// Configuration
const AVATAR_CONFIG = {
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_MIME_TYPES: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  OUTPUT_FORMAT: 'webp' as const,
  OUTPUT_QUALITY: 85,
  SIZES: {
    thumbnail: 64, // For small UI elements
    small: 128, // For lists, cards
    medium: 256, // For profile display
    large: 512, // For full profile view
  },
  BUCKET: 'avatars',
};

// Magic byte signatures for image validation
const MAGIC_SIGNATURES: Record<string, number[]> = {
  'image/jpeg': [0xff, 0xd8, 0xff],
  'image/png': [0x89, 0x50, 0x4e, 0x47],
  'image/gif': [0x47, 0x49, 0x46],
  'image/webp': [0x52, 0x49, 0x46, 0x46], // RIFF header
};

/**
 * POST /api/upload/avatar
 * Secure, optimized avatar upload with WebP conversion and responsive sizes
 */
export async function POST(request: NextRequest) {
  const startTime = performance.now();

  try {
    // 1. Authentication - support both middleware headers and Bearer token
    let uid: string | null = null;
    let privyUserId: string | null = null;

    // First try middleware-set headers (server-side rendering)
    const authContext = await getAuthContext(request);
    if (authContext) {
      uid = authContext.uid;
      privyUserId = authContext.privyUserId;
    }

    // Fall back to Bearer token (client-side uploads)
    if (!uid) {
      const authHeader = request.headers.get('authorization');
      if (!authHeader) {
        return createValidationErrorResponse(
          'Authorization header required',
          'UNAUTHENTICATED',
          401
        );
      }

      const verifyAuthToken = await getVerifyAuthToken();
      const tokenResult = await verifyAuthToken(authHeader);

      if (!tokenResult.success || !tokenResult.claims) {
        return createValidationErrorResponse(
          tokenResult.error || 'Invalid token',
          'INVALID_TOKEN',
          401
        );
      }

      privyUserId = tokenResult.claims.userId;

      // Look up internal user ID from Privy ID
      const userRepo = await getUserAdminRepository();
      const user = await userRepo.findByPrivyId(privyUserId);

      if (!user) {
        return createValidationErrorResponse(
          'User not found',
          'USER_NOT_FOUND',
          404
        );
      }

      uid = user.id;
    }

    if (!uid) {
      return createValidationErrorResponse(
        'Authentication required',
        'UNAUTHENTICATED',
        401
      );
    }

    // 2. Parse form data
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const targetId = formData.get('targetId') as string | null; // userId or daoId

    if (!file) {
      return createValidationErrorResponse(
        'No file provided',
        'NO_FILE_PROVIDED',
        400
      );
    }

    // 3. Validate file size
    if (file.size > AVATAR_CONFIG.MAX_FILE_SIZE) {
      return createValidationErrorResponse(
        `File size must be less than ${AVATAR_CONFIG.MAX_FILE_SIZE / 1024 / 1024}MB`,
        'FILE_TOO_LARGE',
        400
      );
    }

    // 4. Server-side MIME validation (magic bytes)
    const buffer = Buffer.from(await file.arrayBuffer());
    const detectedMime = detectMimeType(buffer);

    if (
      !detectedMime ||
      !AVATAR_CONFIG.ALLOWED_MIME_TYPES.includes(detectedMime)
    ) {
      logger.warn('Invalid file signature detected', {
        uid,
        declaredType: file.type,
        detectedType: detectedMime || 'unknown',
        fileName: file.name,
      });

      return createValidationErrorResponse(
        'Invalid image file. Only JPEG, PNG, WebP, and GIF are allowed.',
        'INVALID_FILE_TYPE',
        400
      );
    }

    // 5. Check for embedded malicious content
    const securityCheck = await checkForMaliciousContent(buffer);
    if (!securityCheck.safe) {
      logger.error('Malicious content detected in avatar upload', undefined, {
        uid,
        reason: securityCheck.reason,
        fileName: file.name,
      });

      return createValidationErrorResponse(
        'File failed security validation',
        'SECURITY_CHECK_FAILED',
        400
      );
    }

    // 6. Generate UUID filename (unpredictable path)
    const avatarId = uuidv4();
    const userId = targetId || uid;

    // 7. Process image with Sharp - convert to WebP and generate sizes
    const processedImages = await processAvatarImage(buffer, avatarId);

    if (!processedImages.success) {
      return createValidationErrorResponse(
        processedImages.error || 'Failed to process image',
        'IMAGE_PROCESSING_FAILED',
        500
      );
    }

    // 8. Upload all sizes to Supabase Storage
    const supabase = await getSupabaseAdmin();
    const uploadedUrls: Record<string, string> = {};

    for (const [sizeName, imageBuffer] of Object.entries(
      processedImages.images!
    )) {
      const filePath = `${userId}/${avatarId}-${sizeName}.webp`;

      const { error: uploadError } = await supabase.storage
        .from(AVATAR_CONFIG.BUCKET)
        .upload(filePath, imageBuffer, {
          contentType: 'image/webp',
          upsert: true,
          cacheControl: '31536000', // 1 year cache (immutable with UUID)
        });

      if (uploadError) {
        logger.error('Failed to upload avatar size', uploadError as Error, {
          uid,
          sizeName,
          filePath,
        });

        // Clean up any uploaded files on failure
        await cleanupPartialUpload(
          supabase,
          userId,
          avatarId,
          Object.keys(uploadedUrls)
        );

        return createValidationErrorResponse(
          'Failed to upload avatar',
          'UPLOAD_FAILED',
          500
        );
      }

      // Get public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from(AVATAR_CONFIG.BUCKET).getPublicUrl(filePath);

      uploadedUrls[sizeName] = publicUrl;
    }

    // 9. Delete old avatars for this user (cleanup)
    await cleanupOldAvatars(supabase, userId, avatarId);

    const processingTime = Math.round(performance.now() - startTime);

    logger.info('Avatar uploaded successfully', {
      uid,
      avatarId,
      sizes: Object.keys(uploadedUrls),
      originalSize: file.size,
      processingTime,
    });

    return NextResponse.json({
      success: true,
      data: {
        avatarId,
        urls: uploadedUrls,
        // Primary URL is the medium size (best balance)
        url: uploadedUrls.medium,
        // Provide all sizes for responsive usage
        responsive: {
          thumbnail: uploadedUrls.thumbnail,
          small: uploadedUrls.small,
          medium: uploadedUrls.medium,
          large: uploadedUrls.large,
        },
      },
      meta: {
        originalSize: file.size,
        optimizedFormat: 'webp',
        processingTime,
      },
    });
  } catch (error) {
    logger.error('Avatar upload error', error as Error);

    return createValidationErrorResponse(
      'Avatar upload failed',
      'UPLOAD_ERROR',
      500
    );
  }
}

/**
 * Detect MIME type from magic bytes
 */
function detectMimeType(buffer: Buffer): string | null {
  const bytes = buffer.slice(0, 16);

  for (const [mimeType, signature] of Object.entries(MAGIC_SIGNATURES)) {
    if (mimeType === 'image/webp') {
      // WebP has RIFF header followed by WEBP at bytes 8-11
      if (
        bytes[0] === 0x52 &&
        bytes[1] === 0x49 &&
        bytes[2] === 0x46 &&
        bytes[3] === 0x46 &&
        bytes[8] === 0x57 &&
        bytes[9] === 0x45 &&
        bytes[10] === 0x42 &&
        bytes[11] === 0x50
      ) {
        return mimeType;
      }
    } else {
      const matches = signature.every((byte, index) => bytes[index] === byte);
      if (matches) {
        return mimeType;
      }
    }
  }

  return null;
}

/**
 * Check for malicious content embedded in image
 */
async function checkForMaliciousContent(
  buffer: Buffer
): Promise<{ safe: boolean; reason?: string }> {
  const text = buffer.toString('utf-8', 0, Math.min(buffer.length, 10000));

  const suspiciousPatterns = [
    /<script/i,
    /javascript:/i,
    /vbscript:/i,
    /on\w+\s*=/i,
    /<iframe/i,
    /<object/i,
    /<embed/i,
    /eval\s*\(/i,
    /exec\s*\(/i,
  ];

  for (const pattern of suspiciousPatterns) {
    if (pattern.test(text)) {
      return { safe: false, reason: `Suspicious pattern: ${pattern.source}` };
    }
  }

  return { safe: true };
}

/**
 * Process image with Sharp - convert to WebP and generate multiple sizes
 */
async function processAvatarImage(
  buffer: Buffer,
  avatarId: string
): Promise<{
  success: boolean;
  error?: string;
  images?: Record<string, Buffer>;
}> {
  try {
    const images: Record<string, Buffer> = {};
    const sharp = await getSharp();

    // Load image with Sharp
    const image = sharp(buffer);
    const metadata = await image.metadata();

    // Validate it's actually an image
    if (!metadata.width || !metadata.height) {
      return { success: false, error: 'Invalid image file' };
    }

    // Generate each size
    for (const [sizeName, size] of Object.entries(AVATAR_CONFIG.SIZES)) {
      const resized = await sharp(buffer)
        .resize(size, size, {
          fit: 'cover', // Crop to fill square
          position: 'center', // Center the crop
        })
        .webp({
          quality: AVATAR_CONFIG.OUTPUT_QUALITY,
          effort: 4, // Balance between speed and compression
        })
        .toBuffer();

      images[sizeName] = resized;
    }

    return { success: true, images };
  } catch (error) {
    logger.error('Sharp image processing error', error as Error);
    return { success: false, error: 'Failed to process image' };
  }
}

/**
 * Clean up partially uploaded files on failure
 */
async function cleanupPartialUpload(
  supabase: Awaited<ReturnType<typeof getSupabaseAdmin>>,
  userId: string,
  avatarId: string,
  uploadedSizes: string[]
): Promise<void> {
  try {
    const filePaths = uploadedSizes.map(
      (size) => `${userId}/${avatarId}-${size}.webp`
    );
    if (filePaths.length > 0) {
      await supabase.storage.from(AVATAR_CONFIG.BUCKET).remove(filePaths);
    }
  } catch (error) {
    logger.error('Failed to cleanup partial upload', error as Error);
  }
}

/**
 * Clean up old avatars for a user (keep only current)
 */
async function cleanupOldAvatars(
  supabase: Awaited<ReturnType<typeof getSupabaseAdmin>>,
  userId: string,
  currentAvatarId: string
): Promise<void> {
  try {
    // List all files in user's folder
    const { data: files, error } = await supabase.storage
      .from(AVATAR_CONFIG.BUCKET)
      .list(userId);

    if (error || !files) return;

    // Find files that don't match current avatar ID
    const oldFiles = files
      .filter((file) => !file.name.startsWith(currentAvatarId))
      .map((file) => `${userId}/${file.name}`);

    if (oldFiles.length > 0) {
      await supabase.storage.from(AVATAR_CONFIG.BUCKET).remove(oldFiles);
      logger.debug('Cleaned up old avatars', {
        userId,
        count: oldFiles.length,
      });
    }
  } catch (error) {
    // Non-critical, just log
    logger.warn('Failed to cleanup old avatars', { userId, error });
  }
}
