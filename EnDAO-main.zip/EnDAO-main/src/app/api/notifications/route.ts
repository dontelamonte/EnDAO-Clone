/**
 * Notifications API Route
 *
 * Server-side endpoint for fetching user notifications.
 * Maps Privy ID to Supabase UUID before querying.
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  notificationAdminRepository,
  userAdminRepository,
} from '@/lib/data/repositories';
import { logger } from '@/lib/services/logger.service';

export async function GET(request: NextRequest) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'User ID required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json({
        success: true,
        data: {
          notifications: [],
          unreadCount: 0,
        },
      });
    }

    const userId = supabaseUser.id;

    // Get query params
    const { searchParams } = new URL(request.url);
    const limitParam = searchParams.get('limit');
    const unreadOnlyParam = searchParams.get('unreadOnly');
    const limit = limitParam ? parseInt(limitParam, 10) : 50;
    const unreadOnly = unreadOnlyParam === 'true';

    // Fetch notifications
    const [notifications, unreadCount] = await Promise.all([
      unreadOnly
        ? notificationAdminRepository.findUnreadByUser(userId, limit)
        : notificationAdminRepository.findByUser(userId, { limit }),
      notificationAdminRepository.countUnread(userId),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        notifications: notifications.map((n) => ({
          id: n.id,
          userId: n.userId,
          daoId: n.daoId,
          type: n.type,
          title: n.title,
          message: n.body || '',
          data: n.metadata,
          read: n.read,
          readAt: n.readAt?.toISOString(),
          createdAt: n.createdAt.toISOString(),
        })),
        unreadCount,
      },
    });
  } catch (error) {
    logger.error(
      '[Notifications API] Error fetching notifications',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to fetch notifications' },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    // Get Privy user ID from auth header (set by middleware)
    const privyId =
      request.headers.get('x-auth-privy-id') ||
      request.headers.get('x-auth-uid');

    if (!privyId) {
      return NextResponse.json(
        { success: false, error: 'User ID required' },
        { status: 401 }
      );
    }

    // Look up Supabase user by Privy ID
    const supabaseUser = await userAdminRepository.findByPrivyId(privyId);
    if (!supabaseUser) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = supabaseUser.id;
    const body = await request.json();

    // Handle mark as read
    if (body.notificationId) {
      // Mark single notification as read
      await notificationAdminRepository.markAsRead(body.notificationId);
      return NextResponse.json({ success: true });
    } else if (body.markAllAsRead) {
      // Mark all notifications as read
      const count = await notificationAdminRepository.markAllAsRead(userId);
      return NextResponse.json({ success: true, data: { count } });
    }

    return NextResponse.json(
      { success: false, error: 'Invalid request' },
      { status: 400 }
    );
  } catch (error) {
    logger.error(
      '[Notifications API] Error updating notifications',
      error as Error
    );
    return NextResponse.json(
      { success: false, error: 'Failed to update notifications' },
      { status: 500 }
    );
  }
}
