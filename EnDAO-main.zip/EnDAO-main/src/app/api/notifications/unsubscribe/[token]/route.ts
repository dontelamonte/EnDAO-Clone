/**
 * Unsubscribe API Route
 * Handles one-click email unsubscribe for CAN-SPAM and GDPR compliance
 *
 * GET /api/notifications/unsubscribe/[token]
 * - Validates token and processes unsubscribe
 * - Returns JSON response for programmatic access
 *
 * This route is public (no auth required) to support one-click unsubscribe
 * from email clients that may not have session cookies.
 */

import { NextRequest, NextResponse } from 'next/server';
import { unsubscribeService } from '@/lib/services/notification/email/unsubscribe.service';
import { logger } from '@/lib/services/logger.service';

interface RouteParams {
  params: Promise<{
    token: string;
  }>;
}

export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { token } = await params;

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing unsubscribe token',
          code: 'MISSING_TOKEN',
        },
        { status: 400 }
      );
    }

    logger.info('[UnsubscribeRoute] Processing unsubscribe request', {
      tokenPrefix: token.substring(0, 8),
    });

    const result = await unsubscribeService.processUnsubscribe(token);

    if (!result.success) {
      logger.error(
        '[UnsubscribeRoute] Unsubscribe processing failed',
        new Error(result.error || 'Unknown error')
      );
      return NextResponse.json(
        {
          success: false,
          error: result.error || 'Failed to process unsubscribe',
          code: 'PROCESSING_ERROR',
        },
        { status: 500 }
      );
    }

    // Return success with details about what was unsubscribed
    return NextResponse.json({
      success: result.data.success ?? false,
      message: result.data.message || 'Unsubscribe processed',
      details: {
        scope: result.data.scope,
        notificationType: result.data.notificationType,
        daoName: result.data.daoName,
      },
    });
  } catch (error) {
    logger.error(
      '[UnsubscribeRoute] Error processing unsubscribe',
      error as Error
    );

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to process unsubscribe request',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

/**
 * POST handler for RFC 8058 one-click unsubscribe
 * Email clients may send a POST request with List-Unsubscribe-Post header
 */
export async function POST(request: NextRequest, { params }: RouteParams) {
  // RFC 8058 specifies that the POST body should contain "List-Unsubscribe=One-Click"
  // We process the unsubscribe the same as GET
  return GET(request, { params });
}
