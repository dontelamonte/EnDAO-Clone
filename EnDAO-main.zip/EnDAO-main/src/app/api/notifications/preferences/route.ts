/**
 * API route for managing user notification preferences
 *
 * Uses the user_preferences table which has a notification_settings JSONB column
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  DigestSettings,
  NotificationPreferencesDocument,
  NotificationType,
} from '@/lib/services/notification/types/database.types';
import { withPrivyAuth } from '@/lib/auth/privy-middleware-enhanced';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
import { userAdminRepository } from '@/lib/data/repositories';

/**
 * Default notification settings stored in user_preferences.notification_settings JSONB
 * This is a simplified format for database storage
 */
interface DbNotificationSettings {
  email: boolean;
  push: boolean;
  proposalCreated: boolean;
  voteReminder: boolean;
  proposalPassed: boolean;
}

const DEFAULT_NOTIFICATION_SETTINGS: DbNotificationSettings = {
  email: true,
  push: false,
  proposalCreated: true,
  voteReminder: true,
  proposalPassed: true,
};

/**
 * All notification types for building complete typePreferences
 */
const ALL_NOTIFICATION_TYPES: NotificationType[] = [
  'proposal_created',
  'proposal_updated',
  'proposal_executed',
  'member_joined',
  'member_left',
  'member_role_changed',
  'treasury_transaction',
  'treasury_freeze',
  'treasury_unfreeze',
  'dao_created',
  'dao_updated',
  'dao_deleted',
  'system_maintenance',
  'security_alert',
  'comment_added',
  'mention',
];

/**
 * Build complete typePreferences with all required NotificationType keys
 */
function buildTypePreferences(
  emailEnabled: boolean,
  pushEnabled: boolean
): Record<NotificationType, { email: boolean; push: boolean; inApp: boolean }> {
  const prefs = {} as Record<
    NotificationType,
    { email: boolean; push: boolean; inApp: boolean }
  >;
  for (const type of ALL_NOTIFICATION_TYPES) {
    prefs[type] = {
      email: emailEnabled,
      push: pushEnabled,
      inApp: true,
    };
  }
  return prefs;
}

/**
 * Create default notification preferences for a user
 */
function createDefaultPreferences(
  userId: string
): NotificationPreferencesDocument {
  const timezone =
    typeof Intl !== 'undefined'
      ? Intl.DateTimeFormat().resolvedOptions().timeZone
      : 'UTC';

  return {
    userId,
    global: {
      emailEnabled: true,
      pushEnabled: false,
      inAppEnabled: true,
      digestEnabled: false,
      quietHours: {
        enabled: false,
        startTime: '22:00',
        endTime: '08:00',
        timezone,
      },
      typePreferences: buildTypePreferences(true, false),
    },
    daoSettings: {},
    digestSettings: {
      enabled: false,
      frequency: 'daily',
      time: '09:00',
      timezone,
      minNotifications: 5,
      includeRead: false,
    } as DigestSettings,
    updatedAt: new Date(),
    version: 1,
    activeDAOs: [],
  };
}

/**
 * Convert user_preferences.notification_settings to NotificationPreferencesDocument
 */
function mapDbPrefsToDocument(
  userId: string,
  dbSettings: DbNotificationSettings | null,
  updatedAt?: string
): NotificationPreferencesDocument {
  const settings = dbSettings || DEFAULT_NOTIFICATION_SETTINGS;
  const timezone =
    typeof Intl !== 'undefined'
      ? Intl.DateTimeFormat().resolvedOptions().timeZone
      : 'UTC';

  return {
    userId,
    global: {
      emailEnabled: settings.email === true,
      pushEnabled: settings.push === true,
      inAppEnabled: true,
      digestEnabled: false,
      quietHours: {
        enabled: false,
        startTime: '22:00',
        endTime: '08:00',
        timezone,
      },
      typePreferences: buildTypePreferences(settings.email, settings.push),
    },
    daoSettings: {},
    digestSettings: {
      enabled: false,
      frequency: 'daily',
      time: '09:00',
      timezone,
      minNotifications: 5,
      includeRead: false,
    } as DigestSettings,
    updatedAt: updatedAt ? new Date(updatedAt) : new Date(),
    version: 1,
    activeDAOs: [],
  };
}

export const GET = withPrivyAuth(async (_request: NextRequest, authContext) => {
  try {
    const { privyUserId } = authContext;
    const supabase = getSupabaseAdmin();

    // Get user by Privy ID
    const user = await userAdminRepository.findByPrivyId(privyUserId);
    if (!user) {
      // Return defaults for unknown user
      return NextResponse.json({
        success: true,
        data: createDefaultPreferences(privyUserId),
      });
    }

    // Query user_preferences table
    // Note: user_preferences table uses JSONB for notification_settings
    // Type assertion needed as table is not in generated Supabase types yet
    const { data: prefs, error } = (await supabase
      .from('user_preferences')
      .select('notification_settings, updated_at')
      .eq('user_id', user.id)
      .maybeSingle()) as unknown as {
      data: {
        notification_settings: DbNotificationSettings | null;
        updated_at: string | null;
      } | null;
      error: Error | null;
    };

    if (error) {
      console.error('Error fetching notification preferences:', error);
      return NextResponse.json({
        success: true,
        data: createDefaultPreferences(user.id),
      });
    }

    // Convert DB format to document format
    const preferences = mapDbPrefsToDocument(
      user.id,
      prefs?.notification_settings ?? null,
      prefs?.updated_at ?? undefined
    );

    return NextResponse.json({
      success: true,
      data: preferences,
    });
  } catch (error) {
    console.error('Error fetching notification preferences:', error);
    return NextResponse.json(
      {
        error: {
          code: 'PREFERENCES_FETCH_FAILED',
          message: 'Failed to fetch notification preferences',
        },
      },
      { status: 500 }
    );
  }
});

export const PUT = withPrivyAuth(async (request: NextRequest, authContext) => {
  try {
    const { privyUserId } = authContext;
    const body = await request.json();
    const supabase = getSupabaseAdmin();

    // Validate request body
    if (!body || typeof body !== 'object') {
      return NextResponse.json(
        {
          error: {
            code: 'INVALID_REQUEST',
            message: 'Request body must be an object',
          },
        },
        { status: 400 }
      );
    }

    // Get user by Privy ID
    const user = await userAdminRepository.findByPrivyId(privyUserId);
    if (!user) {
      return NextResponse.json(
        { error: { code: 'USER_NOT_FOUND', message: 'User not found' } },
        { status: 404 }
      );
    }

    // Convert incoming document format to DB format
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const global = body.global as any;
    const notificationSettings: DbNotificationSettings = {
      email: global?.emailEnabled ?? true,
      push: global?.pushEnabled ?? false,
      proposalCreated: global?.typePreferences?.proposal_created?.email ?? true,
      voteReminder: global?.typePreferences?.proposal_updated?.email ?? true,
      proposalPassed: global?.typePreferences?.proposal_executed?.email ?? true,
    };

    // Upsert user_preferences
    // Type assertion needed as table is not in generated Supabase types yet
    const { error } = await (
      supabase.from('user_preferences') as ReturnType<typeof supabase.from>
    ).upsert(
      {
        user_id: user.id,
        notification_settings: notificationSettings,
        updated_at: new Date().toISOString(),
      } as Record<string, unknown>,
      {
        onConflict: 'user_id',
      }
    );

    if (error) {
      console.error('Error updating notification preferences:', error);
      return NextResponse.json(
        {
          error: {
            code: 'PREFERENCES_UPDATE_FAILED',
            message: 'Failed to update notification preferences',
          },
        },
        { status: 500 }
      );
    }

    // Return updated preferences
    const updatedPrefs = mapDbPrefsToDocument(
      user.id,
      notificationSettings,
      new Date().toISOString()
    );

    return NextResponse.json({
      success: true,
      data: updatedPrefs,
    });
  } catch (error) {
    console.error('Error updating notification preferences:', error);
    return NextResponse.json(
      {
        error: {
          code: 'PREFERENCES_UPDATE_FAILED',
          message: 'Failed to update notification preferences',
        },
      },
      { status: 500 }
    );
  }
});
