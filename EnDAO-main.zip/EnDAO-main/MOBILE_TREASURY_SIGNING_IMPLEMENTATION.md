# Mobile Treasury Signing Feature Implementation

**Status**: ✅ Complete
**Date**: February 7, 2026

## Overview

Implemented treasury signing functionality for the EnDAO mobile app, allowing Safe owners to sign pending treasury transactions from their mobile devices using Privy embedded wallets.

## Files Created

### Backend API Routes

1. **`/src/app/api/mobile/v1/daos/[daoId]/treasury/pending/route.ts`**
   - GET endpoint to fetch pending treasury executions for a DAO
   - Returns list of executions with signature status
   - Checks if user is a Safe owner
   - Includes execution metadata: amount, recipient, required/current signatures

2. **`/src/app/api/mobile/v1/treasury/executions/[executionId]/sign/route.ts`**
   - POST endpoint to submit a signature for a treasury execution
   - Validates signature format (hex, 0x prefix, 132 characters)
   - Verifies treasury access permissions
   - Checks Safe ownership
   - Adds signature via `TreasurySignatureCollectionService`
   - Returns updated signature count and status

### Mobile Hooks

3. **`/apps/mobile/src/hooks/usePendingExecutions.ts`**
   - Custom React hook for fetching pending executions
   - Integrates offline caching (5-minute TTL)
   - Auto-refreshes when network restored
   - Returns: executions array, isOwner flag, loading/error states

### Mobile Components

4. **`/apps/mobile/src/components/treasury/PendingExecutionCard.tsx`**
   - Displays a pending execution card with:
     - Proposal title
     - Amount and recipient (truncated address)
     - Progress bar for signatures (e.g., "2 of 3 signatures")
     - Status badges: "You signed", "Needs signatures", "Ready to execute"
     - "Sign Transaction" button (if user hasn't signed)
   - Follows mobile theme (dark mode, slate palette)

### Mobile Screens

5. **`/apps/mobile/app/dao/[id]/treasury/pending.tsx`**
   - Full screen for viewing and signing pending executions
   - Fetches pending list using `usePendingExecutions` hook
   - Implements signing flow:
     - Uses `useEmbeddedWallet` from Privy
     - Signs Safe transaction hash with `personal_sign`
     - Submits signature to API
     - Shows success/error alerts
     - Refreshes list after signing
   - Empty states for non-owners and no pending transactions
   - Pull-to-refresh support

### Updates to Existing Files

6. **`/apps/mobile/app/dao/[id]/treasury.tsx`**
   - Added button to view pending signatures
   - Shows count of pending executions (if user is Safe owner)
   - Navigates to `/dao/[id]/treasury/pending` screen
   - Button styled with warning color + border

7. **`/apps/mobile/src/services/api.ts`**
   - Added `getPendingExecutions()` method
   - Added `signTreasuryExecution()` method

8. **`/apps/mobile/src/components/treasury/index.ts`**
   - Exported `PendingExecutionCard` component

## Data Flow

```
Mobile App → API Route → Service Layer → Repository → Supabase
     ↓                                                    ↓
     ←─────────────── Response ←─────────────────────────┘
```

### Read Flow (View Pending)

1. User navigates to treasury screen
2. `usePendingExecutions` hook fetches data via API
3. API checks DAO membership and Safe ownership
4. Returns pending executions with signature counts
5. Screen displays cards with "Sign" button

### Write Flow (Sign Transaction)

1. User taps "Sign Transaction" button
2. App prompts Privy wallet to sign Safe transaction hash
3. Signature submitted to `/treasury/executions/[id]/sign` endpoint
4. API validates:
   - Signature format
   - Treasury access permissions
   - Safe ownership
   - Duplicate signature prevention
5. `TreasurySignatureCollectionService` adds signature
6. Signature count updated in database
7. Status changes to "ready_to_execute" if threshold met
8. Success message shown, list refreshed

## Security Features

- **Authentication**: All endpoints require Privy authentication
- **Authorization**: Only Safe owners can sign
- **Treasury Access Control**: Uses `TreasuryAccessControlService` for 4-layer protection
- **Signature Validation**: Format checked (hex, 0x prefix, 132 chars)
- **Duplicate Prevention**: Checks if user already signed
- **Audit Logging**: All signature events logged via `auditLogService`

## Key Design Decisions

### 1. Signature Method
- Used `personal_sign` (not EIP-712) because Safe transactions use raw hash signing
- Compatible with Privy embedded wallet API
- Matches web implementation pattern

### 2. Offline Support
- Cached pending executions for 5 minutes
- Allows viewing offline (but not signing)
- Auto-refreshes when network restored

### 3. Mobile UX
- Progress bar shows signature collection visually
- Status badges use semantic colors
- Truncated addresses for better mobile layout
- Pull-to-refresh for easy updates
- Alert dialogs for success/error feedback

### 4. Component Architecture
- Followed existing mobile patterns (hooks, components, screens)
- Reused common components (LoadingState, ErrorState, EmptyState)
- Consistent with web treasury patterns

## Testing Checklist

### Manual Testing

- [ ] View pending executions as Safe owner
- [ ] View as non-owner (should show "Not Authorized")
- [ ] Sign a transaction
- [ ] Verify signature count increments
- [ ] Try to sign twice (should fail with "already signed")
- [ ] Complete all required signatures
- [ ] Verify status changes to "Ready to execute"
- [ ] Test offline mode (view cached data)
- [ ] Test network restoration (auto-refresh)
- [ ] Pull-to-refresh
- [ ] Empty state (no pending transactions)

### Edge Cases

- [ ] DAO without treasury configured
- [ ] Archived/frozen DAO treasury
- [ ] Invalid signature format
- [ ] Network error during signing
- [ ] User cancels signature prompt

## Related Files

### Services (Reference Only)
- `/src/lib/services/treasury/treasury-signature-collection.service.ts` - Core signature logic
- `/src/lib/services/treasury/treasury-access-control.service.ts` - Permission validation
- `/src/lib/services/safe.service.ts` - Safe ownership checks

### Repositories (Reference Only)
- `/src/lib/data/repositories/supabase/treasury-execution.repository.ts` - Execution CRUD
- Schema: `treasury_executions`, `treasury_execution_signatures`

### Web Implementation (Reference)
- `/src/app/api/treasury/sign/route.ts` - Web signing endpoint
- Includes Safe transaction hash verification

## Future Enhancements

- [ ] Add signature history view (who signed, when)
- [ ] Push notifications for new pending transactions
- [ ] Batch signing (sign multiple at once)
- [ ] QR code scanning for Safe transaction hashes
- [ ] Integration with hardware wallets
- [ ] Transaction simulation/preview

## Notes

- Mobile app NEVER directly accesses Supabase - all operations go through API routes
- Signature format matches Gnosis Safe requirements (hex, 132 chars)
- Safe transaction hash comes from proposal execution, created during proposal finalization
- Execution locks prevent race conditions during signature collection
- Grace period (7 days) protects against malicious treasury changes

## Dependencies

- Privy Expo SDK: `@privy-io/expo` for embedded wallet
- Expo Router: Navigation and screen structure
- React Native: Core mobile UI
- TypeScript: Type safety

## Compliance

- ✅ Follows ADR-001 (repository/service patterns)
- ✅ Mobile-first API architecture (no direct Supabase access)
- ✅ Browser-safe patterns (API routes only)
- ✅ Treasury 4-layer protection enforced
- ✅ Audit logging for all signatures
