import '@testing-library/jest-dom';

// Mock Supabase client
const mockSupabaseClient = {
  from: jest.fn(() => ({
    select: jest.fn().mockReturnThis(),
    insert: jest.fn().mockReturnThis(),
    update: jest.fn().mockReturnThis(),
    delete: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    single: jest.fn().mockResolvedValue({ data: null, error: null }),
    maybeSingle: jest.fn().mockResolvedValue({ data: null, error: null }),
  })),
  auth: {
    getUser: jest.fn().mockResolvedValue({ data: { user: null }, error: null }),
    getSession: jest
      .fn()
      .mockResolvedValue({ data: { session: null }, error: null }),
  },
  channel: jest.fn(() => ({
    on: jest.fn().mockReturnThis(),
    subscribe: jest.fn(),
    unsubscribe: jest.fn(),
  })),
};

jest.mock('@/lib/supabase/client', () => ({
  getSupabaseClient: jest.fn(() => mockSupabaseClient),
  __esModule: true,
}));

jest.mock('@/lib/supabase/admin', () => ({
  getSupabaseAdmin: jest.fn(() => mockSupabaseClient),
  __esModule: true,
}));

// Mock DOMPurify
jest.mock('dompurify', () => ({
  sanitize: jest.fn((input) => input), // Simple passthrough for tests
  __esModule: true,
  default: {
    sanitize: jest.fn((input) => input),
  },
}));

// Mock Privy
const mockPrivyClient = {
  verifyAuthToken: jest.fn().mockResolvedValue({
    userId: 'test-user',
    appId: 'test-privy-app-id',
  }),
  getUser: jest.fn().mockResolvedValue({
    id: 'test-user',
    email: 'test@example.com',
  }),
};

jest.doMock('@privy-io/server-auth', () => ({
  PrivyClient: jest.fn(() => mockPrivyClient),
  __esModule: true,
}));

// Mock Next.js router
jest.mock('next/navigation', () => ({
  useRouter: () => ({
    push: jest.fn(),
    replace: jest.fn(),
    back: jest.fn(),
    forward: jest.fn(),
    refresh: jest.fn(),
    prefetch: jest.fn(),
  }),
  usePathname: () => '/',
  useSearchParams: () => new URLSearchParams(),
}));

// Mock environment variables
process.env.NODE_ENV = 'test';
process.env.NEXT_PUBLIC_SUPABASE_URL = 'https://test.supabase.co';
process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = 'test-anon-key';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'test-service-role-key';
process.env.NEXT_PUBLIC_PRIVY_APP_ID = 'test-privy-app-id';
process.env.PRIVY_APP_SECRET = 'test-privy-secret';

// Global test utilities
global.ResizeObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));

// Mock TextEncoder/TextDecoder for Web APIs
const { TextEncoder, TextDecoder } = require('util');
global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder;

// Mock Blob and URL for file operations
global.Blob = Blob;
global.URL = URL;

// Mock performance API
global.performance = {
  mark: jest.fn(),
  measure: jest.fn(),
  getEntriesByName: jest.fn(() => [{ duration: 100 }]),
  now: jest.fn(() => Date.now()),
};

// Mock IntersectionObserver
global.IntersectionObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn(),
}));

// Setup DOM container for React Testing Library
// Guard for node environment (tests with @jest-environment node)
beforeEach(() => {
  // Create a proper DOM container for React components
  if (typeof document !== 'undefined') {
    document.body.innerHTML = '<div id="root"></div>';
  }
});

afterEach(() => {
  // Cleanup DOM after each test
  if (typeof document !== 'undefined') {
    document.body.innerHTML = '';
  }
});

// Suppress console errors in tests
const originalError = console.error;
beforeAll(() => {
  console.error = (...args) => {
    if (
      typeof args[0] === 'string' &&
      args[0].includes('Warning: ReactDOM.render is no longer supported')
    ) {
      return;
    }
    originalError.call(console, ...args);
  };
});

afterAll(() => {
  console.error = originalError;
});

// Mock nanoid for ES module compatibility
jest.doMock('nanoid', () => ({
  nanoid: jest.fn(
    () => 'test-nanoid-token-' + Math.random().toString(36).substr(2, 9)
  ),
  __esModule: true,
  default: jest.fn(() => 'test-nanoid-default'),
}));

// Mock sonner (toast library)
jest.doMock('sonner', () => ({
  toast: {
    success: jest.fn(),
    error: jest.fn(),
    warning: jest.fn(),
    info: jest.fn(),
  },
  __esModule: true,
}));

// Mock jose (JWT library)
jest.doMock('jose', () => ({
  jwtVerify: jest.fn(),
  SignJWT: jest.fn(),
  __esModule: true,
}));
