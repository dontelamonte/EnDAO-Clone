# Privacy Policy

**Last Updated: August 14, 2025**

## Introduction

EnDAO ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our decentralized autonomous organization (DAO) platform.

## Information We Collect

### Information You Provide

- **Account Information**: Email address, username, and profile information
- **Wallet Information**: Public wallet addresses (we never store private keys)
- **DAO Information**: DAOs you create or join, proposals, and voting records
- **Communications**: Feedback, support requests, and other communications

### Information Automatically Collected

- **Usage Data**: How you interact with our platform
- **Device Information**: Browser type, operating system, and device identifiers
- **Log Data**: IP address, access times, and pages viewed

## How We Use Your Information

We use your information to:

- Provide and maintain our services
- Process transactions and manage DAOs
- Send administrative information and updates
- Respond to inquiries and provide support
- Improve our platform and develop new features
- Comply with legal obligations

## Blockchain Data

Please note that transactions on the blockchain are public and permanent. This includes:

- DAO creation and membership
- Proposals and voting records
- Treasury transactions

We cannot delete or modify blockchain data once it has been recorded.

## Data Security

We implement appropriate technical and organizational security measures to protect your information. However, no method of transmission over the Internet or electronic storage is 100% secure.

## Third-Party Services

We use the following third-party services:

- **Privy**: For wallet authentication
- **Supabase**: For data storage (PostgreSQL)
- **Gnosis Safe**: For treasury management
- **Vercel**: For hosting

These services have their own privacy policies governing the use of your information.

## Your Rights

You have the right to:

- Access your personal information
- Correct inaccurate data
- Request deletion of your data (except blockchain data)
- Opt-out of certain communications
- Export your data

## Children's Privacy

Our services are not intended for users under 18 years of age. We do not knowingly collect information from children under 18.

## International Data Transfers

Your information may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place for such transfers.

## Changes to This Policy

We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.

## Contact Us

If you have questions about this Privacy Policy, please contact us at:

- Email: privacy@endao.ai
- Website: https://endao.ai

## Legal Basis for Processing

We process your personal information based on:

- Your consent
- Performance of a contract
- Compliance with legal obligations
- Our legitimate interests

## Data Retention

We retain your information for as long as necessary to provide our services and fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required by law.

## Cookie Policy

We use cookies and similar tracking technologies to track activity on our platform and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.

## California Privacy Rights

California residents have additional rights under the California Consumer Privacy Act (CCPA), including the right to know what personal information we collect and the right to opt-out of the sale of personal information (which we do not sell).

## European Privacy Rights

If you are in the European Economic Area (EEA), you have additional rights under the General Data Protection Regulation (GDPR), including the right to data portability and the right to lodge a complaint with a supervisory authority.

---

By using EnDAO, you agree to the collection and use of information in accordance with this Privacy Policy.
