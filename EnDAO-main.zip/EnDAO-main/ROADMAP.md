# EnDAO Product Roadmap

**Last Updated**: December 6, 2025 (Roadmap Split: Platform + Token)

This document provides strategic context and navigation for the EnDAO roadmap. For detailed feature specifications, see the split roadmaps below.

---

## Strategic Context

**Vision**: EnDAO as the institutional DAO layer for business—not just organizations managing themselves, but the **connective rails between organizations**. We make decentralized governance accessible to mainstream organizations—HOAs, investment clubs, nonprofits, and cooperatives—without requiring crypto expertise.

**Current Focus**: Platform capability and user experience. Build features that deliver immediate value to existing users before introducing token economics.

**Key Strategic Initiatives**:

- **Platform Maturity**: Social recovery, spending controls, mobile access
- **User Engagement**: Discussion/deliberation system, pro/con arguments, in-app notifications, email participation, quick polls
- **User Experience**: Template-based onboarding, plain language, education, implementation tracking
- **Revenue Generation**: Tiered subscriptions, API access
- **Mobile Companion**: Voting, notifications, on-the-go engagement (Parallel Tracks strategy - see Appendix C in PLATFORM_ROADMAP.md)
- **Civic Tech Integration**: Toxicity-prevention design, outcome statements, participatory budgeting (OGP research synthesis)
- **Future Token Economics**: EDG governance, TCR payments, TEQ labor equity (Phase 3+)

**Revenue Philosophy**: "Utility, not rent seeking"

- Provide genuine value through platform capabilities
- **The Portability Test**: If a DAO leaves EnDAO, can they take their governance history, treasury records, and member data easily? If yes → utility. If no → rent seeking.
- Core features free, infrastructure costs covered by premium services

**Historical Reference**: For detailed technical specifications from early platform design (smart contracts, database schemas, API specs), see [`MASTER_IMPLEMENTATION_SPEC.md`](docs/MASTER_IMPLEMENTATION_SPEC.md). This document is preserved as a reference but has been superseded by the split roadmaps above. Validate assumptions against current roadmaps before implementation.

---

## Current Status

**Version**: 2.2.0 (Treasury Protection System + Enhanced Security)
**Live Production**: [endao.ai](https://endao.ai)

### Recently Completed

- Treasury Protection System with 4-layer security architecture
- Grace period deletion mechanism (7-day recovery window)
- Emergency recovery system for super admin operations
- Platform revenue collection infrastructure on Base Mainnet
- Bounty proposal system with treasury execution
- Monorepo architecture prepared (on `feature/mobile-app` branch)

---

## Roadmap Structure

EnDAO's development roadmap is split into two parallel tracks:

### Platform Roadmap

**[`PLATFORM_ROADMAP.md`](PLATFORM_ROADMAP.md)** - Core governance features and user experience

The Platform Roadmap covers all features that make EnDAO a best-in-class governance platform for mainstream organizations. This is the primary development focus and includes:

- **Tier 0: Foundation** (Live) - Basic DAO creation, proposals, voting, treasury
- **Tier 1: Single DAO Excellence** (Q1-Q2 2026) - Social recovery, spending controls, mobile access, discussion/deliberation, templates, subscriptions
- **Tier 2: Operational Maturity** (Q2-Q3 2026) - Advanced voting, API, email participation, outcome tracking
- **Tier 3: Network Foundation** (Q3-Q4 2026) - Sub-DAOs, DAO-to-DAO relationships, analytics
- **Tier 4: Enterprise Federation** (2027+) - White-label, regulatory compliance, NLP assistance

**Guiding Principle**: Build features that deliver immediate value to existing users before introducing token economics.

### Token Roadmap

**[`TOKEN_ROADMAP.md`](TOKEN_ROADMAP.md)** - Economic primitives and token-based features

The Token Roadmap covers all token-based features and economic mechanisms. Token development is deferred until platform maturity is achieved:

- **Phase 0: Revenue Infrastructure** (Live) - Platform fee collection on Base Mainnet
- **Phase 1: EDG Governance** (Q3 2026) - Protocol governance token with fee discounts
- **Phase 2: TCR Payment** (Q3-Q4 2026) - Stablecoin-pegged utility token for marketplace payments
- **Phase 3: TEQ Labor Equity** (Q4 2026+) - Soulbound equity token earned through verified labor

**Guiding Principle**: Token features require platform stability, user adoption, and regulatory clarity before implementation.

---

## Navigation Guide

### When to Consult Each Roadmap

**Use PLATFORM_ROADMAP.md when:**

- Planning governance feature development
- Prioritizing user experience improvements
- Reviewing subscription/revenue features
- Coordinating mobile app development
- Evaluating civic tech integrations

**Use TOKEN_ROADMAP.md when:**

- Reviewing token economics architecture
- Planning smart contract development
- Evaluating marketplace features
- Assessing regulatory compliance needs
- Coordinating token launches

### Roadmap Tier/Phase Overview

| Roadmap  | Current Tier/Phase  | Focus                                 |
| -------- | ------------------- | ------------------------------------- |
| Platform | Tier 1 (Q1-Q2 2026) | Security, mobile access, deliberation |
| Token    | Phase 0 (Live)      | Revenue infrastructure operational    |

---

## Technical Debt & Infrastructure

See PLATFORM_ROADMAP.md for detailed technical debt tracking.

### Quick Summary

The technical debt items listed below are tracked in detail within PLATFORM_ROADMAP.md:

- Reduce TypeScript `no-explicit-any` warnings (371 remaining, down from 634)
- Add missing tests for treasury services
- Consolidate toast implementations
- Optimize Firestore indexes

### Architectural Optionality

- **Repository Pattern**: All data access through `src/lib/repositories/` abstracts Firestore
- **Purpose**: Preserves future optionality for database migration (PostgreSQL/Supabase) without current investment
- **White-Label Ready**: Abstracted data layer supports multi-tenant branded deployments
- **Portability Test Alignment**: Clean abstractions enable easier data export

---

## How to Request Features

Feature requests are reviewed quarterly and prioritized based on user impact, strategic alignment, technical complexity, and revenue potential.

See individual roadmaps (PLATFORM_ROADMAP.md or TOKEN_ROADMAP.md) for feature request processes specific to each track.

---

## Version History

**v2.2.0** (Sep 2025) - Treasury Protection System
**v2.1.0** (Aug 2025) - Platform Revenue System
**v2.0.0** (Jul 2025) - Ethers v6 Migration
**v1.0.0** (Jun 2025) - Initial Production Launch

---

_For detailed feature specifications and implementation plans, see PLATFORM_ROADMAP.md and TOKEN_ROADMAP.md_
