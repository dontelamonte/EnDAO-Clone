import type { NextConfig } from 'next';
import path from 'path';
import { withSentryConfig } from '@sentry/nextjs';

const nextConfig: NextConfig = {
  // Externalize native modules that shouldn't be bundled
  serverExternalPackages: ['sharp'],

  // PostHog reverse proxy configuration
  async rewrites() {
    return [
      {
        source: '/ingest/static/:path*',
        destination: 'https://us-assets.i.posthog.com/static/:path*',
      },
      {
        source: '/ingest/:path*',
        destination: 'https://us.i.posthog.com/:path*',
      },
    ];
  },
  // Required for PostHog trailing slash API requests
  skipTrailingSlashRedirect: true,

  // Performance optimizations
  compress: true,
  poweredByHeader: false,

  // Enable strict mode for better debugging
  reactStrictMode: true,

  // Generate source maps for Sentry error tracking (hidden from browsers by Sentry)
  productionBrowserSourceMaps: true,

  // Code splitting optimizations
  experimental: {
    // Temporarily disable CSS optimization until critters is installed
    // optimizeCss: true,
    optimizePackageImports: ['lucide-react', '@radix-ui/react-*', 'date-fns'],
  },

  // Suppress hydration errors for known third-party component issues (like Privy)
  compiler: {
    // Temporarily disable console removal to debug Vercel deployment
    removeConsole: false,
  },

  // Bundle analyzer (uncomment to analyze bundle size)
  webpack: (config, { isServer }) => {
    // Fix webpack cache directory to use absolute path
    const cacheDir = path.resolve(process.cwd(), '.next/cache/webpack');
    config.cache = {
      type: 'filesystem',
      cacheDirectory: cacheDir,
    };

    // Externalize sharp and its native dependencies on server
    if (isServer) {
      config.externals = config.externals || [];
      config.externals.push({
        sharp: 'commonjs sharp',
      });
    }

    // Ignore sharp's optional native dependencies that cause build issues
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const webpack = require('webpack');
    config.plugins.push(
      new webpack.IgnorePlugin({
        resourceRegExp: /^@img\/sharp-libvips-dev$/,
      }),
      new webpack.IgnorePlugin({
        resourceRegExp: /^@img\/sharp-wasm32$/,
      })
    );

    if (process.env.ANALYZE === 'true') {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
      config.plugins.push(
        new BundleAnalyzerPlugin({
          analyzerMode: 'static',
          reportFilename: isServer
            ? '../analyze/server.html'
            : './analyze/client.html',
        })
      );
    }

    // Prevent server-only modules from being bundled on client
    if (!isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        net: false,
        tls: false,
        http2: false,
        child_process: false,
      };
    }

    // Ignore optional @react-email/render dependency from resend
    config.resolve.alias = {
      ...config.resolve.alias,
      '@react-email/render': false,
    };

    return config;
  },

  eslint: {
    // Temporarily ignore ESLint errors to unblock deployment and debug blank screen
    ignoreDuringBuilds: true,
  },
  typescript: {
    // Temporarily ignore TypeScript errors during build
    // This is needed due to React 19 type compatibility issues with some components
    // TODO: Fix component types and remove this
    ignoreBuildErrors: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.pexels.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.pixabay.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'randomuser.me',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'via.placeholder.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'api.dicebear.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'qwxfttvzngivqmobfaxn.supabase.co',
        port: '',
        pathname: '/storage/v1/object/public/**',
      },
    ],
    dangerouslyAllowSVG: true,
    contentDispositionType: 'attachment',
    contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
  },
  turbopack: {
    resolveExtensions: ['.tsx', '.ts', '.jsx', '.js', '.mjs', '.json'],
  },
  // Transpile packages that have issues with Turbopack or are workspace packages
  transpilePackages: ['@biconomy/abstractjs', '@endao/shared-types'],
};

// Export configuration with Sentry
export default withSentryConfig(nextConfig, {
  // For all available options, see:
  // https://www.npmjs.com/package/@sentry/webpack-plugin#options

  org: 'endao',

  project: 'javascript-nextjs',

  // Only print logs for uploading source maps in CI
  silent: !process.env.CI,

  // For all available options, see:
  // https://docs.sentry.io/platforms/javascript/guides/nextjs/manual-setup/

  // Upload a larger set of source maps for prettier stack traces (increases build time)
  widenClientFileUpload: true,

  // Source map upload configuration
  sourcemaps: {
    // Delete source maps after upload (security best practice)
    // This removes source maps from the production build so they're not publicly accessible
    deleteSourcemapsAfterUpload: true,
  },

  // Route browser requests to Sentry through a Next.js rewrite to circumvent ad-blockers.
  // This can increase your server load as well as your hosting bill.
  // Note: Check that the configured route will not match with your Next.js middleware, otherwise reporting of client-
  // side errors will fail.
  tunnelRoute: '/monitoring',

  webpack: {
    // Enables automatic instrumentation of Vercel Cron Monitors. (Does not yet work with App Router route handlers.)
    // See the following for more information:
    // https://docs.sentry.io/product/crons/
    // https://vercel.com/docs/cron-jobs
    automaticVercelMonitors: true,

    // Tree-shaking options for reducing bundle size
    treeshake: {
      // Automatically tree-shake Sentry logger statements to reduce bundle size
      removeDebugLogging: true,
    },
  },
});
