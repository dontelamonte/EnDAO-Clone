import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright configuration for UX testing
 * Optimized for Core Web Vitals and user experience validation
 */
export default defineConfig({
  testDir: './tests',

  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,

  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,

  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,

  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: process.env.CI
    ? [['github'], ['html']]
    : [['list'], ['html', { open: 'never' }]],

  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    baseURL: process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:3000',

    /* Collect trace when retrying the failed test. */
    trace: 'on-first-retry',

    /* Take screenshot on failure */
    screenshot: 'only-on-failure',

    /* Record video on failure */
    video: 'retain-on-failure',

    /* Timeout for each action (increased for slow-loading DAO pages) */
    actionTimeout: 60000,

    /* Navigation timeout (increased for slow Next.js compilations) */
    navigationTimeout: 60000,
  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        // Enable experimental performance metrics
        launchOptions: {
          args: ['--enable-experimental-web-platform-features'],
        },
      },
    },

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },

    /* Mobile testing */
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    },

    /* Tablet testing */
    {
      name: 'Desktop Large',
      use: {
        viewport: { width: 1920, height: 1080 },
      },
    },
  ],

  /* Global setup and teardown */
  globalSetup: './tests/global-setup.ts',
  globalTeardown: './tests/global-teardown.ts',

  /* Run your local dev server before starting the tests */
  webServer: process.env.CI
    ? undefined
    : {
        command: 'yarn dev',
        url: 'http://localhost:3000',
        reuseExistingServer: !process.env.CI,
        timeout: 120 * 1000, // 2 minutes
      },

  /* Test timeout */
  timeout: 60 * 1000, // 1 minute per test

  /* Expect timeout - stricter for strengthened tests */
  expect: {
    timeout: 10 * 1000, // 10 seconds for assertions (increased from 5s for reliable testing)
  },

  /* Fail entire suite on first failures during development */
  maxFailures: process.env.CI ? undefined : 5,

  /* Output directory for test results */
  outputDir: 'test-results/',

  /* Test match patterns */
  testMatch: ['**/tests/**/*.spec.ts', '**/tests/**/*.test.ts'],

  /* Global test ignore patterns */
  testIgnore: [
    '**/node_modules/**',
    '**/build/**',
    '**/.next/**',
    '**/dist/**',
  ],
});
