# EnDAO Engineering Guide

**Stack**: Next.js 15, React 19, Supabase/PostgreSQL, Privy, Gnosis Safe | **Mobile**: Expo (React Native) | **Status**: Production | **Live**: [endao.ai](https://endao.ai)

**Vision**: Shared money today, sovereign networks tomorrow — governance infrastructure scaling from community groups to enterprise networks.

**Monorepo**: `apps/web` (Next.js), `apps/mobile` (Expo), `packages/shared-types` (TypeScript types)

---

## Critical Rules

### Feature Completeness (MANDATORY)

**Every UI feature MUST be fully connected end-to-end.** Do not create:

- UI components that only update local state without persistence
- Form fields that aren't connected to API routes
- Settings/toggles that don't actually save to the database
- Backend services without corresponding UI to trigger them

**Before marking a feature complete, verify:**

1. **Database** - Column/table exists in migrations, types match
2. **API Route** - Endpoint exists, validation schema includes fields
3. **Service Layer** - Service handles the operation, maps fields correctly
4. **UI Component** - Calls API (not service directly), handles loading/error states
5. **Persistence** - Changes survive page refresh
6. **Feedback** - User sees success/error toast or indication

**Example Checklist for a new "Profile Visibility" setting:**

```
□ Migration adds `profile_visibility` column to users table
□ `UserProfileInput` type includes `profileVisibility` field
□ `userProfileUpdateSchema` validation allows the field
□ `/api/user/profile` PATCH route processes the field
□ `UserProfileCrudService` maps and saves the field
□ UI component calls API via CSRF hook (not service directly)
□ Auto-save or explicit save button triggers API call
□ Toast confirms save success/failure
□ Value persists after page refresh
```

### Development Tracker (MANDATORY)

**Single Source of Truth**: `docs/development/DEVELOPMENT_TRACKER.md`

**ALWAYS update the tracker when:**

1. **Starting a feature** — Move from "Next Up" to "In Progress"
2. **Completing a feature** — Move to "Complete" section with verification
3. **Discovering new work** — Add to "Next Up" or "Backlog"
4. **Finding partial implementations** — Add to "Partial / Schema Only" section

**Update Format:**

```markdown
| Feature Name | ✅ | 0XX | Brief notes about implementation |
```

**Do NOT update these documents for status:**

- `PLATFORM_ROADMAP.md` — Vision only, not status
- `PLATFORM_AUDIT.md` — Periodic snapshot, regenerated from tracker

**Failure to update the tracker after implementing features will cause documentation drift and confusion.**

### Documentation Structure

| Location | Purpose |
| -------- | ------- |
| `docs/` | Slim, actionable docs (stay in repo) |
| `obsidian/` | Extended notes, design exploration, session logs (gitignored) |

**Workflow**: Extended thinking in Obsidian → slim summaries in `/docs` when decisions are made.

### Debug Code Cleanup (MANDATORY)

**Always remove debugging code once a solution is implemented:**

- Remove `console.log` statements added for debugging
- Remove temporary test endpoints or routes
- Remove commented-out code used for troubleshooting
- Clean up any hardcoded test values

**Before committing a fix, verify no debug artifacts remain.** Debug code in production clutters logs and can leak sensitive information.

### Memory & Type Safety

```bash
NODE_OPTIONS='--max-old-space-size=8192'  # Required for build/type-check
```

- **0 TypeScript/ESLint errors** - maintain zero, fix incrementally
- ~371 `no-explicit-any` warnings - fix in files you touch (Boy Scout Rule)
- **No zombie code** - modify in place, use git history

### Type Patterns (CRITICAL)

**ServiceResponse Discriminated Union** - The response type is mutually exclusive:

```typescript
type ServiceResponse<T> =
  | { success: true; data: T }
  | { success: false; error: string; code: ErrorCode };
```

**WRONG** - Combining checks breaks type narrowing:
```typescript
if (!result.success || !result.data) {
  return { error: result.error || 'Failed' }; // TS error: can't access .error
}
```

**CORRECT** - Separate checks:
```typescript
if (!result.success) {
  return { error: result.error, code: result.code }; // TS knows .error exists
}
if (!result.data) {
  return { error: 'No data', code: 'NOT_FOUND' }; // TS knows .data doesn't exist
}
// Now TS knows result.data exists
```

**Supabase Type Fixes** - When tables aren't in generated types:
```typescript
// Cast .from() to any, NOT the update data
const { data, error } = await (supabase.from('my_table') as any)
  .update({ field: value })
  .eq('id', id);
```

**Error Returns** - Always include `code` from `ErrorCode` type:
```typescript
return { success: false, error: 'Message', code: 'INTERNAL_ERROR' };
```

### Commands

| Command           | Purpose               |
| ----------------- | --------------------- |
| `yarn dev`        | Dev server            |
| `yarn build`      | Production build      |
| `yarn type-check` | TypeScript (8GB heap) |
| `yarn test`       | Jest unit tests       |
| `yarn test:e2e`   | Playwright E2E        |
| `yarn seed`       | Seed test data        |

**Mobile** (from `apps/mobile/`): `yarn start`, `yarn ios`, `yarn android`

---

## Architecture

### Shared Types

Import from `@endao/shared-types` (NOT `@/types/*`). Package: `packages/shared-types/src/`.

**Core Types**: `DAOCategory`, `OrganizationType`, `DAOTag`, `DAOJoinPermission`, `OnboardingState`, `UserProfile`, `UserProfileInput`

### Data Flow Patterns

**Browser-Safe Pattern (Critical)**:

```typescript
// ❌ Browser code CANNOT call services directly
const result = await DAOService.getInstance().updateDAO(daoId, data, userId);

// ✅ Use hooks that call API routes
import { useDAO } from '@/hooks/use-dao';
const { dao, loading, error } = useDAO(daoId);

// ✅ CSRF-protected API calls for mutations
import { useCSRFAPI } from '@/lib/hooks/use-csrf';
const csrfApi = useCSRFAPI();
await csrfApi.call('/api/user/profile', {
  method: 'PATCH',
  body: JSON.stringify(data),
});
```

**Full Stack Flow**:

```
UI Component → Hook → API Route → Service → Repository → Supabase
     ↑                                                      ↓
     └──────────────── Response ←───────────────────────────┘
```

### Repository Pattern

**Location**: `src/lib/data/repositories/` - `{entity}Repository` (client/RLS), `{entity}AdminRepository` (server/bypass RLS)

### Service Layer

**Location**: `src/lib/services/` - extends `BaseService`, returns `ServiceResponse<T>`

**Key Services**: Treasury, Admin, DAO, Proposal, Notification, User

### On-Chain Infrastructure

**Merkle Voting** - Cryptographic proof of votes posted to Base L2:
- **Services**: `MerkleTreeBuilderService`, `MerkleProofService`, `MerkleRootPostingService`
- **API**: `POST /api/proposals/[proposalId]/merkle-proof`

### Mobile Architecture

**Critical**: Mobile app NEVER directly accesses Supabase or service layer.
**Data Flow**: `Mobile App → API Routes (/api/mobile/v1/*) → Service Layer → Supabase`

---

## Key Patterns

### Auto-Save Pattern

For settings that should save automatically (notifications, privacy):

```typescript
const [hasChanges, setHasChanges] = useState(false);
const isInitialMount = useRef(true);

useEffect(() => {
  if (isInitialMount.current) {
    isInitialMount.current = false;
    return;
  }
  if (!hasChanges) return;

  const timer = setTimeout(async () => {
    await csrfApi.call('/api/...', {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
    setHasChanges(false);
    toast({ title: 'Saved' });
  }, 1000); // 1s debounce

  return () => clearTimeout(timer);
}, [hasChanges /* dependencies */]);
```

### React/Next.js Patterns

- Default to RSC, `"use client"` only when needed
- Hooks BEFORE early returns (Rules of Hooks)
- **Debouncing**: 300ms search, 500ms validation, 1000ms auto-save

### Supabase Patterns

- **Client**: `getSupabaseClient()` (browser, RLS)
- **Admin**: `getSupabaseAdmin()` (server only, bypasses RLS)

---

## Security

### Treasury Protection

| Layer              | Purpose                                           |
| ------------------ | ------------------------------------------------- |
| 1. Status          | Blocks archived/deleted DAOs                      |
| 2. Freeze          | `TreasuryAccessControlService` gates transactions |
| 3. Grace Period    | 7-day delay on critical changes                   |
| 4. Execution Locks | `TreasuryExecutionLockService` prevents races     |

### Auth

- **Privy**: Headers `x-auth-uid`, `x-auth-privy-id`, `x-auth-email`, `x-auth-wallet`
- **Validation**: `SecurityValidator.validate(schema, data, { sanitize: true, checkSqlInjection: true, checkXss: true })`

---

## Testing

| Type        | Location             | Purpose                     |
| ----------- | -------------------- | --------------------------- |
| Unit        | `__tests__/`         | Service logic, repositories |
| E2E         | `tests/e2e/`         | Critical user flows         |
| Integration | `tests/integration/` | API routes, database        |

**E2E Setup**: `yarn seed`, Test DAO: `test-tech-innovators`

### Real Tests Only (MANDATORY)

**All tests MUST import and test actual code.** No stub tests allowed.

```typescript
// ❌ BAD - Stub test (tests nothing real)
it('should validate slug', () => {
  const isValid = (s: string) => /^[a-z]+$/.test(s); // Local function!
  expect(isValid('test')).toBe(true);
});

// ✅ GOOD - Tests actual validation schema
import { daoCreateSchema } from '@/lib/validations/api';
it('should validate slug', () => {
  const result = daoCreateSchema.safeParse({ slug: 'invalid--slug' });
  expect(result.success).toBe(false);
});
```

**Every test file MUST have imports from the codebase** (`@/...` or relative imports to actual code).

**Check for stub tests**: `npx tsx scripts/check-stub-tests.ts`

---

## Standards

### File Size Limits (Enforced by CI)

| Threshold  | Action        |
| ---------- | ------------- |
| ≤300 lines | Target        |
| >500 lines | Warning       |
| >800 lines | **Blocks PR** |

### Code Style

- **Formatting**: Prettier, no semicolons, single quotes
- **Naming**: Directories `kebab-case`, Components `PascalCase`, Hooks `camelCase`

### Never Commit

- `node_modules/`, `.next/`, `.env.local`

---

## ADRs (Consult Before Modifying)

| ADR     | Governs                                           |
| ------- | ------------------------------------------------- |
| ADR-001 | Core patterns (repository, service, browser-safe) |
| ADR-002 | Ethers.js wrapper                                 |
| ADR-003 | Safe/treasury wrapper                             |
| ADR-004 | Privy auth wrapper                                |
| ADR-005 | Voting plugin architecture                        |

**Location**: `docs/architecture/decisions/`

---

## UI/UX

- **Web**: Shadcn UI + Tailwind, `lucide-react` icons only
- **Mobile**: React Native StyleSheet, emoji icons, dark theme (slate palette)

### Target User Persona

**Primary Audience**: Crypto-skeptic users from traditional organizations

**Design Principles**:

1. **Familiar analogies**: Treasury → "Shared bank account", Multi-sig → "2-of-3 board approval"
2. **Jargon-free defaults**: Avoid crypto terminology
3. **Progressive disclosure**: Basic explanation upfront, "Learn more" for details

---

## Dependencies

- **Ethers.js**: v6.15.0 + Safe Protocol Kit v4 (DO NOT downgrade)
- **Mobile**: Expo ~52.0, React Native 0.76.6
