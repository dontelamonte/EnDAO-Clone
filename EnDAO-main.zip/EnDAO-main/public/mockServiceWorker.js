/* eslint-disable */
/* tslint:disable */

/**
 * Mock Service Worker (2.6.1).
 * @see https://github.com/mswjs/msw
 * - Please do NOT modify this file.
 * - Please do NOT serve this file on production.
 */

const INTEGRITY_CHECKSUM = '0180cd8a3f9e57a65073d4b13eff7a47';
const IS_MOCKED_RESPONSE = Symbol('isMockedResponse');
const activeClientIds = new Set();

self.addEventListener('install', function () {
  self.skipWaiting();
});

self.addEventListener('activate', function (event) {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('message', async function (event) {
  const clientId = event.source.id;

  if (!clientId || !event.data) {
    return;
  }

  const allClients = await self.clients.matchAll({
    type: 'window',
  });

  switch (event.data.type) {
    case 'MOCK_ACTIVATE': {
      activeClientIds.add(clientId);

      sendToClient(clientId, {
        type: 'MOCKING_ENABLED',
        payload: true,
      });
      break;
    }

    case 'MOCK_DEACTIVATE': {
      activeClientIds.delete(clientId);
      break;
    }

    case 'INTEGRITY_CHECK_REQUEST': {
      sendToClient(clientId, {
        type: 'INTEGRITY_CHECK_RESPONSE',
        payload: INTEGRITY_CHECKSUM,
      });
      break;
    }

    case 'KEEPALIVE_REQUEST': {
      sendToClient(clientId, {
        type: 'KEEPALIVE_RESPONSE',
        payload: {
          msw: {
            workerScript: {
              resolved: true,
              placed: Boolean(
                allClients.find(
                  (client) => client.url === event.data.payload.scriptURL
                )
              ),
              loadedClients: allClients.map((client) => ({
                frameType: client.frameType,
                id: client.id,
                type: client.type,
                url: client.url,
                visibilityState: client.visibilityState,
              })),
            },
          },
        },
      });
      break;
    }
  }
});

function sendToClient(clientId, message) {
  return new Promise((resolve, reject) => {
    const channel = new MessageChannel();

    channel.port1.onmessage = (event) => {
      if (event.data.error) {
        return reject(event.data.error);
      }

      resolve(event.data);
    };

    self.clients.get(clientId).then((client) => {
      client.postMessage(message, [channel.port2]);
    });
  });
}

self.addEventListener('fetch', function (event) {
  const { clientId, request } = event;
  const requestId = crypto.randomUUID();

  return event.respondWith(
    handleRequest(event, requestId).catch((error) => {
      if (request.mode === 'cors' && request.redirect === 'follow') {
        return fetch(request);
      }

      console.error(
        '[MSW] Failed to mock a "%s" request to "%s": %s',
        request.method,
        request.url,
        error
      );
    })
  );

  async function handleRequest(event, requestId) {
    const client = await self.clients.get(event.clientId);

    if (!client) {
      return fetch(event.request);
    }

    const isActiveClient = activeClientIds.has(event.clientId);

    if (!isActiveClient) {
      return fetch(event.request);
    }

    const clonedRequest = event.request.clone();
    const callFrame = await getRequestCallFrame(clonedRequest);

    sendToClient(event.clientId, {
      type: 'REQUEST',
      payload: {
        id: requestId,
        url: clonedRequest.url,
        method: clonedRequest.method,
        headers: Object.fromEntries(clonedRequest.headers.entries()),
        cache: clonedRequest.cache,
        mode: clonedRequest.mode,
        credentials: clonedRequest.credentials,
        destination: clonedRequest.destination,
        integrity: clonedRequest.integrity,
        redirect: clonedRequest.redirect,
        referrer: clonedRequest.referrer,
        referrerPolicy: clonedRequest.referrerPolicy,
        body: await clonedRequest.text(),
        bodyUsed: clonedRequest.bodyUsed,
        keepalive: clonedRequest.keepalive,
        callFrame,
      },
    });

    const responsePromise = getResponse(event, client, requestId);

    const response = await responsePromise;

    return response;
  }

  async function getResponse(event, client, requestId) {
    return new Promise((resolve, reject) => {
      const channel = new MessageChannel();

      channel.port1.onmessage = (event) => {
        if (event.data.error) {
          reject(new Error(event.data.error));
        } else {
          resolve(event.data);
        }
      };

      client.postMessage(
        {
          type: 'REQUEST',
          payload: {
            id: requestId,
          },
        },
        [channel.port2]
      );
    }).then(async (message) => {
      switch (message.type) {
        case 'MOCK_RESPONSE': {
          return respondWithMock(message.data);
        }

        case 'MOCK_NOT_FOUND': {
          return fetch(event.request);
        }

        case 'NETWORK_ERROR': {
          const { name, message } = message.data;
          const networkError = new Error(message);
          networkError.name = name;

          // Reject the request promise with the emulated network error
          // so that the consumer can react to the emulated error.
          throw networkError;
        }
      }

      return fetch(event.request);
    });
  }

  async function respondWithMock(response) {
    // Setting response status code to 0 is not supported.
    // See: https://developer.mozilla.org/en-US/docs/Web/API/Response/Response#status
    if (response.status === 0) {
      response.status = 200;
    }

    const mockedResponse = new Response(response.body, response);

    Reflect.defineProperty(mockedResponse, IS_MOCKED_RESPONSE, {
      value: true,
      enumerable: true,
    });

    return mockedResponse;
  }
});

async function getRequestCallFrame(request) {
  const requestClone = request.clone();
  const callStackTrace = new Error().stack;

  return callStackTrace;
}
