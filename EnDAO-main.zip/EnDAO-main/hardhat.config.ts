import { HardhatUserConfig } from 'hardhat/config';
import '@nomicfoundation/hardhat-ethers';
import '@nomicfoundation/hardhat-verify';
import * as dotenv from 'dotenv';
import * as path from 'path';

// Load multiple env files
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });
dotenv.config({ path: path.resolve(process.cwd(), '.env.safe') });
dotenv.config(); // Load default .env

// Ensure required environment variables are set
const DEPLOYER_PRIVATE_KEY =
  process.env.DEPLOYER_PRIVATE_KEY ||
  process.env.SAFE_DEPLOYER_PRIVATE_KEY ||
  '0x0000000000000000000000000000000000000000000000000000000000000000';
const ENDAO_SAFE_ADDRESS = process.env.ENDAO_SAFE_ADDRESS || '';
const BASESCAN_API_KEY = process.env.BASESCAN_API_KEY || '';

// Warning if critical env vars are missing
if (
  !process.env.DEPLOYER_PRIVATE_KEY &&
  process.env.NODE_ENV === 'production'
) {
  console.warn('⚠️  DEPLOYER_PRIVATE_KEY is not set in environment variables');
}

const config: HardhatUserConfig = {
  solidity: {
    version: '0.8.24',
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
      // viaIR: true, // Not supported in Hardhat 2.x
    },
  },
  networks: {
    // Local development
    hardhat: {
      chainId: 31337,
    },
    localhost: {
      url: 'http://127.0.0.1:8545',
    },
    // Base Sepolia (Testnet)
    'base-sepolia': {
      url: 'https://sepolia.base.org',
      accounts:
        DEPLOYER_PRIVATE_KEY !==
        '0x0000000000000000000000000000000000000000000000000000000000000000'
          ? [DEPLOYER_PRIVATE_KEY]
          : [],
      chainId: 84532,
    },
    // Base Mainnet
    base: {
      url: 'https://mainnet.base.org',
      accounts:
        DEPLOYER_PRIVATE_KEY !==
        '0x0000000000000000000000000000000000000000000000000000000000000000'
          ? [DEPLOYER_PRIVATE_KEY]
          : [],
      chainId: 8453,
    },
  },
  sourcify: {
    enabled: true,
  },
  etherscan: {
    apiKey: {
      base: BASESCAN_API_KEY,
      'base-sepolia': BASESCAN_API_KEY,
    },
    customChains: [
      {
        network: 'base',
        chainId: 8453,
        urls: {
          apiURL: 'https://api.basescan.org/api',
          browserURL: 'https://basescan.org',
        },
      },
      {
        network: 'base-sepolia',
        chainId: 84532,
        urls: {
          apiURL: 'https://api-sepolia.basescan.org/api',
          browserURL: 'https://sepolia.basescan.org',
        },
      },
    ],
  },
  paths: {
    sources: './contracts',
    tests: './test',
    cache: './cache',
    artifacts: './artifacts',
  },
  // Gas reporter for optimization
  // @ts-expect-error gasReporter is from hardhat-gas-reporter plugin
  gasReporter: {
    enabled: process.env.REPORT_GAS === 'true',
    currency: 'USD',
    coinmarketcap: process.env.COINMARKETCAP_API_KEY,
    L2: 'base',
    L2Etherscan: BASESCAN_API_KEY,
  },
} as const;

export default config;
