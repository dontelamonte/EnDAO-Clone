#!/usr/bin/env node

/**
 * File Size Enforcement Script
 *
 * Scans all TypeScript and JavaScript files in src/ and counts lines.
 * Enforces file size thresholds to maintain code quality and readability.
 *
 * Thresholds:
 * - 300 lines: Info (target size)
 * - 500 lines: Warning (exceeds target)
 * - 800 lines: Error (blocks CI)
 *
 * Exit codes:
 * - 0: All files within acceptable limits
 * - 1: One or more files exceed 800 lines
 *
 * @example
 * node scripts/check-file-sizes.js
 */

const fs = require('fs');
const path = require('path');

// Configuration
const CONFIG = {
  targetDir: path.join(process.cwd(), 'src'),
  extensions: ['.ts', '.tsx', '.js', '.jsx'],
  excludeDirs: [
    'node_modules',
    '.next',
    'dist',
    'build',
    'out',
    '__tests__',
    'tests',
  ],
  // File patterns to exclude from size checks (auto-generated, test files)
  excludePatterns: [
    /supabase\/types\.ts$/, // Auto-generated Supabase types
    /\.test\.(ts|tsx|js|jsx)$/, // Unit test files
    /\.spec\.(ts|tsx|js|jsx)$/, // Spec test files
    /docs\/content\.tsx$/, // Auto-generated docs content
    /__tests__\//, // Any files in __tests__ directories
    /tests\//, // Any files in tests directories
  ],
  thresholds: {
    info: 300, // Target size
    warning: 500, // Exceeds target
    error: 800, // Blocks CI
  },
};

/**
 * Recursively finds all matching files in a directory
 * @param {string} dir - Directory to search
 * @param {string[]} extensions - File extensions to match
 * @param {string[]} excludeDirs - Directories to skip
 * @returns {string[]} Array of file paths
 */
function findFiles(dir, extensions, excludeDirs) {
  const files = [];

  function walk(currentDir) {
    try {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);

        if (entry.isDirectory()) {
          // Skip excluded directories
          if (!excludeDirs.includes(entry.name)) {
            walk(fullPath);
          }
        } else if (entry.isFile()) {
          // Check if file matches extensions
          const ext = path.extname(entry.name);
          if (extensions.includes(ext)) {
            files.push(fullPath);
          }
        }
      }
    } catch (error) {
      // Skip directories we can't read
      console.warn(
        `Warning: Cannot read directory ${currentDir}: ${error.message}`
      );
    }
  }

  walk(dir);
  return files;
}

/**
 * Counts lines in a file
 * @param {string} filePath - Path to file
 * @returns {number} Number of lines
 */
function countLines(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    // Count non-empty lines
    return content.split('\n').length;
  } catch (error) {
    console.warn(`Warning: Cannot read file ${filePath}: ${error.message}`);
    return 0;
  }
}

/**
 * Categorizes a file by line count
 * @param {number} lineCount - Number of lines
 * @returns {'ok' | 'info' | 'warning' | 'error'}
 */
function categorize(lineCount) {
  if (lineCount > CONFIG.thresholds.error) return 'error';
  if (lineCount > CONFIG.thresholds.warning) return 'warning';
  if (lineCount > CONFIG.thresholds.info) return 'info';
  return 'ok';
}

/**
 * Formats file path relative to project root
 * @param {string} filePath - Absolute file path
 * @returns {string} Relative path
 */
function formatPath(filePath) {
  return path.relative(process.cwd(), filePath);
}

/**
 * Checks if a file path matches any exclude pattern
 * @param {string} relativePath - Relative file path
 * @param {RegExp[]} patterns - Array of regex patterns to match against
 * @returns {boolean} True if file should be excluded
 */
function isExcluded(relativePath, patterns) {
  // Normalize path separators for cross-platform compatibility
  const normalizedPath = relativePath.replace(/\\/g, '/');
  return patterns.some((pattern) => pattern.test(normalizedPath));
}

/**
 * Main execution
 */
function main() {
  console.log('🔍 Checking file sizes...\n');

  // Find all files
  const files = findFiles(
    CONFIG.targetDir,
    CONFIG.extensions,
    CONFIG.excludeDirs
  );
  console.log(`Found ${files.length} files to check\n`);

  // Analyze files
  const results = {
    ok: [],
    info: [],
    warning: [],
    error: [],
    excluded: [],
  };

  for (const file of files) {
    const relativePath = formatPath(file);

    // Skip files matching exclude patterns
    if (isExcluded(relativePath, CONFIG.excludePatterns)) {
      results.excluded.push({ path: relativePath });
      continue;
    }

    const lineCount = countLines(file);
    const category = categorize(lineCount);

    results[category].push({
      path: relativePath,
      lines: lineCount,
    });
  }

  // Sort results by line count (descending)
  for (const category of Object.keys(results)) {
    results[category].sort((a, b) => b.lines - a.lines);
  }

  // Display results
  let hasErrors = false;

  if (results.error.length > 0) {
    hasErrors = true;
    console.log(
      `❌ ERROR: ${results.error.length} file(s) exceed ${CONFIG.thresholds.error} lines:\n`
    );
    for (const file of results.error) {
      console.log(`  ${file.path} (${file.lines} lines)`);
    }
    console.log('');
  }

  if (results.warning.length > 0) {
    console.log(
      `⚠️  WARNING: ${results.warning.length} file(s) exceed ${CONFIG.thresholds.warning} lines:\n`
    );
    for (const file of results.warning.slice(0, 10)) {
      // Show top 10
      console.log(`  ${file.path} (${file.lines} lines)`);
    }
    if (results.warning.length > 10) {
      console.log(`  ... and ${results.warning.length - 10} more`);
    }
    console.log('');
  }

  if (results.info.length > 0) {
    console.log(
      `ℹ️  INFO: ${results.info.length} file(s) exceed ${CONFIG.thresholds.info} lines (target):\n`
    );
    for (const file of results.info.slice(0, 5)) {
      // Show top 5
      console.log(`  ${file.path} (${file.lines} lines)`);
    }
    if (results.info.length > 5) {
      console.log(`  ... and ${results.info.length - 5} more`);
    }
    console.log('');
  }

  // Summary
  console.log('📊 Summary:');
  console.log(
    `  ✅ Within target (≤${CONFIG.thresholds.info}): ${results.ok.length}`
  );
  console.log(
    `  ℹ️  Exceeds target (>${CONFIG.thresholds.info}): ${results.info.length}`
  );
  console.log(
    `  ⚠️  Warning (>${CONFIG.thresholds.warning}): ${results.warning.length}`
  );
  console.log(
    `  ❌ Error (>${CONFIG.thresholds.error}): ${results.error.length}`
  );
  if (results.excluded.length > 0) {
    console.log(
      `  🔇 Excluded (auto-generated/tests): ${results.excluded.length}`
    );
  }
  console.log('');

  // Exit with appropriate code
  if (hasErrors) {
    console.log(
      `❌ File size check FAILED: ${results.error.length} file(s) exceed ${CONFIG.thresholds.error} lines`
    );
    console.log('Please refactor large files to maintain code quality.\n');
    process.exit(1);
  } else {
    console.log('✅ File size check PASSED\n');
    process.exit(0);
  }
}

// Run if executed directly
if (require.main === module) {
  main();
}

module.exports = { findFiles, countLines, categorize, isExcluded };
