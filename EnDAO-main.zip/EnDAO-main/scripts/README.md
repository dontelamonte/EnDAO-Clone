# CI/CD Architecture Check Scripts

This directory contains scripts for enforcing code quality and architecture standards in the EnDAO project.

## Scripts

### 1. `check-file-sizes.js`

**Purpose**: Enforces file size limits to maintain code readability and quality.

**Thresholds**:

- ≤300 lines: Target size (info)
- > 500 lines: Warning
- > 800 lines: Error (blocks CI)

**Usage**:

```bash
yarn check:files
node scripts/check-file-sizes.js
```

**Exit Codes**:

- 0: All files within acceptable limits
- 1: One or more files exceed 800 lines

### 2. `check-complexity.js`

**Purpose**: Analyzes cyclomatic complexity of functions to identify code that may be difficult to maintain.

**Threshold**:

- Complexity >10: Violation

**Complexity Calculation**:

- Base: 1
- +1 for each: if, else if, for, while, do-while, case, catch, &&, ||, ?, ??

**Usage**:

```bash
yarn check:complexity
node scripts/check-complexity.js
```

**Exit Codes**:

- 0: All functions within acceptable complexity
- 1: One or more functions exceed threshold

### 3. `architecture-report.js`

**Purpose**: Generates comprehensive architecture health reports.

**Includes**:

- File count and total lines of code
- Files categorized by size
- Complexity analysis summary
- Architecture pattern usage (repositories, services, components, API routes)
- Overall health score (0-100)

**Usage**:

```bash
# Console text output
yarn analyze
node scripts/architecture-report.js

# HTML report
yarn analyze:html
node scripts/architecture-report.js --html

# JSON output
node scripts/architecture-report.js --json
```

**Output**:

- Text: Console output
- HTML: `reports/architecture-report.html`
- JSON: Console output (pipe to file if needed)

## NPM Scripts

### Individual Checks

```bash
yarn check:files        # File size check
yarn check:complexity   # Complexity check
yarn analyze            # Architecture report (text)
yarn analyze:html       # Architecture report (HTML)
```

### Combined Checks

```bash
yarn check:architecture # All checks + docs governance
yarn pre-commit        # File size check (used in git hooks)
```

## CI/CD Integration

These scripts are designed to be used in CI/CD pipelines:

1. **Pre-commit Hook**: Runs `check:files` to catch large files early
2. **CI Pipeline**: Runs all checks to ensure code quality standards
3. **Reports**: Generates HTML reports for architecture health tracking

## Configuration

### File Size Thresholds

Edit `CONFIG.thresholds` in `check-file-sizes.js`:

```javascript
thresholds: {
  info: 300,    // Target size
  warning: 500, // Exceeds target
  error: 800    // Blocks CI
}
```

### Complexity Threshold

Edit `CONFIG.complexityThreshold` in `check-complexity.js`:

```javascript
complexityThreshold: 10;
```

### Excluded Directories

Both scripts exclude:

- `node_modules`
- `.next`
- `dist`
- `build`
- `out`

## Health Score Calculation

The architecture report calculates a health score (0-100) based on:

- **File Size Penalties**:
  - -5 points per file >800 lines
  - -2 points per file >500 lines
  - -0.5 points per file >300 lines
- **Complexity Penalties**:
  - -3 points per function with complexity >10
- **Architecture Bonus**:
  - +5 points for good repository/service pattern usage

**Interpretation**:

- 80-100: 🟢 Excellent health
- 60-79: 🟡 Good, with room for improvement
- 0-59: 🔴 Needs attention

## Lighthouse CI

Configuration for Lighthouse CI performance testing is in `.lighthouserc.json`:

**Thresholds**:

- Performance: ≥0.7 (warn)
- Accessibility: ≥0.9 (error)
- Best Practices: ≥0.8 (warn)
- SEO: ≥0.8 (warn)

**Usage**:

```bash
# Install Lighthouse CI
yarn install -g @lhci/cli

# Run Lighthouse CI
lhci autorun
```

## Troubleshooting

### Scripts not executable

```bash
chmod +x scripts/*.js
```

### Module not found errors

Ensure scripts are in the `scripts/` directory and use relative imports.

### Memory issues

If analyzing large projects, increase Node.js heap size:

```bash
NODE_OPTIONS='--max-old-space-size=8192' node scripts/architecture-report.js
```

## Future Enhancements

Potential improvements:

- [ ] Add TypeScript complexity analysis using ts-morph
- [ ] Track health score trends over time
- [ ] Add more architecture pattern detection
- [ ] Generate dependency graphs
- [ ] Add performance regression detection
