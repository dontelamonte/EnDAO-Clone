/**
 * Schema Validation Script
 *
 * Compares expected schema (from service requirements) against actual Supabase schema.
 * Run after migrations to catch missing columns, type mismatches, etc.
 *
 * Usage: npx tsx scripts/validate-schema.ts
 */

import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase credentials');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Define expected schema based on service requirements
// This is the "contract" that services expect from the database
const EXPECTED_SCHEMA: Record<
  string,
  { required: string[]; optional?: string[] }
> = {
  users: {
    required: [
      'id',
      'privy_id',
      'email',
      'display_name',
      'username',
      'profile_setup_complete',
      'created_at',
    ],
    optional: [
      'avatar_url',
      'bio',
      'first_name',
      'last_name',
      'wallets',
      'primary_wallet',
    ],
  },
  daos: {
    required: [
      'id',
      'name',
      'description',
      'created_by',
      'created_at',
      'status',
    ],
    optional: [
      'slug',
      'member_count',
      'treasury_address',
      'settings',
      'is_public',
    ],
  },
  dao_members: {
    required: ['id', 'dao_id', 'user_id', 'role', 'joined_at', 'status'],
    optional: ['display_name', 'bio', 'avatar_url'],
  },
  proposals: {
    required: [
      'id',
      'dao_id',
      'title',
      'description',
      'type',
      'status',
      'created_by',
      'created_at',
    ],
    optional: ['voting_config', 'start_time', 'end_time', 'result'],
  },
  votes: {
    required: ['id', 'proposal_id', 'user_id', 'vote', 'created_at'],
    optional: ['dao_id', 'voting_power', 'ranked_choices'],
  },
  admin_users: {
    required: ['id', 'role', 'email', 'is_active', 'created_at'],
    optional: [
      'user_id',
      'display_name',
      'permissions',
      'created_by',
      'notes',
      'last_login_at',
    ],
  },
  treasury_executions: {
    required: [
      'id',
      'proposal_id',
      'dao_id',
      'status',
      'required_signatures',
      'created_at',
    ],
    optional: [
      'safe_tx_hash',
      'tx_hash',
      'executing_by',
      'executing_started_at',
    ],
  },
  treasury_execution_signatures: {
    required: ['id', 'execution_id', 'signer_id', 'signature', 'created_at'],
    optional: ['signer_address'],
  },
  notifications: {
    required: ['id', 'user_id', 'type', 'title', 'created_at'],
    optional: ['body', 'dao_id', 'metadata', 'read'],
  },
  dao_activities: {
    required: ['id', 'dao_id', 'activity_type', 'created_at'],
    optional: ['user_id', 'title', 'description', 'metadata'],
  },
  user_activities: {
    required: ['id', 'user_id', 'type', 'timestamp'],
    optional: ['dao_id', 'proposal_id', 'details', 'ip_address'],
  },
};

interface ColumnInfo {
  column_name: string;
  data_type: string;
  is_nullable: string;
  column_default: string | null;
}

async function getTableColumns(tableName: string): Promise<ColumnInfo[]> {
  const { data, error } = await supabase.rpc('get_table_columns', {
    p_table_name: tableName,
  });

  if (error) {
    // Fallback: try direct query via information_schema
    const { data: fallbackData, error: fallbackError } = await supabase
      .from(tableName)
      .select('*')
      .limit(0);

    if (fallbackError) {
      console.log(`  ⚠️  Cannot query ${tableName}: ${fallbackError.message}`);
      return [];
    }

    // Get columns from empty result metadata (won't work, but worth trying)
    return [];
  }

  return data || [];
}

async function validateTable(
  tableName: string,
  expected: { required: string[]; optional?: string[] }
): Promise<{
  table: string;
  missing: string[];
  found: string[];
  extra: string[];
  status: 'pass' | 'fail' | 'warning';
}> {
  // Try to select from the table to see what columns exist
  const { data, error } = await supabase.from(tableName).select('*').limit(1);

  if (error) {
    // Check if it's a "table doesn't exist" error
    if (error.code === '42P01' || error.message.includes('does not exist')) {
      return {
        table: tableName,
        missing: expected.required,
        found: [],
        extra: [],
        status: 'fail',
      };
    }

    // For column errors, we can parse what's missing
    const missingMatch = error.message.match(
      /column (\w+)\.(\w+) does not exist/
    );
    if (missingMatch) {
      return {
        table: tableName,
        missing: [missingMatch[2]],
        found: [],
        extra: [],
        status: 'fail',
      };
    }
  }

  // If we got data, check what columns exist
  const foundColumns = data && data.length > 0 ? Object.keys(data[0]) : [];

  // If no data, try to get structure by selecting with error handling for each column
  if (foundColumns.length === 0) {
    const detectedColumns: string[] = [];
    const allExpected = [...expected.required, ...(expected.optional || [])];

    for (const col of allExpected) {
      const { error: colError } = await supabase
        .from(tableName)
        .select(col)
        .limit(1);

      if (!colError || !colError.message.includes('does not exist')) {
        detectedColumns.push(col);
      }
    }

    const missing = expected.required.filter(
      (col) => !detectedColumns.includes(col)
    );

    return {
      table: tableName,
      missing,
      found: detectedColumns,
      extra: [],
      status: missing.length > 0 ? 'fail' : 'pass',
    };
  }

  const missing = expected.required.filter(
    (col) => !foundColumns.includes(col)
  );
  const allExpected = [...expected.required, ...(expected.optional || [])];
  const extra = foundColumns.filter((col) => !allExpected.includes(col));

  return {
    table: tableName,
    missing,
    found: foundColumns,
    extra,
    status: missing.length > 0 ? 'fail' : extra.length > 0 ? 'warning' : 'pass',
  };
}

async function main() {
  console.log('🔍 Validating Supabase Schema Against Service Requirements\n');
  console.log('='.repeat(60));

  let hasFailures = false;
  let hasWarnings = false;

  for (const [tableName, expected] of Object.entries(EXPECTED_SCHEMA)) {
    const result = await validateTable(tableName, expected);

    const icon =
      result.status === 'pass'
        ? '✅'
        : result.status === 'warning'
          ? '⚠️'
          : '❌';
    console.log(`\n${icon} ${tableName}`);

    if (result.missing.length > 0) {
      console.log(`   Missing columns: ${result.missing.join(', ')}`);
      hasFailures = true;
    }

    if (result.extra.length > 0) {
      console.log(`   Extra columns (not in spec): ${result.extra.join(', ')}`);
      hasWarnings = true;
    }

    if (result.status === 'pass') {
      console.log(
        `   All ${expected.required.length} required columns present`
      );
    }
  }

  console.log('\n' + '='.repeat(60));

  if (hasFailures) {
    console.log('\n❌ SCHEMA VALIDATION FAILED');
    console.log(
      '   Some required columns are missing. Run the appropriate migration.'
    );
    process.exit(1);
  } else if (hasWarnings) {
    console.log('\n⚠️  SCHEMA VALIDATION PASSED WITH WARNINGS');
    console.log('   Extra columns found - may need to update EXPECTED_SCHEMA.');
    process.exit(0);
  } else {
    console.log('\n✅ SCHEMA VALIDATION PASSED');
    console.log('   All required columns present in all tables.');
    process.exit(0);
  }
}

main().catch((err) => {
  console.error('Validation failed:', err);
  process.exit(1);
});
