/**
 * Script to apply admin_users migration directly to Supabase
 *
 * Usage: npx tsx scripts/apply-admin-migration.ts
 */

import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase credentials in .env.local');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

async function applyMigration() {
  console.log('🚀 Applying admin_users migration...\n');

  const migrations = [
    {
      name: 'Add email column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS email TEXT`,
    },
    {
      name: 'Add display_name column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS display_name TEXT`,
    },
    {
      name: 'Add permissions column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS permissions JSONB DEFAULT '{}'`,
    },
    {
      name: 'Add created_by column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS created_by TEXT DEFAULT 'system'`,
    },
    {
      name: 'Add is_active column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true`,
    },
    {
      name: 'Add notes column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS notes TEXT`,
    },
    {
      name: 'Add last_login_at column',
      sql: `ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ`,
    },
    {
      name: 'Make user_id nullable',
      sql: `ALTER TABLE admin_users ALTER COLUMN user_id DROP NOT NULL`,
    },
  ];

  for (const migration of migrations) {
    try {
      console.log(`  📝 ${migration.name}...`);

      // Use raw SQL via the postgres function if available, or try direct
      const { error } = await supabase.rpc('exec_sql', { sql: migration.sql });

      if (error) {
        // If rpc doesn't exist, we'll need to use the REST API directly
        if (error.code === 'PGRST202') {
          console.log(
            `     ⚠️  Need to apply via Supabase Dashboard SQL Editor`
          );
        } else {
          console.log(`     ⚠️  ${error.message}`);
        }
      } else {
        console.log(`     ✅ Success`);
      }
    } catch (err) {
      console.log(`     ❌ Error: ${err}`);
    }
  }

  console.log('\n📋 Verifying table structure...');

  // Check the current table structure
  const { data: tableData, error: tableError } = await supabase
    .from('admin_users')
    .select('*')
    .limit(1);

  if (tableError) {
    console.log(`   ❌ Table check failed: ${tableError.message}`);
  } else {
    console.log('   ✅ Table exists and accessible');
    if (tableData && tableData.length > 0) {
      console.log('   Columns found:', Object.keys(tableData[0]));
    }
  }

  console.log(
    '\n💡 If migrations failed, apply manually via Supabase Dashboard:'
  );
  console.log(
    '   1. Go to https://supabase.com/dashboard/project/qwxfttvzngivqmobfaxn'
  );
  console.log('   2. Navigate to SQL Editor');
  console.log(
    '   3. Run the contents of: supabase/migrations/016_admin_users_extended_fields.sql'
  );
}

applyMigration()
  .then(() => {
    console.log('\n✅ Migration script complete');
    process.exit(0);
  })
  .catch((err) => {
    console.error('\n❌ Migration failed:', err);
    process.exit(1);
  });
