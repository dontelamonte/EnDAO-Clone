#!/usr/bin/env npx tsx
/**
 * Production Test Data Cleanup Script
 *
 * ONE-TIME SCRIPT to remove test data that was seeded to production.
 * This script is DESTRUCTIVE - it will permanently delete test data.
 *
 * Usage: npx tsx scripts/cleanup-production-test-data.ts
 *
 * Prerequisites:
 * - .env.local with production SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY
 *
 * Safety:
 * - Only deletes data matching test patterns (privy_id LIKE 'test-privy-user-%', slug LIKE 'test-%')
 * - Requires explicit confirmation
 */

import { createClient } from '@supabase/supabase-js';
import { config } from 'dotenv';
import * as readline from 'readline';

// Check for --force flag
const FORCE_MODE = process.argv.includes('--force');

// Load environment variables
config({ path: '.env.local' });
config({ path: '.env' });

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('Missing required environment variables:');
  if (!SUPABASE_URL) console.error('   - NEXT_PUBLIC_SUPABASE_URL');
  if (!SUPABASE_SERVICE_ROLE_KEY)
    console.error('   - SUPABASE_SERVICE_ROLE_KEY');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

// Test data identifiers
const TEST_USER_PATTERN = 'test-privy-user-%';
const TEST_DAO_PATTERN = 'test-%';
const TEST_EMAIL_PATTERN = '%@test.endao.local';

async function confirmAction(message: string): Promise<boolean> {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    rl.question(`${message} (yes/no): `, (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'yes');
    });
  });
}

async function countTestData() {
  console.log('\n📊 Counting test data in database...\n');

  // Count test users
  const { count: userCount } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })
    .like('privy_id', TEST_USER_PATTERN);

  // Count test DAOs
  const { count: daoCount } = await supabase
    .from('daos')
    .select('*', { count: 'exact', head: true })
    .like('slug', TEST_DAO_PATTERN);

  // Get test user IDs for counting related data
  const { data: testUsers } = await supabase
    .from('users')
    .select('id')
    .like('privy_id', TEST_USER_PATTERN);

  const testUserIds = testUsers?.map((u) => u.id) || [];

  // Get test DAO IDs
  const { data: testDAOs } = await supabase
    .from('daos')
    .select('id')
    .like('slug', TEST_DAO_PATTERN);

  const testDaoIds = testDAOs?.map((d) => d.id) || [];

  // Count members
  let memberCount = 0;
  if (testDaoIds.length > 0) {
    const { count } = await supabase
      .from('dao_members')
      .select('*', { count: 'exact', head: true })
      .in('dao_id', testDaoIds);
    memberCount = count || 0;
  }

  // Count proposals
  let proposalCount = 0;
  if (testUserIds.length > 0) {
    const { count } = await supabase
      .from('proposals')
      .select('*', { count: 'exact', head: true })
      .in('created_by', testUserIds);
    proposalCount = count || 0;
  }

  // Count votes
  let voteCount = 0;
  if (testUserIds.length > 0) {
    const { count } = await supabase
      .from('votes')
      .select('*', { count: 'exact', head: true })
      .in('user_id', testUserIds);
    voteCount = count || 0;
  }

  // Count comments
  let commentCount = 0;
  if (testUserIds.length > 0) {
    const { count } = await supabase
      .from('proposal_comments')
      .select('*', { count: 'exact', head: true })
      .in('user_id', testUserIds);
    commentCount = count || 0;
  }

  console.log('   Test data found:');
  console.log(`   • Users: ${userCount ?? 0}`);
  console.log(`   • DAOs: ${daoCount ?? 0}`);
  console.log(`   • DAO memberships: ${memberCount}`);
  console.log(`   • Proposals: ${proposalCount}`);
  console.log(`   • Votes: ${voteCount}`);
  console.log(`   • Comments: ${commentCount}`);

  return {
    userCount: userCount ?? 0,
    daoCount: daoCount ?? 0,
    memberCount,
    proposalCount,
    voteCount,
    commentCount,
    testUserIds,
    testDaoIds,
  };
}

async function cleanupTestData(testUserIds: string[], testDaoIds: string[]) {
  console.log('\n🧹 Deleting test data...\n');

  // Delete in reverse dependency order

  // 1. Comment likes
  if (testUserIds.length > 0) {
    const { error } = await supabase
      .from('comment_likes')
      .delete()
      .in('user_id', testUserIds);
    if (error) console.error('   Error deleting comment_likes:', error.message);
    else console.log('   ✓ Deleted comment likes');
  }

  // 2. Proposal comments
  if (testUserIds.length > 0) {
    const { error } = await supabase
      .from('proposal_comments')
      .delete()
      .in('user_id', testUserIds);
    if (error)
      console.error('   Error deleting proposal_comments:', error.message);
    else console.log('   ✓ Deleted proposal comments');
  }

  // 3. Votes
  if (testUserIds.length > 0) {
    const { error } = await supabase
      .from('votes')
      .delete()
      .in('user_id', testUserIds);
    if (error) console.error('   Error deleting votes:', error.message);
    else console.log('   ✓ Deleted votes');
  }

  // 4. Proposal drafts
  if (testDaoIds.length > 0) {
    const { error } = await supabase
      .from('proposal_drafts')
      .delete()
      .in('dao_id', testDaoIds);
    if (error)
      console.error('   Error deleting proposal_drafts:', error.message);
    else console.log('   ✓ Deleted proposal drafts');
  }

  // 5. Proposals (by creator)
  if (testUserIds.length > 0) {
    const { error } = await supabase
      .from('proposals')
      .delete()
      .in('created_by', testUserIds);
    if (error) console.error('   Error deleting proposals:', error.message);
    else console.log('   ✓ Deleted proposals');
  }

  // 6. DAO activities
  if (testDaoIds.length > 0) {
    const { error } = await supabase
      .from('dao_activities')
      .delete()
      .in('dao_id', testDaoIds);
    if (error)
      console.error('   Error deleting dao_activities:', error.message);
    else console.log('   ✓ Deleted DAO activities');
  }

  // 7. DAO join requests
  if (testDaoIds.length > 0) {
    const { error } = await supabase
      .from('dao_join_requests')
      .delete()
      .in('dao_id', testDaoIds);
    if (error)
      console.error('   Error deleting dao_join_requests:', error.message);
    else console.log('   ✓ Deleted DAO join requests');
  }

  // 8. DAO members
  if (testDaoIds.length > 0) {
    const { error } = await supabase
      .from('dao_members')
      .delete()
      .in('dao_id', testDaoIds);
    if (error) console.error('   Error deleting dao_members:', error.message);
    else console.log('   ✓ Deleted DAO members');
  }

  // 9. DAO invitations
  if (testDaoIds.length > 0) {
    const { error } = await supabase
      .from('dao_invitations')
      .delete()
      .in('dao_id', testDaoIds);
    if (error)
      console.error('   Error deleting dao_invitations:', error.message);
    else console.log('   ✓ Deleted DAO invitations');
  }

  // 10. DAOs
  const { error: daoError } = await supabase
    .from('daos')
    .delete()
    .like('slug', TEST_DAO_PATTERN);
  if (daoError) console.error('   Error deleting daos:', daoError.message);
  else console.log('   ✓ Deleted test DAOs');

  // 11. Usernames
  const { error: usernameError } = await supabase
    .from('usernames')
    .delete()
    .like('username', '%test.endao.local');
  if (usernameError)
    console.error('   Error deleting usernames:', usernameError.message);
  else console.log('   ✓ Deleted test usernames');

  // 12. User preferences
  if (testUserIds.length > 0) {
    const { error } = await supabase
      .from('user_preferences')
      .delete()
      .in('user_id', testUserIds);
    if (error)
      console.error('   Error deleting user_preferences:', error.message);
    else console.log('   ✓ Deleted user preferences');
  }

  // 13. Users (last)
  const { error: userError } = await supabase
    .from('users')
    .delete()
    .like('privy_id', TEST_USER_PATTERN);
  if (userError) console.error('   Error deleting users:', userError.message);
  else console.log('   ✓ Deleted test users');
}

async function main() {
  console.log(
    '═══════════════════════════════════════════════════════════════'
  );
  console.log('  PRODUCTION TEST DATA CLEANUP');
  console.log(
    '═══════════════════════════════════════════════════════════════'
  );
  console.log(`\n🎯 Target database: ${SUPABASE_URL}`);

  // Count existing test data
  const counts = await countTestData();

  if (
    counts.userCount === 0 &&
    counts.daoCount === 0 &&
    counts.memberCount === 0 &&
    counts.proposalCount === 0
  ) {
    console.log('\n✅ No test data found in database. Nothing to clean up.\n');
    process.exit(0);
  }

  console.log(
    '\n⚠️  WARNING: This will PERMANENTLY DELETE all test data listed above.'
  );
  console.log('   This action cannot be undone.\n');

  if (!FORCE_MODE) {
    const confirmed = await confirmAction('Are you sure you want to proceed?');

    if (!confirmed) {
      console.log('\n❌ Cleanup cancelled.\n');
      process.exit(0);
    }

    // Double confirmation for production
    if (SUPABASE_URL?.includes('supabase.co')) {
      console.log('\n🚨 PRODUCTION DATABASE DETECTED');
      const doubleConfirmed = await confirmAction(
        'Type "yes" again to confirm deletion from PRODUCTION'
      );

      if (!doubleConfirmed) {
        console.log('\n❌ Cleanup cancelled.\n');
        process.exit(0);
      }
    }
  } else {
    console.log('   --force flag detected, skipping confirmations...\n');
  }

  await cleanupTestData(counts.testUserIds, counts.testDaoIds);

  // Verify cleanup
  console.log('\n🔍 Verifying cleanup...');
  const afterCounts = await countTestData();

  if (
    afterCounts.userCount === 0 &&
    afterCounts.daoCount === 0 &&
    afterCounts.memberCount === 0 &&
    afterCounts.proposalCount === 0
  ) {
    console.log('\n✅ Cleanup complete! All test data has been removed.\n');
  } else {
    console.log(
      '\n⚠️  Some test data may remain. Please check the database manually.\n'
    );
  }
}

main().catch((error) => {
  console.error('\n❌ Error:', error.message);
  process.exit(1);
});
