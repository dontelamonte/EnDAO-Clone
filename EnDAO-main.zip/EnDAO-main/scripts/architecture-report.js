#!/usr/bin/env node

/**
 * Architecture Health Report Generator
 *
 * Generates comprehensive architecture health reports including:
 * - File count and total lines of code
 * - Files categorized by size
 * - Complexity analysis summary
 * - Repository pattern usage
 * - Service layer analysis
 *
 * Output Formats:
 * - Console text (default)
 * - HTML report (--html flag)
 * - JSON data (--json flag)
 *
 * @example
 * node scripts/architecture-report.js
 * node scripts/architecture-report.js --html
 * node scripts/architecture-report.js --json
 */

const fs = require('fs');
const path = require('path');

// Import analysis functions from other scripts
const {
  findFiles: findFilesSize,
  countLines,
  categorize,
} = require('./check-file-sizes.js');
const {
  findFiles: findFilesComplexity,
  analyzeFile,
} = require('./check-complexity.js');

// Configuration
const CONFIG = {
  srcDir: path.join(process.cwd(), 'src'),
  extensions: ['.ts', '.tsx', '.js', '.jsx'],
  excludeDirs: ['node_modules', '.next', 'dist', 'build', 'out'],
  reportsDir: path.join(process.cwd(), 'reports'),
  thresholds: {
    info: 300,
    warning: 500,
    error: 800,
  },
  complexityThreshold: 10,
};

/**
 * Analyzes project structure
 * @returns {Object} Analysis results
 */
function analyzeProject() {
  const files = findFilesSize(
    CONFIG.srcDir,
    CONFIG.extensions,
    CONFIG.excludeDirs
  );

  // File size analysis
  const sizeAnalysis = {
    ok: [],
    info: [],
    warning: [],
    error: [],
  };

  let totalLines = 0;

  for (const file of files) {
    const lineCount = countLines(file);
    totalLines += lineCount;
    const category = categorize(lineCount);
    const relativePath = path.relative(process.cwd(), file);

    sizeAnalysis[category].push({
      path: relativePath,
      lines: lineCount,
    });
  }

  // Sort by line count (descending)
  for (const category of Object.keys(sizeAnalysis)) {
    sizeAnalysis[category].sort((a, b) => b.lines - a.lines);
  }

  // Complexity analysis
  const complexityViolations = [];
  for (const file of files) {
    const results = analyzeFile(file);
    complexityViolations.push(...results);
  }
  complexityViolations.sort((a, b) => b.complexity - a.complexity);

  // Repository pattern analysis
  const repositories = files.filter(
    (f) =>
      f.includes('/repositories/') &&
      (f.endsWith('Repository.ts') || f.endsWith('Repository.tsx'))
  );

  // Service layer analysis
  const services = files.filter(
    (f) =>
      f.includes('/services/') &&
      (f.endsWith('Service.ts') || f.endsWith('Service.tsx'))
  );

  // Component analysis
  const components = files.filter((f) => f.includes('/components/'));

  // API routes analysis
  const apiRoutes = files.filter((f) => f.includes('/api/'));

  return {
    fileCount: files.length,
    totalLines,
    averageLines: Math.round(totalLines / files.length),
    sizeAnalysis,
    complexityViolations,
    patterns: {
      repositories: repositories.length,
      services: services.length,
      components: components.length,
      apiRoutes: apiRoutes.length,
    },
    timestamp: new Date().toISOString(),
  };
}

/**
 * Generates console text report
 * @param {Object} data - Analysis data
 */
function generateTextReport(data) {
  console.log(
    '\n╔════════════════════════════════════════════════════════════════╗'
  );
  console.log(
    '║        EnDAO Architecture Health Report                       ║'
  );
  console.log(
    '╚════════════════════════════════════════════════════════════════╝\n'
  );

  console.log('📊 Overall Statistics:');
  console.log(`  Total Files: ${data.fileCount}`);
  console.log(`  Total Lines: ${data.totalLines.toLocaleString()}`);
  console.log(`  Average Lines per File: ${data.averageLines}`);
  console.log('');

  console.log('📏 File Size Distribution:');
  console.log(
    `  ✅ Within target (≤${CONFIG.thresholds.info} lines): ${data.sizeAnalysis.ok.length}`
  );
  console.log(
    `  ℹ️  Exceeds target (>${CONFIG.thresholds.info} lines): ${data.sizeAnalysis.info.length}`
  );
  console.log(
    `  ⚠️  Warning (>${CONFIG.thresholds.warning} lines): ${data.sizeAnalysis.warning.length}`
  );
  console.log(
    `  ❌ Error (>${CONFIG.thresholds.error} lines): ${data.sizeAnalysis.error.length}`
  );
  console.log('');

  if (data.sizeAnalysis.error.length > 0) {
    console.log(`  Largest Files (Error):`);
    for (const file of data.sizeAnalysis.error.slice(0, 5)) {
      console.log(`    - ${file.path} (${file.lines} lines)`);
    }
    console.log('');
  }

  console.log('🔄 Complexity Analysis:');
  console.log(
    `  Functions exceeding threshold (>${CONFIG.complexityThreshold}): ${data.complexityViolations.length}`
  );
  if (data.complexityViolations.length > 0) {
    console.log(`  Most Complex Functions:`);
    for (const v of data.complexityViolations.slice(0, 5)) {
      console.log(
        `    - ${v.function}() in ${v.file} (complexity: ${v.complexity})`
      );
    }
  }
  console.log('');

  console.log('🏗️  Architecture Patterns:');
  console.log(`  Repositories: ${data.patterns.repositories}`);
  console.log(`  Services: ${data.patterns.services}`);
  console.log(`  Components: ${data.patterns.components}`);
  console.log(`  API Routes: ${data.patterns.apiRoutes}`);
  console.log('');

  console.log('🎯 Health Score:');
  const score = calculateHealthScore(data);
  const emoji = score >= 80 ? '🟢' : score >= 60 ? '🟡' : '🔴';
  console.log(`  ${emoji} Overall: ${score}/100`);
  console.log('');

  console.log(`Generated: ${new Date(data.timestamp).toLocaleString()}`);
  console.log('');
}

/**
 * Generates HTML report
 * @param {Object} data - Analysis data
 * @returns {string} HTML content
 */
function generateHTMLReport(data) {
  const score = calculateHealthScore(data);
  const scoreColor =
    score >= 80 ? '#22c55e' : score >= 60 ? '#eab308' : '#ef4444';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EnDAO Architecture Health Report</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      padding: 2rem;
      line-height: 1.6;
    }
    .container { max-width: 1200px; margin: 0 auto; }
    .header {
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
      padding: 2rem;
      border-radius: 1rem;
      margin-bottom: 2rem;
      text-align: center;
    }
    .header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
    .header p { opacity: 0.9; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
    .card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 0.75rem;
      padding: 1.5rem;
    }
    .card h2 { font-size: 1.25rem; margin-bottom: 1rem; color: #60a5fa; }
    .stat { display: flex; justify-content: space-between; margin: 0.75rem 0; padding: 0.5rem; background: #0f172a; border-radius: 0.5rem; }
    .stat-label { opacity: 0.8; }
    .stat-value { font-weight: 600; }
    .score-circle {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      border: 8px solid ${scoreColor};
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.5rem;
      font-weight: bold;
      margin: 1rem auto;
      color: ${scoreColor};
    }
    .list { list-style: none; }
    .list li {
      padding: 0.5rem;
      margin: 0.5rem 0;
      background: #0f172a;
      border-radius: 0.5rem;
      font-family: 'Monaco', 'Courier New', monospace;
      font-size: 0.875rem;
    }
    .badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 0.5rem;
      font-size: 0.875rem;
      font-weight: 500;
      margin-left: 0.5rem;
    }
    .badge-success { background: #22c55e; color: #000; }
    .badge-info { background: #60a5fa; color: #000; }
    .badge-warning { background: #eab308; color: #000; }
    .badge-error { background: #ef4444; color: #fff; }
    .footer {
      text-align: center;
      margin-top: 3rem;
      padding-top: 2rem;
      border-top: 1px solid #334155;
      opacity: 0.7;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🏗️ EnDAO Architecture Health Report</h1>
      <p>Generated: ${new Date(data.timestamp).toLocaleString()}</p>
    </div>

    <div class="grid">
      <div class="card">
        <h2>📊 Overall Statistics</h2>
        <div class="stat">
          <span class="stat-label">Total Files</span>
          <span class="stat-value">${data.fileCount}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Total Lines</span>
          <span class="stat-value">${data.totalLines.toLocaleString()}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Average Lines</span>
          <span class="stat-value">${data.averageLines}</span>
        </div>
      </div>

      <div class="card">
        <h2>📏 File Size Distribution</h2>
        <div class="stat">
          <span class="stat-label">Within Target</span>
          <span class="stat-value">${data.sizeAnalysis.ok.length}<span class="badge badge-success">✓</span></span>
        </div>
        <div class="stat">
          <span class="stat-label">Exceeds Target</span>
          <span class="stat-value">${data.sizeAnalysis.info.length}<span class="badge badge-info">ℹ</span></span>
        </div>
        <div class="stat">
          <span class="stat-label">Warning</span>
          <span class="stat-value">${data.sizeAnalysis.warning.length}<span class="badge badge-warning">⚠</span></span>
        </div>
        <div class="stat">
          <span class="stat-label">Error</span>
          <span class="stat-value">${data.sizeAnalysis.error.length}<span class="badge badge-error">✖</span></span>
        </div>
      </div>

      <div class="card">
        <h2>🔄 Complexity Analysis</h2>
        <div class="stat">
          <span class="stat-label">Complex Functions</span>
          <span class="stat-value">${data.complexityViolations.length}</span>
        </div>
        ${
          data.complexityViolations.length > 0
            ? `
        <div class="stat">
          <span class="stat-label">Highest</span>
          <span class="stat-value">${data.complexityViolations[0].complexity}</span>
        </div>
        `
            : ''
        }
      </div>

      <div class="card">
        <h2>🏗️ Architecture Patterns</h2>
        <div class="stat">
          <span class="stat-label">Repositories</span>
          <span class="stat-value">${data.patterns.repositories}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Services</span>
          <span class="stat-value">${data.patterns.services}</span>
        </div>
        <div class="stat">
          <span class="stat-label">Components</span>
          <span class="stat-value">${data.patterns.components}</span>
        </div>
        <div class="stat">
          <span class="stat-label">API Routes</span>
          <span class="stat-value">${data.patterns.apiRoutes}</span>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>🎯 Health Score</h2>
      <div class="score-circle">${score}</div>
      <p style="text-align: center; opacity: 0.8;">
        ${score >= 80 ? 'Excellent health!' : score >= 60 ? 'Good, with room for improvement' : 'Needs attention'}
      </p>
    </div>

    ${
      data.sizeAnalysis.error.length > 0
        ? `
    <div class="card">
      <h2>⚠️ Largest Files (Exceeding ${CONFIG.thresholds.error} lines)</h2>
      <ul class="list">
        ${data.sizeAnalysis.error
          .slice(0, 10)
          .map(
            (f) =>
              `<li>${f.path} <span class="badge badge-error">${f.lines} lines</span></li>`
          )
          .join('')}
      </ul>
    </div>
    `
        : ''
    }

    ${
      data.complexityViolations.length > 0
        ? `
    <div class="card">
      <h2>🔄 Most Complex Functions</h2>
      <ul class="list">
        ${data.complexityViolations
          .slice(0, 10)
          .map(
            (v) =>
              `<li>${v.function}() in ${v.file} <span class="badge badge-warning">${v.complexity}</span></li>`
          )
          .join('')}
      </ul>
    </div>
    `
        : ''
    }

    <div class="footer">
      <p>EnDAO Architecture Health Report • Generated by CI/CD Pipeline</p>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Calculates overall health score (0-100)
 * @param {Object} data - Analysis data
 * @returns {number} Score
 */
function calculateHealthScore(data) {
  let score = 100;

  // Penalize for large files
  score -= data.sizeAnalysis.error.length * 5;
  score -= data.sizeAnalysis.warning.length * 2;
  score -= data.sizeAnalysis.info.length * 0.5;

  // Penalize for complexity
  score -= data.complexityViolations.length * 3;

  // Bonus for good architecture patterns
  const expectedPatterns = data.fileCount * 0.1; // ~10% should be repositories/services
  const actualPatterns = data.patterns.repositories + data.patterns.services;
  if (actualPatterns >= expectedPatterns) {
    score += 5;
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}

/**
 * Main execution
 */
function main() {
  const args = process.argv.slice(2);
  const htmlFlag = args.includes('--html');
  const jsonFlag = args.includes('--json');

  console.log('🔍 Analyzing project architecture...\n');

  const data = analyzeProject();

  if (jsonFlag) {
    // JSON output
    console.log(JSON.stringify(data, null, 2));
  } else if (htmlFlag) {
    // HTML output
    const html = generateHTMLReport(data);

    // Ensure reports directory exists
    if (!fs.existsSync(CONFIG.reportsDir)) {
      fs.mkdirSync(CONFIG.reportsDir, { recursive: true });
    }

    const outputPath = path.join(CONFIG.reportsDir, 'architecture-report.html');
    fs.writeFileSync(outputPath, html, 'utf8');
    console.log(`✅ HTML report generated: ${outputPath}\n`);
  } else {
    // Text output (default)
    generateTextReport(data);
  }

  process.exit(0);
}

// Run if executed directly
if (require.main === module) {
  main();
}

module.exports = { analyzeProject, calculateHealthScore };
