/**
 * Re-add a user to a DAO as admin
 *
 * Usage: npx tsx scripts/rejoin-dao-as-admin.ts <email> <daoName>
 * Example: npx tsx scripts/rejoin-dao-as-admin.ts user@example.com "VMF Collective"
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { readFileSync } from 'fs';
import { join } from 'path';

// Initialize Firebase Admin using serviceAccountKey.json
if (getApps().length === 0) {
  const serviceAccountPath = join(process.cwd(), 'serviceAccountKey.json');

  try {
    const serviceAccount = JSON.parse(
      readFileSync(serviceAccountPath, 'utf-8')
    );
    initializeApp({
      credential: cert(serviceAccount),
    });
  } catch (error) {
    console.error(
      'Failed to load serviceAccountKey.json from:',
      serviceAccountPath
    );
    console.error(error);
    process.exit(1);
  }
}

const db = getFirestore();

async function findUserByEmail(email: string) {
  const usersRef = db.collection('users');
  const snapshot = await usersRef
    .where('email', '==', email.toLowerCase())
    .limit(1)
    .get();

  if (snapshot.empty) {
    // Try without lowercase
    const snapshot2 = await usersRef.where('email', '==', email).limit(1).get();
    if (snapshot2.empty) {
      return null;
    }
    return { id: snapshot2.docs[0].id, ...snapshot2.docs[0].data() };
  }

  return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
}

async function findDAOByName(name: string) {
  const daosRef = db.collection('daos');
  const snapshot = await daosRef.where('name', '==', name).limit(1).get();

  if (snapshot.empty) {
    // Try partial match
    const allDaos = await daosRef.get();
    for (const doc of allDaos.docs) {
      const data = doc.data();
      if (data.name?.toLowerCase().includes(name.toLowerCase())) {
        return { id: doc.id, ...data };
      }
    }
    return null;
  }

  return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
}

async function findMembership(daoId: string, userId: string) {
  const membersRef = db.collection('dao-members');
  const snapshot = await membersRef
    .where('daoId', '==', daoId)
    .where('userId', '==', userId)
    .limit(1)
    .get();

  if (snapshot.empty) {
    return null;
  }

  return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
}

async function createMembership(
  daoId: string,
  userId: string,
  userDisplayName: string
) {
  const membersRef = db.collection('dao-members');
  const now = Timestamp.now();

  const memberData = {
    daoId,
    userId,
    role: 'admin',
    displayName: userDisplayName,
    joinedAt: now,
    createdAt: now,
    updatedAt: now,
    status: 'active',
    votingWeight: 1,
  };

  const docRef = await membersRef.add(memberData);
  console.log(`Created new membership: ${docRef.id}`);
  return docRef.id;
}

async function updateDAOAdmins(daoId: string, userId: string) {
  const daoRef = db.collection('daos').doc(daoId);
  const daoDoc = await daoRef.get();
  const daoData = daoDoc.data();
  const admins = daoData?.admins || [];
  const memberIds = daoData?.memberIds || [];

  const updates: Record<string, unknown> = {
    updatedAt: Timestamp.now(),
  };

  if (!admins.includes(userId)) {
    updates.admins = [...admins, userId];
    console.log('Added user to dao.admins array');
  } else {
    console.log('User already in dao.admins array');
  }

  // Also add to memberIds array (needed for dashboard query)
  if (!memberIds.includes(userId)) {
    updates.memberIds = [...memberIds, userId];
    updates.memberCount = (daoData?.memberCount || 0) + 1;
    console.log('Added user to dao.memberIds array');
  } else {
    console.log('User already in dao.memberIds array');
  }

  await daoRef.update(updates);
}

async function updateMembershipToAdmin(
  membershipId: string,
  daoId: string,
  userId: string
) {
  const memberRef = db.collection('dao-members').doc(membershipId);

  // Update member role
  await memberRef.update({
    role: 'admin',
    status: 'active',
    updatedAt: Timestamp.now(),
  });

  await updateDAOAdmins(daoId, userId);
  console.log('Successfully updated membership to admin');
}

async function main() {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.log(
      'Usage: npx tsx scripts/rejoin-dao-as-admin.ts <email> <daoName>'
    );
    console.log(
      'Example: npx tsx scripts/rejoin-dao-as-admin.ts user@example.com "VMF Collective"'
    );
    process.exit(1);
  }

  const email = args[0];
  const daoName = args.slice(1).join(' ');

  console.log(`\nLooking for user: ${email}`);
  const user = await findUserByEmail(email);

  if (!user) {
    console.log('User not found!');
    console.log('\nSearching for similar emails...');
    const usersRef = db.collection('users');
    const allUsers = await usersRef.limit(20).get();
    console.log('Recent users:');
    for (const doc of allUsers.docs) {
      const data = doc.data();
      console.log(`  - ${data.email || 'no email'} (${doc.id})`);
    }
    return;
  }

  console.log(`Found user: ${user.id}`);
  console.log(
    `Display name: ${(user as Record<string, unknown>).displayName || (user as Record<string, unknown>).name || 'N/A'}`
  );
  console.log(`Email: ${(user as Record<string, unknown>).email}`);

  console.log(`\nLooking for DAO: ${daoName}`);
  const dao = await findDAOByName(daoName);

  if (!dao) {
    console.log('DAO not found!');
    console.log('\nListing all DAOs:');
    const daosRef = db.collection('daos');
    const allDaos = await daosRef.get();
    for (const doc of allDaos.docs) {
      const data = doc.data();
      console.log(`  - ${data.name} (ID: ${doc.id})`);
    }
    return;
  }

  console.log(`Found DAO: ${dao.id}`);
  console.log(`DAO Name: ${(dao as Record<string, unknown>).name}`);
  console.log(
    `Current admins: ${JSON.stringify((dao as Record<string, unknown>).admins || [])}`
  );

  console.log(`\nLooking for existing membership...`);
  const membership = await findMembership(dao.id, user.id);

  if (membership) {
    console.log(`Found existing membership: ${membership.id}`);
    console.log(
      `Current role: ${(membership as Record<string, unknown>).role}`
    );
    console.log(
      `Current status: ${(membership as Record<string, unknown>).status}`
    );

    if (
      (membership as Record<string, unknown>).role === 'admin' &&
      (membership as Record<string, unknown>).status === 'active'
    ) {
      console.log('\nUser is already an active admin!');
      return;
    }

    console.log('\nUpdating membership to admin...');
    await updateMembershipToAdmin(membership.id, dao.id, user.id);
  } else {
    console.log('No membership found. Creating new membership as admin...');
    const displayName =
      (user as Record<string, unknown>).displayName ||
      (user as Record<string, unknown>).name ||
      'Unknown';
    await createMembership(dao.id, user.id, displayName as string);
    await updateDAOAdmins(dao.id, user.id);
  }

  // Verify the update
  const updatedMembership = await findMembership(dao.id, user.id);
  console.log(`\nVerification:`);
  console.log(`  - Membership ID: ${updatedMembership?.id}`);
  console.log(
    `  - Role: ${(updatedMembership as Record<string, unknown>)?.role}`
  );
  console.log(
    `  - Status: ${(updatedMembership as Record<string, unknown>)?.status}`
  );

  console.log('\nDone!');
}

main().catch(console.error);
