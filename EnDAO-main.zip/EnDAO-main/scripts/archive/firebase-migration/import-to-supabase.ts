/**
 * Supabase Data Import Script
 *
 * Imports data from firebase-export.json into Supabase.
 * Creates ID mappings (Firebase ID → Supabase UUID) for reference integrity.
 *
 * Usage:
 *   npx tsx scripts/import-to-supabase.ts
 *   npx tsx scripts/import-to-supabase.ts --dry-run  # Preview only
 *
 * Prerequisites:
 * - Supabase project created and schema deployed (001_initial_schema.sql)
 * - Environment variables set:
 *   - NEXT_PUBLIC_SUPABASE_URL
 *   - SUPABASE_SERVICE_ROLE_KEY
 * - firebase-export.json exists (from export-firebase-data.ts)
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { config } from 'dotenv';

// Load environment variables
config({ path: '.env.local' });

interface ExportData {
  exportedAt: string;
  users: Record<string, unknown>[];
  daos: Record<string, unknown>[];
  daoMembers: Record<string, unknown>[];
  proposals: Record<string, unknown>[];
  votes: Record<string, unknown>[];
  daoActivities: Record<string, unknown>[];
  daoAdminAuditLogs: Record<string, unknown>[];
  usernames: Record<string, unknown>[];
  adminUsers: Record<string, unknown>[];
  treasuryFreezes: Record<string, unknown>[];
}

interface IdMappings {
  users: Record<string, string>; // Firebase ID/Privy ID → Supabase UUID
  daos: Record<string, string>; // Firebase DAO ID → Supabase UUID
  proposals: Record<string, string>; // Firebase Proposal ID → Supabase UUID
}

async function importData(dryRun: boolean): Promise<void> {
  console.log('\n' + '='.repeat(80));
  console.log('SUPABASE DATA IMPORT');
  console.log('='.repeat(80));
  console.log(`Mode: ${dryRun ? 'DRY RUN (preview only)' : 'IMPORT'}`);

  // Check for export file
  const exportPath = 'firebase-export.json';
  if (!existsSync(exportPath)) {
    console.error(`\n❌ Export file not found: ${exportPath}`);
    console.error('Run: npx tsx scripts/export-firebase-data.ts first');
    process.exit(1);
  }

  // Check environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    console.error('\n❌ Missing Supabase environment variables');
    console.error(
      'Required: NEXT_PUBLIC_SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY'
    );
    process.exit(1);
  }

  // Read export data
  const data: ExportData = JSON.parse(readFileSync(exportPath, 'utf-8'));
  console.log(`\nLoaded export from: ${data.exportedAt}`);

  // Initialize Supabase client (service role bypasses RLS)
  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  // ID mappings
  const idMappings: IdMappings = {
    users: {},
    daos: {},
    proposals: {},
  };

  if (dryRun) {
    console.log('\n⏸️ DRY RUN - Showing what would be imported:\n');
    console.log(`  Users:              ${data.users.length}`);
    console.log(`  DAOs:               ${data.daos.length}`);
    console.log(`  DAO Members:        ${data.daoMembers.length}`);
    console.log(`  Proposals:          ${data.proposals.length}`);
    console.log(`  Votes:              ${data.votes.length}`);
    console.log(`  Activities:         ${data.daoActivities.length}`);
    console.log(`  Admin Audit Logs:   ${data.daoAdminAuditLogs.length}`);
    console.log(`  Usernames:          ${data.usernames.length}`);
    console.log(`  Admin Users:        ${data.adminUsers.length}`);
    console.log(`  Treasury Freezes:   ${data.treasuryFreezes.length}`);
    console.log('\nRun without --dry-run to execute import.');
    return;
  }

  // 1. Import Users
  console.log('\n👤 Importing Users...');
  for (const user of data.users) {
    const firebaseId = user.firebaseId as string;
    const privyId = (user.privyId as string) || firebaseId;

    try {
      const { data: inserted, error } = await supabase
        .from('users')
        .insert({
          privy_id: privyId,
          email: user.email as string | null,
          display_name: user.displayName as string | null,
          username: user.username as string | null,
          lowercase_username: (user.username as string)?.toLowerCase() || null,
          avatar_url: user.avatarUrl as string | null,
          bio: user.bio as string | null,
          profile_setup_complete:
            (user.profileSetupComplete as boolean) || false,
          created_at: (user.createdAt as string) || new Date().toISOString(),
          updated_at: (user.updatedAt as string) || new Date().toISOString(),
        })
        .select()
        .single();

      if (error) {
        console.error(
          `  ❌ Failed: ${user.displayName || privyId}: ${error.message}`
        );
        continue;
      }

      // Map both Firebase ID and Privy ID to new Supabase UUID
      idMappings.users[firebaseId] = inserted.id;
      idMappings.users[privyId] = inserted.id;
      console.log(`  ✅ ${user.displayName || user.email || privyId}`);
    } catch (err) {
      console.error(`  ❌ Error: ${user.displayName || privyId}:`, err);
    }
  }

  // 2. Import DAOs
  console.log('\n📦 Importing DAOs...');
  for (const dao of data.daos) {
    const firebaseId = dao.firebaseId as string;
    const createdByUuid = idMappings.users[dao.createdBy as string] || null;

    try {
      const { data: inserted, error } = await supabase
        .from('daos')
        .insert({
          name: dao.name as string,
          description: dao.description as string | null,
          slug: dao.slug as string | null,
          is_public: (dao.isPublic ?? dao.visibility === 'public') as boolean,
          member_count:
            ((dao.stats as Record<string, unknown>)?.memberCount as number) ||
            (dao.memberCount as number) ||
            0,
          treasury_address: dao.treasuryAddress as string | null,
          treasury_tier: (dao.treasuryTier as number) || 1,
          status: (dao.status as string) || 'active',
          visibility: (dao.visibility as string) || 'public',
          governance_settings:
            (dao.governanceSettings as Record<string, unknown>) || {},
          tags: (dao.tags as string[]) || [],
          social_links: (dao.socialLinks as Record<string, unknown>) || {},
          created_by: createdByUuid,
          created_at: (dao.createdAt as string) || new Date().toISOString(),
          updated_at: (dao.updatedAt as string) || new Date().toISOString(),
        })
        .select()
        .single();

      if (error) {
        console.error(`  ❌ Failed: ${dao.name}: ${error.message}`);
        continue;
      }

      idMappings.daos[firebaseId] = inserted.id;
      console.log(`  ✅ ${dao.name}`);
    } catch (err) {
      console.error(`  ❌ Error: ${dao.name}:`, err);
    }
  }

  // 3. Import DAO Members
  console.log('\n👥 Importing DAO Members...');
  for (const member of data.daoMembers) {
    const daoUuid = idMappings.daos[member.daoId as string];
    const userUuid = idMappings.users[member.userId as string];

    if (!daoUuid || !userUuid) {
      console.warn(
        `  ⚠️ Skipping member - missing mapping: dao=${member.daoId}, user=${member.userId}`
      );
      continue;
    }

    try {
      const { error } = await supabase.from('dao_members').insert({
        dao_id: daoUuid,
        user_id: userUuid,
        role: (member.role as string) || 'member',
        display_name: member.displayName as string | null,
        bio: member.bio as string | null,
        avatar_url: member.avatarUrl as string | null,
        status: (member.status as string) || 'active',
        joined_at: (member.joinedAt as string) || new Date().toISOString(),
        preferences: (member.preferences as Record<string, unknown>) || {},
      });

      if (error) {
        console.error(`  ❌ Failed member: ${error.message}`);
        continue;
      }

      console.log(`  ✅ Member in ${member.daoId}`);
    } catch (err) {
      console.error(`  ❌ Error:`, err);
    }
  }

  // 4. Import Proposals
  console.log('\n📋 Importing Proposals...');
  for (const proposal of data.proposals) {
    const firebaseId = proposal.firebaseId as string;
    const daoUuid = idMappings.daos[proposal.daoId as string];
    const createdByUuid =
      idMappings.users[proposal.createdBy as string] || null;

    if (!daoUuid) {
      console.warn(`  ⚠️ Skipping proposal - DAO not found: ${proposal.daoId}`);
      continue;
    }

    try {
      const { data: inserted, error } = await supabase
        .from('proposals')
        .insert({
          dao_id: daoUuid,
          created_by: createdByUuid,
          title: proposal.title as string,
          description: proposal.description as string | null,
          type: proposal.type as string,
          status: (proposal.status as string) || 'draft',
          voting_config:
            (proposal.votingConfig as Record<string, unknown>) || {},
          voting_start_time: proposal.votingStartTime as string | null,
          voting_end_time: proposal.votingEndTime as string | null,
          execution_method: proposal.executionMethod as string | null,
          execution_data: proposal.executionData as Record<
            string,
            unknown
          > | null,
          executed_at: proposal.executedAt as string | null,
          execution_tx_hash: proposal.executionTxHash as string | null,
          result: proposal.result as Record<string, unknown> | null,
          bounty_reward: proposal.bountyReward as number | null,
          bounty_currency: proposal.bountyCurrency as string | null,
          bounty_deadline: proposal.bountyDeadline as string | null,
          bounty_requirements: proposal.bountyRequirements as string[] | null,
          created_at:
            (proposal.createdAt as string) || new Date().toISOString(),
          updated_at:
            (proposal.updatedAt as string) || new Date().toISOString(),
        })
        .select()
        .single();

      if (error) {
        console.error(`  ❌ Failed: ${proposal.title}: ${error.message}`);
        continue;
      }

      idMappings.proposals[firebaseId] = inserted.id;
      console.log(`  ✅ ${proposal.title}`);
    } catch (err) {
      console.error(`  ❌ Error: ${proposal.title}:`, err);
    }
  }

  // 5. Import Votes
  console.log('\n🗳️ Importing Votes...');
  let votesImported = 0;
  for (const vote of data.votes) {
    const proposalUuid = idMappings.proposals[vote.proposalId as string];
    const userUuid = idMappings.users[vote.userId as string];
    const daoUuid = idMappings.daos[vote.daoId as string];

    if (!proposalUuid || !userUuid || !daoUuid) {
      continue;
    }

    try {
      // Firebase uses 'option' field, PostgreSQL uses 'vote'
      const voteValue = (vote.option ||
        vote.vote ||
        vote.choice ||
        'abstain') as string;

      const { error } = await supabase.from('votes').insert({
        proposal_id: proposalUuid,
        user_id: userUuid,
        dao_id: daoUuid,
        vote: voteValue,
        voting_power: (vote.votingPower as number) || 1,
        ranked_choices: vote.rankedChoices as string[] | null,
        created_at: (vote.createdAt as string) || new Date().toISOString(),
      });

      if (error) {
        console.error(`  ❌ Vote failed: ${error.message}`);
        continue;
      }

      votesImported++;
    } catch (err) {
      console.error(`  ❌ Vote error:`, err);
    }
  }
  console.log(`  ✅ ${votesImported} votes imported`);

  // 6. Import Activities
  console.log('\n📰 Importing Activities...');
  let activitiesImported = 0;
  for (const activity of data.daoActivities) {
    const daoUuid = idMappings.daos[activity.daoId as string];
    const userUuid = idMappings.users[activity.userId as string] || null;
    const proposalUuid =
      idMappings.proposals[activity.proposalId as string] || null;

    if (!daoUuid) continue;

    try {
      const { error } = await supabase.from('dao_activities').insert({
        dao_id: daoUuid,
        user_id: userUuid,
        activity_type:
          (activity.type as string) || (activity.activityType as string),
        title: activity.title as string | null,
        description: activity.description as string | null,
        metadata: (activity.metadata as Record<string, unknown>) || {},
        proposal_id: proposalUuid,
        created_at: (activity.createdAt as string) || new Date().toISOString(),
      });

      if (error) {
        console.error(`  ❌ Activity failed: ${error.message}`);
        continue;
      }

      activitiesImported++;
    } catch (err) {
      console.error(`  ❌ Activity error:`, err);
    }
  }
  console.log(`  ✅ ${activitiesImported} activities imported`);

  // 7. Import Admin Audit Logs
  console.log('\n📝 Importing Admin Audit Logs...');
  let auditLogsImported = 0;
  for (const log of data.daoAdminAuditLogs) {
    const daoUuid = idMappings.daos[log.daoId as string];
    const adminUuid = idMappings.users[log.adminId as string] || null;

    if (!daoUuid) continue;

    try {
      const { error } = await supabase.from('dao_admin_audit_logs').insert({
        dao_id: daoUuid,
        admin_id: adminUuid,
        admin_name: log.adminName as string | null,
        action: log.action as string,
        target_id: log.targetId as string | null,
        target_name: log.targetName as string | null,
        reason: log.reason as string | null,
        metadata: (log.metadata as Record<string, unknown>) || {},
        ip_address: log.ipAddress as string | null,
        created_at: (log.createdAt as string) || new Date().toISOString(),
      });

      if (error) {
        console.error(`  ❌ Audit log failed: ${error.message}`);
        continue;
      }

      auditLogsImported++;
    } catch (err) {
      console.error(`  ❌ Audit log error:`, err);
    }
  }
  console.log(`  ✅ ${auditLogsImported} audit logs imported`);

  // 8. Import Usernames
  console.log('\n🏷️ Importing Usernames...');
  let usernamesImported = 0;
  for (const username of data.usernames) {
    const userUuid = idMappings.users[username.userId as string] || null;

    if (!userUuid) continue;

    try {
      const { error } = await supabase.from('usernames').insert({
        username: username.username as string,
        lowercase_username: (username.username as string).toLowerCase(),
        user_id: userUuid,
        claimed_at: (username.claimedAt as string) || new Date().toISOString(),
      });

      if (error) {
        console.error(`  ❌ Username failed: ${error.message}`);
        continue;
      }

      usernamesImported++;
      console.log(`  ✅ @${username.username}`);
    } catch (err) {
      console.error(`  ❌ Username error:`, err);
    }
  }

  // 9. Import Admin Users
  console.log('\n👑 Importing Admin Users...');
  for (const admin of data.adminUsers) {
    const userUuid = idMappings.users[admin.userId as string];

    if (!userUuid) continue;

    try {
      const { error } = await supabase.from('admin_users').insert({
        user_id: userUuid,
        role: (admin.role as string) || 'admin',
        created_at: (admin.createdAt as string) || new Date().toISOString(),
      });

      if (error) {
        console.error(`  ❌ Admin user failed: ${error.message}`);
        continue;
      }

      console.log(`  ✅ Admin: ${admin.userId}`);
    } catch (err) {
      console.error(`  ❌ Admin user error:`, err);
    }
  }

  // 10. Import Treasury Freezes
  console.log('\n🧊 Importing Treasury Freezes...');
  for (const freeze of data.treasuryFreezes) {
    const daoUuid = idMappings.daos[freeze.daoId as string];
    const frozenByUuid = idMappings.users[freeze.frozenBy as string];

    if (!daoUuid || !frozenByUuid) continue;

    try {
      const { error } = await supabase.from('treasury_freezes').insert({
        dao_id: daoUuid,
        frozen_by: frozenByUuid,
        reason: freeze.reason as string | null,
        frozen_at: (freeze.frozenAt as string) || new Date().toISOString(),
        expires_at: freeze.expiresAt as string | null,
      });

      if (error) {
        console.error(`  ❌ Treasury freeze failed: ${error.message}`);
        continue;
      }

      console.log(`  ✅ Freeze for DAO ${freeze.daoId}`);
    } catch (err) {
      console.error(`  ❌ Treasury freeze error:`, err);
    }
  }

  // Save ID mappings
  const mappingsPath = 'supabase-id-mappings.json';
  writeFileSync(mappingsPath, JSON.stringify(idMappings, null, 2));

  // Summary
  console.log('\n' + '='.repeat(80));
  console.log('IMPORT COMPLETE');
  console.log('='.repeat(80));
  console.log(`
  Users imported:       ${Object.keys(idMappings.users).length / 2}
  DAOs imported:        ${Object.keys(idMappings.daos).length}
  Proposals imported:   ${Object.keys(idMappings.proposals).length}
  Votes imported:       ${votesImported}
  Activities imported:  ${activitiesImported}
  Audit logs imported:  ${auditLogsImported}
  Usernames imported:   ${usernamesImported}

  ID mappings saved to: ${mappingsPath}
  `);
}

async function main(): Promise<void> {
  const dryRun = process.argv.includes('--dry-run');

  try {
    await importData(dryRun);
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Import failed:', error);
    process.exit(1);
  }
}

main();
