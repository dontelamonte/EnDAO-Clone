/**
 * Firebase Data Export Script
 *
 * Exports ONLY real data from Firebase for migration to Supabase.
 * Based on investigation results - excludes test/orphan data.
 *
 * Usage:
 *   npx tsx scripts/export-firebase-data.ts
 *   npx tsx scripts/export-firebase-data.ts --dry-run  # Preview only
 *
 * Output: firebase-export.json
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { writeFileSync } from 'fs';
import { config } from 'dotenv';

// Load environment variables
config({ path: '.env.local' });

// Initialize Firebase Admin
if (getApps().length === 0) {
  const projectId = process.env.FIREBASE_ADMIN_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_ADMIN_CLIENT_EMAIL;
  const privateKeyRaw = process.env.FIREBASE_ADMIN_PRIVATE_KEY;

  if (!projectId || !clientEmail || !privateKeyRaw) {
    console.error('Missing Firebase Admin credentials');
    process.exit(1);
  }

  let privateKey = privateKeyRaw;
  if (privateKey.startsWith('"') && privateKey.endsWith('"')) {
    privateKey = privateKey.slice(1, -1);
  }
  privateKey = privateKey.replace(/\\n/g, '\n');

  initializeApp({
    credential: cert({ projectId, clientEmail, privateKey }),
  });
}

const db = getFirestore();

// Real DAO IDs (from investigation)
const REAL_DAO_IDS = [
  '0hgqwriHfFJMENyD2jQh', // VMF Collective
  'I0xtBCjuiAeaiHbGQNu5', // CST
];

interface ExportData {
  exportedAt: string;
  users: Record<string, unknown>[];
  daos: Record<string, unknown>[];
  daoMembers: Record<string, unknown>[];
  proposals: Record<string, unknown>[];
  votes: Record<string, unknown>[];
  daoActivities: Record<string, unknown>[];
  daoAdminAuditLogs: Record<string, unknown>[];
  usernames: Record<string, unknown>[];
  adminUsers: Record<string, unknown>[];
  treasuryFreezes: Record<string, unknown>[];
}

function formatTimestamp(ts: Timestamp | undefined | null): string | null {
  if (!ts) return null;
  try {
    return ts.toDate().toISOString();
  } catch {
    return null;
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function sanitizeData(data: Record<string, any>): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value instanceof Timestamp) {
      result[key] = formatTimestamp(value);
    } else if (value && typeof value === 'object' && '_seconds' in value) {
      // Handle serialized Timestamp objects
      result[key] = new Date(value._seconds * 1000).toISOString();
    } else if (Array.isArray(value)) {
      result[key] = value.map((item) =>
        item instanceof Timestamp ? formatTimestamp(item) : item
      );
    } else {
      result[key] = value;
    }
  }
  return result;
}

async function exportData(dryRun: boolean): Promise<void> {
  console.log('\n' + '='.repeat(80));
  console.log('FIREBASE DATA EXPORT - Real Data Only');
  console.log('='.repeat(80));
  console.log(`Mode: ${dryRun ? 'DRY RUN (preview only)' : 'EXPORT'}`);
  console.log(`Real DAO IDs: ${REAL_DAO_IDS.join(', ')}`);

  const exportData: ExportData = {
    exportedAt: new Date().toISOString(),
    users: [],
    daos: [],
    daoMembers: [],
    proposals: [],
    votes: [],
    daoActivities: [],
    daoAdminAuditLogs: [],
    usernames: [],
    adminUsers: [],
    treasuryFreezes: [],
  };

  // Track user IDs for later filtering
  const userPrivyIds = new Set<string>();
  const userFirebaseIds = new Set<string>();

  // 1. Export Real DAOs
  console.log('\n📦 Exporting DAOs...');
  for (const daoId of REAL_DAO_IDS) {
    const daoDoc = await db.collection('daos').doc(daoId).get();
    if (daoDoc.exists) {
      const data = daoDoc.data()!;
      exportData.daos.push({
        firebaseId: daoDoc.id,
        ...sanitizeData(data),
      });
      console.log(`  ✅ ${data.name} (${daoId})`);
    } else {
      console.log(`  ⚠️ DAO ${daoId} not found`);
    }
  }

  // 2. Export Members of Real DAOs
  console.log('\n👥 Exporting DAO Members...');
  for (const daoId of REAL_DAO_IDS) {
    const membersSnap = await db
      .collection('dao-members')
      .where('daoId', '==', daoId)
      .get();

    for (const doc of membersSnap.docs) {
      const data = doc.data();
      exportData.daoMembers.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
      // Track user IDs
      if (data.userId) {
        userPrivyIds.add(data.userId);
        userFirebaseIds.add(data.userId);
      }
    }
    console.log(`  ✅ ${membersSnap.size} members from DAO ${daoId}`);
  }

  // 3. Export Users (members of real DAOs + completed profiles)
  console.log('\n👤 Exporting Users...');
  const usersSnap = await db.collection('users').get();
  for (const doc of usersSnap.docs) {
    const data = doc.data();
    const isRealMember =
      userPrivyIds.has(data.privyId) || userFirebaseIds.has(doc.id);
    const hasCompleteProfile = data.profileSetupComplete === true;

    if (isRealMember || hasCompleteProfile) {
      exportData.users.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
      // Add to tracking sets for usernames
      if (data.privyId) userPrivyIds.add(data.privyId);
      userFirebaseIds.add(doc.id);
      console.log(`  ✅ ${data.displayName || data.email || data.privyId}`);
    }
  }
  console.log(`  Total: ${exportData.users.length} users`);

  // 4. Export Proposals from Real DAOs
  console.log('\n📋 Exporting Proposals...');
  for (const daoId of REAL_DAO_IDS) {
    const proposalsSnap = await db
      .collection('proposals')
      .where('daoId', '==', daoId)
      .get();

    for (const doc of proposalsSnap.docs) {
      const data = doc.data();
      exportData.proposals.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
    }
    console.log(`  ✅ ${proposalsSnap.size} proposals from DAO ${daoId}`);
  }

  // 5. Export Votes from Real DAOs only
  console.log('\n🗳️ Exporting Votes...');
  for (const daoId of REAL_DAO_IDS) {
    const votesSnap = await db
      .collection('votes')
      .where('daoId', '==', daoId)
      .get();

    for (const doc of votesSnap.docs) {
      const data = doc.data();
      exportData.votes.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
    }
    console.log(`  ✅ ${votesSnap.size} votes from DAO ${daoId}`);
  }

  // 6. Export Activities from Real DAOs
  console.log('\n📰 Exporting DAO Activities...');
  for (const daoId of REAL_DAO_IDS) {
    const activitiesSnap = await db
      .collection('dao-activities')
      .where('daoId', '==', daoId)
      .get();

    for (const doc of activitiesSnap.docs) {
      const data = doc.data();
      exportData.daoActivities.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
    }
    console.log(`  ✅ ${activitiesSnap.size} activities from DAO ${daoId}`);
  }

  // 7. Export Admin Audit Logs from Real DAOs
  console.log('\n📝 Exporting Admin Audit Logs...');
  for (const daoId of REAL_DAO_IDS) {
    const logsSnap = await db
      .collection('dao-admin-audit-logs')
      .where('daoId', '==', daoId)
      .get();

    for (const doc of logsSnap.docs) {
      const data = doc.data();
      exportData.daoAdminAuditLogs.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
    }
    console.log(`  ✅ ${logsSnap.size} audit logs from DAO ${daoId}`);
  }

  // 8. Export Usernames for exported users
  console.log('\n🏷️ Exporting Usernames...');
  const usernamesSnap = await db.collection('usernames').get();
  for (const doc of usernamesSnap.docs) {
    const data = doc.data();
    // Only export if owned by a user we're exporting
    if (
      data.userId &&
      (userPrivyIds.has(data.userId) || userFirebaseIds.has(data.userId))
    ) {
      exportData.usernames.push({
        username: doc.id,
        ...sanitizeData(data),
      });
      console.log(`  ✅ @${doc.id}`);
    }
  }

  // 9. Export Admin Users
  console.log('\n👑 Exporting Admin Users...');
  const adminUsersSnap = await db.collection('admin_users').get();
  for (const doc of adminUsersSnap.docs) {
    const data = doc.data();
    // Only export if user is being exported
    if (userPrivyIds.has(data.userId) || userFirebaseIds.has(data.userId)) {
      exportData.adminUsers.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
      console.log(`  ✅ Admin: ${data.userId}`);
    }
  }

  // 10. Export Treasury Freezes for Real DAOs
  console.log('\n🧊 Exporting Treasury Freezes...');
  for (const daoId of REAL_DAO_IDS) {
    const freezesSnap = await db
      .collection('treasuryFreezes')
      .where('daoId', '==', daoId)
      .get();

    for (const doc of freezesSnap.docs) {
      const data = doc.data();
      exportData.treasuryFreezes.push({
        firebaseId: doc.id,
        ...sanitizeData(data),
      });
    }
    if (freezesSnap.size > 0) {
      console.log(`  ✅ ${freezesSnap.size} freezes from DAO ${daoId}`);
    }
  }

  // Summary
  console.log('\n' + '='.repeat(80));
  console.log('EXPORT SUMMARY');
  console.log('='.repeat(80));
  console.log(`
  DAOs:                 ${exportData.daos.length}
  Users:                ${exportData.users.length}
  DAO Members:          ${exportData.daoMembers.length}
  Proposals:            ${exportData.proposals.length}
  Votes:                ${exportData.votes.length}
  Activities:           ${exportData.daoActivities.length}
  Admin Audit Logs:     ${exportData.daoAdminAuditLogs.length}
  Usernames:            ${exportData.usernames.length}
  Admin Users:          ${exportData.adminUsers.length}
  Treasury Freezes:     ${exportData.treasuryFreezes.length}
  `);

  if (!dryRun) {
    const outputPath = 'firebase-export.json';
    writeFileSync(outputPath, JSON.stringify(exportData, null, 2));
    console.log(`\n✅ Export saved to: ${outputPath}`);
  } else {
    console.log(
      '\n⏸️ DRY RUN - No file written. Run without --dry-run to export.'
    );
  }
}

async function main(): Promise<void> {
  const dryRun = process.argv.includes('--dry-run');

  try {
    await exportData(dryRun);
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Export failed:', error);
    process.exit(1);
  }
}

main();
