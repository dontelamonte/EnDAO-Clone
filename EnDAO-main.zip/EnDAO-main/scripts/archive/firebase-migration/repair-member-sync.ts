/**
 * Repair Member Sync Script
 *
 * Rebuilds DAO member arrays (memberIds[], admins[], stats.memberCount) from the
 * source-of-truth dao-members collection to fix sync issues.
 *
 * Usage:
 *   # Dry run (show what would change)
 *   npx tsx scripts/repair-member-sync.ts --dao <daoId> --dry-run
 *
 *   # Repair single DAO
 *   npx tsx scripts/repair-member-sync.ts --dao <daoId> --apply
 *
 *   # Repair all DAOs (requires confirmation)
 *   npx tsx scripts/repair-member-sync.ts --all --apply
 *
 *   # Dry run all DAOs
 *   npx tsx scripts/repair-member-sync.ts --all --dry-run
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore, Timestamp, WriteBatch } from 'firebase-admin/firestore';
import { readFileSync } from 'fs';
import { join } from 'path';
import * as readline from 'readline';

// Initialize Firebase Admin
if (getApps().length === 0) {
  const serviceAccountPath = join(process.cwd(), 'serviceAccountKey.json');

  try {
    const serviceAccount = JSON.parse(
      readFileSync(serviceAccountPath, 'utf-8')
    );
    initializeApp({
      credential: cert(serviceAccount),
    });
  } catch (error) {
    console.error(
      'Failed to load serviceAccountKey.json from:',
      serviceAccountPath
    );
    console.error(error);
    process.exit(1);
  }
}

const db = getFirestore();

interface DAOMember {
  userId: string;
  role: 'member' | 'admin';
  isActive?: boolean;
  status?: string;
}

interface DAODocument {
  id: string;
  name: string;
  memberIds: string[];
  admins: string[];
  stats?: {
    memberCount?: number;
  };
  memberCount?: number;
}

interface MemberSyncReport {
  daoId: string;
  daoName: string;
  current: {
    memberIds: string[];
    admins: string[];
    memberCount: number;
  };
  actual: {
    memberIds: string[];
    admins: string[];
    memberCount: number;
  };
  changes: {
    memberIdsToAdd: string[];
    memberIdsToRemove: string[];
    adminsToAdd: string[];
    adminsToRemove: string[];
    memberCountChange: number;
  };
  needsRepair: boolean;
}

/**
 * Fetch active members from dao-members collection
 */
async function getActiveMembersFromCollection(
  daoId: string
): Promise<DAOMember[]> {
  const membersRef = db.collection('dao-members');
  const snapshot = await membersRef.where('daoId', '==', daoId).get();

  const members: DAOMember[] = [];

  for (const doc of snapshot.docs) {
    const data = doc.data();

    // Only include active members (isActive !== false and status !== 'inactive')
    const isActive = data.isActive !== false && data.status !== 'inactive';

    if (isActive) {
      members.push({
        userId: data.userId,
        role: data.role || 'member',
        isActive: data.isActive,
        status: data.status,
      });
    }
  }

  return members;
}

/**
 * Get current DAO document data
 */
async function getDAODocument(daoId: string): Promise<DAODocument | null> {
  const daoRef = db.collection('daos').doc(daoId);
  const daoSnap = await daoRef.get();

  if (!daoSnap.exists) {
    return null;
  }

  const data = daoSnap.data()!;
  return {
    id: daoSnap.id,
    name: data.name || 'Unknown DAO',
    memberIds: data.memberIds || [],
    admins: data.admins || [],
    stats: data.stats,
    memberCount: data.memberCount || data.stats?.memberCount || 0,
  };
}

/**
 * Analyze sync differences and generate repair report
 */
async function analyzeMemberSync(
  daoId: string
): Promise<MemberSyncReport | null> {
  const dao = await getDAODocument(daoId);
  if (!dao) {
    console.error(`DAO not found: ${daoId}`);
    return null;
  }

  const activeMembers = await getActiveMembersFromCollection(daoId);

  // Build actual arrays from dao-members collection
  const actualMemberIds = activeMembers.map((m) => m.userId);
  const actualAdmins = activeMembers
    .filter((m) => m.role === 'admin')
    .map((m) => m.userId);
  const actualMemberCount = activeMembers.length;

  // Calculate differences
  const currentMemberIds = new Set(dao.memberIds);
  const currentAdmins = new Set(dao.admins);
  const actualMemberIdSet = new Set(actualMemberIds);
  const actualAdminSet = new Set(actualAdmins);

  const memberIdsToAdd = actualMemberIds.filter(
    (id) => !currentMemberIds.has(id)
  );
  const memberIdsToRemove = dao.memberIds.filter(
    (id) => !actualMemberIdSet.has(id)
  );
  const adminsToAdd = actualAdmins.filter((id) => !currentAdmins.has(id));
  const adminsToRemove = dao.admins.filter((id) => !actualAdminSet.has(id));
  const memberCountChange = actualMemberCount - dao.memberCount;

  const needsRepair =
    memberIdsToAdd.length > 0 ||
    memberIdsToRemove.length > 0 ||
    adminsToAdd.length > 0 ||
    adminsToRemove.length > 0 ||
    memberCountChange !== 0;

  return {
    daoId,
    daoName: dao.name,
    current: {
      memberIds: dao.memberIds,
      admins: dao.admins,
      memberCount: dao.memberCount,
    },
    actual: {
      memberIds: actualMemberIds,
      admins: actualAdmins,
      memberCount: actualMemberCount,
    },
    changes: {
      memberIdsToAdd,
      memberIdsToRemove,
      adminsToAdd,
      adminsToRemove,
      memberCountChange,
    },
    needsRepair,
  };
}

/**
 * Print sync report
 */
function printReport(report: MemberSyncReport): void {
  console.log(`\n${'='.repeat(60)}`);
  console.log(`DAO: ${report.daoName} (${report.daoId})`);
  console.log('='.repeat(60));

  if (!report.needsRepair) {
    console.log('✓ No sync issues detected. All arrays are in sync.');
    return;
  }

  console.log('\n📋 Current State (DAO Document):');
  console.log(
    `  memberIds: [${report.current.memberIds.join(', ')}] (${report.current.memberIds.length} members)`
  );
  console.log(
    `  admins: [${report.current.admins.join(', ')}] (${report.current.admins.length} admins)`
  );
  console.log(`  memberCount: ${report.current.memberCount}`);

  console.log('\n🔍 Actual State (dao-members collection):');
  console.log(
    `  Active members: [${report.actual.memberIds.join(', ')}] (${report.actual.memberCount} members)`
  );
  console.log(
    `  Admins: [${report.actual.admins.join(', ')}] (${report.actual.admins.length} admins)`
  );

  console.log('\n🔧 Changes to Apply:');

  if (report.changes.memberIdsToAdd.length > 0) {
    console.log(
      `  memberIds - ADD: ${report.changes.memberIdsToAdd.join(', ')}`
    );
  }

  if (report.changes.memberIdsToRemove.length > 0) {
    console.log(
      `  memberIds - REMOVE: ${report.changes.memberIdsToRemove.join(', ')}`
    );
  }

  if (report.changes.adminsToAdd.length > 0) {
    console.log(`  admins - ADD: ${report.changes.adminsToAdd.join(', ')}`);
  }

  if (report.changes.adminsToRemove.length > 0) {
    console.log(
      `  admins - REMOVE: ${report.changes.adminsToRemove.join(', ')}`
    );
  }

  if (report.changes.memberCountChange !== 0) {
    const direction = report.changes.memberCountChange > 0 ? '↑' : '↓';
    console.log(
      `  memberCount: ${report.current.memberCount} ${direction} ${report.actual.memberCount} (${report.changes.memberCountChange > 0 ? '+' : ''}${report.changes.memberCountChange})`
    );
  }
}

/**
 * Apply repairs to DAO document
 */
async function applyRepair(
  report: MemberSyncReport,
  batch?: WriteBatch
): Promise<void> {
  if (!report.needsRepair) {
    return;
  }

  const daoRef = db.collection('daos').doc(report.daoId);
  const useBatch = batch !== undefined;
  const batchToUse = batch || db.batch();

  const updates: Record<string, unknown> = {
    memberIds: report.actual.memberIds,
    admins: report.actual.admins,
    'stats.memberCount': report.actual.memberCount,
    memberCount: report.actual.memberCount, // Also update top-level for backward compatibility
    updatedAt: Timestamp.now(),
  };

  batchToUse.update(daoRef, updates);

  if (!useBatch) {
    await batchToUse.commit();
    console.log(`\n✓ Repair complete for ${report.daoName}`);
  }
}

/**
 * Get all DAO IDs
 */
async function getAllDAOIds(): Promise<string[]> {
  const daosRef = db.collection('daos');
  const snapshot = await daosRef.select('__name__').get();
  return snapshot.docs.map((doc) => doc.id);
}

/**
 * Ask for user confirmation
 */
async function askConfirmation(question: string): Promise<boolean> {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    rl.question(`${question} (y/n): `, (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes');
    });
  });
}

/**
 * Main execution function
 */
async function main() {
  const args = process.argv.slice(2);

  // Parse arguments
  const daoIndex = args.indexOf('--dao');
  const daoId = daoIndex !== -1 ? args[daoIndex + 1] : null;
  const isAllDAOs = args.includes('--all');
  const isDryRun = args.includes('--dry-run');
  const isApply = args.includes('--apply');

  // Validation
  if (!daoId && !isAllDAOs) {
    console.log('Usage:');
    console.log(
      '  npx tsx scripts/repair-member-sync.ts --dao <daoId> --dry-run'
    );
    console.log(
      '  npx tsx scripts/repair-member-sync.ts --dao <daoId> --apply'
    );
    console.log('  npx tsx scripts/repair-member-sync.ts --all --dry-run');
    console.log('  npx tsx scripts/repair-member-sync.ts --all --apply');
    console.log('\nOptions:');
    console.log('  --dao <daoId>  Repair specific DAO');
    console.log('  --all          Repair all DAOs');
    console.log('  --dry-run      Show changes without applying');
    console.log('  --apply        Apply changes');
    process.exit(1);
  }

  if (!isDryRun && !isApply) {
    console.error('Error: Must specify either --dry-run or --apply');
    process.exit(1);
  }

  if (isDryRun && isApply) {
    console.error('Error: Cannot use both --dry-run and --apply');
    process.exit(1);
  }

  const mode = isDryRun ? 'DRY RUN' : 'APPLY CHANGES';
  console.log(`\n🔧 Member Sync Repair Tool - ${mode}`);
  console.log('='.repeat(60));

  // Get DAOs to repair
  let daoIds: string[] = [];

  if (daoId) {
    daoIds = [daoId];
  } else if (isAllDAOs) {
    console.log('\n⏳ Fetching all DAOs...');
    daoIds = await getAllDAOIds();
    console.log(`Found ${daoIds.length} DAOs`);

    if (isApply) {
      const confirmed = await askConfirmation(
        `\n⚠️  This will repair ${daoIds.length} DAOs. Continue?`
      );
      if (!confirmed) {
        console.log('Cancelled.');
        return;
      }
    }
  }

  // Process each DAO
  const reports: MemberSyncReport[] = [];
  let processed = 0;
  let repaired = 0;
  let errors = 0;

  for (const currentDaoId of daoIds) {
    try {
      const report = await analyzeMemberSync(currentDaoId);

      if (!report) {
        errors++;
        continue;
      }

      reports.push(report);
      processed++;

      printReport(report);

      if (isApply && report.needsRepair) {
        await applyRepair(report);
        repaired++;
      }
    } catch (error) {
      console.error(`\n❌ Error processing DAO ${currentDaoId}:`, error);
      errors++;
    }
  }

  // Summary
  console.log('\n' + '='.repeat(60));
  console.log('📊 SUMMARY');
  console.log('='.repeat(60));
  console.log(`Total DAOs processed: ${processed}`);
  console.log(
    `DAOs needing repair: ${reports.filter((r) => r.needsRepair).length}`
  );
  console.log(
    `DAOs already in sync: ${reports.filter((r) => !r.needsRepair).length}`
  );

  if (isApply) {
    console.log(`✓ DAOs repaired: ${repaired}`);
  }

  if (errors > 0) {
    console.log(`❌ Errors: ${errors}`);
  }

  if (isDryRun && reports.some((r) => r.needsRepair)) {
    console.log(
      '\n💡 To apply these changes, run with --apply instead of --dry-run'
    );
  }

  console.log('\nDone!');
}

main().catch(console.error);
