/**
 * Migration Script: Firebase UID -> Privy ID
 *
 * This script migrates all user references from Firebase UIDs to Privy IDs.
 * After migration, the system will use Privy ID as the canonical user identifier.
 *
 * Usage:
 *   # Dry run (no changes)
 *   GOOGLE_APPLICATION_CREDENTIALS=./serviceAccountKey.json npx tsx scripts/migrate-to-privy-id.ts --dry-run
 *
 *   # Actual migration
 *   GOOGLE_APPLICATION_CREDENTIALS=./serviceAccountKey.json npx tsx scripts/migrate-to-privy-id.ts
 */

import * as admin from 'firebase-admin';

// Initialize Firebase Admin
const serviceAccount = require('../serviceAccountKey.json');

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const db = admin.firestore();
const DRY_RUN = process.argv.includes('--dry-run');

interface MigrationStats {
  usersUpdated: number;
  daosUpdated: number;
  membersUpdated: number;
  proposalsUpdated: number;
  votesUpdated: number;
  commentsUpdated: number;
  activitiesUpdated: number;
  errors: string[];
}

const stats: MigrationStats = {
  usersUpdated: 0,
  daosUpdated: 0,
  membersUpdated: 0,
  proposalsUpdated: 0,
  votesUpdated: 0,
  commentsUpdated: 0,
  activitiesUpdated: 0,
  errors: [],
};

/**
 * Build the Firebase UID -> Privy ID mapping from privyUsers collection
 */
async function buildUidMapping(): Promise<Map<string, string>> {
  console.log('\n📋 Building UID -> Privy ID mapping...');

  const mapping = new Map<string, string>();
  const privyUsersSnapshot = await db.collection('privyUsers').get();

  privyUsersSnapshot.forEach((doc) => {
    const privyId = doc.id; // Document ID is the Privy ID
    const firebaseUid = doc.data().uid; // The uid field is the Firebase UID

    if (firebaseUid && firebaseUid !== privyId) {
      mapping.set(firebaseUid, privyId);
      console.log(`   ${firebaseUid} -> ${privyId}`);
    } else if (firebaseUid === privyId) {
      // Already using Privy ID as UID, no migration needed for this user
      console.log(`   ${privyId} (already Privy ID)`);
    }
  });

  console.log(`\n✅ Found ${mapping.size} users needing migration`);
  console.log(
    `   (${privyUsersSnapshot.size - mapping.size} already using Privy ID)`
  );

  return mapping;
}

/**
 * Export current state for backup
 */
async function exportBackup(uidMapping: Map<string, string>) {
  console.log('\n💾 Exporting backup...');

  const backup = {
    timestamp: new Date().toISOString(),
    uidMapping: Object.fromEntries(uidMapping),
    privyUsersCount: uidMapping.size,
  };

  const backupPath = `./scripts/backup-${Date.now()}.json`;
  const fs = require('fs');
  fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2));
  console.log(`   Backup saved to: ${backupPath}`);

  return backup;
}

/**
 * Migrate a single user ID (returns Privy ID if mapping exists, otherwise original)
 */
function migrateUserId(
  uid: string | undefined,
  uidMapping: Map<string, string>
): string | undefined {
  if (!uid) return uid;
  return uidMapping.get(uid) || uid; // Return Privy ID if found, else keep original
}

/**
 * Migrate an array of user IDs
 */
function migrateUserIdArray(
  uids: string[] | undefined,
  uidMapping: Map<string, string>
): string[] | undefined {
  if (!uids || !Array.isArray(uids)) return uids;
  return uids.map((uid) => migrateUserId(uid, uidMapping)!);
}

/**
 * Migrate users collection - re-key documents from Firebase UID to Privy ID
 */
async function migrateUsers(uidMapping: Map<string, string>) {
  console.log('\n👤 Migrating users collection...');

  const usersSnapshot = await db.collection('users').get();

  for (const userDoc of usersSnapshot.docs) {
    const firebaseUid = userDoc.id;
    const privyId = uidMapping.get(firebaseUid);

    if (!privyId) {
      // This user might already be using Privy ID or not in mapping
      continue;
    }

    const userData = userDoc.data();

    if (DRY_RUN) {
      console.log(
        `   [DRY RUN] Would migrate user ${firebaseUid} -> ${privyId}`
      );
      stats.usersUpdated++;
      continue;
    }

    try {
      // Create new document with Privy ID
      await db
        .collection('users')
        .doc(privyId)
        .set({
          ...userData,
          id: privyId, // Update the id field
          // Keep privyUserId for backwards compatibility
          privyUserId: privyId,
          migratedFrom: firebaseUid,
          migratedAt: admin.firestore.Timestamp.now(),
        });

      // Delete old document
      await db.collection('users').doc(firebaseUid).delete();

      console.log(`   ✅ Migrated user ${firebaseUid} -> ${privyId}`);
      stats.usersUpdated++;
    } catch (error) {
      const msg = `Failed to migrate user ${firebaseUid}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Migrate DAOs - update createdBy, admins[], memberIds[]
 */
async function migrateDAOs(uidMapping: Map<string, string>) {
  console.log('\n🏛️  Migrating daos collection...');

  const daosSnapshot = await db.collection('daos').get();

  for (const daoDoc of daosSnapshot.docs) {
    const daoData = daoDoc.data();
    const updates: Record<string, unknown> = {};
    let needsUpdate = false;

    // Migrate createdBy
    if (daoData.createdBy && uidMapping.has(daoData.createdBy)) {
      updates.createdBy = uidMapping.get(daoData.createdBy);
      needsUpdate = true;
    }

    // Migrate creatorId
    if (daoData.creatorId && uidMapping.has(daoData.creatorId)) {
      updates.creatorId = uidMapping.get(daoData.creatorId);
      needsUpdate = true;
    }

    // Migrate admins array
    if (daoData.admins && Array.isArray(daoData.admins)) {
      const migratedAdmins = migrateUserIdArray(daoData.admins, uidMapping);
      if (JSON.stringify(migratedAdmins) !== JSON.stringify(daoData.admins)) {
        updates.admins = migratedAdmins;
        needsUpdate = true;
      }
    }

    // Migrate memberIds array
    if (daoData.memberIds && Array.isArray(daoData.memberIds)) {
      const migratedMemberIds = migrateUserIdArray(
        daoData.memberIds,
        uidMapping
      );
      if (
        JSON.stringify(migratedMemberIds) !== JSON.stringify(daoData.memberIds)
      ) {
        updates.memberIds = migratedMemberIds;
        needsUpdate = true;
      }
    }

    if (!needsUpdate) continue;

    if (DRY_RUN) {
      console.log(
        `   [DRY RUN] Would update DAO ${daoData.name}: ${JSON.stringify(updates)}`
      );
      stats.daosUpdated++;
      continue;
    }

    try {
      await daoDoc.ref.update(updates);
      console.log(`   ✅ Updated DAO ${daoData.name}`);
      stats.daosUpdated++;
    } catch (error) {
      const msg = `Failed to update DAO ${daoDoc.id}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Migrate dao-members - update userId, invitedBy, approvedBy
 */
async function migrateMembers(uidMapping: Map<string, string>) {
  console.log('\n👥 Migrating dao-members collection...');

  const membersSnapshot = await db.collection('dao-members').get();

  for (const memberDoc of membersSnapshot.docs) {
    const memberData = memberDoc.data();
    const updates: Record<string, unknown> = {};
    let needsUpdate = false;

    // Migrate userId
    if (memberData.userId && uidMapping.has(memberData.userId)) {
      updates.userId = uidMapping.get(memberData.userId);
      needsUpdate = true;
    }

    // Migrate invitedBy
    if (memberData.invitedBy && uidMapping.has(memberData.invitedBy)) {
      updates.invitedBy = uidMapping.get(memberData.invitedBy);
      needsUpdate = true;
    }

    // Migrate approvedBy
    if (memberData.approvedBy && uidMapping.has(memberData.approvedBy)) {
      updates.approvedBy = uidMapping.get(memberData.approvedBy);
      needsUpdate = true;
    }

    if (!needsUpdate) continue;

    if (DRY_RUN) {
      console.log(
        `   [DRY RUN] Would update member ${memberDoc.id}: ${JSON.stringify(updates)}`
      );
      stats.membersUpdated++;
      continue;
    }

    try {
      await memberDoc.ref.update(updates);
      console.log(`   ✅ Updated member ${memberDoc.id}`);
      stats.membersUpdated++;
    } catch (error) {
      const msg = `Failed to update member ${memberDoc.id}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Migrate proposals - update createdBy, approvedBy, executedBy
 */
async function migrateProposals(uidMapping: Map<string, string>) {
  console.log('\n📝 Migrating proposals collection...');

  const proposalsSnapshot = await db.collection('proposals').get();

  for (const proposalDoc of proposalsSnapshot.docs) {
    const proposalData = proposalDoc.data();
    const updates: Record<string, unknown> = {};
    let needsUpdate = false;

    // Migrate createdBy
    if (proposalData.createdBy && uidMapping.has(proposalData.createdBy)) {
      updates.createdBy = uidMapping.get(proposalData.createdBy);
      needsUpdate = true;
    }

    // Migrate approvedBy
    if (proposalData.approvedBy && uidMapping.has(proposalData.approvedBy)) {
      updates.approvedBy = uidMapping.get(proposalData.approvedBy);
      needsUpdate = true;
    }

    // Migrate executedBy
    if (proposalData.executedBy && uidMapping.has(proposalData.executedBy)) {
      updates.executedBy = uidMapping.get(proposalData.executedBy);
      needsUpdate = true;
    }

    if (!needsUpdate) continue;

    if (DRY_RUN) {
      console.log(
        `   [DRY RUN] Would update proposal ${proposalDoc.id}: ${JSON.stringify(updates)}`
      );
      stats.proposalsUpdated++;
      continue;
    }

    try {
      await proposalDoc.ref.update(updates);
      console.log(`   ✅ Updated proposal ${proposalDoc.id}`);
      stats.proposalsUpdated++;
    } catch (error) {
      const msg = `Failed to update proposal ${proposalDoc.id}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Migrate votes - update userId, delegatedFrom, delegatedTo
 */
async function migrateVotes(uidMapping: Map<string, string>) {
  console.log('\n🗳️  Migrating votes collection...');

  const votesSnapshot = await db.collection('votes').get();

  for (const voteDoc of votesSnapshot.docs) {
    const voteData = voteDoc.data();
    const updates: Record<string, unknown> = {};
    let needsUpdate = false;

    // Migrate userId
    if (voteData.userId && uidMapping.has(voteData.userId)) {
      updates.userId = uidMapping.get(voteData.userId);
      needsUpdate = true;
    }

    // Migrate delegatedFrom
    if (voteData.delegatedFrom && uidMapping.has(voteData.delegatedFrom)) {
      updates.delegatedFrom = uidMapping.get(voteData.delegatedFrom);
      needsUpdate = true;
    }

    // Migrate delegatedTo
    if (voteData.delegatedTo && uidMapping.has(voteData.delegatedTo)) {
      updates.delegatedTo = uidMapping.get(voteData.delegatedTo);
      needsUpdate = true;
    }

    if (!needsUpdate) continue;

    if (DRY_RUN) {
      console.log(
        `   [DRY RUN] Would update vote ${voteDoc.id}: ${JSON.stringify(updates)}`
      );
      stats.votesUpdated++;
      continue;
    }

    try {
      await voteDoc.ref.update(updates);
      console.log(`   ✅ Updated vote ${voteDoc.id}`);
      stats.votesUpdated++;
    } catch (error) {
      const msg = `Failed to update vote ${voteDoc.id}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Migrate comments - update authorId
 */
async function migrateComments(uidMapping: Map<string, string>) {
  console.log('\n💬 Migrating comments collection...');

  const commentsSnapshot = await db.collection('comments').get();

  for (const commentDoc of commentsSnapshot.docs) {
    const commentData = commentDoc.data();

    if (!commentData.authorId || !uidMapping.has(commentData.authorId)) {
      continue;
    }

    if (DRY_RUN) {
      console.log(`   [DRY RUN] Would update comment ${commentDoc.id}`);
      stats.commentsUpdated++;
      continue;
    }

    try {
      await commentDoc.ref.update({
        authorId: uidMapping.get(commentData.authorId),
      });
      console.log(`   ✅ Updated comment ${commentDoc.id}`);
      stats.commentsUpdated++;
    } catch (error) {
      const msg = `Failed to update comment ${commentDoc.id}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Migrate user activities - update userId
 */
async function migrateActivities(uidMapping: Map<string, string>) {
  console.log('\n📊 Migrating user-activities collection...');

  const activitiesSnapshot = await db.collection('user-activities').get();

  for (const activityDoc of activitiesSnapshot.docs) {
    const activityData = activityDoc.data();
    const updates: Record<string, unknown> = {};
    let needsUpdate = false;

    if (activityData.userId && uidMapping.has(activityData.userId)) {
      updates.userId = uidMapping.get(activityData.userId);
      needsUpdate = true;
    }

    if (
      activityData.targetUserId &&
      uidMapping.has(activityData.targetUserId)
    ) {
      updates.targetUserId = uidMapping.get(activityData.targetUserId);
      needsUpdate = true;
    }

    if (!needsUpdate) continue;

    if (DRY_RUN) {
      console.log(`   [DRY RUN] Would update activity ${activityDoc.id}`);
      stats.activitiesUpdated++;
      continue;
    }

    try {
      await activityDoc.ref.update(updates);
      console.log(`   ✅ Updated activity ${activityDoc.id}`);
      stats.activitiesUpdated++;
    } catch (error) {
      const msg = `Failed to update activity ${activityDoc.id}: ${error}`;
      console.error(`   ❌ ${msg}`);
      stats.errors.push(msg);
    }
  }
}

/**
 * Main migration function
 */
async function main() {
  console.log('🚀 EnDAO User ID Migration');
  console.log('='.repeat(50));
  console.log(
    `Mode: ${DRY_RUN ? '🔍 DRY RUN (no changes)' : '⚡ LIVE MIGRATION'}`
  );
  console.log('='.repeat(50));

  // Step 1: Build the UID -> Privy ID mapping
  const uidMapping = await buildUidMapping();

  if (uidMapping.size === 0) {
    console.log('\n✅ No users need migration! All already using Privy IDs.');
    process.exit(0);
  }

  // Step 2: Export backup
  await exportBackup(uidMapping);

  // Step 3: Migrate all collections
  await migrateUsers(uidMapping);
  await migrateDAOs(uidMapping);
  await migrateMembers(uidMapping);
  await migrateProposals(uidMapping);
  await migrateVotes(uidMapping);
  await migrateComments(uidMapping);
  await migrateActivities(uidMapping);

  // Print summary
  console.log('\n' + '='.repeat(50));
  console.log('📊 Migration Summary');
  console.log('='.repeat(50));
  console.log(`Mode: ${DRY_RUN ? 'DRY RUN' : 'LIVE'}`);
  console.log(`Users migrated: ${stats.usersUpdated}`);
  console.log(`DAOs updated: ${stats.daosUpdated}`);
  console.log(`Members updated: ${stats.membersUpdated}`);
  console.log(`Proposals updated: ${stats.proposalsUpdated}`);
  console.log(`Votes updated: ${stats.votesUpdated}`);
  console.log(`Comments updated: ${stats.commentsUpdated}`);
  console.log(`Activities updated: ${stats.activitiesUpdated}`);

  if (stats.errors.length > 0) {
    console.log(`\n❌ Errors: ${stats.errors.length}`);
    stats.errors.forEach((e) => console.log(`   - ${e}`));
  } else {
    console.log(`\n✅ No errors!`);
  }

  if (DRY_RUN) {
    console.log(
      '\n💡 This was a dry run. Run without --dry-run to apply changes.'
    );
  }
}

main()
  .catch(console.error)
  .finally(() => process.exit(0));
