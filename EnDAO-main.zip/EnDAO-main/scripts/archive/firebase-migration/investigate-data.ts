/**
 * Data Investigation Script
 *
 * Investigates orphaned/test data to understand what should be migrated vs discarded.
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { config } from 'dotenv';

config({ path: '.env.local' });

if (getApps().length === 0) {
  const projectId = process.env.FIREBASE_ADMIN_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_ADMIN_CLIENT_EMAIL;
  const privateKeyRaw = process.env.FIREBASE_ADMIN_PRIVATE_KEY;

  if (!projectId || !clientEmail || !privateKeyRaw) {
    console.error('Missing Firebase Admin credentials');
    process.exit(1);
  }

  let privateKey = privateKeyRaw;
  if (privateKey.startsWith('"') && privateKey.endsWith('"')) {
    privateKey = privateKey.slice(1, -1);
  }
  privateKey = privateKey.replace(/\\n/g, '\n');

  initializeApp({
    credential: cert({ projectId, clientEmail, privateKey }),
  });
}

const db = getFirestore();

// Known real DAO IDs
const REAL_DAO_IDS = [
  '0hgqwriHfFJMENyD2jQh', // VMF Collective
  'I0xtBCjuiAeaiHbGQNu5', // CST
];

async function investigateVotes() {
  console.log('\n=== VOTES INVESTIGATION ===\n');

  const votesSnap = await db.collection('votes').get();
  console.log(`Total votes: ${votesSnap.size}`);

  // Group by daoId
  const votesByDao = new Map<string, number>();
  const votesByProposal = new Map<string, number>();
  const orphanedVotes: string[] = [];

  for (const doc of votesSnap.docs) {
    const data = doc.data();
    const daoId = data.daoId || 'NO_DAO_ID';
    const proposalId = data.proposalId || 'NO_PROPOSAL_ID';

    votesByDao.set(daoId, (votesByDao.get(daoId) || 0) + 1);
    votesByProposal.set(proposalId, (votesByProposal.get(proposalId) || 0) + 1);

    if (!REAL_DAO_IDS.includes(daoId)) {
      orphanedVotes.push(doc.id);
    }
  }

  console.log('\nVotes by DAO:');
  for (const [daoId, count] of votesByDao.entries()) {
    const isReal = REAL_DAO_IDS.includes(daoId);
    const marker = isReal ? '✅ REAL' : '❌ ORPHAN/TEST';
    console.log(`  ${marker}: ${daoId} → ${count} votes`);
  }

  console.log('\nVotes by Proposal (top 10):');
  const sortedProposals = [...votesByProposal.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);
  for (const [proposalId, count] of sortedProposals) {
    console.log(`  ${proposalId}: ${count} votes`);
  }

  console.log(`\nOrphaned votes (not in real DAOs): ${orphanedVotes.length}`);

  return {
    total: votesSnap.size,
    orphaned: orphanedVotes.length,
    real: votesSnap.size - orphanedVotes.length,
  };
}

async function investigateAuditLogs() {
  console.log('\n=== AUDIT_LOGS INVESTIGATION ===\n');

  const auditSnap = await db.collection('audit_logs').limit(20).get();
  console.log(`Sample of audit_logs (first 20 of 1633):`);

  const actionTypes = new Map<string, number>();

  for (const doc of auditSnap.docs) {
    const data = doc.data();
    const action = data.action || data.type || data.eventType || 'UNKNOWN';
    actionTypes.set(action, (actionTypes.get(action) || 0) + 1);

    console.log(`\n  ID: ${doc.id.substring(0, 20)}...`);
    console.log(`  Action: ${action}`);
    console.log(
      `  Timestamp: ${data.timestamp?.toDate?.() || data.createdAt?.toDate?.() || 'unknown'}`
    );
    if (data.daoId) console.log(`  DAO ID: ${data.daoId}`);
    if (data.userId)
      console.log(`  User ID: ${data.userId?.substring(0, 30)}...`);
  }

  // Get full action type distribution
  const fullAuditSnap = await db.collection('audit_logs').get();
  const fullActionTypes = new Map<string, number>();

  for (const doc of fullAuditSnap.docs) {
    const data = doc.data();
    const action = data.action || data.type || data.eventType || 'UNKNOWN';
    fullActionTypes.set(action, (fullActionTypes.get(action) || 0) + 1);
  }

  console.log('\n\nAction type distribution (all 1633 logs):');
  for (const [action, count] of [...fullActionTypes.entries()].sort(
    (a, b) => b[1] - a[1]
  )) {
    console.log(`  ${action}: ${count}`);
  }
}

async function investigateDaoActivities() {
  console.log('\n=== DAO-ACTIVITIES INVESTIGATION ===\n');

  const activitiesSnap = await db.collection('dao-activities').get();
  console.log(`Total activities: ${activitiesSnap.size}`);

  const activitiesByDao = new Map<string, number>();
  const activityTypes = new Map<string, number>();

  for (const doc of activitiesSnap.docs) {
    const data = doc.data();
    const daoId = data.daoId || 'NO_DAO_ID';
    const type = data.type || data.activityType || 'UNKNOWN';

    activitiesByDao.set(daoId, (activitiesByDao.get(daoId) || 0) + 1);
    activityTypes.set(type, (activityTypes.get(type) || 0) + 1);
  }

  console.log('\nActivities by DAO:');
  for (const [daoId, count] of activitiesByDao.entries()) {
    const isReal = REAL_DAO_IDS.includes(daoId);
    const marker = isReal ? '✅ REAL' : '❌ ORPHAN/TEST';
    console.log(`  ${marker}: ${daoId} → ${count} activities`);
  }

  console.log('\nActivity types:');
  for (const [type, count] of [...activityTypes.entries()].sort(
    (a, b) => b[1] - a[1]
  )) {
    console.log(`  ${type}: ${count}`);
  }
}

async function investigateDaoAdminAuditLogs() {
  console.log('\n=== DAO-ADMIN-AUDIT-LOGS INVESTIGATION ===\n');

  const auditSnap = await db.collection('dao-admin-audit-logs').get();
  console.log(`Total admin audit logs: ${auditSnap.size}`);

  const logsByDao = new Map<string, number>();
  const actionTypes = new Map<string, number>();

  for (const doc of auditSnap.docs) {
    const data = doc.data();
    const daoId = data.daoId || 'NO_DAO_ID';
    const action = data.action || 'UNKNOWN';

    logsByDao.set(daoId, (logsByDao.get(daoId) || 0) + 1);
    actionTypes.set(action, (actionTypes.get(action) || 0) + 1);
  }

  console.log('\nAdmin audit logs by DAO:');
  for (const [daoId, count] of logsByDao.entries()) {
    const isReal = REAL_DAO_IDS.includes(daoId);
    const marker = isReal ? '✅ REAL' : '❌ ORPHAN/TEST';
    console.log(`  ${marker}: ${daoId} → ${count} logs`);
  }

  console.log('\nAction types:');
  for (const [action, count] of [...actionTypes.entries()].sort(
    (a, b) => b[1] - a[1]
  )) {
    console.log(`  ${action}: ${count}`);
  }
}

async function main() {
  console.log('='.repeat(80));
  console.log('DATA INVESTIGATION - Understanding what to migrate vs discard');
  console.log('='.repeat(80));

  const voteResults = await investigateVotes();
  await investigateAuditLogs();
  await investigateDaoActivities();
  await investigateDaoAdminAuditLogs();

  console.log('\n' + '='.repeat(80));
  console.log('SUMMARY');
  console.log('='.repeat(80));
  console.log(`
VOTES:
  - Real votes (in CST or VMF): ${voteResults.real}
  - Orphaned/test votes: ${voteResults.orphaned}
  - Recommendation: Only migrate ${voteResults.real} real votes

AUDIT COLLECTIONS:
  - audit_logs (1633): General system logs - likely test/dev logs, probably DON'T need
  - dao-admin-audit-logs (19): Admin actions on DAOs - check if related to real DAOs
  - dao-activities (134): DAO activity feed - check if related to real DAOs

RECOMMENDATION:
  - Migrate: votes, activities, admin-audit-logs ONLY for real DAOs
  - Discard: audit_logs (system logs), orphaned data
  `);
}

main().catch(console.error);
