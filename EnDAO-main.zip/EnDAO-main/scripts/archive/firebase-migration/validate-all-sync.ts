/**
 * Comprehensive Data Sync Validation Script
 *
 * Validates data consistency across all DAOs in Firestore.
 * This is a READ-ONLY diagnostic script that checks for sync issues.
 *
 * Usage:
 *   npx tsx scripts/validate-all-sync.ts              # Check all DAOs
 *   npx tsx scripts/validate-all-sync.ts --dao <id>   # Check single DAO
 *   npx tsx scripts/validate-all-sync.ts --verbose    # Detailed output
 *
 * Exit codes:
 *   0 = No issues found
 *   1 = Issues found or error occurred
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { readFileSync } from 'fs';
import { join } from 'path';

// Initialize Firebase Admin using serviceAccountKey.json
if (getApps().length === 0) {
  const serviceAccountPath = join(process.cwd(), 'serviceAccountKey.json');

  try {
    const serviceAccount = JSON.parse(
      readFileSync(serviceAccountPath, 'utf-8')
    );
    initializeApp({
      credential: cert(serviceAccount),
    });
  } catch (error) {
    console.error(
      'Failed to load serviceAccountKey.json from:',
      serviceAccountPath
    );
    console.error(error);
    process.exit(1);
  }
}

const db = getFirestore();

interface ValidationIssue {
  type:
    | 'member_count'
    | 'admin_sync'
    | 'proposal_count'
    | 'vote_count'
    | 'active_proposals';
  expected: number | string[];
  actual: number | string[];
  drift?: number;
  message: string;
}

interface DAOValidationResult {
  daoId: string;
  daoName: string;
  issues: ValidationIssue[];
}

interface ValidationSummary {
  totalDaosChecked: number;
  daosWithIssues: number;
  totalIssues: number;
  results: DAOValidationResult[];
}

/**
 * Get actual member count from dao-members collection
 */
async function getActualMemberCount(daoId: string): Promise<number> {
  const membersRef = db.collection('dao-members');
  const snapshot = await membersRef
    .where('daoId', '==', daoId)
    .where('status', '==', 'active')
    .get();

  return snapshot.size;
}

/**
 * Get admin user IDs from dao-members collection
 */
async function getActualAdmins(daoId: string): Promise<string[]> {
  const membersRef = db.collection('dao-members');
  const snapshot = await membersRef
    .where('daoId', '==', daoId)
    .where('role', '==', 'admin')
    .where('status', '==', 'active')
    .get();

  return snapshot.docs.map((doc) => doc.data().userId);
}

/**
 * Get actual proposal count
 */
async function getActualProposalCount(daoId: string): Promise<number> {
  const proposalsRef = db.collection('proposals');
  const snapshot = await proposalsRef.where('daoId', '==', daoId).get();

  return snapshot.size;
}

/**
 * Get actual active proposal count
 */
async function getActualActiveProposalCount(daoId: string): Promise<number> {
  const proposalsRef = db.collection('proposals');
  const snapshot = await proposalsRef
    .where('daoId', '==', daoId)
    .where('status', '==', 'active')
    .get();

  return snapshot.size;
}

/**
 * Get total vote count across all proposals for a DAO
 */
async function getActualTotalVotes(daoId: string): Promise<number> {
  const votesRef = db.collection('votes');
  const snapshot = await votesRef.where('daoId', '==', daoId).get();

  return snapshot.size;
}

/**
 * Get votes for a specific proposal
 */
async function getActualProposalVotes(proposalId: string): Promise<number> {
  const votesRef = db.collection('votes');
  const snapshot = await votesRef.where('proposalId', '==', proposalId).get();

  return snapshot.size;
}

/**
 * Validate a single DAO
 */
async function validateDAO(
  daoId: string,
  verbose: boolean
): Promise<DAOValidationResult> {
  const daoDoc = await db.collection('daos').doc(daoId).get();

  if (!daoDoc.exists) {
    return {
      daoId,
      daoName: 'UNKNOWN',
      issues: [
        {
          type: 'member_count',
          expected: 0,
          actual: 0,
          message: 'DAO document not found',
        },
      ],
    };
  }

  const daoData = daoDoc.data()!;
  const daoName = daoData.name || 'Unnamed DAO';
  const issues: ValidationIssue[] = [];

  if (verbose) {
    console.log(`\nValidating: ${daoName} (${daoId})`);
  }

  // Check 1: Member count sync
  const actualMemberCount = await getActualMemberCount(daoId);
  const storedMemberCount = daoData.stats?.memberCount || 0;
  const memberIdsLength = (daoData.memberIds || []).length;

  if (actualMemberCount !== storedMemberCount) {
    issues.push({
      type: 'member_count',
      expected: actualMemberCount,
      actual: storedMemberCount,
      drift: actualMemberCount - storedMemberCount,
      message: `stats.memberCount mismatch: expected ${actualMemberCount}, got ${storedMemberCount}`,
    });
  }

  if (actualMemberCount !== memberIdsLength) {
    issues.push({
      type: 'member_count',
      expected: actualMemberCount,
      actual: memberIdsLength,
      drift: actualMemberCount - memberIdsLength,
      message: `memberIds.length mismatch: expected ${actualMemberCount}, got ${memberIdsLength}`,
    });
  }

  // Check 2: Admin sync
  const actualAdmins = await getActualAdmins(daoId);
  const storedAdmins = daoData.admins || [];

  // Sort arrays for comparison
  const actualAdminsSorted = [...actualAdmins].sort();
  const storedAdminsSorted = [...storedAdmins].sort();

  if (
    JSON.stringify(actualAdminsSorted) !== JSON.stringify(storedAdminsSorted)
  ) {
    issues.push({
      type: 'admin_sync',
      expected: actualAdminsSorted,
      actual: storedAdminsSorted,
      message: `admins[] mismatch: expected [${actualAdminsSorted.join(', ')}], got [${storedAdminsSorted.join(', ')}]`,
    });
  }

  // Check 3: Total proposal count
  const actualProposalCount = await getActualProposalCount(daoId);
  const storedProposalCount = daoData.stats?.totalProposals || 0;

  if (actualProposalCount !== storedProposalCount) {
    issues.push({
      type: 'proposal_count',
      expected: actualProposalCount,
      actual: storedProposalCount,
      drift: actualProposalCount - storedProposalCount,
      message: `stats.totalProposals mismatch: expected ${actualProposalCount}, got ${storedProposalCount}`,
    });
  }

  // Check 4: Active proposal count
  const actualActiveProposals = await getActualActiveProposalCount(daoId);
  const storedActiveProposals = daoData.stats?.activeProposals || 0;

  if (actualActiveProposals !== storedActiveProposals) {
    issues.push({
      type: 'active_proposals',
      expected: actualActiveProposals,
      actual: storedActiveProposals,
      drift: actualActiveProposals - storedActiveProposals,
      message: `stats.activeProposals mismatch: expected ${actualActiveProposals}, got ${storedActiveProposals}`,
    });
  }

  // Check 5: Total vote count
  const actualTotalVotes = await getActualTotalVotes(daoId);
  const storedTotalVotes = daoData.stats?.totalVotes || 0;

  if (actualTotalVotes !== storedTotalVotes) {
    issues.push({
      type: 'vote_count',
      expected: actualTotalVotes,
      actual: storedTotalVotes,
      drift: actualTotalVotes - storedTotalVotes,
      message: `stats.totalVotes mismatch: expected ${actualTotalVotes}, got ${storedTotalVotes}`,
    });
  }

  // Check 6: Individual proposal vote counts (sample check for verbose mode)
  if (verbose && actualProposalCount > 0) {
    const proposalsSnapshot = await db
      .collection('proposals')
      .where('daoId', '==', daoId)
      .limit(5) // Sample first 5 proposals
      .get();

    for (const proposalDoc of proposalsSnapshot.docs) {
      const proposalData = proposalDoc.data();
      const proposalId = proposalDoc.id;
      const actualVotes = await getActualProposalVotes(proposalId);
      const storedVotes = proposalData.results?.totalVotes || 0;

      if (actualVotes !== storedVotes) {
        issues.push({
          type: 'vote_count',
          expected: actualVotes,
          actual: storedVotes,
          drift: actualVotes - storedVotes,
          message: `Proposal "${proposalData.title}" (${proposalId.substring(0, 8)}...) vote mismatch: expected ${actualVotes}, got ${storedVotes}`,
        });
      }
    }
  }

  if (verbose) {
    if (issues.length === 0) {
      console.log('  ✓ No issues found');
    } else {
      console.log(`  ✗ Found ${issues.length} issue(s)`);
    }
  }

  return {
    daoId,
    daoName,
    issues,
  };
}

/**
 * Print validation results
 */
function printResults(summary: ValidationSummary, verbose: boolean): void {
  console.log('\n' + '='.repeat(80));
  console.log('VALIDATION RESULTS');
  console.log('='.repeat(80));

  for (const result of summary.results) {
    if (result.issues.length === 0) {
      if (verbose) {
        console.log(`\n=== DAO: ${result.daoName} (${result.daoId}) ===`);
        console.log('✓ All checks passed');
      }
      continue;
    }

    console.log(`\n=== DAO: ${result.daoName} (${result.daoId}) ===`);

    for (const issue of result.issues) {
      const symbol = '✗';
      console.log(`${symbol} ${issue.message}`);
    }
  }

  console.log('\n' + '='.repeat(80));
  console.log('SUMMARY');
  console.log('='.repeat(80));
  console.log(`DAOs checked: ${summary.totalDaosChecked}`);
  console.log(`DAOs with issues: ${summary.daosWithIssues}`);
  console.log(`Total issues found: ${summary.totalIssues}`);

  if (summary.totalIssues > 0) {
    console.log('\n⚠️  Issues detected. Review output above for details.');
  } else {
    console.log('\n✓ All DAOs passed validation!');
  }
}

/**
 * Main execution
 */
async function main(): Promise<void> {
  const args = process.argv.slice(2);

  // Parse arguments
  let targetDaoId: string | null = null;
  let verbose = false;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--dao' && i + 1 < args.length) {
      targetDaoId = args[i + 1];
      i++;
    } else if (args[i] === '--verbose') {
      verbose = true;
    } else if (args[i] === '--help' || args[i] === '-h') {
      console.log('Usage: npx tsx scripts/validate-all-sync.ts [OPTIONS]');
      console.log('\nOptions:');
      console.log('  --dao <id>      Validate a specific DAO by ID');
      console.log('  --verbose       Show detailed output for all DAOs');
      console.log('  --help, -h      Show this help message');
      console.log('\nExamples:');
      console.log('  npx tsx scripts/validate-all-sync.ts');
      console.log('  npx tsx scripts/validate-all-sync.ts --dao abc123');
      console.log('  npx tsx scripts/validate-all-sync.ts --verbose');
      process.exit(0);
    }
  }

  console.log('Starting data sync validation...');
  if (targetDaoId) {
    console.log(`Target: Single DAO (${targetDaoId})`);
  } else {
    console.log('Target: All DAOs');
  }

  const results: DAOValidationResult[] = [];

  try {
    if (targetDaoId) {
      // Validate single DAO
      const result = await validateDAO(targetDaoId, verbose);
      results.push(result);
    } else {
      // Validate all DAOs
      const daosSnapshot = await db.collection('daos').get();
      console.log(`Found ${daosSnapshot.size} DAOs to validate\n`);

      for (const daoDoc of daosSnapshot.docs) {
        const result = await validateDAO(daoDoc.id, verbose);
        results.push(result);
      }
    }

    // Calculate summary
    const summary: ValidationSummary = {
      totalDaosChecked: results.length,
      daosWithIssues: results.filter((r) => r.issues.length > 0).length,
      totalIssues: results.reduce((sum, r) => sum + r.issues.length, 0),
      results,
    };

    // Print results
    printResults(summary, verbose);

    // Exit with appropriate code
    process.exit(summary.totalIssues > 0 ? 1 : 0);
  } catch (error) {
    console.error('\n❌ Error during validation:', error);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
