/**
 * Vote Count Repair Script
 * Recalculates vote counts from the source-of-truth votes collection
 *
 * Purpose: Repair DAO.stats.totalVotes and proposal.results vote counts
 * by recalculating from the actual votes collection.
 *
 * Usage:
 *   npx tsx scripts/repair-vote-counts.ts --dao abc123
 *   npx tsx scripts/repair-vote-counts.ts --all
 *   npx tsx scripts/repair-vote-counts.ts --dao abc123 --dry-run
 *
 * Prerequisites:
 * 1. Firebase CLI authenticated: firebase login --reauth
 * 2. Or GOOGLE_APPLICATION_CREDENTIALS set to serviceAccountKey.json path
 */

/* eslint-disable no-console */
/* eslint-disable max-statements */
/* eslint-disable complexity */

import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { readFileSync } from 'fs';
import { join } from 'path';

// Initialize Firebase Admin
if (getApps().length === 0) {
  const serviceAccountPath = join(process.cwd(), 'serviceAccountKey.json');

  try {
    const serviceAccount = JSON.parse(
      readFileSync(serviceAccountPath, 'utf-8')
    );
    initializeApp({
      credential: cert(serviceAccount),
    });
    console.log('✅ Firebase Admin initialized');
  } catch (error) {
    console.error(
      '❌ Failed to load serviceAccountKey.json from:',
      serviceAccountPath
    );
    console.error(
      'Please ensure the file exists and contains valid credentials'
    );
    console.error(error);
    process.exit(1);
  }
}

const db = getFirestore();

interface VoteCounts {
  total: number;
  for: number;
  against: number;
  abstain: number;
}

interface ProposalMismatch {
  proposalId: string;
  proposalTitle: string;
  current: VoteCounts;
  actual: VoteCounts;
  needsUpdate: boolean;
}

interface DAORepairReport {
  daoId: string;
  daoName: string;
  proposals: ProposalMismatch[];
  daoTotalVotes: {
    current: number;
    actual: number;
    needsUpdate: boolean;
  };
  changesApplied: number;
}

/**
 * Get all non-deleted votes for a proposal
 */
async function getVotesForProposal(proposalId: string): Promise<VoteCounts> {
  const votesSnapshot = await db
    .collection('votes')
    .where('proposalId', '==', proposalId)
    .get();

  const counts: VoteCounts = {
    total: 0,
    for: 0,
    against: 0,
    abstain: 0,
  };

  votesSnapshot.docs.forEach((doc) => {
    const vote = doc.data();

    // Skip deleted votes (isDeleted field)
    if (vote.isDeleted === true) return;

    counts.total++;

    switch (vote.option) {
      case 'for':
        counts.for++;
        break;
      case 'against':
        counts.against++;
        break;
      case 'abstain':
        counts.abstain++;
        break;
      default:
        // Handle custom options if needed
        break;
    }
  });

  return counts;
}

/**
 * Get all non-deleted votes for a DAO
 */
async function getVotesForDAO(daoId: string): Promise<number> {
  const votesSnapshot = await db
    .collection('votes')
    .where('daoId', '==', daoId)
    .get();

  let totalVotes = 0;

  votesSnapshot.docs.forEach((doc) => {
    const vote = doc.data();
    // Skip deleted votes
    if (vote.isDeleted === true) return;
    totalVotes++;
  });

  return totalVotes;
}

/**
 * Repair vote counts for a single DAO
 */
async function repairDAO(
  daoId: string,
  dryRun: boolean
): Promise<DAORepairReport> {
  // Get DAO document
  const daoDoc = await db.collection('daos').doc(daoId).get();

  if (!daoDoc.exists) {
    throw new Error(`DAO not found: ${daoId}`);
  }

  const daoData = daoDoc.data()!;
  const daoName = daoData.name || 'Unknown DAO';

  console.log(`\n${'='.repeat(70)}`);
  console.log(`Repairing Vote Counts for: ${daoName} (${daoId})`);
  console.log('='.repeat(70));

  const report: DAORepairReport = {
    daoId,
    daoName,
    proposals: [],
    daoTotalVotes: {
      current: daoData.stats?.totalVotes || 0,
      actual: 0,
      needsUpdate: false,
    },
    changesApplied: 0,
  };

  // Get all proposals for this DAO
  const proposalsSnapshot = await db
    .collection('proposals')
    .where('daoId', '==', daoId)
    .get();

  console.log(`\nFound ${proposalsSnapshot.size} proposals\n`);

  // Check each proposal
  for (const proposalDoc of proposalsSnapshot.docs) {
    const proposalData = proposalDoc.data();
    const proposalId = proposalDoc.id;
    const proposalTitle = proposalData.title || 'Untitled';

    const currentCounts: VoteCounts = {
      total: proposalData.results?.totalVotes || 0,
      for: proposalData.results?.forVotes || 0,
      against: proposalData.results?.againstVotes || 0,
      abstain: proposalData.results?.abstainVotes || 0,
    };

    const actualCounts = await getVotesForProposal(proposalId);

    const needsUpdate =
      currentCounts.total !== actualCounts.total ||
      currentCounts.for !== actualCounts.for ||
      currentCounts.against !== actualCounts.against ||
      currentCounts.abstain !== actualCounts.abstain;

    const mismatch: ProposalMismatch = {
      proposalId,
      proposalTitle,
      current: currentCounts,
      actual: actualCounts,
      needsUpdate,
    };

    report.proposals.push(mismatch);

    // Display proposal status
    console.log(`Proposal: "${proposalTitle}" (${proposalId})`);
    console.log(
      `  Current: for=${currentCounts.for}, against=${currentCounts.against}, abstain=${currentCounts.abstain}, total=${currentCounts.total}`
    );
    console.log(
      `  Actual:  for=${actualCounts.for}, against=${actualCounts.against}, abstain=${actualCounts.abstain}, total=${actualCounts.total}`
    );

    if (needsUpdate) {
      const diff = currentCounts.total - actualCounts.total;
      const inflated =
        diff > 0
          ? `(was inflated by ${diff})`
          : `(was deflated by ${Math.abs(diff)})`;
      console.log(`  ✗ Mismatch detected ${inflated}`);

      // Apply fix if not dry run
      if (!dryRun) {
        await proposalDoc.ref.update({
          'results.totalVotes': actualCounts.total,
          'results.forVotes': actualCounts.for,
          'results.againstVotes': actualCounts.against,
          'results.abstainVotes': actualCounts.abstain,
          updatedAt: FieldValue.serverTimestamp(),
        });
        report.changesApplied++;
        console.log(`  ✅ Updated proposal vote counts`);
      }
    } else {
      console.log(`  ✓ No changes needed`);
    }
    console.log();
  }

  // Calculate DAO total votes from actual votes collection
  const actualDAOTotalVotes = await getVotesForDAO(daoId);
  report.daoTotalVotes.actual = actualDAOTotalVotes;
  report.daoTotalVotes.needsUpdate =
    report.daoTotalVotes.current !== actualDAOTotalVotes;

  console.log(`DAO Total Votes:`);
  console.log(`  Current: stats.totalVotes = ${report.daoTotalVotes.current}`);
  console.log(`  Actual:  ${actualDAOTotalVotes} votes`);

  if (report.daoTotalVotes.needsUpdate) {
    const diff = report.daoTotalVotes.current - actualDAOTotalVotes;
    const inflated =
      diff > 0
        ? `(was inflated by ${diff})`
        : `(was deflated by ${Math.abs(diff)})`;
    console.log(
      `  ✗ Mismatch: ${report.daoTotalVotes.current} → ${actualDAOTotalVotes} ${inflated}`
    );

    // Apply fix if not dry run
    if (!dryRun) {
      await daoDoc.ref.update({
        'stats.totalVotes': actualDAOTotalVotes,
        updatedAt: FieldValue.serverTimestamp(),
      });
      report.changesApplied++;
      console.log(`  ✅ Updated DAO total votes`);
    }
  } else {
    console.log(`  ✓ No changes needed`);
  }

  return report;
}

/**
 * Repair vote counts for all DAOs
 */
async function repairAllDAOs(dryRun: boolean): Promise<void> {
  const daosSnapshot = await db.collection('daos').get();

  console.log(`\nFound ${daosSnapshot.size} DAOs\n`);

  const allReports: DAORepairReport[] = [];

  for (const daoDoc of daosSnapshot.docs) {
    try {
      const report = await repairDAO(daoDoc.id, dryRun);
      allReports.push(report);
    } catch (error) {
      console.error(`❌ Error repairing DAO ${daoDoc.id}:`, error);
    }
  }

  // Print summary
  console.log(`\n${'='.repeat(70)}`);
  console.log('SUMMARY');
  console.log('='.repeat(70));

  const totalDAOsWithIssues = allReports.filter(
    (r) => r.daoTotalVotes.needsUpdate || r.proposals.some((p) => p.needsUpdate)
  ).length;

  const totalProposalsWithIssues = allReports.reduce(
    (sum, r) => sum + r.proposals.filter((p) => p.needsUpdate).length,
    0
  );

  const totalChanges = allReports.reduce((sum, r) => sum + r.changesApplied, 0);

  console.log(
    `DAOs with issues: ${totalDAOsWithIssues} / ${allReports.length}`
  );
  console.log(`Proposals with mismatched counts: ${totalProposalsWithIssues}`);

  if (dryRun) {
    console.log(`\nDRY RUN MODE - No changes were applied`);
    console.log(`Run without --dry-run to apply fixes`);
  } else {
    console.log(`\nChanges applied: ${totalChanges}`);
  }

  console.log('='.repeat(70));
}

/**
 * Print summary for a single DAO repair
 */
function printDAOSummary(report: DAORepairReport, dryRun: boolean): void {
  console.log(`\n${'='.repeat(70)}`);
  console.log('SUMMARY');
  console.log('='.repeat(70));

  const proposalsWithIssues = report.proposals.filter(
    (p) => p.needsUpdate
  ).length;

  console.log(`Proposals checked: ${report.proposals.length}`);
  console.log(`Proposals with mismatched counts: ${proposalsWithIssues}`);
  console.log(
    `DAO total votes ${report.daoTotalVotes.needsUpdate ? 'needs update' : 'correct'}`
  );

  if (dryRun) {
    console.log(`\nDRY RUN MODE - No changes were applied`);
    console.log(`Run without --dry-run to apply fixes`);
  } else {
    console.log(`\nChanges applied: ${report.changesApplied}`);

    if (report.changesApplied > 0) {
      const updatedProposals = report.proposals.filter(
        (p) => p.needsUpdate
      ).length;
      if (updatedProposals > 0) {
        console.log(`  - Updated ${updatedProposals} proposal(s)`);
      }
      if (report.daoTotalVotes.needsUpdate) {
        console.log(
          `  - Updated DAO total votes: ${report.daoTotalVotes.current} → ${report.daoTotalVotes.actual}`
        );
      }
    }
  }

  console.log('='.repeat(70));
}

async function main() {
  const args = process.argv.slice(2);
  const daoIdArg = args.find((arg) => arg.startsWith('--dao='))?.split('=')[1];
  const daoIdFlag = args.includes('--dao')
    ? args[args.indexOf('--dao') + 1]
    : undefined;
  const daoId = daoIdArg || daoIdFlag;
  const allDAOs = args.includes('--all');
  const dryRun = args.includes('--dry-run');

  console.log('\n🔧 EnDAO Vote Count Repair Tool\n');

  if (dryRun) {
    console.log('⚠️  DRY RUN MODE - No changes will be applied\n');
  }

  if (!daoId && !allDAOs) {
    console.error('❌ Error: Must specify --dao <daoId> or --all');
    console.log('\nUsage:');
    console.log('  npx tsx scripts/repair-vote-counts.ts --dao abc123');
    console.log('  npx tsx scripts/repair-vote-counts.ts --all');
    console.log(
      '  npx tsx scripts/repair-vote-counts.ts --dao abc123 --dry-run'
    );
    process.exit(1);
  }

  try {
    if (allDAOs) {
      await repairAllDAOs(dryRun);
    } else if (daoId) {
      const report = await repairDAO(daoId, dryRun);
      printDAOSummary(report, dryRun);
    }

    console.log('\n✅ Done!');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Script failed:', error);
    process.exit(1);
  }
}

main();
