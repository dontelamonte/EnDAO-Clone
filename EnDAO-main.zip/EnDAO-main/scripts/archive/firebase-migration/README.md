# Firebase Migration Scripts (Archived)

These scripts were used for the one-time Firebase→Supabase migration completed in December 2024.

**DO NOT RUN** - Migration is complete. The database is now fully Supabase-based.

## Purpose

Historical reference only. These scripts document how data was exported from Firebase Firestore and imported into Supabase PostgreSQL.

## Scripts

| Script                    | Purpose                                                |
| ------------------------- | ------------------------------------------------------ |
| `export-firebase-data.ts` | Export all collections from Firebase Firestore to JSON |
| `import-to-supabase.ts`   | Import exported JSON into Supabase with ID mapping     |
| `audit-firebase-data.ts`  | Audit Firebase data quality and structure              |
| `investigate-data.ts`     | Debug investigation of Firebase documents              |
| `validate-all-sync.ts`    | Validate data sync between Firebase and Supabase       |
| `repair-member-sync.ts`   | Fix member data discrepancies during migration         |
| `repair-vote-counts.ts`   | Fix vote count inconsistencies during migration        |
| `migrate-to-privy-id.ts`  | Migrate user IDs from Firebase Auth to Privy           |
| `rejoin-dao-as-admin.ts`  | Re-establish admin roles after migration               |

## Dependencies

These scripts require `firebase-admin` which is no longer installed. If you need to reference the migration logic, read the code without running it.

## Related Documentation

- `docs/archive/2025/firebase-migration/` - Migration planning and execution docs
- `docs/archive/firebase/firebase-export.json` - Exported data snapshot

## Last Updated

December 2024 - Migration complete, scripts archived.
