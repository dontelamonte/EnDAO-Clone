/**
 * Firebase Data Audit Script
 *
 * Audits all data in Firebase/Firestore to identify:
 * - Real data to migrate (users, DAOs, proposals, votes)
 * - Test data to discard
 *
 * Usage:
 *   npx tsx scripts/audit-firebase-data.ts              # Full audit
 *   npx tsx scripts/audit-firebase-data.ts --verbose    # Detailed output
 *   npx tsx scripts/audit-firebase-data.ts --export     # Export audit to JSON
 *
 * Purpose: Pre-migration planning for Firebase → Supabase migration
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { writeFileSync } from 'fs';
import { join } from 'path';
import { config } from 'dotenv';

// Load environment variables from .env.local
config({ path: '.env.local' });

// Initialize Firebase Admin using environment variables (same as production)
if (getApps().length === 0) {
  const projectId = process.env.FIREBASE_ADMIN_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_ADMIN_CLIENT_EMAIL;
  const privateKeyRaw = process.env.FIREBASE_ADMIN_PRIVATE_KEY;

  if (!projectId || !clientEmail || !privateKeyRaw) {
    console.error(
      'Missing Firebase Admin credentials in environment variables.'
    );
    console.error(
      'Required: FIREBASE_ADMIN_PROJECT_ID, FIREBASE_ADMIN_CLIENT_EMAIL, FIREBASE_ADMIN_PRIVATE_KEY'
    );
    console.error('');
    console.error('Make sure these are set in your .env.local file.');
    process.exit(1);
  }

  try {
    // Handle various private key formats (same as src/lib/firebase-admin.ts)
    let privateKey = privateKeyRaw;
    if (privateKey.startsWith('"') && privateKey.endsWith('"')) {
      privateKey = privateKey.slice(1, -1);
    }
    privateKey = privateKey.replace(/\\n/g, '\n');

    initializeApp({
      credential: cert({
        projectId,
        clientEmail,
        privateKey,
      }),
    });
    console.log(`Firebase Admin initialized for project: ${projectId}`);
  } catch (error) {
    console.error('Failed to initialize Firebase Admin:', error);
    process.exit(1);
  }
}

const db = getFirestore();

interface CollectionAudit {
  name: string;
  count: number;
  details?: Record<string, unknown>[];
}

interface DAOAudit {
  id: string;
  name: string;
  status: string;
  memberCount: number;
  actualMembers: number;
  proposalCount: number;
  voteCount: number;
  activityCount: number;
  createdAt: string;
  isReal: boolean;
  reason?: string;
}

interface UserAudit {
  id: string;
  privyId: string;
  email?: string;
  displayName?: string;
  username?: string;
  profileSetupComplete: boolean;
  createdAt: string;
  daoMemberships: number;
}

interface AuditResult {
  timestamp: string;
  collections: CollectionAudit[];
  daos: DAOAudit[];
  users: UserAudit[];
  summary: {
    totalUsers: number;
    usersWithCompleteProfile: number;
    totalDaos: number;
    realDaos: number;
    testDaos: number;
    totalProposals: number;
    totalVotes: number;
    totalMembers: number;
  };
  recommendedMigration: {
    users: string[];
    daos: string[];
    reasoning: string;
  };
}

// Known real DAO name patterns
const REAL_DAO_PATTERNS = [
  'cst',
  'village',
  'micro fund',
  'village micro fund',
  'vmf',
  'vmf collective',
];

function isRealDAO(name: string): { isReal: boolean; reason: string } {
  const lowerName = name.toLowerCase();

  // Check against known patterns
  for (const pattern of REAL_DAO_PATTERNS) {
    if (lowerName.includes(pattern)) {
      return { isReal: true, reason: `Matches known pattern: "${pattern}"` };
    }
  }

  // Likely test DAOs
  const testPatterns = [
    'test',
    'demo',
    'sample',
    'example',
    'foo',
    'bar',
    'asdf',
  ];
  for (const pattern of testPatterns) {
    if (lowerName.includes(pattern)) {
      return { isReal: false, reason: `Contains test indicator: "${pattern}"` };
    }
  }

  // Default to unknown - will be marked for manual review
  return { isReal: false, reason: 'Unknown - requires manual review' };
}

function formatTimestamp(ts: Timestamp | undefined): string {
  if (!ts) return 'unknown';
  try {
    return ts.toDate().toISOString();
  } catch {
    return 'invalid';
  }
}

async function auditCollections(verbose: boolean): Promise<CollectionAudit[]> {
  const collections = [
    'users',
    'daos',
    'dao-members',
    'proposals',
    'votes',
    'dao-activities',
    'notifications',
    'admin_users',
    'usernames',
    'dao-admin-audit-logs',
    'admin-action-proposals',
    'treasury_ledger',
    'treasuryFreezes',
    'dao-invitations',
    'joinRequests',
    'proposal_drafts',
    'user_preferences',
    'errors',
    'audit_logs',
  ];

  const results: CollectionAudit[] = [];

  console.log('\n=== Collection Inventory ===\n');

  for (const collectionName of collections) {
    try {
      const snapshot = await db.collection(collectionName).get();
      const audit: CollectionAudit = {
        name: collectionName,
        count: snapshot.size,
      };

      console.log(`${collectionName}: ${snapshot.size} documents`);

      if (verbose && snapshot.size > 0 && snapshot.size <= 20) {
        // Show sample data for small collections
        audit.details = snapshot.docs.slice(0, 5).map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
      }

      results.push(audit);
    } catch (error) {
      console.log(`${collectionName}: ERROR - ${error}`);
      results.push({ name: collectionName, count: -1 });
    }
  }

  return results;
}

async function auditDAOs(verbose: boolean): Promise<DAOAudit[]> {
  console.log('\n=== DAO Audit ===\n');

  const daosSnapshot = await db.collection('daos').get();
  const results: DAOAudit[] = [];

  for (const daoDoc of daosSnapshot.docs) {
    const data = daoDoc.data();
    const daoId = daoDoc.id;

    // Count associated data
    const [membersSnap, proposalsSnap, votesSnap, activitiesSnap] =
      await Promise.all([
        db.collection('dao-members').where('daoId', '==', daoId).get(),
        db.collection('proposals').where('daoId', '==', daoId).get(),
        db.collection('votes').where('daoId', '==', daoId).get(),
        db.collection('dao-activities').where('daoId', '==', daoId).get(),
      ]);

    const { isReal, reason } = isRealDAO(data.name || '');

    const audit: DAOAudit = {
      id: daoId,
      name: data.name || 'Unnamed',
      status: data.status || 'active',
      memberCount: data.stats?.memberCount || data.memberCount || 0,
      actualMembers: membersSnap.size,
      proposalCount: proposalsSnap.size,
      voteCount: votesSnap.size,
      activityCount: activitiesSnap.size,
      createdAt: formatTimestamp(data.createdAt),
      isReal,
      reason,
    };

    results.push(audit);

    const realIndicator = isReal ? '✅ REAL' : '❌ TEST';
    console.log(`\n${realIndicator} - ${audit.name}`);
    console.log(`  ID: ${audit.id}`);
    console.log(`  Status: ${audit.status}`);
    console.log(
      `  Members: ${audit.actualMembers} (stored: ${audit.memberCount})`
    );
    console.log(`  Proposals: ${audit.proposalCount}`);
    console.log(`  Votes: ${audit.voteCount}`);
    console.log(`  Activities: ${audit.activityCount}`);
    console.log(`  Created: ${audit.createdAt}`);
    console.log(`  Classification: ${audit.reason}`);
  }

  return results;
}

async function auditUsers(verbose: boolean): Promise<UserAudit[]> {
  console.log('\n=== User Audit ===\n');

  const usersSnapshot = await db.collection('users').get();
  const results: UserAudit[] = [];

  let completeProfiles = 0;
  let incompleteProfiles = 0;

  for (const userDoc of usersSnapshot.docs) {
    const data = userDoc.data();
    const userId = userDoc.id;

    // Count DAO memberships
    const membershipsSnap = await db
      .collection('dao-members')
      .where('userId', '==', data.privyId || userId)
      .get();

    const isComplete = data.profileSetupComplete === true;

    if (isComplete) {
      completeProfiles++;
    } else {
      incompleteProfiles++;
    }

    const audit: UserAudit = {
      id: userId,
      privyId: data.privyId || 'unknown',
      email: data.email,
      displayName: data.displayName,
      username: data.username,
      profileSetupComplete: isComplete,
      createdAt: formatTimestamp(data.createdAt),
      daoMemberships: membershipsSnap.size,
    };

    results.push(audit);

    if (verbose || isComplete) {
      const statusIcon = isComplete ? '✅' : '⏳';
      console.log(
        `${statusIcon} ${audit.displayName || audit.email || audit.privyId}`
      );
      console.log(`    ID: ${audit.id}`);
      console.log(`    Privy ID: ${audit.privyId}`);
      console.log(`    Username: ${audit.username || 'none'}`);
      console.log(`    Profile Complete: ${audit.profileSetupComplete}`);
      console.log(`    DAO Memberships: ${audit.daoMemberships}`);
    }
  }

  console.log(
    `\nSummary: ${completeProfiles} complete, ${incompleteProfiles} incomplete`
  );

  return results;
}

async function generateReport(
  verbose: boolean,
  exportToFile: boolean
): Promise<void> {
  console.log('\n' + '='.repeat(80));
  console.log('FIREBASE DATA AUDIT - Pre-Migration Analysis');
  console.log('='.repeat(80));
  console.log(`Timestamp: ${new Date().toISOString()}`);

  // Run all audits
  const collections = await auditCollections(verbose);
  const daos = await auditDAOs(verbose);
  const users = await auditUsers(verbose);

  // Calculate summary
  const realDaos = daos.filter((d) => d.isReal);
  const testDaos = daos.filter((d) => !d.isReal);
  const usersWithCompleteProfile = users.filter((u) => u.profileSetupComplete);

  const result: AuditResult = {
    timestamp: new Date().toISOString(),
    collections,
    daos,
    users,
    summary: {
      totalUsers: users.length,
      usersWithCompleteProfile: usersWithCompleteProfile.length,
      totalDaos: daos.length,
      realDaos: realDaos.length,
      testDaos: testDaos.length,
      totalProposals:
        collections.find((c) => c.name === 'proposals')?.count || 0,
      totalVotes: collections.find((c) => c.name === 'votes')?.count || 0,
      totalMembers:
        collections.find((c) => c.name === 'dao-members')?.count || 0,
    },
    recommendedMigration: {
      users: usersWithCompleteProfile.map((u) => u.id),
      daos: realDaos.map((d) => d.id),
      reasoning: `
Recommended migration includes:
- ${usersWithCompleteProfile.length} users with completed profiles
- ${realDaos.length} real DAOs (${realDaos.map((d) => d.name).join(', ')})
- All associated members, proposals, votes, and activities for those DAOs
- Usernames claimed by migrated users

Test data to discard:
- ${testDaos.length} test DAOs
- ${users.length - usersWithCompleteProfile.length} users without completed profiles
- All data associated with test DAOs
      `.trim(),
    },
  };

  // Print final summary
  console.log('\n' + '='.repeat(80));
  console.log('MIGRATION RECOMMENDATION');
  console.log('='.repeat(80));

  console.log('\n📦 Data to MIGRATE:');
  console.log(
    `   Users: ${result.summary.usersWithCompleteProfile} (with completed profiles)`
  );
  console.log(`   DAOs: ${result.summary.realDaos} real organizations`);
  realDaos.forEach((d) => {
    console.log(`      - ${d.name} (${d.id})`);
    console.log(
      `        Members: ${d.actualMembers}, Proposals: ${d.proposalCount}, Votes: ${d.voteCount}`
    );
  });

  console.log('\n🗑️  Data to DISCARD:');
  console.log(`   Test DAOs: ${result.summary.testDaos}`);
  testDaos.forEach((d) => {
    console.log(`      - ${d.name} (${d.reason})`);
  });
  console.log(
    `   Incomplete user profiles: ${users.length - usersWithCompleteProfile.length}`
  );

  console.log('\n📊 Collection Counts:');
  collections.forEach((c) => {
    console.log(`   ${c.name}: ${c.count}`);
  });

  // Export to file if requested
  if (exportToFile) {
    const exportPath = join(process.cwd(), 'firebase-audit-report.json');
    writeFileSync(exportPath, JSON.stringify(result, null, 2));
    console.log(`\n✅ Audit report exported to: ${exportPath}`);
  }

  console.log('\n' + '='.repeat(80));
  console.log('NEXT STEPS');
  console.log('='.repeat(80));
  console.log(`
1. Review the DAOs marked as "Unknown - requires manual review"
2. Confirm the real DAOs list with stakeholders
3. Run export script with confirmed DAO IDs
4. Proceed with Supabase schema creation
  `);
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);

  let verbose = false;
  let exportToFile = false;

  for (const arg of args) {
    if (arg === '--verbose') verbose = true;
    if (arg === '--export') exportToFile = true;
    if (arg === '--help' || arg === '-h') {
      console.log('Usage: npx tsx scripts/audit-firebase-data.ts [OPTIONS]');
      console.log('\nOptions:');
      console.log('  --verbose       Show detailed output for all records');
      console.log('  --export        Export audit report to JSON file');
      console.log('  --help, -h      Show this help message');
      process.exit(0);
    }
  }

  try {
    await generateReport(verbose, exportToFile);
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Error during audit:', error);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
