#!/bin/bash

# Switch between local and production Supabase environments
# Usage: ./scripts/switch-env.sh [local|production]

set -e

ENV_FILE=".env.local"
ENV_DEV=".env.development"
ENV_PROD=".env.production"

case "$1" in
  local)
    if [ ! -f "$ENV_DEV" ]; then
      echo "Error: $ENV_DEV not found"
      exit 1
    fi

    # Backup current .env.local if it exists
    if [ -f "$ENV_FILE" ]; then
      echo "Backing up current $ENV_FILE to $ENV_FILE.backup"
      cp "$ENV_FILE" "$ENV_FILE.backup"
    fi

    # Check if Supabase is running
    if ! supabase status &>/dev/null; then
      echo "Starting local Supabase..."
      supabase start
    fi

    # Copy local env and preserve non-Supabase variables from current .env.local
    echo "Switching to LOCAL Supabase environment..."

    # Create new env file with local Supabase config
    cp "$ENV_DEV" "$ENV_FILE.tmp"

    # Append non-Supabase variables from backup if it exists
    if [ -f "$ENV_FILE.backup" ]; then
      grep -v "^NEXT_PUBLIC_SUPABASE_URL\|^NEXT_PUBLIC_SUPABASE_ANON_KEY\|^SUPABASE_SERVICE_ROLE_KEY\|^#" "$ENV_FILE.backup" >> "$ENV_FILE.tmp" 2>/dev/null || true
    fi

    mv "$ENV_FILE.tmp" "$ENV_FILE"

    echo "✅ Switched to LOCAL environment"
    echo "   Supabase URL: http://127.0.0.1:54321"
    echo "   Studio: http://127.0.0.1:54323"
    echo ""
    echo "Run 'pnpm dev' to start the development server"
    ;;

  production)
    if [ ! -f "$ENV_FILE.backup" ]; then
      echo "Error: No backup found. Cannot switch to production."
      echo "You need to manually configure .env.local with production credentials."
      exit 1
    fi

    echo "Switching to PRODUCTION Supabase environment..."
    cp "$ENV_FILE.backup" "$ENV_FILE"

    echo "✅ Switched to PRODUCTION environment"
    echo ""
    echo "⚠️  WARNING: You are now connected to PRODUCTION database"
    ;;

  status)
    if [ -f "$ENV_FILE" ]; then
      URL=$(grep "^NEXT_PUBLIC_SUPABASE_URL=" "$ENV_FILE" | cut -d'=' -f2)
      if echo "$URL" | grep -q "127.0.0.1\|localhost"; then
        echo "Current environment: LOCAL"
        echo "Supabase URL: $URL"
      else
        echo "Current environment: PRODUCTION"
        echo "Supabase URL: $URL"
      fi
    else
      echo "No .env.local found"
    fi
    ;;

  *)
    echo "Usage: $0 [local|production|status]"
    echo ""
    echo "Commands:"
    echo "  local      - Switch to local Supabase (Docker)"
    echo "  production - Switch to production Supabase"
    echo "  status     - Show current environment"
    exit 1
    ;;
esac
