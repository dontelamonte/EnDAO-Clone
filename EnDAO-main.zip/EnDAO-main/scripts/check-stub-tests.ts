#!/usr/bin/env npx tsx
/**
 * Stub Test Detection Script
 *
 * Ensures all test files import and test actual code from the codebase.
 * Run this in CI or as a pre-commit hook to prevent stub tests.
 *
 * Usage: npx tsx scripts/check-stub-tests.ts
 */

import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

const CODEBASE_IMPORT_PATTERNS = [
  /from\s+['"]@\//, // @/ path alias imports
  /from\s+['"]\.\.?\//, // Relative imports from parent/sibling
  /from\s+['"]@endao\//, // Monorepo package imports
  /import\(['"]\.\.?\//, // Dynamic imports from parent/sibling
  /import\(['"]@\//, // Dynamic imports with @/ alias
];

const EXCEPTIONS = [
  // Files that legitimately don't need codebase imports
  'setup.ts',
  'teardown.ts',
  'test-utils.ts',
];

function findTestFiles(dir: string): string[] {
  const files: string[] = [];

  function walk(currentDir: string) {
    const entries = readdirSync(currentDir);
    for (const entry of entries) {
      const fullPath = join(currentDir, entry);
      const stat = statSync(fullPath);

      if (stat.isDirectory()) {
        if (entry !== 'node_modules' && entry !== '.next' && entry !== 'dist') {
          walk(fullPath);
        }
      } else if (entry.endsWith('.test.ts') || entry.endsWith('.test.tsx')) {
        files.push(fullPath);
      }
    }
  }

  walk(dir);
  return files;
}

function hasCodebaseImports(filePath: string): boolean {
  const content = readFileSync(filePath, 'utf-8');
  return CODEBASE_IMPORT_PATTERNS.some((pattern) => pattern.test(content));
}

function isException(filePath: string): boolean {
  return EXCEPTIONS.some((exc) => filePath.endsWith(exc));
}

function main() {
  console.log(
    '🔍 Checking for stub tests (tests without codebase imports)...\n'
  );

  const srcDir = join(process.cwd(), 'src');
  const testFiles = findTestFiles(srcDir);
  const stubTests: string[] = [];

  for (const file of testFiles) {
    if (isException(file)) continue;

    if (!hasCodebaseImports(file)) {
      stubTests.push(file.replace(process.cwd() + '/', ''));
    }
  }

  if (stubTests.length > 0) {
    console.error('❌ Found stub tests that do not import actual code:\n');
    stubTests.forEach((f) => console.error(`   - ${f}`));
    console.error(
      '\n📝 All tests MUST import and test real code from the codebase.'
    );
    console.error(
      '   See docs/development/TEST_IMPROVEMENT_PLAN.md for patterns to follow.\n'
    );
    process.exit(1);
  }

  console.log(
    `✅ All ${testFiles.length} test files import actual code from the codebase.\n`
  );
  process.exit(0);
}

main();
