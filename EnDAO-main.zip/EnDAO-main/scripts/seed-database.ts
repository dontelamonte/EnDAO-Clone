#!/usr/bin/env npx tsx
/**
 * Database Seed Script
 *
 * Seeds the database with test data for E2E testing.
 * Usage: pnpm seed
 *
 * Prerequisites:
 * - .env.local with SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY
 * - Supabase project with migrations applied
 *
 * Alternative: Run seed.sql directly via psql or Supabase dashboard SQL editor
 */

import { createClient } from '@supabase/supabase-js';
import { config } from 'dotenv';

// Load environment variables
config({ path: '.env.local' });
config({ path: '.env' });

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

// Production safety check - block seeding production database
const PRODUCTION_URL_PATTERNS = [
  'supabase.co', // Supabase hosted production
  'endao.ai', // Custom domain
  'prod', // Common production indicators
  'production',
];

const isProductionUrl = (url: string): boolean => {
  const lowerUrl = url.toLowerCase();
  // Allow localhost and local development
  if (lowerUrl.includes('localhost') || lowerUrl.includes('127.0.0.1')) {
    return false;
  }
  // Allow Supabase local development
  if (lowerUrl.includes('supabase.local') || lowerUrl.includes('kong:8000')) {
    return false;
  }
  // Block known production patterns
  return PRODUCTION_URL_PATTERNS.some((pattern) => lowerUrl.includes(pattern));
};

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('❌ Missing required environment variables:');
  if (!SUPABASE_URL) console.error('   - NEXT_PUBLIC_SUPABASE_URL');
  if (!SUPABASE_SERVICE_ROLE_KEY)
    console.error('   - SUPABASE_SERVICE_ROLE_KEY');
  console.error('\nMake sure your .env.local file is configured.');
  process.exit(1);
}

// Block production seeding unless explicitly overridden
if (isProductionUrl(SUPABASE_URL)) {
  console.error('🚫 PRODUCTION DATABASE DETECTED');
  console.error(`   URL: ${SUPABASE_URL}`);
  console.error('');
  console.error('   Seeding production is blocked to prevent data pollution.');
  console.error(
    '   This script should only run against local or staging databases.'
  );
  console.error('');
  console.error('   If you REALLY need to seed production (not recommended):');
  console.error('   FORCE_SEED_PRODUCTION=true pnpm seed');

  if (process.env.FORCE_SEED_PRODUCTION !== 'true') {
    process.exit(1);
  }

  console.warn('');
  console.warn(
    '⚠️  FORCE_SEED_PRODUCTION=true detected. Proceeding with caution...'
  );
  console.warn('');
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

// Test user UUIDs (matching dev-auth.ts and seed.sql)
const TEST_USERS = {
  alice: 'a0000000-0000-0000-0000-000000000000',
  bob: 'b0000000-0000-0000-0000-000000000001',
  carol: 'c0000000-0000-0000-0000-000000000002',
  david: 'd0000000-0000-0000-0000-000000000003',
  emma: 'e0000000-0000-0000-0000-000000000004',
  frank: 'f0000000-0000-0000-0000-000000000005',
  grace: '60000000-0000-0000-0000-000000000006',
  henry: '70000000-0000-0000-0000-000000000007',
  ivy: '80000000-0000-0000-0000-000000000008',
  olivia: 'ee000000-0000-0000-0000-00000000000e',
  // Super admin user for system administration tests
  superAdmin: 'e0000000-0000-0000-0000-000000000009',
};

// Test DAO UUIDs
const TEST_DAOS = {
  techInnovators: '11111111-1111-1111-1111-111111111111',
  greenFuture: '22222222-2222-2222-2222-222222222222',
  artCollective: '33333333-3333-3333-3333-333333333333',
};

// Test Proposal UUIDs (valid UUID format - must start with 0-9 or a-f)
const TEST_PROPOSALS = {
  activeGovernance: '01111111-1111-1111-1111-111111111111',
  activeFunding: '02222222-2222-2222-2222-222222222222',
  passed: '03333333-3333-3333-3333-333333333333',
  failed: '04444444-4444-4444-4444-444444444444',
  draft: '05555555-5555-5555-5555-555555555555',
  underReview: '06666666-6666-6666-6666-666666666666',
  bounty: '07777777-7777-7777-7777-777777777777',
};

// Test Comment UUIDs (valid UUID format - must start with 0-9 or a-f)
const TEST_COMMENTS = {
  comment1: 'a1111111-1111-1111-1111-111111111111',
  comment2: 'a2222222-2222-2222-2222-222222222222',
  comment3: 'a3333333-3333-3333-3333-333333333333',
  comment4: 'a4444444-4444-4444-4444-444444444444',
  comment5: 'a5555555-5555-5555-5555-555555555555',
};

// Test Discussion UUIDs
const TEST_DISCUSSIONS = {
  techIntro: 'd1111111-1111-1111-1111-111111111111',
  governanceIdeas: 'd2222222-2222-2222-2222-222222222222',
  archivedDiscussion: 'd3333333-3333-3333-3333-333333333333',
};

// Test Discussion Comment UUIDs
const TEST_DISCUSSION_COMMENTS = {
  comment1: 'dc111111-1111-1111-1111-111111111111',
  comment2: 'dc222222-2222-2222-2222-222222222222',
  reply1: 'dc333333-3333-3333-3333-333333333333',
};

// Extended DAOs for lifecycle testing
const TEST_DAOS_EXTENDED = {
  pendingDeletion: '44444444-4444-4444-4444-444444444444',
};

async function clearTestData() {
  console.log('🧹 Clearing existing test data...\n');

  // Delete in reverse dependency order
  // Clear discussion-related data first
  await supabase
    .from('discussion_reactions')
    .delete()
    .in('discussion_id', Object.values(TEST_DISCUSSIONS));

  await supabase
    .from('discussion_comment_likes')
    .delete()
    .in('comment_id', Object.values(TEST_DISCUSSION_COMMENTS));

  await supabase
    .from('discussion_comments')
    .delete()
    .in('discussion_id', Object.values(TEST_DISCUSSIONS));

  await supabase
    .from('discussions')
    .delete()
    .in('id', Object.values(TEST_DISCUSSIONS));

  // Delete comment likes for test comments
  await supabase
    .from('comment_likes')
    .delete()
    .in('comment_id', Object.values(TEST_COMMENTS));

  // Delete comments for test proposals
  await supabase
    .from('proposal_comments')
    .delete()
    .in('proposal_id', Object.values(TEST_PROPOSALS));

  // Delete votes for test proposals
  await supabase
    .from('votes')
    .delete()
    .in('proposal_id', Object.values(TEST_PROPOSALS));

  await supabase
    .from('proposal_drafts')
    .delete()
    .in('dao_id', Object.values(TEST_DAOS));

  // Delete test proposals
  await supabase
    .from('proposals')
    .delete()
    .in('id', Object.values(TEST_PROPOSALS));

  // Clear DAO deletion tracking for extended DAOs
  await supabase
    .from('dao_deletion_tracking')
    .delete()
    .eq('dao_id', TEST_DAOS_EXTENDED.pendingDeletion);

  await supabase
    .from('dao_activities')
    .delete()
    .in('dao_id', [...Object.values(TEST_DAOS), TEST_DAOS_EXTENDED.pendingDeletion]);

  await supabase
    .from('dao_join_requests')
    .delete()
    .in('dao_id', [...Object.values(TEST_DAOS), TEST_DAOS_EXTENDED.pendingDeletion]);

  await supabase
    .from('dao_members')
    .delete()
    .in('dao_id', [...Object.values(TEST_DAOS), TEST_DAOS_EXTENDED.pendingDeletion]);

  await supabase
    .from('dao_invitations')
    .delete()
    .in('dao_id', [...Object.values(TEST_DAOS), TEST_DAOS_EXTENDED.pendingDeletion]);

  await supabase.from('daos').delete().like('slug', 'test-%');
  await supabase
    .from('usernames')
    .delete()
    .like('username', '%test.endao.local');
  await supabase
    .from('user_preferences')
    .delete()
    .in('user_id', Object.values(TEST_USERS));

  // Clear admin_users for test super admin
  await supabase
    .from('admin_users')
    .delete()
    .eq('user_id', TEST_USERS.superAdmin);

  await supabase.from('users').delete().like('privy_id', 'test-privy-user-%');

  console.log('   ✓ Test data cleared\n');
}

async function seedUsers() {
  console.log('👤 Seeding test users...');

  const users = [
    {
      id: TEST_USERS.alice,
      privy_id: 'test-privy-user-0',
      email: 'alice0@test.endao.local',
      display_name: 'Alice Smith',
      username: 'alice0',
      lowercase_username: 'alice0',
      bio: 'DAO governance enthusiast',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.bob,
      privy_id: 'test-privy-user-1',
      email: 'bob1@test.endao.local',
      display_name: 'Bob Johnson',
      username: 'bob1',
      lowercase_username: 'bob1',
      bio: 'Software developer',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.carol,
      privy_id: 'test-privy-user-2',
      email: 'carol2@test.endao.local',
      display_name: 'Carol Williams',
      username: 'carol2',
      lowercase_username: 'carol2',
      bio: 'Treasury signer',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.david,
      privy_id: 'test-privy-user-3',
      email: 'david3@test.endao.local',
      display_name: 'David Brown',
      username: 'david3',
      lowercase_username: 'david3',
      bio: 'Active voter',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.emma,
      privy_id: 'test-privy-user-4',
      email: 'emma4@test.endao.local',
      display_name: 'Emma Davis',
      username: 'emma4',
      lowercase_username: 'emma4',
      bio: 'Proposal creator',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.frank,
      privy_id: 'test-privy-user-5',
      email: 'frank5@test.endao.local',
      display_name: 'Frank Miller',
      username: 'frank5',
      lowercase_username: 'frank5',
      bio: 'Commenter',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.grace,
      privy_id: 'test-privy-user-6',
      email: 'grace6@test.endao.local',
      display_name: 'Grace Lee',
      username: 'grace6',
      lowercase_username: 'grace6',
      bio: 'Green Future founder',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.henry,
      privy_id: 'test-privy-user-7',
      email: 'henry7@test.endao.local',
      display_name: 'Henry Wilson',
      username: 'henry7',
      lowercase_username: 'henry7',
      bio: 'Multi-DAO member',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.ivy,
      privy_id: 'test-privy-user-8',
      email: 'ivy8@test.endao.local',
      display_name: 'Ivy Chen',
      username: 'ivy8',
      lowercase_username: 'ivy8',
      bio: 'Art Collective founder',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.olivia,
      privy_id: 'test-privy-user-14',
      email: 'olivia14@test.endao.local',
      display_name: 'Olivia Martinez',
      username: 'olivia14',
      lowercase_username: 'olivia14',
      bio: 'Non-member',
      profile_setup_complete: true,
    },
    {
      id: TEST_USERS.superAdmin,
      privy_id: 'test-privy-user-super-admin',
      email: 'super.admin@test.endao.local',
      display_name: 'Super Admin Test',
      username: 'superadmin',
      lowercase_username: 'superadmin',
      bio: 'System super administrator',
      profile_setup_complete: true,
    },
  ];

  const { error } = await supabase.from('users').insert(users);
  if (error) throw new Error(`Failed to seed users: ${error.message}`);

  console.log(`   ✓ Created ${users.length} test users\n`);
}

async function seedDAOs() {
  console.log('🏛️  Seeding test DAOs...');

  const daos = [
    {
      id: TEST_DAOS.techInnovators,
      name: 'Tech Innovators',
      description: 'A DAO dedicated to funding innovative technology projects.',
      slug: 'test-tech-innovators',
      is_public: true,
      member_count: 8,
      status: 'active',
      visibility: 'public',
      governance_settings: {
        votingPeriodDays: 7,
        quorumPercentage: 30,
        passThreshold: 50,
        votingSystem: 'simple',
        allowVoteChange: true,
      },
      tags: ['technology', 'innovation'],
      created_by: TEST_USERS.alice,
    },
    {
      id: TEST_DAOS.greenFuture,
      name: 'Green Future',
      description: 'Funding environmental initiatives.',
      slug: 'test-green-future',
      is_public: true,
      member_count: 6,
      status: 'active',
      visibility: 'public',
      governance_settings: {
        votingPeriodDays: 5,
        quorumPercentage: 40,
        passThreshold: 60,
        votingSystem: 'simple',
        allowEarlyExecution: true,
      },
      tags: ['environment', 'sustainability'],
      created_by: TEST_USERS.grace,
    },
    {
      id: TEST_DAOS.artCollective,
      name: 'Art Collective',
      description: 'Supporting digital artists.',
      slug: 'test-art-collective',
      is_public: true,
      member_count: 4,
      status: 'active',
      visibility: 'public',
      governance_settings: {
        votingPeriodDays: 3,
        quorumPercentage: 25,
        passThreshold: 50,
        votingSystem: 'simple',
        allowVoteChange: true,
      },
      tags: ['art', 'nft'],
      created_by: TEST_USERS.ivy,
    },
  ];

  const { error } = await supabase.from('daos').insert(daos);
  if (error) throw new Error(`Failed to seed DAOs: ${error.message}`);

  console.log(`   ✓ Created ${daos.length} test DAOs\n`);
}

async function seedMembers() {
  console.log('👥 Seeding DAO members...');

  const members = [
    // Tech Innovators
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.alice,
      role: 'owner',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.bob,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.carol,
      role: 'admin',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.david,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.emma,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.frank,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.henry,
      role: 'member',
      status: 'active',
    },
    // Green Future
    {
      dao_id: TEST_DAOS.greenFuture,
      user_id: TEST_USERS.grace,
      role: 'owner',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.greenFuture,
      user_id: TEST_USERS.alice,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.greenFuture,
      user_id: TEST_USERS.bob,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.greenFuture,
      user_id: TEST_USERS.henry,
      role: 'admin',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.greenFuture,
      user_id: TEST_USERS.david,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.greenFuture,
      user_id: TEST_USERS.emma,
      role: 'member',
      status: 'active',
    },
    // Art Collective
    {
      dao_id: TEST_DAOS.artCollective,
      user_id: TEST_USERS.ivy,
      role: 'owner',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.artCollective,
      user_id: TEST_USERS.henry,
      role: 'member',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS.artCollective,
      user_id: TEST_USERS.frank,
      role: 'member',
      status: 'active',
    },
  ];

  const { error } = await supabase.from('dao_members').insert(members);
  if (error) throw new Error(`Failed to seed members: ${error.message}`);

  console.log(`   ✓ Created ${members.length} DAO memberships\n`);
}

async function seedProposals() {
  console.log('📜 Seeding proposals...');

  const now = new Date();
  const dayMs = 24 * 60 * 60 * 1000;

  const proposals = [
    {
      id: TEST_PROPOSALS.activeGovernance,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.emma,
      title: 'Update Voting Period to 10 Days',
      description:
        'Proposal to extend our voting period from 7 days to 10 days.',
      type: 'governance',
      status: 'active',
      voting_config: {
        votingSystem: 'simple',
        votingPeriodDays: 7,
        quorumPercentage: 30,
        passThreshold: 50,
        allowVoteChange: true,
      },
      voting_start_time: new Date(now.getTime() - 2 * dayMs).toISOString(),
      voting_end_time: new Date(now.getTime() + 5 * dayMs).toISOString(),
    },
    {
      id: TEST_PROPOSALS.activeFunding,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.bob,
      title: 'Fund Developer Tools Project',
      description: 'Requesting 500 USDC to build developer tooling.',
      type: 'funding',
      status: 'active',
      voting_config: {
        votingSystem: 'simple',
        votingPeriodDays: 7,
        quorumPercentage: 30,
        passThreshold: 50,
        allowVoteChange: true,
      },
      voting_start_time: new Date(now.getTime() - 1 * dayMs).toISOString(),
      voting_end_time: new Date(now.getTime() + 6 * dayMs).toISOString(),
      execution_method: 'treasury',
      execution_data: { amount: 500, currency: 'USDC' },
    },
    {
      id: TEST_PROPOSALS.passed,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.alice,
      title: 'Establish Community Guidelines',
      description: 'Creating official community guidelines.',
      type: 'general',
      status: 'passed',
      voting_config: {
        votingSystem: 'simple',
        votingPeriodDays: 7,
        quorumPercentage: 30,
        passThreshold: 50,
      },
      voting_start_time: new Date(now.getTime() - 20 * dayMs).toISOString(),
      voting_end_time: new Date(now.getTime() - 13 * dayMs).toISOString(),
      result: {
        yes: 6,
        no: 1,
        abstain: 1,
        totalVotes: 8,
        quorumReached: true,
        passed: true,
      },
    },
    {
      id: TEST_PROPOSALS.failed,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.david,
      title: 'Purchase NFT Collection',
      description: 'Proposal to spend 2000 USDC on NFTs.',
      type: 'funding',
      status: 'failed',
      voting_config: {
        votingSystem: 'simple',
        votingPeriodDays: 7,
        quorumPercentage: 30,
        passThreshold: 50,
      },
      voting_start_time: new Date(now.getTime() - 30 * dayMs).toISOString(),
      voting_end_time: new Date(now.getTime() - 23 * dayMs).toISOString(),
      result: {
        yes: 2,
        no: 5,
        abstain: 1,
        totalVotes: 8,
        quorumReached: true,
        passed: false,
      },
    },
    {
      id: TEST_PROPOSALS.draft,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.bob,
      title: 'Draft: Partnership Proposal',
      description: 'Working draft for a potential partnership.',
      type: 'general',
      status: 'draft',
      voting_config: {
        votingSystem: 'simple',
        votingPeriodDays: 7,
        quorumPercentage: 30,
        passThreshold: 50,
      },
    },
    {
      id: TEST_PROPOSALS.bounty,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.alice,
      title: 'Build Mobile App MVP',
      description: 'Bounty for developing a mobile app MVP.',
      type: 'bounty',
      status: 'active',
      voting_config: {
        votingSystem: 'simple',
        votingPeriodDays: 14,
        quorumPercentage: 20,
        passThreshold: 50,
      },
      voting_start_time: new Date(now.getTime() - 3 * dayMs).toISOString(),
      voting_end_time: new Date(now.getTime() + 11 * dayMs).toISOString(),
      bounty_reward: 1000,
      bounty_currency: 'USDC',
      bounty_deadline: new Date(now.getTime() + 30 * dayMs).toISOString(),
      bounty_requirements: [
        'React Native experience',
        'Portfolio of mobile apps',
      ],
    },
  ];

  const { error } = await supabase.from('proposals').insert(proposals);
  if (error) throw new Error(`Failed to seed proposals: ${error.message}`);

  console.log(`   ✓ Created ${proposals.length} proposals\n`);
}

async function seedVotes() {
  console.log('🗳️  Seeding votes...');

  const votes = [
    // Votes for active governance proposal (will reach quorum)
    {
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.alice,
      dao_id: TEST_DAOS.techInnovators,
      vote: 'yes',
      voting_power: 1,
    },
    // NOTE: Bob's vote intentionally omitted so E2E tests can vote fresh
    {
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.carol,
      dao_id: TEST_DAOS.techInnovators,
      vote: 'yes',
      voting_power: 1,
    },
    {
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.david,
      dao_id: TEST_DAOS.techInnovators,
      vote: 'no',
      voting_power: 1,
    },
    // Votes for active funding (won't reach quorum yet)
    {
      proposal_id: TEST_PROPOSALS.activeFunding,
      user_id: TEST_USERS.emma,
      dao_id: TEST_DAOS.techInnovators,
      vote: 'yes',
      voting_power: 1,
    },
    // Votes for bounty
    {
      proposal_id: TEST_PROPOSALS.bounty,
      user_id: TEST_USERS.alice,
      dao_id: TEST_DAOS.techInnovators,
      vote: 'yes',
      voting_power: 1,
    },
    {
      proposal_id: TEST_PROPOSALS.bounty,
      user_id: TEST_USERS.carol,
      dao_id: TEST_DAOS.techInnovators,
      vote: 'yes',
      voting_power: 1,
    },
  ];

  const { error } = await supabase.from('votes').insert(votes);
  if (error) throw new Error(`Failed to seed votes: ${error.message}`);

  console.log(`   ✓ Created ${votes.length} votes\n`);
}

async function seedComments() {
  console.log('💬 Seeding comments...');

  const comments = [
    {
      id: TEST_COMMENTS.comment1,
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.bob,
      content:
        'I support extending the voting period. More time means better discussions.',
    },
    {
      id: TEST_COMMENTS.comment2,
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.alice,
      content: 'Thanks for the feedback! I think this will help participation.',
      parent_id: TEST_COMMENTS.comment1,
    },
    {
      id: TEST_COMMENTS.comment3,
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.david,
      content: 'While I see the benefits, 10 days might slow things down.',
    },
    {
      id: TEST_COMMENTS.comment4,
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.frank,
      content: 'Great point David. Maybe 8 days as a compromise?',
      parent_id: TEST_COMMENTS.comment3,
    },
    {
      id: TEST_COMMENTS.comment5,
      proposal_id: TEST_PROPOSALS.activeGovernance,
      user_id: TEST_USERS.emma,
      content: 'As the creator, I am open to adjusting to 8 days.',
    },
  ];

  const { error } = await supabase.from('proposal_comments').insert(comments);
  if (error) throw new Error(`Failed to seed comments: ${error.message}`);

  console.log(`   ✓ Created ${comments.length} comments\n`);
}

async function seedCommentLikes() {
  console.log('❤️  Seeding comment likes...');

  const likes = [
    { comment_id: TEST_COMMENTS.comment1, user_id: TEST_USERS.alice },
    { comment_id: TEST_COMMENTS.comment1, user_id: TEST_USERS.david },
    { comment_id: TEST_COMMENTS.comment1, user_id: TEST_USERS.emma },
    { comment_id: TEST_COMMENTS.comment3, user_id: TEST_USERS.bob },
    { comment_id: TEST_COMMENTS.comment3, user_id: TEST_USERS.frank },
  ];

  const { error } = await supabase.from('comment_likes').insert(likes);
  if (error) throw new Error(`Failed to seed comment likes: ${error.message}`);

  console.log(`   ✓ Created ${likes.length} comment likes\n`);
}

async function seedDrafts() {
  console.log('📝 Seeding proposal drafts...');

  const drafts = [
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.bob,
      title: 'Untitled Draft',
      description: 'Working on a new idea...',
      type: 'general',
      draft_data: { lastSaved: 'auto' },
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.emma,
      title: 'Treasury Diversification',
      description: 'Proposal to diversify treasury',
      type: 'funding',
      draft_data: { amount: 1000 },
    },
  ];

  const { error } = await supabase.from('proposal_drafts').insert(drafts);
  if (error) throw new Error(`Failed to seed drafts: ${error.message}`);

  console.log(`   ✓ Created ${drafts.length} proposal drafts\n`);
}

async function seedDiscussions() {
  console.log('💬 Seeding discussions...');

  const discussions = [
    {
      id: TEST_DISCUSSIONS.techIntro,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.alice,
      title: 'Welcome to Tech Innovators!',
      content:
        'This is our introductory discussion thread. Feel free to introduce yourself and share your interests in technology and innovation. We are excited to have you here!',
      status: 'active',
      is_pinned: true,
      comment_count: 2,
    },
    {
      id: TEST_DISCUSSIONS.governanceIdeas,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.bob,
      title: 'Ideas for Improving Our Governance',
      content:
        'I have been thinking about ways we can improve our governance processes. Some ideas include implementing quadratic voting, adding delegation features, and creating a proposal template system. What do you all think?',
      status: 'active',
      is_pinned: false,
      comment_count: 1,
    },
    {
      id: TEST_DISCUSSIONS.archivedDiscussion,
      dao_id: TEST_DAOS.techInnovators,
      created_by: TEST_USERS.carol,
      title: '[Resolved] Website Migration Update',
      content:
        'We have successfully migrated our website to the new platform. Thanks everyone for your patience during the transition period.',
      status: 'archived',
      is_pinned: false,
      comment_count: 0,
    },
  ];

  const { error } = await supabase.from('discussions').insert(discussions);
  if (error) throw new Error(`Failed to seed discussions: ${error.message}`);

  console.log(`   ✓ Created ${discussions.length} discussions\n`);
}

async function seedDiscussionComments() {
  console.log('💭 Seeding discussion comments...');

  const comments = [
    {
      id: TEST_DISCUSSION_COMMENTS.comment1,
      discussion_id: TEST_DISCUSSIONS.techIntro,
      user_id: TEST_USERS.bob,
      content:
        'Great to be here! I am a software developer interested in blockchain technology.',
    },
    {
      id: TEST_DISCUSSION_COMMENTS.comment2,
      discussion_id: TEST_DISCUSSIONS.techIntro,
      user_id: TEST_USERS.carol,
      content:
        'Welcome everyone! I handle treasury management for the DAO.',
    },
    {
      id: TEST_DISCUSSION_COMMENTS.reply1,
      discussion_id: TEST_DISCUSSIONS.governanceIdeas,
      user_id: TEST_USERS.alice,
      content:
        'These are great ideas Bob! I especially like the quadratic voting suggestion.',
    },
  ];

  const { error } = await supabase
    .from('discussion_comments')
    .insert(comments);
  if (error)
    throw new Error(`Failed to seed discussion comments: ${error.message}`);

  console.log(`   ✓ Created ${comments.length} discussion comments\n`);
}

async function seedDiscussionReactions() {
  console.log('🎉 Seeding discussion reactions...');

  const reactions = [
    {
      discussion_id: TEST_DISCUSSIONS.techIntro,
      user_id: TEST_USERS.bob,
      emoji: '👍',
    },
    {
      discussion_id: TEST_DISCUSSIONS.techIntro,
      user_id: TEST_USERS.carol,
      emoji: '❤️',
    },
    {
      discussion_id: TEST_DISCUSSIONS.techIntro,
      user_id: TEST_USERS.david,
      emoji: '🎉',
    },
    {
      discussion_id: TEST_DISCUSSIONS.governanceIdeas,
      user_id: TEST_USERS.alice,
      emoji: '🚀',
    },
    {
      discussion_id: TEST_DISCUSSIONS.governanceIdeas,
      user_id: TEST_USERS.carol,
      emoji: '👍',
    },
  ];

  const { error } = await supabase
    .from('discussion_reactions')
    .insert(reactions);
  if (error)
    throw new Error(`Failed to seed discussion reactions: ${error.message}`);

  console.log(`   ✓ Created ${reactions.length} discussion reactions\n`);
}

async function seedUserPreferences() {
  console.log('⚙️  Seeding user preferences...');

  const preferences = [
    {
      user_id: TEST_USERS.alice,
      notification_settings: {
        email: true,
        push: true,
        proposalCreated: true,
        voteReminder: true,
        proposalPassed: true,
      },
      display_settings: {
        theme: 'light',
        compactView: false,
      },
    },
    {
      user_id: TEST_USERS.bob,
      notification_settings: {
        email: true,
        push: false,
        proposalCreated: true,
        voteReminder: false,
        proposalPassed: true,
      },
      display_settings: {
        theme: 'dark',
        compactView: true,
      },
    },
    {
      user_id: TEST_USERS.carol,
      notification_settings: {
        email: false,
        push: true,
        proposalCreated: false,
        voteReminder: true,
        proposalPassed: false,
      },
      display_settings: {
        theme: 'system',
        compactView: false,
      },
    },
  ];

  const { error } = await supabase.from('user_preferences').insert(preferences);
  if (error)
    throw new Error(`Failed to seed user preferences: ${error.message}`);

  console.log(`   ✓ Created ${preferences.length} user preferences\n`);
}

async function seedAdminUsers() {
  console.log('🔐 Seeding admin users...');

  const adminUsers = [
    {
      user_id: TEST_USERS.superAdmin,
      role: 'super_admin',
    },
  ];

  const { error } = await supabase.from('admin_users').insert(adminUsers);
  if (error) throw new Error(`Failed to seed admin users: ${error.message}`);

  console.log(`   ✓ Created ${adminUsers.length} admin users\n`);
}

async function seedPendingDeletionDAO() {
  console.log('🗑️  Seeding pending deletion DAO...');

  const now = new Date();
  const dayMs = 24 * 60 * 60 * 1000;

  // Create the DAO with pending_deletion status
  const dao = {
    id: TEST_DAOS_EXTENDED.pendingDeletion,
    name: 'Sunset DAO',
    description: 'A DAO in the process of being deleted.',
    slug: 'test-sunset-dao',
    is_public: true,
    member_count: 2,
    status: 'pending_deletion',
    visibility: 'public',
    governance_settings: {
      votingPeriodDays: 7,
      quorumPercentage: 30,
      passThreshold: 50,
      votingSystem: 'simple',
    },
    tags: ['test', 'lifecycle'],
    created_by: TEST_USERS.alice,
  };

  const { error: daoError } = await supabase.from('daos').insert(dao);
  if (daoError)
    throw new Error(`Failed to seed pending deletion DAO: ${daoError.message}`);

  // Add members to the DAO
  const members = [
    {
      dao_id: TEST_DAOS_EXTENDED.pendingDeletion,
      user_id: TEST_USERS.alice,
      role: 'owner',
      status: 'active',
    },
    {
      dao_id: TEST_DAOS_EXTENDED.pendingDeletion,
      user_id: TEST_USERS.bob,
      role: 'member',
      status: 'active',
    },
  ];

  const { error: memberError } = await supabase
    .from('dao_members')
    .insert(members);
  if (memberError)
    throw new Error(
      `Failed to seed pending deletion DAO members: ${memberError.message}`
    );

  // Create deletion tracking record
  const deletionTracking = {
    dao_id: TEST_DAOS_EXTENDED.pendingDeletion,
    initiated_by: TEST_USERS.alice,
    initiated_at: new Date(now.getTime() - 2 * dayMs).toISOString(),
    reason: 'Testing DAO deletion flow',
    grace_period_days: 7,
    scheduled_deletion_date: new Date(now.getTime() + 5 * dayMs).toISOString(),
    can_recover_until: new Date(now.getTime() + 5 * dayMs).toISOString(),
    status: 'pending',
    original_dao_snapshot: {
      name: 'Sunset DAO',
      member_count: 2,
      created_at: dao.created_by,
    },
    original_member_count: 2,
    original_proposal_count: 0,
  };

  const { error: trackingError } = await supabase
    .from('dao_deletion_tracking')
    .insert(deletionTracking);
  if (trackingError)
    throw new Error(
      `Failed to seed deletion tracking: ${trackingError.message}`
    );

  console.log(`   ✓ Created pending deletion DAO with tracking record\n`);
}

async function seedDAOActivities() {
  console.log('📊 Seeding DAO activities...');

  const now = new Date();
  const hourMs = 60 * 60 * 1000;

  const activities = [
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.alice,
      activity_type: 'member_joined',
      description: 'Alice joined the DAO',
      metadata: { role: 'owner' },
      created_at: new Date(now.getTime() - 48 * hourMs).toISOString(),
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.bob,
      activity_type: 'member_joined',
      description: 'Bob joined the DAO',
      metadata: { role: 'member' },
      created_at: new Date(now.getTime() - 36 * hourMs).toISOString(),
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.emma,
      activity_type: 'proposal_created',
      description: 'Emma created proposal: Update Voting Period',
      metadata: { proposalId: TEST_PROPOSALS.activeGovernance },
      created_at: new Date(now.getTime() - 24 * hourMs).toISOString(),
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.alice,
      activity_type: 'vote_cast',
      description: 'Alice voted on: Update Voting Period',
      metadata: { proposalId: TEST_PROPOSALS.activeGovernance, vote: 'yes' },
      created_at: new Date(now.getTime() - 12 * hourMs).toISOString(),
    },
    {
      dao_id: TEST_DAOS.techInnovators,
      user_id: TEST_USERS.bob,
      activity_type: 'discussion_created',
      description: 'Bob created discussion: Ideas for Improving Our Governance',
      metadata: { discussionId: TEST_DISCUSSIONS.governanceIdeas },
      created_at: new Date(now.getTime() - 6 * hourMs).toISOString(),
    },
  ];

  const { error } = await supabase.from('dao_activities').insert(activities);
  if (error) throw new Error(`Failed to seed DAO activities: ${error.message}`);

  console.log(`   ✓ Created ${activities.length} DAO activities\n`);
}

async function verifySeedData() {
  console.log('🔍 Verifying seed data...\n');

  const { count: userCount } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true })
    .like('privy_id', 'test-privy-user-%');

  const { count: daoCount } = await supabase
    .from('daos')
    .select('*', { count: 'exact', head: true })
    .like('slug', 'test-%');

  const { count: memberCount } = await supabase
    .from('dao_members')
    .select('*', { count: 'exact', head: true })
    .in('dao_id', [...Object.values(TEST_DAOS), TEST_DAOS_EXTENDED.pendingDeletion]);

  const { count: proposalCount } = await supabase
    .from('proposals')
    .select('*', { count: 'exact', head: true })
    .in('id', Object.values(TEST_PROPOSALS));

  const { count: voteCount } = await supabase
    .from('votes')
    .select('*', { count: 'exact', head: true })
    .in('proposal_id', Object.values(TEST_PROPOSALS));

  const { count: commentCount } = await supabase
    .from('proposal_comments')
    .select('*', { count: 'exact', head: true })
    .in('id', Object.values(TEST_COMMENTS));

  const { count: discussionCount } = await supabase
    .from('discussions')
    .select('*', { count: 'exact', head: true })
    .in('id', Object.values(TEST_DISCUSSIONS));

  const { count: discussionCommentCount } = await supabase
    .from('discussion_comments')
    .select('*', { count: 'exact', head: true })
    .in('id', Object.values(TEST_DISCUSSION_COMMENTS));

  const { count: preferenceCount } = await supabase
    .from('user_preferences')
    .select('*', { count: 'exact', head: true })
    .in('user_id', Object.values(TEST_USERS));

  const { count: activityCount } = await supabase
    .from('dao_activities')
    .select('*', { count: 'exact', head: true })
    .in('dao_id', Object.values(TEST_DAOS));

  const { count: adminUserCount } = await supabase
    .from('admin_users')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', TEST_USERS.superAdmin);

  console.log('   📊 Seed data summary:');
  console.log(`      • Test users: ${userCount ?? 0}`);
  console.log(`      • Test DAOs: ${daoCount ?? 0}`);
  console.log(`      • DAO memberships: ${memberCount ?? 0}`);
  console.log(`      • Proposals: ${proposalCount ?? 0}`);
  console.log(`      • Votes: ${voteCount ?? 0}`);
  console.log(`      • Proposal comments: ${commentCount ?? 0}`);
  console.log(`      • Discussions: ${discussionCount ?? 0}`);
  console.log(`      • Discussion comments: ${discussionCommentCount ?? 0}`);
  console.log(`      • User preferences: ${preferenceCount ?? 0}`);
  console.log(`      • DAO activities: ${activityCount ?? 0}`);
  console.log(`      • Admin users: ${adminUserCount ?? 0}`);
}

async function runSeed() {
  console.log('🌱 Starting database seed...\n');

  try {
    await clearTestData();
    await seedUsers();
    await seedDAOs();
    await seedMembers();
    await seedProposals();
    await seedVotes();
    await seedComments();
    await seedCommentLikes();
    await seedDrafts();
    await seedDiscussions();
    await seedDiscussionComments();
    await seedDiscussionReactions();
    await seedUserPreferences();
    await seedAdminUsers();
    await seedPendingDeletionDAO();
    await seedDAOActivities();
    await verifySeedData();

    console.log('\n✅ Database seed completed!\n');

    console.log('📝 Test DAOs available:');
    console.log('   • test-tech-innovators (Tech Innovators)');
    console.log('   • test-green-future (Green Future)');
    console.log('   • test-art-collective (Art Collective)');
    console.log('   • test-sunset-dao (Pending Deletion)');
    console.log('');
    console.log('👤 Test users (use dev auth toolbar to switch):');
    console.log('   • admin: alice0@test.endao.local (DAO owner)');
    console.log('   • member: bob1@test.endao.local (regular member)');
    console.log('   • signer: carol2@test.endao.local (treasury signer)');
    console.log('   • nonMember: olivia14@test.endao.local (not in any DAO)');
    console.log('   • superAdmin: super.admin@test.endao.local (system super admin)');
    console.log('');
    console.log('🧪 Test scenarios available:');
    console.log('   • Active proposal reaching quorum (Update Voting Period)');
    console.log(
      '   • Active proposal not reaching quorum (Fund Developer Tools)'
    );
    console.log('   • Passed proposal (Community Guidelines)');
    console.log('   • Failed proposal (Purchase NFT Collection)');
    console.log('   • Draft proposal (Partnership Proposal)');
    console.log('   • Bounty proposal (Build Mobile App MVP)');
    console.log('   • Comments with likes and replies');
    console.log('   • Discussions with comments and reactions');
    console.log('   • User preferences/notification settings');
    console.log('   • DAO pending deletion with grace period');
    console.log('   • DAO activity feed entries');
    console.log('');
  } catch (error) {
    console.error('\n❌ Seed failed:', (error as Error).message);
    process.exit(1);
  }
}

// Run the seed
runSeed();
