#!/usr/bin/env node

/**
 * Complexity Checking Script
 *
 * Analyzes cyclomatic complexity of functions in TypeScript and JavaScript files.
 * Uses simple AST analysis to detect function declarations and measure complexity.
 *
 * Complexity Calculation:
 * - Base complexity: 1
 * - +1 for each: if, else if, for, while, do-while, case, catch, &&, ||, ?, ??
 *
 * Threshold:
 * - Complexity > 10 is a violation
 *
 * Exit codes:
 * - 0: All functions within acceptable complexity
 * - 1: One or more functions exceed complexity threshold
 *
 * @example
 * node scripts/check-complexity.js
 */

const fs = require('fs');
const path = require('path');

// Configuration
const CONFIG = {
  targetDir: path.join(process.cwd(), 'src'),
  extensions: ['.ts', '.tsx', '.js', '.jsx'],
  excludeDirs: ['node_modules', '.next', 'dist', 'build', 'out'],
  complexityThreshold: 10,
};

/**
 * Recursively finds all matching files in a directory
 * @param {string} dir - Directory to search
 * @param {string[]} extensions - File extensions to match
 * @param {string[]} excludeDirs - Directories to skip
 * @returns {string[]} Array of file paths
 */
function findFiles(dir, extensions, excludeDirs) {
  const files = [];

  function walk(currentDir) {
    try {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);

        if (entry.isDirectory()) {
          if (!excludeDirs.includes(entry.name)) {
            walk(fullPath);
          }
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name);
          if (extensions.includes(ext)) {
            files.push(fullPath);
          }
        }
      }
    } catch (error) {
      console.warn(
        `Warning: Cannot read directory ${currentDir}: ${error.message}`
      );
    }
  }

  walk(dir);
  return files;
}

/**
 * Extracts function definitions from source code
 * Simple regex-based approach (not a full parser)
 * @param {string} content - File content
 * @returns {Array<{name: string, line: number, body: string}>}
 */
function extractFunctions(content) {
  const functions = [];
  const lines = content.split('\n');

  // Patterns to match various function declarations
  const patterns = [
    // function declaration: function name(...) {
    /^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(/,
    // arrow function: const name = (...) => {
    /^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\([^)]*\)\s*=>/,
    // method: name(...) {
    /^\s*(?:async\s+)?(\w+)\s*\([^)]*\)\s*\{/,
    // arrow function without parentheses: const name = x => {
    /^\s*(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\w+\s*=>/,
  ];

  let currentFunction = null;
  let braceDepth = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lineNumber = i + 1;

    // Check if line starts a function
    if (!currentFunction) {
      for (const pattern of patterns) {
        const match = line.match(pattern);
        if (match) {
          const name = match[1];
          // Skip test functions and very short names (often false positives)
          if (!name.startsWith('test') && name.length > 1) {
            currentFunction = {
              name,
              line: lineNumber,
              body: '',
            };
            braceDepth = 0;
          }
          break;
        }
      }
    }

    // Track function body
    if (currentFunction) {
      currentFunction.body += line + '\n';

      // Count braces to detect function end
      for (const char of line) {
        if (char === '{') braceDepth++;
        if (char === '}') braceDepth--;
      }

      // Function ended
      if (braceDepth === 0 && currentFunction.body.includes('{')) {
        functions.push(currentFunction);
        currentFunction = null;
      }
    }
  }

  return functions;
}

/**
 * Calculates cyclomatic complexity of a function body
 * @param {string} body - Function body
 * @returns {number} Complexity score
 */
function calculateComplexity(body) {
  let complexity = 1; // Base complexity

  // Remove comments and strings to avoid false positives
  const cleaned = body
    .replace(/\/\/.*$/gm, '') // Remove line comments
    .replace(/\/\*[\s\S]*?\*\//g, '') // Remove block comments
    .replace(/"[^"]*"|'[^']*'|`[^`]*`/g, ''); // Remove strings

  // Count complexity-increasing constructs
  const patterns = [
    /\bif\s*\(/g, // if statements
    /\belse\s+if\s*\(/g, // else if
    /\bfor\s*\(/g, // for loops
    /\bwhile\s*\(/g, // while loops
    /\bdo\s*\{/g, // do-while loops
    /\bcase\s+/g, // switch cases
    /\bcatch\s*\(/g, // catch blocks
    /\?\?/g, // nullish coalescing
    /&&/g, // logical AND
    /\|\|/g, // logical OR
  ];

  for (const pattern of patterns) {
    const matches = cleaned.match(pattern);
    if (matches) {
      complexity += matches.length;
    }
  }

  // Count ternary operators (? followed by :)
  const ternaryMatches = cleaned.match(/\?[^:]*:/g);
  if (ternaryMatches) {
    complexity += ternaryMatches.length;
  }

  return complexity;
}

/**
 * Analyzes complexity of all functions in a file
 * @param {string} filePath - Path to file
 * @returns {Array<{file: string, function: string, line: number, complexity: number}>}
 */
function analyzeFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const functions = extractFunctions(content);
    const results = [];

    for (const func of functions) {
      const complexity = calculateComplexity(func.body);
      if (complexity > CONFIG.complexityThreshold) {
        results.push({
          file: path.relative(process.cwd(), filePath),
          function: func.name,
          line: func.line,
          complexity,
        });
      }
    }

    return results;
  } catch (error) {
    console.warn(`Warning: Cannot analyze file ${filePath}: ${error.message}`);
    return [];
  }
}

/**
 * Main execution
 */
function main() {
  console.log('🔍 Checking code complexity...\n');

  // Find all files
  const files = findFiles(
    CONFIG.targetDir,
    CONFIG.extensions,
    CONFIG.excludeDirs
  );
  console.log(`Found ${files.length} files to check\n`);

  // Analyze files
  const violations = [];
  let totalFunctions = 0;

  for (const file of files) {
    const results = analyzeFile(file);
    violations.push(...results);
    totalFunctions += results.length;
  }

  // Sort by complexity (descending)
  violations.sort((a, b) => b.complexity - a.complexity);

  // Display results
  if (violations.length > 0) {
    console.log(
      `❌ Found ${violations.length} function(s) with complexity > ${CONFIG.complexityThreshold}:\n`
    );

    for (const v of violations) {
      console.log(`  ${v.file}:${v.line}`);
      console.log(`    Function: ${v.function}()`);
      console.log(`    Complexity: ${v.complexity}`);
      console.log('');
    }

    // Provide guidance
    console.log('💡 Suggestions to reduce complexity:');
    console.log('  - Extract conditional logic into separate functions');
    console.log('  - Use early returns to reduce nesting');
    console.log('  - Split large functions into smaller, focused ones');
    console.log('  - Consider using lookup tables or strategy patterns');
    console.log('');

    console.log(
      `❌ Complexity check FAILED: ${violations.length} function(s) exceed threshold`
    );
    process.exit(1);
  } else {
    console.log(
      `✅ Complexity check PASSED: All functions are within acceptable complexity (≤${CONFIG.complexityThreshold})`
    );
    console.log('');
    process.exit(0);
  }
}

// Run if executed directly
if (require.main === module) {
  main();
}

module.exports = {
  findFiles,
  extractFunctions,
  calculateComplexity,
  analyzeFile,
};
