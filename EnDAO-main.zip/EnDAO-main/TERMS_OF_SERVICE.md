# Terms of Service

**Effective Date: February 28, 2026**

## 1. Acceptance of Terms

By accessing or using EnDAO ("Platform", "Service", "we", "us", or "our"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, do not use our Service.

## 2. Description of Service

EnDAO is a decentralized autonomous organization (DAO) platform that enables users to:

- Create and manage DAOs
- Submit and vote on proposals
- Manage multi-signature treasuries
- Collaborate with other DAO members

## 3. Platform Status and Relationship

### 3.1 Technology Platform Status

EnDAO provides software-as-a-service for DAO governance and operations. The platform is provided "as-is" without warranties of merchantability or fitness for a particular purpose. EnDAO is not liable for vulnerabilities, bugs, or losses arising from smart contract execution.

### 3.2 No Fiduciary Relationship

EnDAO does not act as an agent for users or DAOs created on the platform. To the fullest extent permitted by law, EnDAO owes no fiduciary duties or liabilities to users, and users hereby waive such duties to the maximum extent permitted by law.

### 3.3 Separate Legal Entities

DAOs created on EnDAO platform are separate and independent entities from EnDAO, Inc. EnDAO is not responsible for the actions, omissions, obligations, or liabilities of any DAO created using the platform.

### 3.4 No Control Over User Assets

EnDAO does not custody, control, transmit, or have access to DAO treasuries or member assets. All treasury operations are executed through smart contracts controlled by DAO members via multi-signature mechanisms.

## 4. User Responsibility for Legal Compliance

Users are solely responsible for ensuring their DAO complies with applicable laws, including but not limited to:

- Securities regulations
- Tax obligations
- Money transmission requirements
- Local jurisdiction laws

EnDAO provides technology infrastructure only and does not provide legal, tax, or regulatory advice.

## 5. Eligibility

You must be at least 18 years old to use our Service. By using EnDAO, you represent and warrant that you meet this age requirement.

## 6. User Accounts

### 6.1 Account Creation

To access certain features, you must create an account using your Web3 wallet through our authentication provider (Privy). You are responsible for maintaining the security of your wallet and private keys.

### 6.2 Account Security

- Never share your private keys or seed phrases
- We will never ask for your private keys
- You are solely responsible for all activities under your account

## 7. User Conduct

You agree NOT to:

- Violate any applicable laws or regulations
- Impersonate any person or entity
- Interfere with or disrupt the Service
- Attempt to gain unauthorized access to any part of the Service
- Use the Service for any illegal or unauthorized purpose
- Manipulate voting mechanisms or governance processes
- Submit false, misleading, or fraudulent proposals

## 8. DAO Creation and Management

### 8.1 DAO Creation

When creating a DAO, you must:

- Provide accurate information
- Comply with all applicable laws
- Not create DAOs for illegal purposes

### 8.2 DAO Governance

- All governance decisions are binding once executed on-chain
- Voting results are final and immutable
- Treasury transactions require multi-signature approval as configured

## 9. Proposals and Voting

### 9.1 Proposal Submission

- Proposals must be relevant to the DAO's purpose
- False or misleading proposals may result in account suspension
- Proposal content must not violate these Terms

### 9.2 Voting Rights

- Voting rights are determined by each DAO's governance rules
- Votes are recorded on-chain and cannot be altered
- Vote buying or manipulation is strictly prohibited

## 10. Treasury Management

### 10.1 Multi-Signature Wallets

- Treasury funds are managed through Gnosis Safe smart contracts
- We do not have access to or control over treasury funds
- Treasury transactions require approval from designated signers

### 10.2 Transaction Responsibility

- Users are solely responsible for treasury transactions
- Transactions on blockchain are irreversible
- We are not liable for lost or misdirected funds

## 11. Blockchain Interactions

### 11.1 Gas Fees

You are responsible for paying all blockchain transaction fees (gas fees) associated with your use of the Service.

### 11.2 Blockchain Risks

You acknowledge and accept the risks associated with blockchain technology, including:

- Transaction delays or failures
- Smart contract vulnerabilities
- Network congestion
- Hard forks or chain reorganizations

## 12. Intellectual Property

### 12.1 Platform Content

All content on EnDAO, except user-generated content, is owned by us and protected by intellectual property laws.

### 12.2 User Content

You retain ownership of content you submit but grant us a license to use, display, and distribute it through the Service.

## 13. Privacy

Your use of our Service is also governed by our Privacy Policy. Please review our Privacy Policy, which also governs the Site and informs users of our data collection practices.

## 14. Disclaimers

### 14.1 Service Availability

THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED.

### 14.2 No Investment Advice

Nothing on this platform constitutes investment, legal, tax, or other advice. You should conduct your own due diligence before making any decisions.

### 14.3 Tax Disclaimer

Creating or participating in a DAO has tax implications, including but not limited to:

- Pass-through taxation for DAO activities
- Direct tax liability for token holders
- Reporting and cost basis tracking responsibilities

EnDAO provides transaction exports for your records but does NOT:

- Prepare tax returns
- Provide tax advice
- Calculate cost basis
- File any tax forms on your behalf

Consult a qualified tax advisor in your jurisdiction.

### 14.4 Third-Party Services

We are not responsible for third-party services integrated with our platform, including:

- Blockchain networks
- Wallet providers
- Smart contract protocols

## 15. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, WE SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO:

- Loss of profits
- Loss of data
- Loss of funds
- Smart contract failures
- Unauthorized access to wallets

## 16. Indemnification

You agree to indemnify and hold harmless EnDAO, its affiliates, officers, directors, employees, and agents from any claims, damages, losses, or expenses arising from:

- Your use of the platform
- Your DAO's operations
- Your violation of these Terms
- Breach of applicable laws or regulations by you or your DAO
- Infringement of third-party rights
- Any claims made by DAO members, participants, or affected parties

## 17. Modifications to Terms

We reserve the right to modify these Terms at any time. We will notify users of any material changes by posting the new Terms on this page and updating the "Effective Date."

## 18. Termination

### 18.1 Termination by You

You may stop using our Service at any time.

### 18.2 Termination by Us

We may suspend or terminate your access to the Service for violation of these Terms or for any other reason at our sole discretion.

### 18.3 Effect of Termination

Upon termination:

- Your access to the platform will be revoked
- On-chain data and transactions remain unchanged
- DAO memberships and voting records persist on blockchain

## 19. Jurisdiction and Access

EnDAO operates as a global platform. Users may create DAOs from any location subject to these restrictions:

EnDAO makes no representation that platform services are appropriate or available in all jurisdictions. Users access the platform at their own initiative and are responsible for compliance with local laws.

If your jurisdiction prohibits DAOs, smart contracts, or blockchain governance, you may not use this platform. EnDAO may restrict access from certain jurisdictions at any time without notice.

## 20. Dispute Resolution

### 20.1 Arbitration

Any disputes arising from these Terms shall be resolved through binding arbitration in accordance with the rules of the American Arbitration Association.

### 20.2 Waiver of Class Action

You waive any right to participate in a class action lawsuit or class-wide arbitration.

## 21. Governing Law

These Terms shall be governed by and construed in accordance with the laws of the State of Delaware, United States, without regard to its conflict of law provisions.

## 22. Severability

If any provision of these Terms is held to be invalid or unenforceable, the remaining provisions shall continue in full force and effect.

## 23. Subscription Plans and Billing

### 23.1 Available Plans

EnDAO offers subscription tiers including Starter (free), Community, Organization, and Enterprise plans. Each plan includes specific features and usage limits as described on our pricing page. Feature availability may change with reasonable notice.

### 23.2 Plan Changes

You may upgrade your plan at any time. Upgrades take effect immediately with prorated charges. Downgrades take effect at the end of your current billing period.

## 24. Free Trials

### 24.1 Trial Period

New subscribers to paid plans may receive a 14-day free trial with full access to the selected plan's features.

### 24.2 Trial Eligibility

Free trials are limited to one per DAO. We reserve the right to determine trial eligibility.

### 24.3 Trial Conversion

At the end of your trial:

- If payment information was provided, your subscription automatically converts to paid
- If no payment information was provided, your account downgrades to the Starter plan
- Cancel before the trial ends to avoid charges

## 25. Payment and Billing

### 25.1 Payment Processing

All payments are processed securely through Stripe. We accept major credit cards, debit cards, and other payment methods displayed at checkout.

### 25.2 Automatic Renewal

Subscriptions automatically renew unless cancelled. By subscribing, you authorize recurring charges to your payment method. We will send renewal reminders before charging.

### 25.3 Taxes

Subscription fees exclude applicable taxes (sales tax, VAT, GST). Taxes are calculated based on your billing address and added at checkout.

### 25.4 Failed Payments

If payment fails, we will notify you and retry using Stripe Smart Retries. You have a 14-day grace period to update your payment method before your subscription may be suspended.

## 26. Cancellation and Refunds

### 26.1 How to Cancel

Cancel your subscription anytime through the Stripe Customer Portal (accessible from DAO billing settings) or by contacting billing@endao.ai.

### 26.2 Effect of Cancellation

Upon cancellation:

- Your subscription remains active until the end of your billing period
- Your DAO is downgraded to Starter, not deleted
- On-chain data, proposals, and treasury remain unaffected

### 26.3 Refund Policy

Subscriptions are generally non-refundable. However, refunds may be provided for:

- Extended service disruptions (more than 48 consecutive hours)
- Billing errors or duplicate charges
- First-time subscribers within 7 days of first paid charge (after trial)

Refunds are not provided for partial months, unused features, or Terms violations.

### 26.4 Refund Requests

Contact billing@endao.ai with your DAO name, reason, and billing period. We respond within 5 business days. Approved refunds are processed within 5-10 business days.

## 27. Fair Use

All plans are subject to fair use. Excessive usage impacting platform performance may result in throttling or upgrade requests. Abuse, including circumventing tier limits or reselling access, may result in account suspension.

## 28. Entire Agreement

These Terms constitute the entire agreement between you and EnDAO regarding the use of the Service, superseding any prior agreements.

## 29. Contact Information

If you have any questions about these Terms, please contact us at:

- **General**: legal@endao.ai
- **Billing**: billing@endao.ai
- **Website**: https://endao.ai

## 30. Acknowledgment

BY USING ENDAO, YOU ACKNOWLEDGE THAT YOU HAVE READ THESE TERMS OF SERVICE, UNDERSTOOD THEM, AND AGREE TO BE BOUND BY THEM.

---

© 2026 EnDAO. All rights reserved.
