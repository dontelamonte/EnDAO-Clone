// @ts-nocheck
import {
  time,
  loadFixture,
} from '@nomicfoundation/hardhat-toolbox-viem/network-helpers';
import { expect } from 'chai';
import hre from 'hardhat';
import { getAddress, parseEther, formatEther } from 'viem';

describe('FeeRouter', function () {
  // Fixture to deploy the contract
  async function deployFeeRouterFixture() {
    // Get accounts
    const [owner, endaoSafe, daoSafe, user1, user2] =
      await hre.viem.getWalletClients();

    // Deploy FeeRouter with endaoSafe as revenue recipient
    const feeRouter = await hre.viem.deployContract('FeeRouter', [
      endaoSafe.account.address,
    ]);

    const publicClient = await hre.viem.getPublicClient();

    return {
      feeRouter,
      owner,
      endaoSafe,
      daoSafe,
      user1,
      user2,
      publicClient,
    };
  }

  describe('Deployment', function () {
    it('Should set the correct EnDAO revenue safe', async function () {
      const { feeRouter, endaoSafe } = await loadFixture(
        deployFeeRouterFixture
      );

      const revenueSafe = await feeRouter.read.endaoRevenueSafe();
      expect(getAddress(revenueSafe)).to.equal(
        getAddress(endaoSafe.account.address)
      );
    });

    it('Should have correct fee percentages', async function () {
      const { feeRouter } = await loadFixture(deployFeeRouterFixture);

      const contributionFee = await feeRouter.read.CONTRIBUTION_FEE();
      const transferFee = await feeRouter.read.TRANSFER_FEE();

      expect(contributionFee).to.equal(500n); // 5%
      expect(transferFee).to.equal(200n); // 2%
    });
  });

  describe('Contributions', function () {
    it('Should route contribution correctly with 5% fee', async function () {
      const { feeRouter, publicClient, endaoSafe, daoSafe, user1 } =
        await loadFixture(deployFeeRouterFixture);

      const contributionAmount = parseEther('100');
      const expectedPlatformFee = parseEther('5'); // 5%
      const expectedDaoAmount = parseEther('95'); // 95%

      // Get initial balances
      const endaoInitialBalance = await publicClient.getBalance({
        address: endaoSafe.account.address,
      });
      const daoInitialBalance = await publicClient.getBalance({
        address: daoSafe.account.address,
      });

      // Make contribution
      await feeRouter.write.routeContribution(
        [daoSafe.account.address, 'contribution-1'],
        { value: contributionAmount, account: user1.account }
      );

      // Check final balances
      const endaoFinalBalance = await publicClient.getBalance({
        address: endaoSafe.account.address,
      });
      const daoFinalBalance = await publicClient.getBalance({
        address: daoSafe.account.address,
      });

      expect(endaoFinalBalance - endaoInitialBalance).to.equal(
        expectedPlatformFee
      );
      expect(daoFinalBalance - daoInitialBalance).to.equal(expectedDaoAmount);
    });

    it('Should emit ContributionRouted event', async function () {
      const { feeRouter, daoSafe, user1 } = await loadFixture(
        deployFeeRouterFixture
      );

      const contributionAmount = parseEther('100');

      // Make contribution and check event
      const hash = await feeRouter.write.routeContribution(
        [daoSafe.account.address, 'contribution-1'],
        { value: contributionAmount, account: user1.account }
      );

      // Note: Event checking with viem is different, you'd typically use publicClient.getLogs
      // This is a simplified version
      expect(hash).to.exist;
    });

    it('Should revert with zero value', async function () {
      const { feeRouter, daoSafe, user1 } = await loadFixture(
        deployFeeRouterFixture
      );

      await expect(
        feeRouter.write.routeContribution(
          [daoSafe.account.address, 'contribution-1'],
          { value: 0n, account: user1.account }
        )
      ).to.be.rejectedWith('No value sent');
    });

    it('Should revert with zero address', async function () {
      const { feeRouter, user1 } = await loadFixture(deployFeeRouterFixture);

      await expect(
        feeRouter.write.routeContribution(
          ['0x0000000000000000000000000000000000000000', 'contribution-1'],
          { value: parseEther('100'), account: user1.account }
        )
      ).to.be.rejectedWith('Invalid DAO safe address');
    });
  });

  describe('Transfers', function () {
    it('Should route transfer correctly with 2% fee', async function () {
      const { feeRouter, publicClient, endaoSafe, user1, user2 } =
        await loadFixture(deployFeeRouterFixture);

      const transferAmount = parseEther('100');
      const expectedPlatformFee = parseEther('2'); // 2%
      const expectedRecipientAmount = parseEther('98'); // 98%

      // Get initial balances
      const endaoInitialBalance = await publicClient.getBalance({
        address: endaoSafe.account.address,
      });
      const recipientInitialBalance = await publicClient.getBalance({
        address: user2.account.address,
      });

      // Make transfer
      await feeRouter.write.routeTransfer(
        [user2.account.address, 'transfer-1'],
        { value: transferAmount, account: user1.account }
      );

      // Check final balances
      const endaoFinalBalance = await publicClient.getBalance({
        address: endaoSafe.account.address,
      });
      const recipientFinalBalance = await publicClient.getBalance({
        address: user2.account.address,
      });

      expect(endaoFinalBalance - endaoInitialBalance).to.equal(
        expectedPlatformFee
      );
      expect(recipientFinalBalance - recipientInitialBalance).to.equal(
        expectedRecipientAmount
      );
    });

    it('Should revert with zero value', async function () {
      const { feeRouter, user1, user2 } = await loadFixture(
        deployFeeRouterFixture
      );

      await expect(
        feeRouter.write.routeTransfer([user2.account.address, 'transfer-1'], {
          value: 0n,
          account: user1.account,
        })
      ).to.be.rejectedWith('No value sent');
    });
  });

  describe('Fee Calculations', function () {
    it('Should calculate contribution fee correctly', async function () {
      const { feeRouter } = await loadFixture(deployFeeRouterFixture);

      const amount = parseEther('1000');
      const fee = await feeRouter.read.calculateContributionFee([amount]);

      expect(fee).to.equal(parseEther('50')); // 5% of 1000
    });

    it('Should calculate transfer fee correctly', async function () {
      const { feeRouter } = await loadFixture(deployFeeRouterFixture);

      const amount = parseEther('1000');
      const fee = await feeRouter.read.calculateTransferFee([amount]);

      expect(fee).to.equal(parseEther('20')); // 2% of 1000
    });

    it('Should calculate net amounts correctly', async function () {
      const { feeRouter } = await loadFixture(deployFeeRouterFixture);

      const amount = parseEther('1000');

      const contributionNet = await feeRouter.read.getContributionNetAmount([
        amount,
      ]);
      expect(contributionNet).to.equal(parseEther('950')); // 95% of 1000

      const transferNet = await feeRouter.read.getTransferNetAmount([amount]);
      expect(transferNet).to.equal(parseEther('980')); // 98% of 1000
    });
  });
});
