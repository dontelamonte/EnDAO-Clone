// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title EnDAO FeeRouter
 * @notice Routes contributions and transfers while collecting platform fees
 * @dev Deployed on Base L2 for low gas costs
 */
contract FeeRouter {
    // Platform fee percentages (basis points for precision)
    uint256 public constant CONTRIBUTION_FEE = 500;  // 5%
    uint256 public constant TRANSFER_FEE = 200;      // 2%
    uint256 private constant BASIS_POINTS = 10000;
    
    // EnDAO revenue Safe address (immutable after deployment)
    address public immutable endaoRevenueSafe;
    
    // Events for tracking
    event ContributionRouted(
        address indexed daoSafe,
        address indexed contributor,
        uint256 totalAmount,
        uint256 platformFee,
        uint256 daoAmount,
        string contributionId
    );
    
    event TransferRouted(
        address indexed from,
        address indexed to,
        uint256 totalAmount,
        uint256 platformFee,
        uint256 netAmount,
        string transferId
    );
    
    /**
     * @dev Constructor sets the EnDAO revenue Safe address
     * @param _endaoRevenueSafe Address of EnDAO's Gnosis Safe for fee collection
     */
    constructor(address _endaoRevenueSafe) {
        require(_endaoRevenueSafe != address(0), "Invalid revenue safe address");
        endaoRevenueSafe = _endaoRevenueSafe;
    }
    
    /**
     * @notice Route a contribution to a DAO, taking 5% platform fee
     * @param daoSafe Address of the DAO's Gnosis Safe
     * @param contributionId Unique identifier for tracking in Firebase
     */
    function routeContribution(
        address daoSafe,
        string calldata contributionId
    ) external payable {
        require(msg.value > 0, "No value sent");
        require(daoSafe != address(0), "Invalid DAO safe address");
        require(bytes(contributionId).length > 0, "Invalid contribution ID");
        
        // Calculate fees
        uint256 platformFee = (msg.value * CONTRIBUTION_FEE) / BASIS_POINTS;
        uint256 daoAmount = msg.value - platformFee;
        
        // Transfer platform fee to EnDAO Safe
        (bool feeSuccess,) = endaoRevenueSafe.call{value: platformFee}("");
        require(feeSuccess, "Platform fee transfer failed");
        
        // Transfer remainder to DAO Safe
        (bool daoSuccess,) = daoSafe.call{value: daoAmount}("");
        require(daoSuccess, "DAO transfer failed");
        
        // Emit event for tracking
        emit ContributionRouted(
            daoSafe,
            msg.sender,
            msg.value,
            platformFee,
            daoAmount,
            contributionId
        );
    }
    
    /**
     * @notice Route a treasury transfer, taking 2% platform fee
     * @param destination Address to send funds to
     * @param transferId Unique identifier for tracking in Firebase
     */
    function routeTransfer(
        address destination,
        string calldata transferId
    ) external payable {
        require(msg.value > 0, "No value sent");
        require(destination != address(0), "Invalid destination address");
        require(bytes(transferId).length > 0, "Invalid transfer ID");
        
        // Calculate fees
        uint256 platformFee = (msg.value * TRANSFER_FEE) / BASIS_POINTS;
        uint256 netAmount = msg.value - platformFee;
        
        // Transfer platform fee to EnDAO Safe
        (bool feeSuccess,) = endaoRevenueSafe.call{value: platformFee}("");
        require(feeSuccess, "Platform fee transfer failed");
        
        // Transfer remainder to destination
        (bool destSuccess,) = destination.call{value: netAmount}("");
        require(destSuccess, "Destination transfer failed");
        
        // Emit event for tracking
        emit TransferRouted(
            msg.sender,
            destination,
            msg.value,
            platformFee,
            netAmount,
            transferId
        );
    }
    
    /**
     * @notice Calculate contribution fee for a given amount
     * @param amount The contribution amount
     * @return fee The platform fee amount
     */
    function calculateContributionFee(uint256 amount) external pure returns (uint256 fee) {
        fee = (amount * CONTRIBUTION_FEE) / BASIS_POINTS;
    }
    
    /**
     * @notice Calculate transfer fee for a given amount
     * @param amount The transfer amount  
     * @return fee The platform fee amount
     */
    function calculateTransferFee(uint256 amount) external pure returns (uint256 fee) {
        fee = (amount * TRANSFER_FEE) / BASIS_POINTS;
    }
    
    /**
     * @notice Get the net amount after contribution fee
     * @param amount The contribution amount
     * @return netAmount Amount DAO will receive
     */
    function getContributionNetAmount(uint256 amount) external pure returns (uint256 netAmount) {
        uint256 fee = (amount * CONTRIBUTION_FEE) / BASIS_POINTS;
        netAmount = amount - fee;
    }
    
    /**
     * @notice Get the net amount after transfer fee
     * @param amount The transfer amount
     * @return netAmount Amount recipient will receive
     */
    function getTransferNetAmount(uint256 amount) external pure returns (uint256 netAmount) {
        uint256 fee = (amount * TRANSFER_FEE) / BASIS_POINTS;
        netAmount = amount - fee;
    }
}