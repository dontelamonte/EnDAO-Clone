#!/usr/bin/env node
/**
 * Generate placeholder assets for EAS builds
 *
 * These are temporary placeholder images using EnDAO branding colors.
 * Replace with professional assets before production release.
 *
 * Usage: node scripts/generate-assets.js
 * Requires: sharp (npm install -D sharp)
 */

const fs = require('fs')
const path = require('path')

async function generateAssets() {
  let sharp
  try {
    sharp = require('sharp')
  } catch {
    console.error('Error: sharp is not installed.')
    console.error('Run: pnpm add -D sharp')
    process.exit(1)
  }

  const assetsDir = path.join(__dirname, '..', 'assets')

  // Ensure assets directory exists
  if (!fs.existsSync(assetsDir)) {
    fs.mkdirSync(assetsDir, { recursive: true })
  }

  // EnDAO branding colors
  const darkSlate = '#0f172a'
  const lightText = '#e2e8f0'
  const accentBlue = '#3b82f6'

  const assets = [
    {
      name: 'icon.png',
      width: 1024,
      height: 1024,
      background: darkSlate,
      text: 'E',
      textSize: 600,
    },
    {
      name: 'adaptive-icon.png',
      width: 1024,
      height: 1024,
      background: darkSlate,
      text: 'E',
      textSize: 500,
    },
    {
      name: 'splash.png',
      width: 1284,
      height: 2778,
      background: darkSlate,
      text: 'EnDAO',
      textSize: 200,
    },
    {
      name: 'favicon.png',
      width: 48,
      height: 48,
      background: darkSlate,
      text: 'E',
      textSize: 32,
    },
    {
      name: 'notification-icon.png',
      width: 96,
      height: 96,
      background: 'transparent',
      text: 'E',
      textSize: 64,
      isNotificationIcon: true,
    },
  ]

  console.log('Generating placeholder assets...\n')

  for (const asset of assets) {
    const filepath = path.join(assetsDir, asset.name)

    // Create SVG with text centered
    const svg = createSvg(asset)

    try {
      await sharp(Buffer.from(svg))
        .png()
        .toFile(filepath)

      console.log(`  ✓ ${asset.name} (${asset.width}x${asset.height})`)
    } catch (err) {
      console.error(`  ✗ ${asset.name}: ${err.message}`)
    }
  }

  console.log('\nPlaceholder assets generated!')
  console.log('Replace these with professional assets before production release.')
}

function createSvg(asset) {
  const { width, height, background, text, textSize, isNotificationIcon } = asset

  // Notification icons must be white on transparent for Android
  const textColor = isNotificationIcon ? '#ffffff' : '#e2e8f0'
  const bgColor = isNotificationIcon ? 'none' : background

  return `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="${bgColor}"/>
      <text
        x="50%"
        y="50%"
        font-family="Arial, Helvetica, sans-serif"
        font-size="${textSize}"
        font-weight="bold"
        fill="${textColor}"
        text-anchor="middle"
        dominant-baseline="central"
      >${text}</text>
    </svg>
  `.trim()
}

generateAssets().catch(console.error)
