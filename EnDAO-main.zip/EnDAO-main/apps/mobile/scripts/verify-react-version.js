#!/usr/bin/env node
/**
 * EAS Build Post-Install Script
 * Verifies React 18 is being used for React Native compatibility
 * and fixes the installation if React 19 was hoisted incorrectly.
 */

const fs = require('fs')
const path = require('path')
const { execSync } = require('child_process')

const REQUIRED_REACT_MAJOR = 18
const projectRoot = path.resolve(__dirname, '..')
const workspaceRoot = path.resolve(projectRoot, '../..')

// Paths to check for React
const mobileNodeModules = path.join(projectRoot, 'node_modules')
const rootNodeModules = path.join(workspaceRoot, 'node_modules')

function getReactVersion(nodeModulesPath) {
  const reactPkgPath = path.join(nodeModulesPath, 'react', 'package.json')
  if (fs.existsSync(reactPkgPath)) {
    const pkg = JSON.parse(fs.readFileSync(reactPkgPath, 'utf8'))
    return pkg.version
  }
  return null
}

function getMajorVersion(version) {
  if (!version) return null
  return parseInt(version.split('.')[0], 10)
}

console.log('=== React Version Verification ===')
console.log('Project root:', projectRoot)
console.log('Workspace root:', workspaceRoot)

const mobileReactVersion = getReactVersion(mobileNodeModules)
const rootReactVersion = getReactVersion(rootNodeModules)

console.log('Mobile node_modules React version:', mobileReactVersion || 'NOT FOUND')
console.log('Root node_modules React version:', rootReactVersion || 'NOT FOUND')

const effectiveVersion = mobileReactVersion || rootReactVersion
const majorVersion = getMajorVersion(effectiveVersion)

console.log('Effective React version:', effectiveVersion)
console.log('Major version:', majorVersion)

if (majorVersion !== REQUIRED_REACT_MAJOR) {
  console.log(`\n⚠️  WARNING: React ${majorVersion} detected, but React ${REQUIRED_REACT_MAJOR} is required for React Native!`)
  console.log('Attempting to fix...')

  // Check if mobile's node_modules has React 18
  if (mobileReactVersion && getMajorVersion(mobileReactVersion) === REQUIRED_REACT_MAJOR) {
    console.log('✅ Mobile node_modules has correct React version')
  } else {
    // Try to install React 18 specifically in mobile's node_modules
    console.log('Installing React 18 in mobile workspace...')
    try {
      // Create a symbolic link or copy React 18 to ensure it's used
      execSync('pnpm add react@18.3.1 --save-exact', {
        cwd: projectRoot,
        stdio: 'inherit'
      })
      console.log('✅ React 18 installed successfully')
    } catch (error) {
      console.error('❌ Failed to install React 18:', error.message)
      process.exit(1)
    }
  }
} else {
  console.log(`\n✅ React ${majorVersion} is correctly installed`)
}

// Verify react-native peer dependency compatibility
const rnPkgPath = path.join(rootNodeModules, 'react-native', 'package.json')
if (fs.existsSync(rnPkgPath)) {
  const rnPkg = JSON.parse(fs.readFileSync(rnPkgPath, 'utf8'))
  const reactPeerDep = rnPkg.peerDependencies?.react
  console.log(`\nReact Native ${rnPkg.version} requires React: ${reactPeerDep}`)

  if (reactPeerDep && effectiveVersion) {
    // Simple check - just verify major version matches
    const peerMajor = getMajorVersion(reactPeerDep.replace('^', '').replace('~', ''))
    if (peerMajor !== majorVersion) {
      console.log(`⚠️  Version mismatch detected: have ${majorVersion}, need ${peerMajor}`)
    } else {
      console.log('✅ React version compatible with React Native')
    }
  }
}

console.log('\n=== Verification Complete ===')
