import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { PrivyProvider } from '../src/contexts/PrivyProvider';
import { useNotifications } from '../src/hooks/useNotifications';
import { initNetworkMonitor } from '../src/services/network';

/**
 * NotificationInitializer Component
 *
 * Initializes push notification system by calling useNotifications hook.
 * This component doesn't render anything, it just sets up the notification listeners.
 */
function NotificationInitializer() {
  useNotifications();
  return null;
}

export default function RootLayout() {
  // Initialize network monitor on mount
  useEffect(() => {
    initNetworkMonitor();
  }, []);

  return (
    <PrivyProvider>
      <StatusBar style="light" />
      <NotificationInitializer />
      <Stack
        screenOptions={{
          headerStyle: {
            backgroundColor: '#0f172a', // Slate-900
          },
          headerTintColor: '#f8fafc', // Slate-50
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          contentStyle: {
            backgroundColor: '#0f172a',
          },
        }}
      >
        <Stack.Screen
          name="index"
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="(auth)"
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="(tabs)"
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="dao/[id]"
          options={{
            headerShown: true,
          }}
        />
        <Stack.Screen
          name="proposal/[id]"
          options={{
            headerShown: true,
            title: 'Proposal',
          }}
        />
      </Stack>
    </PrivyProvider>
  );
}
