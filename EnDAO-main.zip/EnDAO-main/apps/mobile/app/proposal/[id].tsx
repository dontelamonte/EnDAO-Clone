/**
 * Proposal Detail Screen
 *
 * Displays proposal details with voting interface and signature support.
 */

import { useState, useCallback } from 'react';
import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  Alert,
} from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { useProposal } from '../../src/hooks/useProposal';
import { useSignedVote } from '../../src/hooks/useSignedVote';
import { LoadingState, ErrorState } from '../../src/components/common';
import {
  VoteButtons,
  VoteChoice,
  VoteResults,
  VoteConfirmation,
  SignedBadge,
} from '../../src/components/voting';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
} from '../../src/constants/theme';

function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case 'active':
    case 'open':
      return colors.proposal.active;
    case 'pending':
    case 'pending_approval':
      return colors.proposal.pending;
    case 'passed':
    case 'approved':
      return colors.proposal.passed;
    case 'rejected':
    case 'failed':
      return colors.proposal.rejected;
    case 'executed':
      return colors.proposal.executed;
    default:
      return colors.text.muted;
  }
}

function formatDate(dateString?: string): string {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

export default function ProposalDetailScreen() {
  const { id: proposalId } = useLocalSearchParams<{ id: string }>();
  const { proposal, voteEligibility, isLoading, error, refetch } =
    useProposal(proposalId);
  const { signVote, submitSignedVote, isSigningVote, signError, hasWallet } =
    useSignedVote();

  const [selectedChoice, setSelectedChoice] = useState<VoteChoice | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const handleVoteSelect = useCallback((choice: VoteChoice) => {
    setSelectedChoice(choice);
  }, []);

  const handleSubmitVote = useCallback(() => {
    if (!selectedChoice) return;
    setShowConfirmation(true);
  }, [selectedChoice]);

  const handleConfirmVote = useCallback(async () => {
    if (!selectedChoice || !proposal) return;

    setIsSubmitting(true);

    // Sign the vote
    const signedVote = await signVote(
      proposal.id,
      proposal.daoId,
      selectedChoice,
      1 // Default strength for now
    );

    if (!signedVote) {
      setIsSubmitting(false);
      Alert.alert(
        'Signing Failed',
        signError || 'Could not sign your vote. Please try again.'
      );
      return;
    }

    // Submit the signed vote
    const result = await submitSignedVote(proposal.id, signedVote);

    setIsSubmitting(false);
    setShowConfirmation(false);

    if (result.success) {
      Alert.alert(
        'Vote Submitted!',
        'Your vote has been cryptographically signed and recorded.',
        [{ text: 'OK', onPress: () => refetch() }]
      );
      setSelectedChoice(null);
    } else {
      Alert.alert(
        'Submission Failed',
        result.error || 'Could not submit your vote. Please try again.'
      );
    }
  }, [
    selectedChoice,
    proposal,
    signVote,
    submitSignedVote,
    signError,
    refetch,
  ]);

  const handleCancelConfirmation = useCallback(() => {
    setShowConfirmation(false);
  }, []);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Loading...' }} />
        <LoadingState message="Loading proposal..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Error' }} />
        <ErrorState message={error} onRetry={refetch} />
      </>
    );
  }

  if (!proposal) {
    return (
      <>
        <Stack.Screen options={{ title: 'Not Found' }} />
        <ErrorState message="Proposal not found" onRetry={refetch} />
      </>
    );
  }

  const statusColor = getStatusColor(proposal.status);
  const isVotingOpen = ['active', 'open'].includes(
    proposal.status.toLowerCase()
  );
  const hasAlreadyVoted = voteEligibility?.hasVoted;
  const canVoteNow = voteEligibility?.canVote && isVotingOpen;

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Proposal',
          headerBackTitle: 'Back',
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary.default}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <View
            style={[
              styles.statusBadge,
              { backgroundColor: statusColor + '20' },
            ]}
          >
            <Text style={[styles.statusText, { color: statusColor }]}>
              {proposal.status}
            </Text>
          </View>
          {proposal.votingType && (
            <Text style={styles.votingType}>{proposal.votingType}</Text>
          )}
        </View>

        {/* Title */}
        <Text style={styles.title}>{proposal.title}</Text>

        {/* Dates */}
        <View style={styles.datesContainer}>
          {proposal.votingStartTime && (
            <Text style={styles.dateText}>
              Starts: {formatDate(proposal.votingStartTime)}
            </Text>
          )}
          {proposal.votingEndTime && (
            <Text style={styles.dateText}>
              Ends: {formatDate(proposal.votingEndTime)}
            </Text>
          )}
        </View>

        {/* Description */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Description</Text>
          <Text style={styles.description}>{proposal.description}</Text>
        </View>

        {/* Results */}
        {proposal.results && (
          <View style={styles.section}>
            <VoteResults
              forVotes={proposal.results.for}
              againstVotes={proposal.results.against}
              abstainVotes={proposal.results.abstain}
              quorumReached={proposal.results.quorumReached}
              thresholdMet={proposal.results.thresholdMet}
            />
          </View>
        )}

        {/* User's Current Vote (if voted) */}
        {hasAlreadyVoted && voteEligibility?.currentVote && (
          <View style={styles.section}>
            <View style={styles.yourVoteContainer}>
              <View style={styles.yourVoteHeader}>
                <Text style={styles.yourVoteTitle}>Your Vote</Text>
                {voteEligibility.currentVote.isSigned && <SignedBadge />}
              </View>
              <Text style={styles.yourVoteChoice}>
                You voted: {voteEligibility.currentVote.choice.toUpperCase()}
              </Text>
            </View>
          </View>
        )}

        {/* Voting Section */}
        {isVotingOpen && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              {hasAlreadyVoted ? 'Change Your Vote' : 'Cast Your Vote'}
            </Text>

            {canVoteNow ? (
              <>
                <VoteButtons
                  selectedChoice={selectedChoice}
                  onSelect={handleVoteSelect}
                  disabled={isSubmitting || isSigningVote}
                />

                {!hasWallet && (
                  <View style={styles.warningContainer}>
                    <Text style={styles.warningText}>
                      Wallet not connected. Your vote will not be
                      cryptographically signed.
                    </Text>
                  </View>
                )}

                {selectedChoice && (
                  <TouchableOpacity
                    style={styles.submitButton}
                    onPress={handleSubmitVote}
                    disabled={isSubmitting || isSigningVote}
                  >
                    <Text style={styles.submitButtonText}>
                      {hasWallet ? 'Sign & Submit Vote' : 'Submit Vote'}
                    </Text>
                  </TouchableOpacity>
                )}
              </>
            ) : (
              <View style={styles.ineligibleContainer}>
                <Text style={styles.ineligibleText}>
                  {voteEligibility?.reason ||
                    'You are not eligible to vote on this proposal.'}
                </Text>
              </View>
            )}
          </View>
        )}

        {/* Voting Closed Message */}
        {!isVotingOpen && (
          <View style={styles.section}>
            <View style={styles.closedContainer}>
              <Text style={styles.closedText}>
                Voting on this proposal has ended.
              </Text>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Vote Confirmation Modal */}
      <VoteConfirmation
        visible={showConfirmation}
        choice={selectedChoice}
        isSubmitting={isSubmitting}
        isSigning={isSigningVote}
        onConfirm={handleConfirmVote}
        onCancel={handleCancelConfirmation}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    paddingBottom: spacing.xxl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    gap: spacing.md,
  },
  statusBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  statusText: {
    fontSize: fontSize.xs,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  votingType: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
  title: {
    fontSize: fontSize.xxl,
    fontWeight: '700',
    color: colors.text.primary,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  datesContainer: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  dateText: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
  },
  section: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: spacing.md,
  },
  description: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    lineHeight: 24,
  },
  yourVoteContainer: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
  },
  yourVoteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  yourVoteTitle: {
    fontSize: fontSize.md,
    fontWeight: '600',
    color: colors.text.primary,
  },
  yourVoteChoice: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  submitButton: {
    backgroundColor: colors.primary.default,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    marginTop: spacing.xl,
  },
  submitButtonText: {
    color: colors.text.primary,
    fontSize: fontSize.lg,
    fontWeight: '600',
  },
  warningContainer: {
    backgroundColor: colors.status.warning + '20',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  warningText: {
    fontSize: fontSize.sm,
    color: colors.status.warning,
    textAlign: 'center',
  },
  ineligibleContainer: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
  },
  ineligibleText: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  closedContainer: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
  },
  closedText: {
    fontSize: fontSize.md,
    color: colors.text.muted,
    textAlign: 'center',
  },
});
