/**
 * Proposal List Screen
 *
 * Displays list of proposals for a DAO with status filtering.
 */

import {
  View,
  FlatList,
  TouchableOpacity,
  Text,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useCallback } from 'react';
import { useProposals, ProposalStatus } from '../../../src/hooks/useProposals';
import {
  LoadingState,
  ErrorState,
  EmptyState,
} from '../../../src/components/common';
import { ProposalCard } from '../../../src/components/voting/ProposalCard';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
} from '../../../src/constants/theme';

const FILTER_OPTIONS: { label: string; value: ProposalStatus }[] = [
  { label: 'All', value: 'all' },
  { label: 'Active', value: 'active' },
  { label: 'Passed', value: 'passed' },
  { label: 'Rejected', value: 'rejected' },
];

export default function ProposalListScreen() {
  const { id: daoId } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const {
    proposals,
    isLoading,
    isRefreshing,
    error,
    refetch,
    statusFilter,
    setStatusFilter,
  } = useProposals(daoId);

  const handleProposalPress = useCallback(
    (proposalId: string) => {
      router.push(`/proposal/${proposalId}`);
    },
    [router]
  );

  const handleRefresh = useCallback(() => {
    refetch(true);
  }, [refetch]);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Proposals' }} />
        <LoadingState message="Loading proposals..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Proposals' }} />
        <ErrorState message={error} onRetry={() => refetch()} />
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Proposals',
          headerBackTitle: 'DAO',
        }}
      />
      <View style={styles.container}>
        {/* Filter Tabs */}
        <View style={styles.filterContainer}>
          {FILTER_OPTIONS.map((option) => (
            <TouchableOpacity
              key={option.value}
              style={[
                styles.filterTab,
                statusFilter === option.value && styles.filterTabActive,
              ]}
              onPress={() => setStatusFilter(option.value)}
            >
              <Text
                style={[
                  styles.filterText,
                  statusFilter === option.value && styles.filterTextActive,
                ]}
              >
                {option.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Proposals List */}
        <FlatList
          data={proposals}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ProposalCard
              id={item.id}
              title={item.title}
              status={item.status}
              description={item.description}
              votingEndTime={item.votingEndTime}
              onPress={() => handleProposalPress(item.id)}
            />
          )}
          ListEmptyComponent={
            <EmptyState
              icon="📋"
              title="No Proposals"
              description={
                statusFilter === 'all'
                  ? 'This DAO has no proposals yet.'
                  : `No ${statusFilter} proposals found.`
              }
            />
          }
          contentContainerStyle={
            proposals.length === 0 ? styles.emptyList : styles.list
          }
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={handleRefresh}
              tintColor={colors.primary.default}
            />
          }
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  filterTab: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    marginRight: spacing.sm,
    borderRadius: borderRadius.full,
    backgroundColor: colors.background.secondary,
  },
  filterTabActive: {
    backgroundColor: colors.primary.default,
  },
  filterText: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    fontWeight: '500',
  },
  filterTextActive: {
    color: colors.text.primary,
  },
  list: {
    padding: spacing.lg,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
});
