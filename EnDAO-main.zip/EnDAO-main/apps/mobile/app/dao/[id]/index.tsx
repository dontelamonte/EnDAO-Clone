/**
 * DAO Detail Screen
 *
 * Displays DAO information, stats, and navigation to proposals.
 */

import {
  View,
  ScrollView,
  TouchableOpacity,
  Text,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useState, useCallback } from 'react';
import { useDAO } from '../../../src/hooks/useDAO';
import { LoadingState, ErrorState } from '../../../src/components/common';
import { DAOHeader, StatBadge } from '../../../src/components/dao';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
} from '../../../src/constants/theme';

export default function DAODetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { dao, stats, isLoading, error, refetch } = useDAO(id);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const navigateToProposals = useCallback(() => {
    router.push(`/dao/${id}/proposals`);
  }, [router, id]);

  const navigateToTreasury = useCallback(() => {
    router.push(`/dao/${id}/treasury`);
  }, [router, id]);

  const navigateToMembers = useCallback(() => {
    router.push(`/dao/${id}/members`);
  }, [router, id]);

  const navigateToAdmin = useCallback(() => {
    router.push(`/dao/${id}/admin`);
  }, [router, id]);

  const navigateToActivity = useCallback(() => {
    router.push(`/dao/${id}/activity`);
  }, [router, id]);

  const navigateToSettings = useCallback(() => {
    router.push(`/dao/${id}/settings`);
  }, [router, id]);

  // Check if user is admin
  const isAdmin = dao?.userRole === 'admin' || dao?.userRole === 'owner';

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Loading...' }} />
        <LoadingState message="Loading DAO details..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Error' }} />
        <ErrorState message={error} onRetry={refetch} />
      </>
    );
  }

  if (!dao) {
    return (
      <>
        <Stack.Screen options={{ title: 'Not Found' }} />
        <ErrorState message="DAO not found" onRetry={refetch} />
      </>
    );
  }

  const participationPercent = stats?.participationRate
    ? `${Math.round(stats.participationRate * 100)}%`
    : '0%';

  return (
    <>
      <Stack.Screen
        options={{
          title: dao.name,
          headerBackTitle: 'Back',
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary.default}
          />
        }
      >
        {/* DAO Header */}
        <DAOHeader
          name={dao.name}
          description={dao.description}
          slug={dao.slug}
          logoUrl={dao.logoUrl}
        />

        {/* Stats Row */}
        {stats && (
          <View style={styles.statsContainer}>
            <StatBadge label="Members" value={stats.memberCount} icon="👥" />
            <StatBadge
              label="Proposals"
              value={stats.proposalCount}
              icon="📋"
            />
            <StatBadge
              label="Active"
              value={stats.activeProposalCount}
              icon="🗳️"
            />
            <StatBadge
              label="Participation"
              value={participationPercent}
              icon="📊"
            />
          </View>
        )}

        {/* Actions */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={navigateToProposals}
          >
            <Text style={styles.primaryButtonText}>View Proposals</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={navigateToTreasury}
          >
            <Text style={styles.secondaryButtonText}>View Treasury</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={navigateToMembers}
          >
            <Text style={styles.secondaryButtonText}>View Members</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={navigateToActivity}
          >
            <Text style={styles.secondaryButtonText}>Activity</Text>
          </TouchableOpacity>

          {isAdmin && (
            <TouchableOpacity
              style={styles.secondaryButton}
              onPress={navigateToSettings}
            >
              <Text style={styles.secondaryButtonText}>Settings</Text>
            </TouchableOpacity>
          )}

          {isAdmin && (
            <TouchableOpacity
              style={styles.adminButton}
              onPress={navigateToAdmin}
            >
              <Text style={styles.adminButtonText}>👑 Admin Dashboard</Text>
            </TouchableOpacity>
          )}

          {stats && stats.activeProposalCount > 0 && (
            <View style={styles.activeProposalsBadge}>
              <Text style={styles.activeProposalsText}>
                {stats.activeProposalCount} active proposal
                {stats.activeProposalCount !== 1 ? 's' : ''} awaiting your vote
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    paddingBottom: spacing.xxl,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.lg,
  },
  actionsContainer: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  primaryButton: {
    backgroundColor: colors.primary.default,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: colors.text.primary,
    fontSize: fontSize.lg,
    fontWeight: '600',
  },
  secondaryButton: {
    backgroundColor: colors.background.tertiary,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    marginTop: spacing.md,
    borderWidth: 1,
    borderColor: colors.border.subtle,
  },
  secondaryButtonText: {
    color: colors.text.primary,
    fontSize: fontSize.lg,
    fontWeight: '600',
  },
  adminButton: {
    backgroundColor: colors.primary.default,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    marginTop: spacing.md,
    borderWidth: 2,
    borderColor: colors.primary.light,
  },
  adminButtonText: {
    color: colors.text.primary,
    fontSize: fontSize.lg,
    fontWeight: '700',
  },
  activeProposalsBadge: {
    marginTop: spacing.lg,
    backgroundColor: colors.proposal.active + '20', // 20% opacity
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.proposal.active,
  },
  activeProposalsText: {
    color: colors.proposal.active,
    fontSize: fontSize.sm,
    textAlign: 'center',
  },
});
