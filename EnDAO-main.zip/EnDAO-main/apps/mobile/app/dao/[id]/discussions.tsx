/**
 * Discussion List Screen
 *
 * Displays list of discussions for a DAO with status filtering.
 */

import {
  View,
  FlatList,
  TouchableOpacity,
  Text,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useCallback } from 'react';
import {
  useDiscussions,
  DiscussionStatus,
} from '../../../src/hooks/useDiscussions';
import {
  LoadingState,
  ErrorState,
  EmptyState,
} from '../../../src/components/common';
import { DiscussionCard } from '../../../src/components/discussions';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
} from '../../../src/constants/theme';

const FILTER_OPTIONS: { label: string; value: DiscussionStatus }[] = [
  { label: 'All', value: 'all' },
  { label: 'Active', value: 'active' },
  { label: 'Archived', value: 'archived' },
];

export default function DiscussionListScreen() {
  const { id: daoId } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const {
    discussions,
    isLoading,
    isRefreshing,
    error,
    refetch,
    statusFilter,
    setStatusFilter,
  } = useDiscussions(daoId);

  const handleDiscussionPress = useCallback(
    (discussionId: string) => {
      router.push(`/discussion/${discussionId}`);
    },
    [router]
  );

  const handleRefresh = useCallback(() => {
    refetch(true);
  }, [refetch]);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Discussions' }} />
        <LoadingState message="Loading discussions..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Discussions' }} />
        <ErrorState message={error} onRetry={() => refetch()} />
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Discussions',
          headerBackTitle: 'DAO',
        }}
      />
      <View style={styles.container}>
        {/* Filter Tabs */}
        <View style={styles.filterContainer}>
          {FILTER_OPTIONS.map((option) => (
            <TouchableOpacity
              key={option.value}
              style={[
                styles.filterTab,
                statusFilter === option.value && styles.filterTabActive,
              ]}
              onPress={() => setStatusFilter(option.value)}
            >
              <Text
                style={[
                  styles.filterText,
                  statusFilter === option.value && styles.filterTextActive,
                ]}
              >
                {option.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Discussions List */}
        <FlatList
          data={discussions}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <DiscussionCard
              id={item.id}
              title={item.title}
              authorName={item.authorName}
              commentCount={item.commentCount}
              createdAt={item.createdAt}
              isPinned={item.isPinned}
              onPress={() => handleDiscussionPress(item.id)}
            />
          )}
          ListEmptyComponent={
            <EmptyState
              icon="💬"
              title="No Discussions"
              description={
                statusFilter === 'all'
                  ? 'This DAO has no discussions yet.'
                  : `No ${statusFilter} discussions found.`
              }
            />
          }
          contentContainerStyle={
            discussions.length === 0 ? styles.emptyList : styles.list
          }
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={handleRefresh}
              tintColor={colors.primary.default}
            />
          }
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  filterTab: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    marginRight: spacing.sm,
    borderRadius: borderRadius.full,
    backgroundColor: colors.background.secondary,
  },
  filterTabActive: {
    backgroundColor: colors.primary.default,
  },
  filterText: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    fontWeight: '500',
  },
  filterTextActive: {
    color: colors.text.primary,
  },
  list: {
    padding: spacing.lg,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
});
