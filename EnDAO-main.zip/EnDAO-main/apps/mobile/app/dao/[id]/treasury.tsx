/**
 * Treasury Screen
 *
 * Displays treasury overview, token balances, and transaction history.
 */

import {
  View,
  FlatList,
  Text,
  StyleSheet,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { useState, useCallback } from 'react';
import { useTreasury } from '../../../src/hooks/useTreasury';
import { usePendingExecutions } from '../../../src/hooks/usePendingExecutions';
import { LoadingState, ErrorState, EmptyState } from '../../../src/components/common';
import {
  TreasuryHeader,
  TokenBalanceCard,
  TransactionItem,
} from '../../../src/components/treasury';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../../src/constants/theme';

export default function TreasuryScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const {
    treasury,
    transactions,
    isLoading,
    error,
    refetch,
    loadMoreTransactions,
    hasMore,
    isLoadingMore,
  } = useTreasury(id);
  const { executions, isOwner } = usePendingExecutions(id);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const handleLoadMore = useCallback(() => {
    if (!isLoadingMore && hasMore) {
      loadMoreTransactions();
    }
  }, [isLoadingMore, hasMore, loadMoreTransactions]);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Treasury' }} />
        <LoadingState message="Loading treasury..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Treasury' }} />
        <ErrorState message={error} onRetry={refetch} />
      </>
    );
  }

  if (!treasury) {
    return (
      <>
        <Stack.Screen options={{ title: 'Treasury' }} />
        <ErrorState message="Treasury not found" onRetry={refetch} />
      </>
    );
  }

  const renderHeader = () => (
    <>
      <TreasuryHeader treasury={treasury} />

      {/* Pending Signatures Button */}
      {treasury.isConfigured && isOwner && executions.length > 0 && (
        <TouchableOpacity
          style={styles.pendingButton}
          onPress={() => router.push(`/dao/${id}/treasury/pending`)}
          activeOpacity={0.7}
        >
          <View style={styles.pendingButtonContent}>
            <Text style={styles.pendingButtonText}>
              📝 {executions.length} Pending Signature
              {executions.length !== 1 ? 's' : ''}
            </Text>
            <Text style={styles.pendingButtonSubtext}>
              Tap to review and sign
            </Text>
          </View>
        </TouchableOpacity>
      )}

      {treasury.isConfigured && treasury.tokens.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tokens</Text>
          {treasury.tokens.map((token) => (
            <TokenBalanceCard key={token.symbol} token={token} />
          ))}
        </View>
      )}

      {treasury.isConfigured && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Transactions</Text>
        </View>
      )}
    </>
  );

  const renderEmptyTransactions = () => {
    if (!treasury.isConfigured) {
      return null;
    }

    return (
      <View style={styles.emptyContainer}>
        <EmptyState
          icon="📭"
          title="No Transactions"
          description="This treasury hasn't received or sent any funds yet."
        />
      </View>
    );
  };

  const renderFooter = () => {
    if (!hasMore) {
      return null;
    }

    if (isLoadingMore) {
      return (
        <View style={styles.loadingMoreContainer}>
          <ActivityIndicator size="small" color={colors.primary.default} />
          <Text style={styles.loadingMoreText}>Loading more...</Text>
        </View>
      );
    }

    return (
      <TouchableOpacity
        style={styles.loadMoreButton}
        onPress={handleLoadMore}
        activeOpacity={0.7}
      >
        <Text style={styles.loadMoreText}>Load More</Text>
      </TouchableOpacity>
    );
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Treasury',
          headerBackTitle: 'Back',
        }}
      />
      <FlatList
        style={styles.container}
        data={transactions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <TransactionItem transaction={item} />}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmptyTransactions}
        ListFooterComponent={renderFooter}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary.default}
          />
        }
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  contentContainer: {
    paddingBottom: spacing.xxl,
  },
  section: {
    padding: spacing.lg,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.md,
  },
  emptyContainer: {
    paddingVertical: spacing.xxl,
  },
  loadingMoreContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.lg,
  },
  loadingMoreText: {
    marginLeft: spacing.sm,
    fontSize: fontSize.sm,
    color: colors.text.secondary,
  },
  loadMoreButton: {
    backgroundColor: colors.background.secondary,
    marginHorizontal: spacing.lg,
    marginVertical: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  loadMoreText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.medium,
    color: colors.primary.default,
  },
  pendingButton: {
    backgroundColor: colors.status.warning + '33', // 20% opacity
    marginHorizontal: spacing.lg,
    marginVertical: spacing.md,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.lg,
    borderWidth: 1,
    borderColor: colors.status.warning,
  },
  pendingButtonContent: {
    alignItems: 'center',
  },
  pendingButtonText: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.xs,
  },
  pendingButtonSubtext: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
  },
});
