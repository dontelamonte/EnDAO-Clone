/**
 * Admin Dashboard Screen
 *
 * Displays admin-specific stats and quick actions for DAO management.
 * Only accessible to admin/owner users.
 */

import {
  View,
  ScrollView,
  Text,
  StyleSheet,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useState, useCallback } from 'react';
import { useDAO } from '../../../src/hooks/useDAO';
import { useAdminStats } from '../../../src/hooks/useAdminStats';
import {
  LoadingState,
  ErrorState,
} from '../../../src/components/common';
import { StatCard } from '../../../src/components/admin';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
  fontWeight,
} from '../../../src/constants/theme';

export default function AdminDashboardScreen() {
  const { id: daoId } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { dao, isLoading: isDaoLoading, error: daoError } = useDAO(daoId);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Check if user is admin
  const isAdmin =
    dao?.userRole === 'admin' || dao?.userRole === 'owner';

  // Fetch admin stats
  const {
    stats,
    isLoading: isStatsLoading,
    error: statsError,
    refetch,
  } = useAdminStats(daoId, isAdmin);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const navigateToMembers = useCallback(() => {
    router.push(`/dao/${daoId}/members`);
  }, [router, daoId]);

  const navigateToProposals = useCallback(() => {
    router.push(`/dao/${daoId}/proposals`);
  }, [router, daoId]);

  const navigateToTreasury = useCallback(() => {
    router.push(`/dao/${daoId}/treasury`);
  }, [router, daoId]);

  // Loading state
  if (isDaoLoading || (isStatsLoading && !isRefreshing)) {
    return (
      <>
        <Stack.Screen options={{ title: 'Admin Dashboard' }} />
        <LoadingState message="Loading admin dashboard..." />
      </>
    );
  }

  // Error state
  if (daoError || statsError) {
    return (
      <>
        <Stack.Screen options={{ title: 'Admin Dashboard' }} />
        <ErrorState
          message={daoError || statsError || 'Failed to load dashboard'}
          onRetry={refetch}
        />
      </>
    );
  }

  // Not an admin
  if (!isAdmin) {
    return (
      <>
        <Stack.Screen options={{ title: 'Admin Dashboard' }} />
        <ErrorState
          message="You must be an admin to access this page"
          onRetry={() => router.back()}
        />
      </>
    );
  }

  // Format treasury balance
  const formatBalance = (balance: string | null): string => {
    if (!balance) return 'Not configured';
    const num = parseFloat(balance);
    if (isNaN(num)) return 'Not configured';
    return `$${num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Admin Dashboard',
          headerBackTitle: 'DAO',
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary.default}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>{dao?.name}</Text>
          <Text style={styles.headerSubtitle}>Admin Dashboard</Text>
        </View>

        {/* Stats Grid */}
        {stats && (
          <>
            <Text style={styles.sectionTitle}>Overview</Text>
            <View style={styles.statsGrid}>
              <StatCard
                icon="👥"
                label="Total Members"
                value={stats.memberCount}
              />
              <StatCard
                icon="👑"
                label="Admins"
                value={stats.adminCount}
                variant="info"
              />
            </View>

            <View style={styles.statsGrid}>
              <StatCard
                icon="📋"
                label="Total Proposals"
                value={stats.proposalCount}
              />
              <StatCard
                icon="🗳️"
                label="Active Proposals"
                value={stats.activeProposalCount}
                variant="warning"
              />
            </View>

            <View style={styles.statsGrid}>
              <StatCard
                icon="✅"
                label="Passed Proposals"
                value={stats.passedProposalCount}
                variant="success"
              />
              <StatCard
                icon="📈"
                label="New Members (7d)"
                value={stats.recentMemberJoins}
                variant="success"
              />
            </View>

            {/* Treasury Balance */}
            {stats.treasuryBalance && (
              <View style={styles.treasuryCard}>
                <Text style={styles.treasuryLabel}>Treasury Balance</Text>
                <Text style={styles.treasuryValue}>
                  {formatBalance(stats.treasuryBalance)}
                </Text>
              </View>
            )}
          </>
        )}

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={navigateToMembers}
          >
            <Text style={styles.actionIcon}>👥</Text>
            <Text style={styles.actionText}>Manage Members</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionButton}
            onPress={navigateToProposals}
          >
            <Text style={styles.actionIcon}>📋</Text>
            <Text style={styles.actionText}>View Proposals</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionButton}
            onPress={navigateToTreasury}
          >
            <Text style={styles.actionIcon}>💰</Text>
            <Text style={styles.actionText}>Treasury</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  header: {
    marginBottom: spacing.xl,
    paddingBottom: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  headerTitle: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.xs,
  },
  headerSubtitle: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginTop: spacing.lg,
    marginBottom: spacing.md,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  treasuryCard: {
    backgroundColor: colors.background.secondary,
    padding: spacing.lg,
    borderRadius: borderRadius.lg,
    borderWidth: 1,
    borderColor: colors.border.default,
    alignItems: 'center',
    marginTop: spacing.md,
  },
  treasuryLabel: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    marginBottom: spacing.xs,
  },
  treasuryValue: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
    color: colors.status.success,
  },
  actionsContainer: {
    gap: spacing.md,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.background.secondary,
    padding: spacing.lg,
    borderRadius: borderRadius.lg,
    borderWidth: 1,
    borderColor: colors.border.subtle,
  },
  actionIcon: {
    fontSize: 24,
    marginRight: spacing.md,
  },
  actionText: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
});
