/**
 * Members List Screen
 *
 * Displays list of DAO members with search and pagination.
 */

import {
  View,
  FlatList,
  Text,
  StyleSheet,
  RefreshControl,
  TextInput,
} from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { useState, useCallback, useMemo } from 'react';
import { useMembers } from '../../../src/hooks/useMembers';
import {
  LoadingState,
  ErrorState,
  EmptyState,
} from '../../../src/components/common';
import { MemberCard } from '../../../src/components/members';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
} from '../../../src/constants/theme';

export default function MembersListScreen() {
  const { id: daoId } = useLocalSearchParams<{ id: string }>();
  const {
    members,
    isLoading,
    error,
    refetch,
    loadMoreMembers,
    hasMore,
    isLoadingMore,
    total,
  } = useMembers(daoId);

  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const handleLoadMore = useCallback(() => {
    if (hasMore && !isLoadingMore) {
      loadMoreMembers();
    }
  }, [hasMore, isLoadingMore, loadMoreMembers]);

  // Client-side filtering by search query
  const filteredMembers = useMemo(() => {
    if (!searchQuery.trim()) {
      return members;
    }

    const query = searchQuery.toLowerCase().trim();
    return members.filter((member) => {
      const displayName = member.displayName?.toLowerCase() || 'anonymous';
      return displayName.includes(query);
    });
  }, [members, searchQuery]);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Members' }} />
        <LoadingState message="Loading members..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Members' }} />
        <ErrorState message={error} onRetry={() => refetch()} />
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: `Members (${total})`,
          headerBackTitle: 'DAO',
        }}
      />
      <View style={styles.container}>
        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search members..."
            placeholderTextColor={colors.text.muted}
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoCapitalize="none"
            autoCorrect={false}
          />
        </View>

        {/* Members List */}
        <FlatList
          data={filteredMembers}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <MemberCard
              member={item}
              onPress={() => {
                // Optional: Navigate to member profile
                // router.push(`/profile/${item.userId}`);
              }}
            />
          )}
          ListEmptyComponent={
            <EmptyState
              icon="👥"
              title="No Members"
              description={
                searchQuery.trim()
                  ? `No members found matching "${searchQuery}"`
                  : 'This DAO has no members yet.'
              }
            />
          }
          ListFooterComponent={
            isLoadingMore ? (
              <View style={styles.loadingMore}>
                <Text style={styles.loadingMoreText}>Loading more...</Text>
              </View>
            ) : null
          }
          contentContainerStyle={
            filteredMembers.length === 0 ? styles.emptyList : styles.list
          }
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={handleRefresh}
              tintColor={colors.primary.default}
            />
          }
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  searchContainer: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  searchInput: {
    backgroundColor: colors.background.secondary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    fontSize: fontSize.md,
    color: colors.text.primary,
    borderWidth: 1,
    borderColor: colors.border.subtle,
  },
  list: {
    padding: spacing.lg,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  loadingMore: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  loadingMoreText: {
    color: colors.text.muted,
    fontSize: fontSize.sm,
  },
});
