/**
 * DAO Settings Screen
 *
 * Accessible to admin/owner users only.
 * Allows configuring DAO settings including logo upload.
 */

import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useState, useEffect } from 'react';
import { useDAO } from '../../../src/hooks/useDAO';
import { LoadingState, ErrorState } from '../../../src/components/common';
import { DAOLogoUpload } from '../../../src/components/dao';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
  fontWeight,
} from '../../../src/constants/theme';

export default function DAOSettingsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { dao, isLoading, error, refetch } = useDAO(id);
  const [logoUrl, setLogoUrl] = useState<string | undefined>(undefined);

  // Check if user is admin
  const isAdmin = dao?.userRole === 'admin' || dao?.userRole === 'owner';

  useEffect(() => {
    // If not admin and data is loaded, redirect back
    if (!isLoading && !isAdmin) {
      Alert.alert(
        'Access Denied',
        'Only admins can access DAO settings.',
        [{ text: 'OK', onPress: () => router.back() }]
      );
    }
  }, [isLoading, isAdmin, router]);

  useEffect(() => {
    if (dao?.logoUrl) {
      setLogoUrl(dao.logoUrl);
    }
  }, [dao?.logoUrl]);

  const handleLogoUploadComplete = async (newLogoUrl: string) => {
    setLogoUrl(newLogoUrl);
    // Refetch DAO data to update everywhere
    await refetch();
  };

  if (isLoading) {
    return (
      <>
        <Stack.Screen
          options={{
            title: 'Settings',
            headerBackTitle: 'Back',
          }}
        />
        <LoadingState message="Loading settings..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen
          options={{
            title: 'Settings',
            headerBackTitle: 'Back',
          }}
        />
        <ErrorState message={error} onRetry={refetch} />
      </>
    );
  }

  if (!dao) {
    return (
      <>
        <Stack.Screen
          options={{
            title: 'Settings',
            headerBackTitle: 'Back',
          }}
        />
        <ErrorState message="DAO not found" onRetry={refetch} />
      </>
    );
  }

  // If not admin, show access denied (shouldn't reach here due to useEffect)
  if (!isAdmin) {
    return (
      <>
        <Stack.Screen
          options={{
            title: 'Settings',
            headerBackTitle: 'Back',
          }}
        />
        <View style={styles.container}>
          <View style={styles.accessDenied}>
            <Text style={styles.accessDeniedTitle}>Access Denied</Text>
            <Text style={styles.accessDeniedText}>
              Only admins can access DAO settings.
            </Text>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => router.back()}
            >
              <Text style={styles.backButtonText}>Go Back</Text>
            </TouchableOpacity>
          </View>
        </View>
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: 'DAO Settings',
          headerBackTitle: 'Back',
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
      >
        {/* Logo Upload Section */}
        <View style={styles.section}>
          <DAOLogoUpload
            daoId={id}
            daoName={dao.name}
            currentLogoUrl={logoUrl}
            onUploadComplete={handleLogoUploadComplete}
          />
        </View>

        {/* DAO Info Section (Read-only for now) */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>DAO Information</Text>

          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Name</Text>
            <View style={styles.readOnlyField}>
              <Text style={styles.readOnlyText}>{dao.name}</Text>
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Slug</Text>
            <View style={styles.readOnlyField}>
              <Text style={styles.readOnlyText}>@{dao.slug}</Text>
            </View>
          </View>

          {dao.description && (
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Description</Text>
              <View style={[styles.readOnlyField, styles.descriptionField]}>
                <Text style={styles.readOnlyText}>{dao.description}</Text>
              </View>
            </View>
          )}

          <View style={styles.infoBox}>
            <Text style={styles.infoText}>
              More settings coming soon. Visit the web app for full
              configuration options.
            </Text>
          </View>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.lg,
  },
  fieldGroup: {
    marginBottom: spacing.lg,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  readOnlyField: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border.default,
  },
  descriptionField: {
    minHeight: 80,
  },
  readOnlyText: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  infoBox: {
    backgroundColor: colors.background.tertiary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginTop: spacing.md,
    borderWidth: 1,
    borderColor: colors.border.subtle,
  },
  infoText: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    lineHeight: 20,
  },
  accessDenied: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  accessDeniedTitle: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.md,
  },
  accessDeniedText: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  backButton: {
    backgroundColor: colors.primary.default,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: borderRadius.lg,
  },
  backButtonText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
});
