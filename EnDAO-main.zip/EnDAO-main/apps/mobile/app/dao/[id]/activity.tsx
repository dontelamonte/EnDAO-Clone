/**
 * Activity Feed Screen
 *
 * Displays activity feed for a DAO with pull-to-refresh and pagination.
 */

import {
  View,
  FlatList,
  Text,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { useState, useCallback } from 'react';
import { useActivities } from '../../../src/hooks/useActivities';
import {
  LoadingState,
  ErrorState,
  EmptyState,
} from '../../../src/components/common';
import { ActivityItem } from '../../../src/components/activity';
import {
  colors,
  fontSize,
  spacing,
} from '../../../src/constants/theme';

export default function ActivityScreen() {
  const { id: daoId } = useLocalSearchParams<{ id: string }>();
  const {
    activities,
    isLoading,
    error,
    refetch,
    loadMore,
    hasMore,
    isLoadingMore,
  } = useActivities(daoId);

  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const handleLoadMore = useCallback(() => {
    if (hasMore && !isLoadingMore) {
      loadMore();
    }
  }, [hasMore, isLoadingMore, loadMore]);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Activity' }} />
        <LoadingState message="Loading activity..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Activity' }} />
        <ErrorState message={error} onRetry={() => refetch()} />
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Activity',
          headerBackTitle: 'DAO',
        }}
      />
      <View style={styles.container}>
        <FlatList
          data={activities}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ActivityItem
              activity={item}
              onPress={() => {
                // Optional: Navigate to related item (proposal, member, etc.)
              }}
            />
          )}
          ListEmptyComponent={
            <EmptyState
              icon="📋"
              title="No Activity"
              description="No activity to show yet. Activity will appear here as members interact with the DAO."
            />
          }
          ListFooterComponent={
            isLoadingMore ? (
              <View style={styles.loadingMore}>
                <Text style={styles.loadingMoreText}>Loading more...</Text>
              </View>
            ) : null
          }
          contentContainerStyle={
            activities.length === 0 ? styles.emptyList : styles.list
          }
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={handleRefresh}
              tintColor={colors.primary.default}
            />
          }
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  list: {
    padding: spacing.lg,
  },
  emptyList: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  loadingMore: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  loadingMoreText: {
    color: colors.text.muted,
    fontSize: fontSize.sm,
  },
});
