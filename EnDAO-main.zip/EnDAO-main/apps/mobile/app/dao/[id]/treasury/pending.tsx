/**
 * Treasury Pending Executions Screen
 *
 * Displays pending treasury executions that need signatures.
 * Allows Safe owners to sign transactions.
 */

import {
  View,
  FlatList,
  Text,
  StyleSheet,
  RefreshControl,
  Alert,
} from 'react-native';
import { useLocalSearchParams, Stack, router } from 'expo-router';
import { useState, useCallback } from 'react';
import { usePendingExecutions } from '../../../../src/hooks/usePendingExecutions';
import { useEmbeddedWallet } from '@privy-io/expo';
import { api } from '../../../../src/services/api';
import { useAuth } from '../../../../src/hooks/useAuth';
import {
  LoadingState,
  ErrorState,
  EmptyState,
} from '../../../../src/components/common';
import { PendingExecutionCard } from '../../../../src/components/treasury';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
} from '../../../../src/constants/theme';
import { daoLogger } from '../../../../src/utils/dev-logger';

export default function PendingExecutionsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { executions, isOwner, isLoading, error, refetch } =
    usePendingExecutions(id);
  const { getAccessToken } = useAuth();
  const wallet = useEmbeddedWallet();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [signingExecutionId, setSigningExecutionId] = useState<string | null>(
    null
  );

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  const handleSign = useCallback(
    async (executionId: string) => {
      if (wallet.status !== 'connected' || !wallet.account) {
        Alert.alert('Error', 'Wallet not connected');
        return;
      }

      // Find the execution to get details for signing
      const execution = executions.find((e) => e.executionId === executionId);
      if (!execution) {
        Alert.alert('Error', 'Execution not found');
        return;
      }

      setSigningExecutionId(executionId);

      try {
        // Create the message to sign (Safe transaction hash)
        const messageToSign = execution.safeTransactionHash;
        const walletAddress = wallet.account.address;

        daoLogger.info('Signing treasury transaction', {
          executionId,
          safeTransactionHash: messageToSign,
          walletAddress,
        });

        // Get the provider from embedded wallet
        const provider = await wallet.getProvider();

        // Use personal_sign to sign the Safe transaction hash
        const signature = await provider.request({
          method: 'personal_sign',
          params: [messageToSign, walletAddress],
        });

        if (!signature) {
          Alert.alert('Cancelled', 'Signature was cancelled');
          setSigningExecutionId(null);
          return;
        }

        daoLogger.info('Signature received, submitting to API');

        // Submit signature to API
        const token = await getAccessToken();
        const response = await api.signTreasuryExecution(
          token,
          executionId,
          signature
        );

        if (response.error) {
          Alert.alert('Error', response.error);
          setSigningExecutionId(null);
          return;
        }

        if (response.data) {
          const { message, currentSignatures, requiredSignatures } =
            response.data;

          // Show success message
          Alert.alert(
            'Success',
            message ||
              `Signed successfully! ${currentSignatures}/${requiredSignatures} signatures`,
            [
              {
                text: 'OK',
                onPress: () => {
                  // Refresh the list to show updated signature count
                  refetch();
                },
              },
            ]
          );
        }
      } catch (err) {
        daoLogger.error('Error signing treasury transaction:', err);
        Alert.alert(
          'Error',
          err instanceof Error
            ? err.message
            : 'Failed to sign transaction. Please try again.'
        );
      } finally {
        setSigningExecutionId(null);
      }
    },
    [wallet, executions, getAccessToken, refetch]
  );

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Pending Signatures' }} />
        <LoadingState message="Loading pending transactions..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Pending Signatures' }} />
        <ErrorState message={error} onRetry={refetch} />
      </>
    );
  }

  // Not a Safe owner
  if (!isOwner) {
    return (
      <>
        <Stack.Screen options={{ title: 'Pending Signatures' }} />
        <View style={styles.container}>
          <EmptyState
            icon="🔐"
            title="Not Authorized"
            description="Only Safe owners can sign treasury transactions."
          />
        </View>
      </>
    );
  }

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <EmptyState
        icon="✅"
        title="No Pending Transactions"
        description="All treasury transactions have been signed or there are no pending transactions."
      />
    </View>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <Text style={styles.headerTitle}>Pending Signatures</Text>
      <Text style={styles.headerSubtitle}>
        Sign treasury transactions to execute approved proposals.
      </Text>
    </View>
  );

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Pending Signatures',
          headerBackTitle: 'Back',
        }}
      />
      <FlatList
        style={styles.container}
        data={executions}
        keyExtractor={(item) => item.executionId}
        renderItem={({ item }) => (
          <PendingExecutionCard
            execution={item}
            onSign={handleSign}
            disabled={signingExecutionId !== null}
          />
        )}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary.default}
          />
        }
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  contentContainer: {
    paddingVertical: spacing.lg,
  },
  header: {
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  headerTitle: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  headerSubtitle: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  emptyContainer: {
    paddingTop: spacing.xxl,
  },
});
