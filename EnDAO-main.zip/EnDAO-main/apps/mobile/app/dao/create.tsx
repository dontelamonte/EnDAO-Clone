/**
 * DAO Creation Wizard Screen
 *
 * 3-step wizard for creating a new DAO on mobile:
 * 1. Choose organization template
 * 2. Enter basic information
 * 3. Review and submit
 */

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { useCreateDAO } from '../../src/hooks/useCreateDAO';
import {
  StepIndicator,
  TemplateStep,
  BasicInfoStep,
  ReviewStep,
} from '../../src/components/dao/create';
import {
  colors,
  spacing,
  borderRadius,
  fontSize,
  fontWeight,
} from '../../src/constants/theme';

export default function CreateDAOScreen() {
  const router = useRouter();
  const {
    formData,
    updateField,
    currentStep,
    canGoNext,
    canGoBack,
    goNext,
    goBack,
    errors,
    isSubmitting,
    submitDAO,
  } = useCreateDAO();

  const handleTemplateSelect = (
    type: NonNullable<typeof formData.organizationType>,
    category: typeof formData.category
  ) => {
    updateField('organizationType', type);
    updateField('category', category);
    // Auto-advance to next step after selection
    setTimeout(() => goNext(), 300);
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <TemplateStep
            selectedType={formData.organizationType}
            onSelect={handleTemplateSelect}
          />
        );
      case 2:
        return (
          <BasicInfoStep
            name={formData.name}
            description={formData.description}
            category={formData.category}
            errors={errors}
            onUpdateName={(value) => updateField('name', value)}
            onUpdateDescription={(value) => updateField('description', value)}
            onUpdateCategory={(value) => updateField('category', value)}
          />
        );
      case 3:
        if (!formData.organizationType) return null;
        return (
          <ReviewStep
            organizationType={formData.organizationType}
            name={formData.name}
            description={formData.description}
            category={formData.category}
          />
        );
      default:
        return null;
    }
  };

  const handlePrimaryAction = () => {
    if (currentStep === 3) {
      submitDAO();
    } else {
      goNext();
    }
  };

  const getPrimaryButtonText = () => {
    if (isSubmitting) return 'Creating...';
    if (currentStep === 3) return 'Create Group';
    return 'Next';
  };

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Create Group',
          headerStyle: { backgroundColor: colors.background.primary },
          headerTintColor: colors.text.primary,
          headerLeft: () =>
            canGoBack ? (
              <TouchableOpacity onPress={goBack} style={styles.headerButton}>
                <Text style={styles.headerButtonText}>Back</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
                <Text style={styles.headerButtonText}>Cancel</Text>
              </TouchableOpacity>
            ),
        }}
      />

      {/* Step Indicator */}
      <StepIndicator currentStep={currentStep} totalSteps={3} />

      {/* Step Content */}
      <View style={styles.content}>{renderStep()}</View>

      {/* Navigation Buttons */}
      <View style={styles.buttonContainer}>
        {/* Show Back button only on step 2 (step 1 auto-advances, step 3 doesn't need it in footer) */}
        {currentStep === 2 && (
          <TouchableOpacity
            style={styles.backButton}
            onPress={goBack}
            disabled={isSubmitting}
          >
            <Text style={styles.backButtonText}>Back</Text>
          </TouchableOpacity>
        )}

        {/* Show Next/Create button on steps 2 and 3 */}
        {currentStep >= 2 && (
          <TouchableOpacity
            style={[
              styles.primaryButton,
              currentStep === 2 && styles.primaryButtonFull,
              (!canGoNext || isSubmitting) && styles.primaryButtonDisabled,
            ]}
            onPress={handlePrimaryAction}
            disabled={!canGoNext || isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator size="small" color={colors.text.primary} />
            ) : (
              <Text style={styles.primaryButtonText}>{getPrimaryButtonText()}</Text>
            )}
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    flex: 1,
  },
  headerButton: {
    paddingHorizontal: spacing.md,
  },
  headerButtonText: {
    fontSize: fontSize.md,
    color: colors.primary.default,
    fontWeight: fontWeight.medium,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: spacing.md,
    padding: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border.default,
    backgroundColor: colors.background.primary,
  },
  backButton: {
    flex: 1,
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border.subtle,
  },
  backButtonText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: colors.primary.default,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    alignItems: 'center',
  },
  primaryButtonFull: {
    flex: 1,
  },
  primaryButtonDisabled: {
    opacity: 0.5,
  },
  primaryButtonText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
});
