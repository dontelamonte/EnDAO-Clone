/**
 * Discussion Detail Screen
 *
 * Displays discussion content with comments.
 */

import { useCallback, useState } from 'react';
import {
  View,
  ScrollView,
  Text,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { useDiscussion } from '../../src/hooks/useDiscussion';
import { LoadingState, ErrorState } from '../../src/components/common';
import {
  colors,
  fontSize,
  spacing,
  borderRadius,
} from '../../src/constants/theme';

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

function CommentItem({
  content,
  authorName,
  createdAt,
  isEdited,
}: {
  content: string;
  authorName: string | null;
  createdAt: string;
  isEdited: boolean;
}) {
  return (
    <View style={styles.commentContainer}>
      <View style={styles.commentHeader}>
        <Text style={styles.commentAuthor} numberOfLines={1}>
          {authorName || 'Anonymous'}
        </Text>
        <View style={styles.commentMeta}>
          <Text style={styles.commentTime}>{formatDate(createdAt)}</Text>
          {isEdited && <Text style={styles.editedBadge}>• edited</Text>}
        </View>
      </View>
      <Text style={styles.commentContent}>{content}</Text>
    </View>
  );
}

export default function DiscussionDetailScreen() {
  const { id: discussionId } = useLocalSearchParams<{ id: string }>();
  const { discussion, comments, isLoading, error, refetch } =
    useDiscussion(discussionId);

  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  }, [refetch]);

  if (isLoading && !isRefreshing) {
    return (
      <>
        <Stack.Screen options={{ title: 'Loading...' }} />
        <LoadingState message="Loading discussion..." />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Stack.Screen options={{ title: 'Error' }} />
        <ErrorState message={error} onRetry={refetch} />
      </>
    );
  }

  if (!discussion) {
    return (
      <>
        <Stack.Screen options={{ title: 'Not Found' }} />
        <ErrorState message="Discussion not found" onRetry={refetch} />
      </>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Discussion',
          headerBackTitle: 'Back',
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary.default}
          />
        }
      >
        {/* Discussion Header */}
        <View style={styles.discussionHeader}>
          {discussion.isPinned && (
            <View style={styles.pinnedBadge}>
              <Text style={styles.pinnedText}>📌 Pinned</Text>
            </View>
          )}
          <Text style={styles.title}>{discussion.title}</Text>
          <View style={styles.metaRow}>
            <Text style={styles.author} numberOfLines={1}>
              {discussion.authorName || 'Anonymous'}
            </Text>
            <Text style={styles.separator}>•</Text>
            <Text style={styles.time}>{formatDate(discussion.createdAt)}</Text>
          </View>
        </View>

        {/* Discussion Content */}
        <View style={styles.contentSection}>
          <Text style={styles.discussionContent}>{discussion.content}</Text>
        </View>

        {/* Comments Section */}
        <View style={styles.commentsSection}>
          <View style={styles.commentsSectionHeader}>
            <Text style={styles.commentsTitle}>
              Comments ({discussion.commentCount})
            </Text>
          </View>

          {comments.length === 0 ? (
            <View style={styles.noComments}>
              <Text style={styles.noCommentsText}>No comments yet</Text>
            </View>
          ) : (
            <View style={styles.commentsList}>
              {comments.map((comment) => (
                <CommentItem
                  key={comment.id}
                  content={comment.content}
                  authorName={comment.authorName}
                  createdAt={comment.createdAt}
                  isEdited={comment.isEdited}
                />
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  content: {
    paddingBottom: spacing.xxl,
  },
  discussionHeader: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
  },
  pinnedBadge: {
    backgroundColor: colors.primary.default + '20',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    alignSelf: 'flex-start',
    marginBottom: spacing.md,
  },
  pinnedText: {
    fontSize: fontSize.xs,
    color: colors.primary.default,
    fontWeight: '600',
  },
  title: {
    fontSize: fontSize.xxl,
    fontWeight: '700',
    color: colors.text.primary,
    marginBottom: spacing.md,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  author: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    fontWeight: '500',
    flexShrink: 1,
  },
  separator: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    marginHorizontal: spacing.xs,
  },
  time: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
  },
  contentSection: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  discussionContent: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    lineHeight: 24,
  },
  commentsSection: {
    paddingTop: spacing.lg,
  },
  commentsSectionHeader: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
  commentsTitle: {
    fontSize: fontSize.lg,
    fontWeight: '600',
    color: colors.text.primary,
  },
  commentsList: {
    paddingHorizontal: spacing.lg,
  },
  commentContainer: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  commentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  commentAuthor: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.text.primary,
    flex: 1,
    marginRight: spacing.sm,
  },
  commentMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  commentTime: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
  editedBadge: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
    marginLeft: spacing.xs,
  },
  commentContent: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    lineHeight: 22,
  },
  noComments: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
  },
  noCommentsText: {
    fontSize: fontSize.md,
    color: colors.text.muted,
    textAlign: 'center',
  },
});
