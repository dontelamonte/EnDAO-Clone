import { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useLoginWithEmail, useLoginWithSMS } from '@privy-io/expo';

const CODE_LENGTH = 6;

export default function VerifyScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{
    method: 'email' | 'sms';
    destination: string;
  }>();
  const { method, destination } = params;

  const { loginWithCode: verifyEmailCode } = useLoginWithEmail();
  const { loginWithCode: verifySMSCode } = useLoginWithSMS();

  const [code, setCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const inputRef = useRef<TextInput>(null);

  useEffect(() => {
    // Auto-focus input
    inputRef.current?.focus();
  }, []);

  const handleVerify = async () => {
    if (code.length !== CODE_LENGTH || isSubmitting) return;

    setIsSubmitting(true);
    try {
      if (method === 'email' && destination) {
        await verifyEmailCode({ code, email: destination });
      } else if (method === 'sms' && destination) {
        await verifySMSCode({ code, phone: destination });
      }
      // On success, navigate to root which will redirect to tabs
      router.replace('/');
    } catch (error) {
      Alert.alert('Verification Failed', 'Invalid code. Please try again.');
      console.error('Verification error:', error);
      setCode('');
      setIsSubmitting(false);
    }
  };

  const handleCodeChange = (text: string) => {
    // Only allow digits
    const cleaned = text.replace(/[^0-9]/g, '').slice(0, CODE_LENGTH);
    setCode(cleaned);

    // Auto-submit when complete
    if (cleaned.length === CODE_LENGTH) {
      setTimeout(() => handleVerify(), 100);
    }
  };

  const maskedDestination = () => {
    if (!destination) return '';
    if (method === 'email') {
      const [local, domain] = destination.split('@');
      return `${local[0]}***@${domain}`;
    }
    return `***-***-${destination.slice(-4)}`;
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.content}>
        {/* Back Button */}
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>

        {/* Header */}
        <Text style={styles.title}>Enter Verification Code</Text>
        <Text style={styles.subtitle}>
          We sent a {CODE_LENGTH}-digit code to{'\n'}
          <Text style={styles.destination}>{maskedDestination()}</Text>
        </Text>

        {/* Code Input */}
        <View style={styles.codeContainer}>
          <TextInput
            ref={inputRef}
            style={styles.hiddenInput}
            value={code}
            onChangeText={handleCodeChange}
            keyboardType="number-pad"
            maxLength={CODE_LENGTH}
            autoComplete="one-time-code"
          />
          <View style={styles.codeDisplay}>
            {Array.from({ length: CODE_LENGTH }).map((_, index) => (
              <View
                key={index}
                style={[
                  styles.codeBox,
                  code.length === index && styles.codeBoxActive,
                  code.length > index && styles.codeBoxFilled,
                ]}
              >
                <Text style={styles.codeText}>{code[index] || ''}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Verify Button */}
        <TouchableOpacity
          style={[
            styles.button,
            (code.length !== CODE_LENGTH || isSubmitting) &&
              styles.buttonDisabled,
          ]}
          onPress={handleVerify}
          disabled={code.length !== CODE_LENGTH || isSubmitting}
        >
          {isSubmitting ? (
            <ActivityIndicator color="#ffffff" />
          ) : (
            <Text style={styles.buttonText}>Verify</Text>
          )}
        </TouchableOpacity>

        {/* Resend */}
        <TouchableOpacity
          style={styles.resendButton}
          onPress={() => {
            router.back();
          }}
        >
          <Text style={styles.resendText}>
            Didn't receive a code? Try again
          </Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
  },
  backButton: {
    marginBottom: 32,
  },
  backText: {
    color: '#3b82f6',
    fontSize: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#f8fafc',
    marginBottom: 12,
  },
  subtitle: {
    fontSize: 16,
    color: '#94a3b8',
    lineHeight: 24,
    marginBottom: 40,
  },
  destination: {
    color: '#f8fafc',
    fontWeight: '600',
  },
  codeContainer: {
    marginBottom: 32,
  },
  hiddenInput: {
    position: 'absolute',
    opacity: 0,
    width: '100%',
    height: 60,
  },
  codeDisplay: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  codeBox: {
    width: 48,
    height: 56,
    borderRadius: 12,
    backgroundColor: '#1e293b',
    borderWidth: 2,
    borderColor: '#334155',
    justifyContent: 'center',
    alignItems: 'center',
  },
  codeBoxActive: {
    borderColor: '#3b82f6',
  },
  codeBoxFilled: {
    borderColor: '#22c55e',
    backgroundColor: '#14532d',
  },
  codeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  button: {
    backgroundColor: '#3b82f6',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 24,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
  },
  resendButton: {
    alignItems: 'center',
  },
  resendText: {
    color: '#3b82f6',
    fontSize: 14,
  },
});
