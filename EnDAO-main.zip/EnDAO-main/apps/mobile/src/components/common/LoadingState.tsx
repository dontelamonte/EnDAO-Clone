/**
 * LoadingState Component
 *
 * Full-screen loading indicator for initial data fetches.
 * Used when navigating to new screens or loading primary content.
 */

import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { colors, fontSize, spacing } from '../../constants/theme';

interface LoadingStateProps {
  /** Optional message to display below the spinner */
  message?: string;
}

export function LoadingState({ message = 'Loading...' }: LoadingStateProps) {
  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={colors.primary.default} />
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background.primary,
    padding: spacing.xl,
  },
  message: {
    marginTop: spacing.lg,
    fontSize: fontSize.md,
    color: colors.text.secondary,
    textAlign: 'center',
  },
});
