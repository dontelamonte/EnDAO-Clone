/**
 * VoteConfirmation Component
 *
 * Modal for confirming vote submission with signing status.
 */

import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';
import { VoteChoice } from './VoteButtons';

interface VoteConfirmationProps {
  visible: boolean;
  choice: VoteChoice | null;
  isSubmitting: boolean;
  isSigning: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

function getChoiceLabel(choice: VoteChoice | null): string {
  switch (choice) {
    case 'for':
      return 'For';
    case 'against':
      return 'Against';
    case 'abstain':
      return 'Abstain';
    default:
      return '';
  }
}

function getChoiceColor(choice: VoteChoice | null): string {
  switch (choice) {
    case 'for':
      return colors.vote.for;
    case 'against':
      return colors.vote.against;
    case 'abstain':
      return colors.vote.abstain;
    default:
      return colors.text.secondary;
  }
}

export function VoteConfirmation({
  visible,
  choice,
  isSubmitting,
  isSigning,
  onConfirm,
  onCancel,
}: VoteConfirmationProps) {
  const choiceLabel = getChoiceLabel(choice);
  const choiceColor = getChoiceColor(choice);
  const isProcessing = isSubmitting || isSigning;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onCancel}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          {isProcessing ? (
            <View style={styles.processingContainer}>
              <ActivityIndicator size="large" color={colors.primary.default} />
              <Text style={styles.processingTitle}>
                {isSigning ? 'Signing Vote...' : 'Submitting Vote...'}
              </Text>
              <Text style={styles.processingSubtitle}>
                {isSigning
                  ? 'Please confirm in your wallet'
                  : 'Recording your vote on-chain'}
              </Text>
            </View>
          ) : (
            <>
              <Text style={styles.title}>Confirm Your Vote</Text>

              <View style={styles.choiceContainer}>
                <Text style={styles.choiceLabel}>You are voting:</Text>
                <View
                  style={[
                    styles.choiceBadge,
                    { backgroundColor: choiceColor + '20' },
                  ]}
                >
                  <Text style={[styles.choiceText, { color: choiceColor }]}>
                    {choiceLabel}
                  </Text>
                </View>
              </View>

              <Text style={styles.signatureNote}>
                Your vote will be cryptographically signed for verification.
              </Text>

              <View style={styles.buttonContainer}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={onCancel}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.confirmButton,
                    { backgroundColor: choiceColor },
                  ]}
                  onPress={onConfirm}
                >
                  <Text style={styles.confirmButtonText}>Confirm & Sign</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  container: {
    width: '100%',
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
  },
  title: {
    fontSize: fontSize.xl,
    fontWeight: '700',
    color: colors.text.primary,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  choiceContainer: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  choiceLabel: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    marginBottom: spacing.md,
  },
  choiceBadge: {
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
  },
  choiceText: {
    fontSize: fontSize.lg,
    fontWeight: '700',
  },
  signatureNote: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.background.tertiary,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: fontSize.md,
    fontWeight: '600',
    color: colors.text.secondary,
  },
  confirmButton: {
    flex: 1,
    paddingVertical: spacing.lg,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
  },
  confirmButtonText: {
    fontSize: fontSize.md,
    fontWeight: '600',
    color: colors.text.primary,
  },
  processingContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
  },
  processingTitle: {
    fontSize: fontSize.lg,
    fontWeight: '600',
    color: colors.text.primary,
    marginTop: spacing.lg,
  },
  processingSubtitle: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    marginTop: spacing.sm,
  },
});
