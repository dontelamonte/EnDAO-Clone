/**
 * ProposalCard Component
 *
 * Displays a proposal summary in a card format with status badge.
 */

import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface ProposalCardProps {
  id: string;
  title: string;
  status: string;
  description?: string;
  votingEndTime?: string;
  onPress: () => void;
}

function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case 'active':
    case 'open':
      return colors.proposal.active;
    case 'pending':
    case 'pending_approval':
    case 'under_review':
      return colors.proposal.pending;
    case 'passed':
    case 'approved':
      return colors.proposal.passed;
    case 'rejected':
    case 'failed':
      return colors.proposal.rejected;
    case 'executed':
      return colors.proposal.executed;
    default:
      return colors.text.muted;
  }
}

function getStatusLabel(status: string): string {
  switch (status.toLowerCase()) {
    case 'pending_approval':
    case 'under_review':
      return 'Pending';
    case 'open':
      return 'Active';
    default:
      return status.charAt(0).toUpperCase() + status.slice(1).toLowerCase();
  }
}

function getTimeRemaining(endTime?: string): string | null {
  if (!endTime) return null;

  const end = new Date(endTime);
  const now = new Date();
  const diff = end.getTime() - now.getTime();

  if (diff <= 0) return 'Ended';

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

  if (days > 0) return `${days}d ${hours}h left`;
  if (hours > 0) return `${hours}h left`;

  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${minutes}m left`;
}

export function ProposalCard({
  title,
  status,
  description,
  votingEndTime,
  onPress,
}: ProposalCardProps) {
  const statusColor = getStatusColor(status);
  const statusLabel = getStatusLabel(status);
  const timeRemaining = getTimeRemaining(votingEndTime);
  const isActive =
    status.toLowerCase() === 'active' || status.toLowerCase() === 'open';

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <View
          style={[styles.statusBadge, { backgroundColor: statusColor + '20' }]}
        >
          <Text style={[styles.statusText, { color: statusColor }]}>
            {statusLabel}
          </Text>
        </View>
        {isActive && timeRemaining && (
          <Text style={styles.timeRemaining}>{timeRemaining}</Text>
        )}
      </View>

      <Text style={styles.title} numberOfLines={2}>
        {title}
      </Text>

      {description && (
        <Text style={styles.description} numberOfLines={2}>
          {description}
        </Text>
      )}

      <View style={styles.footer}>
        <Text style={styles.viewMore}>View details →</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  statusBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  statusText: {
    fontSize: fontSize.xs,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  timeRemaining: {
    fontSize: fontSize.xs,
    color: colors.proposal.active,
    fontWeight: '500',
  },
  title: {
    fontSize: fontSize.lg,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  description: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    lineHeight: 20,
    marginBottom: spacing.md,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  viewMore: {
    fontSize: fontSize.sm,
    color: colors.primary.default,
    fontWeight: '500',
  },
});
