/**
 * VoteResults Component
 *
 * Displays vote tallies with progress bars.
 */

import { View, Text, StyleSheet } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface VoteResultsProps {
  forVotes: number;
  againstVotes: number;
  abstainVotes: number;
  quorumReached?: boolean;
  thresholdMet?: boolean;
}

export function VoteResults({
  forVotes,
  againstVotes,
  abstainVotes,
  quorumReached,
  thresholdMet,
}: VoteResultsProps) {
  const totalVotes = forVotes + againstVotes + abstainVotes;
  const forPercent = totalVotes > 0 ? (forVotes / totalVotes) * 100 : 0;
  const againstPercent = totalVotes > 0 ? (againstVotes / totalVotes) * 100 : 0;
  const abstainPercent = totalVotes > 0 ? (abstainVotes / totalVotes) * 100 : 0;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Current Results</Text>

      {/* For */}
      <View style={styles.resultRow}>
        <View style={styles.labelRow}>
          <Text style={styles.label}>For</Text>
          <Text style={styles.value}>
            {forVotes} ({forPercent.toFixed(1)}%)
          </Text>
        </View>
        <View style={styles.barContainer}>
          <View
            style={[
              styles.bar,
              {
                width: `${forPercent}%`,
                backgroundColor: colors.vote.for,
              },
            ]}
          />
        </View>
      </View>

      {/* Against */}
      <View style={styles.resultRow}>
        <View style={styles.labelRow}>
          <Text style={styles.label}>Against</Text>
          <Text style={styles.value}>
            {againstVotes} ({againstPercent.toFixed(1)}%)
          </Text>
        </View>
        <View style={styles.barContainer}>
          <View
            style={[
              styles.bar,
              {
                width: `${againstPercent}%`,
                backgroundColor: colors.vote.against,
              },
            ]}
          />
        </View>
      </View>

      {/* Abstain */}
      <View style={styles.resultRow}>
        <View style={styles.labelRow}>
          <Text style={styles.label}>Abstain</Text>
          <Text style={styles.value}>
            {abstainVotes} ({abstainPercent.toFixed(1)}%)
          </Text>
        </View>
        <View style={styles.barContainer}>
          <View
            style={[
              styles.bar,
              {
                width: `${abstainPercent}%`,
                backgroundColor: colors.vote.abstain,
              },
            ]}
          />
        </View>
      </View>

      {/* Status indicators */}
      {(quorumReached !== undefined || thresholdMet !== undefined) && (
        <View style={styles.statusContainer}>
          {quorumReached !== undefined && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusIcon}>{quorumReached ? '✓' : '○'}</Text>
              <Text
                style={[
                  styles.statusText,
                  quorumReached && styles.statusTextMet,
                ]}
              >
                Quorum {quorumReached ? 'reached' : 'not reached'}
              </Text>
            </View>
          )}
          {thresholdMet !== undefined && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusIcon}>{thresholdMet ? '✓' : '○'}</Text>
              <Text
                style={[
                  styles.statusText,
                  thresholdMet && styles.statusTextMet,
                ]}
              >
                Threshold {thresholdMet ? 'met' : 'not met'}
              </Text>
            </View>
          )}
        </View>
      )}

      <Text style={styles.totalVotes}>
        Total: {totalVotes} vote{totalVotes !== 1 ? 's' : ''}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
  },
  title: {
    fontSize: fontSize.lg,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: spacing.lg,
  },
  resultRow: {
    marginBottom: spacing.md,
  },
  labelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xs,
  },
  label: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
  },
  value: {
    fontSize: fontSize.sm,
    color: colors.text.primary,
    fontWeight: '500',
  },
  barContainer: {
    height: 8,
    backgroundColor: colors.background.tertiary,
    borderRadius: borderRadius.full,
    overflow: 'hidden',
  },
  bar: {
    height: '100%',
    borderRadius: borderRadius.full,
  },
  statusContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: spacing.md,
    gap: spacing.md,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusIcon: {
    fontSize: fontSize.sm,
    marginRight: spacing.xs,
    color: colors.text.muted,
  },
  statusText: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
  statusTextMet: {
    color: colors.status.success,
  },
  totalVotes: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    marginTop: spacing.md,
    textAlign: 'center',
  },
});
