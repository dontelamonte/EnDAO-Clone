/**
 * VoteButtons Component
 *
 * For/Against/Abstain vote selection buttons.
 */

import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

export type VoteChoice = 'for' | 'against' | 'abstain';

interface VoteButtonsProps {
  selectedChoice: VoteChoice | null;
  onSelect: (choice: VoteChoice) => void;
  disabled?: boolean;
}

const VOTE_OPTIONS: { choice: VoteChoice; label: string; icon: string }[] = [
  { choice: 'for', label: 'For', icon: '👍' },
  { choice: 'against', label: 'Against', icon: '👎' },
  { choice: 'abstain', label: 'Abstain', icon: '🤷' },
];

function getChoiceColor(choice: VoteChoice): string {
  switch (choice) {
    case 'for':
      return colors.vote.for;
    case 'against':
      return colors.vote.against;
    case 'abstain':
      return colors.vote.abstain;
  }
}

export function VoteButtons({
  selectedChoice,
  onSelect,
  disabled = false,
}: VoteButtonsProps) {
  return (
    <View style={styles.container}>
      {VOTE_OPTIONS.map((option) => {
        const isSelected = selectedChoice === option.choice;
        const choiceColor = getChoiceColor(option.choice);

        return (
          <TouchableOpacity
            key={option.choice}
            style={[
              styles.button,
              isSelected && {
                backgroundColor: choiceColor,
                borderColor: choiceColor,
              },
              disabled && styles.buttonDisabled,
            ]}
            onPress={() => onSelect(option.choice)}
            disabled={disabled}
            activeOpacity={0.7}
          >
            <Text style={styles.icon}>{option.icon}</Text>
            <Text style={[styles.label, isSelected && styles.labelSelected]}>
              {option.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: spacing.lg,
    marginHorizontal: spacing.xs,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.background.secondary,
    borderWidth: 2,
    borderColor: colors.border.subtle,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  icon: {
    fontSize: 24,
    marginBottom: spacing.sm,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.text.secondary,
  },
  labelSelected: {
    color: colors.text.primary,
  },
});
