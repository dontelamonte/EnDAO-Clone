/**
 * SignedBadge Component
 *
 * Indicator for cryptographically signed votes.
 */

import { View, Text, StyleSheet } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface SignedBadgeProps {
  isSigned?: boolean;
  compact?: boolean;
}

export function SignedBadge({
  isSigned = true,
  compact = false,
}: SignedBadgeProps) {
  if (!isSigned) return null;

  if (compact) {
    return (
      <View style={styles.compactContainer}>
        <Text style={styles.compactIcon}>🔐</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.icon}>🔐</Text>
      <Text style={styles.text}>Cryptographically Signed</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.status.success + '20',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.status.success + '40',
  },
  icon: {
    fontSize: 14,
    marginRight: spacing.xs,
  },
  text: {
    fontSize: fontSize.xs,
    fontWeight: '500',
    color: colors.status.success,
  },
  compactContainer: {
    backgroundColor: colors.status.success + '20',
    padding: spacing.xs,
    borderRadius: borderRadius.full,
  },
  compactIcon: {
    fontSize: 12,
  },
});
