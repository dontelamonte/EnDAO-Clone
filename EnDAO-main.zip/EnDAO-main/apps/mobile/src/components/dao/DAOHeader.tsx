/**
 * DAOHeader Component
 *
 * Displays DAO avatar/logo, name, and description in a header layout.
 */

import { View, Text, StyleSheet, Image } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface DAOHeaderProps {
  name: string;
  description?: string;
  slug?: string;
  logoUrl?: string;
}

export function DAOHeader({ name, description, slug, logoUrl }: DAOHeaderProps) {
  return (
    <View style={styles.container}>
      <View style={styles.avatarContainer}>
        {logoUrl ? (
          <Image source={{ uri: logoUrl }} style={styles.avatarImage} />
        ) : (
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{name.charAt(0).toUpperCase()}</Text>
          </View>
        )}
      </View>
      <Text style={styles.name}>{name}</Text>
      {slug && <Text style={styles.slug}>@{slug}</Text>}
      {description && (
        <Text style={styles.description} numberOfLines={3}>
          {description}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  avatarContainer: {
    marginBottom: spacing.lg,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.primary.default,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.text.primary,
  },
  name: {
    fontSize: fontSize.xxl,
    fontWeight: '700',
    color: colors.text.primary,
    textAlign: 'center',
  },
  slug: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    marginTop: spacing.xs,
  },
  description: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
    textAlign: 'center',
    marginTop: spacing.md,
    lineHeight: 22,
  },
});
