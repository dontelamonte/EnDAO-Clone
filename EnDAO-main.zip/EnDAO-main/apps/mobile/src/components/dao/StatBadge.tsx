/**
 * StatBadge Component
 *
 * Displays a single stat with label and value.
 */

import { View, Text, StyleSheet } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface StatBadgeProps {
  label: string;
  value: number | string;
  icon?: string;
}

export function StatBadge({ label, value, icon }: StatBadgeProps) {
  const displayValue =
    typeof value === 'number' ? value.toLocaleString() : value;

  return (
    <View style={styles.container}>
      {icon && <Text style={styles.icon}>{icon}</Text>}
      <Text style={styles.value}>{displayValue}</Text>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.sm,
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    marginHorizontal: spacing.xs,
  },
  icon: {
    fontSize: 20,
    marginBottom: spacing.xs,
  },
  value: {
    fontSize: fontSize.xl,
    fontWeight: '700',
    color: colors.text.primary,
  },
  label: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
    marginTop: spacing.xs,
    textTransform: 'uppercase',
  },
});
