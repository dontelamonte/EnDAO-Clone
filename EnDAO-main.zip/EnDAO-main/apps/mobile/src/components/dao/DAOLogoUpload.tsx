/**
 * DAOLogoUpload Component
 *
 * Handles DAO logo image selection, upload, and display.
 * Similar to avatar upload in profile-edit.tsx
 */

import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useState } from 'react';
import { api } from '../../services/api';
import { useAuth } from '../../hooks/useAuth';
import {
  colors,
  spacing,
  borderRadius,
  fontSize,
  fontWeight,
} from '../../constants/theme';

interface DAOLogoUploadProps {
  daoId: string;
  daoName: string;
  currentLogoUrl?: string;
  onUploadComplete: (logoUrl: string) => void;
}

export function DAOLogoUpload({
  daoId,
  daoName,
  currentLogoUrl,
  onUploadComplete,
}: DAOLogoUploadProps) {
  const { getAccessToken } = useAuth();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const pickImage = async () => {
    try {
      // Request permissions
      const permissionResult =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permissionResult.granted) {
        Alert.alert(
          'Permission Required',
          'Please allow access to your photo library to upload a DAO logo.'
        );
        return;
      }

      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1], // Square crop
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadLogo(result.assets[0].uri);
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to pick image. Please try again.');
    }
  };

  const uploadLogo = async (imageUri: string) => {
    setIsUploading(true);
    setUploadError(null);

    try {
      const token = await getAccessToken();
      const response = await api.uploadDAOLogo(token, daoId, imageUri);

      if (response.error) {
        setUploadError(response.error);
        Alert.alert('Upload Failed', response.error);
        return;
      }

      if (response.data) {
        // Update DAO with new logo URL
        const updateResponse = await api.updateDAO(token, daoId, {
          logoUrl: response.data.url,
        });

        if (updateResponse.error) {
          setUploadError(updateResponse.error);
          Alert.alert('Update Failed', updateResponse.error);
          return;
        }

        onUploadComplete(response.data.url);
        Alert.alert('Success', 'DAO logo updated successfully');
      }
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Failed to upload logo';
      setUploadError(message);
      Alert.alert('Error', message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>DAO Logo</Text>

      <TouchableOpacity
        style={styles.logoContainer}
        onPress={pickImage}
        disabled={isUploading}
      >
        {isUploading ? (
          <View style={styles.logo}>
            <ActivityIndicator size="large" color={colors.text.primary} />
          </View>
        ) : currentLogoUrl ? (
          <Image source={{ uri: currentLogoUrl }} style={styles.logoImage} />
        ) : (
          <View style={styles.logo}>
            <Text style={styles.logoText}>
              {daoName.charAt(0).toUpperCase()}
            </Text>
          </View>
        )}
        {!isUploading && (
          <View style={styles.logoOverlay}>
            <Text style={styles.logoOverlayText}>📷</Text>
          </View>
        )}
      </TouchableOpacity>

      <Text style={styles.hint}>
        {isUploading ? 'Uploading...' : 'Tap to change DAO logo'}
      </Text>

      {uploadError && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{uploadError}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.md,
    alignSelf: 'flex-start',
  },
  logoContainer: {
    position: 'relative',
    marginBottom: spacing.md,
  },
  logo: {
    width: 100,
    height: 100,
    borderRadius: borderRadius.full,
    backgroundColor: colors.primary.default,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoImage: {
    width: 100,
    height: 100,
    borderRadius: borderRadius.full,
  },
  logoOverlay: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: borderRadius.full,
    backgroundColor: colors.background.tertiary,
    borderWidth: 2,
    borderColor: colors.background.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoOverlayText: {
    fontSize: fontSize.lg,
  },
  logoText: {
    fontSize: 40,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
  },
  hint: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
  },
  errorContainer: {
    backgroundColor: '#450a0a',
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  errorText: {
    fontSize: fontSize.sm,
    color: colors.status.error,
  },
});
