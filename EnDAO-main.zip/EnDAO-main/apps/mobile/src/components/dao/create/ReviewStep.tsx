/**
 * ReviewStep Component
 *
 * Step 3: Review all selections before creating the DAO.
 * Displays a summary of the organization type, name, description, and category.
 */

import { View, Text, StyleSheet, ScrollView } from 'react-native';
import {
  colors,
  spacing,
  borderRadius,
  fontSize,
  fontWeight,
} from '../../../constants/theme';
import { ORGANIZATION_TEMPLATES, OrganizationType, DAOCategory } from '../../../hooks/useCreateDAO';

interface ReviewStepProps {
  organizationType: OrganizationType;
  name: string;
  description: string;
  category: DAOCategory;
}

export function ReviewStep({
  organizationType,
  name,
  description,
  category,
}: ReviewStepProps) {
  const template = ORGANIZATION_TEMPLATES.find((t) => t.type === organizationType);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Review Your DAO</Text>
        <Text style={styles.subtitle}>Check your selections before creating</Text>
      </View>

      {/* Organization Type */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Organization Type</Text>
        <View style={styles.card}>
          <Text style={styles.cardIcon}>{template?.icon || '🌟'}</Text>
          <Text style={styles.cardTitle}>{template?.name || organizationType}</Text>
          <Text style={styles.cardSubtitle}>{template?.description || ''}</Text>
        </View>
      </View>

      {/* Name */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>DAO Name</Text>
        <View style={styles.card}>
          <Text style={styles.cardText}>{name}</Text>
        </View>
      </View>

      {/* Description */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Description</Text>
        <View style={styles.card}>
          <Text style={styles.cardText}>{description}</Text>
        </View>
      </View>

      {/* Category */}
      <View style={styles.section}>
        <Text style={styles.sectionLabel}>Category</Text>
        <View style={styles.card}>
          <View
            style={[
              styles.categoryBadge,
              category === 'Commerce' && styles.categoryBadgeCommerce,
            ]}
          >
            <Text style={styles.categoryBadgeText}>{category}</Text>
          </View>
        </View>
      </View>

      {/* Info Box */}
      <View style={styles.infoBox}>
        <Text style={styles.infoIcon}>ℹ️</Text>
        <Text style={styles.infoText}>
          You'll be able to customize additional settings after creating your DAO.
        </Text>
      </View>

      {/* Bottom spacer */}
      <View style={styles.bottomSpacer} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionLabel: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    color: colors.text.secondary,
    marginBottom: spacing.sm,
    textTransform: 'uppercase',
  },
  card: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border.default,
  },
  cardIcon: {
    fontSize: 40,
    marginBottom: spacing.sm,
    textAlign: 'center',
  },
  cardTitle: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    textAlign: 'center',
    marginBottom: spacing.xs,
  },
  cardSubtitle: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  cardText: {
    fontSize: fontSize.md,
    color: colors.text.primary,
    lineHeight: fontSize.md * 1.5,
  },
  categoryBadge: {
    backgroundColor: colors.status.info,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    alignSelf: 'flex-start',
  },
  categoryBadgeCommerce: {
    backgroundColor: colors.status.warning,
  },
  categoryBadgeText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
  infoBox: {
    backgroundColor: colors.background.tertiary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.md,
    marginTop: spacing.md,
  },
  infoIcon: {
    fontSize: fontSize.xl,
  },
  infoText: {
    flex: 1,
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    lineHeight: fontSize.sm * 1.5,
  },
  bottomSpacer: {
    height: spacing.xl,
  },
});
