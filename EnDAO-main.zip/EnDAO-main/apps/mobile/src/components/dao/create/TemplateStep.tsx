/**
 * TemplateStep Component
 *
 * Step 1: Select organization type template.
 * Displays 6 cards to choose from, each with name, description, and category badge.
 */

import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import {
  colors,
  spacing,
  borderRadius,
  fontSize,
  fontWeight,
} from '../../../constants/theme';
import { ORGANIZATION_TEMPLATES, OrganizationType, DAOCategory } from '../../../hooks/useCreateDAO';

interface TemplateStepProps {
  selectedType: OrganizationType | null;
  onSelect: (type: OrganizationType, category: DAOCategory) => void;
}

export function TemplateStep({ selectedType, onSelect }: TemplateStepProps) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Choose Your Organization Type</Text>
        <Text style={styles.subtitle}>
          Select the template that best matches your organization
        </Text>
      </View>

      <View style={styles.templateGrid}>
        {ORGANIZATION_TEMPLATES.map((template) => {
          const isSelected = selectedType === template.type;

          return (
            <TouchableOpacity
              key={template.type}
              style={[styles.templateCard, isSelected && styles.templateCardSelected]}
              onPress={() => onSelect(template.type, template.category)}
              activeOpacity={0.7}
            >
              <Text style={styles.templateIcon}>{template.icon}</Text>
              <Text style={styles.templateName}>{template.name}</Text>
              <Text style={styles.templateDescription}>{template.description}</Text>
              <View
                style={[
                  styles.categoryBadge,
                  template.category === 'Commerce' && styles.categoryBadgeCommerce,
                ]}
              >
                <Text style={styles.categoryBadgeText}>{template.category}</Text>
              </View>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  templateGrid: {
    gap: spacing.md,
  },
  templateCard: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    borderWidth: 2,
    borderColor: colors.border.default,
    alignItems: 'center',
  },
  templateCardSelected: {
    borderColor: colors.primary.default,
    backgroundColor: colors.background.tertiary,
  },
  templateIcon: {
    fontSize: 48,
    marginBottom: spacing.md,
  },
  templateName: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  templateDescription: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
    marginBottom: spacing.md,
  },
  categoryBadge: {
    backgroundColor: colors.status.info,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  categoryBadgeCommerce: {
    backgroundColor: colors.status.warning,
  },
  categoryBadgeText: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
});
