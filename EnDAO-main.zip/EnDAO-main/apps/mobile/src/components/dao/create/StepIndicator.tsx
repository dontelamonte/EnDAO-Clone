/**
 * StepIndicator Component
 *
 * Shows the current step in the DAO creation wizard (1/2/3).
 */

import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, borderRadius, fontSize, fontWeight } from '../../../constants/theme';

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
}

export function StepIndicator({ currentStep, totalSteps }: StepIndicatorProps) {
  return (
    <View style={styles.container}>
      {Array.from({ length: totalSteps }, (_, i) => i + 1).map((step) => {
        const isActive = step === currentStep;
        const isCompleted = step < currentStep;

        return (
          <View key={step} style={styles.stepContainer}>
            <View
              style={[
                styles.stepCircle,
                isActive && styles.stepCircleActive,
                isCompleted && styles.stepCircleCompleted,
              ]}
            >
              <Text
                style={[
                  styles.stepNumber,
                  isActive && styles.stepNumberActive,
                  isCompleted && styles.stepNumberCompleted,
                ]}
              >
                {step}
              </Text>
            </View>
            {step < totalSteps && (
              <View
                style={[
                  styles.stepConnector,
                  isCompleted && styles.stepConnectorCompleted,
                ]}
              />
            )}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.lg,
  },
  stepContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepCircle: {
    width: 36,
    height: 36,
    borderRadius: borderRadius.full,
    backgroundColor: colors.background.secondary,
    borderWidth: 2,
    borderColor: colors.border.subtle,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepCircleActive: {
    backgroundColor: colors.primary.default,
    borderColor: colors.primary.default,
  },
  stepCircleCompleted: {
    backgroundColor: colors.status.success,
    borderColor: colors.status.success,
  },
  stepNumber: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.muted,
  },
  stepNumberActive: {
    color: colors.text.primary,
  },
  stepNumberCompleted: {
    color: colors.text.primary,
  },
  stepConnector: {
    width: 40,
    height: 2,
    backgroundColor: colors.border.subtle,
    marginHorizontal: spacing.xs,
  },
  stepConnectorCompleted: {
    backgroundColor: colors.status.success,
  },
});
