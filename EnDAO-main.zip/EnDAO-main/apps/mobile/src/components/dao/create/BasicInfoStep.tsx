/**
 * BasicInfoStep Component
 *
 * Step 2: Enter basic DAO information (name, description, category).
 * Includes validation and character counts.
 */

import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import {
  colors,
  spacing,
  borderRadius,
  fontSize,
  fontWeight,
} from '../../../constants/theme';
import { DAOCategory } from '../../../hooks/useCreateDAO';

interface BasicInfoStepProps {
  name: string;
  description: string;
  category: DAOCategory;
  errors: {
    name?: string;
    description?: string;
    category?: string;
  };
  onUpdateName: (value: string) => void;
  onUpdateDescription: (value: string) => void;
  onUpdateCategory: (value: DAOCategory) => void;
}

export function BasicInfoStep({
  name,
  description,
  category,
  errors,
  onUpdateName,
  onUpdateDescription,
  onUpdateCategory,
}: BasicInfoStepProps) {
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Text style={styles.title}>Basic Information</Text>
          <Text style={styles.subtitle}>Tell us about your organization</Text>
        </View>

        {/* Name Field */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>
            DAO Name <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={[styles.input, errors.name && styles.inputError]}
            value={name}
            onChangeText={onUpdateName}
            placeholder="Enter DAO name"
            placeholderTextColor={colors.text.muted}
            autoCapitalize="words"
            maxLength={100}
          />
          <View style={styles.fieldFooter}>
            {errors.name ? (
              <Text style={styles.errorText}>{errors.name}</Text>
            ) : (
              <Text style={styles.hint}>3-100 characters</Text>
            )}
            <Text style={styles.charCount}>{name.length}/100</Text>
          </View>
        </View>

        {/* Description Field */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>
            Description <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            style={[styles.input, styles.textArea, errors.description && styles.inputError]}
            value={description}
            onChangeText={onUpdateDescription}
            placeholder="Describe your organization's mission and goals"
            placeholderTextColor={colors.text.muted}
            multiline
            numberOfLines={6}
            textAlignVertical="top"
            maxLength={1000}
          />
          <View style={styles.fieldFooter}>
            {errors.description ? (
              <Text style={styles.errorText}>{errors.description}</Text>
            ) : (
              <Text style={styles.hint}>10-1000 characters</Text>
            )}
            <Text style={styles.charCount}>{description.length}/1000</Text>
          </View>
        </View>

        {/* Category Toggle */}
        <View style={styles.fieldGroup}>
          <Text style={styles.label}>
            Category <Text style={styles.required}>*</Text>
          </Text>
          <View style={styles.categoryToggle}>
            <TouchableOpacity
              style={[
                styles.categoryOption,
                category === 'Community' && styles.categoryOptionActive,
              ]}
              onPress={() => onUpdateCategory('Community')}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.categoryOptionText,
                  category === 'Community' && styles.categoryOptionTextActive,
                ]}
              >
                Community
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.categoryOption,
                category === 'Commerce' && styles.categoryOptionActive,
              ]}
              onPress={() => onUpdateCategory('Commerce')}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.categoryOptionText,
                  category === 'Commerce' && styles.categoryOptionTextActive,
                ]}
              >
                Commerce
              </Text>
            </TouchableOpacity>
          </View>
          {errors.category && <Text style={styles.errorText}>{errors.category}</Text>}
        </View>

        {/* Bottom spacer for keyboard */}
        <View style={styles.bottomSpacer} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: fontSize.md,
    color: colors.text.secondary,
  },
  fieldGroup: {
    marginBottom: spacing.xl,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  required: {
    color: colors.status.error,
  },
  input: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    fontSize: fontSize.md,
    color: colors.text.primary,
    borderWidth: 1,
    borderColor: colors.border.default,
  },
  inputError: {
    borderColor: colors.status.error,
  },
  textArea: {
    minHeight: 120,
    paddingTop: spacing.lg,
  },
  fieldFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  hint: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
  charCount: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
  errorText: {
    fontSize: fontSize.xs,
    color: colors.status.error,
  },
  categoryToggle: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  categoryOption: {
    flex: 1,
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.border.default,
  },
  categoryOptionActive: {
    backgroundColor: colors.primary.default,
    borderColor: colors.primary.default,
  },
  categoryOptionText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.secondary,
  },
  categoryOptionTextActive: {
    color: colors.text.primary,
  },
  bottomSpacer: {
    height: spacing.xl,
  },
});
