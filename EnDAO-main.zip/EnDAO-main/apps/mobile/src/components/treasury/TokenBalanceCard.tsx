/**
 * Token Balance Card Component
 *
 * Displays a single token balance with symbol, amount, and USD value.
 */

import { View, Text, StyleSheet } from 'react-native';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../constants/theme';
import type { TreasuryToken } from '../../hooks/useTreasury';

interface TokenBalanceCardProps {
  token: TreasuryToken;
}

export function TokenBalanceCard({ token }: TokenBalanceCardProps) {
  const formatBalance = (balance: string): string => {
    const num = parseFloat(balance);
    if (isNaN(num)) return '0';

    // For large numbers, use comma separators
    if (num >= 1000) {
      return num.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
      });
    }

    // For small numbers, show more decimals
    return num.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 6,
    });
  };

  const formatUSD = (value: string | null): string => {
    if (!value) return '$0.00';
    const num = parseFloat(value);
    if (isNaN(num)) return '$0.00';
    return `$${num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <View style={styles.container}>
      <View style={styles.leftSection}>
        <Text style={styles.symbol}>{token.symbol}</Text>
      </View>
      <View style={styles.rightSection}>
        <Text style={styles.balance}>{formatBalance(token.balance)}</Text>
        <Text style={styles.usdValue}>{formatUSD(token.balanceUsd)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.background.tertiary,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
  },
  leftSection: {
    flex: 1,
  },
  symbol: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
  rightSection: {
    alignItems: 'flex-end',
  },
  balance: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.medium,
    color: colors.text.primary,
    marginBottom: spacing.xs,
  },
  usdValue: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
  },
});
