/**
 * Transaction Item Component
 *
 * Displays a single transaction with icon, amount, address, status, and timestamp.
 */

import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { formatDistanceToNow } from 'date-fns';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../constants/theme';
import type { Transaction } from '../../hooks/useTreasury';

interface TransactionItemProps {
  transaction: Transaction;
}

export function TransactionItem({ transaction }: TransactionItemProps) {
  const truncateAddress = (address: string): string => {
    if (!address) return 'Unknown';
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatAmount = (amount: string): string => {
    const num = parseFloat(amount);
    if (isNaN(num)) return '0';

    // For large numbers, use comma separators
    if (Math.abs(num) >= 1000) {
      return num.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
      });
    }

    // For small numbers, show more decimals
    return num.toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 6,
    });
  };

  const getRelativeTime = (timestamp: string): string => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch {
      return 'Unknown time';
    }
  };

  const getStatusColor = (status: Transaction['status']): string => {
    switch (status) {
      case 'confirmed':
        return colors.status.success;
      case 'failed':
        return colors.status.error;
      case 'pending':
        return colors.status.warning;
      default:
        return colors.text.muted;
    }
  };

  const getStatusText = (status: Transaction['status']): string => {
    switch (status) {
      case 'confirmed':
        return 'Confirmed';
      case 'failed':
        return 'Failed';
      case 'pending':
        return 'Pending';
      default:
        return 'Unknown';
    }
  };

  const isIncoming = transaction.type === 'incoming';
  const iconColor = isIncoming ? colors.status.success : colors.status.error;
  const amountPrefix = isIncoming ? '+' : '-';

  return (
    <TouchableOpacity style={styles.container} activeOpacity={0.7}>
      <View style={styles.leftSection}>
        <View style={[styles.iconContainer, { backgroundColor: iconColor + '20' }]}>
          <Text style={[styles.icon, { color: iconColor }]}>
            {isIncoming ? '↓' : '↑'}
          </Text>
        </View>
      </View>

      <View style={styles.centerSection}>
        <View style={styles.row}>
          <Text style={styles.amount}>
            {amountPrefix}
            {formatAmount(transaction.amount)} {transaction.tokenSymbol}
          </Text>
        </View>
        <Text style={styles.address}>
          {isIncoming ? 'from' : 'to'} {truncateAddress(isIncoming ? transaction.from : transaction.to)}
        </Text>
        <View style={styles.bottomRow}>
          <View style={[styles.statusBadge, { borderColor: getStatusColor(transaction.status) }]}>
            <Text style={[styles.statusText, { color: getStatusColor(transaction.status) }]}>
              {getStatusText(transaction.status)}
            </Text>
          </View>
          <Text style={styles.timestamp}>{getRelativeTime(transaction.timestamp)}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: colors.background.secondary,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
  },
  leftSection: {
    marginRight: spacing.md,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
  },
  centerSection: {
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  amount: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
  address: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    marginBottom: spacing.xs,
    fontFamily: 'monospace',
  },
  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs / 2,
    borderRadius: borderRadius.sm,
    borderWidth: 1,
    marginRight: spacing.sm,
  },
  statusText: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
    textTransform: 'capitalize',
  },
  timestamp: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
});
