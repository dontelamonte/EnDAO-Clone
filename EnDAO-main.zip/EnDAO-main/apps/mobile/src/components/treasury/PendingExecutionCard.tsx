/**
 * PendingExecutionCard Component
 *
 * Displays a treasury execution that needs signatures.
 */

import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../constants/theme';

export interface PendingExecutionCardProps {
  execution: {
    executionId: string;
    proposalId: string;
    amount: string;
    recipient: string;
    currency: string;
    requiredSignatures: number;
    currentSignatures: number;
    hasUserSigned: boolean;
    status: string;
    proposalTitle: string;
  };
  onSign?: (executionId: string) => void;
  disabled?: boolean;
}

export function PendingExecutionCard({
  execution,
  onSign,
  disabled = false,
}: PendingExecutionCardProps) {
  const truncateAddress = (address: string) => {
    if (address.length <= 10) return address;
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const canSign = !execution.hasUserSigned && !disabled;
  const needsMoreSignatures =
    execution.currentSignatures < execution.requiredSignatures;

  return (
    <View style={styles.card}>
      {/* Title */}
      <Text style={styles.title} numberOfLines={1}>
        {execution.proposalTitle}
      </Text>

      {/* Amount and Recipient */}
      <View style={styles.detailsRow}>
        <View style={styles.detailItem}>
          <Text style={styles.label}>Amount</Text>
          <Text style={styles.value}>
            {execution.amount} {execution.currency}
          </Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.label}>To</Text>
          <Text style={styles.value}>{truncateAddress(execution.recipient)}</Text>
        </View>
      </View>

      {/* Signature Progress */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View
            style={[
              styles.progressFill,
              {
                width: `${(execution.currentSignatures / execution.requiredSignatures) * 100}%`,
              },
            ]}
          />
        </View>
        <Text style={styles.progressText}>
          {execution.currentSignatures} of {execution.requiredSignatures}{' '}
          signatures
        </Text>
      </View>

      {/* Status Badge */}
      <View style={styles.statusRow}>
        {execution.hasUserSigned ? (
          <View style={[styles.badge, styles.signedBadge]}>
            <Text style={styles.badgeText}>✓ You signed</Text>
          </View>
        ) : needsMoreSignatures ? (
          <View style={[styles.badge, styles.pendingBadge]}>
            <Text style={styles.badgeText}>Needs signatures</Text>
          </View>
        ) : (
          <View style={[styles.badge, styles.readyBadge]}>
            <Text style={styles.badgeText}>Ready to execute</Text>
          </View>
        )}
      </View>

      {/* Sign Button */}
      {canSign && needsMoreSignatures && onSign && (
        <TouchableOpacity
          style={styles.signButton}
          onPress={() => onSign(execution.executionId)}
          activeOpacity={0.7}
        >
          <Text style={styles.signButtonText}>Sign Transaction</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  title: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.md,
  },
  detailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  detailItem: {
    flex: 1,
  },
  label: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    marginBottom: spacing.xs,
  },
  value: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.medium,
    color: colors.text.primary,
  },
  progressContainer: {
    marginBottom: spacing.md,
  },
  progressBar: {
    height: 8,
    backgroundColor: colors.background.tertiary,
    borderRadius: borderRadius.sm,
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary.default,
  },
  progressText: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  badge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  signedBadge: {
    backgroundColor: colors.status.success + '33', // 20% opacity
  },
  pendingBadge: {
    backgroundColor: colors.status.warning + '33', // 20% opacity
  },
  readyBadge: {
    backgroundColor: colors.status.info + '33', // 20% opacity
  },
  badgeText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    color: colors.text.primary,
  },
  signButton: {
    backgroundColor: colors.primary.default,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  signButtonText: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.background.primary,
  },
});
