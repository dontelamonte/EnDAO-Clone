/**
 * Treasury Header Component
 *
 * Displays treasury overview including total balance and Safe address.
 */

import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../constants/theme';
import type { TreasuryOverview } from '../../hooks/useTreasury';

interface TreasuryHeaderProps {
  treasury: TreasuryOverview;
}

export function TreasuryHeader({ treasury }: TreasuryHeaderProps) {
  const handleCopyAddress = async () => {
    if (!treasury.address) return;

    await Clipboard.setStringAsync(treasury.address);
    Alert.alert('Copied', 'Treasury address copied to clipboard');
  };

  const formatUSD = (value: string | null): string => {
    if (!value) return '$0.00';
    const num = parseFloat(value);
    if (isNaN(num)) return '$0.00';
    return `$${num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const truncateAddress = (address: string): string => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  if (!treasury.isConfigured) {
    return (
      <View style={styles.container}>
        <View style={styles.notConfiguredContainer}>
          <Text style={styles.notConfiguredEmoji}>🔒</Text>
          <Text style={styles.notConfiguredTitle}>Treasury Not Configured</Text>
          <Text style={styles.notConfiguredText}>
            This DAO hasn't set up a treasury yet. Contact an admin to configure a Safe.
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.balanceContainer}>
        <Text style={styles.balanceLabel}>Total Balance</Text>
        <Text style={styles.balanceAmount}>{formatUSD(treasury.balanceUsd)}</Text>
      </View>

      {treasury.address && (
        <TouchableOpacity
          style={styles.addressContainer}
          onPress={handleCopyAddress}
          activeOpacity={0.7}
        >
          <View style={styles.addressRow}>
            <Text style={styles.addressLabel}>Safe Address</Text>
            <Text style={styles.copyIcon}>📋</Text>
          </View>
          <Text style={styles.addressText}>{truncateAddress(treasury.address)}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: spacing.lg,
    backgroundColor: colors.background.secondary,
    borderBottomWidth: 1,
    borderBottomColor: colors.border.default,
  },
  balanceContainer: {
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  balanceLabel: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    marginBottom: spacing.xs,
  },
  balanceAmount: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
  },
  addressContainer: {
    backgroundColor: colors.background.tertiary,
    padding: spacing.md,
    borderRadius: borderRadius.md,
  },
  addressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  addressLabel: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
    textTransform: 'uppercase',
  },
  copyIcon: {
    fontSize: fontSize.md,
  },
  addressText: {
    fontSize: fontSize.md,
    color: colors.text.primary,
    fontFamily: 'monospace',
  },
  notConfiguredContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
  },
  notConfiguredEmoji: {
    fontSize: 48,
    marginBottom: spacing.md,
  },
  notConfiguredTitle: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
    marginBottom: spacing.sm,
  },
  notConfiguredText: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});
