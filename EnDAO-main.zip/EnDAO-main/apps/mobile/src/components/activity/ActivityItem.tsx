/**
 * ActivityItem Component
 *
 * Displays a single activity in the feed with icon and timestamp.
 */

import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface ActivityItemProps {
  activity: {
    id: string;
    type: string;
    title: string;
    description?: string;
    userId: string;
    createdAt: string;
  };
  onPress?: () => void;
}

// Map activity types to emoji icons
const ACTIVITY_ICONS: Record<string, string> = {
  member_joined: '👋',
  member_left: '👋',
  proposal_created: '📝',
  vote_cast: '🗳️',
  proposal_passed: '✅',
  proposal_rejected: '❌',
  proposal_status_changed: '🔄',
  settings_updated: '⚙️',
  treasury_action: '💰',
};

// Format relative timestamp
function getRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)}w ago`;
  return date.toLocaleDateString();
}

export function ActivityItem({ activity, onPress }: ActivityItemProps) {
  const icon = ACTIVITY_ICONS[activity.type] || '📌';
  const relativeTime = getRelativeTime(activity.createdAt);

  const content = (
    <View style={styles.container}>
      {/* Icon */}
      <View style={styles.iconContainer}>
        <Text style={styles.icon}>{icon}</Text>
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={2}>
          {activity.title}
        </Text>
        {activity.description && (
          <Text style={styles.description} numberOfLines={2}>
            {activity.description}
          </Text>
        )}
        <Text style={styles.timestamp}>{relativeTime}</Text>
      </View>
    </View>
  );

  if (onPress) {
    return (
      <TouchableOpacity
        onPress={onPress}
        activeOpacity={0.7}
        style={styles.touchable}
      >
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  touchable: {
    marginBottom: spacing.md,
  },
  container: {
    flexDirection: 'row',
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border.subtle,
    marginBottom: spacing.md,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.md,
    backgroundColor: colors.background.tertiary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  icon: {
    fontSize: fontSize.xl,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    color: colors.text.primary,
    fontSize: fontSize.md,
    fontWeight: '600',
    marginBottom: spacing.xs,
  },
  description: {
    color: colors.text.secondary,
    fontSize: fontSize.sm,
    marginBottom: spacing.xs,
  },
  timestamp: {
    color: colors.text.muted,
    fontSize: fontSize.xs,
  },
});
