/**
 * StatCard Component
 *
 * Displays a single statistic with icon, label, and value.
 * Used in admin dashboard grid.
 */

import { View, Text, StyleSheet } from 'react-native';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../constants/theme';

interface StatCardProps {
  icon: string;
  label: string;
  value: string | number;
  variant?: 'default' | 'success' | 'warning' | 'info';
}

export function StatCard({
  icon,
  label,
  value,
  variant = 'default',
}: StatCardProps) {
  const variantColor = {
    default: colors.text.primary,
    success: colors.status.success,
    warning: colors.status.warning,
    info: colors.status.info,
  }[variant];

  return (
    <View style={styles.container}>
      <Text style={styles.icon}>{icon}</Text>
      <Text style={styles.label}>{label}</Text>
      <Text style={[styles.value, { color: variantColor }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.secondary,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.border.default,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100,
  },
  icon: {
    fontSize: 28,
    marginBottom: spacing.xs,
  },
  label: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
    marginBottom: spacing.xs,
    textAlign: 'center',
  },
  value: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
    color: colors.text.primary,
  },
});
