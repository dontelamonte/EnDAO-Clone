/**
 * Admin Components
 *
 * Barrel export for admin dashboard components.
 */

export { StatCard } from './StatCard';
