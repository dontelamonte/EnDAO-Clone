/**
 * Member Card Component
 *
 * Displays a single DAO member with avatar, name, role, and joined date.
 */

import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { formatDistanceToNow } from 'date-fns';
import {
  colors,
  fontSize,
  fontWeight,
  spacing,
  borderRadius,
} from '../../constants/theme';
import type { Member } from '../../hooks/useMembers';

interface MemberCardProps {
  member: Member;
  onPress?: () => void;
}

export function MemberCard({ member, onPress }: MemberCardProps) {
  const getInitials = (name: string | null): string => {
    if (!name) return '?';
    const parts = name.trim().split(' ');
    if (parts.length === 1) {
      return parts[0].charAt(0).toUpperCase();
    }
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  };

  const getRoleBadgeColor = (role: Member['role']): string => {
    switch (role) {
      case 'owner':
        return colors.status.success;
      case 'admin':
        return colors.primary.default;
      case 'member':
        return colors.text.muted;
      default:
        return colors.text.muted;
    }
  };

  const getRoleLabel = (role: Member['role']): string => {
    switch (role) {
      case 'owner':
        return 'Owner';
      case 'admin':
        return 'Admin';
      case 'member':
        return 'Member';
      default:
        return 'Member';
    }
  };

  const getRelativeTime = (timestamp: string): string => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch {
      return 'Unknown';
    }
  };

  const displayName = member.displayName || 'Anonymous';
  const initials = getInitials(displayName);
  const roleColor = getRoleBadgeColor(member.role);
  const roleLabel = getRoleLabel(member.role);

  const content = (
    <View style={styles.container}>
      <View style={styles.leftSection}>
        <View style={styles.avatarContainer}>
          <Text style={styles.avatarText}>{initials}</Text>
        </View>
      </View>

      <View style={styles.centerSection}>
        <View style={styles.row}>
          <Text style={styles.name} numberOfLines={1}>
            {displayName}
          </Text>
        </View>
        <View style={styles.bottomRow}>
          <View style={[styles.roleBadge, { borderColor: roleColor }]}>
            <Text style={[styles.roleText, { color: roleColor }]}>
              {roleLabel}
            </Text>
          </View>
          <Text style={styles.joinedText}>
            Joined {getRelativeTime(member.joinedAt)}
          </Text>
        </View>
      </View>
    </View>
  );

  if (onPress) {
    return (
      <TouchableOpacity style={styles.touchable} onPress={onPress} activeOpacity={0.7}>
        {content}
      </TouchableOpacity>
    );
  }

  return <View style={styles.touchable}>{content}</View>;
}

const styles = StyleSheet.create({
  touchable: {
    marginBottom: spacing.sm,
  },
  container: {
    flexDirection: 'row',
    backgroundColor: colors.background.secondary,
    padding: spacing.md,
    borderRadius: borderRadius.md,
  },
  leftSection: {
    marginRight: spacing.md,
  },
  avatarContainer: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.full,
    backgroundColor: colors.primary.default + '30',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.primary.default + '50',
  },
  avatarText: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.bold,
    color: colors.primary.default,
  },
  centerSection: {
    flex: 1,
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  name: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.semibold,
    color: colors.text.primary,
  },
  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  roleBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs / 2,
    borderRadius: borderRadius.sm,
    borderWidth: 1,
    marginRight: spacing.sm,
  },
  roleText: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
    textTransform: 'capitalize',
  },
  joinedText: {
    fontSize: fontSize.xs,
    color: colors.text.muted,
  },
});
