/**
 * DiscussionCard Component
 *
 * Displays a discussion summary in a card format for the list view.
 */

import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors, fontSize, spacing, borderRadius } from '../../constants/theme';

interface DiscussionCardProps {
  id: string;
  title: string;
  authorName: string | null;
  commentCount: number;
  createdAt: string;
  isPinned?: boolean;
  onPress: () => void;
}

function getTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diff = now.getTime() - date.getTime();

  const minutes = Math.floor(diff / (1000 * 60));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const weeks = Math.floor(diff / (1000 * 60 * 60 * 24 * 7));

  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  if (weeks < 4) return `${weeks}w ago`;

  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}

export function DiscussionCard({
  title,
  authorName,
  commentCount,
  createdAt,
  isPinned,
  onPress,
}: DiscussionCardProps) {
  const timeAgo = getTimeAgo(createdAt);

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.7}
    >
      {/* Header with pin badge */}
      {isPinned && (
        <View style={styles.pinnedBadge}>
          <Text style={styles.pinnedText}>📌 Pinned</Text>
        </View>
      )}

      {/* Title */}
      <Text style={styles.title} numberOfLines={2}>
        {title}
      </Text>

      {/* Footer with metadata */}
      <View style={styles.footer}>
        <View style={styles.metaRow}>
          <Text style={styles.author} numberOfLines={1}>
            {authorName || 'Anonymous'}
          </Text>
          <Text style={styles.separator}>•</Text>
          <Text style={styles.time}>{timeAgo}</Text>
        </View>
        <View style={styles.commentBadge}>
          <Text style={styles.commentCount}>💬 {commentCount}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background.secondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  pinnedBadge: {
    backgroundColor: colors.primary.default + '20',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    alignSelf: 'flex-start',
    marginBottom: spacing.sm,
  },
  pinnedText: {
    fontSize: fontSize.xs,
    color: colors.primary.default,
    fontWeight: '600',
  },
  title: {
    fontSize: fontSize.lg,
    fontWeight: '600',
    color: colors.text.primary,
    marginBottom: spacing.md,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: spacing.sm,
  },
  author: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    fontWeight: '500',
    flexShrink: 1,
  },
  separator: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
    marginHorizontal: spacing.xs,
  },
  time: {
    fontSize: fontSize.sm,
    color: colors.text.muted,
  },
  commentBadge: {
    backgroundColor: colors.background.tertiary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  commentCount: {
    fontSize: fontSize.sm,
    color: colors.text.secondary,
    fontWeight: '500',
  },
});
