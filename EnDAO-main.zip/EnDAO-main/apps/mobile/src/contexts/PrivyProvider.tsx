import { PrivyProvider as BasePrivyProvider } from '@privy-io/expo';
import { ReactNode } from 'react';
import { privyLogger } from '../utils/dev-logger';

const PRIVY_APP_ID = process.env.EXPO_PUBLIC_PRIVY_APP_ID;
const PRIVY_CLIENT_ID = process.env.EXPO_PUBLIC_PRIVY_CLIENT_ID;

interface PrivyProviderProps {
  children: ReactNode;
}

export function PrivyProvider({ children }: PrivyProviderProps) {
  if (!PRIVY_APP_ID) {
    privyLogger.error('EXPO_PUBLIC_PRIVY_APP_ID is not set');
    return <>{children}</>;
  }

  if (!PRIVY_CLIENT_ID) {
    privyLogger.warn('EXPO_PUBLIC_PRIVY_CLIENT_ID is not set - required for mobile auth');
  }

  return (
    <BasePrivyProvider appId={PRIVY_APP_ID} clientId={PRIVY_CLIENT_ID}>
      {children}
    </BasePrivyProvider>
  );
}
