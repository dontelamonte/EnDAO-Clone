/**
 * Hooks Index
 *
 * Centralizes hook exports for easy imports.
 */

export { useAuth } from './useAuth';
export type { AuthUser, UseAuthReturn } from './useAuth';

export { useDAO } from './useDAO';

export { useProposals } from './useProposals';
export type { Proposal, ProposalStatus } from './useProposals';

export { useProposal } from './useProposal';

export { useSignedVote } from './useSignedVote';
export type { SignedVote, UseSignedVoteReturn } from './useSignedVote';

export { useNotifications } from './useNotifications';
export type { UseNotificationsReturn } from './useNotifications';

export { useCreateDAO } from './useCreateDAO';
export type {
  UseCreateDAOReturn,
  DAOFormData,
  OrganizationType,
  OrganizationTemplate,
} from './useCreateDAO';

export { useTreasury } from './useTreasury';
export type {
  TreasuryOverview,
  TreasuryToken,
  Transaction,
} from './useTreasury';

export { useUnifiedTreasury } from './useUnifiedTreasury';
export { usePaymentMethods } from './usePaymentMethods';
