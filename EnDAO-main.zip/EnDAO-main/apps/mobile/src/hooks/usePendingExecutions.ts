/**
 * usePendingExecutions Hook
 *
 * Fetches pending treasury executions that need signatures for a DAO.
 * Integrates caching for offline-first support.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';

export interface PendingExecution {
  executionId: string;
  proposalId: string;
  amount: string;
  recipient: string;
  currency: string;
  requiredSignatures: number;
  currentSignatures: number;
  hasUserSigned: boolean;
  safeTransactionHash: string;
  status: string;
  proposalTitle: string;
  createdAt: string;
}

interface UsePendingExecutionsReturn {
  executions: PendingExecution[];
  isOwner: boolean;
  isLoading: boolean;
  error: string | null;
  isStale: boolean;
  refetch: () => Promise<void>;
}

export function usePendingExecutions(
  daoId: string
): UsePendingExecutionsReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [executions, setExecutions] = useState<PendingExecution[]>([]);
  const [isOwner, setIsOwner] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isStale, setIsStale] = useState(false);

  const fetchExecutions = useCallback(async () => {
    if (!daoId) {
      setError('No DAO ID provided');
      setIsLoading(false);
      return;
    }

    // Cache key
    const cacheKey = `treasury_pending:${daoId}`;

    // Try cache first
    const cachedData = await cache.get<{
      executions: PendingExecution[];
      isOwner: boolean;
    }>(cacheKey);

    if (cachedData) {
      setExecutions(cachedData.executions);
      setIsOwner(cachedData.isOwner);
      setIsStale(true);
      setIsLoading(false);

      // If offline, return cached data
      if (!network.isConnected()) {
        return;
      }
    }

    // If offline and no cache, show error
    if (!network.isConnected() && !cachedData) {
      setError('No internet connection and no cached data available');
      setIsLoading(false);
      return;
    }

    // Fetch fresh data if online
    if (network.isConnected()) {
      setIsLoading(true);
      setError(null);

      try {
        const token = await getAccessToken();

        const response = await api.getPendingExecutions(token, daoId);

        if (response.error) {
          setError(response.error);
          return;
        }

        if (response.data) {
          setExecutions(response.data.executions);
          setIsOwner(response.data.isOwner);

          // Store fresh data in cache (shorter TTL since signatures change frequently)
          await cache.set(cacheKey, response.data, 5 * 60 * 1000); // 5 minutes
        }

        setIsStale(false);
      } catch (err) {
        daoLogger.error('usePendingExecutions fetch error:', err);
        setError(
          err instanceof Error
            ? err.message
            : 'Failed to load pending executions'
        );
      } finally {
        setIsLoading(false);
      }
    }
  }, [daoId, getAccessToken]);

  useEffect(() => {
    fetchExecutions();
  }, [fetchExecutions]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && isStale) {
      daoLogger.info('Network restored, refreshing pending executions');
      fetchExecutions();
    }
  }, [isOnline, isStale, fetchExecutions]);

  const refetch = useCallback(async () => {
    await fetchExecutions();
  }, [fetchExecutions]);

  return {
    executions,
    isOwner,
    isLoading,
    error,
    isStale,
    refetch,
  };
}
