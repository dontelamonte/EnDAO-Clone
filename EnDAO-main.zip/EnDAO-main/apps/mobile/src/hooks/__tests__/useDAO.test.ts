/**
 * useDAO Hook Tests
 *
 * Tests for the DAO data fetching hook including:
 * - Successful data fetch
 * - Error handling
 * - Cache-first behavior
 * - Network status handling
 */

import { renderHook, waitFor, act } from '@testing-library/react-native';
import { useDAO } from '../useDAO';

// Mock the API service
jest.mock('../../services/api', () => ({
  api: {
    getDAO: jest.fn(),
    getDAOStats: jest.fn(),
  },
}));

// Mock the cache service
jest.mock('../../services/cache', () => ({
  get: jest.fn().mockResolvedValue(null),
  set: jest.fn().mockResolvedValue(undefined),
  CACHE_TTL: {
    DAO_DETAIL: 300000,
  },
}));

// Mock the network service
jest.mock('../../services/network', () => ({
  network: {
    isConnected: jest.fn().mockReturnValue(true),
  },
  useNetworkStatus: () => ({
    isOnline: true,
    isOffline: false,
  }),
}));

// Mock the useAuth hook
jest.mock('../useAuth', () => ({
  useAuth: () => ({
    getAccessToken: jest.fn().mockResolvedValue('test-token'),
  }),
}));

// Mock the dev-logger
jest.mock('../../utils/dev-logger', () => ({
  daoLogger: {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  },
}));

// Import mocked modules for manipulation
import { api } from '../../services/api';
import * as cache from '../../services/cache';
import { network } from '../../services/network';

const mockApi = api as jest.Mocked<typeof api>;
const mockCache = cache as jest.Mocked<typeof cache>;
const mockNetwork = network as jest.Mocked<typeof network>;

describe('useDAO', () => {
  const mockDAO = {
    id: 'test-dao-123',
    name: 'Test DAO',
    slug: 'test-dao',
    description: 'A test DAO for unit testing',
    logoUrl: 'https://example.com/logo.png',
    userRole: 'member' as const,
  };

  const mockStats = {
    memberCount: 100,
    proposalCount: 25,
    activeProposalCount: 5,
    participationRate: 75.5,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    mockNetwork.isConnected.mockReturnValue(true);
    mockCache.get.mockResolvedValue(null);
  });

  it('fetches DAO data successfully', async () => {
    mockApi.getDAO.mockResolvedValueOnce({
      status: 200,
      data: mockDAO,
      error: null,
    });
    mockApi.getDAOStats.mockResolvedValueOnce({
      status: 200,
      data: mockStats,
      error: null,
    });

    const { result } = renderHook(() => useDAO('test-dao-123'));

    // Initially loading
    expect(result.current.isLoading).toBe(true);

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    expect(result.current.dao).toEqual(mockDAO);
    expect(result.current.stats).toEqual(mockStats);
    expect(result.current.error).toBeNull();
    expect(result.current.isStale).toBe(false);
  });

  it('handles API errors gracefully', async () => {
    mockApi.getDAO.mockResolvedValueOnce({
      status: 404,
      data: null,
      error: 'DAO not found',
    });
    mockApi.getDAOStats.mockResolvedValueOnce({
      status: 404,
      data: null,
      error: 'Stats not available',
    });

    const { result } = renderHook(() => useDAO('nonexistent-dao'));

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    expect(result.current.error).toBe('DAO not found');
    expect(result.current.dao).toBeNull();
  });

  it('returns cached data when available', async () => {
    mockCache.get.mockImplementation(async (key: string) => {
      if (key === 'dao:cached-dao') return mockDAO;
      if (key === 'dao_stats:cached-dao') return mockStats;
      return null;
    });

    mockApi.getDAO.mockResolvedValueOnce({
      status: 200,
      data: mockDAO,
      error: null,
    });
    mockApi.getDAOStats.mockResolvedValueOnce({
      status: 200,
      data: mockStats,
      error: null,
    });

    const { result } = renderHook(() => useDAO('cached-dao'));

    // Should immediately have cached data
    await waitFor(() => {
      expect(result.current.dao).toEqual(mockDAO);
    });

    // Should be marked as stale initially
    expect(result.current.isStale).toBe(true);

    // Should eventually refresh
    await waitFor(() => {
      expect(result.current.isStale).toBe(false);
    });
  });

  it('shows error when offline with no cache', async () => {
    mockNetwork.isConnected.mockReturnValue(false);
    mockCache.get.mockResolvedValue(null);

    const { result } = renderHook(() => useDAO('test-dao'));

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    expect(result.current.error).toBe(
      'No internet connection and no cached data available'
    );
  });

  it('returns cached data when offline', async () => {
    mockNetwork.isConnected.mockReturnValue(false);
    mockCache.get.mockImplementation(async (key: string) => {
      if (key === 'dao:offline-dao') return mockDAO;
      if (key === 'dao_stats:offline-dao') return mockStats;
      return null;
    });

    const { result } = renderHook(() => useDAO('offline-dao'));

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    expect(result.current.dao).toEqual(mockDAO);
    expect(result.current.stats).toEqual(mockStats);
    expect(result.current.isStale).toBe(true);
  });

  it('handles missing daoId', async () => {
    const { result } = renderHook(() => useDAO(''));

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    expect(result.current.error).toBe('No DAO ID provided');
  });

  it('supports refetch functionality', async () => {
    mockApi.getDAO.mockResolvedValue({
      status: 200,
      data: mockDAO,
      error: null,
    });
    mockApi.getDAOStats.mockResolvedValue({
      status: 200,
      data: mockStats,
      error: null,
    });

    const { result } = renderHook(() => useDAO('test-dao'));

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
    });

    // Clear call count
    mockApi.getDAO.mockClear();
    mockApi.getDAOStats.mockClear();

    // Trigger refetch
    await act(async () => {
      await result.current.refetch();
    });

    expect(mockApi.getDAO).toHaveBeenCalledTimes(1);
    expect(mockApi.getDAOStats).toHaveBeenCalledTimes(1);
  });
});
