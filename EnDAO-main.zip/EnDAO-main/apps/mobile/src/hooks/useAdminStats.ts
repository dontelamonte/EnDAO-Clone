/**
 * useAdminStats Hook
 *
 * Fetches admin-specific stats for a DAO.
 * Only fetches if user is an admin.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';

export interface AdminStats {
  memberCount: number;
  adminCount: number;
  proposalCount: number;
  activeProposalCount: number;
  passedProposalCount: number;
  rejectedProposalCount: number;
  recentMemberJoins: number;
  recentProposalCount: number;
  treasuryBalance: string | null;
}

interface UseAdminStatsReturn {
  stats: AdminStats | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useAdminStats(
  daoId: string,
  isAdmin: boolean
): UseAdminStatsReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStats = useCallback(async () => {
    // Don't fetch if user is not an admin
    if (!isAdmin) {
      setStats(null);
      setIsLoading(false);
      return;
    }

    if (!daoId) {
      setError('No DAO ID provided');
      setIsLoading(false);
      return;
    }

    // Cache key
    const cacheKey = `admin_stats:${daoId}`;

    // Try cache first
    const cachedStats = await cache.get<AdminStats>(cacheKey);

    if (cachedStats) {
      setStats(cachedStats);
      setIsLoading(false);

      // If offline, return cached data
      if (!network.isConnected()) {
        return;
      }
    }

    // If offline and no cache, show error
    if (!network.isConnected() && !cachedStats) {
      setError('No internet connection and no cached data available');
      setIsLoading(false);
      return;
    }

    // Fetch fresh data if online
    if (network.isConnected()) {
      setIsLoading(true);
      setError(null);

      try {
        const token = await getAccessToken();
        const response = await api.getAdminStats(token, daoId);

        if (response.error) {
          setError(response.error);
          return;
        }

        if (response.data) {
          setStats(response.data);
          // Store fresh data in cache (5 min TTL)
          await cache.set(cacheKey, response.data, 300000);
        }
      } catch (err) {
        daoLogger.error('useAdminStats fetch error:', err);
        setError(
          err instanceof Error ? err.message : 'Failed to load admin stats'
        );
      } finally {
        setIsLoading(false);
      }
    }
  }, [daoId, isAdmin, getAccessToken]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && stats === null && isAdmin) {
      daoLogger.info('Network restored, refreshing admin stats');
      fetchStats();
    }
  }, [isOnline, stats, isAdmin, fetchStats]);

  return {
    stats,
    isLoading,
    error,
    refetch: fetchStats,
  };
}
