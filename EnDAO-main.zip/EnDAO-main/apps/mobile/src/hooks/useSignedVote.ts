/**
 * useSignedVote Hook
 *
 * Provides functionality to sign votes using Privy embedded wallet with
 * EIP-712 typed data signatures (with personal_sign fallback).
 */

import { useState, useCallback } from 'react';
import { useEmbeddedWallet, usePrivy } from '@privy-io/expo';
import { useAuth } from './useAuth';
import { api } from '../services/api';
import { voteLogger } from '../utils/dev-logger';

// Vote message structure matching EIP-712 types
interface VoteMessage {
  proposalId: string;
  daoId: string;
  choice: string;
  voter: string;
  strength: number;
  timestamp: number;
  nonce: string;
}

// EIP-712 Domain for EnDAO
const VOTE_SIGNATURE_DOMAIN = {
  name: 'EnDAO',
  version: '1',
};

// EIP-712 Type definitions
const VOTE_SIGNATURE_TYPES = {
  Vote: [
    { name: 'proposalId', type: 'string' },
    { name: 'daoId', type: 'string' },
    { name: 'choice', type: 'string' },
    { name: 'voter', type: 'address' },
    { name: 'strength', type: 'uint256' },
    { name: 'timestamp', type: 'uint256' },
    { name: 'nonce', type: 'string' },
  ],
};

// Generate UUID v4
function generateNonce(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// Create human-readable message for personal_sign fallback
function createVoteMessageString(message: VoteMessage): string {
  return [
    'EnDAO Vote Signature',
    '',
    `Proposal: ${message.proposalId}`,
    `DAO: ${message.daoId}`,
    `Choice: ${message.choice}`,
    `Voter: ${message.voter}`,
    `Strength: ${message.strength}`,
    `Timestamp: ${message.timestamp}`,
    `Nonce: ${message.nonce}`,
  ].join('\n');
}

export interface SignedVote {
  message: VoteMessage;
  signature: string;
  walletAddress: string;
  signatureType: 'eip712' | 'personal_sign';
}

export interface UseSignedVoteReturn {
  signVote: (
    proposalId: string,
    daoId: string,
    choice: 'for' | 'against' | 'abstain',
    strength?: number
  ) => Promise<SignedVote | null>;
  submitSignedVote: (
    proposalId: string,
    signedVote: SignedVote,
    reason?: string
  ) => Promise<{ success: boolean; error?: string }>;
  isSigningVote: boolean;
  signError: string | null;
  hasWallet: boolean;
}

export function useSignedVote(): UseSignedVoteReturn {
  const { user } = usePrivy();
  const wallet = useEmbeddedWallet();
  const { getAccessToken } = useAuth();

  const [isSigningVote, setIsSigningVote] = useState(false);
  const [signError, setSignError] = useState<string | null>(null);

  // Check if user has a wallet
  const hasWallet = wallet.status === 'connected' && !!wallet.account;

  /**
   * Sign a vote using the embedded wallet
   * Tries EIP-712 first, falls back to personal_sign if needed
   */
  const signVote = useCallback(
    async (
      proposalId: string,
      daoId: string,
      choice: 'for' | 'against' | 'abstain',
      strength: number = 1
    ): Promise<SignedVote | null> => {
      if (!hasWallet || !wallet.account) {
        setSignError('No wallet connected');
        return null;
      }

      try {
        setIsSigningVote(true);
        setSignError(null);

        const walletAddress = wallet.account.address;

        // Create vote message
        const voteMessage: VoteMessage = {
          proposalId,
          daoId,
          choice,
          voter: walletAddress,
          strength,
          timestamp: Math.floor(Date.now() / 1000),
          nonce: generateNonce(),
        };

        let signature: string;
        let signatureType: 'eip712' | 'personal_sign';

        // Get the provider from embedded wallet
        const provider = await wallet.getProvider();

        // Try EIP-712 signing first
        try {
          const typedData = {
            domain: VOTE_SIGNATURE_DOMAIN,
            types: VOTE_SIGNATURE_TYPES,
            message: voteMessage,
            primaryType: 'Vote',
          };

          // Use eth_signTypedData_v4 via provider
          signature = await provider.request({
            method: 'eth_signTypedData_v4',
            params: [walletAddress, JSON.stringify(typedData)],
          });

          signatureType = 'eip712';
        } catch (eip712Error) {
          // Fallback to personal_sign
          voteLogger.warn(
            'EIP-712 signing failed, falling back to personal_sign:',
            eip712Error
          );

          const messageString = createVoteMessageString(voteMessage);

          // Use personal_sign via provider
          signature = await provider.request({
            method: 'personal_sign',
            params: [messageString, walletAddress],
          });

          signatureType = 'personal_sign';
        }

        const signedVote: SignedVote = {
          message: voteMessage,
          signature,
          walletAddress,
          signatureType,
        };

        return signedVote;
      } catch (error) {
        voteLogger.error('Error signing vote:', error);
        const errorMessage =
          error instanceof Error ? error.message : 'Failed to sign vote';
        setSignError(errorMessage);
        return null;
      } finally {
        setIsSigningVote(false);
      }
    },
    [hasWallet, wallet]
  );

  /**
   * Submit a signed vote to the API
   */
  const submitSignedVote = useCallback(
    async (
      proposalId: string,
      signedVote: SignedVote,
      reason?: string
    ): Promise<{ success: boolean; error?: string }> => {
      try {
        setIsSigningVote(true);
        setSignError(null);

        const token = await getAccessToken();

        const response = await api.submitSignedVote(token, proposalId, {
          message: signedVote.message,
          signature: signedVote.signature,
          walletAddress: signedVote.walletAddress,
          signatureType: signedVote.signatureType,
        });

        if (response.error) {
          setSignError(response.error);
          return { success: false, error: response.error };
        }

        return { success: true };
      } catch (error) {
        voteLogger.error('Error submitting signed vote:', error);
        const errorMessage =
          error instanceof Error ? error.message : 'Failed to submit vote';
        setSignError(errorMessage);
        return { success: false, error: errorMessage };
      } finally {
        setIsSigningVote(false);
      }
    },
    [getAccessToken]
  );

  return {
    signVote,
    submitSignedVote,
    isSigningVote,
    signError,
    hasWallet,
  };
}
