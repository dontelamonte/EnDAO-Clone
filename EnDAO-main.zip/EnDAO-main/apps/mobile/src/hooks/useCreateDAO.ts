/**
 * useCreateDAO Hook
 *
 * Manages the state and logic for the 3-step DAO creation wizard.
 * Handles form validation, step navigation, and API submission.
 */

import { useState, useCallback } from 'react';
import { Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import { daoLogger } from '../utils/dev-logger';

export type DAOCategory = 'Community' | 'Commerce';

export type OrganizationType =
  | 'nonprofit'
  | 'cooperative'
  | 'business'
  | 'community_org'
  | 'social_org'
  | 'general';

export interface OrganizationTemplate {
  type: OrganizationType;
  name: string;
  description: string;
  category: DAOCategory;
  icon: string;
}

export const ORGANIZATION_TEMPLATES: OrganizationTemplate[] = [
  {
    type: 'nonprofit',
    name: 'Nonprofit',
    description: 'Charitable organizations and foundations',
    category: 'Community',
    icon: '❤️',
  },
  {
    type: 'cooperative',
    name: 'Cooperative',
    description: 'Member-owned businesses and collectives',
    category: 'Commerce',
    icon: '🤝',
  },
  {
    type: 'business',
    name: 'Business',
    description: 'Companies and commercial enterprises',
    category: 'Commerce',
    icon: '💼',
  },
  {
    type: 'community_org',
    name: 'Community Org',
    description: 'Local groups and neighborhood associations',
    category: 'Community',
    icon: '🏘️',
  },
  {
    type: 'social_org',
    name: 'Social Org',
    description: 'Clubs, societies, and interest groups',
    category: 'Community',
    icon: '🎉',
  },
  {
    type: 'general',
    name: 'General',
    description: 'Other types of organizations',
    category: 'Community',
    icon: '🌟',
  },
];

export interface DAOFormData {
  // Step 1 - Template
  organizationType: OrganizationType | null;

  // Step 2 - Basic Info
  name: string;
  description: string;
  category: DAOCategory;

  // Step 3 - Review (no additional fields)
}

export interface UseCreateDAOReturn {
  // Form data
  formData: DAOFormData;
  updateField: <K extends keyof DAOFormData>(
    field: K,
    value: DAOFormData[K]
  ) => void;
  resetForm: () => void;

  // Step navigation
  currentStep: number;
  canGoNext: boolean;
  canGoBack: boolean;
  goNext: () => void;
  goBack: () => void;
  goToStep: (step: number) => void;

  // Validation
  errors: Partial<Record<keyof DAOFormData, string>>;
  validateStep: (step: number) => boolean;

  // Submission
  isSubmitting: boolean;
  submitDAO: () => Promise<void>;
}

const INITIAL_FORM_DATA: DAOFormData = {
  organizationType: null,
  name: '',
  description: '',
  category: 'Community',
};

export function useCreateDAO(): UseCreateDAOReturn {
  const { getAccessToken } = useAuth();
  const router = useRouter();

  const [formData, setFormData] = useState<DAOFormData>(INITIAL_FORM_DATA);
  const [currentStep, setCurrentStep] = useState(1);
  const [errors, setErrors] = useState<Partial<Record<keyof DAOFormData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateField = useCallback(
    <K extends keyof DAOFormData>(field: K, value: DAOFormData[K]) => {
      setFormData((prev) => ({ ...prev, [field]: value }));
      // Clear error when field is updated
      if (errors[field]) {
        setErrors((prev) => {
          const newErrors = { ...prev };
          delete newErrors[field];
          return newErrors;
        });
      }
    },
    [errors]
  );

  const resetForm = useCallback(() => {
    setFormData(INITIAL_FORM_DATA);
    setCurrentStep(1);
    setErrors({});
    setIsSubmitting(false);
  }, []);

  const validateStep = useCallback(
    (step: number): boolean => {
      const newErrors: Partial<Record<keyof DAOFormData, string>> = {};

      if (step === 1) {
        // Step 1: Template selection
        if (!formData.organizationType) {
          newErrors.organizationType = 'Please select an organization type';
        }
      } else if (step === 2) {
        // Step 2: Basic info
        if (!formData.name.trim()) {
          newErrors.name = 'DAO name is required';
        } else if (formData.name.trim().length < 3) {
          newErrors.name = 'DAO name must be at least 3 characters';
        } else if (formData.name.trim().length > 100) {
          newErrors.name = 'DAO name must be less than 100 characters';
        }

        if (!formData.description.trim()) {
          newErrors.description = 'Description is required';
        } else if (formData.description.trim().length < 10) {
          newErrors.description = 'Description must be at least 10 characters';
        } else if (formData.description.trim().length > 1000) {
          newErrors.description = 'Description must be less than 1000 characters';
        }

        if (!formData.category) {
          newErrors.category = 'Category is required';
        }
      }

      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
    },
    [formData]
  );

  const canGoNext = useCallback(() => {
    if (currentStep === 1) {
      return !!formData.organizationType;
    } else if (currentStep === 2) {
      return (
        formData.name.trim().length >= 3 &&
        formData.description.trim().length >= 10 &&
        !!formData.category
      );
    }
    return false;
  }, [currentStep, formData]);

  const canGoBack = currentStep > 1;

  const goNext = useCallback(() => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, 3));
    }
  }, [currentStep, validateStep]);

  const goBack = useCallback(() => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  }, []);

  const goToStep = useCallback((step: number) => {
    setCurrentStep(Math.max(1, Math.min(step, 3)));
  }, []);

  const submitDAO = useCallback(async () => {
    // Final validation
    if (!validateStep(1) || !validateStep(2)) {
      daoLogger.error('Final validation failed', { errors });
      Alert.alert('Validation Error', 'Please check your inputs and try again');
      return;
    }

    setIsSubmitting(true);

    try {
      const token = await getAccessToken();

      const payload = {
        name: formData.name.trim(),
        description: formData.description.trim(),
        category: formData.category,
        organizationType: formData.organizationType!,
        tags: [],
        joinPermission: 'open' as const,
      };

      daoLogger.info('Creating DAO', { payload });

      const response = await api.createDAO(token, payload);

      if (response.error || !response.data) {
        throw new Error(response.error || 'Failed to create DAO');
      }

      const newDaoId = response.data.id;
      daoLogger.info('DAO created successfully', { dao: response.data });

      Alert.alert('Success', 'Your DAO has been created successfully!', [
        {
          text: 'OK',
          onPress: () => {
            resetForm();
            router.replace(`/dao/${newDaoId}`);
          },
        },
      ]);
    } catch (error) {
      daoLogger.error('Failed to create DAO', error);
      const errorMessage =
        error instanceof Error ? error.message : 'Failed to create DAO';
      Alert.alert('Error', errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  }, [formData, validateStep, getAccessToken, resetForm, router, errors]);

  return {
    formData,
    updateField,
    resetForm,
    currentStep,
    canGoNext: canGoNext(),
    canGoBack,
    goNext,
    goBack,
    goToStep,
    errors,
    validateStep,
    isSubmitting,
    submitDAO,
  };
}
