import { useLoginWithEmail, useLoginWithSMS, usePrivy } from '@privy-io/expo';
import { useCallback, useMemo } from 'react';
import { authLogger } from '../utils/dev-logger';

export interface AuthUser {
  id: string;
  email?: string;
  phone?: string;
  walletAddress?: string;
}

export interface UseAuthReturn {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: () => Promise<void>;
  loginWithEmail: (email: string) => Promise<void>;
  loginWithSMS: (phone: string) => Promise<void>;
  logout: () => Promise<void>;
  getAccessToken: () => Promise<string | null>;
}

// Helper to extract account info from linked_accounts array
function extractUserInfo(user: {
  id: string;
  linked_accounts?: Array<{ type: string; address?: string; number?: string }>;
}) {
  const emailAccount = user.linked_accounts?.find((a) => a.type === 'email');
  const phoneAccount = user.linked_accounts?.find((a) => a.type === 'phone');
  const walletAccount = user.linked_accounts?.find((a) => a.type === 'wallet');

  return {
    id: user.id,
    email: emailAccount?.address,
    phone: phoneAccount?.number,
    walletAddress: walletAccount?.address,
  };
}

export function useAuth(): UseAuthReturn {
  const { user, isReady, logout: privyLogout, getAccessToken } = usePrivy();
  const { sendCode: sendEmailCode } = useLoginWithEmail();
  const { sendCode: sendSMSCode } = useLoginWithSMS();

  const isAuthenticated = !!user;
  const isLoading = !isReady;

  const authUser = useMemo<AuthUser | null>(() => {
    if (!user) return null;
    return extractUserInfo(user);
  }, [user]);

  const login = useCallback(async () => {
    // This triggers Privy's built-in login modal
    // For Expo, we typically use specific login methods
    authLogger.log('Use loginWithEmail or loginWithSMS for mobile login');
  }, []);

  const loginWithEmail = useCallback(
    async (email: string) => {
      try {
        // Send OTP code to email
        await sendEmailCode({ email });
        // Note: OTP verification is handled by Privy UI or separate verifyCode call
      } catch (error) {
        authLogger.error('Email login failed:', error);
        throw error;
      }
    },
    [sendEmailCode]
  );

  const loginWithSMS = useCallback(
    async (phone: string) => {
      try {
        // Send OTP code to phone
        await sendSMSCode({ phone });
        // Note: OTP verification is handled by Privy UI or separate verifyCode call
      } catch (error) {
        authLogger.error('SMS login failed:', error);
        throw error;
      }
    },
    [sendSMSCode]
  );

  const logout = useCallback(async () => {
    try {
      await privyLogout();
    } catch (error) {
      authLogger.error('Logout failed:', error);
      throw error;
    }
  }, [privyLogout]);

  const fetchAccessToken = useCallback(async (): Promise<string | null> => {
    try {
      const token = await getAccessToken();
      return token;
    } catch (error) {
      authLogger.error('Failed to get access token:', error);
      return null;
    }
  }, [getAccessToken]);

  return {
    user: authUser,
    isAuthenticated,
    isLoading,
    login,
    loginWithEmail,
    loginWithSMS,
    logout,
    getAccessToken: fetchAccessToken,
  };
}
