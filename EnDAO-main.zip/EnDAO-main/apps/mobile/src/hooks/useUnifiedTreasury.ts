/**
 * useUnifiedTreasury Hook
 *
 * Fetches unified treasury balance (fiat + crypto) and rail status for hybrid DAOs.
 * Integrates caching for offline-first support.
 */

import { useCallback, useEffect, useState } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';
import type {
  TreasuryRailsStatus,
  UnifiedTreasuryBalance,
} from '@endao/shared-types';

interface UnifiedTreasuryData {
  balance: UnifiedTreasuryBalance;
  rails: TreasuryRailsStatus | null;
}

interface UseUnifiedTreasuryReturn {
  data: UnifiedTreasuryData | null;
  isLoading: boolean;
  error: string | null;
  isStale: boolean;
  refetch: () => Promise<void>;
}

export function useUnifiedTreasury(daoId: string): UseUnifiedTreasuryReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [data, setData] = useState<UnifiedTreasuryData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isStale, setIsStale] = useState(false);

  const fetchUnifiedBalance = useCallback(async () => {
    if (!daoId) {
      setError('No DAO ID provided');
      setIsLoading(false);
      return;
    }

    const cacheKey = `unified_treasury:${daoId}`;

    // Try cache first
    const cachedData = await cache.get<UnifiedTreasuryData>(cacheKey);

    if (cachedData) {
      setData(cachedData);
      setIsStale(true);
      setIsLoading(false);

      if (!network.isConnected()) {
        return;
      }
    }

    // If offline and no cache, show error
    if (!network.isConnected() && !cachedData) {
      setError('No internet connection and no cached data available');
      setIsLoading(false);
      return;
    }

    // Fetch fresh data if online
    if (network.isConnected()) {
      setIsLoading(true);
      setError(null);

      try {
        const token = await getAccessToken();

        const response = await api.getUnifiedTreasuryBalance(token, daoId);
        daoLogger.debug('Unified Treasury API response:', {
          hasData: !!response.data,
          hasError: !!response.error,
        });

        if (response.error) {
          daoLogger.warn('Unified Treasury API error:', response.error);
          setError(response.error);
          return;
        }

        if (response.data) {
          setData(response.data as UnifiedTreasuryData);
          // Cache the data
          await cache.set(cacheKey, response.data, cache.CACHE_TTL.DAO_DETAIL);
        } else {
          setError('Treasury data unavailable');
        }

        setIsStale(false);
      } catch (err) {
        daoLogger.error('useUnifiedTreasury fetch error:', err);
        setError(
          err instanceof Error ? err.message : 'Failed to load treasury'
        );
      } finally {
        setIsLoading(false);
      }
    }
  }, [daoId, getAccessToken]);

  useEffect(() => {
    fetchUnifiedBalance();
  }, [fetchUnifiedBalance]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && isStale) {
      daoLogger.info('Network restored, refreshing unified treasury data');
      fetchUnifiedBalance();
    }
  }, [isOnline, isStale, fetchUnifiedBalance]);

  const refetch = useCallback(async () => {
    await fetchUnifiedBalance();
  }, [fetchUnifiedBalance]);

  return {
    data,
    isLoading,
    error,
    isStale,
    refetch,
  };
}
