/**
 * useMembers Hook
 *
 * Fetches DAO members with pagination and offline caching.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';

export interface Member {
  id: string;
  userId: string;
  displayName: string | null;
  avatarUrl: string | null;
  role: 'member' | 'admin' | 'owner';
  joinedAt: string;
}

interface UseMembersReturn {
  members: Member[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  loadMoreMembers: () => Promise<void>;
  hasMore: boolean;
  isLoadingMore: boolean;
  total: number;
}

export function useMembers(daoId: string): UseMembersReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [members, setMembers] = useState<Member[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [offset, setOffset] = useState(0);
  const [total, setTotal] = useState(0);

  const fetchMembers = useCallback(
    async (loadMore = false) => {
      if (!daoId) {
        setError('No DAO ID provided');
        setIsLoading(false);
        return;
      }

      const currentOffset = loadMore ? offset : 0;

      // Cache key for members
      const membersCacheKey = `members:${daoId}:${currentOffset}`;

      // Try cache first for initial load
      if (!loadMore) {
        const cachedMembers = await cache.get<{
          members: Member[];
          hasMore: boolean;
          total: number;
        }>(membersCacheKey);

        if (cachedMembers) {
          setMembers(cachedMembers.members);
          setHasMore(cachedMembers.hasMore);
          setTotal(cachedMembers.total);
          setIsLoading(false);

          // If offline, return cached data
          if (!network.isConnected()) {
            return;
          }
        }
      }

      // If offline, don't fetch
      if (!network.isConnected()) {
        if (!loadMore && members.length === 0) {
          setError('No internet connection and no cached members');
        }
        setIsLoading(false);
        return;
      }

      // Fetch fresh data if online
      if (network.isConnected()) {
        if (loadMore) {
          setIsLoadingMore(true);
        } else {
          setIsLoading(true);
        }
        setError(null);

        try {
          const token = await getAccessToken();

          const response = await api.getMembers(
            token,
            daoId,
            20,
            currentOffset
          );

          if (response.error) {
            setError(response.error);
            return;
          }

          if (response.data) {
            const { members: newMembers, hasMore: more, total: totalCount } = response.data;

            if (loadMore) {
              setMembers((prev) => [...prev, ...newMembers]);
              setOffset(currentOffset + newMembers.length);
            } else {
              setMembers(newMembers);
              setOffset(newMembers.length);
              // Cache initial members
              await cache.set(
                membersCacheKey,
                response.data,
                cache.CACHE_TTL.DAO_DETAIL
              );
            }

            setHasMore(more);
            setTotal(totalCount);
          }
        } catch (err) {
          daoLogger.error('useMembers fetch error:', err);
          setError(
            err instanceof Error ? err.message : 'Failed to load members'
          );
        } finally {
          if (loadMore) {
            setIsLoadingMore(false);
          } else {
            setIsLoading(false);
          }
        }
      }
    },
    [daoId, getAccessToken, offset, members.length]
  );

  useEffect(() => {
    fetchMembers();
  }, [fetchMembers]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && members.length === 0) {
      daoLogger.info('Network restored, refreshing members');
      fetchMembers();
    }
  }, [isOnline, members.length, fetchMembers]);

  const refetch = useCallback(async () => {
    setOffset(0);
    await fetchMembers();
  }, [fetchMembers]);

  const loadMoreMembers = useCallback(async () => {
    if (!isLoadingMore && hasMore) {
      await fetchMembers(true);
    }
  }, [isLoadingMore, hasMore, fetchMembers]);

  return {
    members,
    isLoading,
    error,
    refetch,
    loadMoreMembers,
    hasMore,
    isLoadingMore,
    total,
  };
}
