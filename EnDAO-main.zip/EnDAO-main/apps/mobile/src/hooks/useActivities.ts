/**
 * useActivities Hook
 *
 * Fetches DAO activities with pagination and offline caching.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';

export interface Activity {
  id: string;
  type: string;
  title: string;
  description?: string;
  userId: string;
  createdAt: string;
  data: Record<string, unknown>;
}

interface UseActivitiesReturn {
  activities: Activity[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  loadMore: () => Promise<void>;
  hasMore: boolean;
  isLoadingMore: boolean;
}

export function useActivities(daoId: string): UseActivitiesReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [offset, setOffset] = useState(0);

  const fetchActivities = useCallback(
    async (loadMore = false) => {
      if (!daoId) {
        setError('No DAO ID provided');
        setIsLoading(false);
        return;
      }

      const currentOffset = loadMore ? offset : 0;

      // Cache key for activities
      const activitiesCacheKey = `activities:${daoId}:${currentOffset}`;

      // Try cache first for initial load
      if (!loadMore) {
        const cachedActivities = await cache.get<{
          activities: Activity[];
          hasMore: boolean;
        }>(activitiesCacheKey);

        if (cachedActivities) {
          setActivities(cachedActivities.activities);
          setHasMore(cachedActivities.hasMore);
          setIsLoading(false);

          // If offline, return cached data
          if (!network.isConnected()) {
            return;
          }
        }
      }

      // If offline, don't fetch
      if (!network.isConnected()) {
        if (!loadMore && activities.length === 0) {
          setError('No internet connection and no cached activities');
        }
        setIsLoading(false);
        return;
      }

      // Fetch fresh data if online
      if (network.isConnected()) {
        if (loadMore) {
          setIsLoadingMore(true);
        } else {
          setIsLoading(true);
        }
        setError(null);

        try {
          const token = await getAccessToken();

          const response = await api.getActivities(
            token,
            daoId,
            20,
            currentOffset
          );

          if (response.error) {
            setError(response.error);
            return;
          }

          if (response.data) {
            const { activities: newActivities, hasMore: more } = response.data;

            if (loadMore) {
              setActivities((prev) => [...prev, ...newActivities]);
              setOffset(currentOffset + newActivities.length);
            } else {
              setActivities(newActivities);
              setOffset(newActivities.length);
              // Cache initial activities
              await cache.set(
                activitiesCacheKey,
                response.data,
                cache.CACHE_TTL.DAO_DETAIL
              );
            }

            setHasMore(more);
          }
        } catch (err) {
          daoLogger.error('useActivities fetch error:', err);
          setError(
            err instanceof Error ? err.message : 'Failed to load activities'
          );
        } finally {
          if (loadMore) {
            setIsLoadingMore(false);
          } else {
            setIsLoading(false);
          }
        }
      }
    },
    [daoId, getAccessToken, offset, activities.length]
  );

  useEffect(() => {
    fetchActivities();
  }, [fetchActivities]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && activities.length === 0) {
      daoLogger.info('Network restored, refreshing activities');
      fetchActivities();
    }
  }, [isOnline, activities.length, fetchActivities]);

  const refetch = useCallback(async () => {
    setOffset(0);
    await fetchActivities();
  }, [fetchActivities]);

  const loadMore = useCallback(async () => {
    if (!isLoadingMore && hasMore) {
      await fetchActivities(true);
    }
  }, [isLoadingMore, hasMore, fetchActivities]);

  return {
    activities,
    isLoading,
    error,
    refetch,
    loadMore,
    hasMore,
    isLoadingMore,
  };
}
