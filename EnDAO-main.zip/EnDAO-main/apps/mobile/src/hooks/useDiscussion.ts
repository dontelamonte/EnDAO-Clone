/**
 * useDiscussion Hook
 *
 * Fetches single discussion details with comments.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import { devLogger } from '../utils/dev-logger';

const logger = devLogger('Discussion');

export interface DiscussionDetails {
  id: string;
  title: string;
  content: string;
  authorId: string;
  authorName: string | null;
  commentCount: number;
  isPinned: boolean;
  status: 'active' | 'archived' | 'converted';
  createdAt: string;
  lastActivityAt: string | null;
}

export interface DiscussionComment {
  id: string;
  content: string;
  authorId: string;
  authorName: string | null;
  parentId: string | null;
  createdAt: string;
  isEdited: boolean;
}

interface UseDiscussionReturn {
  discussion: DiscussionDetails | null;
  comments: DiscussionComment[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useDiscussion(discussionId: string): UseDiscussionReturn {
  const { getAccessToken } = useAuth();
  const [discussion, setDiscussion] = useState<DiscussionDetails | null>(null);
  const [comments, setComments] = useState<DiscussionComment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!discussionId) {
      setError('No discussion ID provided');
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const token = await getAccessToken();
      const response = await api.getDiscussion(token, discussionId);

      if (response.error) {
        setError(response.error);
        return;
      }

      if (response.data) {
        setDiscussion(response.data.discussion);
        setComments(response.data.comments);
      }
    } catch (err) {
      logger.error('useDiscussion fetch error:', err);
      setError(
        err instanceof Error ? err.message : 'Failed to load discussion'
      );
    } finally {
      setIsLoading(false);
    }
  }, [discussionId, getAccessToken]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    discussion,
    comments,
    isLoading,
    error,
    refetch: fetchData,
  };
}
