import { useState, useCallback, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import { apiLogger } from '../utils/dev-logger';

export interface ProfileFormData {
  username?: string;
  displayName?: string;
  bio?: string;
  avatarUrl?: string;
}

export interface UserProfile {
  id: string;
  username?: string;
  displayName: string;
  bio?: string;
  email?: string;
  avatarUrl?: string;
}

export interface UseProfileEditReturn {
  profile: UserProfile | null;
  formData: ProfileFormData;
  isLoading: boolean;
  isSaving: boolean;
  isUploadingAvatar: boolean;
  error: string | null;
  avatarError: string | null;
  updateField: (field: keyof ProfileFormData, value: string) => void;
  uploadAvatar: (imageUri: string) => Promise<boolean>;
  save: () => Promise<boolean>;
  reset: () => void;
}

export function useProfileEdit(): UseProfileEditReturn {
  const { getAccessToken } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [formData, setFormData] = useState<ProfileFormData>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [avatarError, setAvatarError] = useState<string | null>(null);

  // Load profile on mount
  useEffect(() => {
    let isMounted = true;

    const loadProfile = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const token = await getAccessToken();
        const response = await api.getProfile(token);

        if (!isMounted) return;

        if (response.error) {
          setError(response.error);
          apiLogger.error('Failed to load profile:', response.error);
          return;
        }

        if (response.data) {
          setProfile(response.data as UserProfile);
          // Initialize form with current values
          setFormData({
            username: response.data.username || '',
            displayName: response.data.displayName || '',
            bio: (response.data as UserProfile).bio || '',
            avatarUrl: (response.data as UserProfile).avatarUrl || '',
          });
        }
      } catch (err) {
        if (!isMounted) return;
        const errorMsg = err instanceof Error ? err.message : 'Failed to load profile';
        setError(errorMsg);
        apiLogger.error('Profile load error:', err);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    loadProfile();

    return () => {
      isMounted = false;
    };
  }, [getAccessToken]);

  const updateField = useCallback((field: keyof ProfileFormData, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  }, []);

  const uploadAvatar = useCallback(
    async (imageUri: string): Promise<boolean> => {
      try {
        setIsUploadingAvatar(true);
        setAvatarError(null);

        const token = await getAccessToken();

        apiLogger.log('Starting avatar upload', { imageUri });

        const response = await api.uploadAvatar(token, imageUri);

        if (response.error) {
          setAvatarError(response.error);
          apiLogger.error('Failed to upload avatar:', response.error);
          return false;
        }

        if (response.data) {
          const avatarUrl = response.data.url;

          // Update formData with new avatar URL
          setFormData((prev) => ({
            ...prev,
            avatarUrl,
          }));

          // Update profile immediately to show the new avatar
          setProfile((prev) =>
            prev
              ? {
                  ...prev,
                  avatarUrl,
                }
              : null
          );

          // Save the avatar URL to the profile in the backend
          const updateResponse = await api.updateProfile(token, { avatarUrl });

          if (updateResponse.error) {
            apiLogger.error('Failed to save avatar URL to profile:', updateResponse.error);
            // Don't revert the UI change, avatar is uploaded successfully
            // The URL will be saved on the next profile save
          } else {
            apiLogger.log('Avatar uploaded and saved successfully');
          }

          return true;
        }

        return false;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Failed to upload avatar';
        setAvatarError(errorMsg);
        apiLogger.error('Avatar upload error:', err);
        return false;
      } finally {
        setIsUploadingAvatar(false);
      }
    },
    [getAccessToken]
  );

  const save = useCallback(async (): Promise<boolean> => {
    try {
      setIsSaving(true);
      setError(null);

      const token = await getAccessToken();

      // Only send fields that have values
      const updateData: Partial<ProfileFormData> = {};
      if (formData.username !== undefined && formData.username !== '') {
        updateData.username = formData.username;
      }
      if (formData.displayName !== undefined && formData.displayName !== '') {
        updateData.displayName = formData.displayName;
      }
      if (formData.bio !== undefined) {
        updateData.bio = formData.bio;
      }
      if (formData.avatarUrl !== undefined) {
        updateData.avatarUrl = formData.avatarUrl;
      }

      const response = await api.updateProfile(token, updateData);

      if (response.error) {
        setError(response.error);
        apiLogger.error('Failed to save profile:', response.error);
        return false;
      }

      if (response.data) {
        setProfile(response.data as UserProfile);
        apiLogger.log('Profile saved successfully');
        return true;
      }

      return false;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to save profile';
      setError(errorMsg);
      apiLogger.error('Profile save error:', err);
      return false;
    } finally {
      setIsSaving(false);
    }
  }, [formData, getAccessToken]);

  const reset = useCallback(() => {
    if (profile) {
      setFormData({
        username: profile.username || '',
        displayName: profile.displayName || '',
        bio: profile.bio || '',
        avatarUrl: profile.avatarUrl || '',
      });
      setError(null);
      setAvatarError(null);
    }
  }, [profile]);

  return {
    profile,
    formData,
    isLoading,
    isSaving,
    isUploadingAvatar,
    error,
    avatarError,
    updateField,
    uploadAvatar,
    save,
    reset,
  };
}
