/**
 * useProposals Hook
 *
 * Fetches proposals list for a DAO with optional status filtering.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import { proposalLogger } from '../utils/dev-logger';

export interface Proposal {
  id: string;
  title: string;
  status: string;
  description?: string;
  votingStartTime?: string;
  votingEndTime?: string;
  creatorId?: string;
  votingType?: string;
}

export type ProposalStatus =
  | 'all'
  | 'active'
  | 'passed'
  | 'rejected'
  | 'pending';

interface UseProposalsReturn {
  proposals: Proposal[];
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
  refetch: (showRefresh?: boolean) => Promise<void>;
  setStatusFilter: (status: ProposalStatus) => void;
  statusFilter: ProposalStatus;
}

export function useProposals(daoId: string): UseProposalsReturn {
  const { getAccessToken } = useAuth();
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<ProposalStatus>('all');

  const fetchData = useCallback(
    async (showRefresh = false) => {
      if (!daoId) {
        setError('No DAO ID provided');
        setIsLoading(false);
        return;
      }

      if (showRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        const token = await getAccessToken();
        const apiStatus = statusFilter === 'all' ? undefined : statusFilter;
        const response = await api.getProposals(token, daoId, apiStatus);

        if (response.error) {
          setError(response.error);
          return;
        }

        if (response.data) {
          setProposals(response.data);
        }
      } catch (err) {
        proposalLogger.error('useProposals fetch error:', err);
        setError(
          err instanceof Error ? err.message : 'Failed to load proposals'
        );
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [daoId, statusFilter, getAccessToken]
  );

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSetStatusFilter = useCallback((status: ProposalStatus) => {
    setStatusFilter(status);
  }, []);

  return {
    proposals,
    isLoading,
    isRefreshing,
    error,
    refetch: fetchData,
    setStatusFilter: handleSetStatusFilter,
    statusFilter,
  };
}
