/**
 * EnDAO Mobile Notifications Hook
 *
 * Manages push notification registration, preferences, and deep linking.
 * Automatically registers device on login and handles notification taps.
 */

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'expo-router';
import * as Notifications from 'expo-notifications';
import {
  notifications,
  NotificationPreferences,
  DEFAULT_PREFS,
} from '../services/notifications';
import { useAuth } from './useAuth';

export interface UseNotificationsReturn {
  isRegistered: boolean;
  preferences: NotificationPreferences;
  isLoading: boolean;
  updatePreferences: (
    prefs: Partial<NotificationPreferences>
  ) => Promise<boolean>;
  refreshPreferences: () => Promise<void>;
}

export function useNotifications(): UseNotificationsReturn {
  const { isAuthenticated, getAccessToken } = useAuth();
  const router = useRouter();

  const [isRegistered, setIsRegistered] = useState(false);
  const [preferences, setPreferences] =
    useState<NotificationPreferences>(DEFAULT_PREFS);
  const [isLoading, setIsLoading] = useState(true);
  const [deviceId, setDeviceId] = useState<string | null>(null);

  /**
   * Handle notification tap - navigate to appropriate screen
   */
  const handleNotificationTap = useCallback(
    (response: Notifications.NotificationResponse) => {
      const data = response.notification.request.content.data;

      // Clear badge when user taps notification
      notifications.clearBadge();

      // Navigate based on notification type
      if (data?.proposalId) {
        // Navigate to proposal detail
        router.push(`/proposal/${data.proposalId}`);
      } else if (data?.daoId) {
        // Navigate to DAO detail
        router.push(`/dao/${data.daoId}`);
      }
    },
    [router]
  );

  /**
   * Handle foreground notification - just log for now
   */
  const handleForegroundNotification = useCallback(
    (notification: Notifications.Notification) => {
      console.log('Received foreground notification:', notification);
    },
    []
  );

  /**
   * Register device for push notifications
   */
  const registerDevice = useCallback(async () => {
    try {
      const token = await getAccessToken();
      const result = await notifications.register(token);

      if (result.success && result.deviceId) {
        setIsRegistered(true);
        setDeviceId(result.deviceId);
        console.log('Device registered for push notifications');
      } else {
        console.warn('Failed to register device');
      }
    } catch (error) {
      console.error('Device registration error:', error);
    }
  }, [getAccessToken]);

  /**
   * Unregister device on logout
   */
  const unregisterDevice = useCallback(async () => {
    if (!deviceId) return;

    try {
      const token = await getAccessToken();
      await notifications.unregister(token, deviceId);
      setIsRegistered(false);
      setDeviceId(null);
      console.log('Device unregistered from push notifications');
    } catch (error) {
      console.error('Device unregistration error:', error);
    }
  }, [getAccessToken, deviceId]);

  /**
   * Load notification preferences from backend
   */
  const refreshPreferences = useCallback(async () => {
    setIsLoading(true);
    try {
      const token = await getAccessToken();
      const prefs = await notifications.getPreferences(token);
      setPreferences(prefs);
    } catch (error) {
      console.error('Failed to load notification preferences:', error);
      setPreferences(DEFAULT_PREFS);
    } finally {
      setIsLoading(false);
    }
  }, [getAccessToken]);

  /**
   * Update notification preferences
   */
  const updatePrefs = useCallback(
    async (prefs: Partial<NotificationPreferences>): Promise<boolean> => {
      try {
        const token = await getAccessToken();
        const success = await notifications.updatePreferences(token, prefs);

        if (success) {
          // Optimistically update local state
          setPreferences((prev) => ({ ...prev, ...prefs }));
          return true;
        }
        return false;
      } catch (error) {
        console.error('Failed to update notification preferences:', error);
        return false;
      }
    },
    [getAccessToken]
  );

  /**
   * Register device when user logs in
   */
  useEffect(() => {
    if (isAuthenticated && !isRegistered) {
      registerDevice();
      refreshPreferences();
    }
  }, [isAuthenticated, isRegistered, registerDevice, refreshPreferences]);

  /**
   * Unregister device when user logs out
   */
  useEffect(() => {
    if (!isAuthenticated && isRegistered) {
      unregisterDevice();
    }
  }, [isAuthenticated, isRegistered, unregisterDevice]);

  /**
   * Set up notification listeners
   */
  useEffect(() => {
    // Listen for notification taps (when app is backgrounded or closed)
    const tapSubscription = notifications.addNotificationResponseListener(
      handleNotificationTap
    );

    // Listen for foreground notifications
    const foregroundSubscription = notifications.addNotificationListener(
      handleForegroundNotification
    );

    // Clean up listeners on unmount
    return () => {
      tapSubscription.remove();
      foregroundSubscription.remove();
    };
  }, [handleNotificationTap, handleForegroundNotification]);

  return {
    isRegistered,
    preferences,
    isLoading,
    updatePreferences: updatePrefs,
    refreshPreferences,
  };
}
