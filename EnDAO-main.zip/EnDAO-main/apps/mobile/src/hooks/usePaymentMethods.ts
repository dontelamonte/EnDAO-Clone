/**
 * usePaymentMethods Hook
 *
 * Fetches available payment methods for a DAO (card vs crypto).
 * Used in donation flow to show payment options.
 */

import { useCallback, useEffect, useState } from 'react';
import { api } from '../services/api';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';
import type {
  AvailablePaymentMethod,
  DonationPaymentMethod,
} from '@endao/shared-types';

interface PaymentMethodsData {
  daoId: string;
  methods: AvailablePaymentMethod[];
  defaultMethod: DonationPaymentMethod;
}

interface UsePaymentMethodsReturn {
  methods: AvailablePaymentMethod[];
  defaultMethod: DonationPaymentMethod | null;
  isLoading: boolean;
  error: string | null;
  isStale: boolean;
  refetch: () => Promise<void>;
}

export function usePaymentMethods(daoId: string): UsePaymentMethodsReturn {
  const { isOnline } = useNetworkStatus();
  const [methods, setMethods] = useState<AvailablePaymentMethod[]>([]);
  const [defaultMethod, setDefaultMethod] =
    useState<DonationPaymentMethod | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isStale, setIsStale] = useState(false);

  const fetchPaymentMethods = useCallback(async () => {
    if (!daoId) {
      setError('No DAO ID provided');
      setIsLoading(false);
      return;
    }

    const cacheKey = `payment_methods:${daoId}`;

    // Try cache first
    const cachedData = await cache.get<PaymentMethodsData>(cacheKey);

    if (cachedData) {
      setMethods(cachedData.methods);
      setDefaultMethod(cachedData.defaultMethod);
      setIsStale(true);
      setIsLoading(false);

      if (!network.isConnected()) {
        return;
      }
    }

    // If offline and no cache, show error
    if (!network.isConnected() && !cachedData) {
      setError('No internet connection and no cached data available');
      setIsLoading(false);
      return;
    }

    // Fetch fresh data if online
    if (network.isConnected()) {
      setIsLoading(true);
      setError(null);

      try {
        const response = await api.getPaymentMethods(daoId);
        daoLogger.debug('Payment Methods API response:', {
          hasData: !!response.data,
          hasError: !!response.error,
        });

        if (response.error) {
          daoLogger.warn('Payment Methods API error:', response.error);
          setError(response.error);
          return;
        }

        if (response.data) {
          setMethods(response.data.methods);
          setDefaultMethod(response.data.defaultMethod);
          // Cache the data
          await cache.set(cacheKey, response.data, cache.CACHE_TTL.DAO_DETAIL);
        } else {
          setError('Payment methods unavailable');
        }

        setIsStale(false);
      } catch (err) {
        daoLogger.error('usePaymentMethods fetch error:', err);
        setError(
          err instanceof Error ? err.message : 'Failed to load payment methods'
        );
      } finally {
        setIsLoading(false);
      }
    }
  }, [daoId]);

  useEffect(() => {
    fetchPaymentMethods();
  }, [fetchPaymentMethods]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && isStale) {
      daoLogger.info('Network restored, refreshing payment methods');
      fetchPaymentMethods();
    }
  }, [isOnline, isStale, fetchPaymentMethods]);

  const refetch = useCallback(async () => {
    await fetchPaymentMethods();
  }, [fetchPaymentMethods]);

  return {
    methods,
    defaultMethod,
    isLoading,
    error,
    isStale,
    refetch,
  };
}
