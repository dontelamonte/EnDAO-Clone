/**
 * useProposal Hook
 *
 * Fetches single proposal details and vote eligibility.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import { proposalLogger } from '../utils/dev-logger';

interface ProposalDetails {
  id: string;
  title: string;
  description: string;
  status: string;
  votingStartTime?: string;
  votingEndTime?: string;
  creatorId?: string;
  votingType?: string;
  daoId: string;
  results?: {
    for: number;
    against: number;
    abstain: number;
    quorumReached: boolean;
    thresholdMet: boolean;
  };
}

interface VoteEligibility {
  canVote: boolean;
  reason?: string;
  hasVoted?: boolean;
  currentVote?: {
    choice: string;
    voteStrength?: number;
    isSigned?: boolean;
  };
}

interface UseProposalReturn {
  proposal: ProposalDetails | null;
  voteEligibility: VoteEligibility | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useProposal(proposalId: string): UseProposalReturn {
  const { getAccessToken } = useAuth();
  const [proposal, setProposal] = useState<ProposalDetails | null>(null);
  const [voteEligibility, setVoteEligibility] =
    useState<VoteEligibility | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!proposalId) {
      setError('No proposal ID provided');
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const token = await getAccessToken();

      // Fetch proposal details and vote eligibility in parallel
      const [proposalResponse, eligibilityResponse] = await Promise.all([
        api.getProposal(token, proposalId),
        api.canVote(token, proposalId),
      ]);

      if (proposalResponse.error) {
        setError(proposalResponse.error);
        return;
      }

      if (proposalResponse.data) {
        setProposal(proposalResponse.data);
      }

      if (eligibilityResponse.data) {
        setVoteEligibility(eligibilityResponse.data);
      }
    } catch (err) {
      proposalLogger.error('useProposal fetch error:', err);
      setError(err instanceof Error ? err.message : 'Failed to load proposal');
    } finally {
      setIsLoading(false);
    }
  }, [proposalId, getAccessToken]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    proposal,
    voteEligibility,
    isLoading,
    error,
    refetch: fetchData,
  };
}
