/**
 * useDiscussions Hook
 *
 * Fetches discussions list for a DAO with optional status filtering.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import { devLogger } from '../utils/dev-logger';

const logger = devLogger('Discussions');

export interface Discussion {
  id: string;
  title: string;
  content: string;
  authorId: string;
  authorName: string | null;
  commentCount: number;
  isPinned: boolean;
  status: 'active' | 'archived' | 'converted';
  createdAt: string;
  lastActivityAt: string | null;
}

export type DiscussionStatus = 'all' | 'active' | 'archived' | 'converted';

interface UseDiscussionsReturn {
  discussions: Discussion[];
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
  refetch: (showRefresh?: boolean) => Promise<void>;
  setStatusFilter: (status: DiscussionStatus) => void;
  statusFilter: DiscussionStatus;
}

export function useDiscussions(daoId: string): UseDiscussionsReturn {
  const { getAccessToken } = useAuth();
  const [discussions, setDiscussions] = useState<Discussion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<DiscussionStatus>('all');

  const fetchData = useCallback(
    async (showRefresh = false) => {
      if (!daoId) {
        setError('No DAO ID provided');
        setIsLoading(false);
        return;
      }

      if (showRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        const token = await getAccessToken();
        const apiStatus = statusFilter === 'all' ? undefined : statusFilter;
        const response = await api.getDiscussions(token, daoId, apiStatus);

        if (response.error) {
          setError(response.error);
          return;
        }

        if (response.data) {
          setDiscussions(response.data);
        }
      } catch (err) {
        logger.error('useDiscussions fetch error:', err);
        setError(
          err instanceof Error ? err.message : 'Failed to load discussions'
        );
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [daoId, statusFilter, getAccessToken]
  );

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSetStatusFilter = useCallback((status: DiscussionStatus) => {
    setStatusFilter(status);
  }, []);

  return {
    discussions,
    isLoading,
    isRefreshing,
    error,
    refetch: fetchData,
    setStatusFilter: handleSetStatusFilter,
    statusFilter,
  };
}
