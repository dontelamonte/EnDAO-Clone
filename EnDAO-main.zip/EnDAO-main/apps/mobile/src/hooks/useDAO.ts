/**
 * useDAO Hook
 *
 * Fetches DAO details and stats for the DAO detail screen.
 * Integrates caching for offline-first support.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';

interface DAODetails {
  id: string;
  name: string;
  slug: string;
  description?: string;
  logoUrl?: string;
  userRole?: 'member' | 'admin' | 'owner';
}

interface DAOStats {
  memberCount: number;
  proposalCount: number;
  activeProposalCount: number;
  participationRate: number;
}

interface UseDAOReturn {
  dao: DAODetails | null;
  stats: DAOStats | null;
  isLoading: boolean;
  error: string | null;
  isStale: boolean;
  refetch: () => Promise<void>;
}

export function useDAO(daoId: string): UseDAOReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [dao, setDao] = useState<DAODetails | null>(null);
  const [stats, setStats] = useState<DAOStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isStale, setIsStale] = useState(false);

  const fetchData = useCallback(async () => {
    if (!daoId) {
      setError('No DAO ID provided');
      setIsLoading(false);
      return;
    }

    // Cache keys
    const daoCacheKey = `dao:${daoId}`;
    const statsCacheKey = `dao_stats:${daoId}`;

    // Try cache first
    const cachedDao = await cache.get<DAODetails>(daoCacheKey);
    const cachedStats = await cache.get<DAOStats>(statsCacheKey);

    if (cachedDao && cachedStats) {
      setDao(cachedDao);
      setStats(cachedStats);
      setIsStale(true);
      setIsLoading(false);

      // If offline, return cached data
      if (!network.isConnected()) {
        return;
      }
    }

    // If offline and no cache, show error
    if (!network.isConnected() && (!cachedDao || !cachedStats)) {
      setError('No internet connection and no cached data available');
      setIsLoading(false);
      return;
    }

    // Fetch fresh data if online
    if (network.isConnected()) {
      setIsLoading(true);
      setError(null);

      try {
        const token = await getAccessToken();

        // Fetch DAO details and stats in parallel
        const [daoResponse, statsResponse] = await Promise.all([
          api.getDAO(token, daoId),
          api.getDAOStats(token, daoId),
        ]);

        if (daoResponse.error) {
          setError(daoResponse.error);
          return;
        }

        if (daoResponse.data) {
          setDao(daoResponse.data);
          // Store fresh data in cache
          await cache.set(
            daoCacheKey,
            daoResponse.data,
            cache.CACHE_TTL.DAO_DETAIL
          );
        }

        if (statsResponse.data) {
          setStats(statsResponse.data);
          // Store fresh stats in cache
          await cache.set(
            statsCacheKey,
            statsResponse.data,
            cache.CACHE_TTL.DAO_DETAIL
          );
        }

        setIsStale(false);
      } catch (err) {
        daoLogger.error('useDAO fetch error:', err);
        setError(err instanceof Error ? err.message : 'Failed to load DAO');
      } finally {
        setIsLoading(false);
      }
    }
  }, [daoId, getAccessToken]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && isStale) {
      daoLogger.info('Network restored, refreshing DAO data');
      fetchData();
    }
  }, [isOnline, isStale, fetchData]);

  return {
    dao,
    stats,
    isLoading,
    error,
    isStale,
    refetch: fetchData,
  };
}
