/**
 * useTreasury Hook
 *
 * Fetches treasury overview and transaction history for a DAO.
 * Integrates caching for offline-first support.
 */

import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { useAuth } from './useAuth';
import * as cache from '../services/cache';
import { network, useNetworkStatus } from '../services/network';
import { daoLogger } from '../utils/dev-logger';

export interface TreasuryToken {
  symbol: string;
  balance: string;
  balanceUsd: string | null;
}

export interface TreasuryOverview {
  address: string | null;
  balance: string;
  balanceUsd: string | null;
  tokens: TreasuryToken[];
  isConfigured: boolean;
}

export interface Transaction {
  id: string;
  type: 'incoming' | 'outgoing';
  amount: string;
  tokenSymbol: string;
  from: string;
  to: string;
  status: 'pending' | 'confirmed' | 'failed';
  timestamp: string;
  txHash: string | null;
}

interface UseTreasuryReturn {
  treasury: TreasuryOverview | null;
  transactions: Transaction[];
  isLoading: boolean;
  error: string | null;
  isStale: boolean;
  refetch: () => Promise<void>;
  loadMoreTransactions: () => Promise<void>;
  hasMore: boolean;
  isLoadingMore: boolean;
}

export function useTreasury(daoId: string): UseTreasuryReturn {
  const { getAccessToken } = useAuth();
  const { isOnline } = useNetworkStatus();
  const [treasury, setTreasury] = useState<TreasuryOverview | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isStale, setIsStale] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [offset, setOffset] = useState(0);

  const fetchTreasury = useCallback(async () => {
    if (!daoId) {
      setError('No DAO ID provided');
      setIsLoading(false);
      return;
    }

    // Cache key
    const treasuryCacheKey = `treasury:${daoId}`;

    // Try cache first
    const cachedTreasury = await cache.get<TreasuryOverview>(treasuryCacheKey);

    if (cachedTreasury) {
      setTreasury(cachedTreasury);
      setIsStale(true);
      setIsLoading(false);

      // If offline, return cached data
      if (!network.isConnected()) {
        return;
      }
    }

    // If offline and no cache, show error
    if (!network.isConnected() && !cachedTreasury) {
      setError('No internet connection and no cached data available');
      setIsLoading(false);
      return;
    }

    // Fetch fresh data if online
    if (network.isConnected()) {
      setIsLoading(true);
      setError(null);

      try {
        const token = await getAccessToken();

        const response = await api.getTreasury(token, daoId);
        daoLogger.debug('Treasury API response:', {
          hasData: !!response.data,
          hasError: !!response.error,
          status: response.status,
          error: response.error,
        });

        if (response.error) {
          daoLogger.warn('Treasury API error:', response.error);
          setError(response.error);
          return;
        }

        if (response.data) {
          daoLogger.debug('Setting treasury data:', response.data);
          setTreasury(response.data);
          // Store fresh data in cache
          await cache.set(
            treasuryCacheKey,
            response.data,
            cache.CACHE_TTL.DAO_DETAIL
          );
        } else {
          // No data returned - set explicit error
          daoLogger.warn('Treasury API returned success but no data');
          setError('Treasury data unavailable');
        }

        setIsStale(false);
      } catch (err) {
        daoLogger.error('useTreasury fetch error:', err);
        setError(
          err instanceof Error ? err.message : 'Failed to load treasury'
        );
      } finally {
        setIsLoading(false);
      }
    }
  }, [daoId, getAccessToken]);

  const fetchTransactions = useCallback(
    async (loadMore = false) => {
      if (!daoId) {
        return;
      }

      const currentOffset = loadMore ? offset : 0;

      // Cache key for transactions
      const txCacheKey = `treasury_tx:${daoId}:${currentOffset}`;

      // Try cache first for initial load
      if (!loadMore) {
        const cachedTx = await cache.get<{
          transactions: Transaction[];
          hasMore: boolean;
        }>(txCacheKey);

        if (cachedTx) {
          setTransactions(cachedTx.transactions);
          setHasMore(cachedTx.hasMore);
          setIsStale(true);

          // If offline, return cached data
          if (!network.isConnected()) {
            return;
          }
        }
      }

      // If offline, don't fetch
      if (!network.isConnected()) {
        if (!loadMore && transactions.length === 0) {
          setError('No internet connection and no cached transactions');
        }
        return;
      }

      // Fetch fresh data if online
      if (network.isConnected()) {
        if (loadMore) {
          setIsLoadingMore(true);
        } else {
          setIsLoading(true);
        }
        setError(null);

        try {
          const token = await getAccessToken();

          const response = await api.getTreasuryTransactions(
            token,
            daoId,
            20,
            currentOffset
          );

          if (response.error) {
            setError(response.error);
            return;
          }

          if (response.data) {
            const { transactions: newTx, hasMore: more } = response.data;

            if (loadMore) {
              setTransactions((prev) => [...prev, ...newTx]);
              setOffset(currentOffset + newTx.length);
            } else {
              setTransactions(newTx);
              setOffset(newTx.length);
              // Cache initial transactions
              await cache.set(
                txCacheKey,
                response.data,
                cache.CACHE_TTL.PROPOSALS
              );
            }

            setHasMore(more);
          }

          setIsStale(false);
        } catch (err) {
          daoLogger.error('useTreasury transactions fetch error:', err);
          setError(
            err instanceof Error
              ? err.message
              : 'Failed to load transactions'
          );
        } finally {
          if (loadMore) {
            setIsLoadingMore(false);
          } else {
            setIsLoading(false);
          }
        }
      }
    },
    [daoId, getAccessToken, offset, transactions.length]
  );

  useEffect(() => {
    const loadData = async () => {
      await Promise.all([fetchTreasury(), fetchTransactions()]);
    };
    loadData();
  }, [fetchTreasury, fetchTransactions]);

  // Auto-refresh when coming back online
  useEffect(() => {
    if (isOnline && isStale) {
      daoLogger.info('Network restored, refreshing treasury data');
      fetchTreasury();
      fetchTransactions();
    }
  }, [isOnline, isStale, fetchTreasury, fetchTransactions]);

  const refetch = useCallback(async () => {
    setOffset(0);
    await Promise.all([fetchTreasury(), fetchTransactions()]);
  }, [fetchTreasury, fetchTransactions]);

  const loadMoreTransactions = useCallback(async () => {
    if (!isLoadingMore && hasMore) {
      await fetchTransactions(true);
    }
  }, [isLoadingMore, hasMore, fetchTransactions]);

  return {
    treasury,
    transactions,
    isLoading,
    error,
    isStale,
    refetch,
    loadMoreTransactions,
    hasMore,
    isLoadingMore,
  };
}
