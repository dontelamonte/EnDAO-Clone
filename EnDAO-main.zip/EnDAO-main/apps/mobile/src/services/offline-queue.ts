/**
 * Offline Queue Service
 *
 * Queues actions when offline and processes them when connection is restored.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { network } from './network';

const QUEUE_KEY = '@endao:offline_queue';
const MAX_RETRIES = 3;

export type ActionType = 'VOTE' | 'PROFILE_UPDATE';

export interface QueuedAction {
  id: string;
  type: ActionType;
  payload: unknown;
  createdAt: number;
  retryCount: number;
}

/**
 * Generate unique ID for queued action
 */
function generateId(): string {
  return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Get current queue from storage
 */
async function getQueue(): Promise<QueuedAction[]> {
  try {
    const queueData = await AsyncStorage.getItem(QUEUE_KEY);
    if (!queueData) {
      return [];
    }
    return JSON.parse(queueData);
  } catch (error) {
    console.error('Error reading offline queue:', error);
    return [];
  }
}

/**
 * Save queue to storage
 */
async function saveQueue(queue: QueuedAction[]): Promise<void> {
  try {
    await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch (error) {
    console.error('Error saving offline queue:', error);
  }
}

/**
 * Enqueue an action for later processing
 */
export async function enqueue(
  type: ActionType,
  payload: unknown
): Promise<string> {
  const action: QueuedAction = {
    id: generateId(),
    type,
    payload,
    createdAt: Date.now(),
    retryCount: 0,
  };

  const queue = await getQueue();
  queue.push(action);
  await saveQueue(queue);

  return action.id;
}

/**
 * Remove an action from the queue
 */
export async function dequeue(actionId: string): Promise<void> {
  const queue = await getQueue();
  const filteredQueue = queue.filter((action) => action.id !== actionId);
  await saveQueue(filteredQueue);
}

/**
 * Mark an action as retried
 */
export async function markRetry(actionId: string): Promise<void> {
  const queue = await getQueue();
  const action = queue.find((a) => a.id === actionId);

  if (action) {
    action.retryCount += 1;

    if (action.retryCount >= MAX_RETRIES) {
      // Remove action if max retries exceeded
      const filteredQueue = queue.filter((a) => a.id !== actionId);
      await saveQueue(filteredQueue);
      console.warn(`Action ${actionId} exceeded max retries and was removed`);
    } else {
      await saveQueue(queue);
    }
  }
}

/**
 * Process all queued actions
 */
export async function processQueue(
  handler: (action: QueuedAction) => Promise<boolean>
): Promise<void> {
  if (!network.isConnected()) {
    console.log('Cannot process queue: offline');
    return;
  }

  const queue = await getQueue();
  if (queue.length === 0) {
    return;
  }

  console.log(`Processing ${queue.length} queued actions`);

  for (const action of queue) {
    try {
      const success = await handler(action);

      if (success) {
        await dequeue(action.id);
        console.log(`Successfully processed action ${action.id}`);
      } else {
        await markRetry(action.id);
        console.log(
          `Failed to process action ${action.id}, retry count: ${action.retryCount + 1}`
        );
      }
    } catch (error) {
      console.error(`Error processing action ${action.id}:`, error);
      await markRetry(action.id);
    }
  }
}

/**
 * Get count of pending actions
 */
export async function getPendingCount(): Promise<number> {
  const queue = await getQueue();
  return queue.length;
}
