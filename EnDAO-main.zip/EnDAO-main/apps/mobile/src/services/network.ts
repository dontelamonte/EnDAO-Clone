/**
 * Network Monitor Service
 *
 * Monitors network connectivity and provides utilities for offline-first architecture.
 */

import { useState, useEffect } from 'react';
import NetInfo, { NetInfoState } from '@react-native-community/netinfo';

interface NetworkState {
  isConnected: boolean;
  connectionType: string;
}

/**
 * Singleton network state
 */
let networkState: NetworkState = {
  isConnected: true,
  connectionType: 'unknown',
};

let isInitialized = false;
let unsubscribe: (() => void) | null = null;

/**
 * Initialize network monitor
 */
export function initNetworkMonitor(): void {
  if (isInitialized) {
    return;
  }

  unsubscribe = NetInfo.addEventListener((state: NetInfoState) => {
    networkState = {
      isConnected: state.isConnected ?? false,
      connectionType: state.type,
    };
  });

  isInitialized = true;
}

/**
 * Clean up network monitor
 */
export function cleanupNetworkMonitor(): void {
  if (unsubscribe) {
    unsubscribe();
    unsubscribe = null;
  }
  isInitialized = false;
}

/**
 * Network utilities object
 */
export const network = {
  /**
   * Check if device is connected to network
   */
  isConnected(): boolean {
    return networkState.isConnected;
  },

  /**
   * Get current connection type
   */
  getType(): string {
    return networkState.connectionType;
  },

  /**
   * Check if we can fetch data (connected and not on cellular)
   * You might want to add additional logic here for data saver modes
   */
  canFetch(): boolean {
    return networkState.isConnected;
  },

  /**
   * Wait for network connection
   */
  async waitForConnection(timeout: number = 5000): Promise<boolean> {
    if (networkState.isConnected) {
      return true;
    }

    return new Promise((resolve) => {
      const timeoutId = setTimeout(() => {
        if (unsubscribeWait) {
          unsubscribeWait();
        }
        resolve(false);
      }, timeout);

      const unsubscribeWait = NetInfo.addEventListener(
        (state: NetInfoState) => {
          if (state.isConnected) {
            clearTimeout(timeoutId);
            unsubscribeWait();
            resolve(true);
          }
        }
      );
    });
  },
};

/**
 * React hook for network status
 */
export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(networkState.isConnected);
  const [connectionType, setConnectionType] = useState(
    networkState.connectionType
  );

  useEffect(() => {
    // Initialize if not already done
    if (!isInitialized) {
      initNetworkMonitor();
    }

    // Subscribe to network changes
    const unsubscribe = NetInfo.addEventListener((state: NetInfoState) => {
      setIsOnline(state.isConnected ?? false);
      setConnectionType(state.type);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  return { isOnline, connectionType };
}
