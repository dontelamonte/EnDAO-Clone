/**
 * EnDAO Mobile API Client
 *
 * All API calls go through the Next.js backend.
 * Mobile never directly accesses Supabase - the service layer handles that.
 */

import { apiLogger } from '../utils/dev-logger';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'https://endao.ai';

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  body?: unknown;
  headers?: Record<string, string>;
}

interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  status: number;
}

/**
 * Make an authenticated API request to the EnDAO backend
 */
export async function apiRequest<T>(
  endpoint: string,
  accessToken: string | null,
  options: ApiOptions = {}
): Promise<ApiResponse<T>> {
  const { method = 'GET', body, headers = {} } = options;

  const url = `${API_BASE_URL}/api/mobile/v1${endpoint}`;

  try {
    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        ...headers,
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        data: null,
        error: data.error || `HTTP ${response.status}`,
        status: response.status,
      };
    }

    // Unwrap { success: true, data: T } wrapper from API
    const unwrappedData = data.data !== undefined ? data.data : data;

    return {
      data: unwrappedData as T,
      error: null,
      status: response.status,
    };
  } catch (error) {
    apiLogger.error('API request failed:', error);
    return {
      data: null,
      error: error instanceof Error ? error.message : 'Network error',
      status: 0,
    };
  }
}

// Type-safe API methods
export const api = {
  // User
  getProfile: (token: string | null) =>
    apiRequest<{
      id: string;
      username?: string;
      displayName: string;
      email?: string;
      bio?: string;
      avatarUrl?: string;
    }>('/user/profile', token),

  updateProfile: (
    token: string | null,
    data: {
      username?: string;
      displayName?: string;
      bio?: string;
      avatarUrl?: string;
    }
  ) => apiRequest('/user/profile', token, { method: 'PATCH', body: data }),

  /**
   * Upload avatar image to Supabase storage
   * @param token - Authentication token
   * @param imageUri - Local file URI from image picker (e.g., 'file:///path/to/image.jpg')
   * @returns Avatar URL from Supabase storage
   */
  uploadAvatar: async (
    token: string | null,
    imageUri: string
  ): Promise<
    ApiResponse<{ url: string; responsive: Record<string, string> }>
  > => {
    if (!token) {
      return {
        data: null,
        error: 'Authentication required',
        status: 401,
      };
    }

    try {
      // Create FormData for multipart upload
      const formData = new FormData();

      // Extract filename from URI
      const filename = imageUri.split('/').pop() || 'avatar.jpg';

      // Add file to FormData
      // React Native FormData expects { uri, name, type } format
      formData.append('file', {
        uri: imageUri,
        name: filename,
        type: 'image/jpeg', // Default to JPEG, server will validate actual type
      } as unknown as Blob);

      const url = `${API_BASE_URL}/api/upload/avatar`;

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          // Don't set Content-Type - let fetch set it with boundary for multipart
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          data: null,
          error: data.error || `HTTP ${response.status}`,
          status: response.status,
        };
      }

      // Extract URL from response
      const unwrappedData = data.data !== undefined ? data.data : data;

      return {
        data: {
          url: unwrappedData.url,
          responsive: unwrappedData.responsive || {},
        },
        error: null,
        status: response.status,
      };
    } catch (error) {
      apiLogger.error('Avatar upload failed:', error);
      return {
        data: null,
        error: error instanceof Error ? error.message : 'Upload error',
        status: 0,
      };
    }
  },

  /**
   * Upload DAO logo image to Supabase storage
   * @param token - Authentication token
   * @param daoId - ID of the DAO
   * @param imageUri - Local file URI from image picker (e.g., 'file:///path/to/image.jpg')
   * @returns Logo URL and responsive variants from Supabase storage
   */
  uploadDAOLogo: async (
    token: string | null,
    daoId: string,
    imageUri: string
  ): Promise<
    ApiResponse<{ url: string; responsive: Record<string, string> }>
  > => {
    if (!token) {
      return {
        data: null,
        error: 'Authentication required',
        status: 401,
      };
    }

    if (!daoId) {
      return {
        data: null,
        error: 'DAO ID is required',
        status: 400,
      };
    }

    try {
      // Create FormData for multipart upload
      const formData = new FormData();

      // Extract filename from URI
      const filename = imageUri.split('/').pop() || 'logo.jpg';

      // Add file to FormData
      // React Native FormData expects { uri, name, type } format
      formData.append('file', {
        uri: imageUri,
        name: filename,
        type: 'image/jpeg', // Default to JPEG, server will validate actual type
      } as unknown as Blob);

      // Add daoId to FormData
      formData.append('daoId', daoId);

      const url = `${API_BASE_URL}/api/upload/dao-logo`;

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          // Don't set Content-Type - let fetch set it with boundary for multipart
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          data: null,
          error: data.error || `HTTP ${response.status}`,
          status: response.status,
        };
      }

      // Extract URL from response
      const unwrappedData = data.data !== undefined ? data.data : data;

      return {
        data: {
          url: unwrappedData.url,
          responsive: unwrappedData.responsive || {},
        },
        error: null,
        status: response.status,
      };
    } catch (error) {
      apiLogger.error('DAO logo upload failed:', error);
      return {
        data: null,
        error: error instanceof Error ? error.message : 'Upload error',
        status: 0,
      };
    }
  },

  // DAOs
  getMyDAOs: (token: string | null) =>
    apiRequest<Array<{ id: string; name: string; slug: string }>>(
      '/daos',
      token
    ),

  getDAO: (token: string | null, daoId: string) =>
    apiRequest<{
      id: string;
      name: string;
      slug: string;
      description?: string;
      logoUrl?: string;
      userRole?: 'member' | 'admin' | 'owner';
    }>(`/daos/${daoId}`, token),

  updateDAO: (
    token: string | null,
    daoId: string,
    data: {
      name?: string;
      description?: string;
      logoUrl?: string;
    }
  ) =>
    apiRequest(`/daos/${daoId}`, token, {
      method: 'PATCH',
      body: data,
    }),

  createDAO: (
    token: string | null,
    data: {
      name: string;
      description: string;
      category: 'Community' | 'Commerce';
      organizationType:
        | 'nonprofit'
        | 'cooperative'
        | 'business'
        | 'community_org'
        | 'social_org'
        | 'general';
      tags?: string[];
      joinPermission?: 'open' | 'request' | 'invite-only';
    }
  ) =>
    apiRequest<{ id: string; name: string; slug: string; description: string }>(
      '/daos',
      token,
      {
        method: 'POST',
        body: data,
      }
    ),

  // DAO Stats
  getDAOStats: (token: string | null, daoId: string) =>
    apiRequest<{
      memberCount: number;
      proposalCount: number;
      activeProposalCount: number;
      participationRate: number;
    }>(`/daos/${daoId}/stats`, token),

  // Admin Stats
  getAdminStats: (token: string | null, daoId: string) =>
    apiRequest<{
      memberCount: number;
      adminCount: number;
      proposalCount: number;
      activeProposalCount: number;
      passedProposalCount: number;
      rejectedProposalCount: number;
      recentMemberJoins: number;
      recentProposalCount: number;
      treasuryBalance: string | null;
    }>(`/daos/${daoId}/admin/stats`, token),

  // Proposals
  getProposals: (token: string | null, daoId: string, status?: string) =>
    apiRequest<
      Array<{
        id: string;
        title: string;
        status: string;
        description?: string;
        votingStartTime?: string;
        votingEndTime?: string;
        creatorId?: string;
        votingType?: string;
      }>
    >(`/daos/${daoId}/proposals${status ? `?status=${status}` : ''}`, token),

  getProposal: (token: string | null, proposalId: string) =>
    apiRequest<{
      id: string;
      title: string;
      description: string;
      status: string;
      votingStartTime?: string;
      votingEndTime?: string;
      creatorId?: string;
      votingType?: string;
      daoId: string;
      results?: {
        for: number;
        against: number;
        abstain: number;
        quorumReached: boolean;
        thresholdMet: boolean;
      };
    }>(`/proposals/${proposalId}`, token),

  // Vote Eligibility
  canVote: (token: string | null, proposalId: string) =>
    apiRequest<{
      canVote: boolean;
      reason?: string;
      hasVoted?: boolean;
      currentVote?: {
        choice: string;
        voteStrength?: number;
        isSigned?: boolean;
      };
    }>(`/proposals/${proposalId}/can-vote`, token),

  // Legacy vote (without signature)
  vote: (
    token: string | null,
    proposalId: string,
    data: { option: string; reason?: string }
  ) =>
    apiRequest(`/proposals/${proposalId}/vote`, token, {
      method: 'POST',
      body: data,
    }),

  // Signed vote submission
  submitSignedVote: (
    token: string | null,
    proposalId: string,
    data: {
      message: {
        proposalId: string;
        daoId: string;
        choice: string;
        voter: string;
        strength: number;
        timestamp: number;
        nonce: string;
      };
      signature: string;
      walletAddress: string;
      signatureType: 'eip712' | 'personal_sign';
    }
  ) =>
    apiRequest<{
      success: boolean;
      voteId: string;
      signatureVerified: boolean;
    }>(`/proposals/${proposalId}/vote`, token, { method: 'POST', body: data }),

  // Devices (Push Notifications)
  registerDevice: (
    token: string | null,
    data: { pushToken: string; platform: 'ios' | 'android' }
  ) => apiRequest('/devices', token, { method: 'POST', body: data }),

  unregisterDevice: (token: string | null, deviceId: string) =>
    apiRequest(`/devices/${deviceId}`, token, { method: 'DELETE' }),

  // Notification Preferences
  getNotificationPrefs: (token: string | null) =>
    apiRequest<{
      enabled: boolean;
      proposalCreated: boolean;
      voteReminders: boolean;
    }>('/notifications/prefs', token),

  updateNotificationPrefs: (
    token: string | null,
    data: Partial<{ enabled: boolean; proposalCreated: boolean }>
  ) =>
    apiRequest('/notifications/prefs', token, { method: 'PATCH', body: data }),

  // Discussions
  getDiscussions: (token: string | null, daoId: string, status?: string) =>
    apiRequest<
      Array<{
        id: string;
        title: string;
        content: string;
        authorId: string;
        authorName: string | null;
        commentCount: number;
        isPinned: boolean;
        status: 'active' | 'archived' | 'converted';
        createdAt: string;
        lastActivityAt: string | null;
      }>
    >(`/daos/${daoId}/discussions${status ? `?status=${status}` : ''}`, token),

  getDiscussion: (token: string | null, discussionId: string) =>
    apiRequest<{
      discussion: {
        id: string;
        title: string;
        content: string;
        authorId: string;
        authorName: string | null;
        commentCount: number;
        isPinned: boolean;
        status: 'active' | 'archived' | 'converted';
        createdAt: string;
        lastActivityAt: string | null;
      };
      comments: Array<{
        id: string;
        content: string;
        authorId: string;
        authorName: string | null;
        parentId: string | null;
        createdAt: string;
        isEdited: boolean;
      }>;
    }>(`/discussions/${discussionId}`, token),

  // Treasury
  getTreasury: (token: string | null, daoId: string) =>
    apiRequest<{
      address: string | null;
      balance: string;
      balanceUsd: string | null;
      tokens: Array<{
        symbol: string;
        balance: string;
        balanceUsd: string | null;
      }>;
      isConfigured: boolean;
    }>(`/daos/${daoId}/treasury`, token),

  getTreasuryTransactions: (
    token: string | null,
    daoId: string,
    limit?: number,
    offset?: number
  ) =>
    apiRequest<{
      transactions: Array<{
        id: string;
        type: 'incoming' | 'outgoing';
        amount: string;
        tokenSymbol: string;
        from: string;
        to: string;
        status: 'pending' | 'confirmed' | 'failed';
        timestamp: string;
        txHash: string | null;
      }>;
      hasMore: boolean;
    }>(
      `/daos/${daoId}/treasury/transactions?limit=${limit || 20}&offset=${offset || 0}`,
      token
    ),

  getPendingExecutions: (token: string | null, daoId: string) =>
    apiRequest<{
      executions: Array<{
        executionId: string;
        proposalId: string;
        amount: string;
        recipient: string;
        currency: string;
        requiredSignatures: number;
        currentSignatures: number;
        hasUserSigned: boolean;
        safeTransactionHash: string;
        status: string;
        proposalTitle: string;
        createdAt: string;
      }>;
      isOwner: boolean;
    }>(`/daos/${daoId}/treasury/pending`, token),

  signTreasuryExecution: (
    token: string | null,
    executionId: string,
    signature: string
  ) =>
    apiRequest<{
      message: string;
      currentSignatures: number;
      requiredSignatures: number;
      hasEnoughSignatures: boolean;
    }>(`/treasury/executions/${executionId}/sign`, token, {
      method: 'POST',
      body: { signature },
    }),

  // Unified Treasury (Hybrid)
  getUnifiedTreasuryBalance: (token: string | null, daoId: string) =>
    apiRequest<{
      balance: {
        totalUsdValue: number;
        lastUpdated: string;
        fiatBalance: {
          available: number;
          pending: number;
          currency: string;
          stripeAccountId?: string;
        } | null;
        cryptoBalance: {
          totalUsdValue: number;
          safeAddress: string;
          chainId: number;
          assets: Array<{
            symbol: string;
            name: string;
            balance: string;
            decimals: number;
            usdValue: number;
            contractAddress?: string;
          }>;
        } | null;
      };
      rails: {
        hybridEnabled: boolean;
        fiat: {
          status: 'inactive' | 'active' | 'pending';
          stripeAccountId?: string;
          stripeStatus?: string;
        };
        crypto: {
          status: 'inactive' | 'active' | 'pending';
          safeAddress?: string;
          chainId?: number;
        };
      } | null;
    }>(`/daos/${daoId}/treasury/unified-balance`, token),

  // Payment Methods (for donations)
  getPaymentMethods: (daoId: string) =>
    apiRequest<{
      daoId: string;
      methods: Array<{
        method: 'card' | 'crypto';
        enabled: boolean;
        displayName: string;
        description: string;
        processingTime: string;
        fees: {
          platformFeePercent: number;
          processorFeePercent: number;
          processorFeeFixed?: number;
          networkFeeEstimate?: number;
        };
      }>;
      defaultMethod: 'card' | 'crypto';
    }>(`/donations/${daoId}/methods`, null),

  // Members
  getMembers: (
    token: string | null,
    daoId: string,
    limit?: number,
    offset?: number
  ) =>
    apiRequest<{
      members: Array<{
        id: string;
        userId: string;
        displayName: string | null;
        avatarUrl: string | null;
        role: 'member' | 'admin' | 'owner';
        joinedAt: string;
        bio: string | null;
      }>;
      total: number;
      hasMore: boolean;
    }>(
      `/daos/${daoId}/members?limit=${limit || 20}&offset=${offset || 0}`,
      token
    ),

  // Activities
  getActivities: (
    token: string | null,
    daoId: string,
    limit?: number,
    offset?: number
  ) =>
    apiRequest<{
      activities: Array<{
        id: string;
        type: string;
        title: string;
        description?: string;
        userId: string;
        createdAt: string;
        data: Record<string, unknown>;
      }>;
      hasMore: boolean;
    }>(
      `/daos/${daoId}/activities?limit=${limit || 20}&offset=${offset || 0}`,
      token
    ),
};
