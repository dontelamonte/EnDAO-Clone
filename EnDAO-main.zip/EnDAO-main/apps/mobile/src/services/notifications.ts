/**
 * EnDAO Mobile Push Notification Service
 *
 * Handles push notification registration, preferences, and local notifications.
 * Uses Expo Notifications API for cross-platform notification support.
 */

import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { api } from './api';

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export interface NotificationPreferences {
  enabled: boolean;
  proposalCreated: boolean;
  voteReminders: boolean;
  proposalResults: boolean;
  membershipChanges: boolean;
}

export const DEFAULT_PREFS: NotificationPreferences = {
  enabled: true,
  proposalCreated: true,
  voteReminders: true,
  proposalResults: true,
  membershipChanges: false,
};

/**
 * Register device for push notifications
 * Returns expo push token on success
 */
async function register(
  accessToken: string | null
): Promise<{ success: boolean; token?: string; deviceId?: string }> {
  try {
    // Check if device supports push notifications
    if (!Device.isDevice) {
      console.warn('Push notifications only work on physical devices');
      return { success: false };
    }

    // Request permissions
    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.warn('Push notification permission denied');
      return { success: false };
    }

    // Get expo push token
    const tokenData = await Notifications.getExpoPushTokenAsync({
      projectId: process.env.EXPO_PUBLIC_PROJECT_ID,
    });
    const pushToken = tokenData.data;

    // Register device with backend
    const platform = Platform.OS as 'ios' | 'android';
    const response = await api.registerDevice(accessToken, {
      pushToken,
      platform,
    });

    if (response.error) {
      console.error('Failed to register device:', response.error);
      return { success: false, token: pushToken };
    }

    // Extract device ID from response
    const deviceId = (response.data as any)?.deviceId;

    return { success: true, token: pushToken, deviceId };
  } catch (error) {
    console.error('Push notification registration error:', error);
    return { success: false };
  }
}

/**
 * Unregister device on logout
 */
async function unregister(
  accessToken: string | null,
  deviceId: string
): Promise<void> {
  try {
    if (!deviceId) {
      console.warn('No device ID to unregister');
      return;
    }

    const response = await api.unregisterDevice(accessToken, deviceId);

    if (response.error) {
      console.error('Failed to unregister device:', response.error);
    }
  } catch (error) {
    console.error('Device unregistration error:', error);
  }
}

/**
 * Get notification preferences from backend
 */
async function getPreferences(
  accessToken: string | null
): Promise<NotificationPreferences> {
  try {
    const response = await api.getNotificationPrefs(accessToken);

    if (response.error) {
      console.error('Failed to get notification preferences:', response.error);
      return DEFAULT_PREFS;
    }

    // Merge with defaults in case backend has partial data
    return {
      ...DEFAULT_PREFS,
      ...response.data,
    };
  } catch (error) {
    console.error('Get notification preferences error:', error);
    return DEFAULT_PREFS;
  }
}

/**
 * Update notification preferences
 */
async function updatePreferences(
  accessToken: string | null,
  prefs: Partial<NotificationPreferences>
): Promise<boolean> {
  try {
    const response = await api.updateNotificationPrefs(accessToken, prefs);

    if (response.error) {
      console.error(
        'Failed to update notification preferences:',
        response.error
      );
      return false;
    }

    return true;
  } catch (error) {
    console.error('Update notification preferences error:', error);
    return false;
  }
}

/**
 * Add listener for notification taps (user interaction)
 */
function addNotificationResponseListener(
  handler: (response: Notifications.NotificationResponse) => void
): Notifications.Subscription {
  return Notifications.addNotificationResponseReceivedListener(handler);
}

/**
 * Add listener for incoming notifications (foreground)
 */
function addNotificationListener(
  handler: (notification: Notifications.Notification) => void
): Notifications.Subscription {
  return Notifications.addNotificationReceivedListener(handler);
}

/**
 * Get current badge count
 */
async function getBadgeCount(): Promise<number> {
  try {
    const count = await Notifications.getBadgeCountAsync();
    return count;
  } catch (error) {
    console.error('Get badge count error:', error);
    return 0;
  }
}

/**
 * Clear app icon badge
 */
async function clearBadge(): Promise<void> {
  try {
    await Notifications.setBadgeCountAsync(0);
  } catch (error) {
    console.error('Clear badge error:', error);
  }
}

/**
 * Schedule a local notification
 * @param title Notification title
 * @param body Notification body
 * @param data Custom data to include
 * @param triggerSeconds Seconds from now to trigger (null for immediate)
 */
async function scheduleLocal(
  title: string,
  body: string,
  data?: Record<string, any>,
  triggerSeconds?: number
): Promise<string | null> {
  try {
    const identifier = await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data,
      },
      trigger: triggerSeconds
        ? {
            type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
            seconds: triggerSeconds,
          }
        : null,
    });

    return identifier;
  } catch (error) {
    console.error('Schedule local notification error:', error);
    return null;
  }
}

/**
 * Cancel a scheduled notification
 */
async function cancelScheduled(notificationId: string): Promise<void> {
  try {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  } catch (error) {
    console.error('Cancel notification error:', error);
  }
}

export const notifications = {
  register,
  unregister,
  getPreferences,
  updatePreferences,
  addNotificationResponseListener,
  addNotificationListener,
  getBadgeCount,
  clearBadge,
  scheduleLocal,
  cancelScheduled,
};
