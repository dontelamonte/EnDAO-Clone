/**
 * Cache Service
 *
 * Provides local caching using AsyncStorage for offline-first support.
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY_PREFIX = '@endao:';

export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiresAt: number;
}

/**
 * Cache TTL constants (in milliseconds)
 */
export const CACHE_TTL = {
  DAO_LIST: 5 * 60 * 1000, // 5 minutes
  DAO_DETAIL: 2 * 60 * 1000, // 2 minutes
  PROPOSALS: 1 * 60 * 1000, // 1 minute
  PROPOSAL_DETAIL: 30 * 1000, // 30 seconds
  USER_PROFILE: 10 * 60 * 1000, // 10 minutes
} as const;

/**
 * Get cached data
 */
export async function get<T>(key: string): Promise<T | null> {
  try {
    const storageKey = `${KEY_PREFIX}${key}`;
    const item = await AsyncStorage.getItem(storageKey);

    if (!item) {
      return null;
    }

    const entry: CacheEntry<T> = JSON.parse(item);
    const now = Date.now();

    // Check if cache has expired
    if (now > entry.expiresAt) {
      await AsyncStorage.removeItem(storageKey);
      return null;
    }

    return entry.data;
  } catch (error) {
    console.error('Cache get error:', error);
    return null;
  }
}

/**
 * Set cached data with TTL
 */
export async function set<T>(key: string, data: T, ttl: number): Promise<void> {
  try {
    const now = Date.now();
    const entry: CacheEntry<T> = {
      data,
      timestamp: now,
      expiresAt: now + ttl,
    };

    const storageKey = `${KEY_PREFIX}${key}`;
    await AsyncStorage.setItem(storageKey, JSON.stringify(entry));
  } catch (error) {
    console.error('Cache set error:', error);
  }
}

/**
 * Invalidate cached data
 */
export async function invalidate(key: string): Promise<void> {
  try {
    const storageKey = `${KEY_PREFIX}${key}`;
    await AsyncStorage.removeItem(storageKey);
  } catch (error) {
    console.error('Cache invalidate error:', error);
  }
}

/**
 * Clear all cached data
 */
export async function clearAll(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const endaoKeys = keys.filter((key) => key.startsWith(KEY_PREFIX));
    await AsyncStorage.multiRemove(endaoKeys);
  } catch (error) {
    console.error('Cache clearAll error:', error);
  }
}
