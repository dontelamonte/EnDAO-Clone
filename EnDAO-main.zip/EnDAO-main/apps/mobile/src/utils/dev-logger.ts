/**
 * Development-only logger that's stripped from production builds
 * Uses __DEV__ global which is true in dev, false in production
 */

// Type declaration for React Native __DEV__ global
declare const __DEV__: boolean;

type LogLevel = 'log' | 'warn' | 'error' | 'info' | 'debug';

const createLogger = (prefix: string) => {
  const log = (level: LogLevel, ...args: unknown[]) => {
    if (__DEV__) {
      console[level](`[${prefix}]`, ...args);
    }
  };

  return {
    log: (...args: unknown[]) => log('log', ...args),
    info: (...args: unknown[]) => log('info', ...args),
    warn: (...args: unknown[]) => log('warn', ...args),
    error: (...args: unknown[]) => log('error', ...args),
    debug: (...args: unknown[]) => log('debug', ...args),
  };
};

// Pre-configured loggers for common modules
export const authLogger = createLogger('Auth');
export const apiLogger = createLogger('API');
export const daoLogger = createLogger('DAO');
export const proposalLogger = createLogger('Proposal');
export const voteLogger = createLogger('Vote');
export const privyLogger = createLogger('Privy');

// Generic factory for custom loggers
export const devLogger = createLogger;
