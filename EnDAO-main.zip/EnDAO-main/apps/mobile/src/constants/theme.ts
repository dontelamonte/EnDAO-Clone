/**
 * EnDAO Mobile Theme Constants
 *
 * Centralized theme values matching the web app's dark theme.
 * Based on Tailwind CSS color palette used in the web app.
 */

export const colors = {
  // Background colors
  background: {
    primary: '#0f172a', // slate-900 - main background
    secondary: '#1e293b', // slate-800 - cards, panels
    tertiary: '#334155', // slate-700 - elevated elements
  },

  // Text colors
  text: {
    primary: '#f8fafc', // slate-50 - headings, important text
    secondary: '#94a3b8', // slate-400 - body text
    muted: '#64748b', // slate-500 - subtle text
    inverse: '#0f172a', // slate-900 - text on light backgrounds
  },

  // Brand colors
  primary: {
    default: '#3b82f6', // blue-500 - primary actions
    light: '#60a5fa', // blue-400 - hover states
    dark: '#2563eb', // blue-600 - pressed states
  },

  // Status colors
  status: {
    success: '#22c55e', // green-500
    warning: '#f59e0b', // amber-500
    error: '#ef4444', // red-500
    info: '#0ea5e9', // sky-500
  },

  // Proposal status colors
  proposal: {
    active: '#22c55e', // green-500
    pending: '#f59e0b', // amber-500
    passed: '#3b82f6', // blue-500
    rejected: '#ef4444', // red-500
    executed: '#8b5cf6', // violet-500
  },

  // Vote colors
  vote: {
    for: '#22c55e', // green-500
    against: '#ef4444', // red-500
    abstain: '#64748b', // slate-500
  },

  // Border colors
  border: {
    default: '#1e293b', // slate-800
    subtle: '#334155', // slate-700
  },
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const;

export const borderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
} as const;

export const fontSize = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 32,
} as const;

export const fontWeight = {
  normal: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
};
