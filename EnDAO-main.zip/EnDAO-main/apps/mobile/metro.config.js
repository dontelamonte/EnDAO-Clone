const { getDefaultConfig } = require('expo/metro-config')

// SDK 52+ automatically configures Metro for monorepos
// See: https://docs.expo.dev/guides/monorepos/
const config = getDefaultConfig(__dirname)

// Block web-only packages that cause issues with React Native
const originalResolveRequest = config.resolver.resolveRequest
config.resolver.resolveRequest = (context, moduleName, platform) => {
  // Block viem and ox - these are web3 packages that don't work in React Native
  if (moduleName === 'viem' || moduleName.startsWith('viem/') ||
      moduleName === 'ox' || moduleName.startsWith('ox/')) {
    return {
      type: 'empty',
    }
  }

  // Use default resolver for everything else
  if (originalResolveRequest) {
    return originalResolveRequest(context, moduleName, platform)
  }
  return context.resolveRequest(context, moduleName, platform)
}

module.exports = config
