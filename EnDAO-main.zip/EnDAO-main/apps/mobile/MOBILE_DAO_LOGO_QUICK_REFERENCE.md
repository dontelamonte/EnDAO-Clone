# Mobile DAO Logo Upload - Quick Reference

## User Flow

1. **Navigate to DAO** → Tap DAO from list
2. **Access Settings** → Tap "Settings" button (admin only)
3. **Upload Logo** → Tap camera icon on logo
4. **Select Image** → Choose from library, crop to square
5. **Wait for Upload** → Spinner shows progress
6. **Success** → Logo appears immediately

## Key Components

### DAOLogoUpload

```tsx
import { DAOLogoUpload } from '@/components/dao';

<DAOLogoUpload
  daoId={daoId}
  daoName={daoName}
  currentLogoUrl={logoUrl}
  onUploadComplete={(url) => {
    setLogoUrl(url);
    refetch();
  }}
/>;
```

### DAOHeader (with logo)

```tsx
import { DAOHeader } from '@/components/dao';

<DAOHeader
  name={dao.name}
  description={dao.description}
  slug={dao.slug}
  logoUrl={dao.logoUrl} // New prop
/>;
```

## API Methods

### Upload Logo

```typescript
const response = await api.uploadDAOLogo(token, daoId, imageUri);
// Returns: { data: { url, responsive: { thumbnail, small, medium, large } } }
```

### Update DAO

```typescript
const response = await api.updateDAO(token, daoId, {
  logoUrl: newLogoUrl,
});
```

### Get DAO (includes logoUrl + userRole)

```typescript
const response = await api.getDAO(token, daoId);
// Returns: { id, name, slug, description, logoUrl, userRole }
```

## Admin Permission Check

```typescript
// In component
const { dao } = useDAO(daoId);
const isAdmin = dao?.userRole === 'admin' || dao?.userRole === 'owner';

if (isAdmin) {
  // Show settings button
}
```

## Navigation

```typescript
// To settings screen
router.push(`/dao/${daoId}/settings`);

// Settings screen route
// File: app/dao/[id]/settings.tsx
```

## Image Picker Configuration

```typescript
const result = await ImagePicker.launchImageLibraryAsync({
  mediaTypes: ImagePicker.MediaTypeOptions.Images,
  allowsEditing: true,
  aspect: [1, 1], // Square crop
  quality: 0.8, // Good balance
});
```

## Error Handling

```typescript
// In component
const [uploadError, setUploadError] = useState<string | null>(null);

if (response.error) {
  setUploadError(response.error);
  Alert.alert('Upload Failed', response.error);
}
```

## Responsive Sizes

Server returns 4 sizes (all WebP):

- `thumbnail`: 64x64 (for small UI)
- `small`: 128x128 (for cards/lists)
- `medium`: 256x256 (for headers) ← Default
- `large`: 512x512 (for full display)

## Theme Colors Used

```typescript
colors.primary.default; // Avatar background
colors.background.primary; // Screen background
colors.background.secondary; // Read-only field background
colors.background.tertiary; // Overlay background
colors.text.primary; // Primary text
colors.text.secondary; // Secondary text
colors.text.muted; // Hint text
colors.border.default; // Border color
colors.status.error; // Error messages
```

## Common Issues & Solutions

### Issue: Settings button not showing

**Solution**: Check `dao.userRole` is 'admin' or 'owner'

### Issue: Upload fails with 403

**Solution**: User is not admin, check backend permissions

### Issue: Logo not updating after upload

**Solution**: Call `refetch()` after upload completes

### Issue: Image picker permissions denied

**Solution**: User needs to grant photo library access

### Issue: Large image upload slow

**Solution**: Server automatically compresses to WebP, but consider client-side resize

## Testing

```bash
# Run type check
cd apps/mobile
npx tsc --noEmit

# Start dev server
yarn start

# Test on iOS
yarn ios

# Test on Android
yarn android
```

## Debugging

Enable logging in api.ts:

```typescript
apiLogger.info('Uploading DAO logo', { daoId, imageUri });
```

Check network tab in React Native Debugger for API responses.
