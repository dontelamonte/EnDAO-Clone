/**
 * Custom entry point for EnDAO mobile app
 *
 * Polyfills MUST be imported before expo-router/entry to ensure
 * crypto APIs are available before Privy initializes.
 */

// Crypto polyfills - MUST be first
import 'react-native-get-random-values';
import '@ethersproject/shims';

// Now load the app
import 'expo-router/entry';
