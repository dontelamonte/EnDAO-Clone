# PostHog Post-Wizard Report

The wizard has completed a deep integration of PostHog analytics into your EnDAO project. This integration includes client-side event tracking via the `posthog-js` SDK, server-side tracking capability via `posthog-node`, user identification for correlating anonymous and authenticated sessions, exception tracking, and a reverse proxy configuration to improve reliability against ad blockers.

## Integration Summary

### Core Setup Files

| File                            | Purpose                                                    |
| ------------------------------- | ---------------------------------------------------------- |
| `src/instrumentation-client.ts` | Client-side PostHog initialization with exception tracking |
| `src/lib/posthog-server.ts`     | Server-side PostHog client for API routes                  |
| `next.config.ts`                | Reverse proxy rewrites for PostHog ingestion               |
| `.env`                          | Environment variables for PostHog API key and host         |

### Event Tracking Implementation

| Event Name                 | Description                                                 | File Path                                               |
| -------------------------- | ----------------------------------------------------------- | ------------------------------------------------------- |
| `user_signed_up`           | User completes authentication/signup flow via Privy         | `src/lib/auth/auth-context.tsx`                         |
| `user_signed_out`          | User signs out from the application                         | `src/lib/auth/auth-context.tsx`                         |
| `dao_creation_started`     | User begins the DAO creation wizard by selecting a template | `src/components/dao/create/create-dao-wizard-core.tsx`  |
| `dao_created`              | User successfully creates a new DAO                         | `src/components/dao/create/create-dao-wizard-core.tsx`  |
| `proposal_submitted`       | User successfully submits a new proposal for voting         | `src/hooks/proposals/use-proposal-submission.ts`        |
| `proposal_draft_saved`     | User saves a proposal as draft                              | `src/hooks/proposals/use-proposal-submission.ts`        |
| `vote_cast`                | User successfully casts a vote on a proposal                | `src/app/dao/[id]/proposals/[proposalId]/vote/page.tsx` |
| `invitation_accepted`      | User accepts an invitation to join a DAO                    | `src/app/dao/[id]/join/page.tsx`                        |
| `treasury_created`         | Admin successfully creates a treasury Safe for the DAO      | `src/components/treasury/treasury-setup.tsx`            |
| `dao_discovered`           | User clicks on a DAO from the discover page to view details | `src/app/discover/components/dao-grid.tsx`              |
| `search_performed`         | User performs a search on the discover page                 | `src/app/discover/page.tsx`                             |
| `error_boundary_triggered` | Application error caught by React error boundary            | `src/components/error-boundary.tsx`                     |

### User Identification

Users are automatically identified when they authenticate via Privy. The `posthog.identify()` call is made with:

- Distinct ID: User's Privy ID (canonical identifier)
- Properties: email, displayName, username

On sign-out, `posthog.reset()` is called to unlink the device from the user.

## Next Steps

We've built some insights and a dashboard for you to keep an eye on user behavior, based on the events we just instrumented:

### Dashboard

- **Analytics Basics**: [https://us.posthog.com/project/269587/dashboard/923345](https://us.posthog.com/project/269587/dashboard/923345)

### Insights

- **User Signups Over Time**: [https://us.posthog.com/project/269587/insights/8yjL6qUB](https://us.posthog.com/project/269587/insights/8yjL6qUB)
- **DAO Creation Funnel**: [https://us.posthog.com/project/269587/insights/JhcfY4Bs](https://us.posthog.com/project/269587/insights/JhcfY4Bs)
- **Proposal to Vote Funnel**: [https://us.posthog.com/project/269587/insights/h6L0LZ3o](https://us.posthog.com/project/269587/insights/h6L0LZ3o)
- **Key Events Breakdown**: [https://us.posthog.com/project/269587/insights/veINvmqc](https://us.posthog.com/project/269587/insights/veINvmqc)
- **Error Tracking**: [https://us.posthog.com/project/269587/insights/4OcH41Wv](https://us.posthog.com/project/269587/insights/4OcH41Wv)

## Configuration Notes

### Environment Variables

Make sure these are set in your deployment environment:

```
NEXT_PUBLIC_POSTHOG_KEY=phc_FtBLs2nT1a2FUPLlBMZLVwmk2AU1xHX5LLJMZkcaNzF
NEXT_PUBLIC_POSTHOG_HOST=https://us.i.posthog.com
```

### Reverse Proxy

The reverse proxy is configured in `next.config.ts` to route requests through `/ingest/*` to avoid ad blockers. This improves tracking reliability without additional infrastructure.
