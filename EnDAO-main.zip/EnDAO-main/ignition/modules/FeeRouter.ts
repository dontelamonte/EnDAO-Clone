// @ts-nocheck - Hardhat Ignition SDK types not available in TypeScript
import { buildModule } from '@nomicfoundation/hardhat-ignition/modules';
import { parseEther } from 'viem';

// Load EnDAO Safe address from environment
const ENDAO_SAFE_ADDRESS =
  process.env.ENDAO_SAFE_ADDRESS ||
  '0x0000000000000000000000000000000000000000';

if (ENDAO_SAFE_ADDRESS === '0x0000000000000000000000000000000000000000') {
  throw new Error('Please set ENDAO_SAFE_ADDRESS in your .env file');
}

const FeeRouterModule = buildModule('FeeRouterModule', (m: any) => {
  // Deploy the FeeRouter contract with EnDAO Safe address
  const feeRouter = m.contract('FeeRouter', [ENDAO_SAFE_ADDRESS]);

  // You can also set up additional configuration here if needed
  // For example, verifying the deployment worked:
  m.call(feeRouter, 'endaoRevenueSafe', [], {
    id: 'verify-safe-address',
  });

  return { feeRouter };
});

export default FeeRouterModule;
