# EnDAO

**The institutional DAO layer for business** — governance infrastructure that scales from community groups to enterprise networks.

We're building the connective rails between organizations: shared treasuries, transparent decisions, and accountable governance — accessible to HOAs, investment clubs, nonprofits, cooperatives, and business networks without requiring crypto expertise.

Built with Next.js 15 (App Router), React 19, TypeScript, Supabase/PostgreSQL, Privy Auth, and Gnosis Safe.

🚀 **Live**: [endao.ai](https://endao.ai)
📋 **Version**: 2.2.0 (Treasury Protection System)

---

## Features

### Core Platform

- **DAO Management**: Create and manage decentralized organizations with Commerce or Community presets
- **Proposal System**: General, funding, governance, and bounty proposal types
- **Voting**: Simple (Yes/No/Abstain), ranked choice, with configurable quorum and thresholds
- **Treasury**: Gnosis Safe integration on Base Mainnet with 4-layer protection
- **Membership**: Role-based access control (Owner, Admin, Member) with invite flows
- **Profile System**: User profiles with username management and setup enforcement

### Security & Compliance

- **Treasury Protection**: Status checks, freeze system, 7-day grace period, emergency recovery
- **Input Validation**: Zod schemas with SQL injection and XSS detection
- **Audit Logging**: Comprehensive activity tracking with 2-year retention
- **Rate Limiting**: Per-endpoint protection tiers

### Administration

- **DAO Admin Dashboard**: Member management, settings, proposal oversight
- **Super Admin Tools**: Platform-wide administration and emergency controls
- **Platform Revenue**: Fee collection via FeeRouter on Base Mainnet

---

## Tech Stack

| Layer        | Technology                                                |
| ------------ | --------------------------------------------------------- |
| **Frontend** | Next.js 15, React 19, TypeScript, Tailwind CSS, Shadcn/ui |
| **Backend**  | Supabase (PostgreSQL), Privy Authentication               |
| **Treasury** | Gnosis Safe L2 on Base network, Ethers.js v6              |
| **Hosting**  | Vercel with multi-environment setup                       |

---

## Quick Start

```bash
# Clone and install
git clone <repo>
cd endao
yarn install

# Configure environment
cp .env.example .env.local
# Add Supabase, Privy, and Safe credentials

# Run development server
yarn dev
```

**Note**: Use `NODE_OPTIONS='--max-old-space-size=8192'` for builds to prevent OOM errors on this large codebase (245k+ LOC).

---

## Documentation

📚 **[Documentation Hub](docs/README.md)** — Start here for all documentation

### Key Documents

| Document                                          | Description                            |
| ------------------------------------------------- | -------------------------------------- |
| [Roadmap](ROADMAP.md)                             | Strategic vision and feature timeline  |
| [Master Spec](docs/MASTER_IMPLEMENTATION_SPEC.md) | Comprehensive technical specifications |
| [Setup Guide](docs/deployment/SETUP.md)           | Development environment setup          |
| [Treasury Docs](docs/treasury/README.md)          | Treasury system documentation          |
| [API Reference](docs/api/API.md)                  | API endpoint documentation             |
| [Contributing](CONTRIBUTING.md)                   | Development guidelines                 |

---

## Development

```bash
# Core commands
yarn dev                 # Start dev server
yarn build               # Production build
yarn type-check          # TypeScript validation
yarn lint                # ESLint
yarn test                # Unit tests (Jest)
yarn test:e2e            # E2E tests (Playwright)

# Architecture monitoring
yarn check:architecture  # File size and complexity checks
```

### Code Quality Standards

| Metric                | Target     | Limit                     |
| --------------------- | ---------- | ------------------------- |
| File size             | <300 lines | 800 lines (blocks commit) |
| Function size         | <100 lines | —                         |
| Cyclomatic complexity | <10        | —                         |
| TypeScript errors     | 0          | 0 (maintained)            |
| ESLint errors         | 0          | 0 (maintained)            |

---

## Architecture

### Design Patterns

- **Repository Pattern**: Supabase/PostgreSQL with RLS and admin bypass
- **Service Layer**: Business logic with `BaseService` inheritance
- **Server Components**: RSC-first with client islands for interactivity
- **DAO-Driven Config**: Governance parameters from DAO settings, not form inputs

### Project Structure

```
src/
├── app/                 # Next.js App Router pages
├── components/          # React components by domain
│   ├── admin/          # Administration interfaces
│   ├── dao/            # DAO management components
│   ├── treasury/       # Treasury UI components
│   └── ui/             # Shadcn/ui components
├── hooks/              # Custom React hooks
├── lib/
│   ├── repositories/   # Data access layer
│   ├── services/       # Business logic layer
│   └── security/       # Validation and security
└── types/              # TypeScript definitions
```

---

## Current Status

**v2.2.0** includes:

- Treasury Protection System with 4-layer security
- Platform revenue collection on Base Mainnet
- Bounty proposal system with treasury execution
- Enhanced security architecture (input validation, rate limiting)
- Profile setup enforcement flow

See [ROADMAP.md](ROADMAP.md) for upcoming features and strategic direction.

---

## License

MIT
