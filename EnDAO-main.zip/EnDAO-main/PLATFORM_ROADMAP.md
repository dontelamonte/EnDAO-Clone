# EnDAO Platform Roadmap

**Vision**: Building the institutional DAO layer for business - governance infrastructure that scales from community groups to enterprise networks.

**Philosophy**: Progressive complexity tiers. Each feature built for a single DAO must be designed as a primitive that enables multi-DAO and enterprise-level functionality.

**Status**: Production platform live at [endao.ai](https://endao.ai)

> **Implementation Status**: For current feature status, see [DEVELOPMENT_TRACKER.md](/docs/development/DEVELOPMENT_TRACKER.md). This document defines the strategic vision and specifications.

---

## Table of Contents

1. [Primitive Build Philosophy](#primitive-build-philosophy)
2. [AI Type Definitions](#ai-type-definitions)
3. [Progressive Disclosure Framework](#progressive-disclosure-framework)
4. [AI Configuration Model](#ai-configuration-model)
5. [Primitive Inventory & Build Map](#primitive-inventory--build-map)
6. [Critical Path: Big Four](#critical-path-big-four)
7. [Tier 0: Foundation (LIVE)](#tier-0-foundation-live)
8. [Tier 1: Single DAO Excellence](#tier-1-single-dao-excellence)
9. [Tier 2: Operational Maturity](#tier-2-operational-maturity)
10. [Tier 3: Network Foundation](#tier-3-network-foundation)
11. [Tier 4: Enterprise Federation](#tier-4-enterprise-federation)

---

## Primitive Build Philosophy

### Core Principle

> **Every feature built for a single DAO must be designed as a primitive that enables multi-DAO and enterprise-level functionality.**

This means:

1. **No Dead Ends**: Every feature should have a clear "network extension" path
2. **Composable by Design**: Features should be building blocks, not monoliths
3. **API-First Internals**: Even single-DAO features should use internal APIs that can become external
4. **Data Model Extensibility**: Schemas should reserve fields for cross-DAO relationships

### Primitive Categories

| Category           | Single-DAO Function | Network Extension                                      |
| ------------------ | ------------------- | ------------------------------------------------------ |
| **Identity**       | User/DAO profiles   | Verified DAO identity, ENS, federation registry        |
| **Governance**     | Proposals, votes    | Shared proposals, cross-DAO approval, delegation       |
| **Treasury**       | Safe, transactions  | Cross-treasury transfers, sub-DAO budgets, ops wallets |
| **Communication**  | Notifications       | Federated alerts, cross-DAO digests, webhook mesh      |
| **Access Control** | Admin/Member roles  | Observer, Moderator, Treasurer, permission inheritance |
| **Relationships**  | Membership          | Sub-DAO hierarchy, DAO-to-DAO, federation              |
| **Reporting**      | Activity dashboard  | Cross-DAO analytics, enterprise roll-up                |

---

## AI Type Definitions

EnDAO's AI capabilities follow a progressive maturity model, from simple assistance to autonomous participation:

| AI Type            | Interaction Model                               | When to Use                                      | Examples                                                   |
| ------------------ | ----------------------------------------------- | ------------------------------------------------ | ---------------------------------------------------------- |
| **Conversational** | Human asks → AI answers                         | Understanding, explanations, Q&A, drafts         | Proposal Summarizer, Governance Q&A, Draft Assistant       |
| **Utility**        | AI acts → Human reviews if needed               | Workflow automation, data management, scheduling | Workflow Automator, Deadline Enforcer, Calendar Sync       |
| **Analysis**       | AI monitors → Surfaces insights                 | Sentiment, quality, moderation, synthesis        | Discussion Synthesizer, Devil's Advocate, Quality Metrics  |
| **Infrastructure** | Enables agent participation                     | Auth, permissions, delegation, safety            | API Key Auth, Delegation Registry, Decision Explainability |
| **Agents**         | AI decides within constraints → Human oversight | Autonomous actors with scoped authority          | Secretary Agent, Treasury Agent, Delegate Agent            |

### Democratic Safeguards

All AI capabilities are designed with democratic principles (McKinney Framework):

| Safeguard                | Implementation                                            |
| ------------------------ | --------------------------------------------------------- |
| **Inclusiveness**        | AI cannot exclude members; human oversight on recruitment |
| **Popular Control**      | Humans retain final authority; delegation revocable       |
| **Considered Judgement** | Confidence scoring; escalation on uncertainty             |
| **Transparency**         | All AI actions labeled; reasoning logged                  |

---

## Progressive Disclosure Framework

### Principle

> "Anticipate user needs, build the infrastructure, but don't overwhelm. Let users discover AI capabilities as they need them."

### Implementation Layers

| Layer                     | Visibility                         | User Action Required | Examples                              |
| ------------------------- | ---------------------------------- | -------------------- | ------------------------------------- |
| **Layer 0: Invisible**    | Hidden, runs in background         | None                 | Workflow Automator, Deadline Enforcer |
| **Layer 1: Suggested**    | Appears contextually when relevant | Dismiss or accept    | "This looks similar to Proposal #42"  |
| **Layer 2: Discoverable** | In menus, settings, not prominent  | Navigate to find     | AI Settings page, "Enable Q&A" toggle |
| **Layer 3: Prominent**    | Visible in main UI, but optional   | Click to use         | "✨ Summarize" button on proposal     |
| **Layer 4: Guided**       | Part of onboarding/wizard          | Follow prompts       | DAO Setup Wizard with AI suggestions  |

### Progressive Disclosure Rules

1. **Max 2-3 layers deep** - Don't bury features too far
2. **Right split** - Frequent features upfront, rare features secondary
3. **Clear affordances** - Users must know MORE exists
4. **Contextual reveal** - Show AI options when relevant (proposal page → proposal AI)
5. **Opt-in progression** - User enables category → individual features appear
6. **Zero-state education** - When AI is off, show what they're missing (subtle)

---

## AI Configuration Model

**Decision**: AI features are **opt-in per DAO** with **configurable settings at DAO level**.

| Setting                     | Scope     | Default          |
| --------------------------- | --------- | ---------------- |
| `ai.enabled`                | DAO-level | `false` (opt-in) |
| `ai.conversational.enabled` | DAO-level | `false`          |
| `ai.utility.enabled`        | DAO-level | `false`          |
| Individual feature toggles  | DAO-level | `false`          |

**Rationale**: For governance software with fiduciary implications, opt-in respects:

- User consent and privacy expectations
- Cost predictability (no surprise LLM usage)
- Governance-sensitive organizations that may prohibit AI

### Feature Rollout Strategy

| Phase        | AI Enabled | Features Visible | User Experience                       |
| ------------ | ---------- | ---------------- | ------------------------------------- |
| **Off**      | No         | None             | No AI UI elements shown               |
| **Basic**    | Yes        | Layer 0-1 only   | Background automation + suggestions   |
| **Standard** | Yes        | Layer 0-3        | + Prominent features like Summarize   |
| **Advanced** | Yes        | All layers       | + Discoverable features like NL Rules |

This allows DAOs to "turn the dial" on AI sophistication as they're ready.

---

## Primitive Inventory & Build Map

### Complete Primitive Inventory (Platform + AI)

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              TIER 0: FOUNDATION (LIVE)                                  │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│  PLATFORM (8)                       │  AI (0)                                           │
│  ✅ Privy Auth & Identity           │  (none yet)                                       │
│  ✅ DAO CRUD & Members              │                                                   │
│  ✅ Proposals & Voting              │                                                   │
│  ✅ Safe Treasury                   │                                                   │
│  ✅ Gasless Execution               │                                                   │
│  ✅ 4-Layer Protection              │                                                   │
│  ✅ Audit Logging                   │                                                   │
│  ✅ FeeRouter (5%/2%)               │                                                   │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                      ↓
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                         TIER 1: SINGLE DAO EXCELLENCE                                   │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│  PLATFORM (5)                       │  AI CONVERSATIONAL (5)    AI UTILITY (12)         │
│  ✅ Discussion System               │  ⬜ Proposal Summarizer   ⬜ Workflow Automator    │
│  ✅ Notification System             │  ⬜ Plain Language Trans  ⬜ Deadline Enforcer     │
│  ✅ Onboarding Templates            │  ⬜ Governance Q&A        ⬜ Notification Router   │
│  ✅ Reporting Dashboard             │  ⬜ Draft Assistant       ⬜ Onboarding Sequencer  │
│  ⬜ Member Wallet View              │  ⬜ Onboarding Guide      ⬜ Task Tracker          │
│                                     │                          ⬜ Calendar Sync         │
│                                     │                          ⬜ Report Scheduler      │
│                                     │                          ⬜ Data Import Agent     │
│                                     │                          ⬜ Document Organizer    │
│                                     │                          ⬜ Auto-Triage           │
│                                     │                          ⬜ Duplicate Detector    │
│                                     │                          ⬜ DAO Setup Wizard      │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                      ↓
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                         TIER 2: OPERATIONAL MATURITY                                    │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│  PLATFORM (6)                       │  AI ANALYSIS (6)          AI UTILITY (2)          │
│  ⬜ Quick Polls                     │  ⬜ Discussion Synthesizer ⬜ Meeting Processor    │
│  ⬜ Email Participation             │  ⬜ Devil's Advocate       ⬜ Natural Lang Rules   │
│  ⬜ Spending Limits                 │  ⬜ Quality Metrics                               │
│  ⬜ Observer Role                   │  ⬜ Sentiment Monitor                             │
│  ⬜ Implementation Tracking         │  ⬜ Content Moderator                             │
│  ⬜ Evidence Attachment             │  ⬜ Report Generator                              │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                      ↓
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                         TIER 3: NETWORK FOUNDATION                                      │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│  PLATFORM (4)                       │  AI INFRASTRUCTURE (6)                            │
│  ⬜ Sub-DAO Architecture            │  ⬜ API Key Auth                                  │
│  ⬜ Social Recovery                 │  ⬜ Agent Member Type                             │
│  ⬜ Commerce vs Community           │  ⬜ Delegation Registry                           │
│  ⬜ Public API                      │  ⬜ Capability Permissions                        │
│                                     │  ⬜ Decision Explainability                       │
│                                     │  ⬜ Human-in-Loop Triggers                        │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                      ↓
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                         TIER 4: ENTERPRISE FEDERATION                                   │
├─────────────────────────────────────────────────────────────────────────────────────────┤
│  PLATFORM (4)                       │  AI AGENTS (6)                                    │
│  ⬜ DAO-to-DAO Relationships        │  ⬜ Secretary Agent                               │
│  ⬜ Enterprise Dashboard            │  ⬜ Analyst Agent                                 │
│  ⬜ White-Label                     │  ⬜ Compliance Agent                              │
│  ⬜ Federation Protocol             │  ⬜ Delegate Agent                                │
│                                     │  ⬜ Treasury Agent                                │
│                                     │  ⬜ Arbiter Agent                                 │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### Primitive Count by Tier

| Tier      | Platform | AI Conversational | AI Utility | AI Analysis | AI Infra | AI Agents | Total  |
| --------- | -------- | ----------------- | ---------- | ----------- | -------- | --------- | ------ |
| 0         | 8 (live) | -                 | -          | -           | -        | -         | 8      |
| 1         | 5        | 5                 | 12         | -           | -        | -         | 22     |
| 2         | 6        | -                 | 2          | 6           | -        | -         | 14     |
| 3         | 4        | -                 | -          | -           | 6        | -         | 10     |
| 4         | 4        | -                 | -          | -           | -        | 6         | 10     |
| **Total** | **27**   | **5**             | **14**     | **6**       | **6**    | **6**     | **64** |

---

## Critical Path: Big Four

The most important primitives to architect for extensibility:

| Primitive               | Tier | Type     | Unlocks                           | Priority    |
| ----------------------- | ---- | -------- | --------------------------------- | ----------- |
| **Discussion System**   | 1    | Platform | 6 enterprise caps + 5 AI Analysis | 🔴 CRITICAL |
| **Notification System** | 1    | Platform | 5 enterprise caps + 3 AI Utility  | 🔴 CRITICAL |
| **Reporting Dashboard** | 1    | Platform | 7 enterprise caps + 4 AI features | 🔴 CRITICAL |
| **Public API**          | 3    | Platform | 6 enterprise caps + agent auth    | 🔴 CRITICAL |

### Why the Big Four Matter

These four primitives unlock the most downstream capabilities:

**Discussion System** enables:

- Cross-DAO deliberation and federated forums
- White-label deployments with custom discussion policies
- DAO-to-DAO marketplace negotiations
- AI agents (Discussion Synthesizer, Devil's Advocate, Content Moderator, Sentiment Monitor, Analyst Agent)
- Participatory budgeting deliberation
- Multi-language/internationalization content

**Notification System** enables:

- Federated alerts and cross-DAO digest
- White-label email templates
- Mobile companion app push notifications
- AI agents (Deadline Enforcer, Notification Router, Human-in-Loop Triggers)
- Email participation workflows

**Reporting Dashboard** enables:

- Enterprise roll-up and cross-DAO analytics
- White-label custom metrics and report branding
- Budget management (budget vs. actual tracking)
- Compliance suite export-ready data
- AI agents (Governance Q&A, Report Scheduler, Quality Metrics, Report Generator)
- Participatory budgeting visualization

**Public API** enables:

- Partner integrations and white-label deployments
- Mobile companion app
- AI agent authentication
- Federation protocol
- Third-party integrations and developer ecosystem

---

## Tier 0: Foundation (LIVE)

**Status**: Production platform live at [endao.ai](https://endao.ai)

### What Exists (8 Platform Primitives)

| Component                  | Status  | Notes                                                   |
| -------------------------- | ------- | ------------------------------------------------------- |
| **Privy Authentication**   | ✅ Live | Email/social login, embedded wallet                     |
| **DAO CRUD**               | ✅ Live | Create, read, update, soft-delete DAOs                  |
| **Member Management**      | ✅ Live | Binary roles (Admin/Member), profile management         |
| **Proposal System**        | ✅ Live | 4 types: general, funding, governance, bounty           |
| **Simple Voting**          | ✅ Live | Yes/No voting, quorum enforcement                       |
| **Treasury (Gnosis Safe)** | ✅ Live | 2-of-3 multi-sig on Base mainnet                        |
| **Gasless Execution**      | ✅ Live | Biconomy MEE-7579 integration                           |
| **4-Layer Protection**     | ✅ Live | Status checks, freeze, grace period, emergency recovery |
| **Ledger Recording**       | ✅ Live | Full audit trail of treasury transactions               |
| **FeeRouter**              | ✅ Live | 5% contribution fee / 2% transfer fee                   |

**Tier 0 Status**: COMPLETE - ready to build on

**SPEC Reference**: See `/docs/MASTER_IMPLEMENTATION_SPEC.md` for detailed technical specifications.

---

## Tier 1: Single DAO Excellence

**Goal**: Make one DAO work beautifully before scaling

**Priority Framework**: What's missing for "Single DAO Excellence"?

- Better deliberation (Discussion System)
- Better notifications (Notification System)
- Better onboarding (Templates)
- Better reporting (Reporting Dashboard)
- Better member experience (Wallet View)
- AI assistance for understanding and automation

---

### 1.1 Discussion & Deliberation System

**Purpose**: Enable community deliberation before proposals, improve decision quality
**Why Critical**: Current flow jumps straight to proposals - no space to form ideas, debate, or answer questions

| Use Case                               | Acceptance Criteria                                           |
| -------------------------------------- | ------------------------------------------------------------- |
| Member discusses idea before proposing | Discussion created without vote, can convert to proposal      |
| Community debates contentious topic    | Pro/Con arguments visible, flat structure prevents flame wars |
| Proposer answers member questions      | Q&A section with proposer-only answers                        |
| Discussion reaches consensus           | Clear path to convert discussion → formal proposal            |
| Admins moderate toxic content          | Flag/hide/delete capabilities with audit trail                |

**Dependencies**: None (standalone)
**Complexity**: Medium
**Network Extension**: Cross-DAO deliberation, federated forums

**Data Model**:

```typescript
interface Discussion {
  id: string;
  daoId: string;
  creatorId: string;
  title: string;
  description: string;
  status: 'active' | 'resolved' | 'converted_to_proposal' | 'archived';
  proposalId?: string; // If converted
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

interface DiscussionComment {
  id: string;
  discussionId: string;
  authorId: string;
  content: string;
  parentCommentId?: string; // For threading
  reactions: Record<string, string[]>; // emoji -> userIds
  createdAt: Timestamp;
}
```

---

### 1.2 In-App Notification System

**Purpose**: Alert members of governance activity without manual checking
**Why Critical**: Without notifications, engagement requires members to manually check for updates

| Use Case                                | Acceptance Criteria                                        |
| --------------------------------------- | ---------------------------------------------------------- |
| Member notified of new proposal         | Bell icon badge, notification in feed                      |
| Admin notified of pending signature     | Push to notification center, email option                  |
| Member reminded before vote closes      | 24h warning notification                                   |
| Member notified of discussion reply     | Real-time or batched digest                                |
| Member configures preferences           | Per-event notification settings (in-app, email, SMS, none) |
| Member receives SMS for critical alerts | Treasury alerts, security alerts, vote reminders           |

**Dependencies**: None (standalone)
**Complexity**: Low-Medium
**Network Extension**: Federated alerts, cross-DAO digest, webhook mesh

**Data Model**:

```typescript
interface Notification {
  id: string
  userId: string
  daoId: string
  type: 'proposal_created' | 'vote_reminder' | 'signature_needed' | 'discussion_reply' | ...
  title: string
  message: string
  actionUrl?: string
  read: boolean
  createdAt: Timestamp
}

interface NotificationPreferences {
  userId: string
  daoId: string
  channels: {
    inApp: boolean
    email: boolean
    push?: boolean  // Mobile push notifications
    sms: boolean    // SMS for critical alerts
  }
  smsConfig?: {
    phoneNumber: string     // E.164 format
    verified: boolean
    categories: ('voting' | 'treasury' | 'security')[]
  }
  events: Record<NotificationType, boolean>
}
```

**SMS Integration**:

- **Provider**: Twilio
- **Use Cases**: Vote reminders (24h before close), Treasury alerts (critical), Security alerts (new device login)
- **Opt-in**: User must verify phone number before receiving SMS
- **Cost**: SMS costs passed through to DAO (premium feature in subscription tiers)

---

### 1.3 Onboarding Templates

**Purpose**: Guide new DAOs through setup with pre-configured governance
**Why Critical**: Friction at DAO creation leads to abandonment

| Use Case                    | Acceptance Criteria                                                     |
| --------------------------- | ----------------------------------------------------------------------- |
| Nonprofit creates DAO       | Selects "Nonprofit" template, pre-filled governance settings            |
| HOA creates DAO             | Selects "Community Association" template with appropriate quorum/voting |
| Investment club creates DAO | Selects "Investment Club" template with treasury focus                  |
| Custom DAO setup            | Blank template, manual configuration                                    |
| New member joins            | Guided tour of key features, contextual tips                            |

**Dependencies**: None (standalone)
**Complexity**: Low
**Network Extension**: Template marketplace, white-label branding

**Template Types**:

- Nonprofit (high quorum, longer voting periods, focus on mission)
- Community Association/HOA (consent governance, member privacy)
- Investment Club (treasury focus, spending limits, reporting)
- Cooperative (equal voting, labor equity)
- Professional Association (committees, observer roles)
- Custom (blank slate)

**Data Model**:

```typescript
interface DAOTemplate {
  id: string;
  name: string;
  description: string;
  category:
    | 'nonprofit'
    | 'hoa'
    | 'investment'
    | 'cooperative'
    | 'professional'
    | 'custom';
  defaultSettings: {
    votingPeriodDays: number;
    quorumPercentage: number;
    passThreshold: number;
    privacyLevel: 'public' | 'member-only';
  };
  onboardingSteps: OnboardingStep[];
  recommendedContent: string[]; // Links to Education Hub content
}
```

---

### 1.3.1 Education Hub

**Purpose**: Shared content platform for DAO education and platform usage guidance
**Why Critical**: Users need to understand both DAOs (concept) and EnDAO (platform) to be effective

**Two Purposes**:

1. **DAO Education**: What are DAOs, governance concepts, use cases, best practices
2. **Platform Usage**: How to use EnDAO features, guided tutorials, FAQs

| Use Case                     | Acceptance Criteria                               |
| ---------------------------- | ------------------------------------------------- |
| New user learns about DAOs   | Reads "What is a DAO?" guide before/during signup |
| DAO creator selects template | Gets template-specific education path             |
| Member learns to vote        | Contextual tutorial on first vote                 |
| Admin sets up treasury       | Step-by-step guide with screenshots               |
| Mobile user browses content  | Education content renders properly on mobile      |

**Dependencies**: Onboarding Templates (1.3) for integration
**Complexity**: Medium
**Network Extension**: Template marketplace, white-label content, community translations

**Design Principle**: Shared content model that works on both web and mobile from day one.

**Data Model**:

```typescript
interface EducationContent {
  id: string;
  slug: string; // URL-friendly identifier
  type: 'article' | 'guide' | 'tutorial' | 'faq';
  title: string;
  summary: string; // Short preview for cards
  content: string; // Markdown content

  category:
    | 'governance'
    | 'treasury'
    | 'membership'
    | 'getting-started'
    | 'best-practices';
  audience: (
    | 'nonprofit'
    | 'hoa'
    | 'investment_club'
    | 'cooperative'
    | 'community'
  )[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';

  platforms: ('web' | 'mobile')[];
  mobileOptimized: boolean;
  readTimeMinutes: number;

  relatedContentIds: string[];
  nextContentId?: string; // For learning paths
}
```

**Integration Points**:

- Template selection → Education path assignment
- First-time actions → Contextual tutorials
- Help buttons → Relevant articles
- Mobile app → Same content, mobile-optimized rendering

---

### 1.4 Governance Reporting Dashboard

**Purpose**: Visibility into governance health, activity, and treasury status
**Why Critical**: No visibility = no trust = no engagement

| Use Case                         | Acceptance Criteria                                                       |
| -------------------------------- | ------------------------------------------------------------------------- |
| Admin views governance health    | Dashboard shows: proposal pass rate, voter participation, avg voting time |
| Treasurer views treasury status  | Shows: balance, recent transactions, monthly burn rate                    |
| Member views activity feed       | Timeline of proposals, votes, treasury movements                          |
| Admin exports reports            | CSV/PDF export for compliance, audits                                     |
| Observer reviews historical data | Read-only access to all metrics                                           |

**Dependencies**: None (standalone, uses existing data)
**Complexity**: Medium
**Network Extension**: Cross-DAO analytics, enterprise roll-up

**Metrics to Track**:

- **Governance Health**: Proposal count, pass rate, voter participation rate, avg time to vote
- **Treasury**: Current balance, monthly inflow/outflow, burn rate, largest transactions
- **Engagement**: Active members, proposal comments, discussion activity
- **Compliance**: Deadlines, officer changes, filings due

**Data Model** (derived from existing data):

```typescript
interface GovernanceMetrics {
  daoId: string;
  period: 'daily' | 'weekly' | 'monthly';
  proposalCount: number;
  passRate: number;
  voterParticipation: number;
  avgVotingTime: number;
  activeMembers: number;
}

interface TreasuryMetrics {
  daoId: string;
  period: 'daily' | 'weekly' | 'monthly';
  balance: number;
  inflow: number;
  outflow: number;
  burnRate: number;
  transactionCount: number;
}
```

---

### 1.5 Member Wallet Integration

**Purpose**: Members need to see their own holdings and activity
**Why Critical**: Personal finance view builds engagement and transparency

| Use Case                           | Acceptance Criteria                                |
| ---------------------------------- | -------------------------------------------------- |
| Member views personal wallet       | Shows connected wallets, balance (if applicable)   |
| Member views transaction history   | Personal ledger of contributions/receipts from DAO |
| Member manages profile preferences | Notification settings, display name, bio, avatar   |
| Member connects external wallet    | Link external wallet to profile                    |
| Member views voting history        | Past votes, current delegations                    |

**Dependencies**: Privy wallet infrastructure (exists)
**Complexity**: Medium
**Network Extension**: Cross-DAO portfolio, unified identity

**SPEC Reference**: §2.7.3 (Member Profile Integration)

**Data Model** (extends existing user profile):

```typescript
interface MemberWalletView {
  userId: string;
  connectedWallets: {
    address: string;
    provider: 'privy' | 'external';
    balance?: number;
  }[];
  transactionHistory: {
    daoId: string;
    type: 'contribution' | 'receipt' | 'vote' | 'proposal';
    amount?: number;
    timestamp: Timestamp;
  }[];
  votingHistory: {
    proposalId: string;
    vote: 'yes' | 'no' | 'abstain';
    timestamp: Timestamp;
  }[];
}
```

---

### 1.6 AI: Conversational Suite (5 features)

**Purpose**: AI that helps members understand and participate in governance

**Disclosure Layer**: Layer 3 (Prominent) - Visible buttons/search in main UI
**AI Provider**: OpenAI/Anthropic API
**Dependencies**: Varies by feature (see below)

#### 1.6.1 Proposal Summarizer

**Purpose**: Generate TL;DR for long proposals
**Why Critical**: Reduces cognitive load, improves accessibility

| Use Case                    | Acceptance Criteria                                     |
| --------------------------- | ------------------------------------------------------- |
| Long proposal needs summary | AI generates 2-3 sentence summary on proposal card      |
| Member clicks "Summarize"   | Summary appears with attribution "AI-generated summary" |
| Summary is inaccurate       | Member can dismiss, report issue                        |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Low
**Network Extension**: Cross-DAO proposal digest
**Implementation**: Read proposal → LLM API → display summary

---

#### 1.6.2 Plain Language Translator

**Purpose**: Rewrite complex governance text in accessible language
**Why Critical**: Improves inclusivity, reduces barriers to participation

| Use Case                      | Acceptance Criteria                                      |
| ----------------------------- | -------------------------------------------------------- |
| Complex governance text       | Member clicks "Simplify" → AI rewrites in plain language |
| Legal jargon in proposal      | AI explains terms in context                             |
| Member unfamiliar with crypto | AI translates technical terms                            |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Low
**Network Extension**: Accessibility across DAOs, multi-language support foundation
**Implementation**: Read text → LLM API (plain language instruction) → display rewrite

---

#### 1.6.3 Governance Q&A

**Purpose**: Answer questions about DAO history, bylaws, past decisions
**Why Critical**: Reduces repetitive questions, helps new members

| Use Case                                  | Acceptance Criteria                                         |
| ----------------------------------------- | ----------------------------------------------------------- |
| Member asks "What did we decide about X?" | AI searches history, answers with source links              |
| Member asks about bylaws                  | AI explains rules in plain language                         |
| AI doesn't know                           | Responds "I don't have that information" (no hallucination) |
| Question is ambiguous                     | AI asks clarifying question                                 |

**Dependencies**: Reporting Dashboard (Tier 1)
**Complexity**: Medium (RAG required for search)
**Network Extension**: Cross-DAO knowledge base, federated Q&A
**Implementation**: Question → RAG search (proposals, discussions, settings) → LLM synthesis → answer with sources

---

#### 1.6.4 Draft Assistant

**Purpose**: Help members write proposals, comments, discussion posts
**Why Critical**: Lowers barrier to participation, improves quality

| Use Case                           | Acceptance Criteria                        |
| ---------------------------------- | ------------------------------------------ |
| Member needs help writing proposal | AI suggests structure, sections, language  |
| Member wants to refine draft       | AI improves clarity, grammar, tone         |
| Member stuck on complex topic      | AI provides outline, key points to address |

**Dependencies**: Templates (Tier 1), Proposal System (Tier 0) ✅
**Complexity**: Low-Medium
**Network Extension**: Shared template library, best practice patterns
**Implementation**: Draft text + template context → LLM API → suggestions

---

#### 1.6.5 Onboarding Guide

**Purpose**: Explain DAO to new members in personalized way
**Why Critical**: Reduces onboarding friction, builds engagement

| Use Case                            | Acceptance Criteria                           |
| ----------------------------------- | --------------------------------------------- |
| New member joins                    | AI explains DAO purpose, norms, key decisions |
| Member asks "How does voting work?" | AI explains with examples from this DAO       |
| Member unfamiliar with DAOs         | AI provides gentle introduction to concepts   |

**Dependencies**: DAO Settings (Tier 0) ✅
**Complexity**: Low
**Network Extension**: Federated onboarding, white-label welcome messages
**Implementation**: DAO config + member context → LLM API → personalized explanation

---

### 1.7 AI: Utility Suite (12 features)

**Purpose**: AI that automates governance workflows and data management

**Disclosure Layer**: Layer 0-1 (Invisible or Suggested) - Runs in background or appears contextually
**AI Provider**: Background workers + LLM for smart routing
**Dependencies**: Varies by feature (see below)

#### 1.7.1 Workflow Automator

**Purpose**: Manage proposal lifecycle automatically
**Why Critical**: Ensures nothing falls through cracks, reduces admin burden

| Use Case                 | Acceptance Criteria                              |
| ------------------------ | ------------------------------------------------ |
| Proposal passes          | Status auto-updates to "Awaiting Implementation" |
| Implementation complete  | Workflow prompts for evidence attachment         |
| Proposal execution fails | Auto-escalates to admins with error details      |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Low-Medium
**Disclosure**: Layer 0 (Invisible)
**Network Extension**: Cross-DAO workflow templates
**Implementation**: Watch proposal status changes → trigger next actions

---

#### 1.7.2 Deadline Enforcer

**Purpose**: Reminders, auto-close, escalation for time-sensitive actions
**Why Critical**: Prevents voter apathy, ensures timely decisions

| Use Case               | Acceptance Criteria                          |
| ---------------------- | -------------------------------------------- |
| Vote ends in 24h       | Reminder sent to non-voters                  |
| Vote deadline passes   | Proposal auto-closes, results tallied        |
| Implementation overdue | Escalation notification to assignee + admins |

**Dependencies**: Notification System (Tier 1)
**Complexity**: Low
**Disclosure**: Layer 0 (Invisible)
**Network Extension**: Federated deadline tracking
**Implementation**: Cron job checks deadlines → send notifications → auto-close

---

#### 1.7.3 Notification Router

**Purpose**: Smart alert distribution based on role, interest, urgency
**Why Critical**: Right people notified at right time, reduces noise

| Use Case             | Acceptance Criteria                                                |
| -------------------- | ------------------------------------------------------------------ |
| New funding proposal | Notifies treasurers, finance committee, all members (configurable) |
| Signature needed     | Notifies only signers, escalates if delayed                        |
| Discussion reply     | Notifies only discussion participants                              |

**Dependencies**: Notification System (Tier 1)
**Complexity**: Medium (rule engine + LLM for smart routing)
**Disclosure**: Layer 0 (Invisible)
**Network Extension**: Cross-DAO alert routing, federated notifications
**Implementation**: Event occurs → routing rules + AI categorization → targeted notifications

---

#### 1.7.4 Onboarding Sequencer

**Purpose**: Multi-step new member flow automatically
**Why Critical**: Consistent onboarding, reduces admin burden

| Use Case              | Acceptance Criteria                       |
| --------------------- | ----------------------------------------- |
| New member joins      | 5-step welcome flow starts automatically  |
| Step 1: Profile setup | Prompts for bio, avatar, preferences      |
| Step 2: DAO tour      | Guided walkthrough of key features        |
| Step 3: First vote    | Encourages participation on open proposal |
| Step 4: Introduction  | Prompts to introduce self in discussion   |
| Step 5: Resources     | Links to DAO docs, bylaws, FAQs           |

**Dependencies**: Member System (Tier 0) ✅, Notification System (Tier 1)
**Complexity**: Low
**Disclosure**: Layer 4 (Guided)
**Network Extension**: Federated onboarding paths, white-label welcome flows
**Implementation**: New member event → trigger sequenced notifications + UI prompts

---

#### 1.7.5 Task Tracker

**Purpose**: Implementation status tracking, assignments, reminders
**Why Critical**: Visibility into execution of passed proposals

| Use Case        | Acceptance Criteria                                         |
| --------------- | ----------------------------------------------------------- |
| Proposal passes | Creates task, assigns to owner (or prompts admin to assign) |
| Task updated    | Owner can mark progress, add comments                       |
| Task overdue    | Sends reminder, escalates to admins                         |
| Task completed  | Prompts for evidence attachment, marks proposal as executed |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Low-Medium
**Disclosure**: Layer 2 (Discoverable)
**Network Extension**: Cross-DAO project management, federated milestones
**Implementation**: Passed proposal → create task → track status → send reminders

---

#### 1.7.6 Calendar Sync

**Purpose**: Governance events appear on shared calendar
**Why Critical**: Vote deadlines, meeting dates visible in familiar tools

| Use Case          | Acceptance Criteria                 |
| ----------------- | ----------------------------------- |
| Proposal created  | Vote deadline added to DAO calendar |
| Meeting scheduled | Event added with reminder           |
| Calendar exported | iCal/Google Calendar sync available |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Low
**Disclosure**: Layer 2 (Discoverable)
**Network Extension**: Federated governance calendar
**Implementation**: Governance event → create calendar event → expose iCal feed

---

#### 1.7.7 Report Scheduler

**Purpose**: Recurring reports, auto-send to stakeholders
**Why Critical**: Regular transparency without manual effort

| Use Case                 | Acceptance Criteria                            |
| ------------------------ | ---------------------------------------------- |
| Weekly governance digest | Auto-generates summary, emails to members      |
| Monthly treasury report  | Auto-generates financial summary, exports PDF  |
| Quarterly compliance     | Prepares required data, alerts admin to review |

**Dependencies**: Reporting Dashboard (Tier 1), Notification System (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 2 (Discoverable)
**Network Extension**: Enterprise roll-up scheduling, white-label report branding
**Implementation**: Cron schedule → generate report from metrics → send via notification system

---

#### 1.7.8 Data Import Agent

**Purpose**: CSV import, external sync, data migration
**Why Critical**: Reduces manual data entry, enables migration from other tools

| Use Case                 | Acceptance Criteria                                |
| ------------------------ | -------------------------------------------------- |
| Admin uploads member CSV | AI parses, validates, creates member records       |
| CSV has errors           | AI flags issues, suggests corrections              |
| External system sync     | Periodic import from Google Sheets, Airtable, etc. |

**Dependencies**: Member System (Tier 0) ✅, Treasury System (Tier 0) ✅
**Complexity**: Medium
**Disclosure**: Layer 2 (Discoverable)
**Network Extension**: Cross-DAO data migration, standardized formats
**Implementation**: File upload → parse CSV → validate + LLM for fuzzy matching → create records

---

#### 1.7.9 Document Organizer

**Purpose**: Auto-tag, version, index uploaded files
**Why Critical**: Searchability, governance record-keeping

| Use Case                  | Acceptance Criteria                   |
| ------------------------- | ------------------------------------- |
| File attached to proposal | AI extracts metadata, suggests tags   |
| Document updated          | Version tracking, diff view           |
| Search for document       | Full-text search, tag-based filtering |

**Dependencies**: Evidence Attachment (Tier 2)
**Complexity**: Medium
**Disclosure**: Layer 0 (Invisible)
**Network Extension**: Shared document registry, cross-DAO search
**Implementation**: File upload → extract text → LLM categorization → index for search

---

#### 1.7.10 Auto-Triage (NEW)

**Purpose**: Auto-assign proposals, suggest labels, route to committees
**Why Critical**: Reduces admin burden, ensures right people see proposals

| Use Case            | Acceptance Criteria                      |
| ------------------- | ---------------------------------------- |
| Proposal submitted  | AI suggests: assignee, labels, committee |
| Funding proposal    | Auto-routes to finance committee         |
| Governance proposal | Auto-routes to governance committee      |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Medium (ML categorization)
**Disclosure**: Layer 1 (Suggested)
**Network Extension**: Cross-DAO triage patterns, federated routing
**Implementation**: New proposal → analyze content → suggest assignments (admin can override)

**Inspired by**: Linear's Triage Intelligence

---

#### 1.7.11 Duplicate Detector (NEW)

**Purpose**: Flag when new proposal resembles existing/past proposals
**Why Critical**: Prevents redundant work, highlights precedent

| Use Case              | Acceptance Criteria                          |
| --------------------- | -------------------------------------------- |
| New proposal created  | AI checks similarity to existing proposals   |
| High similarity found | Pop-up: "This looks similar to Proposal #42" |
| Member can dismiss    | Suggestion is advisory, not blocking         |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Medium (semantic search)
**Disclosure**: Layer 1 (Suggested)
**Network Extension**: Cross-DAO duplicate detection
**Implementation**: New proposal → semantic search existing proposals → flag if similarity > threshold

**Inspired by**: Linear's duplicate detection

---

#### 1.7.12 DAO Setup Wizard (NEW)

**Purpose**: Admin describes org → AI generates governance config template
**Why Critical**: Reduces setup friction, suggests best practices

| Use Case           | Acceptance Criteria                               |
| ------------------ | ------------------------------------------------- |
| Admin creates DAO  | Wizard asks questions about org type, size, goals |
| AI suggests config | Voting period, quorum, roles based on answers     |
| Admin customizes   | Can override all suggestions                      |

**Dependencies**: DAO Settings (Tier 0) ✅, Templates (Tier 1)
**Complexity**: Low-Medium
**Disclosure**: Layer 4 (Guided)
**Network Extension**: White-label templates, partner-specific wizards
**Implementation**: Questionnaire → LLM analysis → generate config from template

**Inspired by**: Asana's AI Studio, Monday.com's workflow builder

---

## Tier 2: Operational Maturity

**Goal**: Enable real-world governance operations with analysis capabilities

**Prerequisite**: Tier 1 complete

---

### 2.1 Quick Polls (Sense Checks)

**Purpose**: Test ideas before formal proposals, gauge sentiment
**Why Critical**: Reduces proposal spam, builds consensus before voting

| Use Case                     | Acceptance Criteria                              |
| ---------------------------- | ------------------------------------------------ |
| Leader gauges sentiment      | Creates 24-48h poll with emoji or ranked options |
| Community prioritizes agenda | Ranked preference poll before meeting            |
| Poll results inform proposal | Clear data on member preferences                 |
| Poll converts to proposal    | "Escalate to Proposal" action available          |

**Dependencies**: Discussion System (Tier 1)
**Complexity**: Low
**Network Extension**: Cross-DAO polling, federation-wide surveys

**SPEC Reference**: ROADMAP.md §2.6

**Data Model**:

```typescript
interface QuickPoll {
  id: string;
  daoId: string;
  creatorId: string;
  question: string;
  options: string[];
  duration: number; // hours
  votingType: 'single' | 'ranked' | 'emoji';
  results: Record<string, number>;
  status: 'active' | 'closed';
  convertedToProposal?: boolean;
  proposalId?: string;
  createdAt: Timestamp;
  closesAt: Timestamp;
}
```

---

### 2.2 Email Notification & Participation

**Purpose**: Meet members where they are (inbox), enable voting via email
**Why Critical**: Increases engagement for members who don't check platform daily

| Use Case                     | Acceptance Criteria                                |
| ---------------------------- | -------------------------------------------------- |
| Member votes via email reply | Reply "Yes/No" to vote notification, vote recorded |
| Member gets digest           | Weekly summary of DAO activity emailed             |
| Member comments via reply    | Reply routes to correct discussion thread          |
| Member unsubscribes          | Email preferences respect unsubscribe              |

**Dependencies**: Notification System (Tier 1)
**Complexity**: High (email parsing, security, spam prevention)
**Network Extension**: Federated digest, cross-DAO email routing

**SPEC Reference**: ROADMAP.md §2.7

**Security Considerations**:

- Email-to-vote requires signed token in email (prevent spoofing)
- Rate limiting on email replies (prevent spam)
- Member must confirm email address ownership

---

### 2.3 Spending Limits Enforcement

**Purpose**: Day-to-day operations without full governance vote
**Why Critical**: Enables operational velocity while maintaining oversight

| Use Case                         | Acceptance Criteria                            |
| -------------------------------- | ---------------------------------------------- |
| Treasurer pays vendor under $500 | Executes without governance vote               |
| Transaction over $500            | Requires secondary approval or governance vote |
| Daily limit reached              | Blocks further transactions until next day     |
| Monthly budget allocation        | Admin sets spending pools by category          |

**Dependencies**: Treasury System (Tier 0) ✅
**Complexity**: Medium (app-layer first, on-chain enforcement later)
**Network Extension**: Sub-DAO budget allocation, cross-treasury limits

**SPEC Reference**: §3.3, §3.5, §1.3 (Spending Limits)

**Implementation Phases**:

1. **Phase 1 (Tier 2)**: App-layer limits (Firestore rules + API validation)
2. **Phase 2 (Tier 3)**: On-chain limits via Safe modules

---

### 2.4 Observer Role

**Purpose**: Grant read access to auditors, advisors, partners
**Why Critical**: External oversight without governance participation

| Use Case                     | Acceptance Criteria                               |
| ---------------------------- | ------------------------------------------------- |
| Accountant reviews treasury  | Can view all transactions, cannot vote or propose |
| Lawyer reviews governance    | Can view proposals, discussions, cannot vote      |
| Board advisor monitors       | Can comment on discussions, cannot vote           |
| Investor observes operations | Read-only dashboard access                        |

**Dependencies**: None (extends existing role system)
**Complexity**: Low (add `observer` role to existing schema)
**Network Extension**: Federated oversight, enterprise compliance view

**SPEC Reference**: ROADMAP.md §2.16

**Data Model** (extends existing Member):

```typescript
interface Member {
  role: 'admin' | 'member' | 'observer'; // Add observer
  observerType?: 'auditor' | 'advisor' | 'investor' | 'partner';
  observerNotes?: string;
}
```

---

### 2.5 Implementation Status Tracking

**Purpose**: Visibility into execution of passed proposals
**Why Critical**: Accountability for governance decisions

| Use Case               | Acceptance Criteria                        |
| ---------------------- | ------------------------------------------ |
| Proposal passes        | Shows "Awaiting Start" status              |
| Work begins            | Assigned owner updates to "In Progress"    |
| Work completes         | Owner attaches evidence, marks "Completed" |
| Implementation blocked | Owner can flag issues, request help        |

**Dependencies**: Proposal System (Tier 0) ✅
**Complexity**: Low (extend proposal schema)
**Network Extension**: Cross-DAO project tracking, federated milestones

**SPEC Reference**: ROADMAP.md §2.10

**Data Model** (extends existing Proposal):

```typescript
interface Proposal {
  implementationStatus?:
    | 'awaiting_start'
    | 'in_progress'
    | 'blocked'
    | 'completed';
  assignedTo?: string; // Member ID
  implementationNotes?: string;
  evidenceUrls?: string[];
  completedAt?: Timestamp;
}
```

---

### 2.6 Evidence & Document Attachment

**Purpose**: Data-driven governance decisions with supporting documents
**Why Critical**: Transparency, informed voting, audit trail

| Use Case                     | Acceptance Criteria                    |
| ---------------------------- | -------------------------------------- |
| Proposer attaches budget     | PDF/XLSX uploadable to proposal        |
| Admin reviews before publish | Optional moderation gate for documents |
| Version tracking             | Document versions tracked if updated   |
| Search within documents      | Full-text search of attached files     |

**Dependencies**: None (extends proposal system)
**Complexity**: Medium (file storage, processing, search)
**Network Extension**: Shared evidence, agreement encoding, legal docs

**SPEC Reference**: ROADMAP.md §2.14

**Data Model**:

```typescript
interface Document {
  id: string;
  proposalId: string;
  uploadedBy: string;
  filename: string;
  fileType: string;
  fileSize: number;
  storageUrl: string;
  version: number;
  extractedText?: string; // For search
  tags?: string[];
  createdAt: Timestamp;
}
```

---

### 2.7 Advanced Voting Mechanisms

**Purpose**: Complete the voting primitive with all 4 voting types for full governance flexibility
**Why Critical**: Different governance contexts require different voting mechanisms

**Current Status**:
| Voting Type | Status | Notes |
|-------------|--------|-------|
| Simple (Yes/No/Abstain) | ✅ Live | Production ready |
| Ranked Choice | ✅ Live | Up to 10 options |
| Quadratic Voting | 🔶 Infrastructure | Types defined, UI "Coming Soon" |
| Weighted/Token Voting | 🔶 Infrastructure | Weight fields exist |
| Vote Delegation | 🔶 Infrastructure | Data structures ready |

**Requirement**: All 4 voting types must be fully functional by end of Tier 2.

#### 2.7.1 Quadratic Voting

| Use Case                              | Acceptance Criteria                          |
| ------------------------------------- | -------------------------------------------- |
| Member expresses preference intensity | Can allocate "voice credits" across options  |
| Cost scales quadratically             | 1 vote = 1 credit, 2 votes = 4 credits, etc. |
| Results show preference strength      | Display reflects quadratic-weighted totals   |
| DAO enables quadratic voting          | Toggle in governance settings                |

**Dependencies**: Voting Engine (Tier 0) ✅
**Complexity**: Medium (calculation logic, UI for credit allocation)

#### 2.7.2 Weighted/Token Voting

| Use Case                    | Acceptance Criteria                                    |
| --------------------------- | ------------------------------------------------------ |
| Stake-based voting          | Vote weight proportional to token holdings             |
| Configurable weight sources | DAO chooses: equal, token-based, reputation-based      |
| Weight displayed clearly    | Member sees their vote weight before casting           |
| Historical weight snapshot  | Weight captured at proposal creation (prevents gaming) |

**Dependencies**: Voting Engine (Tier 0) ✅
**Complexity**: Medium (weight calculation, snapshot mechanism)

#### 2.7.3 Vote Delegation

| Use Case                          | Acceptance Criteria                    |
| --------------------------------- | -------------------------------------- |
| Member delegates to trusted voter | One-click delegation to another member |
| Delegation is revocable           | Can revoke at any time                 |
| Delegate sees delegated power     | Dashboard shows delegated votes        |
| Delegation chains                 | Optional: A → B → C delegation         |

**Dependencies**: Member System (Tier 0) ✅, Voting Engine (Tier 0) ✅
**Complexity**: Medium-High (delegation tracking, transitive delegation optional)

**Data Model** (extends existing Voting):

```typescript
interface VotingConfig {
  votingType: 'simple' | 'ranked' | 'quadratic' | 'weighted';
  weightSource?: 'equal' | 'token' | 'reputation' | 'custom';
  quadraticCredits?: number; // Per member
  delegationEnabled: boolean;
  delegationChainDepth?: number; // Max depth, 0 = no chains
}

interface Delegation {
  id: string;
  daoId: string;
  fromMemberId: string;
  toMemberId: string;
  scope: 'all' | 'proposal_type' | 'specific_proposal';
  scopeFilter?: string[];
  createdAt: Timestamp;
  revokedAt?: Timestamp;
}
```

---

### 2.8 AI: Analysis Suite (6 features)

**Purpose**: AI monitors governance quality, surfaces insights

**Disclosure Layer**: Layer 1-2 (Suggested or Discoverable) - Context-aware, not always visible
**AI Provider**: OpenAI/Anthropic with RAG for context
**Dependencies**: Discussion System (Tier 1), Reporting Dashboard (Tier 1)

#### 2.8.1 Discussion Synthesizer

**Purpose**: AI summarizes discussion threads
**Why Critical**: Long discussions hard to follow; synthesis helps latecomers

| Use Case                              | Acceptance Criteria                       |
| ------------------------------------- | ----------------------------------------- |
| Discussion has 20+ comments           | AI generates summary of key points        |
| New member joins discussion           | Can quickly understand current state      |
| Summary updates as discussion evolves | Re-generates when significant new content |

**Dependencies**: Discussion System (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 2 (Discoverable - "Show Summary" link)
**Network Extension**: Cross-DAO deliberation synthesis
**Implementation**: Read discussion + comments → LLM synthesis → display summary

---

#### 2.8.2 Devil's Advocate

**Purpose**: Surface counterarguments to prevent groupthink (McKinney App #6)
**Why Critical**: Research shows flat argument structure reduces polarization

| Use Case                       | Acceptance Criteria                                   |
| ------------------------------ | ----------------------------------------------------- |
| Proposal has no opposing views | AI suggests counterargument (labeled as AI-generated) |
| Discussion is one-sided        | AI flags missing perspectives                         |
| Human can dismiss              | AI suggestion can be hidden/dismissed                 |
| AI argument sparks debate      | Members respond to AI's point (success metric)        |

**Dependencies**: Discussion System (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 1 (Suggested - appears when one-sided detected)
**Network Extension**: Cross-DAO perspective sharing
**Implementation**: Analyze discussion sentiment → detect one-sided → generate counterargument

**McKinney Framework Alignment**: Application #6 - Challenge groupthink

---

#### 2.8.3 Quality Metrics

**Purpose**: Score deliberation quality (engagement, diversity, respect)
**Why Critical**: Data-driven governance improvement

| Use Case                      | Acceptance Criteria                                             |
| ----------------------------- | --------------------------------------------------------------- |
| Discussion evaluated          | Metrics: participation %, argument diversity, sentiment balance |
| Admin views quality dashboard | See trends over time, identify issues                           |
| Low quality flagged           | Alert admins to discussions needing moderation                  |

**Dependencies**: Discussion System (Tier 1), Reporting Dashboard (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 2 (Discoverable - in reporting dashboard)
**Network Extension**: Federation quality standards, benchmarking
**Implementation**: Analyze discussion patterns → calculate metrics → display in dashboard

**McKinney Framework Alignment**: Application #11 - Assess deliberative quality

---

#### 2.8.4 Sentiment Monitor

**Purpose**: Track discussion emotional dynamics
**Why Critical**: Identify heated discussions before they become toxic

| Use Case                  | Acceptance Criteria                      |
| ------------------------- | ---------------------------------------- |
| Discussion getting heated | AI surfaces "temperature" indicator      |
| High negativity detected  | Alert admins, suggest cooling-off period |
| Positive sentiment trends | Highlight constructive discussions       |

**Dependencies**: Discussion System (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 1 (Suggested - appears when heated detected)
**Network Extension**: Cross-DAO sentiment dashboard
**Implementation**: Real-time sentiment analysis → display indicator → alert on threshold

**McKinney Framework Alignment**: Application #7 - Monitor emotional dynamics

---

#### 2.8.5 Content Moderator

**Purpose**: Flag toxic content, suggest improvements
**Why Critical**: Healthy discussions require moderation

| Use Case                   | Acceptance Criteria                        |
| -------------------------- | ------------------------------------------ |
| Toxic comment posted       | AI flags for admin review, suggests edit   |
| Spam detected              | Auto-hide, alert admins                    |
| Personal attack identified | Flag with severity level, recommend action |

**Dependencies**: Discussion System (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 0 (Invisible - runs in background)
**Network Extension**: Shared moderation policies, cross-DAO reporting
**Implementation**: Comment posted → toxicity check → flag/hide → notify admins

---

#### 2.8.6 Report Generator

**Purpose**: Create governance summaries, impact reports
**Why Critical**: Regular transparency without manual effort

| Use Case                       | Acceptance Criteria                                |
| ------------------------------ | -------------------------------------------------- |
| Admin needs monthly report     | AI generates governance health summary with charts |
| Annual report for stakeholders | AI compiles year-in-review with key metrics        |
| Compliance report              | AI prepares required data for filing               |

**Dependencies**: Reporting Dashboard (Tier 1)
**Complexity**: Medium
**Disclosure**: Layer 2 (Discoverable - in reporting tools)
**Network Extension**: Enterprise roll-up reports, white-label branding
**Implementation**: Query metrics → LLM narrative generation → format report

**McKinney Framework Alignment**: Application #9 - Draft recommendations

---

### 2.9 AI: Utility Suite - Tier 2 (2 features)

#### 2.9.1 Meeting Processor (NEW)

**Purpose**: Upload recording/notes → extract decisions, create tasks
**Why Critical**: Automates post-meeting work, ensures action items tracked

| Use Case                       | Acceptance Criteria                               |
| ------------------------------ | ------------------------------------------------- |
| Upload board meeting recording | AI transcribes, extracts decisions, action items  |
| Meeting notes uploaded         | AI parses, creates proposals/tasks from decisions |
| Action items assigned          | Creates tasks, assigns to owners mentioned        |

**Dependencies**: Task Tracker (Tier 1), Proposal System (Tier 0) ✅
**Complexity**: High (transcription + parsing)
**Disclosure**: Layer 2 (Discoverable)
**Network Extension**: Cross-DAO meeting coordination
**Implementation**: Audio/text upload → transcribe → LLM extract decisions → create records

**Inspired by**: Monday.com's meeting processor

---

#### 2.9.2 Natural Language Rules (NEW)

**Purpose**: Admin describes rule → system creates automation
**Why Critical**: Democratizes automation, no coding required

| Use Case               | Acceptance Criteria                             |
| ---------------------- | ----------------------------------------------- |
| Admin wants automation | Describes: "Send reminder 24h before vote ends" |
| AI configures workflow | Creates trigger + action                        |
| Admin approves         | Reviews, activates automation                   |

**Dependencies**: Notification System (Tier 1), Workflow Automator (Tier 1)
**Complexity**: High (NL understanding + workflow generation)
**Disclosure**: Layer 2 (Discoverable - in automation settings)
**Network Extension**: White-label automation templates
**Implementation**: NL input → parse intent → generate workflow config → confirm with admin

**Inspired by**: Monday.com's workflow builder, Asana's AI Studio

---

## Tier 3: Network Foundation

**Goal**: Enable organizational relationships and AI agent infrastructure

**Prerequisite**: Tier 2 complete

---

### 3.1 Sub-DAO Architecture

**Purpose**: Departments, chapters, working groups as child DAOs
**Why Critical**: Organizational hierarchy enables federated governance

| Use Case                 | Acceptance Criteria                          |
| ------------------------ | -------------------------------------------- |
| Parent creates child DAO | Sub-DAO inherits settings, separate treasury |
| Child requests budget    | Proposal routes to parent for approval       |
| Org chart visualization  | Shows hierarchy of sub-DAOs                  |
| Permission inheritance   | Child admins can be granted by parent        |

**Dependencies**: Tier 2 complete
**Complexity**: High (hierarchy, permissions, treasury allocation)
**Network Extension**: Multi-level hierarchy, cross-sub-DAO governance

**SPEC Reference**: §5.1 (Sub-DAO Hierarchy)

**Data Model**:

```typescript
interface DAO {
  parentDaoId?: string; // Null for root DAOs
  childDaoIds?: string[];
  hierarchyLevel: number; // 0 = root, 1 = child, 2 = grandchild
  budgetAllocation?: {
    parentDaoId: string;
    amount: number;
    period: 'monthly' | 'quarterly' | 'annual';
  };
}
```

---

### 3.2 Social Recovery System

**Purpose**: Non-crypto users can recover DAO access via trusted guardians
**Why Critical**: Non-custodial wallets are scary without recovery

| Use Case                   | Acceptance Criteria                |
| -------------------------- | ---------------------------------- |
| Admin designates guardians | 3-5 trusted individuals added      |
| User loses access          | Guardian initiates recovery        |
| Multiple guardians approve | 3-of-5 threshold triggers recovery |
| 7-day timelock             | Admin can cancel during window     |

**Dependencies**: Safe integration (Tier 0) ✅
**Complexity**: High (Safe social recovery module integration)
**Network Extension**: Cross-DAO guardian networks

**SPEC Reference**: §6.2, §10.1.1 (MVP blocker per spec)

**Implementation**: Gnosis Safe Social Recovery Module

---

### 3.3 Commerce vs Community Split

**Purpose**: Optimize governance for DAO type
**Why Critical**: Different use cases need different defaults

| Use Case                | Acceptance Criteria                                      |
| ----------------------- | -------------------------------------------------------- |
| Commerce DAO created    | Gets Safe by default, higher quorum, formal voting       |
| Community DAO created   | Tracking-only treasury, consent governance, lower quorum |
| Migration between types | Governance vote to change type, warns of implications    |

**Dependencies**: DAO creation flow (Tier 0) ✅
**Complexity**: Medium (schema + UI flow)
**Network Extension**: Type-specific federation rules

**SPEC Reference**: §4 (Commerce vs Community)

**Data Model** (extends DAO):

```typescript
interface DAO {
  type: 'commerce' | 'community';
  commerceConfig?: {
    requiresMultiSig: boolean;
    defaultQuorum: number; // Higher for commerce
    votingPeriodDays: number; // Longer for commerce
  };
  communityConfig?: {
    consentGovernance: boolean;
    socialRecovery: boolean;
    trackingOnlyTreasury: boolean;
  };
}
```

---

### 3.4 Public API & Developer Portal

**Purpose**: Third-party integrations, partner deployments
**Why Critical**: Ecosystem growth, white-label deployments, mobile app

| Use Case               | Acceptance Criteria                            |
| ---------------------- | ---------------------------------------------- |
| Developer gets API key | Self-service key management                    |
| Read-only API calls    | GET endpoints for proposals, members, treasury |
| Rate limiting          | Tier-based limits enforced                     |
| Webhook subscriptions  | Developers subscribe to governance events      |
| API documentation      | OpenAPI spec, interactive docs                 |

**Dependencies**: Tiered subscription system
**Complexity**: Medium (REST API + auth + docs)
**Network Extension**: Cross-DAO API federation, agent authentication

**SPEC Reference**: §9 (API Architecture)

**Endpoints** (initial):

- `GET /api/v1/daos/:id`
- `GET /api/v1/daos/:id/proposals`
- `GET /api/v1/daos/:id/members`
- `GET /api/v1/daos/:id/treasury/balance`
- `POST /api/v1/webhooks` (subscribe to events)

---

### 3.5 AI Infrastructure (6 features)

**Purpose**: Build the rails for AI agent participation in governance

**Dependencies**: Tier 1-2 platform primitives complete
**Complexity**: High (new data models, security, permissions)

#### 3.5.1 API Key Authentication

**Purpose**: Authenticate agents separately from humans
**Why Critical**: Agents need identity for API access

| Use Case                  | Acceptance Criteria                      |
| ------------------------- | ---------------------------------------- |
| DAO creates agent API key | Key scoped to DAO, specific capabilities |
| Agent authenticates       | Uses API key in requests                 |
| Key rotation              | Admin can revoke, regenerate keys        |
| Audit trail               | All agent API calls logged               |

**Dependencies**: Public API (Tier 3)
**Complexity**: Medium
**Network Extension**: Cross-DAO agent identity, federated auth

---

#### 3.5.2 Agent Member Type

**Purpose**: Data model foundation for AI agents as DAO participants
**Why Critical**: Distinguishes agents from humans in governance

| Use Case                    | Acceptance Criteria                       |
| --------------------------- | ----------------------------------------- |
| DAO adds AI agent           | Member created with `memberType: 'agent'` |
| Agent has separate identity | Distinct from human members in UI         |
| Agent actions labeled       | All AI actions visually identified        |

**Dependencies**: Member model (Tier 0) ✅
**Complexity**: Low (schema change)
**Network Extension**: Cross-DAO agent registry

**Data Model** (extends Member):

```typescript
interface Member {
  memberType: 'human' | 'agent';
  agentConfig?: {
    provider: 'endao' | 'external';
    capabilities: AgentCapability[];
    delegatedBy: string[]; // Human member IDs
    constraints: AgentConstraint[];
    confidenceThreshold: number; // Escalate if below
  };
}
```

---

#### 3.5.3 Delegation Registry

**Purpose**: Track human → agent authority grants
**Why Critical**: Humans must be able to delegate and revoke authority

| Use Case                      | Acceptance Criteria                             |
| ----------------------------- | ----------------------------------------------- |
| Member delegates voting to AI | Creates delegation record with constraints      |
| Member revokes delegation     | Instantly removes agent authority               |
| Delegation has limits         | Scope (vote/spend), amount caps, proposal types |
| Audit trail                   | All delegations logged immutably                |

**Dependencies**: Permission system (Tier 0) ✅, Agent Member Type (3.5.2)
**Complexity**: Medium
**Network Extension**: Cross-DAO delegation, federated authority

**Data Model**:

```typescript
interface Delegation {
  id: string;
  fromMemberId: string; // Human
  toAgentId: string; // Agent
  scope: DelegationScope; // 'vote' | 'spend' | 'read'
  constraints: {
    maxAmount?: number;
    categories?: string[];
    proposalTypes?: string[];
    confidenceThreshold?: number;
  };
  createdAt: Timestamp;
  revokedAt?: Timestamp;
}
```

---

#### 3.5.4 Capability Permissions

**Purpose**: Granular scopes for agent authority (read/vote/spend up to X)
**Why Critical**: Fine-grained control prevents agent overreach

| Use Case                      | Acceptance Criteria                    |
| ----------------------------- | -------------------------------------- |
| Agent granted read-only       | Can query data, cannot vote or spend   |
| Agent granted vote authority  | Can vote on proposals, cannot spend    |
| Agent granted spend authority | Can execute transactions within limits |
| Capability revocation         | Admin can remove specific capabilities |

**Dependencies**: Role system (Tier 0) ✅, Agent Member Type (3.5.2)
**Complexity**: Medium
**Network Extension**: Permission inheritance across DAOs

**Capabilities**:

- `read`: Query DAO data
- `vote`: Cast votes on proposals
- `propose`: Create proposals
- `spend`: Execute treasury transactions (within limits)
- `moderate`: Flag content for review
- `report`: Generate reports

---

#### 3.5.5 Decision Explainability

**Purpose**: Audit trail for AI reasoning
**Why Critical**: Accountability requires understanding why AI acted

| Use Case                        | Acceptance Criteria                              |
| ------------------------------- | ------------------------------------------------ |
| Agent votes on proposal         | Logs reasoning, confidence score, input context  |
| Admin reviews AI decisions      | Dashboard shows all AI actions with explanations |
| Human overrides AI              | Override logged with reason                      |
| Regulation requires explanation | Full audit trail exportable                      |

**Dependencies**: Audit logging (Tier 0) ✅, Agent Member Type (3.5.2)
**Complexity**: Medium
**Network Extension**: Cross-DAO AI audit, federated oversight

**Data Model**:

```typescript
interface AgentDecision {
  agentId: string;
  action: string;
  reasoning: string; // AI explanation
  confidence: number;
  inputContext: string[];
  timestamp: Timestamp;
  humanOverride?: {
    overriddenBy: string;
    reason: string;
    timestamp: Timestamp;
  };
}
```

---

#### 3.5.6 Human-in-Loop Triggers

**Purpose**: Escalation when confidence < threshold or high-stakes decision
**Why Critical**: Safety mechanism for agent autonomy

| Use Case                            | Acceptance Criteria                             |
| ----------------------------------- | ----------------------------------------------- |
| Agent makes low-confidence decision | Escalates to human, logs reasoning              |
| High-stakes action (large spend)    | Always requires human approval                  |
| Agent detects edge case             | Flags for human review                          |
| Human can adjust threshold          | Per-agent, per-capability confidence thresholds |

**Dependencies**: Notification System (Tier 1), Delegation Registry (3.5.3)
**Complexity**: Medium
**Network Extension**: Federated escalation, cross-DAO human oversight

**Escalation Triggers**:

- Confidence < threshold (configurable)
- Transaction amount > limit
- Proposal type = governance (changes rules)
- Anomaly detected (unusual pattern)
- Agent requests help (uncertainty flag)

---

## Tier 4: Enterprise Federation

**Goal**: Cross-organization governance + AI agent participation

**Prerequisite**: Tier 3 complete

---

### 4.1 DAO-to-DAO Relationships

**Purpose**: Enable vendor/customer, partner, joint venture relationships
**Why Critical**: Organizations need to transact and govern together

| Use Case                    | Acceptance Criteria                          |
| --------------------------- | -------------------------------------------- |
| DAOs establish relationship | Mutual agreement creates relationship record |
| Relationship types          | Vendor/customer, partner, investor, member   |
| Shared proposals            | Proposal requires approval from both DAOs    |
| Cross-treasury payments     | Automated payments based on agreements       |

**Dependencies**: Tier 3 complete
**Complexity**: Very High
**Network Extension**: Federation protocol, multi-DAO governance

**SPEC Reference**: §5.2-5.3

**Data Model**:

```typescript
interface DaoRelationship {
  id: string;
  daoId1: string;
  daoId2: string;
  type: 'vendor_customer' | 'partner' | 'investor' | 'member';
  status: 'pending' | 'active' | 'suspended' | 'terminated';
  agreement?: {
    documentUrl: string;
    terms: string;
    startDate: Timestamp;
    endDate?: Timestamp;
  };
  createdAt: Timestamp;
}
```

---

### 4.2 Enterprise Dashboard & White-Label

**Purpose**: Roll-up view of multiple DAOs, custom branding
**Why Critical**: Partners need oversight, branding for deployments

| Use Case                      | Acceptance Criteria                                 |
| ----------------------------- | --------------------------------------------------- |
| Enterprise views all sub-DAOs | Consolidated dashboard with key metrics             |
| White-label deployment        | Custom logo, colors, domain per deployment          |
| Partner admin access          | Observer role across all client DAOs                |
| Roll-up reporting             | Aggregated governance, treasury, compliance metrics |

**Dependencies**: Tier 3 complete
**Complexity**: Very High
**Network Extension**: Multi-tenant architecture, partner ecosystem

**SPEC Reference**: ROADMAP.md §4.2

---

### 4.3 Federation Protocol

**Purpose**: Cross-DAO identity, discovery, interoperability
**Why Critical**: DAO-to-DAO interactions need standards

| Use Case                    | Acceptance Criteria                               |
| --------------------------- | ------------------------------------------------- |
| DAO registers on network    | Verified identity, ENS name, metadata             |
| DAOs discover each other    | Searchable registry, filtering by type/location   |
| Shared governance standards | Interoperable proposal formats, voting mechanisms |
| Cross-DAO communication     | Standardized messaging, webhook mesh              |

**Dependencies**: Tier 3 complete
**Complexity**: Very High
**Network Extension**: Open protocol for any DAO platform

**SPEC Reference**: ROADMAP.md §4.3, §5.4

---

### 4.4 AI Agents (6 features)

**Purpose**: Autonomous AI agents as governance participants with scoped authority

**Dependencies**: All Tier 3 AI Infrastructure primitives
**Complexity**: Very High (autonomous decision-making, safety, oversight)

#### 4.4.1 Secretary Agent

**Purpose**: Autonomous agent for meeting minutes, action items, Q&A
**Why Critical**: Reduces volunteer burnout, first read-only agent

| Use Case                     | Acceptance Criteria                             |
| ---------------------------- | ----------------------------------------------- |
| Meeting ends                 | Secretary drafts minutes from discussion thread |
| Minutes need approval        | Human admin approves before publishing          |
| Member asks routine question | Secretary answers based on DAO history          |
| Action item created          | Secretary tracks status, sends reminders        |

**Authority Scope**: Read-only governance access
**Human Oversight**: Human approves all published content
**Dependencies**: Discussion System (Tier 1), Notification System (Tier 1), Reporting Dashboard (Tier 1), Templates (Tier 1)
**Complexity**: High

---

#### 4.4.2 Analyst Agent

**Purpose**: Autonomous agent for proposal analysis, risk flagging, impact modeling
**Why Critical**: Helps voters make informed decisions

| Use Case                         | Acceptance Criteria                   |
| -------------------------------- | ------------------------------------- |
| New funding proposal             | Analyst generates risk assessment     |
| Complex governance proposal      | Analyst models potential impacts      |
| Proposal similar to past failure | Analyst flags precedent               |
| Voter asks for analysis          | Analyst provides summary with sources |

**Authority Scope**: Read-only, advisory output
**Human Oversight**: Humans decide; analyst only advises
**Dependencies**: Reporting Dashboard (Tier 1), Discussion System (Tier 1), Proposal Summarizer (Tier 1)
**Complexity**: High

---

#### 4.4.3 Delegate Agent

**Purpose**: Autonomous agent that votes on behalf of members per stated preferences
**Why Critical**: Enables participation for time-constrained members

| Use Case                      | Acceptance Criteria                       |
| ----------------------------- | ----------------------------------------- |
| Member configures preferences | "Vote yes on budget proposals under $10K" |
| Proposal matches preferences  | Delegate votes per rules, logs reasoning  |
| Low confidence                | Delegate abstains, notifies human         |
| Human overrides               | Vote changed, override logged             |

**Authority Scope**: Delegated vote power (revocable)
**Human Oversight**: Revocable delegation, confidence thresholds
**Dependencies**: Voting Engine (Tier 0) ✅, Delegation Registry (Tier 3), Human-in-Loop Triggers (Tier 3)
**Complexity**: Very High

**McKinney Framework Alignment**: Respects popular control - delegation is voluntary and revocable

---

#### 4.4.4 Compliance Agent

**Purpose**: Autonomous agent for regulatory compliance monitoring
**Why Critical**: CTA/BOI filing, deadlines, officer tracking

| Use Case                    | Acceptance Criteria                       |
| --------------------------- | ----------------------------------------- |
| Officer change approved     | Compliance detects BOI-reportable event   |
| Filing deadline approaching | Compliance alerts admins 30 days before   |
| Compliance prepares filing  | Human certifies before submission         |
| Audit requested             | Compliance generates report with evidence |

**Authority Scope**: Read governance, prepare filings (no auto-submit)
**Human Oversight**: Human certifies all regulatory submissions
**Dependencies**: Reporting Dashboard (Tier 1), Officer Registry, Evidence Attachment (Tier 2)
**Complexity**: High

---

#### 4.4.5 Treasury Agent

**Purpose**: Autonomous agent for treasury operations within parameters
**Why Critical**: Routine payments without human bottleneck

| Use Case                    | Acceptance Criteria                                 |
| --------------------------- | --------------------------------------------------- |
| Approved vendor payment due | Agent executes within pre-approved limits           |
| Payment exceeds limit       | Agent escalates to human                            |
| Agent logs reasoning        | Full audit trail of all treasury actions            |
| Agent optimizes yield       | Moves idle funds to safe yield (within constraints) |

**Authority Scope**: Spend within voted parameters (daily/transaction limits)
**Human Oversight**: Humans set parameters; agent operates within
**Dependencies**: Spending Limits (Tier 2), Delegation Registry (Tier 3), Ledger (Tier 0) ✅, Safe Integration (Tier 0) ✅
**Complexity**: Very High (treasury is critical path)

**Security**: All treasury agent actions require human-approved spending limits and daily/monthly caps

---

#### 4.4.6 Arbiter Agent (Experimental)

**Purpose**: Autonomous agent for dispute resolution, bylaw interpretation
**Why Critical**: Routine disputes can be resolved without human intervention

| Use Case                       | Acceptance Criteria                          |
| ------------------------------ | -------------------------------------------- |
| Member disputes interpretation | Arbiter explains bylaws, suggests resolution |
| Routine dispute arises         | Arbiter proposes solution based on precedent |
| Edge case detected             | Arbiter escalates to humans                  |
| Human appeal path              | Members can challenge arbiter decisions      |

**Authority Scope**: Advisory, can escalate but not enforce
**Human Oversight**: Human appeal path for all decisions
**Dependencies**: Discussion System (Tier 1), Evidence Attachment (Tier 2), Human-in-Loop Triggers (Tier 3)
**Complexity**: Very High (legal/ethical implications)

**Note**: This agent is experimental and requires careful legal/ethical review before deployment

---

### 4.5 Cross-DAO AI Coordination

**Purpose**: Enable AI agents to coordinate across DAOs
**Why Critical**: Federation requires agent-to-agent communication

| Use Case                      | Acceptance Criteria                                 |
| ----------------------------- | --------------------------------------------------- |
| Sub-DAO agent requests budget | Routes to parent DAO for approval                   |
| Federated compliance          | Cross-DAO compliance reporting                      |
| Shared knowledge base         | Q&A agents can query federated history              |
| Agent-to-agent messaging      | Standardized protocol for inter-agent communication |

**Dependencies**: All Tier 3-4 AI primitives, Federation Protocol (4.3)
**Complexity**: Very High

---

## Enterprise Capability Scaffolding

### What Each Enterprise Capability Requires

This section traces the primitive dependencies for key enterprise capabilities.

#### Cross-DAO Shared Proposals

**Requires**:

- [Tier 0] ✅ Proposal system
- [Tier 0] ✅ Voting engine
- [Tier 1] ⬜ Discussion system (for cross-DAO deliberation)
- [Tier 1] ⬜ Notification system (for multi-DAO alerts)
- [Tier 3] ⬜ Sub-DAO architecture (relationship model)
- [Tier 3] ⬜ DAO-to-DAO relationship registry
- [Tier 4] ⬜ Dual-approval workflow
- [Tier 4] ⬜ Cross-DAO notification routing

#### White-Label / Custom Deployments

**Requires**:

- [Tier 0] ✅ Repository pattern (data layer abstraction)
- [Tier 0] ✅ DAO settings (configurable governance params)
- [Tier 1] ⬜ Templates & onboarding (customizable flows)
- [Tier 1] ⬜ Theming system (CSS variables, brand colors, logo)
- [Tier 2] ⬜ Custom domain support (per-DAO vanity URLs)
- [Tier 2] ⬜ Observer role (partner admin access)
- [Tier 3] ⬜ Public API (partner integrations)
- [Tier 3] ⬜ Multi-tenant isolation (data segregation per deployment)
- [Tier 4] ⬜ Custom role definitions (partner-specific roles)
- [Tier 4] ⬜ Plugin architecture (custom modules)

#### Participatory Budgeting

**Requires**:

- [Tier 0] ✅ Proposal system
- [Tier 0] ✅ Voting engine
- [Tier 0] ✅ Treasury execution
- [Tier 1] ⬜ Discussion system (budget deliberation)
- [Tier 1] ⬜ Reporting dashboard (budget visualization)
- [Tier 2] ⬜ Quick polls (priority sensing)
- [Tier 2] ⬜ Spending limits (budget pool constraints)
- [Tier 3] ⬜ Knapsack voting algorithm (constraint-aware voting)
- [Tier 3] ⬜ Budget pool management (define allocation pool)
- [Tier 4] ⬜ Auto-execution (vote → treasury disbursement)

**Competitive Moat**: Civic tech platforms vote on budgets but can't execute them. EnDAO votes AND executes via Safe.

---

## Appendix A: Primitive Frequency Analysis

**How many enterprise capabilities does each primitive unlock?**

| Primitive                   | Enterprise Capabilities Enabled                                            | Priority Score |
| --------------------------- | -------------------------------------------------------------------------- | -------------- |
| **Discussion System**       | 6 (Shared Proposals, White-Label, Marketplace, Budget Mgmt, AI Agents, PB) | 🔴 CRITICAL    |
| **Reporting Dashboard**     | 7 (Dashboard, White-Label, Budget Mgmt, Compliance, AI Agents, PB, Mobile) | 🔴 CRITICAL    |
| **Notification System**     | 5 (Shared Proposals, White-Label, AI Agents, Mobile, Alerts)               | 🔴 CRITICAL    |
| **Public API**              | 6 (Dashboard, Federation, White-Label, Mobile, AI Agents, Integrations)    | 🔴 CRITICAL    |
| **Templates & Onboarding**  | 4 (Federation, White-Label, i18n, Marketplace)                             | 🟡 HIGH        |
| **Observer Role**           | 4 (Dashboard, Compliance, White-Label, AI Agents)                          | 🟡 HIGH        |
| **Spending Limits**         | 5 (Cross-Treasury, Budget Mgmt, AI Agents, PB, Ops Wallet)                 | 🟡 HIGH        |
| **Evidence Attachment**     | 3 (Marketplace, Compliance, Agreement Encoding)                            | 🟡 HIGH        |
| **Quick Polls**             | 2 (PB, Mobile)                                                             | 🟢 MEDIUM      |
| **Implementation Tracking** | 2 (Marketplace, Project Tracking)                                          | 🟢 MEDIUM      |

---

## Appendix B: AI Primitive → Platform Dependency Map

| AI Primitive              | Type     | Platform Dependency                                       | Status           |
| ------------------------- | -------- | --------------------------------------------------------- | ---------------- |
| **TIER 1 CONVERSATIONAL** |          |                                                           |                  |
| Proposal Summarizer       | Conv     | Proposal System (Tier 0)                                  | ✅ Can build now |
| Plain Language Translator | Conv     | Proposal System (Tier 0)                                  | ✅ Can build now |
| Governance Q&A            | Conv     | Reporting Dashboard (Tier 1)                              | ⬜ Blocked       |
| Draft Assistant           | Conv     | Templates (Tier 1)                                        | ⬜ Blocked       |
| Onboarding Guide          | Conv     | DAO Settings (Tier 0)                                     | ✅ Can build now |
| **TIER 1 UTILITY**        |          |                                                           |                  |
| Workflow Automator        | Util     | Proposal System (Tier 0)                                  | ✅ Can build now |
| Deadline Enforcer         | Util     | Notification System (Tier 1)                              | ⬜ Blocked       |
| Notification Router       | Util     | Notification System (Tier 1)                              | ⬜ Blocked       |
| Onboarding Sequencer      | Util     | Member System (Tier 0)                                    | ✅ Can build now |
| Task Tracker              | Util     | Proposal System (Tier 0)                                  | ✅ Can build now |
| Calendar Sync             | Util     | Proposal System (Tier 0)                                  | ✅ Can build now |
| Report Scheduler          | Util     | Reporting Dashboard (Tier 1)                              | ⬜ Blocked       |
| Data Import Agent         | Util     | Member System (Tier 0)                                    | ✅ Can build now |
| Document Organizer        | Util     | Evidence Attachment (Tier 2)                              | ⬜ Blocked       |
| Auto-Triage               | Util     | Proposal System (Tier 0)                                  | ✅ Can build now |
| Duplicate Detector        | Util     | Proposal System (Tier 0)                                  | ✅ Can build now |
| DAO Setup Wizard          | Util     | DAO Settings (Tier 0)                                     | ✅ Can build now |
| **TIER 2 ANALYSIS**       |          |                                                           |                  |
| Discussion Synthesizer    | Analysis | Discussion System (Tier 1)                                | ⬜ Blocked       |
| Devil's Advocate          | Analysis | Discussion System (Tier 1)                                | ⬜ Blocked       |
| Quality Metrics           | Analysis | Reporting Dashboard (Tier 1)                              | ⬜ Blocked       |
| Sentiment Monitor         | Analysis | Discussion System (Tier 1)                                | ⬜ Blocked       |
| Content Moderator         | Analysis | Discussion System (Tier 1)                                | ⬜ Blocked       |
| Report Generator          | Analysis | Reporting Dashboard (Tier 1)                              | ⬜ Blocked       |
| **TIER 2 UTILITY**        |          |                                                           |                  |
| Meeting Processor         | Util     | Task Tracker (Tier 1), Proposal System (Tier 0)           | ⬜ Blocked       |
| Natural Language Rules    | Util     | Notification System (Tier 1), Workflow Automator (Tier 1) | ⬜ Blocked       |
| **TIER 3 INFRASTRUCTURE** |          |                                                           |                  |
| API Key Auth              | Infra    | Public API (Tier 3)                                       | ⬜ Blocked       |
| Agent Member Type         | Infra    | Member System (Tier 0)                                    | ✅ Can build now |
| Delegation Registry       | Infra    | Permission System (Tier 0)                                | ✅ Can build now |
| Capability Permissions    | Infra    | Role System (Tier 0)                                      | ✅ Can build now |
| Decision Explainability   | Infra    | Audit Logging (Tier 0)                                    | ✅ Can build now |
| Human-in-Loop Triggers    | Infra    | Notification System (Tier 1)                              | ⬜ Blocked       |
| **TIER 4 AGENTS**         |          |                                                           |                  |
| All Agents                | Agent    | Multiple Tier 1-3 dependencies                            | ⬜ Blocked       |

### Quick Win AI (11 features ready to build)

These AI features depend ONLY on Tier 0 (live) infrastructure:

**Conversational (3)**:

1. Proposal Summarizer
2. Plain Language Translator
3. Onboarding Guide

**Utility (8)**: 4. Workflow Automator 5. Onboarding Sequencer 6. Task Tracker 7. Calendar Sync 8. Data Import Agent 9. Auto-Triage 10. Duplicate Detector 11. DAO Setup Wizard

**Recommendation**: Start with these 4 to prove architecture:

1. **Proposal Summarizer** (Conversational, Layer 3) - visible, immediate value
2. **Workflow Automator** (Utility, Layer 0) - invisible, background magic
3. **Auto-Triage** (Utility, Layer 1) - suggested, learning behavior
4. **DAO Setup Wizard** (Utility, Layer 4) - guided, onboarding hook

---

## Appendix C: Mobile App Architecture

### Strategy: Dual-Track Multi-Market

EnDAO's mobile strategy operates as two parallel tracks sharing common infrastructure but diverging on UX, payments, and connectivity. See `MOBILE_STRATEGY.md` for full details.

| Track | Platform | Payment | Target Markets |
|-------|----------|---------|----------------|
| **US/Western** | Expo native app | Stripe | US, UK, EU |
| **Africa** | PWA first, native only if needed | Flutterwave, M-Pesa | Ghana → Nigeria → Kenya → East Africa |

### What's Shared (build once)

- Backend API routes (`/api/mobile/v1/*`, `/api/payments/*`)
- Supabase schema + RLS
- `@endao/shared-types`, `@endao/shared-validators`
- Auth (Privy), Core governance logic

### What Diverges

| Concern | US Track | Africa Track |
|---------|----------|--------------|
| Connectivity | Online assumed | Offline-first, 3 tiers |
| Payments | Stripe | Flutterwave → M-Pesa |
| App size | <50MB | <30MB critical |
| Language | English | English → French → Swahili |

### Current Status

- **Phase 0 (Monorepo)**: ✅ Complete
- **Phase 1 (Foundation)**: ✅ Complete
- **Phase 2 (Signed Voting)**: 🔄 In Progress
- **Phase 7 (Quality)**: ✅ Complete

### Feature Status (US Native App)

| Feature | Status | Notes |
|---------|--------|-------|
| Authentication | ✅ Built | Privy RN SDK |
| DAO List/Dashboard | ✅ Built | Home screen, pull-to-refresh |
| DAO Details | ✅ Built | Core viewing |
| Proposal List/Detail | ✅ Built | Core engagement |
| Push Notifications | ✅ Built | Expo Notifications |
| User Profile | ✅ Built | Account management |
| Signed Voting | 🔄 In Progress | EIP-712 port |
| Discussions | ⏳ Pending | |
| Image Upload | ⏳ Pending | |
| DAO Creation | ⏳ Pending | Simplified flow |
| Treasury View | ⏳ Pending | Read-only |

### Architecture Principle

**Mobile NEVER directly accesses Supabase.** All data flows through API routes:

```
Mobile App → /api/mobile/v1/* → Service Layer → Supabase
```

### Reference Documentation

- **Mobile Strategy**: `/docs/research/mobile/MOBILE_STRATEGY.md` (single source of truth for mobile + multi-market)
- **Technical Decisions**: See Mobile Strategy Section 9 (Architectural Decisions)

---

## Document Cross-References

- **Technical Specifications**: `/docs/MASTER_IMPLEMENTATION_SPEC.md`
- **Token Economics**: `/TOKEN_ROADMAP.md`
- **Mobile Strategy**: `/docs/research/mobile/MOBILE_STRATEGY.md`
- **Competitive Research**: `/docs/research/COMPETITIVE_POSITIONING_RESEARCH.md`
- **AI & Deliberation Research**: `/docs/research/DIGITAL_PB_AI_RESEARCH.md`
- **AI Agent Concepts**: `/docs/concepts/AI_AGENTS_AS_GOVERNANCE_PARTICIPANTS.md`

---

_Last Updated: December 2025_
_Status: Platform v2.2.0 live, Tier 1 planning in progress_
