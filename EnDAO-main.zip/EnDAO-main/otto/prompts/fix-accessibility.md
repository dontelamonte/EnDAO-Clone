# Task: Fix Accessibility Issues

You are Otto, an autonomous coding agent. Your task is to improve accessibility (a11y) in EnDAO's React components.

## Step 1: Discovery

Find components with potential a11y issues:

```bash
# Find clickable divs (should be buttons)
grep -rn "onClick=" src/components --include="*.tsx" | grep "<div" | head -20

# Find images without alt text
grep -rn "<img" src/components --include="*.tsx" | grep -v "alt=" | head -20

# Find inputs without labels
grep -rn "<input" src/components --include="*.tsx" | grep -v "aria-label" | head -20
```

## Step 2: Common Fixes

### Clickable Divs → Buttons

```tsx
// Before
<div onClick={handleClick} className="btn">Click me</div>

// After
<button onClick={handleClick} className="btn" type="button">
  Click me
</button>
```

### Missing Alt Text

```tsx
// Before
<img src={user.avatar} />

// After
<img src={user.avatar} alt={`${user.name}'s avatar`} />

// Decorative images
<img src="/decorative.png" alt="" aria-hidden="true" />
```

### Form Labels

```tsx
// Before
<input type="email" placeholder="Email" />

// After
<label htmlFor="email" className="sr-only">Email address</label>
<input
  id="email"
  type="email"
  placeholder="Email"
  aria-label="Email address"
/>
```

### Interactive Elements

```tsx
// Before
<span onClick={toggle}>▼</span>

// After
<button
  onClick={toggle}
  type="button"
  aria-expanded={isOpen}
  aria-label="Toggle dropdown"
>
  <span aria-hidden="true">▼</span>
</button>
```

### Focus Management

```tsx
// Add focus styles
className="focus:outline-none focus:ring-2 focus:ring-blue-500"

// Skip link for keyboard users
<a href="#main-content" className="sr-only focus:not-sr-only">
  Skip to main content
</a>
```

## Step 3: ARIA Patterns

Common ARIA attributes to add:

- `aria-label` - For elements without visible text
- `aria-labelledby` - Reference another element's text
- `aria-describedby` - Additional description
- `aria-expanded` - For toggleable elements
- `aria-hidden="true"` - Hide decorative elements
- `role="button"` - For non-button clickables (prefer actual buttons)

## Step 4: Process

1. Find components with a11y issues
2. Read the component to understand context
3. Apply appropriate fixes
4. Test with keyboard navigation mentally
5. Move to next component

## Constraints

- Don't break existing functionality
- Maintain visual appearance
- Use semantic HTML where possible (button, nav, main, etc.)
- Follow existing patterns in the codebase

Begin by running discovery commands to find issues.
