# Task: Fix no-explicit-any Warnings

You are Otto, an autonomous coding agent. Your task is to systematically fix `@typescript-eslint/no-explicit-any` warnings in the EnDAO codebase.

## Step 1: Discovery

First, find all files with `any` type warnings:

```bash
npx eslint src --quiet 2>&1 | grep "no-explicit-any" | head -50
```

Count total remaining:

```bash
npx eslint src 2>&1 | grep -c "no-explicit-any"
```

## Step 2: Strategy

For each `any` type, choose the appropriate fix:

### Option A: Use existing types

Check `src/types/` for existing interfaces:

- `dao.ts` - DAO, DAOMember, DAOSettings
- `proposal.ts` - Proposal, Vote, ProposalStatus
- `user.ts` - User, UserProfile
- `safe.ts` - SafeTransaction, SafeSignature

```typescript
// Before
const dao: any = await fetchDAO();

// After
const dao: DAO = await fetchDAO();
```

### Option B: Use `unknown` with type guards

For truly unknown data:

```typescript
// Before
function process(data: any) {
  return data.value;
}

// After
function process(data: unknown) {
  if (typeof data === 'object' && data !== null && 'value' in data) {
    return (data as { value: unknown }).value;
  }
  throw new Error('Invalid data');
}
```

### Option C: Define new interface

If no suitable type exists:

```typescript
// Before
const config: any = { ... }

// After
interface ServiceConfig {
  apiUrl: string
  timeout: number
}
const config: ServiceConfig = { ... }
```

### Option D: eslint-disable (last resort)

Only for third-party SDK issues:

```typescript
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Biconomy SDK returns untyped response
const result: any = await biconomyClient.execute();
```

## Step 3: Process Files

1. Pick 5-10 files from the ESLint output
2. Read each file to understand context
3. Apply the appropriate fix strategy
4. Run ESLint on the file to verify fix worked
5. Move to next file

## Step 4: Report Progress

After each batch, report:

- Files fixed in this iteration
- Remaining count
- Any files that couldn't be fixed and why

## Constraints

- Do NOT modify files in `node_modules/`
- Do NOT add `@ts-ignore` - use proper types or `unknown`
- Do NOT break existing functionality - run `yarn type-check` periodically
- Prefer existing types from `src/types/` over creating new ones

Begin by running the discovery commands to find files to fix.
