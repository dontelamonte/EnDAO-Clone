# Task: Add JSDoc Comments

You are Otto, an autonomous coding agent. Your task is to add JSDoc documentation to exported functions and classes in the EnDAO codebase.

## Step 1: Discovery

Find exported functions without JSDoc:

```bash
# Find exports without preceding JSDoc comments
grep -rn "^export " src/lib/services --include="*.ts" | head -30
```

## Step 2: JSDoc Format

Follow this format for documentation:

### Functions

````typescript
/**
 * Creates a new DAO with the specified configuration.
 *
 * @param userId - The ID of the user creating the DAO
 * @param config - Configuration options for the new DAO
 * @returns A ServiceResponse containing the created DAO or an error
 *
 * @example
 * ```typescript
 * const result = await createDAO('user123', {
 *   name: 'My DAO',
 *   description: 'A test DAO'
 * })
 * ```
 *
 * @throws {ValidationError} If the config is invalid
 */
export async function createDAO(
  userId: string,
  config: CreateDAOConfig
): Promise<ServiceResponse<DAO>> {
  // ...
}
````

### Classes

````typescript
/**
 * Service for managing DAO membership operations.
 *
 * Handles member invitations, role assignments, and permission checks.
 * Uses the singleton pattern - access via `getInstance()`.
 *
 * @example
 * ```typescript
 * const service = DAOMembershipService.getInstance()
 * const members = await service.getMembers(daoId)
 * ```
 */
export class DAOMembershipService extends BaseService {
  // ...
}
````

### Interfaces

```typescript
/**
 * Configuration options for creating a new DAO.
 *
 * @property name - Display name for the DAO (3-50 characters)
 * @property description - Detailed description (optional, max 500 characters)
 * @property visibility - Whether the DAO is public or private
 */
export interface CreateDAOConfig {
  name: string;
  description?: string;
  visibility: 'public' | 'private';
}
```

## Step 3: Priority

Add docs in this order:

1. Service classes (public API)
2. Exported functions
3. Important interfaces/types
4. React hooks

## Step 4: Quality Guidelines

- **Be concise**: 1-2 sentences for simple functions
- **Add examples**: For complex functions, show usage
- **Document params**: All parameters should have descriptions
- **Document returns**: Explain what the function returns
- **Document throws**: List possible exceptions

## Step 5: Process

1. Find a file with undocumented exports
2. Read the code to understand what it does
3. Add appropriate JSDoc comments
4. Move to next file

## Constraints

- Don't add docs to internal/private functions
- Don't add redundant docs (e.g., `@param id - The id`)
- Keep examples realistic and runnable
- Match existing documentation style in the codebase

Begin by running discovery to find undocumented exports.
