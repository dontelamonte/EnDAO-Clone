#!/usr/bin/env python3
"""
Otto - EnDAO's Autonomous Coding Agent
======================================

Otto automates repetitive coding tasks across the EnDAO codebase,
tracking progress and resuming across sessions.

Usage:
    python otto.py --task fix-any-types
    python otto.py --task fix-any-types --max-iterations 5
    python otto.py --task generate-tests --target src/lib/services
"""

import argparse
import asyncio
import os
import sys
from pathlib import Path

from agent import run_autonomous_agent

# Available task types
AVAILABLE_TASKS = [
    "fix-any-types",
    "generate-tests",
    "add-jsdoc",
    "fix-accessibility",
    "migrate-repositories",
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Otto - EnDAO's Autonomous Coding Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Fix all no-explicit-any warnings
    python otto.py --task fix-any-types

    # Generate tests for services (limited iterations for testing)
    python otto.py --task generate-tests --target src/lib/services --max-iterations 3

    # Add JSDoc comments to hooks
    python otto.py --task add-jsdoc --target src/hooks
        """
    )

    parser.add_argument(
        "--task",
        type=str,
        required=True,
        choices=AVAILABLE_TASKS,
        help="The task type for Otto to perform"
    )

    parser.add_argument(
        "--target",
        type=str,
        default=None,
        help="Target directory to focus on (e.g., src/lib/services)"
    )

    parser.add_argument(
        "--max-iterations",
        type=int,
        default=50,
        help="Maximum number of iterations (default: 50)"
    )

    parser.add_argument(
        "--model",
        type=str,
        default="claude-sonnet-4-20250514",
        help="Claude model to use (default: claude-sonnet-4-20250514)"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes"
    )

    return parser.parse_args()


def validate_environment():
    """Ensure required environment is set up."""
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("Error: ANTHROPIC_API_KEY environment variable is not set.")
        print("\nTo set it:")
        print("  export ANTHROPIC_API_KEY='your-api-key'")
        sys.exit(1)

    # Verify we're in the EnDAO project
    endao_root = Path(__file__).parent.parent
    if not (endao_root / "CLAUDE.md").exists():
        print("Error: Otto must be run from within the EnDAO project.")
        print(f"Expected to find CLAUDE.md at: {endao_root / 'CLAUDE.md'}")
        sys.exit(1)

    return endao_root


def main():
    args = parse_args()
    project_dir = validate_environment()

    print(f"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   🤖 OTTO - EnDAO's Autonomous Coding Agent                   ║
║                                                               ║
╠═══════════════════════════════════════════════════════════════╣
║  Task:        {args.task:<45} ║
║  Target:      {(args.target or 'entire codebase'):<45} ║
║  Max Iters:   {str(args.max_iterations):<45} ║
║  Model:       {args.model:<45} ║
║  Dry Run:     {str(args.dry_run):<45} ║
╚═══════════════════════════════════════════════════════════════╝
    """)

    if args.dry_run:
        print("🔍 DRY RUN MODE - No changes will be made\n")

    print("Starting Otto... Press Ctrl+C to pause (progress will be saved)\n")

    try:
        asyncio.run(
            run_autonomous_agent(
                task=args.task,
                target=args.target,
                project_dir=project_dir,
                max_iterations=args.max_iterations,
                model=args.model,
                dry_run=args.dry_run,
            )
        )
    except KeyboardInterrupt:
        print("\n\n⏸️  Otto paused. Progress has been saved.")
        print("   Run the same command to resume where you left off.")
    except Exception as e:
        print(f"\n❌ Otto encountered an error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
