"""
Otto Security Hooks
===================

Pre-tool-use hooks that validate bash commands for security.
Uses an allowlist approach - only explicitly permitted commands can run.

Customized for EnDAO's development environment.
"""

import os
import re
import shlex


# Allowed commands for EnDAO development
ALLOWED_COMMANDS = {
    # File inspection (read-only)
    "ls",
    "cat",
    "head",
    "tail",
    "wc",
    "grep",
    "find",

    # Directory navigation
    "pwd",
    "cd",

    # Node.js development
    "npm",
    "npx",
    "node",

    # TypeScript/JavaScript tooling
    "tsc",
    "eslint",
    "prettier",

    # Version control (safe operations only)
    "git",

    # Process inspection
    "ps",
    "lsof",

    # Utilities
    "echo",
    "sleep",
    "true",
    "false",
}

# Commands that are explicitly blocked
BLOCKED_COMMANDS = {
    "rm",        # No deletions - Otto should edit, not delete
    "rmdir",
    "mv",        # No moves - could break imports
    "curl",      # No network requests
    "wget",
    "ssh",
    "scp",
    "sudo",
    "su",
    "chmod",     # No permission changes
    "chown",
    "kill",
    "pkill",
    "killall",
}

# Git operations that are allowed
ALLOWED_GIT_OPERATIONS = {
    "status",
    "diff",
    "log",
    "show",
    "branch",
    "add",
    "commit",
    "stash",
}

# Git operations that are blocked
BLOCKED_GIT_OPERATIONS = {
    "push",      # No pushing - human should review first
    "pull",
    "fetch",
    "reset",     # No hard resets
    "rebase",
    "merge",
    "checkout",  # No branch switching
    "clone",
}


def split_command_segments(command_string: str) -> list[str]:
    """Split compound commands into individual segments."""
    segments = re.split(r"\s*(?:&&|\|\|)\s*", command_string)
    result = []
    for segment in segments:
        sub_segments = re.split(r'(?<!["\'])\s*;\s*(?!["\'])', segment)
        for sub in sub_segments:
            sub = sub.strip()
            if sub:
                result.append(sub)
    return result


def extract_commands(command_string: str) -> list[str]:
    """Extract command names from shell command string."""
    commands = []
    segments = re.split(r'(?<!["\'])\s*;\s*(?!["\'])', command_string)

    for segment in segments:
        segment = segment.strip()
        if not segment:
            continue

        try:
            tokens = shlex.split(segment)
        except ValueError:
            return []

        if not tokens:
            continue

        expect_command = True

        for token in tokens:
            if token in ("|", "||", "&&", "&"):
                expect_command = True
                continue

            if token in (
                "if", "then", "else", "elif", "fi", "for", "while",
                "until", "do", "done", "case", "esac", "in", "!", "{", "}"
            ):
                continue

            if token.startswith("-"):
                continue

            if "=" in token and not token.startswith("="):
                continue

            if expect_command:
                cmd = os.path.basename(token)
                commands.append(cmd)
                expect_command = False

    return commands


def validate_git_command(command_string: str) -> tuple[bool, str]:
    """Validate git commands - only allow safe read operations and commits."""
    try:
        tokens = shlex.split(command_string)
    except ValueError:
        return False, "Could not parse git command"

    if not tokens or tokens[0] != "git":
        return False, "Not a git command"

    if len(tokens) < 2:
        return True, ""  # Just 'git' is fine

    operation = tokens[1]

    # Check for --force flags
    if "--force" in tokens or "-f" in tokens:
        return False, "Force flags are not allowed"

    if operation in BLOCKED_GIT_OPERATIONS:
        return False, f"git {operation} is not allowed - Otto cannot {operation}"

    if operation in ALLOWED_GIT_OPERATIONS:
        return True, ""

    # Allow other read-only git operations
    return True, ""


def validate_npm_command(command_string: str) -> tuple[bool, str]:
    """Validate npm commands - block installs and publishes."""
    try:
        tokens = shlex.split(command_string)
    except ValueError:
        return False, "Could not parse npm command"

    if not tokens:
        return False, "Empty command"

    blocked_npm_ops = {"install", "i", "publish", "unpublish", "deprecate"}

    for token in tokens[1:]:
        if token in blocked_npm_ops:
            return False, f"npm {token} is not allowed - Otto cannot modify dependencies"

    return True, ""


async def bash_security_hook(input_data, tool_use_id=None, context=None):
    """
    Pre-tool-use hook validating bash commands.

    Security philosophy:
    - Otto can READ anything
    - Otto can EDIT files (via SDK tools, not bash)
    - Otto can RUN linting/type checking
    - Otto can COMMIT changes
    - Otto CANNOT delete, move, push, or install
    """
    if input_data.get("tool_name") != "Bash":
        return {}

    command = input_data.get("tool_input", {}).get("command", "")
    if not command:
        return {}

    commands = extract_commands(command)

    if not commands:
        return {
            "decision": "block",
            "reason": f"Could not parse command for security validation: {command}",
        }

    for cmd in commands:
        # Check explicit blocks first
        if cmd in BLOCKED_COMMANDS:
            return {
                "decision": "block",
                "reason": f"Command '{cmd}' is blocked for safety. Otto cannot delete, move, or modify system settings.",
            }

        # Check allowlist
        if cmd not in ALLOWED_COMMANDS:
            return {
                "decision": "block",
                "reason": f"Command '{cmd}' is not in Otto's allowed commands list.",
            }

        # Validate git operations
        if cmd == "git":
            segments = split_command_segments(command)
            for segment in segments:
                if segment.strip().startswith("git"):
                    allowed, reason = validate_git_command(segment)
                    if not allowed:
                        return {"decision": "block", "reason": reason}

        # Validate npm operations
        if cmd in ("npm", "npx"):
            segments = split_command_segments(command)
            for segment in segments:
                if segment.strip().startswith(cmd):
                    allowed, reason = validate_npm_command(segment)
                    if not allowed:
                        return {"decision": "block", "reason": reason}

    return {}
