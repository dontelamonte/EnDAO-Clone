# Otto 🤖

**EnDAO's Autonomous Coding Agent**

Otto automates repetitive coding tasks across the EnDAO codebase, tracking progress and resuming across sessions.

## Quick Start

```bash
# Install dependencies
cd otto
pip install -r requirements.txt

# Set API key
export ANTHROPIC_API_KEY='your-key'

# Run Otto
python otto.py --task fix-any-types
```

## Available Tasks

| Task                   | Description                                       |
| ---------------------- | ------------------------------------------------- |
| `fix-any-types`        | Fix `@typescript-eslint/no-explicit-any` warnings |
| `generate-tests`       | Generate unit tests for services and hooks        |
| `add-jsdoc`            | Add JSDoc documentation to exports                |
| `fix-accessibility`    | Improve component accessibility                   |
| `migrate-repositories` | Migrate Firestore calls to repository pattern     |

## Usage

```bash
# Basic usage
python otto.py --task fix-any-types

# Target specific directory
python otto.py --task generate-tests --target src/lib/services

# Limit iterations (for testing)
python otto.py --task fix-any-types --max-iterations 3

# Dry run (preview without changes)
python otto.py --task add-jsdoc --dry-run
```

## How It Works

1. **Discovery**: Otto finds files that need work
2. **Processing**: Works through files in batches (5-10 per iteration)
3. **Progress Tracking**: Saves state to `otto_progress.json`
4. **Resumption**: Can be paused (Ctrl+C) and resumed anytime

```
┌──────────────────────────────────────────────────────┐
│                   OTTO WORKFLOW                      │
├──────────────────────────────────────────────────────┤
│                                                      │
│   Start ──► Discovery ──► Process Files ──► Save    │
│               │              │                │      │
│               │              │                │      │
│               ▼              ▼                ▼      │
│           Find issues    Fix 5-10 files   Update    │
│           via ESLint     per iteration    progress  │
│               │              │                │      │
│               └──────────────┴────────────────┘      │
│                         │                            │
│                         ▼                            │
│                  More files? ──► Yes ──► Continue   │
│                         │                            │
│                         ▼                            │
│                        Done                          │
│                                                      │
└──────────────────────────────────────────────────────┘
```

## Security

Otto uses a strict allowlist for bash commands:

**Allowed**: `ls`, `cat`, `grep`, `npm`, `npx`, `git status/diff/add/commit`, `eslint`

**Blocked**: `rm`, `mv`, `git push`, `yarn install`, `curl`

Otto can:

- ✅ Read any file
- ✅ Edit files (via SDK tools)
- ✅ Run linting and type checks
- ✅ Commit changes (locally)

Otto cannot:

- ❌ Delete files
- ❌ Push to remote
- ❌ Install packages
- ❌ Make network requests

## Progress File

Progress is saved to `otto_progress.json`:

```json
{
  "task": "fix-any-types",
  "started_at": "2025-11-27T10:00:00",
  "iterations": 5,
  "files_processed": ["src/hooks/use-auth.ts", "..."],
  "files_remaining": ["src/lib/services/dao.ts", "..."],
  "errors": [],
  "last_updated": "2025-11-27T10:45:00"
}
```

To reset progress, delete this file.

## Adding New Tasks

1. Create a prompt in `prompts/your-task.md`
2. Add task name to `AVAILABLE_TASKS` in `otto.py`
3. Test with `--max-iterations 1`

## Troubleshooting

**"ANTHROPIC_API_KEY not set"**

```bash
export ANTHROPIC_API_KEY='sk-ant-...'
```

**"Command blocked by security"**
Otto only allows safe commands. Check `security.py` for the allowlist.

**"Otto seems stuck"**
Check `otto_progress.json` for errors. You can reset by deleting the file.

---

Built with the [Claude Code SDK](https://github.com/anthropics/claude-code-sdk)
