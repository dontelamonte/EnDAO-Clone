"""
Otto Agent - Core Session Logic
===============================

Handles the autonomous coding loop, progress tracking, and session management.
"""

import asyncio
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from claude_code_sdk import ClaudeCode, Message
from prompts import get_task_prompt, get_continuation_prompt
from security import bash_security_hook


# Progress tracking file
PROGRESS_FILE = "otto_progress.json"


def load_progress(project_dir: Path, task: str) -> dict:
    """Load progress from previous sessions."""
    progress_path = project_dir / PROGRESS_FILE

    if progress_path.exists():
        try:
            with open(progress_path) as f:
                data = json.load(f)
                # Only resume if same task
                if data.get("task") == task:
                    return data
        except json.JSONDecodeError:
            pass

    # Fresh start
    return {
        "task": task,
        "started_at": datetime.now().isoformat(),
        "iterations": 0,
        "files_processed": [],
        "files_remaining": [],
        "errors": [],
        "last_updated": None,
    }


def save_progress(project_dir: Path, progress: dict):
    """Save progress for session resumption."""
    progress["last_updated"] = datetime.now().isoformat()
    progress_path = project_dir / PROGRESS_FILE

    with open(progress_path, "w") as f:
        json.dump(progress, f, indent=2)


async def run_agent_session(
    prompt: str,
    project_dir: Path,
    model: str,
    dry_run: bool = False,
) -> tuple[bool, str]:
    """
    Run a single agent session with Claude.

    Returns:
        (success, summary) tuple
    """
    print(f"\n{'─' * 60}")
    print(f"🤖 Otto is working...")
    print(f"{'─' * 60}\n")

    start_time = time.time()

    # Create SDK client with security hooks
    client = ClaudeCode(
        model=model,
        cwd=str(project_dir),
        pre_tool_use_hook=bash_security_hook,
    )

    summary = ""
    tool_uses = 0

    try:
        # Stream the response
        async for event in client.stream(prompt):
            if isinstance(event, Message):
                if event.type == "text":
                    # Print assistant's thinking/response
                    print(event.content, end="", flush=True)
                    summary += event.content
                elif event.type == "tool_use":
                    tool_uses += 1
                    tool_name = event.name
                    print(f"\n  🔧 Using tool: {tool_name}")
                elif event.type == "tool_result":
                    if event.is_error:
                        print(f"  ❌ Tool error: {event.content[:200]}...")
                    else:
                        print(f"  ✅ Tool completed")

    except Exception as e:
        print(f"\n❌ Session error: {e}")
        return False, str(e)

    elapsed = time.time() - start_time
    print(f"\n\n{'─' * 60}")
    print(f"⏱️  Session completed in {elapsed:.1f}s ({tool_uses} tool uses)")
    print(f"{'─' * 60}")

    return True, summary


async def run_autonomous_agent(
    task: str,
    target: Optional[str],
    project_dir: Path,
    max_iterations: int,
    model: str,
    dry_run: bool = False,
):
    """
    Run Otto autonomously until task is complete or max iterations reached.
    """
    progress = load_progress(project_dir, task)
    is_continuation = progress["iterations"] > 0

    if is_continuation:
        print(f"📂 Resuming from iteration {progress['iterations']}")
        print(f"   Files processed: {len(progress['files_processed'])}")
        print(f"   Files remaining: {len(progress['files_remaining'])}")
    else:
        print("🆕 Starting fresh task")

    iteration = progress["iterations"]

    while iteration < max_iterations:
        iteration += 1
        progress["iterations"] = iteration

        print(f"\n{'═' * 60}")
        print(f"📍 ITERATION {iteration}/{max_iterations}")
        print(f"{'═' * 60}")

        # Get the appropriate prompt
        if iteration == 1 and not is_continuation:
            prompt = get_task_prompt(task, target, project_dir)
        else:
            prompt = get_continuation_prompt(task, progress)

        # Run the session
        success, summary = await run_agent_session(
            prompt=prompt,
            project_dir=project_dir,
            model=model,
            dry_run=dry_run,
        )

        if not success:
            progress["errors"].append({
                "iteration": iteration,
                "error": summary,
                "timestamp": datetime.now().isoformat(),
            })

        # Save progress after each iteration
        save_progress(project_dir, progress)

        # Check for completion signals in the summary
        if any(phrase in summary.lower() for phrase in [
            "all files processed",
            "no more files",
            "task complete",
            "nothing left to fix",
            "0 remaining",
        ]):
            print("\n🎉 Otto has completed the task!")
            break

        # Brief pause before next iteration
        if iteration < max_iterations:
            print("\n⏳ Starting next iteration in 3 seconds...")
            await asyncio.sleep(3)

    # Final summary
    print(f"""
╔═══════════════════════════════════════════════════════════════╗
║                     OTTO SESSION COMPLETE                     ║
╠═══════════════════════════════════════════════════════════════╣
║  Task:           {task:<41} ║
║  Iterations:     {iteration:<41} ║
║  Files Done:     {len(progress['files_processed']):<41} ║
║  Errors:         {len(progress['errors']):<41} ║
╚═══════════════════════════════════════════════════════════════╝

Progress saved to: {project_dir / PROGRESS_FILE}

To review changes:
  git diff
  git status

To commit changes:
  git add -A && git commit -m "fix: Otto automated {task}"
    """)
