"""
Otto Prompts
============

Task-specific prompts for Otto's autonomous coding sessions.
"""

from pathlib import Path
from typing import Optional


PROMPTS_DIR = Path(__file__).parent / "prompts"


def load_prompt(name: str) -> str:
    """Load a prompt template from the prompts directory."""
    prompt_path = PROMPTS_DIR / f"{name}.md"
    if prompt_path.exists():
        return prompt_path.read_text()
    raise FileNotFoundError(f"Prompt not found: {prompt_path}")


def get_task_prompt(task: str, target: Optional[str], project_dir: Path) -> str:
    """
    Get the initial prompt for a task.

    This is used on the first iteration to set up the task context.
    """
    # Load the base prompt for this task
    prompt = load_prompt(task)

    # Inject context
    context = f"""
## Project Context

- **Project Root**: {project_dir}
- **Target Directory**: {target or 'entire codebase (src/)'}
- **Type Definitions**: src/types/

## Important Rules (from CLAUDE.md)

1. **Memory Limits**: Use `NODE_OPTIONS='--max-old-space-size=8192'` for tsc/build commands
2. **Boy Scout Rule**: Fix `any` types when you touch a file
3. **No Zombie Code**: Never create .bak or _old files
4. **Prefer `unknown`**: Use `unknown` + type guards over `any`

## Your Task

"""
    return context + prompt


def get_continuation_prompt(task: str, progress: dict) -> str:
    """
    Get the continuation prompt for resuming a task.

    This is used on subsequent iterations to continue where we left off.
    """
    files_done = len(progress.get("files_processed", []))
    files_remaining = progress.get("files_remaining", [])
    errors = progress.get("errors", [])

    prompt = f"""
## Continuation - Iteration {progress.get('iterations', 0)}

You are continuing the **{task}** task.

### Progress So Far
- Files processed: {files_done}
- Files remaining: {len(files_remaining)}
- Errors encountered: {len(errors)}

### Recent Errors (if any)
{_format_errors(errors[-3:]) if errors else "None"}

### Files Still To Process
{_format_file_list(files_remaining[:20]) if files_remaining else "Run ESLint to find remaining files"}

### Instructions

1. If you have a list of remaining files, process the next batch (5-10 files)
2. If the list is empty, run ESLint to check for remaining issues
3. After fixing files, update the progress by listing what you fixed
4. If there are no more issues, respond with "Task complete - no more files to fix"

Continue the task now.
"""
    return prompt


def _format_errors(errors: list) -> str:
    """Format recent errors for display."""
    if not errors:
        return "None"

    lines = []
    for err in errors:
        lines.append(f"- Iteration {err.get('iteration')}: {err.get('error', 'Unknown')[:100]}")
    return "\n".join(lines)


def _format_file_list(files: list) -> str:
    """Format a file list for display."""
    if not files:
        return "None - run discovery"

    lines = [f"- {f}" for f in files[:20]]
    if len(files) > 20:
        lines.append(f"... and {len(files) - 20} more")
    return "\n".join(lines)
