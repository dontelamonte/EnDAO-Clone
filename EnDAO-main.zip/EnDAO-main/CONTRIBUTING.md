# Contributing

## Development Workflow

1. **Fork & Clone**

```bash
git clone https://github.com/[your-username]/endao-mvp.git
cd endao-mvp
yarn install
```

2. **Create Branch**

```bash
git checkout -b feature/your-feature
```

3. **Make Changes**

- Write code
- Add tests
- Update docs if needed

4. **Commit**

```bash
git commit -m "feat: your feature description"
```

Use conventional commits:

- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation
- `refactor:` Code refactoring
- `test:` Tests
- `chore:` Maintenance

5. **Push & PR**

```bash
git push origin feature/your-feature
```

Create pull request to `development` branch.

## Code Standards

### TypeScript & Quality

- TypeScript strict mode required
- ESLint rules enforced (including architectural rules)
- Prettier formatting applied automatically
- Tests for new features required
- No console.logs in production

### Architectural Standards

- **File Size**: 500 lines maximum (warning at 400, error at 800)
- **Function Complexity**: Cyclomatic complexity ≤ 10
- **Function Length**: 100 lines maximum per function
- **Nesting Depth**: 4 levels maximum
- **Parameters**: 4 parameters maximum per function

### Component Architecture

- **Compound Components**: Break complex UI into focused sub-components
- **Single Responsibility**: Each component has one clear purpose
- **Composition over Inheritance**: Use composition patterns for flexibility
- **Context for State**: Use React Context for component communication

### Service Architecture

- **Service Layer Pattern**: Business logic in dedicated service classes
- **Single Responsibility**: One service per business domain
- **Interface Segregation**: Small, focused service interfaces
- **Dependency Injection**: Services depend on abstractions

## Development Patterns

### Component Development

Follow the compound component pattern for complex UI:

```typescript
// ✅ Good: Compound components
export function DAOSettings() {
  return (
    <DAOSettingsProvider>
      <DAOGeneralSettings />
      <DAOGovernanceSettings />
      <DAOMembershipSettings />
    </DAOSettingsProvider>
  )
}

// ❌ Avoid: Monolithic components
export function DAOSettings() {
  // 500+ lines of mixed concerns
}
```

### Hook Organization

Organize hooks by domain in dedicated directories:

```typescript
// ✅ Good: Domain-specific hooks
hooks/dao/
├── use-dao-creation.ts
├── use-dao-data.ts
└── use-dao-members.ts

// ❌ Avoid: Generic hook naming
hooks/
├── use-data.ts
├── use-form.ts
```

### Service Development

Create focused service classes:

```typescript
// ✅ Good: Focused service
export class ProposalValidationService {
  validateProposal(proposal: CreateProposalInput): ValidationResult {
    // Single responsibility: validation only
  }
}

// ❌ Avoid: God services
export class ProposalService {
  // 1000+ lines handling CRUD, validation, voting, etc.
}
```

## Architecture Monitoring

### Pre-development Checks

Before starting work on any feature:

```bash
# Check current architecture health
yarn analyze

# Identify files needing attention
yarn check:architecture
```

### During Development

Regularly validate your changes:

```bash
# Check file sizes while developing
yarn check:files

# Analyze code complexity
yarn check:complexity
```

### Pre-commit Validation

Before committing, ensure quality standards:

```bash
# Run comprehensive architecture check
yarn check:architecture

# Generate detailed report if needed
yarn analyze
```

### Architecture Monitoring Tools

#### File Size Analysis

```bash
# Check all files
yarn check:files

# Check specific file
yarn check:files -- --file src/components/dao/large-component.tsx

# Get JSON output for tooling
yarn check:files -- --json
```

#### Complexity Analysis

```bash
# Analyze all files
yarn check:complexity

# Get detailed complexity report
yarn check:complexity -- --detailed

# Focus on specific directory
yarn check:complexity -- --path src/components/dao
```

#### Architecture Health Dashboard

```bash
# Generate comprehensive report
yarn analyze

# Create HTML dashboard for stakeholders
yarn analyze:html

# View report at reports/architecture-report.html
```

## Refactoring Guidelines

### When to Refactor

Refactor immediately if you encounter:

- Files exceeding 500 lines
- Functions with cyclomatic complexity > 10
- Components handling multiple concerns
- Services with mixed responsibilities

### Refactoring Process

1. **Analyze**: Use `yarn check:files` and `yarn check:complexity`
2. **Plan**: Identify logical component/service boundaries
3. **Extract**: Create focused sub-components or services
4. **Test**: Ensure functionality is preserved
5. **Validate**: Run `yarn check:architecture`

### Common Refactoring Patterns

- **Component Extraction**: Break large components into compound components
- **Hook Creation**: Extract reusable logic into custom hooks
- **Service Splitting**: Separate business concerns into focused services
- **Context Addition**: Add React Context for component communication

## Testing

### Required Testing

```bash
yarn test             # Unit tests
yarn type-check       # TypeScript validation
yarn lint             # Linting (including architecture rules)
yarn check:architecture  # Architecture validation
```

### Test Organization

- **Unit Tests**: Test individual components and services
- **Integration Tests**: Test component interactions
- **Architecture Tests**: Validate structural patterns

## PR Requirements

### Code Quality

- ✅ All tests pass
- ✅ No TypeScript errors
- ✅ Code formatted with Prettier
- ✅ ESLint passes (including architectural rules)
- ✅ Architecture checks pass (`yarn check:architecture`)

### Documentation

- ✅ PR description explains the change
- ✅ Large changes include architecture impact assessment
- ✅ New patterns documented in code comments

### Architecture Compliance

- ✅ No files exceed 500 lines (800 line hard limit)
- ✅ Components follow compound component pattern
- ✅ Services follow single responsibility principle
- ✅ Hooks are organized by domain
- ✅ Functions have complexity ≤ 10

### Branch Requirements

- ✅ Targets `development` branch
- ✅ Branch name follows convention: `feature/description`, `fix/description`, `refactor/description`
- ✅ Commit messages follow conventional commits format

### Architecture Review

For significant architectural changes:

- 📋 Include architecture impact assessment
- 📋 Run `yarn analyze:html` and share results
- 📋 Document new patterns in docs/REFACTORING_GUIDE.md if applicable
- 📋 Consider creating example implementations for new patterns

## Getting Help

### Architecture Questions

- Review [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for system overview
- Check [docs/REFACTORING_GUIDE.md](docs/REFACTORING_GUIDE.md) for patterns
- Use `yarn analyze` for specific recommendations

### Tool Usage

- Run `yarn check:files --help` for file size tool options
- Run `yarn check:complexity --help` for complexity analysis options
- Generate HTML reports with `yarn analyze:html` for visual insights
