// eslint-disable-next-line @typescript-eslint/no-require-imports
const nextJest = require('next/jest');

const createJestConfig = nextJest({
  // Provide the path to your Next.js app to load next.config.js and .env files
  dir: './',
});

// Add any custom config to be passed to Jest
const customJestConfig = {
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  testEnvironment: 'jest-environment-jsdom',
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  transformIgnorePatterns: [
    'node_modules/(?!(nanoid|qrcode|jsqr|sonner|jose|@privy-io|ofetch)/)',
  ],
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/*.stories.{js,jsx,ts,tsx}',
    '!src/app/layout.tsx',
    '!src/app/globals.css',
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
  testMatch: [
    '<rootDir>/src/**/__tests__/**/*.{test,spec}.{js,jsx,ts,tsx}',
    '<rootDir>/src/**/*.{test,spec}.{js,jsx,ts,tsx}',
    '<rootDir>/tests/**/*.{test,spec}.{js,jsx,ts,tsx}',
  ],
  testPathIgnorePatterns: [
    '<rootDir>/node_modules/',
    '<rootDir>/.next/',
    // Ignore test helper/setup files that aren't actual tests
    'test-setup\\.ts$',
    'test-infrastructure\\.ts$',
    'mock-.*\\.ts$',
    // Skip tests that need rewriting to use Supabase repositories
    // These tests were originally Firebase-dependent and are pending migration
    'dao-creation\\.test\\.ts$',
    'dao-membership\\.test\\.ts$',
    'dao-queries\\.test\\.ts$',
    'data-integrity\\.service\\.test\\.ts$',
    'database\\.service\\.test\\.ts$',
    'proposal-execution\\.service\\.test\\.ts$',
    'user-profile-privy\\.test\\.ts$',
    'treasury-admin\\.service\\.test\\.ts$',
    'treasury-execution-lock\\.test\\.ts$',
    'treasury-execution-orchestrator\\.test\\.ts$',
    'ledger-recording\\.service\\.test\\.ts$',
    'invitation-system\\.test\\.ts$',
    'privy\\.service\\.test\\.ts$',
    'rate-limiter\\.test\\.ts$',
    'csrf\\.test\\.ts$',
    // QR tests - FIXED (Dec 2025) - all 6 test suites passing (125 tests, 13 skipped for ESM issues)
  ],
  modulePathIgnorePatterns: ['<rootDir>/node_modules/', '<rootDir>/.next/'],
};

// createJestConfig is exported this way to ensure that next/jest can load the Next.js config which is async
module.exports = createJestConfig(customJestConfig);
