// This file configures the initialization of Sentry on the server.
// The config you add here will be used whenever the server handles a request.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/

import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: 'https://b3497bb96692ae8d70e8627bfe79b42d@o4510563340255232.ingest.us.sentry.io/4510563341565952',

  // Define how likely traces are sampled. Adjust this value in production, or use tracesSampler for greater control.
  tracesSampleRate: 1,

  // Enable logs to be sent to Sentry
  enableLogs: true,

  // Enable sending user PII (Personally Identifiable Information)
  // https://docs.sentry.io/platforms/javascript/guides/nextjs/configuration/options/#sendDefaultPii
  sendDefaultPii: true,

  // Ignore known non-actionable errors
  // See: https://github.com/vercel/next.js/discussions/75995
  ignoreErrors: [
    // Next.js streaming bug with Node.js 22+ - no official fix available
    'controller[kState].transformAlgorithm is not a function',
    // HTTP connection aborted during streaming response - normal infrastructure behavior
    /^Error: aborted$/,
    // Client closed connection before response completed
    'write EPIPE',
    'read ECONNRESET',
  ],

  // Filter out noisy events before sending
  beforeSend(event, hint) {
    const error = hint.originalException;

    // Filter infrastructure-level errors that aren't actionable
    if (error instanceof Error) {
      // Next.js streaming/transformer errors (known unresolved issue)
      if (error.message?.includes('transformAlgorithm')) {
        return null;
      }
      // HTTP connection aborted (user navigated away, network issues)
      if (error.message === 'aborted') {
        return null;
      }
    }

    return event;
  },
});
