# Mobile Discussions API

Mobile API routes for discussions, following the existing mobile API patterns.

## Created Routes

### 1. List DAO Discussions

**Endpoint**: `GET /api/mobile/v1/daos/[daoId]/discussions`

**Description**: Fetch all discussions for a specific DAO

**Query Parameters**:
- `status` (optional): Filter by status (`active`, `archived`, `converted`)

**Response Format**:
```typescript
{
  success: true,
  data: [{
    id: string,
    title: string,
    content: string,
    authorId: string,
    authorName: string | null,
    commentCount: number,
    isPinned: boolean,
    status: 'active' | 'archived' | 'converted',
    createdAt: string,
    lastActivityAt: string | null,
  }]
}
```

**Example**:
```bash
GET /api/mobile/v1/daos/123e4567-e89b-12d3-a456-426614174000/discussions?status=active
```

---

### 2. Get Discussion with Comments

**Endpoint**: `GET /api/mobile/v1/discussions/[discussionId]`

**Description**: Fetch a single discussion with all its comments (top-level only)

**Response Format**:
```typescript
{
  success: true,
  data: {
    discussion: {
      id: string,
      title: string,
      content: string,
      authorId: string,
      authorName: string | null,
      commentCount: number,
      isPinned: boolean,
      status: 'active' | 'archived' | 'converted',
      createdAt: string,
      lastActivityAt: string | null,
    },
    comments: [{
      id: string,
      content: string,
      authorId: string,
      authorName: string | null,
      parentId: string | null,
      createdAt: string,
      isEdited: boolean,
    }]
  }
}
```

**Example**:
```bash
GET /api/mobile/v1/discussions/123e4567-e89b-12d3-a456-426614174000
```

---

### 3. List/Create Comments

**Endpoint**: `GET /api/mobile/v1/discussions/[discussionId]/comments`

**Description**: Fetch comments for a discussion

**Query Parameters**:
- `sortBy` (optional): Sort order (`newest` or `oldest`, default: `oldest`)

**Response Format**:
```typescript
{
  success: true,
  data: [{
    id: string,
    content: string,
    authorId: string,
    authorName: string | null,
    parentId: string | null,
    createdAt: string,
    isEdited: boolean,
  }]
}
```

**Example**:
```bash
GET /api/mobile/v1/discussions/123e4567-e89b-12d3-a456-426614174000/comments?sortBy=newest
```

---

**Endpoint**: `POST /api/mobile/v1/discussions/[discussionId]/comments`

**Description**: Create a new comment on a discussion

**Request Body**:
```typescript
{
  content: string,      // Required, max 10000 chars
  parentId?: string,    // Optional, UUID of parent comment for replies
}
```

**Response Format** (201 Created):
```typescript
{
  success: true,
  data: {
    id: string,
    content: string,
    authorId: string,
    authorName: string | null,
    parentId: string | null,
    createdAt: string,
    isEdited: boolean,
  }
}
```

**Validation Rules**:
- Discussion must exist and be active (not archived or converted)
- Content is required and must be 1-10000 characters
- Parent comment (if specified) must exist and belong to the same discussion
- User must be authenticated

**Example**:
```bash
POST /api/mobile/v1/discussions/123e4567-e89b-12d3-a456-426614174000/comments
Content-Type: application/json

{
  "content": "Great idea! I'd like to contribute to this.",
  "parentId": null
}
```

---

## Common Error Responses

All endpoints return consistent error format:

```typescript
{
  success: false,
  error: string,
  details?: any  // Only for validation errors
}
```

**HTTP Status Codes**:
- `401` - Authentication required
- `400` - Bad request (missing parameters, validation error)
- `404` - Resource not found
- `500` - Internal server error

---

## Implementation Details

### Authentication
All routes use `getAuthContext()` to verify authentication and get user context.

### Repositories Used
- `discussionAdminRepository` - Discussion CRUD operations (server-side)
- `discussionCommentAdminRepository` - Comment CRUD operations (server-side)
- `userAdminRepository` - User lookup for enriching author info

### User Info Enrichment
- All discussion and comment responses include `authorName` field
- Author names are fetched from the users table using `userAdminRepository`
- Batch fetching is used for performance (no N+1 queries)
- Fallback to `null` if user lookup fails

### Comment Creation Side Effects
When a comment is created:
1. Comment is saved to `discussion_comments` table
2. Discussion `comment_count` is incremented
3. Discussion `last_activity_at` is updated

---

## Files Created

1. `/src/app/api/mobile/v1/daos/[daoId]/discussions/route.ts`
2. `/src/app/api/mobile/v1/discussions/[discussionId]/route.ts`
3. `/src/app/api/mobile/v1/discussions/[discussionId]/comments/route.ts`

All routes follow the existing mobile API patterns and use server-side admin repositories to bypass RLS.
