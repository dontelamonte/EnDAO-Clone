# API Reference

## Purpose

This document provides comprehensive API documentation for the EnDAO platform, including endpoints, authentication, rate limiting, and usage examples for integrating with the EnDAO governance system.

## Last Updated

September 2025

## Owner/Maintainer

Development Team

## Overview

EnDAO API endpoints for DAO management, authentication, and treasury operations, built on a modular service architecture with specialized service classes for different business domains.

## Base URL

- Development: `http://localhost:3000/api`
- Production: `https://endao.ai/api`

## Authentication

All protected endpoints require Bearer token from Privy authentication.

```
Authorization: Bearer <privy-access-token>
```

## Endpoints

### Health Check

**GET** `/health`

- Returns: `OK` (200)
- No authentication required

### DAO Management

#### Create DAO

**POST** `/daos/create`

```json
{
  "name": "string",
  "description": "string",
  "category": "community | commerce",
  "visibility": "public | private"
}
```

#### Get DAO

**GET** `/daos/[daoId]`

- Returns: DAO object with members and proposals

#### Update DAO

**PATCH** `/daos/[daoId]`

- Body: Partial DAO object
- Requires: Admin role

### Member Management

#### Join DAO

**POST** `/daos/[daoId]/join`

- Creates membership request

#### Remove Member

**DELETE** `/daos/[daoId]/members/[userId]`

- Requires: Admin role

### Treasury

#### Create Safe

**POST** `/treasury/v2/create-safe`

```json
{
  "daoId": "string",
  "adminWallets": ["0x..."] // Optional
}
```

- Returns: Safe address and configuration
- Creates L2-optimized Safe on Base network

### Proposals

#### Create Proposal

**POST** `/proposals/create`

```json
{
  "daoId": "string",
  "title": "string",
  "description": "string",
  "type": "general | treasury | member",
  "votingPeriodDays": 7
}
```

#### Vote on Proposal

**POST** `/proposals/[proposalId]/vote`

```json
{
  "vote": "for | against | abstain"
}
```

## Error Responses

```json
{
  "error": "Error message",
  "details": {} // Optional
}
```

## Service Architecture

The API is built on a modular service layer with specialized services:

### Core Services

- **DAO Services**: 5 modules (CRUD, membership, query, statistics, validation)
- **User Services**: 4 modules (activity, preferences, profile CRUD, validation)
- **Proposal Services**: 4 modules (CRUD, query, validation, voting)
- **Audit Services**: 4 modules (analytics, compliance, core, query)
- **Admin Services**: 4 modules (access control, activity logging, initialization, user management)
- **Treasury Services**: 6 services for Safe operations and treasury management

### Import Patterns

```typescript
// Service imports follow modular structure
import { DAOCRUDService } from '@/lib/services/dao/dao-crud.service';
import { ProposalVotingService } from '@/lib/services/proposal/proposal-voting.service';
import { UserActivityService } from '@/lib/services/user/user-activity.service';
```

## Rate Limiting

- 100 requests per minute per IP
- 1000 requests per hour per authenticated user
