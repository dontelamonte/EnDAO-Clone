# Materialized Views Refresh System

## Overview

The EnDAO platform uses materialized views to provide high-performance analytics without impacting real-time operations. This document describes the automated refresh system for keeping these views up-to-date.

## Materialized Views

Located in `supabase/migrations/011_materialized_views.sql`, the following materialized views are maintained:

### 1. DAO Activity Summary (`dao_activity_summary`)

- **Purpose**: 30-day rolling window of DAO activity metrics
- **Refresh Schedule**: Every hour at :00 (via cron)
- **Used By**: Discovery page, DAO dashboards, admin analytics
- **Key Metrics**: Proposals created, members joined, votes cast, unique active users

### 2. User Activity Summary (`user_activity_summary`)

- **Purpose**: User engagement and contribution metrics
- **Refresh Schedule**: Every hour at :30 (via cron)
- **Used By**: User profiles, leaderboards, reputation systems
- **Key Metrics**: Active DAO count, proposals created, votes cast, recent activity

### 3. Proposal Analytics (`proposal_analytics`)

- **Purpose**: Governance insights and proposal statistics by DAO
- **Refresh Schedule**: Daily at 3:00 AM UTC (via cron)
- **Used By**: DAO analytics, governance insights
- **Key Metrics**: Pass rate, proposal types, average participation, timeline metrics

## Refresh API Endpoint

**Endpoint**: `POST /api/admin/refresh-analytics`

### Authentication

The endpoint supports two authentication methods:

1. **Admin Email** (for manual refreshes)
   - Uses `x-auth-email` header
   - Email must be in `ADMIN_EMAILS` environment variable
   - Includes constant-time validation to prevent enumeration

2. **Cron Secret** (for automated refreshes)
   - Uses `Authorization: Bearer {CRON_SECRET}` header
   - Configured in Vercel environment variables
   - Used by Vercel Cron jobs

### Parameters

**Query Parameters**:

- `view` (optional): Specifies which view(s) to refresh
  - `all` (default): Refresh all materialized views
  - `dao_activity`: Refresh only DAO activity summary
  - `user_activity`: Refresh only user activity summary
  - `proposal_analytics`: Refresh only proposal analytics

### Examples

**Manual refresh (all views)**:

```bash
curl -X POST https://endao.ai/api/admin/refresh-analytics \
  -H "x-auth-email: admin@example.com"
```

**Manual refresh (specific view)**:

```bash
curl -X POST https://endao.ai/api/admin/refresh-analytics?view=dao_activity \
  -H "x-auth-email: admin@example.com"
```

**Cron job refresh**:

```bash
curl -X POST https://endao.ai/api/admin/refresh-analytics?view=dao_activity \
  -H "Authorization: Bearer ${CRON_SECRET}"
```

**Health check**:

```bash
curl https://endao.ai/api/admin/refresh-analytics
```

### Response Format

**Success**:

```json
{
  "success": true,
  "data": {
    "view": "dao_activity",
    "refreshedAt": "2024-12-10T19:30:00.000Z",
    "duration": 1234
  }
}
```

**Error**:

```json
{
  "success": false,
  "error": "Admin access required",
  "code": "FORBIDDEN"
}
```

## Automated Scheduling

Configured in `vercel.json`:

```json
{
  "crons": [
    {
      "path": "/api/admin/refresh-analytics?view=dao_activity",
      "schedule": "0 * * * *"
    },
    {
      "path": "/api/admin/refresh-analytics?view=user_activity",
      "schedule": "30 * * * *"
    },
    {
      "path": "/api/admin/refresh-analytics?view=proposal_analytics",
      "schedule": "0 3 * * *"
    }
  ]
}
```

### Schedule Explanation

- **DAO Activity** (`0 * * * *`): Every hour at :00 minutes
  - High-frequency metrics for discovery and dashboards
  - Captures recent activity within 1 hour

- **User Activity** (`30 * * * *`): Every hour at :30 minutes
  - Staggered to distribute load
  - User metrics less time-sensitive than DAO activity

- **Proposal Analytics** (`0 3 * * *`): Daily at 3:00 AM UTC
  - Less volatile metrics, daily refresh sufficient
  - Runs during low-traffic period

## Database Functions

The following PostgreSQL functions are created by the migration:

### Individual Refresh Functions

```sql
-- Refresh single view
SELECT refresh_dao_activity_summary();
SELECT refresh_user_activity_summary();
SELECT refresh_proposal_analytics();
```

### Bulk Refresh Function

```sql
-- Refresh all views at once
SELECT refresh_all_analytics();
```

All refresh operations use `REFRESH MATERIALIZED VIEW CONCURRENTLY` to avoid locking the views during refresh.

## Performance Considerations

### Concurrent Refresh Requirements

- Each materialized view requires a **unique index** for concurrent refresh
- Indexes created: `idx_dao_activity_summary_pk`, `idx_user_activity_summary_pk`, `idx_proposal_analytics_pk`
- Concurrent refresh allows queries to continue during the refresh operation

### Refresh Duration

Typical refresh times (approximate):

- **DAO Activity**: 2-5 seconds for 100 DAOs
- **User Activity**: 3-7 seconds for 1000 users
- **Proposal Analytics**: 1-3 seconds for 500 proposals

### Load Distribution

- Hourly refreshes staggered by 30 minutes to distribute database load
- Daily refresh scheduled during low-traffic period (3 AM UTC)
- Each refresh is independent and can fail without affecting others

## Monitoring

### Logging

All refresh operations are logged with:

- View being refreshed
- Authentication method (admin or cron)
- Duration of refresh operation
- Any errors encountered

**Example Log**:

```
[API] Refreshing materialized views
  view: "dao_activity"
  authMethod: "cron"
  duration: 2341ms
```

### Error Handling

- Failed refreshes return detailed error messages
- Errors logged to application logs for investigation
- Cron failures reported in Vercel deployment logs

### Health Monitoring

Use the GET endpoint to verify availability:

```bash
curl https://endao.ai/api/admin/refresh-analytics
```

## Feature Flag Integration

The materialized views are controlled by the `useMaterializedViews` feature flag:

**Flag**: `useMaterializedViews`
**Default**: `false` (Phase 5 feature)

When enabled:

- Application queries use materialized views instead of computed aggregations
- Fallback to computed queries if views are stale or unavailable
- Try materialized view → try regular view → fallback to computed

**Service Layer Integration**:

```typescript
import { featureFlagService } from '@/lib/features/feature-flag.service';

const useMaterializedViews = featureFlagService.isEnabled(
  'useMaterializedViews'
);

if (useMaterializedViews) {
  // Query materialized view
  const { data } = await supabase
    .from('dao_activity_summary')
    .select('*')
    .eq('dao_id', daoId);
} else {
  // Fallback to computed query
  // ... existing aggregation logic
}
```

## Environment Variables

Required environment variables:

**Development**:

```bash
ADMIN_EMAILS=admin1@example.com,admin2@example.com
CRON_SECRET=your-secure-random-secret
```

**Production** (Vercel):

1. Navigate to Project Settings → Environment Variables
2. Add `ADMIN_EMAILS` with comma-separated admin emails
3. Add `CRON_SECRET` with a secure random value (use for all cron jobs)

## Security Considerations

### Admin Access Control

- Constant-time email comparison prevents timing attacks
- Prevents admin email enumeration through response timing
- 100ms base delay for unauthorized attempts

### Cron Authentication

- Shared secret (`CRON_SECRET`) required for all automated refreshes
- Same secret used across all cron jobs for consistency
- Rotate secret if compromised

### Rate Limiting

- Manual refreshes subject to API rate limits
- Cron jobs bypass rate limiting (authenticated)
- Multiple concurrent refreshes prevented by PostgreSQL locks

## Troubleshooting

### View Not Refreshing

1. Check Vercel cron job logs in deployment dashboard
2. Verify `CRON_SECRET` environment variable is set
3. Check application logs for errors
4. Manually trigger refresh to test endpoint

### Stale Data

1. Check `refreshed_at` column in materialized view:
   ```sql
   SELECT refreshed_at FROM dao_activity_summary LIMIT 1;
   ```
2. Manually trigger refresh if needed
3. Verify cron schedule is correct in `vercel.json`

### Performance Issues

1. Check refresh duration in logs
2. Monitor database CPU and memory during refresh
3. Consider adjusting refresh frequency if database is overloaded
4. Verify indexes are present on materialized views

### Migration Issues

1. Ensure migration 011 has been applied:
   ```bash
   supabase db remote list
   ```
2. Verify RPC functions exist:
   ```sql
   SELECT routine_name FROM information_schema.routines
   WHERE routine_schema = 'public'
   AND routine_name LIKE 'refresh_%';
   ```
3. Check materialized views exist:
   ```sql
   SELECT matviewname FROM pg_matviews;
   ```

## Manual Operations

### Force Immediate Refresh

```bash
# All views
curl -X POST https://endao.ai/api/admin/refresh-analytics \
  -H "x-auth-email: your-admin@email.com"

# Specific view
curl -X POST "https://endao.ai/api/admin/refresh-analytics?view=dao_activity" \
  -H "x-auth-email: your-admin@email.com"
```

### Database Console

```sql
-- Check view freshness
SELECT
  'dao_activity_summary' as view_name,
  refreshed_at,
  NOW() - refreshed_at as age
FROM dao_activity_summary
LIMIT 1;

-- Manual refresh (requires superuser or SECURITY DEFINER function)
REFRESH MATERIALIZED VIEW CONCURRENTLY dao_activity_summary;
REFRESH MATERIALIZED VIEW CONCURRENTLY user_activity_summary;
REFRESH MATERIALIZED VIEW CONCURRENTLY proposal_analytics;
```

## Future Enhancements

### Planned Improvements

1. **Incremental Refresh**: Only refresh changed data instead of full rebuild
2. **Smart Scheduling**: Adjust refresh frequency based on activity levels
3. **Monitoring Dashboard**: Real-time view of refresh status and performance
4. **Alerting**: Notify admins if refreshes fail or take too long
5. **pg_cron Migration**: Move to pg_cron for database-native scheduling (if supported by Supabase)

### Phase 6+ Considerations

- Additional materialized views for trending DAOs, user rankings
- Partition materialized views by time period for faster refreshes
- Implement change data capture (CDC) for real-time view updates
- Add view-specific refresh strategies (full vs incremental)

## References

- Migration: `supabase/migrations/011_materialized_views.sql`
- API Route: `src/app/api/admin/refresh-analytics/route.ts`
- Vercel Config: `vercel.json`
- Feature Flag: `src/lib/features/feature-flag.service.ts`
- Documentation: `docs/database/materialized-views-refresh.md`
