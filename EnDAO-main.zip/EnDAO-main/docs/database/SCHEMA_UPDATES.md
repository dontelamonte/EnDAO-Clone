# Database Schema Updates - Ecosystem Growth Plan

**Status**: Planned Updates for Phased Implementation
**Last Updated**: December 17, 2025
**Database**: Supabase (PostgreSQL)

---

## Overview

This document outlines database schema updates required for the EnDAO ecosystem growth plan. Changes support:

- **DAO Type Differentiation**: Commerce vs Community DAOs
- **Treasury Tier System**: 4-tier treasury maturity model
- **Operations Wallet**: Tier 3+ daily operations infrastructure
- **Social Recovery**: Guardian-based account recovery
- **Sub-DAO Hierarchy**: Parent-child DAO relationships
- **DAO-to-DAO Connections**: Partner/vendor/customer relationships
- **Token-Weighted Voting**: EDG/TEQ voting power
- **Consent Governance**: Community DAO governance model
- **Labor Marketplace**: Job marketplace with escrow

---

## 1. Updated Tables

### 1.1 DAOs Table (`daos`)

**New/Updated Fields**:

```typescript
interface DAODocument {
  // ... existing fields (id, name, description, slug, avatar, banner)

  // Classification (NEW)
  daoType: 'commerce' | 'community';
  treasuryTier: 1 | 2 | 3 | 4;
  treasuryMode: 'disabled' | 'tracking' | 'safe';

  // Treasury (UPDATED)
  treasury?: {
    safeAddress?: string;
    chainId: number;
    requiredSignatures: number;
    owners: string[];
  };

  // Ops Wallet (NEW - Tier 3+)
  opsWallet?: {
    address: string;
    maxDailySpend: number;
    maxSingleTransaction: number;
    requiresApprovalAbove: number;
    treasurerUserIds: string[];
    refillThreshold: number;
  };

  // Governance (UPDATED)
  settings: {
    votingPeriodDays: number;
    quorumPercentage: number;
    passThreshold: number;
    governanceStyle: 'proposal' | 'consent'; // NEW
    consentSettings?: {
      // NEW
      passAfterDays: number;
      objectionThreshold: number;
    };
  };

  // Sub-DAO Hierarchy (NEW)
  parentDaoId?: string;
  childDaoIds?: string[];
  hierarchyLevel: number;

  // DAO-to-DAO Relationships (NEW)
  linkedDaos?: Array<{
    daoId: string;
    relationship: 'partner' | 'vendor' | 'customer' | 'subsidiary';
    since: Timestamp;
    status: 'pending' | 'active' | 'terminated';
  }>;

  // Recovery Configuration (NEW)
  recoveryConfig?: {
    guardians: Array<{
      userId: string;
      email: string;
      recoveryWeight: number;
      addedAt: Timestamp;
    }>;
    recoveryThreshold: number;
    timelockDuration: number;
  };

  // Integrations (NEW)
  integrations?: {
    quickbooks?: {
      realmId: string;
      syncEnabled: boolean;
      lastSyncAt?: Timestamp;
    };
  };

  // Metadata (existing)
  status: 'active' | 'archived' | 'pending_deletion' | 'deleted';
  createdAt: Timestamp;
  updatedAt: Timestamp;
  createdBy: string;
  memberCount: number;
  proposalCount: number;
}
```

**Migration Notes**:

- All existing DAOs default to `daoType: 'commerce'`, `treasuryTier: 2`
- `governanceStyle` defaults to `'proposal'` for existing DAOs
- `hierarchyLevel: 0` for existing DAOs (root level)

---

### 1.2 DAO Members Table (`dao_members`)

**New/Updated Fields**:

```typescript
interface DAOMemberDocument {
  // ... existing fields (id, daoId, userId, role, isActive, displayName, avatar, bio)

  // Permissions (NEW)
  permissions?: {
    canPropose: boolean;
    canVote: boolean;
    isTreasurer: boolean;
    isGuardian: boolean;
  };

  // Token Stats (NEW - cached for performance)
  tokenStats?: {
    teqBalance: string; // BigInt as string
    tcrEarned: string; // BigInt as string
    hoursContributed: number;
    lastUpdated: Timestamp;
  };

  // Metadata (existing)
  joinedAt: Timestamp;
  invitedBy?: string;
  status: 'pending' | 'active' | 'suspended' | 'removed';
}
```

**Migration Notes**:

- Default permissions: `canPropose: true`, `canVote: true`, `isTreasurer: false`, `isGuardian: false`
- `tokenStats` initially null, populated on first labor contribution or token transfer

---

### 1.3 Proposals Table (`proposals`)

**New/Updated Fields**:

```typescript
interface ProposalDocument {
  // ... existing fields (id, daoId, creatorId, title, description, type)

  // Voting Config (UPDATED - now stored per proposal)
  votingConfig: {
    system: 'simple' | 'token_weighted' | 'quadratic'; // NEW
    quorumPercentage: number;
    passThreshold: number;
    votingPeriodDays: number;
  };

  // Token-Weighted Results (NEW)
  tokenWeightedResults?: {
    for: string; // BigInt as string
    against: string; // BigInt as string
    abstain: string; // BigInt as string
    totalPower: string; // BigInt as string
  };

  // Consent Governance (NEW - for Community DAOs)
  consentData?: {
    currentObjections: number;
    objectors: string[];
    passAfterDays: number;
    objectionThreshold: number;
  };

  // Results (UPDATED - simple voting results remain)
  results?: {
    for: number;
    against: number;
    abstain: number;
    uniqueVoters: number;
    quorumReached: boolean;
    passed: boolean;
  };

  // ... existing fields (status, timing, metadata)
}
```

**Migration Notes**:

- Existing proposals default to `votingConfig.system: 'simple'`
- `votingConfig` inherits DAO settings at proposal creation time
- `tokenWeightedResults` populated only if `system: 'token_weighted'`
- `consentData` populated only if DAO `governanceStyle: 'consent'`

---

### 1.4 Votes Table (`votes`)

**New/Updated Fields**:

```typescript
interface VoteDocument {
  // ... existing fields (id, proposalId, daoId, voterId, choice)

  // Token-Weighted Voting (NEW)
  votingPower?: string; // BigInt as string
  tokenType?: 'edg' | 'teq' | 'equal';

  // Delegation (NEW)
  delegatedFrom?: string; // If voting on behalf of another user

  // Metadata (existing)
  createdAt: Timestamp;
  txHash?: string; // If on-chain vote
}
```

**Migration Notes**:

- Existing votes have `votingPower: null` (simple voting)
- `tokenType: 'equal'` means 1-person-1-vote (backward compatible)

---

## 2. New Tables

### 2.1 Recovery Requests Table (`recovery_requests`)

**Purpose**: Track social recovery requests for lost DAO owner keys.

```typescript
interface RecoveryRequestDocument {
  id: string;
  daoId: string;

  // Request Details
  initiatedBy: string;
  newOwnerAddress: string;

  // Guardian Approvals
  guardianApprovals: Array<{
    guardianId: string;
    approvedAt: Timestamp;
  }>;
  totalWeight: number;
  requiredWeight: number;

  // Timing
  initiatedAt: Timestamp;
  executesAt: Timestamp; // After timelock (e.g., 7 days)
  executedAt?: Timestamp;
  cancelledAt?: Timestamp;

  // Status
  status: 'pending' | 'approved' | 'executed' | 'cancelled' | 'expired';
  cancelReason?: string;
  cancelledBy?: string;
}
```

**Row Level Security (RLS) Policies**:

- Read: DAO admins + guardians only
- Write: Server-side only (API routes via service role)
- Immutable audit trail once initiated

**Indexes Required**: See Section 3

---

### 2.2 Marketplace Jobs Table (`marketplace_jobs`)

**Purpose**: Track labor marketplace jobs with escrow and TEQ minting.

```typescript
interface MarketplaceJobDocument {
  id: string;
  daoId?: string; // Optional - can be cross-DAO marketplace

  // Parties
  clientId: string;
  clientAddress: string;
  providerId?: string;
  providerAddress?: string;

  // Job Details
  title: string;
  description: string;
  jobTypeId: number; // Links to LaborOracle job types
  estimatedHours: number;
  actualHours?: number;

  // Payment
  amount: string; // TCR amount (BigInt as string)
  escrowAddress: string;
  paymentStatus: 'escrowed' | 'released' | 'refunded';

  // Status
  status: 'open' | 'in_progress' | 'completed' | 'disputed' | 'cancelled';

  // Equity Minting
  teqMinted?: string; // BigInt as string
  laborRate?: number; // USD/hour rate from LaborOracle

  // Metadata
  createdAt: Timestamp;
  acceptedAt?: Timestamp;
  completedAt?: Timestamp;
  txHash?: string;
  disputeReason?: string;
}
```

**Row Level Security (RLS) Policies**:

- Read: Public (for marketplace discovery)
- Write: Client (create), Provider (accept/complete), Server (escrow operations via service role)

**Indexes Required**: See Section 3

---

### 2.3 Users Table Updates (`users`)

**New/Updated Fields**:

```typescript
interface UserDocument {
  // ... existing fields (uid, privyId, email, username, profile, walletAddresses)

  // Cached Token Balances (NEW)
  tokenBalances?: {
    edg: string; // BigInt as string
    teq: string; // BigInt as string
    tcr: string; // BigInt as string
    lastUpdated: Timestamp;
  };

  // Labor Stats (NEW)
  laborStats?: {
    totalHoursWorked: number;
    totalTCREarned: string; // BigInt as string
    totalTEQEarned: string; // BigInt as string
    averageHourlyRate: number;
    jobTypes: Record<number, number>; // jobTypeId -> hours worked
  };

  // KYC (NEW - for fiat bridge)
  kycStatus?: 'none' | 'pending' | 'verified' | 'rejected';
  kycVerifiedAt?: Timestamp;

  // ... existing fields (preferences, metadata)
}
```

**Migration Notes**:

- `tokenBalances` initially null, populated on first token transfer
- `laborStats` initially null, populated on first job completion
- `kycStatus` defaults to `'none'`

---

## 3. PostgreSQL Indexes

**Critical Indexes for New Features**:

```sql
-- Proposals table indexes
CREATE INDEX idx_proposals_dao_status_created ON proposals (dao_id, status, created_at DESC);

-- DAO members table indexes
CREATE INDEX idx_dao_members_dao_active_role ON dao_members (dao_id, is_active, role);

-- Treasury ledger table indexes
CREATE INDEX idx_treasury_ledger_dao_created ON treasury_ledger (dao_id, created_at DESC);
CREATE INDEX idx_treasury_ledger_dao_type_created ON treasury_ledger (dao_id, type, created_at DESC);

-- Votes table indexes
CREATE INDEX idx_votes_proposal_voter ON votes (proposal_id, voter_id);

-- Marketplace jobs table indexes
CREATE INDEX idx_marketplace_jobs_status_created ON marketplace_jobs (status, created_at DESC);
CREATE INDEX idx_marketplace_jobs_provider_status ON marketplace_jobs (provider_id, status);

-- Recovery requests table indexes
CREATE INDEX idx_recovery_requests_dao_status ON recovery_requests (dao_id, status);
```

**Deployment Instructions**:

```bash
# Create a new Supabase migration
npx supabase migration new add_ecosystem_indexes

# Edit the migration file in supabase/migrations/
# Add the index creation statements above

# Apply migration to local database
npx supabase db push

# Apply migration to production
npx supabase db push --linked
```

---

## 4. Migration Strategy

### 4.1 Backward Compatibility

**Critical Principles**:

- All new fields are optional (nullable)
- Existing code continues to work without schema updates
- Gradual rollout via feature flags

**Migration Order**:

1. Deploy schema changes (optional fields only)
2. Deploy API routes with backward compatibility
3. Deploy UI features with feature flags
4. Backfill data for existing DAOs (via migration script)
5. Enable feature flags per DAO or globally

### 4.2 Data Backfill Scripts

**Location**: `scripts/migrations/`

**Required Scripts**:

- `backfill-dao-type.ts` - Set `daoType` and `treasuryTier` for existing DAOs
- `backfill-governance-style.ts` - Set `governanceStyle: 'proposal'` for existing DAOs
- `backfill-voting-config.ts` - Migrate voting settings to proposal-level `votingConfig`
- `backfill-member-permissions.ts` - Set default permissions for existing members

**Execution**:

```bash
# Always use increased memory for backfill scripts
NODE_OPTIONS='--max-old-space-size=8192' tsx scripts/migrations/backfill-dao-type.ts
```

### 4.3 Repository Pattern Updates

**Updated Repositories**:

- `src/lib/data/repositories/supabase/dao.repository.ts` - Add DAO type filtering, tier filtering
- `src/lib/data/repositories/supabase/proposal.repository.ts` - Add voting system filtering
- `src/lib/data/repositories/supabase/member.repository.ts` - Add permission queries

**Service Layer Updates**:

- `src/lib/services/dao/dao-crud.service.ts` - Validate DAO type and tier on creation
- `src/lib/services/proposal/index.ts` - Handle voting config inheritance
- `src/lib/services/proposal/voting/voting-engine.service.ts` - Support token-weighted and consent voting

---

## 5. Security Considerations

### 5.1 Access Control Updates (RLS Policies)

**Recovery Requests**:

- Guardians can approve their own recovery request approvals
- DAO admins can cancel recovery requests during timelock
- Execution requires reaching `recoveryThreshold` weight
- RLS policies enforce DAO-scoped access

**Ops Wallet**:

- Treasurers can create transactions below approval threshold
- Transactions above threshold require admin approval
- Daily spend limits enforced server-side via Supabase Admin client (not client-side)

**Marketplace Jobs**:

- Escrow operations server-side only (via service role)
- TEQ minting triggered by LaborOracle verification
- Dispute resolution requires admin/moderator role
- RLS allows public read for marketplace discovery

### 5.2 Validation Rules

**DAO Creation**:

```typescript
// Commerce DAOs must start at Tier 2+
if (daoType === 'commerce' && treasuryTier < 2) {
  throw new Error('Commerce DAOs require Tier 2+ treasury');
}

// Community DAOs should use Consent governance
if (daoType === 'community' && governanceStyle === 'proposal') {
  console.warn('Community DAOs should consider Consent governance');
}
```

**Recovery Configuration**:

```typescript
// Recovery threshold must be > 50% of total guardian weight
const totalWeight = recoveryConfig.guardians.reduce(
  (sum, g) => sum + g.recoveryWeight,
  0
);
if (recoveryConfig.recoveryThreshold <= totalWeight / 2) {
  throw new Error('Recovery threshold must exceed 50% of guardian weight');
}
```

---

## 6. Testing Requirements

### 6.1 Unit Tests

**Required Test Coverage**:

- DAO type validation (Commerce vs Community)
- Treasury tier enforcement (spending limits, ops wallet availability)
- Voting system selection (simple vs token-weighted vs consent)
- Recovery request lifecycle (initiate → approve → execute/cancel)
- Marketplace job escrow flow (create → accept → complete → release)

**Test Files**:

```
__tests__/lib/services/dao-type-service.test.ts
__tests__/lib/services/recovery-service.test.ts
__tests__/lib/services/marketplace-service.test.ts
__tests__/lib/services/voting-token-weighted.test.ts
```

### 6.2 E2E Tests

**Critical Flows**:

- Create Commerce DAO → Treasury setup → Ops Wallet → Daily transaction
- Create Community DAO → Consent proposal → Objection → Auto-pass after timeout
- Initiate recovery → Guardian approvals → Timelock wait → Execute swap
- Create marketplace job → Accept → Complete → TEQ mint + TCR release

**Test Files**:

```
tests/e2e/dao-types.spec.ts
tests/e2e/social-recovery.spec.ts
tests/e2e/marketplace-flow.spec.ts
tests/e2e/token-weighted-voting.spec.ts
```

---

## 7. Rollout Checklist

**Pre-Deployment**:

- [ ] Schema updates deployed to Supabase (via migrations)
- [ ] Indexes created and active
- [ ] RLS policies updated and tested
- [ ] Migration scripts tested on staging environment
- [ ] Backward compatibility verified with existing DAOs

**Deployment**:

- [ ] Deploy API routes with feature flags disabled
- [ ] Run backfill scripts for existing data
- [ ] Deploy UI components with feature flags
- [ ] Enable feature flags for test DAOs
- [ ] Monitor error rates and performance

**Post-Deployment**:

- [ ] Verify new DAOs use correct defaults
- [ ] Monitor recovery request flows
- [ ] Track marketplace job completion rates
- [ ] Analyze token-weighted voting participation
- [ ] Gather user feedback on Commerce vs Community distinction

---

**Related Documentation**:

- Master Spec: `/Users/jjones/.claude/plans/polished-leaping-snail.md`
- Architecture: `docs/ARCHITECTURE.md`
- Security: `docs/SECURITY.md`
- Treasury: `docs/TREASURY_PROTECTION.md`
