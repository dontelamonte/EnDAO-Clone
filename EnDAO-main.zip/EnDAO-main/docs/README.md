# EnDAO Documentation

## Purpose

This documentation hub provides comprehensive guidance for the EnDAO platform, covering architecture, development setup, treasury systems, security, and deployment. Start here to find your way to the specific documentation you need.

## Last Updated

December 16, 2025

---

## Quick Navigation

### By Task

- **Setting up dev environment?** → [Setup Guide](deployment/SETUP.md)
- **Understanding architecture?** → [Architecture Docs](architecture/)
- **Implementing treasury features?** → [Treasury Quick Start](treasury/quick-start.md)
- **AI agent guidelines?** → [Documentation Governance](DOCUMENTATION_GOVERNANCE.md)
- **Working with API?** → [API Reference](api/API.md)

### By Role

- **Developers**: Start with [Setup](deployment/SETUP.md) → [Architecture](architecture/) → [Treasury API](treasury/api-reference.md)
- **Contributors**: Read [Contributing Guide](../CONTRIBUTING.md) → [Documentation Governance](DOCUMENTATION_GOVERNANCE.md)
- **AI Agents**: Follow [Documentation Governance](DOCUMENTATION_GOVERNANCE.md) strictly

---

## 📚 Core Documentation

### Architecture & Patterns

- [**Architecture Enforcement**](architecture/ARCHITECTURE_ENFORCEMENT.md) - How standards are enforced through automation
- [**Code Splitting Guide**](architecture/CODE_SPLITTING.md) - Performance optimization through lazy loading
- [**Token Architecture**](architecture/TOKEN_ARCHITECTURE.md) - EDG/TCR/TEQ tri-token system design

### Architecture Decision Records

- [**ADR-001: Initial Architecture**](architecture/decisions/001-initial-architecture.md) - Core architectural patterns and technology decisions
- [**ADR-002: Ethers Adapter Pattern**](architecture/decisions/002-ethers-adapter-pattern.md) - ethers.js v6 abstraction layer
- [**ADR-003: Safe Adapter Pattern**](architecture/decisions/003-safe-adapter-pattern.md) - Safe Protocol Kit v4 integration
- [**ADR-004: Privy Adapter Pattern**](architecture/decisions/004-privy-adapter-pattern.md) - Authentication and signing abstraction
- [**ADR-005: Voting Plugin Architecture**](architecture/decisions/005-voting-plugin-architecture.md) - Extensible voting system design

### Smart Contracts

- [**Contracts Overview**](contracts/README.md) - Contract deployment addresses and role matrix
- [**Labor Marketplace**](contracts/LABOR_MARKETPLACE.md) - LaborOracle and ServiceMarketplace contracts
- [**Spending Limits**](contracts/SPENDING_LIMITS.md) - Zodiac SpendingLimitsModule and OpsWallet

### Development

- [**Setup Guide**](deployment/SETUP.md) - Development environment setup and configuration
- [**API Reference**](api/API.md) - API endpoint documentation
- [**Database Guide**](database/SCHEMA_UPDATES.md) - Database schema and migration guide

### Features (Future Roadmap)

- [**Treasury Tiers**](features/TREASURY_TIERS.md) - 4-tier treasury system (Starter → Enterprise)
- [**Social Recovery**](features/SOCIAL_RECOVERY.md) - Guardian-based account recovery system

### Treasury System (Current)

- [**Treasury Quick Start**](treasury/quick-start.md) - Get started with treasury features
- [**Treasury API Reference**](treasury/api-reference.md) - Complete API documentation
- [**Treasury Integration Guide**](treasury/integration-guide.md) - Frontend integration patterns
- [**Treasury Advanced Topics**](treasury/advanced-topics.md) - Production deployment and optimization
- [**Treasury Protection System**](treasury/TREASURY_PROTECTION.md) - Security framework documentation
- [**In-App Signing Architecture**](treasury/IN_APP_SIGNING_ARCHITECTURE.md) - Signing flow design
- [**Treasury User Guide**](treasury/TREASURY_USER_GUIDE.md) - End-user treasury documentation

### Database

- [**Schema Updates**](database/SCHEMA_UPDATES.md) - Database schema and migration guide

### Platform Revenue System

- [**Platform Revenue Deployment**](deployment/PLATFORM_REVENUE_DEPLOYMENT.md) - Revenue system deployment procedures

### Security

- [**Security Guide**](security/SECURITY_GUIDE.md) - Security practices and guidelines
- [**Admin Safeguards Review**](security/admin-safeguards-security-review.md) - Admin security review
- [**Treasury Execution Locking**](security/TREASURY_EXECUTION_LOCKING.md) - Transaction locking mechanisms

### Guides

- [**DAO-to-DAO Transfers**](guides/DAO_TO_DAO_TRANSFERS.md) - Inter-DAO transfer architecture

### AI & Documentation

- [**Documentation Governance**](DOCUMENTATION_GOVERNANCE.md) - Documentation creation and maintenance rules

## 🎯 Quick Start

1. **New Developer?** Start with [Setup Guide](deployment/SETUP.md)
2. **Understanding the codebase?** Read [Architecture Docs](architecture/)
3. **Contributing code?** Review [Architecture Enforcement](architecture/ARCHITECTURE_ENFORCEMENT.md)
4. **Optimizing performance?** Check [Code Splitting Guide](architecture/CODE_SPLITTING.md)

## 📊 Architecture Standards

| Metric              | Target     | Enforcement     |
| ------------------- | ---------- | --------------- |
| File Size           | <500 lines | Pre-commit hook |
| Function Complexity | <10        | ESLint          |
| Bundle Size         | <500KB     | CI/CD check     |
| Test Coverage       | >80%       | GitHub Actions  |

## 🔧 Useful Commands

```bash
# Check architecture compliance
yarn check:architecture

# Analyze specific file
yarn analyze -- --file path/to/file.ts

# Bundle size analysis
yarn bundle-analyzer

# Run all checks
yarn check:all
```

## 📈 Current Health Metrics

- **Files >500 lines**: 7 (down from 16)
- **Average file size**: 157 lines
- **Bundle size**: ~450KB (after code splitting)
- **Test coverage**: 82%

## 🚀 Recent Improvements

### December 2025

- ✅ **Roadmap Restructured**: Split into PLATFORM_ROADMAP.md and TOKEN_ROADMAP.md
- ✅ **Monorepo Foundation**: Shared types package (`@endao/shared-types`) for web + mobile
- ✅ **Implementation Tasks Aligned**: Platform-focused priorities with "Big Four" primitives
- ✅ **Documentation Cleanup**: Removed broken links, archived stale files

### November 2025

- ✅ **Treasury Protection v2.2.0**: 4-layer security with grace period deletion
- ✅ **Platform Revenue System**: EnDAO Safe and FeeRouter deployed on Base
- ✅ **Codebase Cleanup**: Deleted 125 orphan files, reduced from 1000 to 875 files

### Previous

- ✅ **Token Architecture**: EDG/TCR/TEQ tri-token system (see TOKEN_ROADMAP.md)
- ✅ **Treasury Tiers**: 4-tier system design (Starter → Enterprise)
- ✅ Eliminated all files >800 lines
- ✅ Implemented comprehensive code splitting
- ✅ Automated architecture enforcement

---

_Last Updated: December 16, 2025_
