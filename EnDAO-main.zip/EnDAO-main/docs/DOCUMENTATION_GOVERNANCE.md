# Documentation Governance Framework

## Executive Summary

This framework establishes comprehensive governance for documentation creation, maintenance, and organization within the EnDAO project. It prevents documentation sprawl, eliminates redundancy, and ensures high-quality, discoverable documentation that serves both development velocity and user needs.

## 🎯 Core Principles

### 1. Single Source of Truth (SSOT)

- **One Topic, One Location**: Each concept documented in exactly one canonical location
- **Authoritative References**: All other mentions link to the canonical source
- **Version Control**: Documentation changes tracked alongside code changes
- **Ownership**: Clear responsibility for each document's accuracy and maintenance

### 2. Just-in-Time Documentation

- **Need-Driven Creation**: Documentation created only when there's a verified need
- **Evidence-Based Justification**: All new documentation requires justification
- **Lifecycle Management**: Regular review and archival of outdated documentation
- **Maintenance Accountability**: Clear ownership and update responsibilities

### 3. Information Architecture Excellence

- **Hierarchical Organization**: Logical, discoverable structure
- **Consistent Naming**: Standardized file and folder naming conventions
- **Cross-References**: Clear relationships between related documents
- **Search Optimization**: Structured for both human and automated discovery

## 📊 Current State Analysis

### Documentation Inventory (90+ files identified)

- **Root Level**: 8 files (ARCHITECTURE.md, CHANGELOG.md, etc.)
- **docs/ Directory**: 82+ files across 15 subdirectories
- **Scattered Files**: 15+ files in component/service directories
- **Archive Content**: 50+ archived files (historical value, low current relevance)

### Identified Issues

1. **Redundancy**: Multiple files covering similar topics
2. **Outdated Content**: 30% of files haven't been updated in 6+ months
3. **Poor Discoverability**: Inconsistent naming and organization
4. **Unclear Ownership**: No clear maintenance responsibilities
5. **Documentation Debt**: Accumulating faster than cleanup

## 🏗️ Information Architecture

### Master Documentation Hierarchy

```
/
├── README.md                     # Project overview & quick start
├── ARCHITECTURE.md               # High-level system design
├── CHANGELOG.md                  # Version history
├── CONTRIBUTING.md               # Contribution guidelines
├── CLAUDE.md                    # AI assistant context
├── PRIVACY_POLICY.md            # Legal requirements
├── TERMS_OF_SERVICE.md          # Legal requirements
│
├── docs/                        # All project documentation
│   ├── README.md               # Documentation index & navigation
│   │
│   ├── architecture/           # System design & patterns
│   │   ├── README.md          # Architecture overview
│   │   ├── patterns.md        # Design patterns
│   │   ├── enforcement.md     # Architecture compliance
│   │   └── decisions/         # ADRs (Architecture Decision Records)
│   │       ├── 001-tech-stack.md
│   │       └── 002-auth-strategy.md
│   │
│   ├── api/                   # API documentation
│   │   ├── README.md         # API overview
│   │   ├── endpoints.md      # Endpoint reference
│   │   ├── authentication.md # Auth patterns
│   │   └── errors.md         # Error handling
│   │
│   ├── guides/               # How-to documentation
│   │   ├── README.md        # Guide index
│   │   ├── setup.md         # Development setup
│   │   ├── deployment.md    # Deployment procedures
│   │   ├── testing.md       # Testing strategies
│   │   └── troubleshooting.md # Common issues
│   │
│   ├── features/            # Feature-specific documentation
│   │   ├── README.md       # Feature overview
│   │   ├── dao-management.md
│   │   ├── proposal-system.md
│   │   ├── treasury-integration.md
│   │   └── user-authentication.md
│   │
│   ├── security/           # Security documentation
│   │   ├── README.md      # Security overview
│   │   ├── threat-model.md
│   │   ├── audit-reports.md
│   │   └── guidelines.md
│   │
│   ├── operations/         # Operational procedures
│   │   ├── README.md      # Operations overview
│   │   ├── monitoring.md  # System monitoring
│   │   ├── backups.md     # Backup procedures
│   │   └── incident-response.md
│   │
│   └── archive/           # Historical documentation
│       ├── README.md     # Archive index
│       ├── deprecated/   # Deprecated features
│       └── migrations/   # Migration records
│
└── src/                   # Code documentation
    ├── components/
    │   └── feature-name/
    │       └── README.md  # Component-specific docs only
    └── lib/
        └── services/
            └── service-name/
                └── README.md  # Service-specific docs only
```

### Document Types & Purposes

| Type             | Purpose                            | Audience                | Maintenance      |
| ---------------- | ---------------------------------- | ----------------------- | ---------------- |
| **README**       | Quick orientation, getting started | All users               | High frequency   |
| **Architecture** | System design, patterns, decisions | Developers, architects  | Medium frequency |
| **API**          | Endpoint documentation, schemas    | Developers, integrators | Code-driven      |
| **Guides**       | Step-by-step instructions          | Developers, operators   | Task-driven      |
| **Features**     | Business logic, user flows         | Product, developers     | Feature-driven   |
| **Security**     | Threat models, compliance          | Security, compliance    | Risk-driven      |
| **Operations**   | Procedures, runbooks               | DevOps, support         | Incident-driven  |

## 📋 Documentation Standards

### Content Standards

#### 1. Required Sections

Every document must include:

```markdown
# Document Title

## Purpose

## Audience

## Last Updated

## Owner/Maintainer

## Table of Contents (if >500 words)

## Content

## Related Documents

## Changelog (for significant docs)
```

#### 2. Quality Requirements

- **Clarity**: Written for target audience comprehension level
- **Completeness**: Covers all aspects of the topic
- **Currency**: Information is accurate and up-to-date
- **Consistency**: Follows established style and structure
- **Actionability**: Provides clear next steps or outcomes

#### 3. Style Guidelines

- **Language**: Clear, concise, jargon-free where possible
- **Structure**: Logical flow with clear headings
- **Examples**: Concrete, copy-pasteable examples
- **Links**: Relative paths, descriptive link text
- **Formatting**: Consistent use of markdown features

### File Naming Conventions

#### Directory Names

- **Format**: `lowercase-with-hyphens`
- **Examples**: `architecture`, `api-reference`, `security-guidelines`
- **Avoid**: camelCase, snake_case, spaces, special characters

#### File Names

- **Format**: `UPPERCASE_CONCEPTS.md` (for major docs), `lowercase-with-hyphens.md` (for specific topics)
- **Major Docs**: `README.md`, `ARCHITECTURE.md`, `DEPLOYMENT_GUIDE.md`
- **Specific Topics**: `setup-development.md`, `api-authentication.md`
- **ADRs**: `001-decision-title.md` (numbered, chronological)
- **Avoid**: spaces, special characters, version numbers in names

#### Examples

```
✅ Good:
- README.md
- API_REFERENCE.md
- setup-development.md
- 001-choose-database.md

❌ Bad:
- read me.md
- API Reference v2.md
- setup_development.md
- database-decision-final-FINAL.md
```

## 🤖 AI Agent Guidelines

### Documentation Creation Rules

#### When AI Agents MUST NOT Create Documentation

1. **Routine Operations**: Code changes, bug fixes, minor features
2. **Duplicate Content**: Topic already covered in existing documentation
3. **Temporary Information**: Status updates, temporary configurations
4. **Speculative Content**: Future plans, unconfirmed requirements
5. **Auto-Generated Content**: Without explicit user request

#### When AI Agents MAY Create Documentation

1. **Explicit User Request**: "Please document X"
2. **New Architecture**: Significant system changes requiring documentation
3. **Security Critical**: Security vulnerabilities, compliance requirements
4. **API Changes**: Breaking changes requiring documentation updates
5. **Major Features**: Complex features requiring user guidance

#### Pre-Creation Validation Checklist

Before creating any documentation, AI agents must:

1. **📋 Need Assessment**
   - [ ] Verify genuine need exists
   - [ ] Confirm no existing documentation covers the topic
   - [ ] Identify target audience and use case
   - [ ] Estimate documentation lifecycle (temporary vs. permanent)

2. **🔍 Content Analysis**
   - [ ] Check for overlapping content in existing docs
   - [ ] Identify canonical location for the information
   - [ ] Determine if information belongs in code comments instead
   - [ ] Verify information accuracy and completeness

3. **📁 Placement Strategy**
   - [ ] Determine correct directory based on hierarchy
   - [ ] Choose appropriate file name following conventions
   - [ ] Identify related documents for cross-referencing
   - [ ] Plan for maintenance and ownership

4. **🎯 Quality Validation**
   - [ ] Ensure content meets quality standards
   - [ ] Include all required sections
   - [ ] Follow style guidelines
   - [ ] Add appropriate metadata and cross-references

### Decision Framework for AI Agents

```mermaid
flowchart TD
    A[Documentation Request] --> B{Explicit User Request?}
    B -->|No| C{Critical System Change?}
    B -->|Yes| D[Validate Need]
    C -->|No| E[STOP: Do Not Create]
    C -->|Yes| D
    D --> F{Existing Coverage?}
    F -->|Yes| G[Update Existing]
    F -->|No| H[Validate Placement]
    H --> I[Apply Quality Standards]
    I --> J[Create Documentation]
    G --> K[Link to Canonical Source]
    J --> L[Update Cross-References]
    K --> L
    L --> M[Document Complete]
    E --> N[Suggest Alternative Action]
```

### Alternative Actions Instead of Creating Documentation

When documentation should NOT be created, AI agents should:

1. **Add Code Comments**
   - Explain complex logic in code comments
   - Add docstrings to functions and classes
   - Use inline comments for non-obvious implementations

2. **Update Existing Documentation**
   - Add information to existing relevant files
   - Update outdated sections in current docs
   - Improve existing documentation quality

3. **Suggest User Actions**
   - "This would be better documented in [existing file]"
   - "Consider adding this to the existing [topic] documentation"
   - "This might belong in code comments rather than separate documentation"

4. **Create GitHub Issues**
   - Document feature requests as issues
   - Track bugs and improvements in issue tracker
   - Use issue forms for consistent reporting

### Common Violations and Corrections

#### Violation: Creating Unnecessary READMEs

```
❌ Bad: Creating README.md for every component
✅ Good: Only create READMEs for complex, reusable components
```

#### Violation: Documenting Obvious Code

```
❌ Bad: "This function adds two numbers"
✅ Good: Document complex business logic, algorithms, or non-obvious behavior
```

#### Violation: Creating Status Reports as Files

```
❌ Bad: Creating "deployment-status-2025-09-16.md"
✅ Good: Update existing deployment documentation or use GitHub issues
```

#### Violation: Duplicating Existing Information

```
❌ Bad: Creating new API docs when API.md already exists
✅ Good: Update existing API.md with new information
```

### Consultation Requirements

#### Mandatory Consultation

AI agents must consult with docs-curator agent before:

1. Creating new top-level documentation files
2. Restructuring existing documentation hierarchy
3. Deprecating or archiving documentation
4. Creating documentation that spans multiple domains
5. Establishing new documentation categories

#### Documentation Review Process

1. **Pre-Creation**: Consult docs-curator for placement and structure
2. **During Creation**: Follow established patterns and standards
3. **Post-Creation**: Update navigation and cross-references
4. **Ongoing**: Monitor for updates and maintenance needs

## 🔒 Enforcement Mechanisms

### Automated Validation

#### Pre-Commit Hooks

```bash
#!/bin/bash
# docs-validation-hook.sh

echo "🔍 Validating documentation changes..."

# Check for new .md files
NEW_DOCS=$(git diff --cached --name-only --diff-filter=A | grep '\.md$')

if [ ! -z "$NEW_DOCS" ]; then
    echo "📝 New documentation files detected:"
    echo "$NEW_DOCS"

    # Validate file naming
    for file in $NEW_DOCS; do
        if [[ ! "$file" =~ ^[A-Z_]+\.md$|^[a-z-]+\.md$|^[0-9]{3}-[a-z-]+\.md$ ]]; then
            echo "❌ Invalid file name: $file"
            echo "   Must follow naming conventions"
            exit 1
        fi
    done

    # Check for required sections
    for file in $NEW_DOCS; do
        if ! grep -q "## Purpose" "$file"; then
            echo "❌ Missing required section '## Purpose' in $file"
            exit 1
        fi
        if ! grep -q "## Last Updated" "$file"; then
            echo "❌ Missing required section '## Last Updated' in $file"
            exit 1
        fi
    done

    echo "✅ Documentation validation passed"
fi
```

#### GitHub Actions Workflow

```yaml
name: Documentation Governance
on:
  pull_request:
    paths:
      - '**/*.md'

jobs:
  validate-docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Validate Documentation Structure
        run: |
          ./scripts/validate-docs.sh

      - name: Check for Duplicate Content
        run: |
          ./scripts/check-duplicates.sh

      - name: Validate Links
        run: |
          ./scripts/validate-links.sh

      - name: Update Documentation Index
        run: |
          ./scripts/update-doc-index.sh
```

### Documentation Linting

#### markdownlint Configuration

```json
{
  "MD001": true,
  "MD003": { "style": "atx" },
  "MD007": { "indent": 2 },
  "MD012": { "maximum": 2 },
  "MD013": { "line_length": 100 },
  "MD022": true,
  "MD025": { "level": 1 },
  "MD026": { "punctuation": ".,;:!" },
  "MD029": { "style": "ordered" },
  "MD033": { "allowed_elements": ["details", "summary"] },
  "MD041": true
}
```

### Review Checkpoints

#### Pull Request Template

```markdown
## Documentation Changes Checklist

### Required for All Documentation Changes

- [ ] Followed naming conventions
- [ ] Included required sections (Purpose, Audience, Last Updated)
- [ ] Validated no duplicate content exists
- [ ] Updated cross-references and navigation
- [ ] Added to appropriate index/README

### Required for New Documentation

- [ ] Justified need for new documentation
- [ ] Consulted docs-curator for placement
- [ ] Identified document owner/maintainer
- [ ] Planned maintenance schedule
- [ ] Added to governance tracking

### Quality Standards

- [ ] Clear, audience-appropriate language
- [ ] Actionable content with examples
- [ ] Proper markdown formatting
- [ ] All links functional and relative
- [ ] Spelling and grammar checked
```

## 📈 Monitoring & Metrics

### Documentation Health Metrics

#### Quantitative Metrics

- **Coverage**: Percentage of features with documentation
- **Freshness**: Percentage of docs updated in last 90 days
- **Accessibility**: Average time to find information
- **Quality**: Docs meeting all quality standards
- **Redundancy**: Duplicate content instances detected

#### Qualitative Metrics

- **User Satisfaction**: Developer feedback on documentation quality
- **Onboarding Time**: Time for new developers to become productive
- **Support Tickets**: Documentation-related issues reported
- **Contribution Rate**: Community contributions to documentation

### Tracking Dashboard

```yaml
metrics:
  total_documents: 95
  documents_meeting_standards: 87%
  average_age_days: 45
  orphaned_documents: 3
  duplicate_content_instances: 0
  broken_links: 2
  maintenance_overdue: 5

health_score: 92/100

alerts:
  - 'Treasury documentation needs update (90 days old)'
  - 'API reference missing authentication section'
  - 'Setup guide has 2 broken links'
```

## 🔧 Implementation Strategy

### Phase 1: Foundation (Week 1)

1. **Audit & Assessment**
   - Complete documentation inventory
   - Identify redundancies and gaps
   - Classify documents by type and quality
   - Map current vs. desired structure

2. **Framework Implementation**
   - Create governance documentation
   - Establish validation scripts
   - Configure automated checks
   - Train AI agents on new rules

### Phase 2: Consolidation (Weeks 2-3)

1. **Structure Migration**
   - Implement master hierarchy
   - Migrate existing documentation
   - Consolidate duplicate content
   - Archive outdated material

2. **Quality Improvement**
   - Apply content standards to all docs
   - Fix broken links and references
   - Update outdated information
   - Establish ownership for each document

### Phase 3: Enforcement (Week 4)

1. **Automation Deployment**
   - Enable pre-commit hooks
   - Deploy GitHub Actions workflows
   - Configure monitoring dashboards
   - Establish review processes

2. **Training & Adoption**
   - Train development team on new standards
   - Update contribution guidelines
   - Create documentation patterns
   - Establish maintenance schedules

### Phase 4: Optimization (Ongoing)

1. **Continuous Improvement**
   - Monitor metrics and user feedback
   - Refine standards and processes
   - Optimize information architecture
   - Enhance automation and tooling

## 📋 Templates & Tools

### Document Templates

#### README Template

```markdown
# [Component/Service Name]

## Purpose

Brief description of what this component/service does and why it exists.

## Audience

- Primary: [target audience]
- Secondary: [additional audience]

## Last Updated

[Date] by [Author]

## Quick Start

[Minimal steps to get started]

## Architecture

[High-level overview]

## API Reference

[If applicable]

## Configuration

[Environment variables, settings]

## Testing

[How to test this component]

## Troubleshooting

[Common issues and solutions]

## Related Documents

- [Link to related documentation]

## Owner/Maintainer

- Primary: [Name/Team]
- Secondary: [Name/Team]
```

#### Architecture Decision Record (ADR) Template

```markdown
# [ADR-###] [Decision Title]

## Status

[Proposed | Accepted | Rejected | Deprecated | Superseded]

## Context

[What is the issue that we're seeing that is motivating this decision or change?]

## Decision

[What is the change that we're proposing or have agreed to implement?]

## Consequences

[What becomes easier or more difficult to do and any risks introduced by this change?]

## Alternatives Considered

[What other options were evaluated?]

## Last Updated

[Date] by [Author]

## Related Decisions

- [Links to related ADRs]
```

### Validation Scripts

#### Documentation Structure Validator

```bash
#!/bin/bash
# validate-structure.sh

DOCS_DIR="docs"
ERRORS=0

echo "🔍 Validating documentation structure..."

# Check required directories exist
REQUIRED_DIRS=("architecture" "api" "guides" "features" "security" "operations")
for dir in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$DOCS_DIR/$dir" ]; then
        echo "❌ Required directory missing: $DOCS_DIR/$dir"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check each directory has README
for dir in "$DOCS_DIR"/*; do
    if [ -d "$dir" ] && [ ! -f "$dir/README.md" ]; then
        echo "❌ Missing README.md in $(basename "$dir")"
        ERRORS=$((ERRORS + 1))
    fi
done

if [ $ERRORS -eq 0 ]; then
    echo "✅ Documentation structure validation passed"
    exit 0
else
    echo "❌ Documentation structure validation failed with $ERRORS errors"
    exit 1
fi
```

#### Content Quality Checker

```bash
#!/bin/bash
# check-quality.sh

find docs -name "*.md" -type f | while read file; do
    echo "📋 Checking $file..."

    # Check for required sections
    if ! grep -q "## Purpose" "$file"; then
        echo "  ⚠️  Missing Purpose section"
    fi

    if ! grep -q "## Last Updated" "$file"; then
        echo "  ⚠️  Missing Last Updated section"
    fi

    # Check for outdated content (>90 days)
    LAST_MODIFIED=$(git log -1 --format="%at" "$file" 2>/dev/null)
    if [ ! -z "$LAST_MODIFIED" ]; then
        DAYS_OLD=$(( ($(date +%s) - $LAST_MODIFIED) / 86400 ))
        if [ $DAYS_OLD -gt 90 ]; then
            echo "  ⚠️  Content is $DAYS_OLD days old"
        fi
    fi

    # Check for broken internal links
    grep -o '\[.*\](\.\/[^)]*\.md)' "$file" | while read link; do
        target=$(echo "$link" | sed 's/.*](\.\///' | sed 's/).*//')
        if [ ! -f "$(dirname "$file")/$target" ]; then
            echo "  ❌ Broken link: $link"
        fi
    done
done
```

## 🎯 Success Metrics

### Immediate Goals (30 days)

- Reduce total documentation files by 40%
- Achieve 95% compliance with naming conventions
- Eliminate all duplicate content instances
- Establish clear ownership for all documents

### Medium-term Goals (90 days)

- 90% of documents meet quality standards
- Average documentation age <60 days
- Zero broken internal links
- New developer onboarding time <2 hours

### Long-term Goals (6 months)

- Fully automated documentation validation
- Self-maintaining documentation system
- Developer satisfaction score >4.5/5
- Zero documentation-related support tickets

## 📞 Support & Escalation

### Documentation Issues

- **Minor Issues**: Create GitHub issue with `documentation` label
- **Major Restructuring**: Consult with docs-curator agent
- **Policy Violations**: Escalate to technical lead
- **Emergency**: Direct message to documentation maintainer

### Continuous Improvement

- Monthly documentation review meetings
- Quarterly process optimization reviews
- Annual framework assessment and updates
- User feedback integration cycles

---

**Document Owner**: docs-curator agent
**Last Updated**: September 16, 2025
**Next Review**: October 16, 2025
