# DAO-to-DAO Transfer Architecture

## Purpose

This document outlines the architecture and implementation details for enabling secure treasury fund transfers between different DAOs, supporting collaborations and inter-DAO operations.

## Last Updated

September 2025

## Overview

DAO-to-DAO transfers enable treasury funds to move between different DAOs, supporting collaborations, grants, and inter-DAO operations.

## Two Approaches

### Approach 1: Through Proposal System (Recommended)

**Best for**: Governance, transparency, audit trail

```typescript
// 1. Create a treasury proposal in the sending DAO
const proposal = {
  type: 'treasury',
  title: 'Grant to Atlanta Chain DAO',
  metadata: {
    treasuryRecipient: '0xATLANTA_CHAIN_SAFE_ADDRESS', // Target DAO's Safe
    treasuryAmount: '0.0001',
    treasuryCurrency: 'ETH',
    recipientType: 'dao', // New field to indicate DAO recipient
    recipientDaoId: 'atlanta-chain-dao', // For tracking
  },
};

// 2. Proposal passes through voting
// 3. Multi-sig execution as normal
// 4. Funds transfer to other DAO's Safe
```

**Pros:**

- Full governance oversight
- Community can vote on inter-DAO transfers
- Complete audit trail
- Follows existing flow

**Cons:**

- Slower (voting period required)
- More complex for small transfers

### Approach 2: Direct Safe-to-Safe (Testing/Emergency)

**Best for**: Testing, emergency transfers, pre-approved operations

```typescript
// Direct transfer between Safes
await safeService.createTransaction(
  fromSafeAddress, // Sending DAO's Safe
  toSafeAddress, // Receiving DAO's Safe
  amount,
  '0x',
  'Inter-DAO transfer'
);
// Still requires multi-sig from sending DAO
```

**Pros:**

- Faster execution
- Good for testing
- Simpler for pre-approved transfers

**Cons:**

- Bypasses governance
- Less transparency
- No voting record

## Implementation Plan

### Phase 1: Basic DAO-to-DAO (Current)

```typescript
// Works today - just use another DAO's Safe as recipient
proposal.metadata.treasuryRecipient = '0xOTHER_DAO_SAFE';
```

### Phase 2: Enhanced Tracking (Recommended)

```typescript
// Add DAO recipient awareness
interface TreasuryProposalMetadata {
  treasuryRecipient: string;
  treasuryAmount: string;
  treasuryCurrency: string;
  recipientType?: 'wallet' | 'dao' | 'contract'; // NEW
  recipientDaoId?: string; // NEW - if type is 'dao'
  recipientDaoName?: string; // NEW - for display
}
```

### Phase 3: Bilateral Agreements (Future)

```typescript
// Pre-approved transfer agreements between DAOs
interface DAOPartnership {
  fromDaoId: string;
  toDaoId: string;
  maxAmount: string;
  frequency: 'once' | 'monthly' | 'unlimited';
  requiresProposal: boolean; // Can bypass if false
  expiresAt: Date;
}
```

## Testing Strategy

### Test Case 1: Simple DAO-to-DAO via Proposal

1. Create proposal in Test DAO to send to Atlanta Chain DAO
2. Vote and pass proposal
3. Execute with 2 signatures
4. Verify funds arrive in Atlanta Chain DAO's Safe

### Test Case 2: Direct Safe Transfer (Testing Only)

1. Use direct Safe transaction creation
2. Set recipient as other DAO's Safe address
3. Collect 2 signatures
4. Execute and verify

### Test Case 3: Reciprocal Transfer

1. Test DAO → Atlanta Chain DAO (0.00001 ETH)
2. Atlanta Chain DAO → Test DAO (0.00001 ETH)
3. Verify both treasuries update correctly

## Security Considerations

1. **Recipient Validation**
   - Verify recipient is a valid Safe address
   - Check if recipient is a known DAO in the system
   - Warn if sending to unknown addresses

2. **Amount Limits**
   - Enforce daily/weekly limits for DAO-to-DAO transfers
   - Higher limits require more signatures or proposal

3. **Audit Trail**
   - Log all DAO-to-DAO transfers specially
   - Track cumulative transfers between DAO pairs
   - Generate relationship graphs

## Current Capabilities

✅ **What Works Now:**

- Any DAO can send to any address (including other DAO Safes)
- Multi-sig required from sending DAO
- Full audit logging
- Monitoring alerts for large transfers

⏳ **What Needs Addition:**

- UI indication when recipient is another DAO
- Recipient DAO validation and lookup
- Inter-DAO transfer history view
- Bilateral agreement system

## Quick Test Commands

```bash
# Test 1: Via Proposal (Full Flow)
- Create proposal with Atlanta Chain DAO's Safe as recipient
- Amount: 0.00001 ETH
- Vote, pass, execute with 2 sigs

# Test 2: Direct Test (No Proposal)
yarn test:treasury:direct -- --from=test-dao --to=atlanta-chain

# Test 3: Check Balance Changes
- Before: Test DAO (0.0007), Atlanta Chain (0.0006)
- Transfer: 0.0001 from Test → Atlanta
- After: Test DAO (0.0006), Atlanta Chain (0.0007)
```

## Recommendations

### For Testing Multi-Sig:

✅ Use **Direct Safe Testing** (Approach 2)

- Faster iteration
- No waiting for voting periods
- Tests pure multi-sig mechanics

### For DAO-to-DAO Transfers:

✅ Use **Proposal System** (Approach 1) for production
✅ Use **Direct Transfer** for testing only

### Implementation Priority:

1. Test direct Safe transfers first (no code changes needed)
2. Add recipient type detection (small enhancement)
3. Build inter-DAO dashboard (future feature)

## Summary

**You can test both scenarios TODAY:**

1. **Multi-sig only**: Create Safe transactions directly without proposals
2. **DAO-to-DAO**: Just use another DAO's Safe address as recipient

Both will require 2 signatures from the sending DAO's admins, maintaining security while enabling flexible testing.
