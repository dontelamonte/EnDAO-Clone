# TypeScript Strictness Gradual Rollout

## Purpose

This document describes the gradual rollout strategy for enabling TypeScript strictness in the EnDAO MVP project builds, allowing teams to progressively fix type errors without blocking development.

## Last Updated

October 4, 2025

## Overview

This document describes the gradual rollout strategy for enabling TypeScript strictness in the EnDAO MVP project builds.

## Current State

**Status**: Lenient Mode (Default)

- TypeScript errors do NOT block builds
- All deployments succeed regardless of type errors
- Maintains backward compatibility with existing deployments

## Implementation

### Environment Variable Control

The TypeScript strictness is controlled via the `STRICT_BUILD` environment variable:

```typescript
typescript: {
  ignoreBuildErrors: process.env.STRICT_BUILD !== 'true',
}
```

- **Default** (`STRICT_BUILD` not set): `ignoreBuildErrors: true` (lenient mode)
- **Strict** (`STRICT_BUILD=true`): `ignoreBuildErrors: false` (strict mode)

### New npm Scripts

```bash
# Check types without building (existing)
yarn type-check

# Check types with strict build mode enabled (new)
yarn type-check:strict
```

## Rollout Plan

### Phase 1: Local Testing (Week 1)

**Objective**: Identify all TypeScript errors without blocking deployments

1. Run locally to see all errors:

   ```bash
   yarn type-check:strict
   ```

2. Review error output and categorize:
   - Critical errors (blocking functionality)
   - Type annotation issues (low priority)
   - Third-party dependency issues (may need `@ts-ignore`)

3. Create GitHub issues for critical errors

### Phase 2: Incremental Fixes (Week 2-3)

**Objective**: Fix TypeScript errors incrementally without breaking changes

1. Fix critical errors first:
   - Missing null checks
   - Incorrect type annotations
   - Breaking type mismatches

2. Fix moderate errors:
   - Implicit any types
   - Unsafe type assertions
   - Missing return types

3. Address low-priority warnings:
   - Style-related type issues
   - Documentation type improvements

### Phase 3: Staging Deployment (Week 4)

**Objective**: Test strict mode in staging environment

1. Enable in Vercel staging environment:
   - Go to Vercel dashboard → staging environment
   - Add environment variable: `STRICT_BUILD=true`
   - Trigger a deployment

2. Monitor builds:
   - Ensure builds pass successfully
   - Check for any runtime issues
   - Verify all features work correctly

3. Iterate if needed:
   - If builds fail, identify new errors
   - Fix errors and retry
   - Keep staging in strict mode for testing

### Phase 4: Production Deployment (Week 5+)

**Objective**: Enable strict TypeScript checks in production

1. Enable in Vercel production environment:
   - Go to Vercel dashboard → production environment
   - Add environment variable: `STRICT_BUILD=true`
   - Deploy to production

2. Monitor production builds:
   - Ensure successful deployments
   - Monitor error tracking (Sentry)
   - Watch for any type-related runtime issues

3. Make strict mode permanent:
   - Update `next.config.ts` to default to strict mode
   - Update documentation
   - Close rollout tracking issue

## Testing the Configuration

### Local Testing

```bash
# Test lenient mode (current default)
yarn build

# Test strict mode
STRICT_BUILD=true yarn build

# Just type checking (faster)
yarn type-check:strict
```

### Vercel Environment Variables

**Staging Environment:**

1. Go to Vercel dashboard
2. Select project → Settings → Environment Variables
3. Add: `STRICT_BUILD` = `true` (Staging only)
4. Redeploy staging

**Production Environment:**

1. Same steps as staging
2. Add: `STRICT_BUILD` = `true` (Production only)
3. Redeploy production

## Rollback Plan

If issues arise after enabling strict mode:

1. **Immediate rollback**:
   - Remove `STRICT_BUILD=true` from Vercel environment
   - Redeploy affected environment
   - Builds will return to lenient mode

2. **Investigation**:
   - Review failed build logs
   - Identify problematic type errors
   - Create hotfix PR if needed

3. **Re-enable**:
   - Fix identified issues
   - Test locally with `STRICT_BUILD=true`
   - Re-enable in staging first
   - Verify before production re-enable

## Benefits

1. **Safe Rollout**: Default behavior unchanged, deployments won't break
2. **Incremental Adoption**: Can be enabled per environment
3. **Easy Rollback**: Just remove environment variable
4. **Developer Control**: Developers can test strict mode locally
5. **Production Safety**: Validate in staging before production

## Monitoring

Track progress using:

```bash
# Count TypeScript errors
yarn type-check:strict 2>&1 | grep "error TS" | wc -l

# List all error types
yarn type-check:strict 2>&1 | grep "error TS" | cut -d: -f4 | sort | uniq -c
```

## Success Criteria

- ✅ Phase 1: All TypeScript errors identified and documented
- ✅ Phase 2: Critical errors fixed (<5 remaining errors)
- ✅ Phase 3: Staging builds passing with strict mode for 1 week
- ✅ Phase 4: Production builds passing with strict mode
- ✅ Phase 5: Strict mode made default in next.config.ts

## Timeline

- **Week 1**: Local testing and error cataloging
- **Week 2-3**: Incremental fixes
- **Week 4**: Staging validation
- **Week 5+**: Production rollout

**Estimated Total Time**: 5-6 weeks

---

**Status**: ✅ Implementation Complete
**Next Step**: Begin Phase 1 (Local Testing)
**Last Updated**: 2025-10-04
