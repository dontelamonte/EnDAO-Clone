# Group Management Features Plan

**Status**: Planning | **Created**: February 2026

EnDAO feature expansion to serve as an institutional layer for formal organizations.

---

## Executive Summary

EnDAO is 88% feature-complete for core governance. This plan addresses gaps in **group management** that formal organizations need:

| Feature                 | Current State               | Target State                  | Priority |
| ----------------------- | --------------------------- | ----------------------------- | -------- |
| Decision Journal        | Implicit (in activity feed) | Dedicated searchable UI       | HIGH     |
| Meeting → Vote Pipeline | Not implemented             | Full workflow                 | HIGH     |
| Calendar Integration    | Not implemented             | Sync to Google/Outlook        | MEDIUM   |
| Task/Action Tracking    | Not implemented             | Kanban + decision linking     | MEDIUM   |
| Member Directory        | Basic list + 3 roles        | Rich profiles + permissions   | LOW      |
| Document Linking        | URLs in metadata            | Validated links with previews | LOW      |

**Principles**:

- **Don't build what exists** — Link to Google Calendar, don't build a calendar
- **Decisions are the core** — Everything connects back to governance decisions
- **No PM bloat** — Not another Monday/Asana; governance-first, execution-aware

---

## Part 1: What Already Exists

### Proposals & Voting ✅ (95% complete)

| Feature                        | Status | Location                             |
| ------------------------------ | ------ | ------------------------------------ |
| Proposal CRUD                  | ✅     | `ProposalServiceOrchestrator`        |
| 4 proposal types               | ✅     | general, funding, governance, bounty |
| Simple voting (Yes/No/Abstain) | ✅     | `VotingEngineService`                |
| Ranked choice voting           | ✅     | Up to 10 options                     |
| Quadratic voting               | ✅     | `QuadraticCreditService`             |
| Vote delegation                | ✅     | Full/percentage/proposal-specific    |
| Merkle voting (on-chain)       | ✅     | `MerkleTreeBuilderService`           |
| Discussion/comments            | ✅     | Nested threading, reactions          |
| Proposal execution             | ✅     | `ExecutionEngineService`             |

**Gap**: No weighted voting UI (type exists).

### Member Management ✅ (90% complete)

| Feature                      | Status | Location                   |
| ---------------------------- | ------ | -------------------------- |
| Member list                  | ✅     | `members-list.tsx`         |
| 3 roles (owner/admin/member) | ✅     | `dao_members.role`         |
| Add/remove/promote           | ✅     | `member-action-dialog.tsx` |
| Join requests                | ✅     | `dao_join_requests` table  |
| QR code invites              | ✅     | `/api/dao/[id]/join/qr`    |
| Member profiles (per-DAO)    | ✅     | display_name, bio, avatar  |

**Gap**: No permission visualization, no custom roles beyond 3-tier.

### Treasury ✅ (90% complete)

| Feature                 | Status | Location                            |
| ----------------------- | ------ | ----------------------------------- |
| Gnosis Safe integration | ✅     | `SafeService`                       |
| Stripe Connect (fiat)   | ✅     | `OfframpService`                    |
| Multi-sig signing       | ✅     | `SafeSigningService`                |
| Transaction history     | ✅     | `treasury_ledger`                   |
| 4-layer access control  | ✅     | Status, freeze, grace period, locks |
| Platform fees           | ✅     | FeeRouter contract                  |

**Gap**: Spending limits enforcement incomplete.

### Notifications ✅ (85% complete)

| Feature               | Status | Location                          |
| --------------------- | ------ | --------------------------------- |
| In-app notifications  | ✅     | Bell icon, notification center    |
| Email (13+ templates) | ✅     | Resend via `EmailTemplateService` |
| Push notifications    | ✅     | Expo Push with deep linking       |
| Voting reminders      | ✅     | 24h/6h/1h before deadline         |
| User preferences      | ✅     | Per-category toggles              |

**Gap**: No SMS, Slack, or Discord integrations.

### Activity History ✅ (85% complete)

| Feature           | Status | Location                           |
| ----------------- | ------ | ---------------------------------- |
| Activity feed     | ✅     | `dao_activities` table             |
| Admin audit logs  | ✅     | `dao_admin_audit_logs` (immutable) |
| Proposal history  | ✅     | Full lifecycle tracking            |
| Treasury history  | ✅     | `treasury_ledger`                  |
| Vote history      | ✅     | `votes` table with timestamps      |
| Reports (5 types) | ✅     | `dao-reports-panel.tsx`            |

**Gap**: No dedicated Decision Journal UI, no task tracking.

### Meetings/Calendar ❌ (20% complete)

| Feature               | Status | Notes                                  |
| --------------------- | ------ | -------------------------------------- |
| DAO meeting link      | ✅     | Static Zoom/Meet link in `socialLinks` |
| Proposal meeting link | ✅     | Optional link in proposal metadata     |
| Scheduled meetings    | ❌     | Not implemented                        |
| Calendar integration  | ❌     | Not implemented                        |
| .ics export           | ❌     | Not implemented                        |

### Documents ⚠️ (40% complete)

| Feature             | Status | Notes                                |
| ------------------- | ------ | ------------------------------------ |
| Attachment URLs     | ✅     | `attachments[]` in proposal metadata |
| Image URLs          | ✅     | `images[]` in proposal metadata      |
| Avatar/logo upload  | ✅     | Supabase storage                     |
| Document upload UI  | ❌     | No UI, only URLs                     |
| Link validation     | ❌     | No broken link detection             |
| Metadata extraction | ❌     | No title/icon from links             |

---

## Part 2: Features to Build

### Feature 1: Decision Journal

**What**: Searchable, filterable log of all governance decisions with execution status.

**Why**: Organizations need to answer "What did we decide?" and "Did it happen?"

#### Current State

- Activity feed exists but mixes decisions with other events
- Admin audit logs are technical (not user-facing)
- No way to see "decisions only" with their outcomes

#### Target State

```
┌─────────────────────────────────────────────────────────────────┐
│  DECISION JOURNAL                     [Table ▼] [Timeline]      │
│  ─────────────────                                               │
│  [All types ▼]  [2026 ▼]  [Search decisions...]                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  MAR 15, 2026 │ TREASURY │ Passed 8-2                           │
│  "Approve Q2 marketing budget of $5,000"                        │
│  ├── ✅ Executed: $5,000 sent to 0x7a3...                       │
│  ├── 📋 3 tasks created → 2 done, 1 in progress                 │
│  └── [View proposal] [View tasks]                               │
│                                                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  MAR 10, 2026 │ MEMBERSHIP │ Passed 12-0                        │
│  "Add Sarah Chen as Treasurer"                                  │
│  ├── ✅ Executed: Role updated                                  │
│  └── [View proposal]                                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

#### Data Model

No new tables needed — derive from existing:

```typescript
interface DecisionJournalEntry {
  id: string; // proposal.id
  title: string; // proposal.title
  type: 'treasury' | 'membership' | 'policy' | 'general';
  outcome: 'passed' | 'rejected';
  voteCount: { for: number; against: number; abstain: number };
  decidedAt: Date; // proposal.endTime

  // Execution tracking
  executionStatus: 'pending' | 'executed' | 'failed' | 'not_required';
  executedAt?: Date;
  executionTxHash?: string;

  // Task tracking (new)
  tasks: TaskSummary[];

  // Links
  proposalId: string;
  meetingId?: string; // If created from meeting
  linkedDocuments: LinkedDocument[];
}
```

#### API

```typescript
// GET /api/dao/[id]/decisions
// Query params: type, dateFrom, dateTo, search, page
// Returns: PaginatedResponse<DecisionJournalEntry>

// Derived from proposals where status = 'passed' | 'rejected'
```

#### UI Components

| Component               | Purpose                                    |
| ----------------------- | ------------------------------------------ |
| `decision-journal.tsx`  | Main page with filters and views           |
| `decision-card.tsx`     | Individual decision with outcome and tasks |
| `decision-timeline.tsx` | Vertical timeline view                     |
| `decision-filters.tsx`  | Filter bar (type, date, search)            |

#### Implementation

1. Create API route that queries proposals + aggregates execution status
2. Add timeline view to existing activity UI
3. Add filter for "decisions only"
4. Link to tasks (once task system exists)

**Effort**: 3-4 days

---

### Feature 2: Meeting → Vote Pipeline

**What**: Connect meeting agendas to proposals so decisions flow naturally from discussions.

**Why**: Most governance happens in meetings. Currently, meeting outcomes disconnect from voting.

#### Current State

- Proposals exist independently
- No meeting entity
- No agenda → proposal flow

#### Target State

**Before Meeting:**

```
┌─────────────────────────────────────────────────────────────────┐
│  MEETING: March Board Meeting                                    │
│  📅 March 20, 2026 @ 2:00 PM                                    │
│  📍 Zoom: https://zoom.us/j/123456                              │
│  [Add to Calendar]                                               │
├─────────────────────────────────────────────────────────────────┤
│  AGENDA                                                          │
│                                                                  │
│  1. ☑️ Approve Q1 financial report                              │
│     └── [Draft proposal ready] — Will vote after meeting        │
│                                                                  │
│  2. 💬 Discuss marketing strategy                               │
│     └── Discussion only (no vote)                               │
│                                                                  │
│  3. ☑️ Vote on 3 new member applications                        │
│     └── [Draft proposal ready]                                  │
│                                                                  │
│  [+ Add agenda item]                                            │
└─────────────────────────────────────────────────────────────────┘
```

**After Meeting:**

```
┌─────────────────────────────────────────────────────────────────┐
│  MEETING: March Board Meeting                                    │
│  Status: Concluded                                               │
├─────────────────────────────────────────────────────────────────┤
│  OUTCOMES                                                        │
│                                                                  │
│  1. ✅ Q1 financial report                                      │
│     Motion: "Approve as presented"                              │
│     └── [Open Voting Now]  [Schedule for Mar 21]                │
│                                                                  │
│  2. 📝 Marketing strategy                                       │
│     Notes: Focus on social media Q2                             │
│     └── No vote needed                                          │
│                                                                  │
│  3. ✅ New member applications                                  │
│     └── [Voting Open] — Ends Mar 23                             │
│                                                                  │
│  [Generate Minutes]                                             │
└─────────────────────────────────────────────────────────────────┘
```

#### Data Model

```sql
-- New table: meetings
CREATE TABLE meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID REFERENCES daos(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  scheduled_at TIMESTAMPTZ NOT NULL,
  location TEXT,                    -- "Zoom: https://..." or "123 Main St"
  meeting_link TEXT,                -- Video conference URL
  status TEXT DEFAULT 'scheduled',  -- scheduled, in_progress, concluded, cancelled
  notes TEXT,                       -- Meeting notes/minutes
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  concluded_at TIMESTAMPTZ
);

-- New table: agenda_items
CREATE TABLE agenda_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  item_type TEXT DEFAULT 'discussion',  -- 'discussion' | 'voting'
  order_index INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',        -- pending, discussed, converted
  discussion_notes TEXT,
  proposal_id UUID REFERENCES proposals(id),  -- Link to converted proposal
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add to proposals table
ALTER TABLE proposals ADD COLUMN meeting_id UUID REFERENCES meetings(id);
ALTER TABLE proposals ADD COLUMN agenda_item_id UUID REFERENCES agenda_items(id);
```

#### API Routes

```typescript
// Meetings CRUD
POST / api / dao / [id] / meetings;
GET / api / dao / [id] / meetings;
GET / api / dao / [id] / meetings / [meetingId];
PATCH / api / dao / [id] / meetings / [meetingId];
DELETE / api / dao / [id] / meetings / [meetingId];

// Agenda items
POST / api / dao / [id] / meetings / [meetingId] / agenda;
PATCH / api / dao / [id] / meetings / [meetingId] / agenda / [itemId];
DELETE / api / dao / [id] / meetings / [meetingId] / agenda / [itemId];

// Convert agenda item to proposal (one-click)
POST / api / dao / [id] / meetings / [meetingId] / agenda / [itemId] / convert -
  to -
  proposal;
// Body: { proposalType, votingConfig }
// Returns: Proposal with meetingId and agendaItemId set

// Conclude meeting
POST / api / dao / [id] / meetings / [meetingId] / conclude;
// Body: { notes }
```

#### UI Components

| Component              | Purpose                         |
| ---------------------- | ------------------------------- |
| `meetings-list.tsx`    | List of scheduled/past meetings |
| `meeting-detail.tsx`   | Single meeting with agenda      |
| `meeting-form.tsx`     | Create/edit meeting             |
| `agenda-item-card.tsx` | Agenda item with convert button |
| `meeting-minutes.tsx`  | Generated minutes from outcomes |

#### Implementation

1. Create database migrations
2. Build meeting service layer
3. Build UI components
4. Add "Open Voting" flow from agenda item
5. Link proposals back to meetings in decision journal

**Effort**: 5-7 days

---

### Feature 3: Calendar Integration

**What**: Sync voting deadlines and meetings to members' existing calendars.

**Why**: People miss votes because deadlines aren't in their calendars.

#### Current State

- No calendar integration
- No .ics export
- Deadlines only visible in app

#### Target State

Three levels of integration:

**Level 1: Add-to-Calendar Buttons (MVP)**

```
┌─────────────────────────────────────────┐
│  Voting ends: March 25, 2026 @ 5:00 PM  │
│                                         │
│  [📅 Google] [📅 Outlook] [📅 Apple]    │
└─────────────────────────────────────────┘
```

**Level 2: .ics Download**

```
┌─────────────────────────────────────────┐
│  [⬇️ Download Calendar Event (.ics)]    │
└─────────────────────────────────────────┘
```

**Level 3: Calendar Subscription (Future)**

- Subscribe URL for all DAO events
- Auto-updates when new proposals created

#### Implementation (Level 1-2)

```typescript
// Utility: Generate Google Calendar URL
function getGoogleCalendarUrl(event: CalendarEvent): string {
  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: event.title,
    dates: `${formatICSDate(event.start)}/${formatICSDate(event.end)}`,
    details: event.description,
    location: event.location || '',
  });
  return `https://calendar.google.com/calendar/render?${params}`;
}

// Utility: Generate .ics file content
function generateICS(event: CalendarEvent): string {
  return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//EnDAO//Governance//EN
BEGIN:VEVENT
UID:${event.id}@endao.ai
DTSTAMP:${formatICSDate(new Date())}
DTSTART:${formatICSDate(event.start)}
DTEND:${formatICSDate(event.end)}
SUMMARY:${event.title}
DESCRIPTION:${event.description.replace(/\n/g, '\\n')}
URL:${event.url}
END:VEVENT
END:VCALENDAR`;
}

// Component
function AddToCalendar({ proposal }: { proposal: Proposal }) {
  const event = {
    id: proposal.id,
    title: `Vote: ${proposal.title}`,
    start: new Date(),
    end: new Date(proposal.endTime),
    description: `Voting deadline for "${proposal.title}"\n\nView: ${window.location.href}`,
    url: window.location.href,
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <Calendar className="h-4 w-4 mr-2" />
          Add to Calendar
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem onClick={() => window.open(getGoogleCalendarUrl(event))}>
          Google Calendar
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => window.open(getOutlookCalendarUrl(event))}>
          Outlook
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => downloadICS(event)}>
          Download .ics
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
```

#### Where to Add

- Proposal detail page (voting deadline)
- Meeting detail page (meeting time)
- Notification emails (include .ics attachment)

**Effort**: 2-3 days (Level 1-2)

---

### Feature 4: Task/Action Item Tracking

**What**: Track action items that result from governance decisions.

**Why**: Decisions without accountability don't get implemented.

#### Current State

- Bounties can act as tasks (limited)
- No formal task system
- No decision → task flow

#### Target State

```
┌─────────────────────────────────────────────────────────────────┐
│  TASKS                                   [Kanban] [List]        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  TO DO          │  IN PROGRESS   │  REVIEW      │  DONE         │
│  ────────────── │  ───────────── │  ─────────── │  ────────     │
│                 │                │              │               │
│  ┌───────────┐  │  ┌───────────┐ │              │  ┌─────────┐  │
│  │ Update    │  │  │ Hire      │ │              │  │ Budget  │  │
│  │ website   │  │  │ designer  │ │              │  │ approved│  │
│  │           │  │  │           │ │              │  │         │  │
│  │ @Alice    │  │  │ @Bob      │ │              │  │ @Carol  │  │
│  │ Due: 3/20 │  │  │ Due: 3/25 │ │              │  │ ✓ 3/15  │  │
│  │           │  │  │           │ │              │  │         │  │
│  │ From:     │  │  │ From:     │ │              │  │ From:   │  │
│  │ Decision  │  │  │ Decision  │ │              │  │ Decision│  │
│  │ #47       │  │  │ #52       │ │              │  │ #45     │  │
│  └───────────┘  │  └───────────┘ │              │  └─────────┘  │
│                 │                │              │               │
└─────────────────────────────────────────────────────────────────┘
```

#### Data Model

```sql
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID REFERENCES daos(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,

  -- Assignment
  assigned_to UUID REFERENCES users(id),
  created_by UUID REFERENCES users(id),

  -- Status
  status TEXT DEFAULT 'todo',  -- todo, in_progress, review, completed, blocked
  priority TEXT DEFAULT 'medium',  -- low, medium, high, urgent
  progress INTEGER DEFAULT 0,  -- 0-100

  -- Dates
  due_date TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  -- Decision linkage (key feature)
  proposal_id UUID REFERENCES proposals(id),  -- Source decision
  meeting_id UUID REFERENCES meetings(id),    -- Source meeting (if any)

  -- Ordering for kanban
  order_index INTEGER DEFAULT 0
);

CREATE INDEX idx_tasks_dao_status ON tasks(dao_id, status);
CREATE INDEX idx_tasks_assigned ON tasks(assigned_to, status);
CREATE INDEX idx_tasks_proposal ON tasks(proposal_id);
```

#### API Routes

```typescript
// Tasks CRUD
POST / api / dao / [id] / tasks;
GET / api / dao / [id] / tasks;
GET / api / dao / [id] / tasks / [taskId];
PATCH / api / dao / [id] / tasks / [taskId];
DELETE / api / dao / [id] / tasks / [taskId];

// Bulk operations for kanban
PATCH / api / dao / [id] / tasks / reorder;
// Body: { taskId, newStatus, newOrderIndex }

// Create tasks from proposal (after passing)
POST / api / dao / [id] / proposals / [proposalId] / create - tasks;
// Body: { tasks: [{ title, assignedTo, dueDate }] }

// My tasks
GET / api / user / tasks;
```

#### UI Components

| Component            | Purpose                            |
| -------------------- | ---------------------------------- |
| `task-kanban.tsx`    | Drag-and-drop kanban board         |
| `task-list.tsx`      | Filterable list view               |
| `task-card.tsx`      | Task card with decision link       |
| `task-form.tsx`      | Create/edit task                   |
| `task-quick-add.tsx` | Inline task creation from proposal |

#### Create Tasks from Decision

When a proposal passes, prompt to create tasks:

```
┌─────────────────────────────────────────────────────────────────┐
│  ✅ Proposal Passed: "Approve Q2 Marketing Budget"              │
│                                                                  │
│  Create action items from this decision?                        │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ Task 1: Research ad platforms         @Alice    Due: 3/20  ││
│  │ Task 2: Get design quotes             @Bob      Due: 3/25  ││
│  │ Task 3: Draft campaign brief          @Carol    Due: 3/30  ││
│  │ [+ Add another task]                                       ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                  │
│  [Skip]  [Create Tasks]                                         │
└─────────────────────────────────────────────────────────────────┘
```

**Effort**: 5-7 days

---

### Feature 5: Enhanced Member Directory

**What**: Rich member profiles with role visualization and permissions.

**Why**: Formal organizations need to know who can do what.

#### Current State

- Basic member list with name, avatar, role
- 3 roles: owner, admin, member
- No permission visualization

#### Target State

```
┌─────────────────────────────────────────────────────────────────┐
│  MEMBERS (24)                     [Grid] [List] [By Role]       │
│  [Search members...]                                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────┐  ┌─────────────────────────┐       │
│  │  👤 Sarah Chen          │  │  👤 Mike Johnson        │       │
│  │  ────────────────────   │  │  ────────────────────   │       │
│  │  🏷️ TREASURER (Admin)   │  │  🏷️ ADMIN              │       │
│  │                         │  │                         │       │
│  │  Permissions:           │  │  Permissions:           │       │
│  │  ✓ Create proposals     │  │  ✓ Create proposals     │       │
│  │  ✓ Manage treasury      │  │  ✓ Manage members       │       │
│  │  ✓ Vote                 │  │  ✓ Vote                 │       │
│  │                         │  │                         │       │
│  │  Joined: Jan 2025       │  │  Joined: Mar 2024       │       │
│  │  [View Profile] [···]   │  │  [View Profile] [···]   │       │
│  └─────────────────────────┘  └─────────────────────────┘       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

#### Data Model Changes

```sql
-- Add custom title to dao_members
ALTER TABLE dao_members ADD COLUMN title TEXT;  -- "Treasurer", "Secretary", etc.

-- Permissions are derived from role (no new table needed)
-- Role hierarchy: owner > admin > member
-- Permissions per role:
--   owner: all permissions
--   admin: create proposals, manage members, vote, view treasury
--   member: create proposals, vote
```

```typescript
interface MemberWithPermissions {
  id: string;
  userId: string;
  displayName: string;
  avatarUrl?: string;
  role: 'owner' | 'admin' | 'member';
  title?: string; // Custom title like "Treasurer"
  joinedAt: Date;
  permissions: {
    canVote: boolean;
    canCreateProposal: boolean;
    canManageTreasury: boolean;
    canManageMembers: boolean;
    canArchiveDao: boolean;
  };
}

// Derive permissions from role
function getPermissions(role: MemberRole): Permissions {
  switch (role) {
    case 'owner':
      return {
        canVote: true,
        canCreateProposal: true,
        canManageTreasury: true,
        canManageMembers: true,
        canArchiveDao: true,
      };
    case 'admin':
      return {
        canVote: true,
        canCreateProposal: true,
        canManageTreasury: true,
        canManageMembers: true,
        canArchiveDao: false,
      };
    case 'member':
      return {
        canVote: true,
        canCreateProposal: true,
        canManageTreasury: false,
        canManageMembers: false,
        canArchiveDao: false,
      };
  }
}
```

#### UI Enhancements

1. **Permission badges** on member cards
2. **Title field** (editable by admin) — "Treasurer", "Secretary", "Board Chair"
3. **"By Role" view** — Grouped list showing hierarchy
4. **Permission legend** — What each role can do

**Effort**: 2-3 days

---

### Feature 6: Document Linking

**What**: Link external documents (Google Drive, Notion, Dropbox) to proposals with validation.

**Why**: Decisions need supporting documents; don't want to host storage.

#### Current State

- `attachments[]` stores raw URLs
- No validation
- No metadata extraction
- No preview

#### Target State

```
┌─────────────────────────────────────────────────────────────────┐
│  SUPPORTING DOCUMENTS                                           │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ 📄 Q2 Budget Spreadsheet                                  │  │
│  │    Google Sheets • Modified 2 days ago                    │  │
│  │    [Open ↗]                                               │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ ⚠️ Vendor Quote Document                                  │  │
│  │    Link may be broken or you lost access                  │  │
│  │    [Try opening ↗]                                        │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ 🔗 Paste Google Drive, Notion, or Dropbox link...         │  │
│  │    [Add Document]                                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

#### Data Model

```typescript
interface LinkedDocument {
  id: string;
  url: string;
  provider: 'google-drive' | 'notion' | 'dropbox' | 'other';
  title?: string; // Extracted from URL/API
  icon?: string; // Provider icon
  lastVerified?: Date; // When we last checked accessibility
  isAccessible: boolean;
  accessError?: 'unauthorized' | 'not-found' | 'expired';
}

// Store in proposal metadata (existing field)
interface ProposalMetadata {
  // ... existing fields
  linkedDocuments?: LinkedDocument[];
}
```

#### API Route

```typescript
// POST /api/documents/validate
// Body: { url: string }
// Returns: LinkedDocument with metadata

async function validateDocument(url: string): Promise<LinkedDocument> {
  const provider = detectProvider(url);

  try {
    // Try to fetch metadata (HEAD request or provider API)
    const metadata = await fetchMetadata(url, provider);
    return {
      url,
      provider,
      title: metadata.title,
      icon: getProviderIcon(provider),
      lastVerified: new Date(),
      isAccessible: true,
    };
  } catch (error) {
    return {
      url,
      provider,
      lastVerified: new Date(),
      isAccessible: false,
      accessError: classifyError(error),
    };
  }
}
```

#### UI Component

```typescript
function DocumentLink({ doc }: { doc: LinkedDocument }) {
  if (!doc.isAccessible) {
    return (
      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="flex items-center gap-3 py-3">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <div className="flex-1">
            <p className="font-medium text-amber-900">
              {doc.accessError === 'unauthorized' ? 'Access lost' : 'Link broken'}
            </p>
            <a href={doc.url} className="text-xs text-amber-700 underline">
              Try opening directly
            </a>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover:shadow-sm transition-shadow cursor-pointer"
          onClick={() => window.open(doc.url)}>
      <CardContent className="flex items-center gap-3 py-3">
        <img src={doc.icon} alt="" className="h-6 w-6" />
        <div className="flex-1 min-w-0">
          <p className="font-medium truncate">{doc.title || 'Document'}</p>
          <p className="text-xs text-muted-foreground">
            {doc.provider} • Verified {formatRelative(doc.lastVerified)}
          </p>
        </div>
        <ExternalLink className="h-4 w-4 text-muted-foreground" />
      </CardContent>
    </Card>
  );
}
```

**Effort**: 2-3 days

---

## Part 3: Implementation Plan

### Phase 1: Foundation (Week 1-2)

| Task                                   | Days | Dependencies |
| -------------------------------------- | ---- | ------------ |
| Decision Journal API                   | 2    | None         |
| Decision Journal UI (table + timeline) | 2    | API          |
| Meeting database schema                | 1    | None         |
| Meeting service layer                  | 2    | Schema       |
| Meeting UI (list, detail, form)        | 2    | Service      |

**Deliverables**: Decision Journal page, Meeting creation/viewing

### Phase 2: Workflows (Week 3-4)

| Task                             | Days | Dependencies   |
| -------------------------------- | ---- | -------------- |
| Agenda items with voting flag    | 2    | Meetings       |
| Convert agenda to proposal flow  | 2    | Agenda items   |
| Calendar integration (Level 1-2) | 2    | None           |
| Add to proposal detail pages     | 1    | Calendar utils |

**Deliverables**: Meeting → Vote pipeline, Add to Calendar buttons

### Phase 3: Task Management (Week 5-6)

| Task                            | Days | Dependencies      |
| ------------------------------- | ---- | ----------------- |
| Tasks database schema           | 1    | None              |
| Tasks service layer             | 2    | Schema            |
| Task Kanban UI                  | 3    | Service           |
| Create tasks from decision flow | 2    | Tasks + Decisions |
| Task list in Decision Journal   | 1    | Both              |

**Deliverables**: Full task system linked to decisions

### Phase 4: Polish (Week 7)

| Task                             | Days | Dependencies |
| -------------------------------- | ---- | ------------ |
| Enhanced member directory        | 2    | None         |
| Document linking with validation | 2    | None         |
| Mobile support for new features  | 2    | All above    |
| Testing and bug fixes            | 1    | All          |

**Deliverables**: Complete feature set

---

## Part 4: Best Practices Summary

### UI/UX Patterns

| Pattern                          | Apply To          | Implementation                               |
| -------------------------------- | ----------------- | -------------------------------------------- |
| **Dual view** (table + timeline) | Decision Journal  | Toggle button, shared filter state           |
| **One-click actions**            | Agenda → Proposal | Single button, immediate feedback            |
| **Progressive disclosure**       | Document errors   | Show simple message, expand for details      |
| **Kanban with links**            | Tasks             | dnd-kit library, card links back to decision |
| **Permission badges**            | Members           | Derived from role, color + icon + text       |

### Accessibility Requirements

| Feature           | Requirements                                       |
| ----------------- | -------------------------------------------------- |
| Decision timeline | Keyboard navigation, screen reader labels          |
| Task kanban       | Keyboard drag-drop (Enter to pick, arrows to move) |
| Calendar buttons  | Clear labels ("Add to Google Calendar")            |
| Document links    | Error states announced, links focusable            |
| Member cards      | Role badges have text, not just color              |

### Mobile Considerations

| Feature          | Mobile Approach                               |
| ---------------- | --------------------------------------------- |
| Decision Journal | Vertical timeline (no table on small screens) |
| Kanban           | Single column, swipe to change status         |
| Calendar         | Native share sheet for .ics files             |
| Member directory | Card stack, not grid                          |

### Code Patterns

```typescript
// 1. Always use CSRF API for mutations
const csrfApi = useCSRFAPI();
await csrfApi.call('/api/...', { method: 'POST', body: JSON.stringify(data) });

// 2. ServiceResponse handling
if (!result.success) {
  toast.error(result.error);
  return;
}
// TS knows result.data exists here

// 3. Optimistic updates for kanban
const [tasks, setTasks] = useState(initialTasks);
const moveTask = async (taskId: string, newStatus: Status) => {
  // Optimistic update
  setTasks((prev) =>
    prev.map((t) => (t.id === taskId ? { ...t, status: newStatus } : t))
  );

  // API call
  const result = await csrfApi.call(`/api/tasks/${taskId}`, {
    method: 'PATCH',
    body: JSON.stringify({ status: newStatus }),
  });

  // Revert on failure
  if (!result.success) {
    setTasks(initialTasks);
    toast.error('Failed to update task');
  }
};

// 4. Calendar URL generation
const getGoogleCalendarUrl = (event: CalendarEvent) => {
  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: event.title,
    dates: `${formatICS(event.start)}/${formatICS(event.end)}`,
    details: event.description,
  });
  return `https://calendar.google.com/calendar/render?${params}`;
};
```

---

## Success Metrics

| Metric                 | Target                          | Measurement    |
| ---------------------- | ------------------------------- | -------------- |
| Decision Journal usage | 50% of admins view weekly       | Analytics      |
| Meeting creation       | 30% of DAOs create meetings     | Database       |
| Task completion rate   | 70% of tasks marked complete    | Database       |
| Calendar adds          | 20% of voters add to calendar   | Click tracking |
| Document links         | Avg 2 docs per funding proposal | Database       |

---

## What We're NOT Building

| Feature                  | Why Not                                 |
| ------------------------ | --------------------------------------- |
| Full calendar app        | Google/Outlook exist; just integrate    |
| Video conferencing       | Zoom/Meet exist; just link              |
| Document editing         | Google Docs/Notion exist; just link     |
| Chat/messaging           | Slack/Discord exist                     |
| Project boards           | Would become Monday/Asana; not our core |
| Complex role permissions | 3-tier is sufficient for most orgs      |

**Philosophy**: EnDAO is the **decision layer**, not the **content layer**. We connect to tools people already use, we don't replace them.
