# EnDAO Ecosystem Growth Plan - Master Implementation Specification

> ⚠️ **HISTORICAL REFERENCE DOCUMENT**
>
> This document contains detailed specifications from early platform design (Dec 2025).
> For current priorities and authoritative roadmaps, see:
>
> - **Platform features**: [PLATFORM_ROADMAP.md](/PLATFORM_ROADMAP.md)
> - **Token economics**: [TOKEN_ROADMAP.md](/TOKEN_ROADMAP.md)
> - **Development status**: [docs/development/DEVELOPMENT_TRACKER.md](/docs/development/DEVELOPMENT_TRACKER.md)
>
> Sections may contain assumptions that have evolved. Validate against current roadmaps before implementation.

---

**Purpose**: Comprehensive scaling architecture for the future of decentralized business
**Source**: `/docs/ECOSYSTEM_GROWTH_PLAN.md` v2.0
**Generated**: December 5, 2025
**Status**: Historical Reference (superseded by PLATFORM_ROADMAP.md and TOKEN_ROADMAP.md)
**Classification**: INTERNAL - Strategic Planning Document

---

## Vision Statement

> **"EnDAO as the institutional DAO layer for business—not just organizations managing themselves, but the connective rails between organizations."**

This document defines the complete technical, economic, and operational architecture for transforming EnDAO from a DAO management platform into the foundational infrastructure for decentralized business.

---

## Table of Contents

1. [Current State Assessment](#1-current-state-assessment)
2. [Token Architecture (TEQ/TCR/EDG)](#2-token-architecture-teqtcredg)
   - 2.1 EDG Governance Token
   - 2.2 TCR TimeCredits Token
   - 2.3 TEQ Time-Equity Token
   - 2.4 LaborOracle
   - 2.5 ServiceMarketplace
   - 2.6 Tokenomics Deep Dive
   - 2.7 Token Integration Points
3. [Treasury Tier System](#3-treasury-tier-system)
   - 3.1 Tier 1: Starter
   - 3.2 Tier 2: Growing
   - 3.3 Tier 3: Established (Ops Wallet)
   - 3.4 Tier 4: Enterprise
   - 3.5 Treasury UX Flows
   - 3.6 Multi-Currency Handling
   - 3.7 Accounting Integrations
4. [Commerce vs Community DAOs](#4-commerce-vs-community-daos)
   - 4.1 Type Selection
   - 4.2 Consent-Based Governance
   - 4.3 Type Migration
   - 4.4 Configuration Deep Dive
5. [Sub-DAO & DAO-to-DAO Architecture](#5-sub-dao--dao-to-dao-architecture)
   - 5.1 Sub-DAO Hierarchy
   - 5.2 DAO-to-DAO Relationships
   - 5.3 DAO-to-DAO Primitives
   - 5.4 Federation Protocol
   - 5.5 Discovery Mechanism
6. [Recovery & Security](#6-recovery--security)
   - 6.1 Current Security
   - 6.2 Social Recovery
   - 6.3 EnDAO Guardian Service
   - 6.4 Security Audit Requirements
   - 6.5 Incident Response
7. [Revenue Model Implementation](#7-revenue-model-implementation)
   - 7.1 Revenue Streams
   - 7.2 Fee Distribution
   - 7.3 Portability Test
   - 7.4 Financial Projections
8. [Legal-Technical Bridge](#8-legal-technical-bridge)
   - 8.1 Entity Strategy
   - 8.2 Technical-Legal Mapping
   - 8.3 Tax Reporting
   - 8.4 Compliance Framework
9. [API & Database Specifications](#9-api--database-specifications)
   - 9.1 API Architecture
   - 9.2 Database Schemas
   - 9.3 Event System
10. [Implementation Phases](#10-implementation-phases)

- 10.1 Phase 1: MVP Quality
- 10.2 Phase 2: Network Foundation
- 10.3 Phase 3: Network Features
- 10.4 Phase 4: Institutional Rails

11. [Technical Checklists](#11-technical-checklists)

- 11.1 Smart Contract Checklist
- 11.2 Platform Checklist
- 11.3 Testing Strategy
- 11.4 Monitoring & Alerting

12. [Appendices](#12-appendices)

---

## 1. Current State Assessment

### What's Live in Production

| Component                       | Status  | Location                                             |
| ------------------------------- | ------- | ---------------------------------------------------- |
| **FeeRouter.sol**               | ✅ LIVE | Base Mainnet, 5% contribution / 2% transfer fees     |
| **Treasury Execution**          | ✅ LIVE | Gnosis Safe v1.4.1 + Biconomy MEE-7579 gasless       |
| **Proposal System**             | ✅ LIVE | 4-type system (general, funding, governance, bounty) |
| **Voting Engine**               | ✅ LIVE | Simple voting, quorum enforcement                    |
| **Member Management**           | ✅ LIVE | Binary roles (member/admin)                          |
| **Ledger Recording**            | ✅ LIVE | Full transaction audit trail                         |
| **4-Layer Treasury Protection** | ✅ LIVE | Freeze, grace period, emergency recovery             |

### What's Schema-Only (Fields Exist, Not Enforced)

| Feature               | Fields Defined                                                   | Enforcement Status   |
| --------------------- | ---------------------------------------------------------------- | -------------------- |
| Spending Limits       | `maxDailySpend`, `maxSingleTransaction`, `requiresApprovalAbove` | ❌ Not validated     |
| Whitelist/Blacklist   | `whitelistedRecipients`, `blacklistedAddresses`                  | ❌ Not enforced      |
| Timelock Delays       | `timelockDelay`                                                  | ❌ Not implemented   |
| Token-Weighted Voting | `votingPower` calculations                                       | ❌ Equal weight only |
| Vote Delegation       | `allowDelegation`                                                | ❌ Not implemented   |

### What's Not Built

| Component                   | Phase Target          |
| --------------------------- | --------------------- |
| TEQ (Time-Equity) Token     | Phase 2               |
| TCR (TimeCredits) Token     | Phase 1               |
| EDG (Governance) Token      | Phase 1 (priority)    |
| ServiceMarketplace          | Phase 2               |
| LaborOracle                 | Phase 2               |
| Social Recovery             | Phase 1 (MVP blocker) |
| Commerce vs Community Split | Phase 1               |
| Sub-DAO Hierarchy           | Phase 2               |
| DAO-to-DAO Rails            | Phase 3               |

---

## 2. Token Architecture (TEQ/TCR/EDG)

### Token Summary Matrix

| Token   | Full Name            | Purpose                             | Transferable | Standard                   | Phase |
| ------- | -------------------- | ----------------------------------- | ------------ | -------------------------- | ----- |
| **EDG** | EnDAO Governance     | Protocol governance + fee discounts | ✅ Yes       | ERC-20Votes + ERC-4626     | 1     |
| **TCR** | TimeCredits          | Labor payment utility               | ✅ Yes       | ERC-20 + ERC-2612          | 1     |
| **TEQ** | Time-Equity Protocol | Soulbound membership equity         | ❌ No        | ERC-20 (Soulbound) + Votes | 2     |

### 2.1 EDG Token (Launch First)

**Why First**: EDG enables protocol governance before marketplace exists. Holders can vote on:

- Treasury allocation decisions
- Rate setting for LaborOracle
- Committee (Sub-DAO) admission
- Protocol parameter changes

**Technical Specification**:

```solidity
// contracts/EDG.sol
contract EDG is ERC20, ERC20Votes, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");

    constructor() ERC20("EnDAO Governance", "EDG") ERC20Permit("EDG") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    function mint(address to, uint256 amount) external onlyRole(MINTER_ROLE) {
        _mint(to, amount);
    }

    // ERC-20Votes requires these overrides
    function _update(address from, address to, uint256 value)
        internal override(ERC20, ERC20Votes)
    {
        super._update(from, to, value);
    }

    function nonces(address owner) public view override(ERC20Permit, Nonces) returns (uint256) {
        return super.nonces(owner);
    }
}
```

**Staking Vault (Fee Discounts)**:

```solidity
// contracts/EDGVault.sol
contract EDGVault is ERC4626 {
    uint256 public constant GOLD_THRESHOLD = 50_000 ether;
    uint256 public constant SILVER_THRESHOLD = 10_000 ether;

    function getDiscountTier(address user) public view returns (uint256) {
        uint256 balance = balanceOf(user);
        if (balance >= GOLD_THRESHOLD) return 100;  // 100% fee discount
        if (balance >= SILVER_THRESHOLD) return 50; // 50% fee discount
        return 0;
    }

    // Integration point: FeeRouter checks this before calculating fees
    function calculateDiscountedFee(address user, uint256 baseFee) external view returns (uint256) {
        uint256 discount = getDiscountTier(user);
        return (baseFee * (100 - discount)) / 100;
    }
}
```

**Integration with Existing Infrastructure**:

| Existing Component | Integration Point                                                     |
| ------------------ | --------------------------------------------------------------------- |
| `FeeRouter.sol`    | Call `edgVault.getDiscountTier(user)` before fee calculation          |
| Proposal voting    | Weight votes by EDG balance: `votingPower = edgBalance / totalSupply` |
| DAO admin actions  | Require EDG stake for treasury admin role                             |

**Distribution Strategy**:

- 10% - Team (4-year vesting, 1-year cliff)
- 15% - Early contributors (2-year vesting)
- 25% - Community treasury (governance-controlled)
- 50% - Reserved for future distribution (locked initially)

---

### 2.2 TCR Token (TimeCredits)

**Purpose**: Payment utility token for the labor marketplace. 1 TCR = $1 USD equivalent.

**Technical Specification**:

```solidity
// contracts/TCR.sol
contract TCR is ERC20, ERC20Permit, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BRIDGE_ROLE = keccak256("BRIDGE_ROLE");

    constructor() ERC20("TimeCredits", "TCR") ERC20Permit("TCR") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    // Mint by marketplace (work completion) or bridge (fiat on-ramp)
    function mint(address to, uint256 amount) external {
        require(
            hasRole(MINTER_ROLE, msg.sender) || hasRole(BRIDGE_ROLE, msg.sender),
            "Unauthorized"
        );
        _mint(to, amount);
    }

    // Burn for off-ramp
    function burn(uint256 amount) external {
        _burn(msg.sender, amount);
    }
}
```

**Fiat Bridge Architecture**:

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   User's Bank   │────▶│  Bridge Service  │────▶│   TCR Token     │
│   (Stripe/ACH)  │     │  (Centralized)   │     │   (On-chain)    │
└─────────────────┘     └──────────────────┘     └─────────────────┘
         │                       │                        │
         │  $100 USD            │  Verify deposit        │  Mint 100 TCR
         │                       │  KYC check             │  to user wallet
         ▼                       ▼                        ▼
    Fiat account           BRIDGE_ROLE calls           ERC-20 balance
    debited                 tcr.mint(user, 100e18)     updated
```

**Fee Flow (Existing FeeRouter Integration)**:

```
Job Completion Flow:
1. Client deposits 100 TCR to ServiceMarketplace escrow
2. Provider completes work
3. Client approves completion
4. ServiceMarketplace calls:
   - tcr.transfer(provider, 97 TCR)     // 97% to provider
   - tcr.transfer(feeRouter, 3 TCR)     // 3% protocol fee
   - teq.mint(provider, equityValue)    // Equity minted (Phase 2)
```

---

### 2.3 TEQ Token (Time-Equity Protocol) - Phase 2

**Purpose**: Soulbound membership equity. Cannot be transferred, only earned through labor.

**Technical Specification**:

```solidity
// contracts/TEQ.sol
contract TEQ is ERC20, ERC20Votes, AccessControl {
    error Soulbound();
    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");

    // Track cumulative labor value for each holder
    mapping(address => uint256) public cumulativeLaborValueUSD;

    struct VestingSchedule {
        uint256 totalAmount;
        uint256 vestedAmount;
        uint256 startTime;
        uint256 cliffDuration;
        uint256 vestingDuration;
    }
    mapping(address => VestingSchedule) public vestingSchedules;

    constructor() ERC20("Time-Equity Protocol", "TEQ") ERC20Permit("TEQ") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    function mint(address to, uint256 amount, uint256 laborValueUSD)
        external onlyRole(CONTROLLER_ROLE)
    {
        cumulativeLaborValueUSD[to] += laborValueUSD;
        _mint(to, amount);
        emit EquityMinted(to, amount, laborValueUSD, cumulativeLaborValueUSD[to]);
    }

    // SOULBOUND: Block all transfers
    function _update(address from, address to, uint256 value)
        internal override(ERC20, ERC20Votes)
    {
        // Allow mint (from == 0) and burn (to == 0), block transfers
        if (from != address(0) && to != address(0)) {
            revert Soulbound();
        }
        super._update(from, to, value);
    }

    event EquityMinted(address indexed to, uint256 amount, uint256 laborValueUSD, uint256 cumulative);
}
```

**Liquidity Events (How TEQ Holders Exit)**:

1. **Treasury Buybacks**: DUNA votes to buy back TEQ at Cost-Plus valuation
2. **Dividends**: DUNA distributes surplus revenue proportionally to TEQ holders
3. **Redemption Window**: Annual 30-day window where holders can request redemption

---

### 2.4 LaborOracle (Cost-Plus Valuation)

**Purpose**: Replaces complex "Health Score" with `Hours × Market Rate`.

```solidity
// contracts/LaborOracle.sol
contract LaborOracle is AccessControl {
    bytes32 public constant UPDATER_ROLE = keccak256("UPDATER_ROLE");

    struct JobType {
        uint256 ratePerHour;      // In USD cents (e.g., 5000 = $50/hr)
        uint256 maxRateCap;       // Anti-gaming: max rate allowed
        uint256 maxHoursPerWeek;  // Anti-gaming: max hours per contributor
        bool requiresAttestation; // Requires EAS attestation
        bool isActive;
    }

    mapping(uint256 => JobType) public jobTypes;
    mapping(address => mapping(uint256 => uint256)) public weeklyHours; // user => week => hours

    function setJobType(
        uint256 jobTypeId,
        uint256 ratePerHour,
        uint256 maxRateCap,
        uint256 maxHoursPerWeek,
        bool requiresAttestation
    ) external onlyRole(UPDATER_ROLE) {
        require(ratePerHour <= maxRateCap, "Rate exceeds cap");
        jobTypes[jobTypeId] = JobType({
            ratePerHour: ratePerHour,
            maxRateCap: maxRateCap,
            maxHoursPerWeek: maxHoursPerWeek,
            requiresAttestation: requiresAttestation,
            isActive: true
        });
        emit JobTypeUpdated(jobTypeId, ratePerHour, maxRateCap, maxHoursPerWeek);
    }

    function calculateEquityValue(
        address contributor,
        uint256 jobTypeId,
        uint256 hoursWorked
    ) external returns (uint256 equityValue) {
        JobType storage job = jobTypes[jobTypeId];
        require(job.isActive, "Job type inactive");

        // Anti-gaming: Check weekly hour cap
        uint256 currentWeek = block.timestamp / 1 weeks;
        uint256 newWeeklyTotal = weeklyHours[contributor][currentWeek] + hoursWorked;
        require(newWeeklyTotal <= job.maxHoursPerWeek, "Exceeds weekly cap");

        weeklyHours[contributor][currentWeek] = newWeeklyTotal;

        // Calculate: hours × rate (in cents) / 100 = USD value
        equityValue = (hoursWorked * job.ratePerHour) / 100;

        return equityValue;
    }

    event JobTypeUpdated(uint256 indexed jobTypeId, uint256 rate, uint256 maxCap, uint256 maxHours);
}
```

**Initial Job Types (Beta)**:

| Job Type ID | Category      | Rate/Hour | Max Cap | Max Hours/Week |
| ----------- | ------------- | --------- | ------- | -------------- |
| 1           | General Labor | $50       | $75     | 40             |
| 2           | Skilled Trade | $75       | $125    | 40             |
| 3           | Professional  | $100      | $200    | 40             |
| 4           | Executive     | $150      | $300    | 30             |
| 5           | Advisory      | $200      | $500    | 20             |

---

### 2.5 ServiceMarketplace (Double-Dip Integration)

```solidity
// contracts/ServiceMarketplace.sol
contract ServiceMarketplace is ReentrancyGuard, AccessControl {
    IERC20 public tcr;
    TEQ public teq;
    LaborOracle public laborOracle;
    EDGVault public edgVault;
    address public treasury;
    uint256 public protocolFeeBps = 300; // 3%

    struct Job {
        address client;
        address provider;
        uint256 amount;          // TCR amount
        uint256 jobTypeId;
        uint256 hoursWorked;
        JobStatus status;
    }

    enum JobStatus { Created, InProgress, Completed, Disputed, Cancelled }

    mapping(uint256 => Job) public jobs;
    uint256 public nextJobId;

    function createJob(
        address provider,
        uint256 amount,
        uint256 jobTypeId,
        uint256 estimatedHours
    ) external nonReentrant returns (uint256 jobId) {
        // Transfer TCR to escrow
        tcr.transferFrom(msg.sender, address(this), amount);

        jobId = nextJobId++;
        jobs[jobId] = Job({
            client: msg.sender,
            provider: provider,
            amount: amount,
            jobTypeId: jobTypeId,
            hoursWorked: estimatedHours,
            status: JobStatus.Created
        });

        emit JobCreated(jobId, msg.sender, provider, amount, jobTypeId);
    }

    function completeJob(uint256 jobId, uint256 actualHours) external nonReentrant {
        Job storage job = jobs[jobId];
        require(msg.sender == job.client, "Only client");
        require(job.status == JobStatus.InProgress, "Invalid status");

        job.hoursWorked = actualHours;
        job.status = JobStatus.Completed;

        // Calculate fee with EDG discount
        uint256 baseFee = (job.amount * protocolFeeBps) / 10000;
        uint256 actualFee = edgVault.calculateDiscountedFee(job.client, baseFee);
        uint256 payout = job.amount - actualFee;

        // THE DOUBLE-DIP:
        // 1. Pay provider in TCR
        tcr.transfer(job.provider, payout);

        // 2. Send fee to treasury
        if (actualFee > 0) {
            tcr.transfer(treasury, actualFee);
        }

        // 3. Calculate and mint equity (TEQ)
        uint256 equityValue = laborOracle.calculateEquityValue(
            job.provider,
            job.jobTypeId,
            actualHours
        );
        teq.mint(job.provider, equityValue * 1e18, equityValue);

        emit JobCompleted(jobId, payout, equityValue, actualFee);
    }

    event JobCreated(uint256 indexed jobId, address client, address provider, uint256 amount, uint256 jobTypeId);
    event JobCompleted(uint256 indexed jobId, uint256 payout, uint256 equityValue, uint256 fee);
}
```

---

### 2.6 Tokenomics Deep Dive

#### 2.6.1 EDG Token Economics

**Total Supply**: 1,000,000,000 EDG (1 billion)
**Initial Circulating**: 100,000,000 EDG (10%)

**Distribution Schedule**:

| Allocation          | Amount      | %   | Vesting               | Cliff     | Purpose                    |
| ------------------- | ----------- | --- | --------------------- | --------- | -------------------------- |
| Team & Founders     | 100,000,000 | 10% | 48 months             | 12 months | Core team incentive        |
| Early Contributors  | 150,000,000 | 15% | 24 months             | 6 months  | Pre-launch contributors    |
| Community Treasury  | 250,000,000 | 25% | Governance-controlled | None      | DAO-voted initiatives      |
| Protocol Reserves   | 200,000,000 | 20% | 60 months             | 24 months | Strategic reserves         |
| Ecosystem Growth    | 150,000,000 | 15% | 36 months             | None      | Partnerships, integrations |
| Liquidity Provision | 100,000,000 | 10% | Immediate             | None      | DEX liquidity              |
| Airdrops & Rewards  | 50,000,000  | 5%  | 12 months             | None      | Community rewards          |

**Vesting Schedule Implementation**:

```solidity
// contracts/EDGVesting.sol
contract EDGVesting is AccessControl {
    struct VestingSchedule {
        uint256 totalAmount;
        uint256 startTime;
        uint256 cliffDuration;
        uint256 vestingDuration;
        uint256 releasedAmount;
        bool revocable;
        bool revoked;
    }

    mapping(address => VestingSchedule) public schedules;
    IERC20 public edgToken;

    function createVestingSchedule(
        address beneficiary,
        uint256 amount,
        uint256 cliffDuration,
        uint256 vestingDuration,
        bool revocable
    ) external onlyRole(ADMIN_ROLE) {
        require(schedules[beneficiary].totalAmount == 0, "Already has schedule");

        schedules[beneficiary] = VestingSchedule({
            totalAmount: amount,
            startTime: block.timestamp,
            cliffDuration: cliffDuration,
            vestingDuration: vestingDuration,
            releasedAmount: 0,
            revocable: revocable,
            revoked: false
        });

        edgToken.transferFrom(msg.sender, address(this), amount);
        emit VestingScheduleCreated(beneficiary, amount, cliffDuration, vestingDuration);
    }

    function vestedAmount(address beneficiary) public view returns (uint256) {
        VestingSchedule storage schedule = schedules[beneficiary];

        if (schedule.revoked) {
            return schedule.releasedAmount;
        }

        uint256 elapsed = block.timestamp - schedule.startTime;

        // Before cliff: 0
        if (elapsed < schedule.cliffDuration) {
            return 0;
        }

        // After full vesting: 100%
        if (elapsed >= schedule.vestingDuration) {
            return schedule.totalAmount;
        }

        // Linear vesting after cliff
        return (schedule.totalAmount * elapsed) / schedule.vestingDuration;
    }

    function release(address beneficiary) external {
        VestingSchedule storage schedule = schedules[beneficiary];
        uint256 vested = vestedAmount(beneficiary);
        uint256 releasable = vested - schedule.releasedAmount;

        require(releasable > 0, "Nothing to release");

        schedule.releasedAmount = vested;
        edgToken.transfer(beneficiary, releasable);

        emit TokensReleased(beneficiary, releasable);
    }

    event VestingScheduleCreated(address indexed beneficiary, uint256 amount, uint256 cliff, uint256 duration);
    event TokensReleased(address indexed beneficiary, uint256 amount);
}
```

**Governance Voting Power Calculation**:

```typescript
// src/lib/services/governance/voting-power.service.ts
interface VotingPowerCalculation {
  edgBalance: bigint; // Raw EDG balance
  stakedBalance: bigint; // EDG in vault
  delegatedPower: bigint; // Power delegated from others
  delegatedAway: bigint; // Power delegated to others
  totalVotingPower: bigint; // Final calculation
  percentageOfTotal: number; // % of total voting power
}

class VotingPowerService {
  // Voting power = (balance + staked) * multiplier + delegated - delegatedAway
  async calculateVotingPower(address: string): Promise<VotingPowerCalculation> {
    const [balance, staked, delegated, delegatedAway] = await Promise.all([
      this.edgContract.balanceOf(address),
      this.edgVault.balanceOf(address),
      this.getDelegatedToMe(address),
      this.getDelegatedFromMe(address),
    ]);

    // Staking multiplier: 1.5x for staked tokens
    const stakingMultiplier = 150n; // 1.5x in basis points
    const rawPower = balance + (staked * stakingMultiplier) / 100n;
    const totalVotingPower = rawPower + delegated - delegatedAway;

    const totalSupplyPower = await this.getTotalVotingPower();
    const percentageOfTotal =
      Number((totalVotingPower * 10000n) / totalSupplyPower) / 100;

    return {
      edgBalance: balance,
      stakedBalance: staked,
      delegatedPower: delegated,
      delegatedAway,
      totalVotingPower,
      percentageOfTotal,
    };
  }

  // Quadratic voting support (Phase 3)
  async calculateQuadraticPower(address: string): Promise<bigint> {
    const { totalVotingPower } = await this.calculateVotingPower(address);
    // sqrt(votingPower) to reduce whale influence
    return this.sqrt(totalVotingPower);
  }

  private sqrt(value: bigint): bigint {
    if (value < 0n) throw new Error('Negative value');
    if (value < 2n) return value;
    let z = value;
    let x = value / 2n + 1n;
    while (x < z) {
      z = x;
      x = (value / x + x) / 2n;
    }
    return z;
  }
}
```

#### 2.6.2 TCR Token Economics

**Supply Model**: Elastic (mint on deposit, burn on withdrawal)
**Peg**: 1 TCR = $1.00 USD

**Mint/Burn Mechanics**:

```
MINT FLOW:
User deposits $100 USDC → Bridge verifies → Mints 100 TCR to user
TCR Supply: +100

BURN FLOW:
User burns 100 TCR → Bridge verifies → Releases $100 USDC to user
TCR Supply: -100
```

**Collateralization Requirements**:

| Collateral Type | Ratio | Accepted Assets        |
| --------------- | ----- | ---------------------- |
| Fiat Reserves   | 100%  | USD (bank), USDC, USDT |
| Stablecoin      | 100%  | USDC, DAI, FRAX        |
| Volatile        | 150%  | ETH, BTC (with oracle) |

**Bridge Service Architecture**:

```typescript
// src/lib/services/bridge/tcr-bridge.service.ts
interface BridgeConfig {
  minDepositAmount: number; // $10 minimum
  maxDepositAmount: number; // $100,000 per transaction
  dailyLimit: number; // $1,000,000 per day
  kycThreshold: number; // $10,000 requires KYC
  processingTime: {
    ach: number; // 3-5 business days
    wire: number; // 1-2 business days
    stablecoin: number; // < 1 minute
  };
}

class TCRBridgeService {
  async initiateDeposit(
    userId: string,
    amount: number,
    paymentMethod: 'ach' | 'wire' | 'stablecoin',
    sourceAsset?: string
  ): Promise<DepositRequest> {
    // Validate user and KYC
    const user = await this.userService.getUser(userId);
    if (amount >= this.config.kycThreshold && !user.kycVerified) {
      throw new Error('KYC required for deposits over $10,000');
    }

    // Check daily limits
    const todayVolume = await this.getDailyVolume(userId);
    if (todayVolume + amount > this.config.dailyLimit) {
      throw new Error('Daily limit exceeded');
    }

    // Create deposit request
    const request = await this.createDepositRequest({
      userId,
      amount,
      paymentMethod,
      sourceAsset,
      status: 'pending',
      estimatedCompletion: this.estimateCompletion(paymentMethod),
    });

    // For stablecoin deposits, monitor for on-chain confirmation
    if (paymentMethod === 'stablecoin') {
      await this.monitorStablecoinDeposit(request);
    }

    return request;
  }

  async confirmDeposit(requestId: string): Promise<void> {
    const request = await this.getRequest(requestId);

    // Verify funds received
    await this.verifyFundsReceived(request);

    // Mint TCR to user's wallet
    const userWallet = await this.walletService.getUserWallet(request.userId);
    await this.tcrContract.mint(userWallet, request.amount * 1e18);

    // Update request status
    await this.updateRequest(requestId, { status: 'completed' });

    // Record for compliance
    await this.complianceService.recordMint({
      userId: request.userId,
      amount: request.amount,
      source: request.paymentMethod,
      timestamp: new Date(),
    });
  }

  async initiateWithdrawal(
    userId: string,
    amount: number,
    destination: 'bank' | 'stablecoin',
    destinationAddress?: string
  ): Promise<WithdrawalRequest> {
    // Verify user has sufficient TCR balance
    const balance = await this.tcrContract.balanceOf(
      await this.walletService.getUserWallet(userId)
    );
    if (balance < BigInt(amount) * 10n ** 18n) {
      throw new Error('Insufficient TCR balance');
    }

    // Create withdrawal request with hold
    const request = await this.createWithdrawalRequest({
      userId,
      amount,
      destination,
      destinationAddress,
      status: 'pending_burn',
    });

    // Burn TCR from user's wallet
    await this.tcrContract.burnFrom(
      await this.walletService.getUserWallet(userId),
      BigInt(amount) * 10n ** 18n
    );

    // Queue fiat/stablecoin transfer
    await this.queueTransfer(request);

    return request;
  }
}
```

#### 2.6.3 TEQ Token Economics

**Supply Model**: Inflationary (minted on labor completion)
**Cap**: No hard cap (labor-backed, tied to real economic value)

**Inflation Controls**:

| Control           | Mechanism               | Limit                    |
| ----------------- | ----------------------- | ------------------------ |
| Rate Caps         | LaborOracle limits      | Max $500/hr              |
| Hour Caps         | Weekly limits           | Max 60 hrs/week          |
| Attestation       | Supervisor verification | Required above $5,000/mo |
| Governance Freeze | ENDAO vote              | Emergency stop           |

**Equity Value Calculation**:

```
TEQ Minted = Hours Worked × Hourly Rate × Quality Multiplier

Where:
- Hours Worked: Verified by attestation (1-60 per week)
- Hourly Rate: From LaborOracle (e.g., $100/hr for Professional)
- Quality Multiplier: 0.8x - 1.2x based on client rating
```

**Redemption Economics**:

```typescript
// src/lib/services/teq/redemption.service.ts
interface RedemptionWindow {
  windowId: string;
  startDate: Date;
  endDate: Date;
  redemptionRate: number; // TCR per TEQ
  maxRedemptionPool: number; // Total TCR available
  totalRequested: number;
  status: 'upcoming' | 'active' | 'processing' | 'complete';
}

class TEQRedemptionService {
  // Annual redemption window (30 days each year)
  async createRedemptionWindow(
    year: number,
    redemptionPoolTCR: number
  ): Promise<RedemptionWindow> {
    // Calculate redemption rate based on:
    // 1. Total TEQ supply
    // 2. Available redemption pool
    // 3. Historical redemption demand

    const teqSupply = await this.teqContract.totalSupply();
    const historicalDemand = await this.getHistoricalDemandRate();

    // Base rate: pool / (supply * expected demand rate)
    const expectedDemand = (Number(teqSupply) / 1e18) * historicalDemand;
    const redemptionRate = redemptionPoolTCR / expectedDemand;

    const window: RedemptionWindow = {
      windowId: `redemption-${year}`,
      startDate: new Date(`${year}-03-01`),
      endDate: new Date(`${year}-03-31`),
      redemptionRate: Math.min(redemptionRate, 1.0), // Cap at 1:1
      maxRedemptionPool: redemptionPoolTCR,
      totalRequested: 0,
      status: 'upcoming',
    };

    await this.saveWindow(window);
    return window;
  }

  async requestRedemption(
    userId: string,
    teqAmount: number
  ): Promise<RedemptionRequest> {
    const activeWindow = await this.getActiveWindow();
    if (!activeWindow || activeWindow.status !== 'active') {
      throw new Error('No active redemption window');
    }

    // Check user TEQ balance
    const userWallet = await this.walletService.getUserWallet(userId);
    const balance = await this.teqContract.balanceOf(userWallet);
    if (balance < BigInt(teqAmount) * 10n ** 18n) {
      throw new Error('Insufficient TEQ balance');
    }

    // Calculate TCR payout
    const tcrPayout = teqAmount * activeWindow.redemptionRate;

    // Check if pool has capacity
    if (
      activeWindow.totalRequested + tcrPayout >
      activeWindow.maxRedemptionPool
    ) {
      throw new Error('Redemption pool exhausted');
    }

    // Create request (TEQ locked until processing)
    const request = await this.createRequest({
      userId,
      teqAmount,
      tcrPayout,
      windowId: activeWindow.windowId,
      status: 'pending',
    });

    // Lock TEQ
    await this.teqContract.lockForRedemption(
      userWallet,
      BigInt(teqAmount) * 10n ** 18n
    );

    // Update window
    activeWindow.totalRequested += tcrPayout;
    await this.saveWindow(activeWindow);

    return request;
  }

  async processRedemption(requestId: string): Promise<void> {
    const request = await this.getRequest(requestId);
    const userWallet = await this.walletService.getUserWallet(request.userId);

    // Burn locked TEQ
    await this.teqContract.burnLocked(
      userWallet,
      BigInt(request.teqAmount) * 10n ** 18n
    );

    // Transfer TCR
    await this.tcrContract.transfer(
      userWallet,
      BigInt(request.tcrPayout) * 10n ** 18n
    );

    await this.updateRequest(requestId, { status: 'complete' });
  }
}
```

#### 2.6.4 Liquidity Strategy

**DEX Liquidity (EDG)**:

| Pool                  | Allocation | Initial TVL Target |
| --------------------- | ---------- | ------------------ |
| EDG/ETH (Uniswap V3)  | 40M EDG    | $5M                |
| EDG/USDC (Uniswap V3) | 30M EDG    | $3M                |
| EDG/TCR (Aerodrome)   | 30M EDG    | $2M                |

**Liquidity Incentives**:

```solidity
// contracts/LiquidityMining.sol
contract LiquidityMining is Ownable {
    IERC20 public edgToken;
    IERC20 public lpToken;

    uint256 public rewardRate;           // EDG per second
    uint256 public lastUpdateTime;
    uint256 public rewardPerTokenStored;

    mapping(address => uint256) public userRewardPerTokenPaid;
    mapping(address => uint256) public rewards;
    mapping(address => uint256) public balances;

    uint256 public totalSupply;

    modifier updateReward(address account) {
        rewardPerTokenStored = rewardPerToken();
        lastUpdateTime = block.timestamp;
        if (account != address(0)) {
            rewards[account] = earned(account);
            userRewardPerTokenPaid[account] = rewardPerTokenStored;
        }
        _;
    }

    function rewardPerToken() public view returns (uint256) {
        if (totalSupply == 0) return rewardPerTokenStored;
        return rewardPerTokenStored + (
            (block.timestamp - lastUpdateTime) * rewardRate * 1e18 / totalSupply
        );
    }

    function earned(address account) public view returns (uint256) {
        return (
            balances[account] * (rewardPerToken() - userRewardPerTokenPaid[account]) / 1e18
        ) + rewards[account];
    }

    function stake(uint256 amount) external updateReward(msg.sender) {
        totalSupply += amount;
        balances[msg.sender] += amount;
        lpToken.transferFrom(msg.sender, address(this), amount);
        emit Staked(msg.sender, amount);
    }

    function withdraw(uint256 amount) external updateReward(msg.sender) {
        totalSupply -= amount;
        balances[msg.sender] -= amount;
        lpToken.transfer(msg.sender, amount);
        emit Withdrawn(msg.sender, amount);
    }

    function getReward() external updateReward(msg.sender) {
        uint256 reward = rewards[msg.sender];
        if (reward > 0) {
            rewards[msg.sender] = 0;
            edgToken.transfer(msg.sender, reward);
            emit RewardPaid(msg.sender, reward);
        }
    }

    event Staked(address indexed user, uint256 amount);
    event Withdrawn(address indexed user, uint256 amount);
    event RewardPaid(address indexed user, uint256 reward);
}
```

---

### 2.7 Token Integration Points

#### 2.7.1 Integration with Existing Voting System

```typescript
// src/lib/services/proposal/token-weighted-voting.service.ts
interface TokenWeightedVote {
  proposalId: string;
  voterId: string;
  choice: 'for' | 'against' | 'abstain';
  votingPower: bigint;
  tokenType: 'edg' | 'teq' | 'both';
  timestamp: Timestamp;
}

class TokenWeightedVotingService {
  // Update existing VotingEngineService to support token weights
  async castTokenWeightedVote(
    proposalId: string,
    voterId: string,
    choice: 'for' | 'against' | 'abstain'
  ): Promise<TokenWeightedVote> {
    const proposal = await this.proposalRepository.findById(proposalId);

    // Get voting power based on proposal type
    let votingPower: bigint;
    if (proposal.type === 'protocol_governance') {
      // Protocol governance uses EDG
      votingPower = await this.votingPowerService
        .calculateVotingPower(voterId)
        .then((r) => r.totalVotingPower);
    } else if (proposal.type === 'dao_internal') {
      // Internal DAO governance uses TEQ or equal weight
      const dao = await this.daoRepository.findById(proposal.daoId);
      if (dao.votingSystem === 'token_weighted') {
        votingPower = await this.teqContract.balanceOf(
          await this.walletService.getUserWallet(voterId)
        );
      } else {
        votingPower = 1n; // Equal weight
      }
    }

    const vote: TokenWeightedVote = {
      proposalId,
      voterId,
      choice,
      votingPower,
      tokenType: proposal.type === 'protocol_governance' ? 'edg' : 'teq',
      timestamp: Timestamp.now(),
    };

    await this.voteRepository.save(vote);

    // Update proposal vote tallies
    await this.updateProposalTallies(proposalId, choice, votingPower);

    return vote;
  }

  private async updateProposalTallies(
    proposalId: string,
    choice: string,
    power: bigint
  ): Promise<void> {
    await runTransaction(db, async (transaction) => {
      const proposalRef = doc(db, 'proposals', proposalId);
      const proposal = await transaction.get(proposalRef);

      const tallies = proposal.data()?.tokenWeightedTallies || {
        for: '0',
        against: '0',
        abstain: '0',
        totalPower: '0',
      };

      tallies[choice] = (BigInt(tallies[choice]) + power).toString();
      tallies.totalPower = (BigInt(tallies.totalPower) + power).toString();

      transaction.update(proposalRef, { tokenWeightedTallies: tallies });
    });
  }
}
```

#### 2.7.2 Integration with FeeRouter

```solidity
// contracts/FeeRouterV2.sol
contract FeeRouterV2 is FeeRouter {
    EDGVault public edgVault;
    TCR public tcrToken;

    // Override fee calculation to include EDG discounts
    function calculateFee(
        address payer,
        uint256 amount,
        uint256 baseFeeBps
    ) public view returns (uint256 fee, uint256 discount) {
        uint256 discountTier = edgVault.getDiscountTier(payer);

        // Gold: 100% discount, Silver: 50% discount
        uint256 discountedFeeBps = baseFeeBps * (100 - discountTier) / 100;
        fee = (amount * discountedFeeBps) / 10000;
        discount = (amount * baseFeeBps / 10000) - fee;

        return (fee, discount);
    }

    function routeContribution(
        address daoSafe,
        address contributor
    ) external payable override {
        require(msg.value > 0, "No value sent");

        (uint256 fee, uint256 discount) = calculateFee(
            contributor,
            msg.value,
            contributionFeeBps
        );

        uint256 daoAmount = msg.value - fee;

        // Send to DAO
        (bool daoSuccess, ) = daoSafe.call{value: daoAmount}("");
        require(daoSuccess, "DAO transfer failed");

        // Send fee to protocol treasury
        if (fee > 0) {
            (bool feeSuccess, ) = revenueSafe.call{value: fee}("");
            require(feeSuccess, "Fee transfer failed");
        }

        emit ContributionRouted(
            contributor,
            daoSafe,
            msg.value,
            daoAmount,
            fee,
            discount
        );
    }

    event ContributionRouted(
        address indexed contributor,
        address indexed daoSafe,
        uint256 totalAmount,
        uint256 daoAmount,
        uint256 fee,
        uint256 discount
    );
}
```

#### 2.7.3 Integration with Member Profiles

```typescript
// src/types/user.ts - Extended for tokens
interface UserProfile {
  // Existing fields...
  uid: string;
  displayName?: string;
  avatar?: string;
  bio?: string;

  // Token integration fields
  walletAddresses: {
    primary: string; // Main wallet for token holdings
    privy?: string; // Privy embedded wallet
    external?: string[]; // Additional connected wallets
  };

  tokenBalances?: {
    edg: string; // Cached EDG balance
    teq: string; // Cached TEQ balance
    tcr: string; // Cached TCR balance
    lastUpdated: Timestamp;
  };

  vestingSchedules?: {
    edg?: {
      totalAmount: string;
      vestedAmount: string;
      nextVestDate: Timestamp;
    };
  };

  laborStats?: {
    totalHoursWorked: number;
    totalTCREarned: string;
    totalTEQEarned: string;
    averageHourlyRate: number;
    jobTypes: Record<number, number>; // jobTypeId -> hours
  };
}
```

---

## 3. Treasury Tier System

### Tier Overview

| Tier | Name        | Treasury Mode        | Spending Limits   | Target User              |
| ---- | ----------- | -------------------- | ----------------- | ------------------------ |
| 1    | Starter     | Disabled/Tracking    | N/A               | Community orgs, new DAOs |
| 2    | Growing     | Simple Safe (2-of-3) | App-layer only    | Small businesses         |
| 3    | Established | Safe + Ops Wallet    | On-chain (Zodiac) | Established nonprofits   |
| 4    | Enterprise  | Sub-DAOs + Dashboard | Full hierarchy    | Networks, federations    |

### 3.1 Tier 1: Starter (Disabled)

**Implementation**:

```typescript
// src/types/dao.ts - Update DAO interface
interface DAO {
  // ... existing fields

  // Treasury Tier System
  treasuryTier: 1 | 2 | 3 | 4;
  treasuryMode: 'disabled' | 'tracking' | 'safe';

  // Tier 1 specific
  trackingLedger?: {
    entries: LedgerEntry[];
    totalIn: number;
    totalOut: number;
  };
}

interface LedgerEntry {
  id: string;
  date: Timestamp;
  description: string;
  amount: number;
  category: 'income' | 'expense';
  attachments?: string[];
  createdBy: string;
}
```

**UI Requirements**:

- Simple income/expense tracking
- No blockchain integration
- Export to CSV/PDF for tax purposes
- "Upgrade to Safe" CTA when first funding proposal created

**Upgrade Trigger**:

```typescript
// src/lib/services/treasury/tier-upgrade.service.ts
async function checkTierUpgrade(
  daoId: string,
  proposalType: string
): Promise<void> {
  if (proposalType === 'funding') {
    const dao = await daoRepository.findById(daoId);
    if (dao.treasuryTier === 1) {
      // Prompt user to upgrade to Tier 2
      await notificationService.sendUpgradePrompt(daoId, {
        currentTier: 1,
        suggestedTier: 2,
        reason: 'First funding proposal requires treasury',
      });
    }
  }
}
```

---

### 3.2 Tier 2: Growing (Simple Safe)

**What Exists**: Full Safe integration is already implemented.

**What's Missing**: Clear tier designation in DAO creation flow.

**Implementation**:

```typescript
// src/app/dao/new/page.tsx - Update creation flow
const tierOptions = [
  {
    tier: 1,
    name: 'Starter',
    description: 'Track finances without blockchain',
    features: [
      'Income/expense tracking',
      'Export reports',
      'No crypto required',
    ],
    recommended: daoType === 'community',
  },
  {
    tier: 2,
    name: 'Growing',
    description: 'Secure multi-sig treasury',
    features: ['Gnosis Safe vault', '2-of-3 signing', 'On-chain transactions'],
    recommended: daoType === 'commerce',
  },
];
```

**Safe Configuration (Existing)**:

- 2-of-3 default threshold
- Automatic Safe deployment on tier selection
- Gasless deployment via Biconomy

---

### 3.3 Tier 3: Established (Ops Wallet)

**Architecture**:

```
┌─────────────────────────────────────────────┐
│           Main Safe (Vault)                 │
│     Requires full governance proposal       │
│     Balance: Majority of funds              │
└──────────────────┬──────────────────────────┘
                   │
                   │ Periodic refill via proposal
                   ▼
┌─────────────────────────────────────────────┐
│           Ops Wallet (Quick Spend)          │
│  • maxDailySpend: $1,000                    │
│  • maxSingleTransaction: $500               │
│  • requiresApprovalAbove: $250              │
│  • Single-signer (treasurer role)           │
└─────────────────────────────────────────────┘
```

**Phase 1: App-Layer Enforcement (MVP)**:

```typescript
// src/lib/services/treasury/ops-wallet.service.ts
interface OpsWalletConfig {
  mainSafeAddress: string;
  opsWalletAddress: string;
  maxDailySpend: number; // in USD
  maxSingleTransaction: number; // in USD
  requiresApprovalAbove: number; // in USD
  treasurerUserIds: string[]; // Single-signers
  refillThreshold: number; // Auto-request refill when balance below this
}

class OpsWalletService {
  async validateTransaction(
    daoId: string,
    amount: number,
    treasurerId: string
  ): Promise<ValidationResult> {
    const config = await this.getConfig(daoId);

    // Check single transaction limit
    if (amount > config.maxSingleTransaction) {
      return { valid: false, reason: 'Exceeds single transaction limit' };
    }

    // Check daily spend
    const todaySpend = await this.getDailySpend(daoId);
    if (todaySpend + amount > config.maxDailySpend) {
      return { valid: false, reason: 'Exceeds daily spend limit' };
    }

    // Check if requires additional approval
    if (amount > config.requiresApprovalAbove) {
      return { valid: true, requiresApproval: true };
    }

    return { valid: true, requiresApproval: false };
  }

  async executeOpsTransaction(
    daoId: string,
    recipient: string,
    amount: number,
    treasurerId: string
  ): Promise<TransactionResult> {
    const validation = await this.validateTransaction(
      daoId,
      amount,
      treasurerId
    );

    if (!validation.valid) {
      throw new Error(validation.reason);
    }

    if (validation.requiresApproval) {
      // Create approval request, notify other treasurer
      return this.createApprovalRequest(daoId, recipient, amount, treasurerId);
    }

    // Execute directly via ops wallet Safe
    return this.executeDirectly(daoId, recipient, amount);
  }
}
```

**Phase 2: On-Chain Enforcement (Zodiac Modules)**:

```solidity
// contracts/SpendingLimitsModule.sol
// Zodiac module for on-chain spending limit enforcement

import "@gnosis.pm/zodiac/contracts/core/Module.sol";

contract SpendingLimitsModule is Module {
    struct SpendingConfig {
        uint256 maxDailySpend;           // In wei or token units
        uint256 maxSingleTransaction;
        uint256 requiresApprovalAbove;
        address[] approvers;
        uint256 approvalThreshold;
    }

    struct DailyUsage {
        uint256 amount;
        uint256 resetTimestamp;
    }

    mapping(address => SpendingConfig) public configs;  // token => config
    mapping(address => DailyUsage) public dailyUsage;   // token => usage

    function setUp(bytes memory initParams) public override {
        __Ownable_init();
        (address _owner, address _avatar, address _target) = abi.decode(
            initParams,
            (address, address, address)
        );
        setAvatar(_avatar);
        setTarget(_target);
        transferOwnership(_owner);
    }

    function executeTransaction(
        address to,
        uint256 value,
        bytes calldata data,
        Enum.Operation operation,
        address token
    ) external returns (bool success) {
        SpendingConfig storage config = configs[token];

        // Reset daily usage if new day
        if (block.timestamp >= dailyUsage[token].resetTimestamp + 1 days) {
            dailyUsage[token] = DailyUsage({
                amount: 0,
                resetTimestamp: block.timestamp
            });
        }

        uint256 amount = token == address(0) ? value : _extractAmount(data);

        // Check single transaction limit
        require(
            amount <= config.maxSingleTransaction,
            "Exceeds single transaction limit"
        );

        // Check daily limit
        require(
            dailyUsage[token].amount + amount <= config.maxDailySpend,
            "Exceeds daily spend limit"
        );

        // Update daily usage
        dailyUsage[token].amount += amount;

        // If above approval threshold, require multi-sig approval
        if (amount > config.requiresApprovalAbove) {
            require(
                _hasApproval(msg.sender, config),
                "Requires additional approval"
            );
        }

        // Execute via Safe
        success = exec(to, value, data, operation);
        require(success, "Module transaction failed");

        emit TransactionExecuted(to, value, token, amount);
    }

    event TransactionExecuted(address to, uint256 value, address token, uint256 amount);
}
```

---

### 3.4 Tier 4: Enterprise (Sub-DAOs)

See Section 5 for Sub-DAO architecture.

---

### 3.5 Treasury UX Flows

#### 3.5.1 Ops Wallet Transaction Flow

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        OPS WALLET TRANSACTION FLOW                        │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  1. INITIATION                                                            │
│  ┌─────────────────┐                                                      │
│  │   Treasurer     │──▶ Clicks "New Payment" in Ops Wallet                │
│  │   (Single-sig)  │                                                      │
│  └─────────────────┘                                                      │
│                                                                           │
│  2. VALIDATION                                                            │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │  System checks:                                                   │     │
│  │  ├── Single transaction limit ($500)        ✓ Pass / ✗ Block     │     │
│  │  ├── Daily spend limit ($1,000)             ✓ Pass / ✗ Block     │     │
│  │  ├── Recipient whitelist                    ✓ Pass / ⚠ Warn      │     │
│  │  └── Approval threshold ($250)              ✓ Auto / ⚠ Approval  │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
│  3a. AUTO-APPROVED (< $250)                                               │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │  ┌───────────┐    ┌────────────┐    ┌────────────┐              │     │
│  │  │ Treasurer │───▶│   Sign     │───▶│  Execute   │───▶ Done    │     │
│  │  │  clicks   │    │  (Privy)   │    │  (Safe)    │              │     │
│  │  └───────────┘    └────────────┘    └────────────┘              │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
│  3b. REQUIRES APPROVAL (> $250)                                           │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │  ┌───────────┐    ┌────────────┐    ┌────────────┐    ┌──────┐ │     │
│  │  │ Treasurer │───▶│  Request   │───▶│  Approver  │───▶│ Sign │ │     │
│  │  │  creates  │    │   sent     │    │  reviews   │    │ both │ │     │
│  │  └───────────┘    └────────────┘    └────────────┘    └──────┘ │     │
│  │                         │                                       │     │
│  │                         ▼                                       │     │
│  │               ┌──────────────────┐                              │     │
│  │               │ Email/Push/App   │                              │     │
│  │               │  notification    │                              │     │
│  │               └──────────────────┘                              │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
│  4. LEDGER RECORDING                                                      │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │  • Transaction hash recorded                                     │     │
│  │  • Category auto-assigned (or selected)                          │     │
│  │  • Receipt/invoice attached (optional)                           │     │
│  │  • Synced to accounting integration (if configured)              │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
└──────────────────────────────────────────────────────────────────────────┘
```

#### 3.5.2 Main Safe (Vault) Transaction Flow

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        MAIN SAFE TRANSACTION FLOW                         │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  1. PROPOSAL CREATION                                                     │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │  Admin creates "Funding Proposal"                                │     │
│  │  ├── Title: "Q1 Marketing Budget"                                │     │
│  │  ├── Amount: $10,000 USDC                                        │     │
│  │  ├── Recipient: 0x...marketing-agency                            │     │
│  │  ├── Category: Marketing                                         │     │
│  │  └── Attachments: contract.pdf, invoice.pdf                      │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
│  2. GOVERNANCE VOTING                                                     │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │           ┌──────────────────────────────────────┐              │     │
│  │           │         VOTING PERIOD (7 days)        │              │     │
│  │           ├──────────────────────────────────────┤              │     │
│  │           │  For: ████████████████░░░░ 72%       │              │     │
│  │           │  Against: ████░░░░░░░░░░░░░ 18%      │              │     │
│  │           │  Abstain: ██░░░░░░░░░░░░░░░ 10%      │              │     │
│  │           ├──────────────────────────────────────┤              │     │
│  │           │  Quorum: 42% (min 30%)      ✓        │              │     │
│  │           │  Pass Threshold: 51%        ✓        │              │     │
│  │           └──────────────────────────────────────┘              │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
│  3. MULTI-SIG EXECUTION                                                   │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │                                                                   │     │
│  │  Safe Threshold: 2 of 3 signers                                  │     │
│  │                                                                   │     │
│  │  ┌─────────┐   ┌─────────┐   ┌─────────┐                        │     │
│  │  │ Signer1 │   │ Signer2 │   │ Signer3 │                        │     │
│  │  │   ✓     │   │   ✓     │   │   -     │                        │     │
│  │  └─────────┘   └─────────┘   └─────────┘                        │     │
│  │       │             │                                            │     │
│  │       ▼             ▼                                            │     │
│  │  ┌──────────────────────────────────────┐                       │     │
│  │  │  Transaction submitted to Safe API   │                       │     │
│  │  │  Waiting for confirmations...        │                       │     │
│  │  └──────────────────────────────────────┘                       │     │
│  │                                                                   │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
│  4. ON-CHAIN EXECUTION                                                    │
│  ┌─────────────────────────────────────────────────────────────────┐     │
│  │  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐       │     │
│  │  │ Gas estimate │───▶│ Biconomy MEE │───▶│  Broadcast   │       │     │
│  │  │   check      │    │  (gasless)   │    │  to Base     │       │     │
│  │  └──────────────┘    └──────────────┘    └──────────────┘       │     │
│  │                              │                                   │     │
│  │                              ▼                                   │     │
│  │                    ┌──────────────────┐                         │     │
│  │                    │ If gasless fails │                         │     │
│  │                    │ ──▶ Traditional  │                         │     │
│  │                    │     Safe exec    │                         │     │
│  │                    └──────────────────┘                         │     │
│  └─────────────────────────────────────────────────────────────────┘     │
│                                                                           │
└──────────────────────────────────────────────────────────────────────────┘
```

#### 3.5.3 Refill Flow (Vault → Ops Wallet)

```typescript
// src/lib/services/treasury/ops-refill.service.ts
interface RefillRequest {
  id: string;
  daoId: string;
  opsWalletAddress: string;
  requestedAmount: number;
  currentBalance: number;
  threshold: number;
  status: 'pending' | 'proposed' | 'approved' | 'executed' | 'rejected';
  proposalId?: string;
  createdAt: Timestamp;
  executedAt?: Timestamp;
}

class OpsRefillService {
  async checkRefillNeeded(daoId: string): Promise<boolean> {
    const config = await this.getOpsWalletConfig(daoId);
    const balance = await this.getOpsWalletBalance(config.opsWalletAddress);

    return balance < config.refillThreshold;
  }

  async initiateRefill(daoId: string): Promise<RefillRequest> {
    const config = await this.getOpsWalletConfig(daoId);
    const currentBalance = await this.getOpsWalletBalance(
      config.opsWalletAddress
    );

    // Calculate refill amount (bring back to max daily spend * 7 days)
    const targetBalance = config.maxDailySpend * 7;
    const refillAmount = targetBalance - currentBalance;

    // Create refill request
    const request: RefillRequest = {
      id: generateId(),
      daoId,
      opsWalletAddress: config.opsWalletAddress,
      requestedAmount: refillAmount,
      currentBalance,
      threshold: config.refillThreshold,
      status: 'pending',
      createdAt: Timestamp.now(),
    };

    await this.saveRefillRequest(request);

    // Auto-create funding proposal
    const proposal = await this.proposalService.create({
      daoId,
      type: 'funding',
      title: `Ops Wallet Refill: $${refillAmount.toLocaleString()}`,
      description: `Automatic refill request. Current balance: $${currentBalance.toLocaleString()}, Target: $${targetBalance.toLocaleString()}`,
      amount: refillAmount,
      recipientAddress: config.opsWalletAddress,
      metadata: {
        refillRequestId: request.id,
        autoGenerated: true,
      },
    });

    request.proposalId = proposal.id;
    request.status = 'proposed';
    await this.saveRefillRequest(request);

    // Notify treasurers
    await this.notificationService.notifyTreasurers(daoId, {
      type: 'ops_refill_needed',
      requestId: request.id,
      amount: refillAmount,
    });

    return request;
  }

  // Scheduled job to check all Ops Wallets
  async runRefillCheck(): Promise<void> {
    const daosWithOpsWallet = await this.daoRepository.findWithOpsWallet();

    for (const dao of daosWithOpsWallet) {
      const needsRefill = await this.checkRefillNeeded(dao.id);

      if (needsRefill) {
        const existingRequest = await this.getPendingRefillRequest(dao.id);

        if (!existingRequest) {
          await this.initiateRefill(dao.id);
        }
      }
    }
  }
}
```

---

### 3.6 Multi-Currency Handling

#### 3.6.1 Supported Assets

| Asset | Type   | Network | Oracle          | Use Case           |
| ----- | ------ | ------- | --------------- | ------------------ |
| ETH   | Native | Base    | Chainlink       | Gas, contributions |
| USDC  | ERC-20 | Base    | 1:1 USD         | Treasury, payments |
| USDT  | ERC-20 | Base    | 1:1 USD         | Treasury           |
| TCR   | ERC-20 | Base    | 1:1 USD         | Labor marketplace  |
| EDG   | ERC-20 | Base    | Market          | Governance         |
| TEQ   | ERC-20 | Base    | N/A (soulbound) | Equity             |

#### 3.6.2 Multi-Asset Treasury Service

```typescript
// src/lib/services/treasury/multi-asset.service.ts
interface TreasuryBalance {
  token: string;
  symbol: string;
  balance: string;
  decimals: number;
  usdValue: number;
  percentage: number;
}

interface TreasuryPortfolio {
  daoId: string;
  safeAddress: string;
  totalUsdValue: number;
  balances: TreasuryBalance[];
  lastUpdated: Timestamp;
}

class MultiAssetTreasuryService {
  private supportedTokens = [
    {
      address: '0x0000000000000000000000000000000000000000',
      symbol: 'ETH',
      decimals: 18,
    },
    {
      address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
      symbol: 'USDC',
      decimals: 6,
    },
    {
      address: '0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2',
      symbol: 'USDT',
      decimals: 6,
    },
    // TCR, EDG addresses added at deployment
  ];

  async getPortfolio(daoId: string): Promise<TreasuryPortfolio> {
    const dao = await this.daoRepository.findById(daoId);
    const safeAddress = dao.treasury?.safeAddress;

    if (!safeAddress) {
      throw new Error('No treasury configured');
    }

    // Fetch balances in parallel
    const balancePromises = this.supportedTokens.map(async (token) => {
      const balance = await this.getTokenBalance(safeAddress, token.address);
      const usdValue = await this.getUsdValue(
        token.symbol,
        balance,
        token.decimals
      );

      return {
        token: token.address,
        symbol: token.symbol,
        balance: balance.toString(),
        decimals: token.decimals,
        usdValue,
      };
    });

    const balances = await Promise.all(balancePromises);
    const totalUsdValue = balances.reduce((sum, b) => sum + b.usdValue, 0);

    // Calculate percentages
    const withPercentages = balances.map((b) => ({
      ...b,
      percentage: totalUsdValue > 0 ? (b.usdValue / totalUsdValue) * 100 : 0,
    }));

    return {
      daoId,
      safeAddress,
      totalUsdValue,
      balances: withPercentages.filter((b) => b.usdValue > 0),
      lastUpdated: Timestamp.now(),
    };
  }

  async executeMultiAssetTransfer(
    daoId: string,
    transfers: Array<{
      token: string;
      recipient: string;
      amount: string;
    }>
  ): Promise<string> {
    const dao = await this.daoRepository.findById(daoId);
    const safeAddress = dao.treasury?.safeAddress;

    // Build batch transaction
    const transactions = transfers.map((t) => ({
      to: t.token === 'ETH' ? t.recipient : t.token,
      value: t.token === 'ETH' ? t.amount : '0',
      data:
        t.token === 'ETH'
          ? '0x'
          : this.encodeERC20Transfer(t.recipient, t.amount),
    }));

    // Execute via Safe with MEE batching
    const result = await this.treasuryExecutionOrchestrator.executeBatch(
      safeAddress,
      transactions
    );

    return result.txHash;
  }

  private async getUsdValue(
    symbol: string,
    balance: bigint,
    decimals: number
  ): Promise<number> {
    // Stablecoins: 1:1
    if (['USDC', 'USDT', 'TCR'].includes(symbol)) {
      return Number(balance) / Math.pow(10, decimals);
    }

    // ETH: Use Chainlink oracle
    if (symbol === 'ETH') {
      const ethPrice = await this.priceOracle.getEthPrice();
      return (Number(balance) / 1e18) * ethPrice;
    }

    // EDG: Use DEX TWAP
    if (symbol === 'EDG') {
      const edgPrice = await this.priceOracle.getEdgPrice();
      return (Number(balance) / 1e18) * edgPrice;
    }

    return 0;
  }
}
```

#### 3.6.3 Currency Conversion Service

```typescript
// src/lib/services/treasury/currency-conversion.service.ts
interface SwapQuote {
  inputToken: string;
  outputToken: string;
  inputAmount: string;
  outputAmount: string;
  priceImpact: number;
  route: string[];
  expiresAt: Timestamp;
}

class CurrencyConversionService {
  // Integration with Aerodrome (Base DEX)
  async getSwapQuote(
    inputToken: string,
    outputToken: string,
    inputAmount: string
  ): Promise<SwapQuote> {
    // Use 0x API or Aerodrome directly
    const quote = await this.aggregator.getQuote({
      sellToken: inputToken,
      buyToken: outputToken,
      sellAmount: inputAmount,
      slippagePercentage: 0.5,
    });

    return {
      inputToken,
      outputToken,
      inputAmount,
      outputAmount: quote.buyAmount,
      priceImpact: quote.estimatedPriceImpact,
      route: quote.route,
      expiresAt: Timestamp.fromMillis(Date.now() + 30000), // 30 seconds
    };
  }

  async executeSwap(daoId: string, quote: SwapQuote): Promise<string> {
    // Verify quote hasn't expired
    if (Date.now() > quote.expiresAt.toMillis()) {
      throw new Error('Quote expired');
    }

    // Execute swap via Safe
    const dao = await this.daoRepository.findById(daoId);
    const safeAddress = dao.treasury?.safeAddress;

    // Approve if needed
    if (quote.inputToken !== 'ETH') {
      await this.ensureApproval(
        safeAddress,
        quote.inputToken,
        quote.inputAmount
      );
    }

    // Execute swap transaction
    const txHash = await this.treasuryExecutionOrchestrator.execute(
      safeAddress,
      {
        to: this.aggregatorAddress,
        value: quote.inputToken === 'ETH' ? quote.inputAmount : '0',
        data: this.encodeSwap(quote),
      }
    );

    // Record in ledger
    await this.ledgerService.recordSwap({
      daoId,
      txHash,
      inputToken: quote.inputToken,
      inputAmount: quote.inputAmount,
      outputToken: quote.outputToken,
      outputAmount: quote.outputAmount,
    });

    return txHash;
  }
}
```

---

### 3.7 Accounting Integrations

#### 3.7.1 QuickBooks Integration

```typescript
// src/lib/services/integrations/quickbooks.service.ts
interface QuickBooksConfig {
  daoId: string;
  realmId: string;
  accessToken: string;
  refreshToken: string;
  tokenExpiry: Timestamp;
  syncEnabled: boolean;
  lastSyncAt?: Timestamp;
  accountMappings: {
    treasuryAccount: string; // QB Account ID for treasury
    expenseAccount: string; // QB Account ID for expenses
    incomeAccount: string; // QB Account ID for income
    equityAccount: string; // QB Account ID for member equity
  };
}

class QuickBooksIntegrationService {
  async syncTransactions(daoId: string): Promise<SyncResult> {
    const config = await this.getConfig(daoId);

    if (!config.syncEnabled) {
      throw new Error('QuickBooks sync not enabled');
    }

    // Refresh token if needed
    await this.ensureValidToken(config);

    // Get transactions since last sync
    const transactions = await this.ledgerService.getTransactionsSince(
      daoId,
      config.lastSyncAt || new Date(0)
    );

    const results: SyncResult = {
      synced: 0,
      failed: 0,
      errors: [],
    };

    for (const tx of transactions) {
      try {
        await this.createQuickBooksEntry(config, tx);
        results.synced++;
      } catch (error) {
        results.failed++;
        results.errors.push({
          transactionId: tx.id,
          error: error.message,
        });
      }
    }

    // Update last sync time
    config.lastSyncAt = Timestamp.now();
    await this.saveConfig(config);

    return results;
  }

  private async createQuickBooksEntry(
    config: QuickBooksConfig,
    tx: LedgerTransaction
  ): Promise<void> {
    const qb = this.getQBClient(config);

    if (tx.type === 'expense' || tx.type === 'transfer_out') {
      // Create expense entry
      await qb.createExpense({
        AccountRef: { value: config.accountMappings.expenseAccount },
        PaymentType: 'Cash',
        TotalAmt: tx.usdValue,
        TxnDate: tx.timestamp.toDate().toISOString().split('T')[0],
        Line: [
          {
            DetailType: 'AccountBasedExpenseLineDetail',
            Amount: tx.usdValue,
            AccountBasedExpenseLineDetail: {
              AccountRef: { value: config.accountMappings.expenseAccount },
            },
            Description: tx.description,
          },
        ],
        PrivateNote: `EnDAO Tx: ${tx.txHash}`,
      });
    } else if (tx.type === 'income' || tx.type === 'transfer_in') {
      // Create sales receipt
      await qb.createSalesReceipt({
        DepositToAccountRef: { value: config.accountMappings.treasuryAccount },
        TotalAmt: tx.usdValue,
        TxnDate: tx.timestamp.toDate().toISOString().split('T')[0],
        Line: [
          {
            DetailType: 'SalesItemLineDetail',
            Amount: tx.usdValue,
            SalesItemLineDetail: {
              ItemRef: { value: 'contribution' },
            },
            Description: tx.description,
          },
        ],
        PrivateNote: `EnDAO Tx: ${tx.txHash}`,
      });
    }
  }

  async generateFinancialReport(
    daoId: string,
    startDate: Date,
    endDate: Date,
    reportType: 'profit_loss' | 'balance_sheet' | 'cash_flow'
  ): Promise<FinancialReport> {
    const config = await this.getConfig(daoId);
    const qb = this.getQBClient(config);

    const report = await qb.getReport(reportType, {
      start_date: startDate.toISOString().split('T')[0],
      end_date: endDate.toISOString().split('T')[0],
    });

    return this.transformQBReport(report);
  }
}
```

#### 3.7.2 Export Formats

```typescript
// src/lib/services/export/treasury-export.service.ts
interface ExportOptions {
  daoId: string;
  startDate: Date;
  endDate: Date;
  format: 'csv' | 'pdf' | 'json' | 'quickbooks' | 'xero';
  includeAttachments: boolean;
  categories?: string[];
}

class TreasuryExportService {
  async exportTransactions(options: ExportOptions): Promise<ExportResult> {
    const transactions = await this.ledgerService.getTransactions({
      daoId: options.daoId,
      startDate: options.startDate,
      endDate: options.endDate,
      categories: options.categories,
    });

    switch (options.format) {
      case 'csv':
        return this.exportCSV(transactions, options);
      case 'pdf':
        return this.exportPDF(transactions, options);
      case 'json':
        return this.exportJSON(transactions, options);
      case 'quickbooks':
        return this.exportQuickBooksIIF(transactions, options);
      case 'xero':
        return this.exportXeroCSV(transactions, options);
    }
  }

  private async exportCSV(
    transactions: LedgerTransaction[],
    options: ExportOptions
  ): Promise<ExportResult> {
    const headers = [
      'Date',
      'Type',
      'Description',
      'Category',
      'Amount (USD)',
      'Token',
      'Token Amount',
      'From',
      'To',
      'Transaction Hash',
      'Status',
    ];

    const rows = transactions.map((tx) => [
      tx.timestamp.toDate().toISOString(),
      tx.type,
      tx.description,
      tx.category,
      tx.usdValue.toFixed(2),
      tx.token,
      tx.amount,
      tx.from,
      tx.to,
      tx.txHash,
      tx.status,
    ]);

    const csv = [headers, ...rows]
      .map((row) => row.map((cell) => `"${cell}"`).join(','))
      .join('\n');

    return {
      format: 'csv',
      filename: `treasury-${options.daoId}-${Date.now()}.csv`,
      content: Buffer.from(csv),
      mimeType: 'text/csv',
    };
  }

  private async exportPDF(
    transactions: LedgerTransaction[],
    options: ExportOptions
  ): Promise<ExportResult> {
    const dao = await this.daoRepository.findById(options.daoId);

    // Use Puppeteer to generate PDF
    const html = await this.renderReportTemplate({
      dao,
      transactions,
      startDate: options.startDate,
      endDate: options.endDate,
      summary: this.calculateSummary(transactions),
    });

    const pdf = await this.puppeteer.generatePDF(html);

    return {
      format: 'pdf',
      filename: `treasury-report-${options.daoId}-${Date.now()}.pdf`,
      content: pdf,
      mimeType: 'application/pdf',
    };
  }

  private calculateSummary(transactions: LedgerTransaction[]): TreasurySummary {
    return {
      totalIncome: transactions
        .filter((t) => t.type === 'income' || t.type === 'transfer_in')
        .reduce((sum, t) => sum + t.usdValue, 0),
      totalExpenses: transactions
        .filter((t) => t.type === 'expense' || t.type === 'transfer_out')
        .reduce((sum, t) => sum + t.usdValue, 0),
      netChange: 0, // Calculated from above
      byCategory: {}, // Group by category
      byMonth: {}, // Group by month
    };
  }
}
```

---

## 4. Commerce vs Community DAOs

### Default Configuration Matrix

| Setting             | Commerce DAO        | Community DAO |
| ------------------- | ------------------- | ------------- |
| `treasuryTier`      | 2 (Safe from day 1) | 1 (Disabled)  |
| `treasuryMode`      | `'safe'`            | `'disabled'`  |
| `votingQuorum`      | 30%                 | 15%           |
| `passThreshold`     | 51%                 | 51%           |
| `governanceStyle`   | `'proposal'`        | `'consent'`   |
| `opsWalletPriority` | High                | Low           |
| `memberInviteFlow`  | Open + approval     | Invite-only   |

### 4.1 DAO Type Selection (Onboarding)

```typescript
// src/app/dao/new/components/dao-type-selector.tsx
const daoTypes = [
  {
    type: 'commerce',
    title: 'Commerce DAO',
    description: 'For businesses, cooperatives, and revenue-focused ventures',
    icon: Building2,
    defaults: {
      treasuryTier: 2,
      treasuryMode: 'safe',
      votingQuorum: 30,
      passThreshold: 51,
      governanceStyle: 'proposal',
      suggestOpsWallet: true,
    },
    examples: [
      'Worker cooperatives',
      'Investment clubs',
      'Freelancer collectives',
    ],
  },
  {
    type: 'community',
    title: 'Community DAO',
    description: 'For nonprofits, clubs, and member-driven organizations',
    icon: Users,
    defaults: {
      treasuryTier: 1,
      treasuryMode: 'disabled',
      votingQuorum: 15,
      passThreshold: 51,
      governanceStyle: 'consent',
      suggestOpsWallet: false,
    },
    examples: ['HOAs', 'Book clubs', 'Advocacy groups', 'Alumni associations'],
  },
];
```

### 4.2 Consent-Based Governance (Community DAOs)

**Concept**: Proposals pass after X days unless Y% object. Reduces governance fatigue.

```typescript
// src/types/proposal.ts - Extend proposal types
interface ConsentProposal extends BaseProposal {
  governanceStyle: 'consent';
  passAfterDays: number; // e.g., 7 days
  objectionThreshold: number; // e.g., 10%
  currentObjections: number;
  objectors: string[];
  consentStatus: 'active' | 'passed' | 'blocked';
}

// src/lib/services/proposal/consent-governance.service.ts
class ConsentGovernanceService {
  async checkAutoPass(proposalId: string): Promise<void> {
    const proposal = await proposalRepository.findById(proposalId);

    if (proposal.governanceStyle !== 'consent') return;

    const daysSinceCreation = this.getDaysSince(proposal.createdAt);
    const objectionRate =
      proposal.currentObjections / proposal.totalEligibleMembers;

    // Auto-pass if time elapsed and objection threshold not met
    if (daysSinceCreation >= proposal.passAfterDays) {
      if (objectionRate < proposal.objectionThreshold / 100) {
        await this.passProposal(proposalId);
      } else {
        await this.blockProposal(proposalId);
      }
    }
  }

  async registerObjection(proposalId: string, memberId: string): Promise<void> {
    const proposal = await proposalRepository.findById(proposalId);

    if (proposal.objectors.includes(memberId)) {
      throw new Error('Already objected');
    }

    await proposalRepository.update(proposalId, {
      currentObjections: proposal.currentObjections + 1,
      objectors: [...proposal.objectors, memberId],
    });

    // Check if threshold exceeded
    await this.checkAutoPass(proposalId);
  }
}
```

**UI for Consent Proposals**:

```
┌─────────────────────────────────────────────────────────────┐
│  📋 Proposal: Update Community Guidelines                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  This proposal will auto-pass in 4 days unless 10%          │
│  of members object.                                          │
│                                                              │
│  ┌────────────────────────────────────────────┐             │
│  │ ████████████░░░░░░░░░░░░░░░░░░ 3% objected │             │
│  └────────────────────────────────────────────┘             │
│                                                              │
│  [ I have concerns ] [ View details ]                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 4.3 Migration Between Types

```typescript
// src/lib/services/dao/type-migration.service.ts
class DAOTypeMigrationService {
  async migrateType(
    daoId: string,
    fromType: 'commerce' | 'community',
    toType: 'commerce' | 'community'
  ): Promise<void> {
    // Requires admin proposal
    const dao = await daoRepository.findById(daoId);

    // Get new defaults
    const newDefaults = daoTypeDefaults[toType];

    // Update DAO settings
    await daoRepository.update(daoId, {
      daoType: toType,
      // Preserve existing settings that were manually configured
      votingQuorum: dao.settings.votingQuorum || newDefaults.votingQuorum,
      passThreshold: dao.settings.passThreshold || newDefaults.passThreshold,
      governanceStyle: newDefaults.governanceStyle,
      // Treasury upgrade handled separately
    });

    await auditService.log(daoId, 'dao_type_migrated', { fromType, toType });
  }
}
```

---

## 5. Sub-DAO & DAO-to-DAO Architecture

### 5.1 Sub-DAO Hierarchy (Phase 2)

**Schema (Reserve Now)**:

```typescript
// src/types/dao.ts
interface DAO {
  // ... existing fields

  // Sub-DAO hierarchy
  parentDaoId?: string;
  childDaoIds?: string[];
  hierarchyLevel: number; // 0 = root, 1 = child, 2 = grandchild

  // Permissions from parent
  inheritedPermissions?: {
    treasuryAccess: boolean; // Can access parent treasury
    proposalCreation: boolean; // Can create proposals in parent
    memberSync: boolean; // Members auto-synced from parent
  };
}
```

**Example Hierarchy**:

```
EnDAO DUNA (Root - Level 0)
├── Regional Hub: West (Level 1)
│   ├── San Francisco Chapter (Level 2)
│   └── Los Angeles Chapter (Level 2)
├── Regional Hub: East (Level 1)
│   ├── New York Chapter (Level 2)
│   └── Boston Chapter (Level 2)
└── Working Groups (Level 1)
    ├── Treasury Committee (Level 2)
    └── Governance Committee (Level 2)
```

**UI: Sub-DAO Dashboard**:

```typescript
// src/app/dao/[id]/sub-daos/page.tsx
export default function SubDAOsPage({ params }: { params: { id: string } }) {
  const { dao } = useDAO(params.id)
  const { childDaos } = useChildDAOs(params.id)

  return (
    <div>
      <h1>Sub-Organizations</h1>

      {/* Hierarchy visualization */}
      <OrgChart data={buildHierarchy(dao, childDaos)} />

      {/* Child DAO cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {childDaos.map(child => (
          <SubDAOCard
            key={child.id}
            dao={child}
            onManage={() => router.push(`/dao/${child.id}`)}
          />
        ))}
      </div>

      {/* Create new sub-DAO */}
      <Button onClick={() => setShowCreateModal(true)}>
        Create Sub-Organization
      </Button>
    </div>
  )
}
```

### 5.2 DAO-to-DAO Relationships (Phase 3)

**Relationship Types**:

| Type         | Description         | Permissions                              |
| ------------ | ------------------- | ---------------------------------------- |
| `partner`    | Equal collaboration | Shared proposals, joint treasury actions |
| `vendor`     | Service provider    | Payment rails, SLA tracking              |
| `customer`   | Service recipient   | Invoice/payment flow                     |
| `subsidiary` | Owned child         | Full parent oversight                    |

**Schema**:

```typescript
interface DAORelationship {
  id: string;
  daoId: string;
  linkedDaoId: string;
  relationship: 'partner' | 'vendor' | 'customer' | 'subsidiary';
  since: Timestamp;
  status: 'pending' | 'active' | 'terminated';

  // Permissions granted in this relationship
  permissions: {
    sharedProposals: boolean; // Can create cross-DAO proposals
    treasuryTransfers: boolean; // Can send/receive treasury transfers
    memberVisibility: boolean; // Can see member list
    agreementEncoding: boolean; // Can create on-chain agreements
  };

  // Requires approval from both DAOs
  approvals: {
    initiator: { userId: string; approvedAt: Timestamp };
    acceptor?: { userId: string; approvedAt: Timestamp };
  };
}
```

### 5.3 DAO-to-DAO Primitives (Phase 4)

| Primitive                   | Description               | Implementation                   |
| --------------------------- | ------------------------- | -------------------------------- |
| **DAO Identity**            | Verified org in registry  | ENS subdomain + attestation      |
| **Shared Proposal**         | Both DAOs must approve    | Dual-approval flow with timelock |
| **Cross-Treasury Transfer** | Direct DAO→DAO payment    | Safe module or app-layer         |
| **Agreement Encoding**      | On-chain service contract | Smart contract template          |

**Shared Proposal Flow**:

```mermaid
sequenceDiagram
    participant DAO_A as DAO A
    participant Proposal as Shared Proposal
    participant DAO_B as DAO B

    DAO_A->>Proposal: Create shared proposal
    Proposal->>DAO_B: Notify linked DAO

    par Parallel Voting
        DAO_A->>Proposal: Members vote (passes 60%)
        DAO_B->>Proposal: Members vote (passes 55%)
    end

    Proposal->>Proposal: Check both passed
    Proposal->>DAO_A: Execute on DAO A
    Proposal->>DAO_B: Execute on DAO B
```

---

## 6. Recovery & Security

### 6.1 Current Security (Live)

| Mechanism                | Status  | Implementation                          |
| ------------------------ | ------- | --------------------------------------- |
| 3+ Safe signers          | ✅ Live | Gnosis Safe threshold                   |
| Emergency recovery       | ✅ Live | Super admin via TreasuryRecoveryService |
| 7-day grace period       | ✅ Live | DAOSoftDeleteService                    |
| Treasury freeze/unfreeze | ✅ Live | TreasuryAccessControlService            |
| 4-layer protection       | ✅ Live | Status → Freeze → Grace → Emergency     |

### 6.2 Social Recovery (MVP Blocker)

**Concept**: Member designates trusted guardians who can collectively restore access.

**Schema**:

```typescript
interface RecoveryConfig {
  daoId: string;

  // Guardians
  guardians: Array<{
    userId: string;
    email: string; // For notifications
    addedAt: Timestamp;
    recoveryWeight: number; // 1-100, typically all equal
  }>;

  // Thresholds
  recoveryThreshold: number; // Weight needed to trigger recovery (e.g., 60)
  timelockDuration: number; // Seconds before recovery executes (e.g., 7 days)

  // Active recovery requests
  pendingRecovery?: {
    initiatedBy: string;
    initiatedAt: Timestamp;
    newOwnerAddress: string;
    guardianApprovals: Array<{
      guardianId: string;
      approvedAt: Timestamp;
    }>;
    totalWeight: number;
    executesAt: Timestamp;
    status: 'pending' | 'approved' | 'cancelled' | 'executed';
  };
}
```

**Flow**:

```typescript
// src/lib/services/recovery/social-recovery.service.ts
class SocialRecoveryService {
  async initiateRecovery(
    daoId: string,
    requesterId: string,
    newOwnerAddress: string
  ): Promise<RecoveryRequest> {
    const config = await this.getConfig(daoId);

    // Validate requester is a guardian
    const guardian = config.guardians.find((g) => g.userId === requesterId);
    if (!guardian) throw new Error('Not a guardian');

    // Create pending recovery
    const request: PendingRecovery = {
      initiatedBy: requesterId,
      initiatedAt: Timestamp.now(),
      newOwnerAddress,
      guardianApprovals: [
        {
          guardianId: requesterId,
          approvedAt: Timestamp.now(),
        },
      ],
      totalWeight: guardian.recoveryWeight,
      executesAt: Timestamp.fromMillis(
        Date.now() + config.timelockDuration * 1000
      ),
      status: 'pending',
    };

    await this.saveRecovery(daoId, request);

    // Notify all other guardians
    await this.notifyGuardians(daoId, config.guardians, request);

    // Notify current DAO admins (they can cancel)
    await this.notifyAdmins(daoId, request);

    return request;
  }

  async approveRecovery(daoId: string, guardianId: string): Promise<void> {
    const config = await this.getConfig(daoId);
    const pending = config.pendingRecovery;

    if (!pending || pending.status !== 'pending') {
      throw new Error('No pending recovery');
    }

    const guardian = config.guardians.find((g) => g.userId === guardianId);
    if (!guardian) throw new Error('Not a guardian');

    // Check not already approved
    if (pending.guardianApprovals.some((a) => a.guardianId === guardianId)) {
      throw new Error('Already approved');
    }

    // Add approval
    pending.guardianApprovals.push({
      guardianId,
      approvedAt: Timestamp.now(),
    });
    pending.totalWeight += guardian.recoveryWeight;

    // Check if threshold met
    if (pending.totalWeight >= config.recoveryThreshold) {
      pending.status = 'approved';
      // Schedule execution after timelock
      await this.scheduleExecution(daoId, pending);
    }

    await this.saveRecovery(daoId, pending);
  }

  async executeRecovery(daoId: string): Promise<void> {
    const config = await this.getConfig(daoId);
    const pending = config.pendingRecovery;

    if (pending?.status !== 'approved') {
      throw new Error('Recovery not approved');
    }

    if (Date.now() < pending.executesAt.toMillis()) {
      throw new Error('Timelock not elapsed');
    }

    // Execute Safe owner swap
    await this.swapSafeOwner(daoId, pending.newOwnerAddress);

    pending.status = 'executed';
    await this.saveRecovery(daoId, pending);

    await auditService.log(daoId, 'recovery_executed', {
      newOwner: pending.newOwnerAddress,
      guardianApprovals: pending.guardianApprovals.length,
    });
  }
}
```

**UI Components**:

1. **Guardian Nomination** (`/dao/[id]/settings/recovery`)
2. **Recovery Initiation** (accessible to guardians only)
3. **Approval Dashboard** (guardians see pending requests)
4. **Admin Cancellation** (admins can cancel during timelock)
5. **Status Timeline** (visualize recovery progress)

### 6.3 EnDAO Guardian Service (Phase 3 - Premium)

**Concept**: EnDAO acts as a recovery backstop for DAOs that pay for the service.

**Features**:

- EnDAO holds 1 guardian slot in participating DAOs
- 24/7 response SLA for recovery requests
- Identity verification before approving recovery
- Monthly fee based on treasury size

---

## 7. Revenue Model Implementation

### 7.1 Revenue Streams

| Stream               | Type              | Rate               | Phase   |
| -------------------- | ----------------- | ------------------ | ------- |
| TCR Transaction Fee  | % on marketplace  | 3%                 | Phase 1 |
| Volume-Based Fees    | % above threshold | 0.5% above $10K/mo | Phase 2 |
| Premium Integrations | Subscription      | $50-500/mo         | Phase 2 |
| EnDAO Guardian       | Service fee       | $100-1000/mo       | Phase 3 |
| Consulting/Migration | One-time          | Custom             | Phase 3 |

### 7.2 Fee Distribution (On-Chain)

```solidity
// Update to FeeRouter.sol
contract FeeRouter {
    uint256 public constant TREASURY_SHARE = 70;     // 70%
    uint256 public constant LP_SHARE = 20;           // 20%
    uint256 public constant DEVELOPMENT_SHARE = 10;  // 10%

    address public treasuryAddress;
    address public lpRewardsAddress;
    address public developmentAddress;

    function distributeFees(uint256 amount) external {
        uint256 treasuryAmount = (amount * TREASURY_SHARE) / 100;
        uint256 lpAmount = (amount * LP_SHARE) / 100;
        uint256 devAmount = amount - treasuryAmount - lpAmount;

        tcr.transfer(treasuryAddress, treasuryAmount);
        tcr.transfer(lpRewardsAddress, lpAmount);
        tcr.transfer(developmentAddress, devAmount);

        emit FeesDistributed(treasuryAmount, lpAmount, devAmount);
    }
}
```

### 7.3 The Portability Test

**Principle**: Core features free, infrastructure costs covered by premium.

**Implementation Checklist**:

| Data Type             | Exportable? | Format              |
| --------------------- | ----------- | ------------------- |
| Governance history    | ✅ Yes      | JSON, CSV           |
| Treasury records      | ✅ Yes      | CSV, PDF            |
| Member data           | ✅ Yes      | JSON (with consent) |
| Proposal archive      | ✅ Yes      | JSON, Markdown      |
| On-chain transactions | ✅ Yes      | Etherscan links     |

**Export Center (Phase 1)**:

```typescript
// src/app/dao/[id]/settings/export/page.tsx
const exportOptions = [
  {
    type: 'governance_history',
    label: 'Governance History',
    description: 'All proposals, votes, and outcomes',
    formats: ['json', 'csv', 'pdf'],
  },
  {
    type: 'treasury_ledger',
    label: 'Treasury Records',
    description: 'Complete transaction history',
    formats: ['csv', 'pdf', 'quickbooks'],
  },
  {
    type: 'member_directory',
    label: 'Member Directory',
    description: 'Member list with roles (requires consent)',
    formats: ['json', 'csv'],
  },
  {
    type: 'full_backup',
    label: 'Full DAO Backup',
    description: 'Everything in portable format',
    formats: ['json'],
  },
];
```

---

## 8. Legal-Technical Bridge

### 8.1 Entity Strategy

**Primary Path**: Wyoming DUNA (Decentralized Unincorporated Nonprofit Association)

**Backup Path**: Delaware PBC + 501(c)(3) Foundation

| Scenario           | Choose DUNA                | Choose PBC                       |
| ------------------ | -------------------------- | -------------------------------- |
| Timeline           | DUNA established, ready    | DUNA formation delays            |
| Regulatory clarity | DUNA offers better DAO fit | PBC more traditional recognition |
| Tax treatment      | Nonprofit pass-through     | C-Corp + Foundation split        |

### 8.2 Technical-Legal Mapping

| Technical Component          | Wyoming DUNA Equivalent             |
| ---------------------------- | ----------------------------------- |
| EnDAO Treasury (Gnosis Safe) | DUNA Treasury (taxable entity)      |
| SubDAO (Gnosis Safe)         | Authorized Committee                |
| TEQ Token                    | Membership Interest                 |
| TCR Transaction              | Commercial Contract (1099-DA ready) |
| EDG Vote                     | Member Vote (binding)               |
| Smart Contract               | Operating Agreement Exhibit         |

### 8.3 1099-DA Tax Reporting (Phase 2)

```typescript
// src/lib/services/tax/1099-da.service.ts
interface Form1099DA {
  taxYear: number;
  payerInfo: {
    name: string;
    tin: string;
    address: string;
  };
  recipientInfo: {
    name: string;
    tin: string;
    address: string;
  };
  transactions: Array<{
    date: Date;
    description: string;
    grossProceeds: number;
    costBasis: number;
    gainLoss: number;
    shortLongTerm: 'short' | 'long';
  }>;
  totalGrossProceeds: number;
  totalCostBasis: number;
  totalGainLoss: number;
}

class TaxReportingService {
  async generate1099DA(userId: string, taxYear: number): Promise<Form1099DA> {
    // Aggregate all TCR transactions for user
    const transactions = await this.getUserTransactions(userId, taxYear);

    // Calculate cost basis (FIFO method)
    const processed = this.calculateCostBasis(transactions);

    // Generate form
    return this.buildForm(userId, taxYear, processed);
  }
}
```

---

## 9. Implementation Phases

### Phase 1: MVP Quality (Current → Q1 2026)

| Priority | Item                               | Status                | Owner           |
| -------- | ---------------------------------- | --------------------- | --------------- |
| P0       | **EDG Token Deployment**           | 🔴 Not started        | Smart contracts |
| P0       | **Social Recovery**                | 🔴 MVP Blocker        | Platform        |
| P1       | **Spending Limits Enforcement**    | 🟡 Schema exists      | Platform        |
| P1       | **Commerce vs Community Defaults** | 🟡 Not differentiated | Platform        |
| P2       | **Export Center UI**               | 🔴 API only           | Platform        |
| P2       | **TCR Token Deployment**           | 🔴 Not started        | Smart contracts |

**Smart Contract Deliverables**:

1. `EDG.sol` - Governance token
2. `EDGVault.sol` - Staking for fee discounts
3. `TCR.sol` - TimeCredits utility token
4. Update `FeeRouter.sol` - Integrate EDG discounts

**Platform Deliverables**:

1. Social Recovery service + UI
2. DAO type selection in onboarding
3. Spending limit enforcement in treasury execution
4. Export Center UI

---

### Phase 2: Network Foundation (Q2 2026)

| Priority | Item                              |
| -------- | --------------------------------- |
| P0       | Sub-DAO data model & UI           |
| P0       | TEQ Token deployment              |
| P0       | LaborOracle deployment            |
| P0       | ServiceMarketplace deployment     |
| P1       | Ops Wallet (app-layer)            |
| P1       | Consent-based governance          |
| P2       | Double-Dip activation             |
| P2       | DAO-to-DAO relationships (schema) |

**Smart Contract Deliverables**:

1. `TEQ.sol` - Soulbound equity token
2. `LaborOracle.sol` - Cost-Plus rate oracle
3. `ServiceMarketplace.sol` - Labor marketplace with Double-Dip

---

### Phase 3: Network Features (Q3 2026)

| Priority | Item                         |
| -------- | ---------------------------- |
| P0       | DAO-to-DAO payments          |
| P0       | Shared proposals (cross-DAO) |
| P1       | EnDAO Guardian (premium)     |
| P1       | Zodiac module integration    |
| P2       | AI governance assistant      |

**Entity Formation**:

- Form EnDAO DUNA (Wyoming) OR
- Delaware PBC + Foundation (backup)

---

### Phase 4: Institutional Rails (Q4 2026+)

| Priority | Item                           |
| -------- | ------------------------------ |
| P0       | Discovery/federation protocol  |
| P1       | Agreement encoding             |
| P1       | Enterprise unified dashboard   |
| P2       | Chainlink automated rate feeds |
| P2       | Multi-chain deployment         |

---

## 10. Technical Checklists

### Smart Contract Checklist

- [ ] **EDG.sol**: ERC-20Votes, mint function, access control
- [ ] **EDGVault.sol**: ERC-4626, discount tiers, integration with FeeRouter
- [ ] **TCR.sol**: ERC-20 + ERC-2612, mint/burn, bridge role
- [ ] **TEQ.sol**: Soulbound, cumulative labor tracking, vesting
- [ ] **LaborOracle.sol**: Rate management, anti-gaming caps, attestation
- [ ] **ServiceMarketplace.sol**: Escrow, Double-Dip, fee integration
- [ ] **FeeRouter.sol update**: EDG discount check, fee distribution

### Platform Checklist

- [ ] **Social Recovery**: Guardian CRUD, initiation flow, approval dashboard, timelock UI
- [ ] **Commerce vs Community**: Type selector in onboarding, default configs
- [ ] **Spending Limits**: Validation in OpsWalletService, enforcement in treasury execution
- [ ] **Export Center**: UI for all export types, format generators
- [ ] **Treasury Tiers**: Tier selection in DAO creation, upgrade prompts
- [ ] **Sub-DAO Schema**: parentDaoId, childDaoIds, hierarchy level fields
- [ ] **Consent Governance**: Auto-pass scheduler, objection tracking, UI

### Contract Role Matrix

| Contract    | Role                 | Initial Holder     | Final Holder                 |
| ----------- | -------------------- | ------------------ | ---------------------------- |
| EDG         | `MINTER_ROLE`        | Multi-sig          | Governor                     |
| EDG         | `DEFAULT_ADMIN_ROLE` | Multi-sig          | TimelockController           |
| TCR         | `MINTER_ROLE`        | ServiceMarketplace | ServiceMarketplace           |
| TCR         | `BRIDGE_ROLE`        | Bridge service     | Bridge service               |
| TEQ         | `CONTROLLER_ROLE`    | ServiceMarketplace | ServiceMarketplace           |
| LaborOracle | `UPDATER_ROLE`       | Multi-sig          | Governor                     |
| All         | `DEFAULT_ADMIN_ROLE` | Multi-sig          | TimelockController (Phase 3) |

---

## Appendix: File Locations

| Component          | Path                                                            |
| ------------------ | --------------------------------------------------------------- |
| DAO Types          | `src/types/dao.ts`                                              |
| Treasury Service   | `src/lib/services/treasury/`                                    |
| Proposal Service   | `src/lib/services/proposal/`                                    |
| Recovery Service   | `src/lib/services/recovery/` (new)                              |
| Ops Wallet Service | `src/lib/services/treasury/ops-wallet.service.ts` (new)         |
| Consent Governance | `src/lib/services/proposal/consent-governance.service.ts` (new) |
| Tax Reporting      | `src/lib/services/tax/` (new)                                   |
| Smart Contracts    | `contracts/`                                                    |
| Contract ABIs      | `src/lib/contracts/`                                            |

---

## 9. API & Database Specifications

### 9.1 API Architecture

#### 9.1.1 API Route Structure

```
/api
├── /auth
│   ├── POST /login                     # Privy authentication
│   ├── POST /logout
│   └── GET  /me                        # Current user info
│
├── /daos
│   ├── GET  /                          # List DAOs
│   ├── POST /                          # Create DAO
│   ├── GET  /:id                       # Get DAO details
│   ├── PATCH /:id                      # Update DAO
│   ├── DELETE /:id                     # Soft delete DAO
│   ├── GET  /:id/members               # List members
│   ├── POST /:id/members               # Add member
│   └── GET  /:id/stats                 # DAO statistics
│
├── /proposals
│   ├── GET  /                          # List proposals
│   ├── POST /                          # Create proposal
│   ├── GET  /:id                       # Get proposal
│   ├── PATCH /:id                      # Update proposal
│   ├── POST /:id/approve               # Admin approve
│   ├── POST /:id/reject                # Admin reject
│   ├── POST /:id/vote                  # Cast vote
│   └── POST /:id/execute               # Execute passed proposal
│
├── /treasury
│   ├── GET  /:daoId/balance            # Get treasury balance
│   ├── GET  /:daoId/portfolio          # Multi-asset portfolio
│   ├── GET  /:daoId/transactions       # Transaction history
│   ├── POST /:daoId/execute            # Execute transaction
│   ├── POST /:daoId/sign               # Sign pending tx
│   ├── POST /:daoId/create-safe        # Deploy new Safe
│   ├── POST /:daoId/swap               # Currency swap
│   └── GET  /:daoId/export             # Export transactions
│
├── /ops-wallet
│   ├── GET  /:daoId/config             # Get Ops Wallet config
│   ├── PATCH /:daoId/config            # Update config
│   ├── POST /:daoId/transaction        # Create ops transaction
│   ├── POST /:daoId/approve            # Approve pending
│   └── GET  /:daoId/history            # Ops wallet history
│
├── /tokens
│   ├── GET  /balances/:address         # Get all token balances
│   ├── GET  /edg/voting-power/:address # EDG voting power
│   ├── GET  /teq/stats/:address        # TEQ labor stats
│   ├── POST /tcr/deposit               # Initiate TCR deposit
│   └── POST /tcr/withdraw              # Initiate TCR withdrawal
│
├── /marketplace
│   ├── GET  /jobs                      # List jobs
│   ├── POST /jobs                      # Create job
│   ├── GET  /jobs/:id                  # Get job details
│   ├── POST /jobs/:id/accept           # Provider accepts
│   ├── POST /jobs/:id/complete         # Client confirms completion
│   └── POST /jobs/:id/dispute          # Open dispute
│
├── /recovery
│   ├── GET  /:daoId/config             # Get recovery config
│   ├── POST /:daoId/guardians          # Add guardian
│   ├── DELETE /:daoId/guardians/:id    # Remove guardian
│   ├── POST /:daoId/initiate           # Initiate recovery
│   ├── POST /:daoId/approve            # Guardian approves
│   └── POST /:daoId/cancel             # Cancel recovery
│
├── /integrations
│   ├── GET  /quickbooks/connect        # OAuth flow start
│   ├── POST /quickbooks/callback       # OAuth callback
│   ├── POST /quickbooks/sync           # Manual sync
│   └── GET  /quickbooks/status         # Sync status
│
└── /admin
    ├── GET  /health                    # System health
    ├── GET  /metrics                   # Usage metrics
    └── POST /freeze/:daoId             # Emergency freeze
```

#### 9.1.2 API Response Standards

```typescript
// src/types/api.ts
interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
  meta?: {
    pagination?: {
      page: number;
      limit: number;
      total: number;
      hasMore: boolean;
    };
    timestamp: string;
    requestId: string;
  };
}

// Error codes
const ErrorCodes = {
  // Authentication
  AUTH_REQUIRED: 'AUTH_REQUIRED',
  AUTH_INVALID: 'AUTH_INVALID',
  AUTH_EXPIRED: 'AUTH_EXPIRED',

  // Authorization
  FORBIDDEN: 'FORBIDDEN',
  NOT_MEMBER: 'NOT_MEMBER',
  NOT_ADMIN: 'NOT_ADMIN',

  // Validation
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_INPUT: 'INVALID_INPUT',

  // Resources
  NOT_FOUND: 'NOT_FOUND',
  ALREADY_EXISTS: 'ALREADY_EXISTS',

  // Treasury
  INSUFFICIENT_BALANCE: 'INSUFFICIENT_BALANCE',
  TREASURY_FROZEN: 'TREASURY_FROZEN',
  SPENDING_LIMIT_EXCEEDED: 'SPENDING_LIMIT_EXCEEDED',

  // Governance
  VOTING_CLOSED: 'VOTING_CLOSED',
  ALREADY_VOTED: 'ALREADY_VOTED',
  QUORUM_NOT_MET: 'QUORUM_NOT_MET',

  // Token
  TOKEN_SOULBOUND: 'TOKEN_SOULBOUND',
  BRIDGE_UNAVAILABLE: 'BRIDGE_UNAVAILABLE',

  // System
  INTERNAL_ERROR: 'INTERNAL_ERROR',
  RATE_LIMITED: 'RATE_LIMITED',
} as const;
```

#### 9.1.3 Rate Limiting

```typescript
// src/middleware/rate-limit.ts
const rateLimits = {
  // Public endpoints
  public: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 60, // 60 requests per minute
  },

  // Authenticated endpoints
  authenticated: {
    windowMs: 60 * 1000,
    maxRequests: 120,
  },

  // Treasury operations
  treasury: {
    windowMs: 60 * 1000,
    maxRequests: 10, // 10 treasury ops per minute
  },

  // Bridge operations
  bridge: {
    windowMs: 60 * 60 * 1000, // 1 hour
    maxRequests: 20, // 20 bridge ops per hour
  },
};
```

---

### 9.2 Database Schemas

#### 9.2.1 Database Tables (Supabase/PostgreSQL)

```typescript
// Database table schemas (Supabase PostgreSQL)

// daos table
interface DAODocument {
  id: string;
  name: string;
  description?: string;
  slug: string;
  avatar?: string;
  banner?: string;

  // Classification
  daoType: 'commerce' | 'community';
  treasuryTier: 1 | 2 | 3 | 4;
  treasuryMode: 'disabled' | 'tracking' | 'safe';

  // Treasury
  treasury?: {
    safeAddress?: string;
    chainId: number;
    requiredSignatures: number;
    owners: string[];
  };

  // Ops Wallet (Tier 3+)
  opsWallet?: {
    address: string;
    maxDailySpend: number;
    maxSingleTransaction: number;
    requiresApprovalAbove: number;
    treasurerUserIds: string[];
    refillThreshold: number;
  };

  // Governance
  settings: {
    votingPeriodDays: number;
    quorumPercentage: number;
    passThreshold: number;
    governanceStyle: 'proposal' | 'consent';
    consentSettings?: {
      passAfterDays: number;
      objectionThreshold: number;
    };
  };

  // Sub-DAO hierarchy
  parentDaoId?: string;
  childDaoIds?: string[];
  hierarchyLevel: number;

  // DAO-to-DAO relationships
  linkedDaos?: Array<{
    daoId: string;
    relationship: 'partner' | 'vendor' | 'customer' | 'subsidiary';
    since: Timestamp;
    status: 'pending' | 'active' | 'terminated';
  }>;

  // Recovery
  recoveryConfig?: {
    guardians: Array<{
      userId: string;
      email: string;
      recoveryWeight: number;
      addedAt: Timestamp;
    }>;
    recoveryThreshold: number;
    timelockDuration: number;
  };

  // Integrations
  integrations?: {
    quickbooks?: {
      realmId: string;
      syncEnabled: boolean;
      lastSyncAt?: Timestamp;
    };
  };

  // Metadata
  status: 'active' | 'archived' | 'pending_deletion' | 'deleted';
  createdAt: Timestamp;
  updatedAt: Timestamp;
  createdBy: string;
  memberCount: number;
  proposalCount: number;
}

// dao-members/{memberId}
interface DAOMemberDocument {
  id: string;
  daoId: string;
  userId: string;
  role: 'member' | 'admin';
  isActive: boolean;

  // Permissions
  permissions?: {
    canPropose: boolean;
    canVote: boolean;
    isTreasurer: boolean;
    isGuardian: boolean;
  };

  // Profile overrides
  displayName?: string;
  avatar?: string;
  bio?: string;

  // Token stats (cached)
  tokenStats?: {
    teqBalance: string;
    tcrEarned: string;
    hoursContributed: number;
    lastUpdated: Timestamp;
  };

  // Metadata
  joinedAt: Timestamp;
  invitedBy?: string;
  status: 'pending' | 'active' | 'suspended' | 'removed';
}

// proposals/{proposalId}
interface ProposalDocument {
  id: string;
  daoId: string;
  creatorId: string;

  // Content
  title: string;
  description: string;
  type: 'general' | 'funding' | 'governance' | 'bounty';

  // Funding specific
  amount?: number;
  recipientAddress?: string;
  currency?: string;

  // Bounty specific
  bountyReward?: number;
  bountyCurrency?: string;
  bountyDeadline?: Timestamp;
  bountyRequirements?: string;

  // Voting config
  votingConfig: {
    system: 'simple' | 'token_weighted' | 'quadratic';
    quorumPercentage: number;
    passThreshold: number;
    votingPeriodDays: number;
  };

  // Status
  status:
    | 'draft'
    | 'under_review'
    | 'active'
    | 'passed'
    | 'rejected'
    | 'expired'
    | 'executed'
    | 'cancelled';

  // Timing
  submittedAt?: Timestamp;
  votingStartsAt?: Timestamp;
  votingEndsAt?: Timestamp;
  executedAt?: Timestamp;

  // Results
  results?: {
    for: number;
    against: number;
    abstain: number;
    uniqueVoters: number;
    quorumReached: boolean;
    passed: boolean;
  };

  // Token-weighted results
  tokenWeightedResults?: {
    for: string; // BigInt as string
    against: string;
    abstain: string;
    totalPower: string;
  };

  // Consent governance (community DAOs)
  consentData?: {
    currentObjections: number;
    objectors: string[];
    passAfterDays: number;
    objectionThreshold: number;
  };

  // Metadata
  createdAt: Timestamp;
  updatedAt: Timestamp;
  attachments?: string[];
  txHash?: string;
}

// votes/{voteId}
interface VoteDocument {
  id: string;
  proposalId: string;
  daoId: string;
  voterId: string;
  choice: 'for' | 'against' | 'abstain';

  // Token-weighted voting
  votingPower?: string; // BigInt as string
  tokenType?: 'edg' | 'teq' | 'equal';

  // Delegation
  delegatedFrom?: string; // If voting on behalf of

  // Metadata
  createdAt: Timestamp;
  txHash?: string; // If on-chain vote
}

// treasury_ledger/{transactionId}
interface LedgerDocument {
  id: string;
  daoId: string;

  // Transaction details
  type:
    | 'income'
    | 'expense'
    | 'transfer_in'
    | 'transfer_out'
    | 'swap'
    | 'proposal_execution';
  description: string;
  category?: string;

  // Amounts
  token: string;
  tokenAmount: string;
  usdValue: number;
  decimals: number;

  // Addresses
  from: string;
  to: string;
  txHash: string;

  // Status
  status: 'pending' | 'confirmed' | 'failed';
  blockNumber?: number;
  confirmations?: number;

  // Linked entities
  proposalId?: string;
  opsTransactionId?: string;
  refillRequestId?: string;

  // Metadata
  createdAt: Timestamp;
  confirmedAt?: Timestamp;
  createdBy: string;
  attachments?: string[];
  notes?: string;
}

// recovery_requests/{requestId}
interface RecoveryRequestDocument {
  id: string;
  daoId: string;

  // Request details
  initiatedBy: string;
  newOwnerAddress: string;

  // Approvals
  guardianApprovals: Array<{
    guardianId: string;
    approvedAt: Timestamp;
  }>;
  totalWeight: number;
  requiredWeight: number;

  // Timing
  initiatedAt: Timestamp;
  executesAt: Timestamp; // After timelock
  executedAt?: Timestamp;
  cancelledAt?: Timestamp;

  // Status
  status: 'pending' | 'approved' | 'executed' | 'cancelled' | 'expired';
  cancelReason?: string;
  cancelledBy?: string;
}

// marketplace_jobs/{jobId}
interface MarketplaceJobDocument {
  id: string;
  daoId?: string; // Optional - can be cross-DAO

  // Parties
  clientId: string;
  clientAddress: string;
  providerId?: string;
  providerAddress?: string;

  // Job details
  title: string;
  description: string;
  jobTypeId: number;
  estimatedHours: number;
  actualHours?: number;

  // Payment
  amount: string; // TCR amount
  escrowAddress: string;
  paymentStatus: 'escrowed' | 'released' | 'refunded';

  // Status
  status: 'open' | 'in_progress' | 'completed' | 'disputed' | 'cancelled';

  // Equity minting
  teqMinted?: string;
  laborRate?: number;

  // Metadata
  createdAt: Timestamp;
  acceptedAt?: Timestamp;
  completedAt?: Timestamp;
  txHash?: string;
  disputeReason?: string;
}

// users/{userId}
interface UserDocument {
  uid: string;
  privyId: string;
  email?: string;
  username?: string;
  lowercaseUsername?: string;

  // Profile
  displayName?: string;
  avatar?: string;
  bio?: string;
  profileSetupComplete: boolean;

  // Wallets
  walletAddresses: {
    primary: string;
    privy?: string;
    external?: string[];
  };

  // Cached token balances
  tokenBalances?: {
    edg: string;
    teq: string;
    tcr: string;
    lastUpdated: Timestamp;
  };

  // Labor stats
  laborStats?: {
    totalHoursWorked: number;
    totalTCREarned: string;
    totalTEQEarned: string;
    averageHourlyRate: number;
    jobTypes: Record<number, number>;
  };

  // KYC (for bridge)
  kycStatus?: 'none' | 'pending' | 'verified' | 'rejected';
  kycVerifiedAt?: Timestamp;

  // Preferences
  preferences?: {
    emailNotifications: boolean;
    pushNotifications: boolean;
    theme: 'light' | 'dark' | 'system';
    language: string;
  };

  // Metadata
  createdAt: Timestamp;
  updatedAt: Timestamp;
  lastLoginAt: Timestamp;
}
```

#### 9.2.2 PostgreSQL Indexes

```sql
-- Critical database indexes (Supabase PostgreSQL)

-- Proposals table indexes
CREATE INDEX idx_proposals_dao_status_created ON proposals (dao_id, status, created_at DESC);

-- DAO members table indexes
CREATE INDEX idx_dao_members_dao_active_role ON dao_members (dao_id, is_active, role);

-- Treasury ledger table indexes
CREATE INDEX idx_treasury_ledger_dao_created ON treasury_ledger (dao_id, created_at DESC);
CREATE INDEX idx_treasury_ledger_dao_type_created ON treasury_ledger (dao_id, type, created_at DESC);

-- Votes table indexes
CREATE INDEX idx_votes_proposal_voter ON votes (proposal_id, voter_id);

-- Marketplace jobs table indexes
CREATE INDEX idx_marketplace_jobs_status_created ON marketplace_jobs (status, created_at DESC);
CREATE INDEX idx_marketplace_jobs_provider_status ON marketplace_jobs (provider_id, status);
```

---

### 9.3 Event System

#### 9.3.1 Event Types

```typescript
// src/lib/events/event-types.ts
type EventType =
  // DAO lifecycle
  | 'dao.created'
  | 'dao.updated'
  | 'dao.archived'
  | 'dao.deleted'
  | 'dao.tier_upgraded'

  // Membership
  | 'member.joined'
  | 'member.left'
  | 'member.role_changed'
  | 'member.suspended'

  // Proposals
  | 'proposal.created'
  | 'proposal.submitted'
  | 'proposal.approved'
  | 'proposal.rejected'
  | 'proposal.voting_started'
  | 'proposal.voting_ended'
  | 'proposal.passed'
  | 'proposal.failed'
  | 'proposal.executed'

  // Voting
  | 'vote.cast'
  | 'vote.changed'
  | 'vote.delegated'

  // Treasury
  | 'treasury.created'
  | 'treasury.transaction_initiated'
  | 'treasury.transaction_signed'
  | 'treasury.transaction_executed'
  | 'treasury.transaction_failed'
  | 'treasury.frozen'
  | 'treasury.unfrozen'

  // Ops Wallet
  | 'ops_wallet.configured'
  | 'ops_wallet.transaction_created'
  | 'ops_wallet.transaction_approved'
  | 'ops_wallet.transaction_executed'
  | 'ops_wallet.refill_requested'
  | 'ops_wallet.refill_completed'

  // Recovery
  | 'recovery.guardian_added'
  | 'recovery.guardian_removed'
  | 'recovery.initiated'
  | 'recovery.approved'
  | 'recovery.cancelled'
  | 'recovery.executed'

  // Tokens
  | 'token.edg_transferred'
  | 'token.edg_staked'
  | 'token.edg_unstaked'
  | 'token.tcr_minted'
  | 'token.tcr_burned'
  | 'token.teq_minted'

  // Marketplace
  | 'job.created'
  | 'job.accepted'
  | 'job.completed'
  | 'job.disputed'
  | 'job.resolved';

interface EventPayload {
  eventId: string;
  type: EventType;
  timestamp: Timestamp;
  actor: {
    userId: string;
    walletAddress?: string;
  };
  resource: {
    type: 'dao' | 'proposal' | 'member' | 'treasury' | 'job' | 'token';
    id: string;
    daoId?: string;
  };
  data: Record<string, unknown>;
  metadata?: {
    txHash?: string;
    ipAddress?: string;
    userAgent?: string;
  };
}
```

#### 9.3.2 Event Processing

```typescript
// src/lib/events/event-processor.ts
class EventProcessor {
  private handlers: Map<EventType, EventHandler[]> = new Map();

  register(eventType: EventType, handler: EventHandler): void {
    const existing = this.handlers.get(eventType) || [];
    this.handlers.set(eventType, [...existing, handler]);
  }

  async process(event: EventPayload): Promise<void> {
    // Store event
    await this.eventStore.save(event);

    // Get handlers
    const handlers = this.handlers.get(event.type) || [];

    // Execute handlers in parallel
    await Promise.allSettled(handlers.map((handler) => handler.handle(event)));
  }
}

// Event handlers
class NotificationHandler implements EventHandler {
  async handle(event: EventPayload): Promise<void> {
    switch (event.type) {
      case 'proposal.voting_started':
        await this.notifyAllMembers(event.resource.daoId!, {
          title: 'New Proposal for Voting',
          body: `A new proposal requires your vote`,
          link: `/dao/${event.resource.daoId}/proposals/${event.resource.id}`,
        });
        break;

      case 'treasury.transaction_initiated':
        await this.notifySigners(event.resource.daoId!, {
          title: 'Transaction Needs Signature',
          body: 'A treasury transaction is waiting for your signature',
        });
        break;

      case 'recovery.initiated':
        await this.notifyAdmins(event.resource.daoId!, {
          title: 'Recovery Request Initiated',
          body: 'A recovery request has been started. Review immediately.',
          priority: 'high',
        });
        break;
    }
  }
}

class AnalyticsHandler implements EventHandler {
  async handle(event: EventPayload): Promise<void> {
    await this.analytics.track({
      event: event.type,
      userId: event.actor.userId,
      properties: {
        daoId: event.resource.daoId,
        resourceType: event.resource.type,
        resourceId: event.resource.id,
        ...event.data,
      },
    });
  }
}

class AuditLogHandler implements EventHandler {
  async handle(event: EventPayload): Promise<void> {
    if (this.isAuditableEvent(event.type)) {
      await this.auditService.log({
        action: event.type,
        actor: event.actor.userId,
        resource: event.resource,
        data: event.data,
        timestamp: event.timestamp,
        metadata: event.metadata,
      });
    }
  }

  private isAuditableEvent(type: EventType): boolean {
    return (
      type.startsWith('treasury.') ||
      type.startsWith('recovery.') ||
      type.includes('role_changed') ||
      type.includes('executed')
    );
  }
}
```

---

## 10. Implementation Phases (Detailed)

### 10.1 Phase 1: MVP Quality (Current → Q1 2026)

#### 10.1.1 Milestone 1.1: Social Recovery (4 weeks)

| Week | Deliverable                                  | Owner    |
| ---- | -------------------------------------------- | -------- |
| 1    | Schema design, API routes                    | Backend  |
| 2    | Service implementation                       | Backend  |
| 3    | UI: Guardian management, Recovery initiation | Frontend |
| 4    | Testing, security review                     | QA       |

**Acceptance Criteria**:

- [ ] Guardians can be added/removed by DAO admins
- [ ] Recovery can be initiated by any guardian
- [ ] Multiple guardians can approve recovery
- [ ] 7-day timelock before execution
- [ ] Admins can cancel during timelock
- [ ] Safe owner swap executes correctly

#### 10.1.2 Milestone 1.2: Commerce vs Community Split (3 weeks)

| Week | Deliverable                           | Owner      |
| ---- | ------------------------------------- | ---------- |
| 1    | DAO type field, default configs       | Backend    |
| 2    | Onboarding flow update, type selector | Frontend   |
| 3    | Consent governance implementation     | Full stack |

**Acceptance Criteria**:

- [ ] New DAOs select Commerce or Community type
- [ ] Commerce DAOs get Tier 2 treasury by default
- [ ] Community DAOs get Tier 1 (disabled) by default
- [ ] Consent-based proposals work for Community DAOs
- [ ] Existing DAOs can migrate types

#### 10.1.3 Milestone 1.3: Spending Limits Enforcement (2 weeks)

| Week | Deliverable                          | Owner    |
| ---- | ------------------------------------ | -------- |
| 1    | Validation logic in OpsWalletService | Backend  |
| 2    | UI feedback, error handling          | Frontend |

**Acceptance Criteria**:

- [ ] Single transaction limits enforced
- [ ] Daily spend limits enforced
- [ ] Above-threshold transactions require approval
- [ ] Clear error messages for limit violations

#### 10.1.4 Milestone 1.4: EDG Token Deployment (6 weeks)

| Week | Deliverable                                   | Owner           |
| ---- | --------------------------------------------- | --------------- |
| 1-2  | Contract development (EDG, EDGVault, Vesting) | Smart contracts |
| 3    | Unit tests, local deployment                  | Smart contracts |
| 4    | External audit                                | Security        |
| 5    | Testnet deployment, integration tests         | Full stack      |
| 6    | Mainnet deployment, monitoring                | DevOps          |

**Acceptance Criteria**:

- [ ] EDG token deployed on Base Mainnet
- [ ] EDGVault staking working
- [ ] Vesting contracts deployed for team/contributors
- [ ] Integration with FeeRouter for discounts
- [ ] Audit report clean (no critical/high findings)

---

### 10.2 Phase 2: Network Foundation (Q2 2026)

#### 10.2.1 Milestone 2.1: Sub-DAO Data Model (3 weeks)

**Deliverables**:

- parentDaoId, childDaoIds fields in DAO schema
- Sub-DAO creation flow
- Org chart visualization
- Permission inheritance logic

#### 10.2.2 Milestone 2.2: TEQ + LaborOracle + ServiceMarketplace (8 weeks)

**Deliverables**:

- TEQ soulbound token contract
- LaborOracle with job types
- ServiceMarketplace with escrow
- Double-Dip integration
- Fiat bridge integration (TCR)

#### 10.2.3 Milestone 2.3: Ops Wallet Full Implementation (4 weeks)

**Deliverables**:

- Ops Wallet creation flow
- Refill mechanism
- Approval workflows
- Transaction history UI

---

### 10.3 Phase 3: Network Features (Q3 2026)

#### 10.3.1 Milestone 3.1: DAO-to-DAO Primitives (6 weeks)

**Deliverables**:

- DAO relationships (partner/vendor/customer)
- Shared proposals
- Cross-treasury transfers
- Discovery registry

#### 10.3.2 Milestone 3.2: EnDAO Guardian Service (4 weeks)

**Deliverables**:

- Guardian registration flow
- 24/7 monitoring setup
- Identity verification integration
- Pricing and billing

#### 10.3.3 Milestone 3.3: Entity Formation (Ongoing)

**Deliverables**:

- Wyoming DUNA formation (primary)
- OR Delaware PBC + Foundation (backup)
- Legal documentation
- Tax structure setup

---

### 10.4 Phase 4: Institutional Rails (Q4 2026+)

#### 10.4.1 Milestone 4.1: Federation Protocol

**Deliverables**:

- DAO registry smart contract
- ENS subdomain integration
- Discovery API
- Cross-network identity

#### 10.4.2 Milestone 4.2: Enterprise Dashboard

**Deliverables**:

- Unified view of Sub-DAOs
- Aggregated treasury reporting
- Cross-DAO analytics
- White-label capabilities

---

## 11. Technical Checklists (Expanded)

### 11.1 Smart Contract Checklist

```
PRE-DEPLOYMENT:
- [ ] Code review by 2+ engineers
- [ ] 100% test coverage
- [ ] Slither/Mythril static analysis
- [ ] External audit (Tier 1 firm)
- [ ] Audit findings resolved
- [ ] Testnet deployment successful
- [ ] Integration tests passing
- [ ] Gas optimization verified
- [ ] Upgrade path documented (if applicable)

DEPLOYMENT:
- [ ] Deploy to Base Mainnet
- [ ] Verify contract on BaseScan
- [ ] Transfer admin to multi-sig
- [ ] Document deployed addresses
- [ ] Update environment variables
- [ ] Update contract ABIs in frontend

POST-DEPLOYMENT:
- [ ] Monitor for first 24 hours
- [ ] Verify all integrations working
- [ ] Run production smoke tests
- [ ] Update status page
- [ ] Announce deployment
```

### 11.2 Platform Checklist

```
FEATURE DEVELOPMENT:
- [ ] Technical spec reviewed
- [ ] Database schema migrations written
- [ ] API routes implemented
- [ ] Service layer complete
- [ ] UI components built
- [ ] Unit tests (>80% coverage)
- [ ] Integration tests
- [ ] E2E tests for critical paths
- [ ] Accessibility audit (WCAG 2.1 AA)
- [ ] Mobile responsive
- [ ] Error handling complete
- [ ] Loading states implemented
- [ ] Analytics events added

PRE-RELEASE:
- [ ] Security review
- [ ] Performance testing
- [ ] Documentation updated
- [ ] Changelog entry
- [ ] Feature flag configured
- [ ] Rollback plan documented

RELEASE:
- [ ] Staging environment verified
- [ ] Production deployment
- [ ] Smoke tests passing
- [ ] Monitoring alerts configured
- [ ] On-call notified
```

### 11.3 Testing Strategy

#### 11.3.1 Test Coverage Requirements

| Layer            | Min Coverage   | Tools                       |
| ---------------- | -------------- | --------------------------- |
| Smart Contracts  | 100%           | Hardhat, Foundry            |
| API Routes       | 80%            | Jest, Supertest             |
| Services         | 80%            | Jest                        |
| React Components | 70%            | Jest, React Testing Library |
| E2E Flows        | Critical paths | Playwright                  |

#### 11.3.2 Critical E2E Test Scenarios

```typescript
// tests/e2e/critical-paths.spec.ts
describe('Critical User Flows', () => {
  test('Complete DAO creation and funding', async () => {
    // 1. User signs up with Privy
    // 2. Creates new Commerce DAO
    // 3. Safe is deployed
    // 4. Creates funding proposal
    // 5. Votes pass
    // 6. Executes treasury transfer
  });

  test('Social recovery flow', async () => {
    // 1. Admin adds 3 guardians
    // 2. Guardian initiates recovery
    // 3. 2nd guardian approves
    // 4. Verify timelock
    // 5. Execute recovery
    // 6. Verify new owner
  });

  test('Labor marketplace double-dip', async () => {
    // 1. Client creates job with TCR escrow
    // 2. Provider accepts
    // 3. Client confirms completion
    // 4. Verify TCR payment
    // 5. Verify TEQ minting
    // 6. Verify fee to treasury
  });

  test('Ops wallet spending limits', async () => {
    // 1. Configure ops wallet limits
    // 2. Execute transaction under limit (auto-approve)
    // 3. Execute transaction over threshold (needs approval)
    // 4. Exceed daily limit (blocked)
    // 5. Verify ledger recording
  });
});
```

### 11.4 Monitoring & Alerting

#### 11.4.1 Key Metrics

```typescript
// src/lib/monitoring/metrics.ts
const criticalMetrics = {
  // System health
  'api.response_time_p95': { threshold: 500, unit: 'ms' },
  'api.error_rate': { threshold: 1, unit: '%' },
  'api.availability': { threshold: 99.9, unit: '%' },

  // Treasury
  'treasury.pending_signatures': { threshold: 10, unit: 'count' },
  'treasury.execution_failures': { threshold: 1, unit: 'count' },
  'treasury.large_transfers': { threshold: 10000, unit: 'USD' },

  // Governance
  'proposals.expiring_soon': { threshold: 5, unit: 'count' },
  'voting.low_participation': { threshold: 10, unit: '%' },

  // Security
  'recovery.active_requests': { threshold: 1, unit: 'count' },
  'auth.failed_attempts': { threshold: 100, unit: 'count/hour' },
  'rate_limit.exceeded': { threshold: 50, unit: 'count/minute' },

  // Blockchain
  'contract.failed_txs': { threshold: 5, unit: 'count/hour' },
  'gas.price_spike': { threshold: 100, unit: 'gwei' },
  'bridge.pending_deposits': { threshold: 50, unit: 'count' },
};
```

#### 11.4.2 Alert Channels

| Severity | Channel                      | Response Time     |
| -------- | ---------------------------- | ----------------- |
| Critical | PagerDuty + Slack #incidents | 5 minutes         |
| High     | Slack #alerts                | 30 minutes        |
| Medium   | Slack #monitoring            | 4 hours           |
| Low      | Email digest                 | Next business day |

#### 11.4.3 Runbooks

```markdown
## Runbook: Treasury Execution Failure

### Detection

- Alert: `treasury.execution_failures > 0`
- Dashboard: Treasury Execution Errors

### Diagnosis

1. Check Safe API status: https://safe-transaction-base.safe.global/status
2. Check Base network status: https://basescan.org/gastracker
3. Review error logs: `yarn logs:treasury`

### Resolution

- If Safe API down: Wait for recovery, transactions will retry
- If gas spike: Wait for gas to normalize, manual retry
- If contract error: Investigate logs, escalate to dev team

### Escalation

- After 30 min: Notify on-call engineer
- After 2 hours: Notify engineering lead
- If funds at risk: Notify CEO, consider emergency freeze
```

---

## 12. Appendices

### Appendix A: Glossary

| Term                   | Definition                                                                                       |
| ---------------------- | ------------------------------------------------------------------------------------------------ |
| **EDG**                | EnDAO Governance token. Transferable, used for protocol governance and fee discounts.            |
| **TCR**                | TimeCredits. Stablecoin-pegged utility token for the labor marketplace. 1 TCR = $1 USD.          |
| **TEQ**                | Time-Equity Protocol token. Soulbound (non-transferable) membership equity earned through labor. |
| **DUNA**               | Decentralized Unincorporated Nonprofit Association. Wyoming legal structure for DAOs.            |
| **Double-Dip**         | Core value proposition where labor transactions generate both payment (TCR) and equity (TEQ).    |
| **Cost-Plus**          | Valuation methodology: Hours × Market Rate from LaborOracle.                                     |
| **Ops Wallet**         | Limited-authority wallet for day-to-day spending without full governance approval.               |
| **Social Recovery**    | Guardian-based account recovery mechanism using threshold signatures.                            |
| **Consent Governance** | Proposals pass after X days unless Y% object. Reduces governance fatigue.                        |

### Appendix B: Environment Variables

```bash
# .env.example

# Authentication
NEXT_PUBLIC_PRIVY_APP_ID=
PRIVY_APP_SECRET=

# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Blockchain
NEXT_PUBLIC_NETWORK=base
NEXT_PUBLIC_CHAIN_ID=8453
NEXT_PUBLIC_RPC_URL=https://mainnet.base.org

# Contracts
NEXT_PUBLIC_FEE_ROUTER_ADDRESS=
NEXT_PUBLIC_EDG_ADDRESS=
NEXT_PUBLIC_EDG_VAULT_ADDRESS=
NEXT_PUBLIC_TCR_ADDRESS=
NEXT_PUBLIC_TEQ_ADDRESS=
NEXT_PUBLIC_LABOR_ORACLE_ADDRESS=
NEXT_PUBLIC_SERVICE_MARKETPLACE_ADDRESS=

# Safe
NEXT_PUBLIC_SAFE_TRANSACTION_SERVICE=https://safe-transaction-base.safe.global

# Platform
ENDAO_SAFE_ADDRESS=0x00dc44400adb57a85364c97442bd5e95faa861e7
INVITATION_TOKEN_SECRET=

# Biconomy (Gasless)
BICONOMY_API_KEY=
BICONOMY_BUNDLER_URL=

# Integrations
QUICKBOOKS_CLIENT_ID=
QUICKBOOKS_CLIENT_SECRET=

# Monitoring
SENTRY_DSN=
DATADOG_API_KEY=
```

### Appendix C: Contract Addresses (To Be Deployed)

| Contract             | Testnet (Base Sepolia) | Mainnet (Base)                             |
| -------------------- | ---------------------- | ------------------------------------------ |
| FeeRouter            | 0x...                  | 0xf8786857eD04621d6e81959aAb36e422F687E4c8 |
| EDG                  | TBD                    | TBD                                        |
| EDGVault             | TBD                    | TBD                                        |
| EDGVesting           | TBD                    | TBD                                        |
| TCR                  | TBD                    | TBD                                        |
| TEQ                  | TBD                    | TBD                                        |
| LaborOracle          | TBD                    | TBD                                        |
| ServiceMarketplace   | TBD                    | TBD                                        |
| SpendingLimitsModule | TBD                    | TBD                                        |

---

**Document Status**: Draft - Master Implementation Specification
**Next Steps**:

1. Review with team
2. Prioritize Phase 1 milestones
3. Assign owners to each deliverable
4. Begin implementation

**Version History**:

- v0.1 (Dec 5, 2025): Initial comprehensive specification
