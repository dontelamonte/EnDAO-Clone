# In-App Treasury Signing Architecture

## Purpose

Design and implementation specification for Gnosis Safe transaction signing within the EnDAO platform. This document outlines the architecture, data flows, security considerations, and implementation phases for enabling users to sign treasury transactions directly in the application without visiting external Safe UI.

## Last Updated

October 30, 2025

## Overview

Design document for implementing Gnosis Safe transaction signing within the EnDAO platform, eliminating the need for users to visit external Safe UI.

**Status**: Implementation Complete
**Priority**: HIGH - Critical for UX

---

## Problem Statement

**Current State**: Users are directed to external Safe UI to sign treasury transactions via "View on Safe UI" link in `ExecutionProgress` component.

**Issue**: This creates friction and confusion:

- Context switching between platforms
- Users may not understand they need to sign elsewhere
- Breaks the in-app workflow experience
- Adds complexity to the user journey

**Goal**: Enable users to sign Safe transactions directly within EnDAO interface using Gnosis Safe Protocol Kit SDK.

---

## Technical Architecture

### Core Components

#### 1. Safe SDK Signing Service

**File**: `/src/lib/services/treasury/safe-signing.service.ts`

**Purpose**: Wrapper around Safe Protocol Kit for transaction signing operations.

**Key Methods**:

```typescript
class SafeSigningService extends BaseService {
  // Initialize Safe SDK with user's wallet
  async initializeSafeSDK(
    safeAddress: string,
    userWallet: WalletClient
  ): Promise<Safe>;

  // Sign a pending Safe transaction
  async signTransaction(
    safeAddress: string,
    safeTxHash: string,
    userWallet: WalletClient
  ): Promise<SignatureResult>;

  // Check if user is a Safe signer
  async isUserSigner(
    safeAddress: string,
    userAddress: string
  ): Promise<boolean>;

  // Get pending transaction details
  async getPendingTransaction(
    safeAddress: string,
    safeTxHash: string
  ): Promise<SafeTransaction>;
}
```

**Dependencies**:

- `@safe-global/protocol-kit` (v4.1.7) ✅ Already installed
- `@safe-global/api-kit` for Safe Transaction Service API
- Privy wallet for user wallet connection
- Ethers v6 for signing

---

#### 2. Treasury Signing Modal Component

**File**: `/src/components/dao/treasury/treasury-signing-modal.tsx`

**Purpose**: Modal interface for signing treasury transactions within EnDAO.

**Features**:

- Transaction details display (amount, recipient, reason)
- Signer verification (check if current user is signer)
- Signature collection progress
- Real-time signature status updates
- Error handling and retry logic

**UI Flow**:

```
1. User clicks "Sign Transaction" button
2. Modal opens with transaction details
3. Verify user is a signer (show error if not)
4. Connect wallet via Privy (if not connected)
5. Show signing prompt
6. User confirms in wallet
7. Signature submitted to Safe API
8. Modal shows success + updates progress
9. Modal auto-closes after 2 seconds
```

---

#### 3. Updated Execution Progress Component

**File**: `/src/components/dao/treasury/execution-progress.tsx` (modify)

**Changes**:

```typescript
// REMOVE: "View on Safe UI" external link

// ADD: "Sign Transaction" button (for signers)
{isUserSigner && !userHasSigned && (
  <Button onClick={() => setShowSigningModal(true)}>
    <Icon name="PenLine" className="h-4 w-4 mr-2" />
    Sign Transaction
  </Button>
)}

// ADD: Signing modal integration
<TreasurySigningModal
  open={showSigningModal}
  onClose={() => setShowSigningModal(false)}
  safeAddress={proposal.metadata.safeAddress}
  safeTxHash={proposal.executionStatus.safeTxHash}
  proposalId={proposal.id}
  onSignatureComplete={handleSignatureComplete}
/>
```

---

## Data Flow

### Signing Flow Sequence

```mermaid
sequenceDiagram
    participant User
    participant Modal as Signing Modal
    participant Privy as Privy Wallet
    participant SafeSDK as Safe Protocol Kit
    participant SafeAPI as Safe Transaction Service
    participant Supabase as Database

    User->>Modal: Click "Sign Transaction"
    Modal->>SafeSDK: Verify user is signer
    SafeSDK->>SafeAPI: Check Safe owners
    SafeAPI-->>Modal: User verification result

    alt User is signer
        Modal->>Privy: Request wallet connection
        Privy-->>Modal: Wallet connected
        Modal->>SafeSDK: Initialize Safe instance
        SafeSDK->>SafeAPI: Get pending transaction
        SafeAPI-->>Modal: Transaction details
        Modal->>User: Show transaction for review
        User->>Modal: Confirm signing
        Modal->>Privy: Request signature
        Privy->>User: Wallet prompt
        User-->>Privy: Approve signature
        Privy-->>SafeSDK: Signed transaction
        SafeSDK->>SafeAPI: Submit signature
        SafeAPI-->>Modal: Signature confirmation
        Modal->>Supabase: Update execution status
        Supabase-->>Modal: Update confirmed
        Modal->>User: Success message
    else User not signer
        Modal->>User: Error: Not authorized to sign
    end
```

---

## Implementation Phases

### Phase 1: Safe Signing Service (4-6 hours)

**Tasks**:

- [x] Install `@safe-global/api-kit` package
- [ ] Create `SafeSigningService` class
- [ ] Implement Safe SDK initialization with Privy wallet
- [ ] Implement transaction signing method
- [ ] Implement signer verification method
- [ ] Add error handling and logging
- [ ] Write unit tests

**Deliverables**:

- `/src/lib/services/treasury/safe-signing.service.ts` (~300-400 lines)
- `/src/lib/services/treasury/__tests__/safe-signing.service.test.ts` (~200-300 lines)

---

### Phase 2: Signing Modal Component (6-8 hours)

**Tasks**:

- [ ] Create `TreasurySigningModal` component
- [ ] Build transaction details display
- [ ] Implement signer verification UI
- [ ] Integrate Privy wallet connection
- [ ] Add signing flow with loading states
- [ ] Implement error handling UI
- [ ] Add success confirmation animation
- [ ] Write component tests

**Deliverables**:

- `/src/components/dao/treasury/treasury-signing-modal.tsx` (~400-500 lines)
- `/src/components/dao/treasury/__tests__/treasury-signing-modal.test.tsx` (~200-300 lines)

---

### Phase 3: Execution Progress Integration (2-3 hours)

**Tasks**:

- [ ] Remove "View on Safe UI" link
- [ ] Add "Sign Transaction" button
- [ ] Integrate signing modal
- [ ] Add signer status checks
- [ ] Update signature completion handler
- [ ] Test full signing flow

**Deliverables**:

- Modified `/src/components/dao/treasury/execution-progress.tsx`

---

### Phase 4: Testing & Validation (4-6 hours)

**Tasks**:

- [ ] Unit tests for signing service
- [ ] Component tests for signing modal
- [ ] Integration tests for full signing flow
- [ ] Test with multiple signers
- [ ] Test error scenarios (network failures, wallet rejection)
- [ ] Test on Base mainnet with real Safe

**Deliverables**:

- Comprehensive test suite
- Test report document

---

## Security Considerations

### Authentication & Authorization

**Signer Verification**:

```typescript
// Before allowing signature, verify:
1. User is connected via Privy
2. User's wallet address matches a Safe owner
3. User hasn't already signed this transaction
4. Transaction is still pending (not executed)
```

**Transaction Validation**:

```typescript
// Before signing, validate:
1. Safe transaction hash matches proposal metadata
2. Transaction details match proposal (amount, recipient)
3. Transaction hasn't been executed yet
4. Safe has sufficient balance
```

### Error Handling

**Wallet Connection Errors**:

- User not logged in → Show login prompt
- Wallet connection failed → Retry with clear error message
- Wrong network → Prompt network switch to Base

**Signing Errors**:

- User rejected signature → Show friendly message, allow retry
- Network timeout → Retry with exponential backoff
- Safe API unavailable → Show status and suggest retry later

**Security Errors**:

- User not a signer → Clear error message, hide sign button
- Transaction already executed → Show completed status
- Insufficient Safe balance → Warning before signing attempt

---

## Technical Specifications

### Safe Protocol Kit Integration

**Installation**:

```bash
yarn install @safe-global/api-kit@latest
```

**Initialization**:

```typescript
import { Safe, EthersAdapter } from '@safe-global/protocol-kit';
import { SafeApiKit } from '@safe-global/api-kit';
import { ethers } from 'ethers';

// Get user's wallet from Privy
const privyWallet = await getPrivyWallet();
const signer = await privyWallet.getSigner();

// Create Ethers adapter
const ethAdapter = new EthersAdapter({
  ethers,
  signerOrProvider: signer,
});

// Initialize Safe instance
const safe = await Safe.create({
  ethAdapter,
  safeAddress: '0x...',
});

// Initialize API Kit
const apiKit = new SafeApiKit({
  chainId: 8453n, // Base mainnet
  txServiceUrl: 'https://safe-transaction-base.safe.global',
});
```

**Signing Transaction**:

```typescript
// Get pending transaction from Safe API
const transaction = await apiKit.getTransaction(safeTxHash);

// Sign transaction
const signature = await safe.signTransactionHash(transaction.safeTxHash);

// Submit signature to Safe API
await apiKit.confirmTransaction(safeTxHash, signature.data);
```

---

### Database Updates

**Execution Status Schema** (already in Proposal type):

```typescript
executionStatus: {
  status: 'collecting_signatures' | 'executing' | 'completed',
  safeTxHash: string,
  signaturesCollected: number,
  signaturesRequired: number,
  signedBy: string[], // User IDs who have signed
  pendingSigners: string[], // User IDs yet to sign
  lastUpdated: Timestamp,
  signatures: {
    userId: string,
    address: string,
    signedAt: Timestamp,
    signature: string
  }[]
}
```

**Update After Signature**:

```typescript
// Update execution status in Supabase
await supabase
  .from('proposal_execution_status')
  .update({
    signed_by: [...existingSignedBy, userId],
    pending_signers: pendingSigners.filter((id) => id !== userId),
    signatures_collected: signaturesCollected + 1,
    last_updated: new Date().toISOString(),
  })
  .eq('proposal_id', proposalId);

// Insert signature record
await supabase.from('proposal_signatures').insert({
  proposal_id: proposalId,
  user_id: userId,
  address: userAddress,
  signed_at: new Date().toISOString(),
  signature: signature.data,
});
```

---

## User Experience Flow

### Happy Path

1. **User sees proposal passed** → Execution Progress shows "2/3 signatures"
2. **User clicks "Sign Transaction"** → Modal opens with transaction details
3. **User reviews details** → Amount, recipient, reason all displayed clearly
4. **User confirms** → Privy wallet prompt appears
5. **User signs in wallet** → Signature submitted automatically
6. **Success confirmation** → Progress updates to "3/3 signatures", execution begins
7. **Modal auto-closes** → User returns to updated proposal view

### Error Paths

**Not a Signer**:

- Sign button is hidden
- Badge shows "Not a signer"
- User can view progress but not sign

**Already Signed**:

- Sign button is disabled
- Badge shows "Signed" with checkmark
- User's signature shows in signer list

**Wallet Connection Failed**:

- Modal shows error
- "Retry Connection" button appears
- Clear error message explains issue

**Signature Rejected**:

- Modal shows friendly message
- "Try Again" button available
- Transaction remains unsigned

---

## Migration Strategy

### Deployment Plan

**Phase 1: Add In-App Signing** (Keep both options)

- Deploy new signing modal and service
- Add "Sign in EnDAO" button alongside existing "View on Safe UI" link
- Monitor usage and error rates
- Gather user feedback

**Phase 2: Make In-App Primary** (After 1 week)

- Make "Sign in EnDAO" the primary action (larger button)
- Move "View on Safe UI" to secondary (smaller link)
- Continue monitoring

**Phase 3: Remove External Link** (After 2 weeks if successful)

- Remove "View on Safe UI" link entirely
- Keep in-app signing only
- Update documentation

### Rollback Plan

If issues arise:

1. Feature flag to disable in-app signing
2. Revert to "View on Safe UI" link
3. Fix issues in preview environment
4. Re-deploy when stable

---

## Testing Checklist

### Unit Tests

- [ ] SafeSigningService initializes correctly
- [ ] Signer verification logic works
- [ ] Signature submission handles errors
- [ ] Transaction validation catches invalid data

### Integration Tests

- [ ] Full signing flow with real Safe on testnet
- [ ] Multiple signers can sign in sequence
- [ ] Execution triggers after threshold reached
- [ ] Error recovery works for all error types

### E2E Tests

- [ ] Create treasury proposal → sign → execute
- [ ] Test with 1-of-1, 2-of-3, and 3-of-5 Safe configurations
- [ ] Test signature rejection and retry
- [ ] Test network failures and recovery

---

## Dependencies

### npm Packages

- `@safe-global/protocol-kit@^4.1.7` ✅ Installed
- `@safe-global/api-kit@latest` ❌ Need to install
- `@privy-io/react-auth` ✅ Installed
- `ethers@^6.15.0` ✅ Installed

### External Services

- Gnosis Safe Transaction Service API (Base mainnet)
- Privy wallet connection
- Supabase real-time updates

---

## Success Metrics

**User Experience**:

- 90%+ of users complete signing within EnDAO
- <5% error rate on signature submissions
- Average signing time <60 seconds

**Technical**:

- <500ms response time for signer verification
- <2s for signature submission
- 99.9% uptime for signing service

**Business**:

- Reduced support tickets related to treasury signing
- Increased treasury proposal execution rate
- Positive user feedback on signing experience

---

## Timeline

**Total Estimated Time**: 16-23 hours

| Phase                    | Duration | Deliverables              |
| ------------------------ | -------- | ------------------------- |
| Phase 1: Signing Service | 4-6h     | Service + tests           |
| Phase 2: Signing Modal   | 6-8h     | Component + tests         |
| Phase 3: Integration     | 2-3h     | Updated ExecutionProgress |
| Phase 4: Testing         | 4-6h     | Full test suite           |

**Target Completion**: 3-4 days with focused work

---

## Related Documentation

- Wave 4 Treasury Execution Status Implementation
- Gnosis Safe Protocol Kit Documentation: https://docs.safe.global/sdk/protocol-kit
- Privy Wallet Integration Guide
- EnDAO Treasury Architecture (CLAUDE.md)

---

**Status**: Ready for implementation pending user approval
**Next Steps**: Install @safe-global/api-kit and begin Phase 1
