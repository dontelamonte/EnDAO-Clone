# Treasury System API Reference

## Purpose

This document provides comprehensive API documentation for the EnDAO treasury system, including core services, API endpoints, type definitions, and code examples for common operations.

## Last Updated

September 2025

---

## Table of Contents

1. [Core Services API](#core-services-api)
2. [REST API Endpoints](#rest-api-endpoints)
3. [Type Definitions](#type-definitions)
4. [Service Response Pattern](#service-response-pattern)
5. [Code Examples](#code-examples)

---

## Core Services API

### 1. Treasury Access Control Service

**Purpose:** Validates all treasury operations against DAO status and freeze state.

#### Methods

**Key Methods:**

- `isTreasuryAccessible(daoId)` → `ServiceResponse<TreasuryAccessStatus>`
- `validateTreasuryOperation(daoId, userId, operation, authContext)` → `ServiceResponse<TreasuryOperationValidation>`
- `freezeTreasury(daoId, userId, reason, authContext, metadata?)` → Freezes treasury
- `unfreezeTreasury(daoId, userId, authContext, unfreezeReason?)` → Unfreezes treasury
- `checkMultipleTreasuryAccess(daoIds[])` → Batch access check

**Example:**

```typescript
const result = await treasuryAccessControlService.isTreasuryAccessible(daoId);
if (result.success && result.data?.accessible) {
  // Proceed with operation
}
```

---

### 2. DAO Soft Delete Service

**Purpose:** Manages the 7-day grace period for DAO deletion with treasury protection.

**Key Methods:**

- `initiateDeletion(daoId, adminId, reason, authContext, gracePeriodDays?)` → Starts deletion with grace period
- `recoverDAO(daoId, adminId, authContext, recoveryReason?)` → Recovers DAO during grace period
- `getGracePeriodStatus(daoId)` → Gets current grace period status
- `executeDeletion(daoId, executorId, authContext)` → Executes deletion after grace period

**Example:**

```typescript
const result = await daoSoftDeleteService.initiateDeletion(
  daoId,
  adminId,
  reason,
  authContext,
  7
);
// Returns: { deletionRecordId, gracePeriodStatus, treasuryFrozen, notificationsSent }
```

---

### 3. Treasury Notification Service

**Purpose:** Manages multi-channel notifications for treasury protection events.

**Key Methods:**

- `notifyDAODeletionWarning(daoId, deletionDate, initiatedBy, daoMetadata)` → Deletion warning
- `notifyRecoveryCompleted(daoId, recoveredBy)` → Recovery completion notice
- `notifyTreasuryFrozen(daoId, frozenBy, reason)` → Treasury freeze alert
- `notifyGracePeriodReminder(daoId, daysRemaining, deletionDate)` → Grace period reminder
- `notifyEmergencyFreeze(daoId, freezeReason, initiatedBy)` → Emergency freeze alert

---

### 4. Treasury Recovery Service

**Purpose:** Provides super admin emergency recovery capabilities.

**Key Methods:**

- `emergencyRecoverDAO(daoId, superAdminId, reason, authContext, recoveryType, override?)` → Emergency DAO recovery
- `bulkRecoveryOperation(daoIds, superAdminId, reason, authContext)` → Bulk recovery for incidents
- `emergencyUnfreezeTreasury(daoId, superAdminId, reason, authContext, override?)` → Emergency unfreeze

**Example:**

```typescript
const result = await treasuryRecoveryService.emergencyRecoverDAO(
  daoId,
  superAdminId,
  'Malicious deletion',
  authContext,
  'malicious_deletion',
  true
);
// Returns: { daoRecovered, treasuryUnfrozen, executionTime }
```

---

## REST API Endpoints

### Create Treasury

**POST** `/api/treasury/v2/create-safe`

Creates a new L2-optimized Safe for a DAO.

**Request:**

```json
{
  "daoId": "dao-id",
  "adminWallets": ["0x..."] // Optional, uses deployer if empty
}
```

**Response:**

```json
{
  "success": true,
  "safeAddress": "0x...",
  "owners": ["0x..."],
  "threshold": 1,
  "isDeployed": true,
  "version": "1.4.1+L2",
  "l2Optimized": true,
  "message": "L2-optimized Treasury Safe created and deployed successfully"
}
```

**Error Response:**

```json
{
  "success": false,
  "error": "Error message",
  "metadata": {
    "code": "ERROR_CODE",
    "details": {}
  }
}
```

---

## Type Definitions

### Treasury Access Status

```typescript
interface TreasuryAccessStatus {
  accessible: boolean;
  reason?:
    | 'dao_deleted'
    | 'dao_archived'
    | 'dao_pending_deletion'
    | 'treasury_frozen'
    | 'dao_not_found';
  details?: string;
  daoStatus?: DAOStatus;
  frozenAt?: Date;
  frozenBy?: string;
  frozenReason?: string;
}
```

### Grace Period Status

```typescript
interface GracePeriodStatus {
  isPending: boolean;
  gracePeriodDays: number;
  daysRemaining: number;
  hoursRemaining: number;
  scheduledDeletionDate: Date;
  canRecoverUntil: Date;
  initiatedBy: string;
  initiatedAt: Date;
  reason: string;
}
```

### Notification Types

```typescript
type TreasuryNotificationType =
  | 'dao_deletion_warning' // When DAO deletion is initiated
  | 'treasury_frozen' // When treasury is frozen
  | 'recovery_completed' // When DAO is recovered
  | 'grace_period_reminder' // Daily reminders during grace period
  | 'emergency_freeze' // Emergency treasury freeze
  | 'grace_period_final' // Final warning before deletion
  | 'treasury_unfrozen'; // When treasury freeze is lifted
```

### Service Response Pattern

```typescript
interface ServiceResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  metadata?: Record<string, any>;
}
```

---

## Code Examples

### Example: Complete Treasury Transfer

```typescript
// 1. Check access
const accessCheck = await treasuryAccessControlService.isTreasuryAccessible(daoId)
if (!accessCheck.data?.accessible) return { error: accessCheck.data?.reason }

// 2. Validate operation
const validation = await treasuryAccessControlService.validateTreasuryOperation(
  daoId, userId, 'transfer_funds', authContext
)
if (!validation.data?.isValid) return { errors: validation.data?.errors }

// 3. Execute and log
const result = await executeTransfer(daoId, amount, recipient)
await auditCoreService.logTreasuryEvent('treasury.transfer', 'success', ...)
```

### Example: Batch Access Check

```typescript
const daoIds = ['dao1', 'dao2', 'dao3'];
const batchResult =
  await treasuryAccessControlService.checkMultipleTreasuryAccess(daoIds);
// Process each DAO's access status
```

### Example: Grace Period Workflow

```typescript
// Initiate deletion with 7-day grace period
const deletion = await daoSoftDeleteService.initiateDeletion(
  daoId,
  adminId,
  reason,
  authContext,
  7
);
// Monitor status and send reminders as needed
```

---

_For integration examples and best practices, see [Integration Guide](./integration-guide.md)_
