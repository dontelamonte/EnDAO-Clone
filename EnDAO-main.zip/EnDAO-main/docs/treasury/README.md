# EnDAO Treasury System

## Overview

The EnDAO treasury system provides secure, multi-signature wallet management for DAOs using Gnosis Safe technology. Our implementation uses L2-optimized Safe contracts (v1.4.1+L2) on Base network for reduced gas costs while maintaining the same security guarantees.

## Architecture

### Core Components

- **Service Layer**: `/src/lib/services/safe-l2.service.ts` - L2-optimized Safe deployment and management
- **API Endpoint**: `/src/app/api/treasury/v2/create-safe/route.ts` - REST API for treasury creation
- **Configuration**: `/src/config/safe-contracts.ts` - Contract addresses and network configuration
- **UI Components**: `/src/components/treasury/` - React components for treasury interface

### Technology Stack

- **Smart Contracts**: Gnosis Safe v1.4.1+L2
- **Blockchain**: Base (Layer 2 Ethereum)
- **Web3 Provider**: Ethers.js v5
- **Safe SDK**: @safe-global/protocol-kit

## Features

### Current Features

- ✅ L2-optimized Safe deployment
- ✅ Multi-signature wallet creation
- ✅ Automatic DAO admin assignment as Safe owners
- ✅ Configurable signature threshold
- ✅ Base Sepolia testnet support
- ✅ Safe balance checking
- ✅ Transaction sending (for testing)

### Planned Features

- 🔄 Base mainnet deployment
- 🔄 Transaction queue management
- 🔄 Treasury analytics dashboard
- 🔄 Automated fund distribution
- 🔄 Token management support

## Production Deployment

### Current Platform Revenue Deployment (Testnet)

- **Network**: Base Sepolia (Chain ID: 84532)
- **EnDAO Safe**: `0x00dc44400adb57a85364c97442bd5e95faa861e7` (Revenue Collection)
- **FeeRouter Contract**: `0xf8786857eD04621d6e81959aAb36e422F687E4c8`
- **Safe Version**: 1.4.1+L2 (L2-optimized)
- **View Safe**: [Safe App Link](https://app.safe.global/home?safe=base-sepolia:0x00dc44400adb57a85364c97442bd5e95faa861e7)
- **View Contract**: [BaseScan Link](https://sepolia.basescan.org/address/0xf8786857eD04621d6e81959aAb36e422F687E4c8)

### Example DAO Safe (Test Deployment)

- **Test Safe**: `0x87C68E1D71e8CA215Caa179F51F609ce94c1b71C`
- **Purpose**: DAO treasury testing and development
- **View Test Safe**: [Safe App Link](https://app.safe.global/home?safe=basesep:0x87C68E1D71e8CA215Caa179F51F609ce94c1b71C)

### Environment Variables

```env
# Base Sepolia RPC
NEXT_PUBLIC_BASE_SEPOLIA_RPC_URL=https://sepolia.base.org

# Safe Configuration
SAFE_DEPLOYER_PRIVATE_KEY=your-deployer-key
SAFE_API_KEY=optional-safe-api-key
NEXT_PUBLIC_SAFE_SERVICE_URL=https://safe-transaction-base-sepolia.safe.global
```

## Documentation

### Getting Started

**New to the treasury system?** Start here:

- **[Quick Start Guide](./quick-start.md)** - Get up and running in minutes with essential setup, basic operations, and quick reference

### For Developers

Choose your focus area:

- **[API Reference](./api-reference.md)** - Complete API documentation for all treasury services, endpoints, and type definitions
- **[Integration Guide](./integration-guide.md)** - Frontend integration with React hooks, component patterns, and database schema
- **[Advanced Topics](./advanced-topics.md)** - Production deployment, performance optimization, security testing, and troubleshooting

### For End Users

- **[Treasury User Guide](./TREASURY_USER_GUIDE.md)** - Complete user-facing documentation for treasury operations

### Specialized Topics

- **[Treasury Protection](./TREASURY_PROTECTION.md)** - Four-layer protection system and security measures
- **[Security & Threat Model](./security/threat-model.md)** - Security architecture and threat analysis
- **[DAO Wallet Permissions](./dao-wallet-user-permissions.md)** - User permission model for treasury operations

## Quick Links

### Contract Addresses (L2-Optimized v1.4.1+L2)

- **Safe Singleton**: `0x29fcB43b46531BcA003ddC8FCB67FFE91900C762`
- **Proxy Factory**: `0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67`
- **Fallback Handler**: `0xfd0732Dc9E303f09fCEf3a7388Ad10A83459Ec99`

### External Resources

- [Gnosis Safe Documentation](https://docs.safe.global/)
- [Base Network Documentation](https://docs.base.org/)
- [Safe SDK Reference](https://github.com/safe-global/safe-core-sdk)
- [L2 Optimization Details](https://github.com/safe-global/safe-smart-account/releases/tag/v1.4.1)

## Support

For treasury-related issues:

1. Check the documentation links above for your specific use case
2. Review deployment logs in console for technical issues
3. Verify contract addresses in `/src/config/safe-contracts.ts`
4. Contact development team for assistance
