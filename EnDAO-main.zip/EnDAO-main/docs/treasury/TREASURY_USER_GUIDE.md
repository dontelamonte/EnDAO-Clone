# Treasury User Guide: Complete Protection & Management System

## Purpose

This guide provides comprehensive instructions for EnDAO users to understand and interact with the treasury protection system, from setup through daily operations and troubleshooting.

## Last Updated

February 2026

## Overview

This comprehensive guide covers treasury protection and management for group administrators and treasury signers. The treasury protection system automatically protects your organization's funds during critical operations through defense-in-depth security architecture.

---

## Table of Contents

1. [Understanding Your Role](#understanding-your-role)
2. [Treasury Protection System](#treasury-protection-system)
3. [Group Deletion Process](#group-deletion-process)
4. [Admin Dashboard Guide](#admin-dashboard-guide)
5. [Notification System](#notification-system)
6. [Protection Status Dashboard](#protection-status-dashboard)
7. [Emergency Situations](#emergency-situations)
8. [Security Best Practices](#security-best-practices)
9. [Troubleshooting](#troubleshooting)
10. [FAQ](#frequently-asked-questions)

---

## Understanding Your Role

### Group Administrator Role

As a group admin, you have the ability to manage your organization, including the critical responsibility of handling deletion requests. Your responsibilities include:

- **Manage organization operations** including members, proposals, and settings
- **Handle deletion requests** with understanding of treasury protection implications
- **Monitor protection alerts** and respond appropriately
- **Coordinate with treasury signers** during critical operations
- **Access admin protection dashboard** for detailed status monitoring

### Treasury Signer Role

As a treasury signer, you have co-signing authority over your organization's funds. Your responsibilities include:

- **Monitor treasury security alerts** and respond to protection notifications
- **Understand when treasury access is restricted** and why
- **Know how to escalate security concerns** when needed
- **Respond appropriately to deletion warnings** and protection events
- **Maintain security best practices** for your account and access

### Shared Protections

Both roles benefit from:

- **Automatic treasury freeze** during risky operations
- **Immediate notifications** for critical events
- **7-day grace period** for deletion recovery
- **Emergency recovery options** for extreme situations

---

## Treasury Protection System

### What is Treasury Protection?

Treasury protection is a security system that automatically protects your organization's funds during critical operations like deletion. The system implements defense-in-depth security with multiple layers of protection.

### How It Works

When critical operations are detected, the system:

1. **Immediately freezes your treasury** to prevent any fund movements
2. **Starts a 7-day grace period** where you can cancel the deletion
3. **Sends notifications** to all treasury signers and admins
4. **Maintains complete access** to all other group functions during this period

### Why We Have This System

- **Prevent accidental deletion**: Gives you time to reconsider
- **Protect against malicious actions**: Even if an admin goes rogue, funds stay safe
- **Ensure compliance**: Provides audit trails for regulatory requirements
- **Peace of mind**: Treasury signers know their funds are protected

### Protection Triggers

The system automatically activates when:

- Group deletion is initiated
- Security incidents are detected
- System errors affect treasury access
- Emergency situations require intervention

**Protection is automatic** - you don't need to take any action for the system to protect your funds.

---

## Group Deletion Process

### Step 1: Initiating Deletion (Admin Action)

When an admin clicks "Delete Group" in the admin panel:

**What happens immediately:**

- Group status changes to "Pending Deletion"
- Treasury is automatically frozen
- 7-day countdown begins
- Notifications are sent to all treasury signers and admins

**Important:** This action cannot be undone instantly. You'll need to go through the recovery process.

### Step 2: Grace Period (7 Days)

During the 7-day grace period:

**✅ What you CAN do:**

- Access all group functions except treasury operations
- Manage members and proposals
- View treasury balance (read-only)
- Cancel the deletion at any time
- Communicate with members about the situation

**❌ What you CANNOT do:**

- Make treasury transactions
- Transfer funds
- Create funding proposals that execute
- Access co-signing functions

**Treasury Status Indicator:**

```
🔒 Treasury Frozen - Group Deletion in Progress
⏰ 5 days remaining to cancel deletion
🔄 Cancel Deletion Available
```

### Step 3: Recovery (Canceling Deletion)

**For Group Admins** - To cancel the deletion and restore full access:

1. **Go to Admin Panel**
   - Navigate to `/dao/{your-group-id}/admin?tab=protection`
   - You'll see the protection status dashboard

2. **Click "Cancel Deletion"**
   - Confirm your decision
   - Enter a reason for canceling (optional but recommended)

3. **Immediate Results**
   - Group status returns to "Active"
   - Treasury is unfrozen
   - All treasury functions resume
   - Recovery notification is sent to treasury signers

**For Treasury Signers** - If admins are unresponsive:

- Contact admins immediately through organization channels
- Escalate to platform support for emergency intervention
- Provide evidence if deletion appears malicious

### Step 4: What Happens if No Action is Taken

If the 7-day grace period expires without action:

**⚠️ Final Warning (24 hours before):**

- Critical notifications sent to all treasury signers
- Last chance to recover through normal process

**🚨 After Grace Period Expires:**

- Group is permanently deleted
- Treasury remains frozen
- Only super admin emergency recovery possible
- Much more complex recovery process required

---

## Admin Dashboard Guide

### Accessing the Admin Dashboard

Navigate to: **Admin Panel → Protection Tab** at `/dao/{group-id}/admin?tab=protection`

### Dashboard Sections

#### 1. Current Status

```
Status: Active | Pending Deletion | Deleted
Treasury: Accessible | Frozen | Emergency Frozen
Grace Period: Not Active | X days remaining | Expired
```

#### 2. Protection History

- Previous deletion attempts
- Recovery actions taken
- System-generated protection events

#### 3. Quick Actions

- **Cancel Deletion** (if in grace period)
- **Test Notifications** (verify alert delivery)
- **Contact Support** (for emergency situations)

#### 4. Treasury Status

- Current freeze status and reason
- Signers who will receive notifications
- Treasury balance (read-only during freeze)

### Treasury Admin Execution Dashboard

For co-signed treasury operations, navigate to: `/dao/{group-id}/treasury/admin`

#### Access Requirements

- Must be a group admin or treasury admin
- Shows your admin number (Admin 1 or Admin 2)
- Displays signature requirements (2-of-2 co-signing)

#### Visual Status Indicators

- **Blue badge**: "Needs Initiation" - Any admin can start
- **Orange badge**: "Needs Your Signature" - You need to sign
- **Yellow badge**: "Waiting for Co-Admin" - Other admin must sign
- **Green badge**: "Ready to Execute" - Fully signed, ready for submission

#### Treasury Execution Flow

**Step 1: Initiate**

1. Find proposal showing "Needs Initiation"
2. Click "Initiate Execution" button
3. Wait for confirmation toast

**Step 2: Sign (Both Admins)**

1. First admin: Click "Sign Transaction"
2. Toast shows "Signature 1/2 added"
3. Second admin: Refresh and click "Sign Transaction"
4. Toast shows "Signature 2/2 added. Ready to execute!"

**Step 3: Execute (Gasless)**

1. Button changes to "Submit Transaction (Gasless)"
2. Click to submit via Gelato (no gas fees required)
3. Toast shows "Transaction submitted 🚀"
4. Status updates to "Completed" when done

---

## Notification System

### Who Gets Notified?

**Automatic notifications are sent to:**

- All treasury signers
- All group admins
- Any additional emails configured in settings

### Notification Types

#### 1. Group Deletion Warning (🚨 Critical)

**When received:** Your organization has been scheduled for deletion by an admin.

**Example notification:**

```
🚨 Group Deletion Warning: [Organization Name]

Your organization has been scheduled for deletion in 7 days.

What this means:
• Your organization will be permanently removed if no action is taken
• All funds in your treasury are now frozen and protected
• You have 7 days to cancel this deletion

What you need to do:
1. Log into your dashboard
2. Go to the Protection tab
3. Click "Cancel Deletion" to save your organization

Your organization's funds are protected during this process.
```

**Admin Response:**

- **If deletion is expected:** Monitor for any changes in plans
- **If deletion is unexpected:** Immediately cancel deletion in admin panel

**Treasury Signer Response:**

- **If deletion is expected:** No action needed - funds are protected
- **If deletion is unexpected:** Contact admins immediately and escalate if unresponsive

#### 2. Grace Period Reminders (⏰ Warning)

Regular updates during the 7-day deletion countdown sent at:

- **Day 5**: Regular reminder with status update
- **Day 3**: Urgent reminder with instructions
- **Day 1**: Final warning with immediate action required

#### 3. Final Warning (🚨 Critical)

**24 hours remaining** before permanent deletion - immediate action required.

#### 4. Treasury Frozen (🔒 High Priority)

Treasury has been frozen for security reasons outside of deletion process.

#### 5. Recovery Completed (✅ Informational)

Organization has been recovered and treasury is unfrozen.

#### 6. Emergency Freeze (🚨 Critical)

Immediate emergency freeze due to security incident - contact support immediately.

### Testing Notifications

To verify that notifications are working:

1. Go to **Admin Panel → Protection Tab**
2. Click **"Test Notifications"**
3. Check that all treasury signers receive the test message
4. Fix any delivery issues before they become critical

---

## Protection Status Dashboard

### Key Information to Monitor

#### Treasury Status Indicators

```
🟢 Active - Normal operations
🟡 Frozen - Temporarily restricted
🔴 Emergency Frozen - Critical security restriction
```

#### Protection Status

```
✅ Protected - Security systems active
⏳ Grace Period - Deletion countdown active
🚨 Critical - Immediate attention needed
```

#### Recent Activity

- Admin actions that affect treasury
- Security events and notifications
- Protection system activations

### What You Can and Cannot Do

#### During Normal Operations

**✅ You CAN:**

- Approve treasury transactions
- Monitor treasury balance
- Access all treasury functions
- Participate in funding proposals

**ℹ️ Always verify:** Large transactions and emergency requests

#### During Treasury Freeze

**❌ You CANNOT:**

- Approve new treasury transactions
- Execute pending transactions
- Access transaction interfaces
- Process funding proposals

**✅ You CAN:**

- View treasury balance (read-only)
- Access organization information
- Communicate with admins and members
- Monitor protection status

---

## Emergency Situations

### When to Escalate

**Immediate escalation needed:**

- Unexpected deletion notifications
- Suspicious admin activity
- Inability to contact admins during critical period
- System errors affecting treasury access
- Security alerts without explanation

### How to Escalate

#### Level 1: Contact Organization Admins

- Use organization communication channels
- Ask for immediate explanation of the situation
- Request cancellation if deletion is inappropriate

#### Level 2: Platform Support

- Use official support channels
- Provide specific details about the situation
- Include organization ID and your account information

#### Level 3: Emergency Recovery

- Contact super admins for critical situations
- Provide evidence of malicious activity
- Request immediate intervention

### What Information to Provide

**Always include:**

- Organization name and ID
- Your account email (for verification)
- Description of the issue
- Screenshots of notifications/dashboard
- Timeline of events

**For suspected security incidents:**

- Evidence of suspicious activity
- Recent admin changes
- Unusual transaction patterns
- Communication attempts with admins

### Recovery Scenarios

#### Normal Recovery (During Grace Period)

**Timeframe:** Immediate (< 5 minutes)
**Requirements:** Valid admin access
**Process:** Simple button click in admin panel

**Steps:**

1. Admin Panel → Protection Tab
2. Click "Cancel Deletion"
3. Confirm action
4. Treasury automatically unfrozen

#### Emergency Recovery (After Grace Period)

**Timeframe:** Variable (hours to days)
**Requirements:** Super admin intervention
**Process:** Formal recovery request

**Steps:**

1. Contact platform support immediately
2. Provide detailed justification for recovery
3. Super admin reviews and approves request
4. Emergency recovery process initiated
5. Treasury and group manually restored

**Required Information:**

- Group ID and organization name
- Reason for deletion and recovery request
- Contact information for verification
- Any relevant documentation

---

## Security Best Practices

### Account Security

- **Keep your account secure** - use strong authentication
- **Use strong passwords** for admin accounts
- **Enable 2FA** when available
- **Monitor access logs** regularly

### Treasury Protection

- **Understand the system** - know how protection works
- **Verify treasury signers** - ensure correct people get notifications
- **Keep contact info current** - update emails when they change
- **Document procedures** - have clear processes for your organization

### Monitoring & Vigilance

- **Review treasury activity regularly** - understand normal patterns
- **Know your fellow signers** - maintain communication
- **Understand admin roles** - know who can make critical decisions
- **Monitor notifications closely** - check email regularly

### Red Flags to Watch For

- **Unexpected deletion notifications** - especially without prior discussion
- **New admins added suddenly** - without proper introduction
- **Large transactions** - during unusual times or circumstances
- **Multiple security alerts** - pattern of concerning activity
- **Unresponsive admins** - during critical periods

### Incident Response

- **Have an emergency plan** - know who to contact and how
- **Document everything** - keep records of all actions
- **Communicate clearly** - keep stakeholders informed
- **Follow procedures** - don't try to circumvent protection systems

---

## Troubleshooting

### Common Issues

#### "Treasury Access Denied"

**Cause:** Treasury operations are blocked due to protection system

**Solution:**

1. Check group status in admin panel
2. If "Pending Deletion" - cancel deletion to restore access
3. If "Active" but treasury frozen - contact support
4. Verify you're not trying to access during maintenance

#### "Cannot Cancel Deletion"

**Possible Causes:**

- Grace period has expired
- System error or technical issue
- Insufficient admin permissions

**Solutions:**

1. **If grace period expired:** Contact super admin for emergency recovery
2. **If system error:** Use support channels immediately
3. **If permission issue:** Verify you have admin access to the group

#### "Notifications Not Received"

**Troubleshooting Steps:**

1. Check spam/junk folders
2. Verify email addresses in group settings
3. Test notification delivery in admin panel
4. Contact support if delivery consistently fails

#### "Treasury Shows as Frozen but Group is Active"

**Possible Causes:**

- Previous deletion was canceled but treasury not unfrozen
- System error during recovery process
- Emergency freeze due to security incident

**Immediate Actions:**

1. Check protection dashboard for status details
2. Look for any emergency notifications
3. Contact support with specific error details
4. Do not attempt treasury operations until resolved

#### Admin Dashboard Issues

#### "Network Error" messages

- These are RPC connection warnings
- Don't affect functionality
- Gelato will handle actual blockchain interaction

#### Button not changing after action

1. Click "Refresh" button
2. Wait 1-2 seconds for state propagation
3. Check browser console for errors

#### Can't see dashboard

1. Verify you're logged in as an admin
2. Check DAO ID in URL is correct
3. Clear browser cache/cookies
4. Check console for debug logs

---

## Technical Understanding

### How Treasury Co-Signing Works

Your organization uses a secure co-signing system for treasury management. The protection system:

1. **Monitors group status** - watches for critical state changes
2. **Coordinates with treasury** - manages access at the platform level
3. **Blocks platform access** - prevents organization admins from initiating transactions
4. **Preserves signer control** - you maintain your signing authority

**Important:** The protection system manages access at the platform level, preventing admins from creating transactions during protection events.

### Data & Privacy

**What the system tracks:**

- Treasury protection events
- Notification delivery status
- Organization status changes
- Admin actions affecting treasury

**What the system does NOT track:**

- Your personal transaction history
- Private communications
- Personal account activities

---

## Frequently Asked Questions

### General Questions

#### Q: Can I speed up the grace period?

A: No, the 7-day grace period is fixed for security reasons. However, you can cancel the deletion immediately at any time during this period.

#### Q: What happens to proposals during the grace period?

A: Most group functions continue normally. However, funding proposals cannot execute because the treasury is frozen.

#### Q: Are there fees for canceling deletion?

A: No, canceling deletion is free and encouraged if the deletion was accidental.

#### Q: Can I delete the group immediately without the grace period?

A: No, the 7-day grace period is mandatory for all deletions to protect treasury funds.

#### Q: Does the protection system work for all treasury types?

A: Yes, protection works for all treasuries integrated with the platform.

### Treasury Signer Specific Questions

#### Q: What if I disagree with a deletion decision?

A: Contact organization admins first. If unsuccessful, escalate to platform support for emergency recovery assistance.

#### Q: How long do freezes typically last?

A: Normal deletion grace periods last 7 days. Emergency freezes are resolved as quickly as possible, usually within 24-48 hours.

#### Q: Can multiple signers act independently during protection events?

A: Yes, any treasury signer can escalate concerns independently. However, coordination with other signers is recommended.

#### Q: What if I'm traveling and miss critical notifications?

A: The system sends multiple reminders over 7 days. If you miss them, other signers may also receive alerts and can escalate if needed.

### Admin Specific Questions

#### Q: Can treasury signers override the admin deletion?

A: No, but treasury signers can request emergency recovery from super admins if they believe the deletion is malicious.

#### Q: What if I lose admin access during the grace period?

A: Contact support immediately. They can help verify your identity and assist with recovery.

#### Q: Are there fees for protection system activation?

A: No, the protection system is free and automatic. There are no fees for freezes, notifications, or recovery operations.

#### Q: Can I opt out of protection notifications?

A: No, these are critical security notifications that cannot be disabled. However, you can update your contact information to ensure proper delivery.

---

## Emergency Contacts

**For urgent treasury protection issues:**

**Platform Support:**

- Email: [Support email]
- Emergency line: [Emergency contact]
- Response time: <4 hours for critical issues

**Super Admin Emergency Recovery:**

- Contact: [Super admin contact]
- Use only for: Malicious deletions, compromised admins, system failures
- Response time: <24 hours

**Remember:** The protection system is designed to keep your funds safe. When you receive notifications, take them seriously and respond appropriately. When in doubt, contact support rather than ignoring alerts.

---

## Resources

- [Treasury System Technical Documentation](./README.md)
- [Security & Threat Model](./security/threat-model.md)
- [Deployment Guide](./deployment-guide.md)
- [Integration Guide](./dev/integration-guide.md)
