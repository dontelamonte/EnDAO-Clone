# Treasury Protection System

## Purpose

Complete documentation for the Treasury Protection System, a comprehensive security framework that safeguards organization funds during critical operations like DAO deletion. This document provides navigation, system overview, architecture details, and quick-start guides for all user roles.

## Last Updated

September 2025

## Overview

The Treasury Protection System provides defense-in-depth security for organization funds through multiple protection layers, automated alerts, and recovery mechanisms. The system ensures treasury assets remain secure even during emergency situations.

**Core Philosophy**: "Protect first, act second" - Every treasury operation is validated against multiple security layers before execution.

## Quick Start by Role

### For DAO Admins

- **Primary Guide**: [DAO Admin Guide](./user-guides/dao-admin-guide.md)
- **Key Actions**: Understand grace periods, cancel deletions, monitor protection status
- **Dashboard**: `/dao/{id}/admin?tab=protection`

### For Safe Owners

- **Primary Guide**: [Safe Owner Guide](./user-guides/safe-owner-guide.md)
- **Key Actions**: Respond to notifications, understand protection alerts, escalate concerns
- **Notifications**: Automatic alerts via email and platform

### For Developers

- **Primary Guide**: [Integration Guide](./dev/integration-guide.md)
- **Key Actions**: Integrate services, implement UI components, handle errors
- **API Reference**: See DEVELOPER_GUIDE.md for complete API documentation

### For Security Teams

- **Primary Guide**: [Security & Threat Model](./security/threat-model.md)
- **Key Actions**: Understand attack vectors, review controls, implement monitoring
- **Compliance**: SOC 2 Type II and GDPR compliant

## System Architecture

### 4-Layer Protection Framework

**Layer 1: DAO Status Validation**

- Blocks treasury access for: `deleted`, `archived`, `pending_deletion`
- Allows operations only for: `active` state
- Real-time validation on every operation

**Layer 2: Treasury Freeze Management**

- Automatic freeze during deletion process
- Manual freeze for security incidents
- Emergency unfreeze with super admin override

**Layer 3: Grace Period Protection**

- 7-day mandatory recovery window
- Treasury frozen throughout grace period
- Multiple recovery opportunities

**Layer 4: Emergency Recovery**

- Super admin override capabilities
- Bulk recovery for system-wide incidents
- Complete audit trail for compliance

### System Components

```
Treasury Protection System
├── TreasuryAccessControlService   (Gateway security)
├── DAOSoftDeleteService          (Grace period management)
├── TreasuryNotificationService   (Multi-channel alerts)
└── TreasuryRecoveryService       (Emergency operations)
```

#### 1. Treasury Access Control Service

**Primary Function**: Gateway security for all treasury operations

**Capabilities:**

- DAO status validation before treasury access
- Treasury freeze/unfreeze management
- Comprehensive audit logging for all access attempts
- Protection against operations on deleted/archived DAOs

#### 2. DAO Soft Delete Service

**Primary Function**: 7-day grace period management

**Protection Workflow:**

1. Deletion Initiated → DAO status changes to `pending_deletion`
2. Treasury Frozen → All treasury operations blocked
3. Notifications Sent → Alerts to Safe owners and admins
4. Grace Period Active → 7-day recovery window
5. Recovery or Execution → Either DAO is recovered or permanently deleted

#### 3. Treasury Notification Service

**Primary Function**: Multi-channel alert system

**Notification Types:**

- DAO Deletion Warning (Critical, immediate)
- Treasury Frozen (Critical, immediate)
- Grace Period Reminders (Days 5, 3, 1)
- Recovery Completed (Confirmation)
- Emergency Freeze (Critical, immediate)

#### 4. Treasury Recovery Service

**Primary Function**: Emergency recovery operations

**Recovery Scenarios:**

- Malicious deletion by unauthorized admin
- System error requiring rollback
- Emergency access for urgent situations
- Compliance incident recovery

## Protection Workflows

### Normal Operations

```
Active DAO → Treasury Accessible → Normal Operations
```

### Deletion Process

```
Delete Request → Treasury Frozen → Grace Period (7 days) → Recovery or Deletion
```

### Emergency Recovery

```
Critical Issue → Emergency Freeze → Super Admin Review → Recovery or Escalation
```

## Key Features

### Automatic Protection

- **Treasury Freeze**: Funds automatically protected during deletion
- **Grace Period**: 7-day recovery window for all deletions
- **Status Validation**: Real-time access control based on DAO state

### Multi-Channel Notifications

- **Immediate Alerts**: Critical notifications for deletion events
- **Scheduled Reminders**: Regular updates during grace period (days 5, 3, 1)
- **User-Friendly Messaging**: Clear explanations for non-crypto users
- **Multiple Channels**: Email, in-app, webhook delivery

### Emergency Recovery

- **Super Admin Override**: Emergency recovery for critical situations
- **Bulk Operations**: Handle multiple DAOs during incidents
- **Comprehensive Auditing**: Complete audit trail for compliance

### Monitoring & Compliance

- **Real-time Monitoring**: System health and security metrics
- **Audit Logging**: Complete audit trail for all operations
- **Compliance Ready**: SOC 2 and GDPR compliance features

## Technical Architecture

### Service Layer Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend Components                      │
├─────────────────────────────────────────────────────────────┤
│                    Service Orchestration                    │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐│
│  │   Access        │ │   Notification  │ │   Recovery      ││
│  │   Control       │ │   Service       │ │   Service       ││
│  └─────────────────┘ └─────────────────┘ └─────────────────┘│
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐│
│  │            DAO Soft Delete Service                      ││
│  └─────────────────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────┤
│                    Data Layer (Supabase)                    │
│  • DAOs Table                                               │
│  • Treasury Freezes Table                                  │
│  • Deletion Tracking Table                                 │
│  • Recovery Requests Table                                 │
│  • Audit Logs Table                                        │
└─────────────────────────────────────────────────────────────┘
```

### Configuration

**Grace Period Settings:**

```typescript
gracePeriodDays: number = 7  // Default: 7 days, range: 1-30 days
recoveryDeadline: Date = deletionDate - 1 hour
```

**Notification Schedule:**

```typescript
reminders: [
  { daysRemaining: 5, type: 'grace_period_reminder' },
  { daysRemaining: 3, type: 'grace_period_reminder' },
  { daysRemaining: 1, type: 'grace_period_final' },
];
```

**Access Control Rules:**

```typescript
blockedStatuses: ['deleted', 'archived', 'pending_deletion'];
allowedStatuses: ['active'];
```

## Frequently Asked Questions

### For All Users

**Q: How long is the grace period for deletion?**
A: 7 days by default. This cannot be shortened but provides multiple opportunities to cancel deletion.

**Q: Are there fees for using the protection system?**
A: No, all protection features are included at no additional cost.

**Q: Can the protection system be disabled?**
A: No, treasury protection is mandatory for all organizations to ensure fund safety.

### For DAO Admins

**Q: Can I speed up deletion if I'm certain?**
A: No, the 7-day grace period is mandatory for security. You can cancel deletion immediately if needed.

**Q: What happens to proposals during grace period?**
A: Most DAO functions continue normally, but treasury-related proposals cannot execute.

**Q: Can I modify the grace period length?**
A: The grace period is fixed at 7 days for security and consistency.

### For Safe Owners

**Q: Can I override an admin's deletion decision?**
A: Not directly, but you can escalate to super admins if you believe the deletion is malicious.

**Q: Do I need to take action when I receive notifications?**
A: Monitor the situation and escalate concerns, but the system automatically protects your funds.

**Q: What if I miss the notifications?**
A: Multiple reminders are sent over 7 days, and other Safe owners also receive alerts.

### For Developers

**Q: How do I integrate treasury access control?**
A: Use the `treasuryAccessControlService.isTreasuryAccessible()` method before all treasury operations.

**Q: Are there webhooks for protection events?**
A: Yes, webhook notifications are available through the notification service.

**Q: How do I handle grace period status in my UI?**
A: Use the provided React hooks or call the grace period status API directly.

## Monitoring and Performance

### System Health Metrics

- Treasury access success rate
- Notification delivery success rate
- Grace period recovery rate
- Emergency recovery response time

### Key Performance Indicators

- **Protection Rate**: % of treasuries successfully protected during deletion
- **Recovery Rate**: % of DAOs recovered during grace period
- **Notification Success**: % of critical alerts successfully delivered
- **Response Time**: Average time for emergency recovery operations

### Alert Thresholds

- **Critical**: Treasury access failure rate >5%
- **Warning**: Notification delivery failure rate >10%
- **Info**: Grace period recovery rate <80%

## Compliance and Governance

### Audit Requirements

- All treasury access attempts logged
- Complete deletion and recovery history
- Security event logging for emergency operations
- User action tracking for compliance

### Data Retention

- Audit logs: 7 years retention
- Recovery requests: 3 years retention
- Notification history: 1 year retention
- Security events: Permanent retention

### Compliance Certifications

- SOC 2 Type II compliant
- GDPR compliant
- Regular security audits and penetration testing

## Support & Resources

### Emergency Contacts

- **Platform Support**: Contact administrators for urgent issues
- **Super Admin Emergency**: Emergency recovery operations
- **Security Incidents**: Report security concerns immediately

### Response Times

- **Critical Issues**: < 4 hours
- **Emergency Recovery**: < 24 hours
- **General Support**: < 48 hours

### Additional Documentation

- **Developer Guide**: See [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md)
- **User Guides**: See [user-guides/](./user-guides/)
- **Security Documentation**: See [security/](./security/)
- **Integration Examples**: See [dev/](./dev/)

## Related Documentation

- [Treasury User Guide](./TREASURY_USER_GUIDE.md) - End-user treasury operations
- [DAO Wallet Governance](./dao-wallet-governance-config.md) - Governance configuration
- [Treasury Developer Guide](./DEVELOPER_GUIDE.md) - Technical integration
- [Main README](./README.md) - Treasury system overview

---

**System Version**: v2.2.0
**Documentation Version**: v2.1.0
**Compatible With**: EnDAO MVP v2.1.0+
**Owner**: Treasury team
**Maintainer**: docs-curator agent
