# DAO Active Wallet - User Permissions & UI Access

**Last Updated**: September 30, 2025

## Overview

This document details what different user roles can see and do with the DAO Active Wallet system across all UI interfaces.

## User Roles

### 1. **Regular Members** (non-admin)

### 2. **DAO Admins**

### 3. **Super Admins** (platform administrators)

---

## UI Access Matrix

### DAO Creation Wizard (`/create-dao`)

**Who Can Access**: All authenticated users

#### Step 3: Active Wallet Configuration

**All Users See:**

- ✅ Enable/Disable toggle for active wallet creation
- ✅ Three governance preset options:
  - **Community DAO** (Recommended)
  - **Active DeFi DAO**
  - **Conservative DAO**
- ✅ Preset descriptions with tier limits
- ✅ Educational content explaining:
  - What is an Active Wallet
  - Active Wallet vs. Treasury Safe
  - Use cases (staking, swapping, DeFi)
  - Governance tiers

**Defaults:**

- Active wallet: **Enabled**
- Preset: **Community DAO**

**User Actions:**

- Toggle wallet creation on/off
- Select governance preset
- Read educational content
- Proceed to next step

**Result:**
When DAO is created, if wallet enabled:

- Active wallet created automatically
- Governance config applied based on preset
- Wallet address stored in DAO document
- Creator becomes first admin with wallet access

---

## DAO Settings Page (`/dao/[id]/settings`)

### Access Control

**Permission Check:**

```typescript
// Line 148 in page.tsx
if (!permissions.canManageSettings) {
  // Show "Access Denied" screen
  return <AccessDeniedCard />
}
```

**Result:**

- ❌ **Regular Members**: Cannot access settings page at all
- ✅ **DAO Admins**: Full access to all tabs
- ✅ **Super Admins**: Full access + danger zone

---

### Regular Members (Non-Admin)

**Cannot Access Settings Page**

When a regular member tries to visit `/dao/[id]/settings`:

```
┌─────────────────────────────────────┐
│  🚨 Access Denied                   │
├─────────────────────────────────────┤
│  You don't have permission to       │
│  manage settings for this DAO.      │
│  Only DAO admins can access this    │
│  page.                              │
│                                     │
│  [Back to DAO]  [Discover DAOs]     │
└─────────────────────────────────────┘
```

**What They See Elsewhere:**

- DAO main page: Can see DAO info, proposals, members
- Treasury tab: May see treasury balance (if public)
- Cannot see active wallet details
- Cannot see governance configuration

---

### DAO Admins

**Full Settings Access**

When admin visits `/dao/[id]/settings`, they see:

#### Settings Tabs (5 tabs for non-super-admins):

```
┌───────────────────────────────────────────────────────┐
│ [General] [Membership] [Governance] [Treasury] [⚡ Active Wallet] │
└───────────────────────────────────────────────────────┘
```

---

### Active Wallet Tab (`active-wallet`)

**Location:** `/dao/[id]/settings` → Active Wallet tab

**Access:** DAO Admins and Super Admins only

#### Scenario 1: DAO Has Active Wallet

**What Admins See:**

```typescript
// From dao-settings-content.tsx line 326
{dao.activeWalletAddress ? (
  <DAOWalletGovernanceSettings
    daoId={dao.id}
    currentConfig={dao.walletGovernanceConfig}
  />
) : (
  <ActiveWalletSetup daoId={dao.id} />
)}
```

**UI Components:**

1. **Quick Setup Section**

   ```
   ┌─────────────────────────────────────────┐
   │  Quick Setup                            │
   │  Apply a preset configuration           │
   │                                         │
   │  [Community DAO] [Active DeFi] [Conservative] │
   └─────────────────────────────────────────┘
   ```

   - **Action**: Click button to apply preset
   - **Result**: Governance config updated instantly
   - **API Call**: `PUT /api/dao/[id]/wallet/governance`

2. **Current Configuration Summary**

   ```
   ┌─────────────────────────────────────────┐
   │  Current Configuration                  │
   ├─────────────────────────────────────────┤
   │  Model: tiered                          │
   │  Currency: SOL                          │
   │                                         │
   │  ✅ Tier 1: Enabled (instant)          │
   │  ✅ Tier 2: Enabled (multi-sig)        │
   │  ✅ Tier 3: Enabled (proposal)         │
   └─────────────────────────────────────────┘
   ```

3. **Advanced Configuration Notice**

   ```
   ┌─────────────────────────────────────────┐
   │  ℹ️  Advanced Configuration             │
   │                                         │
   │  For detailed tier settings, contact    │
   │  support or use the governance API.     │
   └─────────────────────────────────────────┘
   ```

4. **Wallet Address Display**
   ```
   ┌─────────────────────────────────────────┐
   │  Active Wallet Address                  │
   │  0x1234...5678                          │
   │  [Copy]                                 │
   └─────────────────────────────────────────┘
   ```

**Admin Actions:**

- ✅ Apply governance presets (one-click)
- ✅ View current configuration
- ✅ Copy wallet address
- ✅ See wallet creation status
- ❌ Cannot modify advanced tier settings in UI (future feature)
- ❌ Cannot revoke delegation via UI (future feature, currently API only)

---

#### Scenario 2: DAO Does NOT Have Active Wallet

**What Admins See:**

**UI Component: ActiveWalletSetup**

```
┌─────────────────────────────────────────────────┐
│  Create Active Wallet                           │
│  Set up a programmable wallet for automated     │
│  DeFi operations                                │
├─────────────────────────────────────────────────┤
│                                                 │
│  ℹ️  This will create a Privy-powered wallet   │
│     with configurable governance. You'll be     │
│     able to set spending limits and approval    │
│     requirements.                               │
│                                                 │
│  [🔓 Create Active Wallet]                      │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Admin Actions:**

- ✅ Click "Create Active Wallet" button
- **API Call**: `POST /api/dao/[id]/wallet/create`
- **Result**:
  - Wallet created with default Community preset
  - Success message with wallet address
  - UI updates to show governance settings
  - Tab refreshes to show Scenario 1

**Error Handling:**

```
┌─────────────────────────────────────────────────┐
│  ⚠️ Failed to create wallet                     │
│  Network error. Please try again.               │
└─────────────────────────────────────────────────┘
```

---

### Super Admins

**Additional Tabs (7 tabs total):**

```
┌───────────────────────────────────────────────────────────────────┐
│ [General] [Membership] [Governance] [Treasury] [⚡ Active Wallet] [🛡️ Admin] [⚠️ Danger] │
└───────────────────────────────────────────────────────────────────┘
```

**Super Admin Exclusive:**

- Admin tab: Platform-wide admin features
- Danger tab: Delete DAO, archive, emergency actions

**Active Wallet Tab:**

- Same as DAO Admins (no additional features currently)
- Future: Emergency wallet revocation UI

---

## API Endpoints & Permissions

### Governance Configuration

**Endpoint**: `GET /api/dao/[id]/wallet/governance`

- **Access**: DAO Admins + Super Admins
- **Returns**: Current governance configuration
- **Use Case**: Loading current config in settings

**Endpoint**: `PUT /api/dao/[id]/wallet/governance`

- **Access**: DAO Admins + Super Admins only
- **Payload**: `{ preset: 'community' | 'active_defi' | 'conservative' }` or full config
- **Use Case**: Applying presets or updating config

### Wallet Creation

**Endpoint**: `POST /api/dao/[id]/wallet/create`

- **Access**: DAO Admins + Super Admins only
- **Returns**: `{ address: string, config: {...} }`
- **Use Case**: Creating wallet for existing DAOs

### Wallet Status

**Endpoint**: `GET /api/dao/[id]/wallet/status`

- **Access**: DAO Admins + Super Admins only
- **Returns**: `{ status: 'created' | 'pending' | 'failed' | 'none', address?: string }`
- **Use Case**: Polling during wallet creation

### Delegation Management

**Endpoint**: `GET /api/dao/[id]/wallet/delegation`

- **Access**: DAO Admins + Super Admins only
- **Returns**: Delegation status
- **Use Case**: Checking if delegation is active

**Endpoint**: `PUT /api/dao/[id]/wallet/delegation`

- **Access**: DAO Admins only
- **Payload**: Updated delegation policies
- **Use Case**: Updating delegation config (future feature)

**Endpoint**: `DELETE /api/dao/[id]/wallet/delegation`

- **Access**: DAO Admins only (emergency revocation)
- **Use Case**: Revoking all delegations (future UI feature)

---

## Permission Enforcement

### Frontend Checks

**Route-Level Protection** (`/dao/[id]/settings/page.tsx`):

```typescript
// Lines 41-45
const { permissions, loading: permissionsLoading } = useAdminPermissions({
  daoId,
  dao: state.dao,
  autoRefresh: false,
})

// Line 148
if (!permissions.canManageSettings) {
  return <AccessDeniedCard />
}
```

**Tab-Level Protection** (`dao-settings-content.tsx`):

```typescript
// Lines 283-286
<TabsTrigger value="active-wallet" className="flex items-center gap-2">
  <Icon name="Zap" className="h-4 w-4" />
  Active Wallet
</TabsTrigger>
```

- Tab is visible to all admins
- Content checks wallet existence
- Actions require admin permissions

### Backend API Protection

**All Wallet API Routes** require admin verification:

```typescript
// Example from governance/route.ts
const hasPermission = await daoMembershipService.verifyAdminPermission(
  daoId,
  userId
);

if (!hasPermission) {
  return NextResponse.json(
    { error: 'Only admins can manage wallet governance' },
    { status: 403 }
  );
}
```

---

## What Users See in DAO Main Page

### Regular Members

**DAO Page** (`/dao/[id]`):

- ✅ DAO name, description, stats
- ✅ Proposals tab (can vote if member)
- ✅ Members tab (can see member list)
- ✅ Treasury tab (may see Safe balance if public)
- ❌ **No Active Wallet information visible**
- ❌ No settings link in navigation

### DAO Admins

**DAO Page** (`/dao/[id]`):

- ✅ Everything regular members see
- ✅ **Settings button in header/navigation**
- ✅ Admin badge/indicator
- ✅ Additional admin actions (invite members, etc.)
- ❌ Active wallet details not shown on main page
  - **Must go to Settings → Active Wallet tab**

### Super Admins

**DAO Page** (`/dao/[id]`):

- ✅ Everything DAO admins see
- ✅ Platform admin controls
- ✅ Additional moderation tools

---

## Future Enhancements (Not Yet Implemented)

### Phase 2 Features

**Admin Table** (`/admin/daos`):

- Column showing wallet status (✓/✗/⚠️)
- Bulk wallet creation for DAOs
- Migration tools

**Advanced Governance UI**:

- Detailed tier configuration editor
- Custom spending limits per token
- Protocol allowlist management
- Quorum configuration

**Transaction Monitoring**:

- Active wallet transaction history
- Spending analytics
- Delegation usage metrics

**Emergency Controls**:

- UI button for delegation revocation
- Freeze wallet functionality
- Recovery workflows

---

## Summary: What Each Role Can Do

### Regular Members (Non-Admin)

- ❌ Cannot access settings page at all
- ❌ Cannot see active wallet information
- ❌ Cannot create or manage wallets
- ✅ Can participate in proposals that may involve wallet actions

### DAO Admins

- ✅ **Full access to Active Wallet settings tab**
- ✅ Create active wallet (if doesn't exist)
- ✅ Apply governance presets (Community, Active DeFi, Conservative)
- ✅ View current configuration and wallet address
- ✅ Access via Settings → Active Wallet tab
- ❌ Cannot see advanced tier editing UI (future feature)
- ❌ Cannot use emergency controls via UI (API only)

### Super Admins

- ✅ Everything DAO admins can do
- ✅ Access to Admin and Danger tabs
- ✅ Platform-wide wallet management (future)
- ✅ Emergency override capabilities (future UI)

---

## Key Takeaways

1. **Settings page is admin-only** - Regular members see "Access Denied"

2. **Active Wallet tab is the 5th tab** in DAO settings (after General, Membership, Governance, Treasury)

3. **Conditional UI based on wallet existence**:
   - Wallet exists → Show governance settings
   - No wallet → Show creation button

4. **One-click preset application** - Admins can quickly switch between governance models

5. **No advanced editing in UI yet** - Detailed tier configuration requires API calls

6. **Future features planned** - Transaction monitoring, advanced config UI, emergency controls

---

_This document reflects the current implementation as of September 30, 2025. Features and UI may change as development continues._
