# Treasury System Integration Guide

## Purpose

This guide provides detailed instructions for integrating the treasury protection system into frontend components and understanding the database schema. It covers React hooks, component patterns, database collections, and best practices for building treasury-aware features.

## Last Updated

September 2025

---

## Table of Contents

1. [Frontend Integration](#frontend-integration)
2. [React Hooks](#react-hooks)
3. [Component Integration Examples](#component-integration-examples)
4. [Database Schema](#database-schema)
5. [Best Practices](#best-practices)

---

## Frontend Integration

### Treasury Admin Operations

#### Multi-Signature Execution Flow

Access treasury admin dashboard at: `/dao/{dao-id}/treasury/admin`

**Requirements:**

- Must be a DAO admin or treasury admin
- Shows admin number (Admin 1 or Admin 2)
- Displays signature requirements (2-of-2 multi-sig)

**Visual Status Indicators:**

- **Blue badge**: "Needs Initiation" - Any admin can start
- **Orange badge**: "Needs Your Signature" - You need to sign
- **Yellow badge**: "Waiting for Co-Admin" - Other admin must sign
- **Green badge**: "Ready to Execute" - Fully signed, ready for submission

**Execution Process:**

1. **Initiate**: Find proposal showing "Needs Initiation" → Click "Initiate Execution"
2. **Sign**: Both admins click "Sign Transaction" in sequence
3. **Execute**: Click "Submit Transaction (Gasless)" via Gelato (no gas fees)

---

## React Hooks

### useDAODeletionStatus Hook

Monitors DAO deletion status and grace period countdown.

```typescript
import { useDAODeletionStatus } from '@/hooks/use-dao-deletion-status'

function DeletionStatusComponent({ daoId }: { daoId: string }) {
  const {
    // Status data
    gracePeriodStatus,
    isPendingDeletion,
    canRecover,
    daysRemaining,
    hoursRemaining,

    // Loading states
    loading,
    error,

    // Helper functions
    getCountdownText,
    getUrgencyLevel,
    getScheduledDeletionDate,
    refresh,
  } = useDAODeletionStatus(daoId)

  if (loading) return <div>Checking deletion status...</div>
  if (error) return <div>Error: {error}</div>

  if (isPendingDeletion) {
    return (
      <div className={`alert alert-${getUrgencyLevel()}`}>
        <h3>DAO Deletion in Progress</h3>
        <p>{getCountdownText()}</p>
        <p>Scheduled for: {getScheduledDeletionDate()}</p>
        {canRecover && (
          <button onClick={() => handleCancelDeletion()}>
            Cancel Deletion
          </button>
        )}
      </div>
    )
  }

  return <div>DAO is active</div>
}
```

**Return Values:**

| Property                     | Type                                | Description                        |
| ---------------------------- | ----------------------------------- | ---------------------------------- |
| `gracePeriodStatus`          | `GracePeriodStatus \| null`         | Complete grace period information  |
| `isPendingDeletion`          | `boolean`                           | True if DAO is pending deletion    |
| `canRecover`                 | `boolean`                           | True if recovery is still possible |
| `daysRemaining`              | `number`                            | Days until deletion                |
| `hoursRemaining`             | `number`                            | Hours until deletion               |
| `loading`                    | `boolean`                           | Loading state                      |
| `error`                      | `string \| null`                    | Error message if any               |
| `getCountdownText()`         | `string`                            | Human-readable countdown           |
| `getUrgencyLevel()`          | `'info' \| 'warning' \| 'critical'` | Urgency indicator                  |
| `getScheduledDeletionDate()` | `string`                            | Formatted deletion date            |
| `refresh()`                  | `() => Promise<void>`               | Manually refresh status            |

---

### useTreasuryAccessControl Hook

Validates treasury access and provides status information.

```typescript
import { useTreasuryAccessControl } from '@/hooks/use-treasury-access-control'

function TreasuryAccessGuard({
  daoId,
  children
}: {
  daoId: string
  children: React.ReactNode
}) {
  const {
    // Status data
    accessStatus,
    freezeRecord,
    isAccessible,
    isFrozen,
    isDAOPendingDeletion,

    // Loading states
    loading,
    error,

    // Helper functions
    getStatusMessage,
    getStatusLevel,
    getFreezeInfo,
    shouldDisableOperation,
    refresh,
  } = useTreasuryAccessControl(daoId)

  if (loading) return <div>Checking treasury access...</div>
  if (error) return <div>Error: {error}</div>

  if (!isAccessible) {
    const statusLevel = getStatusLevel()
    const message = getStatusMessage()
    const freezeInfo = getFreezeInfo()

    return (
      <div className={`alert alert-${statusLevel}`}>
        <h3>Treasury Access Restricted</h3>
        <p>{message}</p>
        {freezeInfo && (
          <div>
            <p>Frozen by: {freezeInfo.frozenBy}</p>
            <p>Frozen at: {freezeInfo.frozenAt.toLocaleDateString()}</p>
            <p>Reason: {freezeInfo.reason}</p>
          </div>
        )}
        {isDAOPendingDeletion && (
          <p>Go to Admin → Protection to cancel deletion.</p>
        )}
      </div>
    )
  }

  return <>{children}</>
}
```

**Return Values:**

| Property                     | Type                                | Description                           |
| ---------------------------- | ----------------------------------- | ------------------------------------- |
| `accessStatus`               | `TreasuryAccessStatus \| null`      | Complete access status                |
| `freezeRecord`               | `TreasuryFreezeRecord \| null`      | Freeze details if frozen              |
| `isAccessible`               | `boolean`                           | True if treasury operations allowed   |
| `isFrozen`                   | `boolean`                           | True if treasury is frozen            |
| `isDAOPendingDeletion`       | `boolean`                           | True if DAO pending deletion          |
| `loading`                    | `boolean`                           | Loading state                         |
| `error`                      | `string \| null`                    | Error message if any                  |
| `getStatusMessage()`         | `string`                            | Human-readable status message         |
| `getStatusLevel()`           | `'success' \| 'warning' \| 'error'` | Status severity                       |
| `getFreezeInfo()`            | `FreezeInfo \| null`                | Freeze details if applicable          |
| `shouldDisableOperation(op)` | `boolean`                           | Check if operation should be disabled |
| `refresh()`                  | `() => Promise<void>`               | Manually refresh status               |

---

## Component Integration Examples

### Treasury Dashboard with Protection

```typescript
import { useTreasuryAccessControl } from '@/hooks/use-treasury-access-control'
import { useDAODeletionStatus } from '@/hooks/use-dao-deletion-status'

export function TreasuryDashboard({ daoId }: { daoId: string }) {
  const {
    isAccessible,
    isFrozen,
    getStatusMessage,
    getStatusLevel
  } = useTreasuryAccessControl(daoId)

  const {
    isPendingDeletion,
    getCountdownText,
    getUrgencyLevel
  } = useDAODeletionStatus(daoId)

  return (
    <div className="treasury-dashboard">
      {/* Status Alerts */}
      {!isAccessible && (
        <Alert variant={getStatusLevel()}>
          <AlertTitle>Treasury Access Restricted</AlertTitle>
          <AlertDescription>{getStatusMessage()}</AlertDescription>
        </Alert>
      )}

      {isPendingDeletion && (
        <Alert variant={getUrgencyLevel()}>
          <AlertTitle>DAO Deletion Scheduled</AlertTitle>
          <AlertDescription>{getCountdownText()}</AlertDescription>
        </Alert>
      )}

      {/* Treasury Operations */}
      <TreasuryOperations
        daoId={daoId}
        disabled={!isAccessible}
        frozenNotice={isFrozen ? 'Treasury is frozen' : undefined}
      />
    </div>
  )
}
```

### Protected Operation Button

```typescript
import { useTreasuryAccessControl } from '@/hooks/use-treasury-access-control'

export function TreasuryOperationButton({
  daoId,
  operation,
  children,
  onClick
}: {
  daoId: string
  operation: string
  children: React.ReactNode
  onClick: () => void
}) {
  const { shouldDisableOperation, getStatusMessage } = useTreasuryAccessControl(daoId)

  const isDisabled = shouldDisableOperation(operation)
  const disabledReason = isDisabled ? getStatusMessage() : undefined

  return (
    <Button
      onClick={onClick}
      disabled={isDisabled}
      title={disabledReason}
    >
      {children}
    </Button>
  )
}
```

---

## Database Schema

### Collections

#### DAOs Collection

```typescript
interface DAO {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'archived' | 'pending_deletion' | 'deleted';

  // Treasury configuration
  safeAddress?: string;
  safeOwners?: string[];
  safeThreshold?: number;
  treasuryEnabled?: boolean;
  treasuryCreatedAt?: Timestamp;
  treasuryMetadata?: {
    version: string;
    network: string;
    chainId: number;
    l2Optimized: boolean;
  };

  // Deletion tracking
  pendingDeletionSince?: Timestamp;
  recoveredAt?: Timestamp;
  recoveredBy?: string;

  // Standard DAO fields
  memberIds: string[];
  admins: string[];
  settings: DAOSettings;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

#### DAO Deletion Tracking Collection

```typescript
interface DAODeletionRecord {
  id: string;
  daoId: string;

  // Deletion metadata
  initiatedBy: string;
  initiatedAt: Timestamp;
  reason: string;

  // Grace period configuration
  gracePeriodDays: number;
  scheduledDeletionDate: Timestamp;
  canRecoverUntil: Timestamp;

  // Status tracking
  status: 'pending' | 'executed' | 'recovered' | 'expired';

  // Recovery tracking
  recoveredBy?: string;
  recoveredAt?: Timestamp;
  recoveryReason?: string;

  // Execution tracking
  executedBy?: string;
  executedAt?: Timestamp;

  // Snapshot for recovery
  originalDAOSnapshot: Partial<DAO>;
  originalMemberCount: number;
  originalProposalCount: number;

  // Metadata
  metadata?: Record<string, any>;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

#### Treasury Freezes Collection

```typescript
interface TreasuryFreezeRecord {
  daoId: string; // Document ID
  frozenAt: Timestamp;
  frozenBy: string;
  reason: string;
  unfrozenAt?: Timestamp;
  unfrozenBy?: string;
  isActive: boolean;
  metadata?: Record<string, any>;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

#### Treasury Notifications Collection

```typescript
interface TreasuryNotification {
  id: string;
  daoId: string;
  type: TreasuryNotificationType;
  priority: NotificationPriority;

  // Timing
  scheduledFor: Timestamp;
  createdAt: Timestamp;
  sentAt?: Timestamp;

  // Recipients
  recipients: {
    safeOwners: string[];
    daoAdmins: string[];
    daoMembers?: string[];
    externalEmails?: string[];
  };

  // Content
  title: string;
  message: string;
  actionUrl?: string;

  // Context
  treasuryContext: TreasuryContext;
  daoContext: DAOContext;

  // Status
  status: 'scheduled' | 'sending' | 'sent' | 'failed' | 'cancelled';
  deliveryResults?: DeliveryResult[];

  // Metadata
  createdBy: string;
  updatedAt: Timestamp;
}
```

---

## Best Practices

### Frontend Integration

1. **Always Use Hooks**
   - Use `useTreasuryAccessControl` before treasury operations
   - Use `useDAODeletionStatus` for deletion-aware UIs
   - Leverage hook helpers for consistent UX

2. **Error Handling**
   - Display meaningful error messages to users
   - Provide recovery actions when applicable
   - Log errors for debugging

3. **Loading States**
   - Show loading indicators during async operations
   - Disable buttons during operations
   - Provide feedback for long operations

4. **Real-Time Updates**
   - Use hook `refresh()` methods for manual updates
   - Consider polling for critical status changes
   - Update UI immediately after operations

### Database Operations

1. **Always Validate Status**
   - Check DAO status before operations
   - Verify treasury freeze state
   - Validate grace period constraints

2. **Use Transactions**
   - Batch related database updates
   - Ensure atomicity for critical operations
   - Handle rollback scenarios

3. **Audit Logging**
   - Log all treasury operations
   - Include full context in logs
   - Use structured logging format

4. **Data Consistency**
   - Keep DAO status in sync with freeze records
   - Update timestamps consistently
   - Validate data integrity

---

_For performance optimization and troubleshooting, see [Advanced Topics](./advanced-topics.md)_
