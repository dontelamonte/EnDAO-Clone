# Treasury System Quick Start

## Purpose

This guide provides a rapid onboarding path for developers to get started with the EnDAO treasury system. It covers the essential setup steps, basic operations, and quick reference information needed to begin working with the treasury system.

## Last Updated

September 2025

---

## Table of Contents

1. [Technology Stack](#technology-stack)
2. [Architecture Overview](#architecture-overview)
3. [Initial Setup](#initial-setup)
4. [Basic Operations](#basic-operations)
5. [Quick Reference](#quick-reference)

---

## Technology Stack

### Blockchain Infrastructure

- **Smart Contracts**: Gnosis Safe v1.4.1+L2
- **Blockchain**: Base (Layer 2 Ethereum)
- **Network**: Base Sepolia (testnet), Base Mainnet (production)
- **Chain ID**: 84532 (Sepolia), 8453 (Mainnet)

### Web3 Integration

- **Web3 Provider**: Ethers.js v6.15.0
- **Safe SDK**: @safe-global/protocol-kit v4.1.7
- **Authentication**: Privy (wallet auth)

### Backend Services

- **Database**: Supabase (PostgreSQL)
- **Authentication**: Privy
- **Functions**: Next.js API Routes
- **Hosting**: Vercel

### Frontend Framework

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS + Shadcn/ui
- **State Management**: React hooks + Context

---

## Architecture Overview

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Layer                        │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐│
│  │   DAO Admin     │ │   Treasury      │ │   Recovery      ││
│  │   Components    │ │   Components    │ │   Interface     ││
│  └─────────────────┘ └─────────────────┘ └─────────────────┘│
├─────────────────────────────────────────────────────────────┤
│                    Service Layer                            │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐│
│  │   Treasury      │ │   Treasury      │ │   Treasury      ││
│  │   Access        │ │   Notification  │ │   Recovery      ││
│  │   Control       │ │   Service       │ │   Service       ││
│  └─────────────────┘ └─────────────────┘ └─────────────────┘│
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐│
│  │            DAO Soft Delete Service                      ││
│  │         (Central Orchestrator)                          ││
│  └─────────────────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────┤
│                    Infrastructure Layer                     │
│  • Base L2 Network                                          │
│  • Gnosis Safe Contracts                                   │
│  • Supabase PostgreSQL                                     │
│  • Privy Authentication                                    │
└─────────────────────────────────────────────────────────────┘
```

### Core Components

- **Service Layer**: `/src/lib/services/safe-l2.service.ts` - L2-optimized Safe deployment and management
- **API Endpoints**: `/src/app/api/treasury/v2/` - REST APIs for treasury operations
- **Configuration**: `/src/config/safe-contracts.ts` - Contract addresses and network configuration
- **UI Components**: `/src/components/treasury/` - React components for treasury interface
- **Protection System**: Four core services providing comprehensive treasury security

---

## Initial Setup

### Prerequisites

Before getting started, ensure you have:

1. **Development Environment**
   - Node.js 18+ installed
   - Git for version control
   - Code editor (VS Code recommended)

2. **Network Access**
   - Base Sepolia RPC endpoint
   - Stable internet connection

3. **Deployer Wallet**
   - Private key with deployment permissions
   - Minimum 0.002 ETH for gas costs
   - Wallet address added to environment variables

### Environment Configuration

Create or update `.env.local` with the following:

```env
# Base Configuration
NEXT_PUBLIC_BASE_SEPOLIA_RPC_URL=https://sepolia.base.org
NEXT_PUBLIC_SAFE_SERVICE_URL=https://safe-transaction-base-sepolia.safe.global

# Safe Deployment
SAFE_DEPLOYER_PRIVATE_KEY=your-private-key
SAFE_API_KEY=optional-safe-api-key

# Platform Revenue (Production)
ENDAO_SAFE_ADDRESS=0x00dc44400adb57a85364c97442bd5e95faa861e7
NEXT_PUBLIC_FEE_ROUTER_ADDRESS=0xf8786857eD04621d6e81959aAb36e422F687E4c8
```

### Installation Steps

```bash
# 1. Clone the repository
git clone https://github.com/your-org/endao-mvp.git
cd endao-mvp

# 2. Install dependencies
yarn install

# 3. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your values

# 4. Start development server
yarn dev
```

---

## Basic Operations

### Creating a Treasury

#### Method 1: Through the UI (Recommended)

1. **Navigate to DAO Settings**
   - Go to your DAO dashboard
   - Click "Settings" in the sidebar
   - Select "Treasury" tab

2. **Setup Treasury**
   - Click "Setup Treasury" button
   - Review owner addresses (auto-populated with admins)
   - Confirm transaction
   - Wait for deployment confirmation

#### Method 2: Using the API

```typescript
// POST /api/treasury/v2/create-safe
const response = await fetch('/api/treasury/v2/create-safe', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    daoId: 'your-dao-id',
    adminWallets: ['0x...'], // Optional
  }),
});

const result = await response.json();
// Returns: { success: true, safeAddress: '0x...', ... }
```

### Checking Treasury Status

```typescript
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';

// Check if treasury is accessible
const accessResult =
  await treasuryAccessControlService.isTreasuryAccessible(daoId);

if (accessResult.success && accessResult.data?.accessible) {
  console.log('Treasury is accessible');
} else {
  console.log('Treasury blocked:', accessResult.data?.reason);
}
```

### Executing Treasury Operations

```typescript
// Validate operation before execution
const validationResult =
  await treasuryAccessControlService.validateTreasuryOperation(
    daoId,
    userId,
    'transfer_funds',
    authContext
  );

if (validationResult.success && validationResult.data?.isValid) {
  // Proceed with treasury operation
  await executeTreasuryOperation();
} else {
  // Handle validation errors
  const errors = validationResult.data?.errors || [];
  console.error('Validation failed:', errors);
}
```

---

## Quick Reference

### Key Services

| Service                 | Purpose                       | Import Path                                               |
| ----------------------- | ----------------------------- | --------------------------------------------------------- |
| Treasury Access Control | Validates treasury operations | `@/lib/services/treasury/treasury-access-control.service` |
| DAO Soft Delete         | Manages grace period deletion | `@/lib/services/dao/dao-soft-delete.service`              |
| Treasury Notification   | Sends multi-channel alerts    | `@/lib/services/treasury/treasury-notification.service`   |
| Treasury Recovery       | Emergency recovery operations | `@/lib/services/treasury/treasury-recovery.service`       |

### Common Patterns

**Service Response Pattern:**

```typescript
interface ServiceResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  metadata?: Record<string, any>;
}
```

**Error Handling:**

```typescript
const result = await service.operation();

if (result.success) {
  const data = result.data!;
  // Process success
} else {
  const error = result.error || 'Unknown error';
  // Handle error
}
```

### Contract Addresses (L2-Optimized v1.4.1+L2)

- **Safe Singleton**: `0x29fcB43b46531BcA003ddC8FCB67FFE91900C762`
- **Proxy Factory**: `0x4e1DCf7AD4e460CfD30791CCC4F9c8a4f820ec67`
- **Fallback Handler**: `0xfd0732Dc9E303f09fCEf3a7388Ad10A83459Ec99`

### Current Platform Configuration

- **Network**: Base Sepolia (Chain ID: 84532)
- **EnDAO Safe**: `0x00dc44400adb57a85364c97442bd5e95faa861e7` (Revenue Collection)
- **FeeRouter Contract**: `0xf8786857eD04621d6e81959aAb36e422F687E4c8`
- **Safe Version**: 1.4.1+L2 (L2-optimized)
- **Example Test Safe**: `0x87C68E1D71e8CA215Caa179F51F609ce94c1b71C`

### Next Steps

Now that you have the basics covered, explore these resources for deeper understanding:

- [API Reference](./api-reference.md) - Complete API documentation
- [Integration Guide](./integration-guide.md) - Frontend and database integration
- [Advanced Topics](./advanced-topics.md) - Performance optimization and troubleshooting
- [Complete User Guide](./TREASURY_USER_GUIDE.md) - End-user documentation
- [Security Documentation](./security/threat-model.md) - Security and threat model

---

_For detailed API documentation and advanced features, see [API Reference](./api-reference.md)_
