# Treasury System Advanced Topics

## Purpose

This document covers advanced treasury system topics including deployment procedures, performance optimization, security testing, and troubleshooting complex issues. It is intended for experienced developers working on production deployments and system optimization.

## Last Updated

September 2025

---

## Table of Contents

1. [Deployment Guide](#deployment-guide)
2. [Performance & Optimization](#performance--optimization)
3. [Security & Testing](#security--testing)
4. [Troubleshooting](#troubleshooting)
5. [Production Checklist](#production-checklist)

---

## Deployment Guide

### Prerequisites

Before deploying a treasury Safe, ensure you have:

1. **Network Access**
   - Base Sepolia RPC endpoint
   - Stable internet connection

2. **Deployer Wallet**
   - Private key with deployment permissions
   - Minimum 0.002 ETH for gas costs
   - Wallet address added to environment variables

3. **Environment Configuration**

   ```env
   # Base Configuration
   NEXT_PUBLIC_BASE_SEPOLIA_RPC_URL=https://sepolia.base.org
   NEXT_PUBLIC_SAFE_SERVICE_URL=https://safe-transaction-base-sepolia.safe.global

   # Safe Deployment
   SAFE_DEPLOYER_PRIVATE_KEY=your-private-key
   SAFE_API_KEY=optional-safe-api-key

   # Platform Revenue (Production)
   ENDAO_SAFE_ADDRESS=0x00dc44400adb57a85364c97442bd5e95faa861e7
   NEXT_PUBLIC_FEE_ROUTER_ADDRESS=0xf8786857eD04621d6e81959aAb36e422F687E4c8
   ```

### Deployment Methods

#### Method 1: API Deployment (Recommended)

For production DAO treasury creation through the app:

1. **Admin creates treasury through UI**
   - Navigate to DAO settings
   - Click "Setup Treasury"
   - Confirm transaction

2. **Backend process**
   - API endpoint: `/api/treasury/v2/create-safe`
   - Automatically uses L2-optimized contracts
   - Returns Safe address and configuration

#### Method 2: Script Deployment (Development/Testing)

For manual deployment or testing:

```bash
# Deploy L2-optimized Safe
node scripts/deploy-safe-l2.js

# Expected output:
# Deploying L2-optimized Safe...
# ✅ L2-optimized Safe deployed successfully!
# Address: 0x...
# View in app: https://app.safe.global/home?safe=basesep:0x...
```

### Deployment Process

#### Step 1: Validate Configuration

```javascript
// Check deployer balance
const balance = await provider.getBalance(deployerAddress);
console.log('Deployer balance:', ethers.formatEther(balance));

// Verify minimum balance (0.002 ETH)
if (balance < ethers.parseEther('0.002')) {
  throw new Error('Insufficient balance for deployment');
}
```

#### Step 2: Configure Safe Parameters

```javascript
const safeConfig = {
  owners: [
    '0x...', // Admin wallet 1
    '0x...', // Admin wallet 2
  ],
  threshold: 2, // Number of required signatures
  network: 'base-sepolia',
  version: '1.4.1+L2',
};
```

#### Step 3: Deploy Safe

```javascript
// Using safe-l2.service.ts
const safeAddress = await safeL2Service.deployL2Safe(
  safeConfig.owners,
  safeConfig.threshold
);
```

### Post-Deployment

#### Update DAO Configuration

After successful deployment, update the DAO with Safe details:

```javascript
await updateDoc(daoRef, {
  safeAddress,
  safeOwners: owners,
  safeThreshold: threshold,
  treasuryEnabled: true,
  treasuryCreatedAt: new Date(),
  treasuryMetadata: {
    version: '1.4.1+L2',
    network: 'base-sepolia',
    chainId: 84532,
    l2Optimized: true,
  },
});
```

---

## Performance & Optimization

### Caching Strategies

Implement intelligent caching for treasury operations:

```typescript
class CachedTreasuryAccessService {
  private cache = new Map<
    string,
    { result: TreasuryAccessStatus; timestamp: number }
  >();
  private readonly CACHE_TTL = 30000; // 30 seconds

  async isTreasuryAccessible(
    daoId: string
  ): Promise<ServiceResponse<TreasuryAccessStatus>> {
    const cached = this.cache.get(daoId);
    const now = Date.now();

    if (cached && now - cached.timestamp < this.CACHE_TTL) {
      return { success: true, data: cached.result };
    }

    const result =
      await treasuryAccessControlService.isTreasuryAccessible(daoId);

    if (result.success && result.data) {
      this.cache.set(daoId, { result: result.data, timestamp: now });
    }

    return result;
  }

  clearCache(daoId?: string) {
    if (daoId) {
      this.cache.delete(daoId);
    } else {
      this.cache.clear();
    }
  }
}
```

### Batch Operations

Batch treasury access checks for multiple DAOs:

```typescript
// Batch treasury access checks for multiple DAOs
const daoIds = ['dao1', 'dao2', 'dao3'];
const batchResult =
  await treasuryAccessControlService.checkMultipleTreasuryAccess(daoIds);

if (batchResult.success) {
  const accessStatuses = batchResult.data!;

  Object.entries(accessStatuses).forEach(([daoId, status]) => {
    if (status.accessible) {
      enableTreasuryOperations(daoId);
    } else {
      disableTreasuryOperations(daoId, status.reason);
    }
  });
}
```

### Optimization Tips

1. **Cache access control results** for short periods (30 seconds)
2. **Batch operations** when checking multiple DAOs
3. **Use React hooks** for automatic status updates
4. **Implement optimistic UI updates** with error handling
5. **Debounce status checks** in real-time interfaces

---

## Security & Testing

### Error Handling

All services use a consistent error handling pattern:

```typescript
interface ServiceResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  metadata?: Record<string, any>;
}

// Usage example
const result = await treasuryAccessControlService.isTreasuryAccessible(daoId);

if (result.success) {
  // Handle success case
  const accessStatus = result.data!;
  // ... process data
} else {
  // Handle error case
  const errorMessage = result.error || 'Unknown error';
  // ... handle error
}
```

### Unit Testing Examples

#### Testing Treasury Access Control

```typescript
import { treasuryAccessControlService } from '@/lib/services/treasury/treasury-access-control.service';

describe('TreasuryAccessControlService', () => {
  test('should allow access for active DAO', async () => {
    const result =
      await treasuryAccessControlService.isTreasuryAccessible('active-dao-id');

    expect(result.success).toBe(true);
    expect(result.data?.accessible).toBe(true);
  });

  test('should deny access for pending deletion DAO', async () => {
    const result = await treasuryAccessControlService.isTreasuryAccessible(
      'pending-deletion-dao-id'
    );

    expect(result.success).toBe(true);
    expect(result.data?.accessible).toBe(false);
    expect(result.data?.reason).toBe('dao_pending_deletion');
  });
});
```

### Security Considerations

#### Permission Validation

```typescript
// Always validate permissions before operations
async function validateAdminPermission(
  daoId: string,
  userId: string
): Promise<boolean> {
  // Check DAO admin status
  const dao = await getDAO(daoId);
  if (!dao?.admins?.includes(userId)) {
    return false;
  }

  // Additional checks for sensitive operations
  const accessResult =
    await treasuryAccessControlService.validateTreasuryOperation(
      daoId,
      userId,
      'admin_operation'
    );

  return accessResult.success && accessResult.data?.isValid;
}
```

#### Input Sanitization

```typescript
// All services include input sanitization
const sanitizedReason = treasuryAccessControlService.sanitizeString(userInput);
```

#### Audit Logging

```typescript
// All operations are automatically logged
// Manual logging for custom operations:
await auditCoreService.logTreasuryEvent(
  'custom.operation',
  'success',
  authContext,
  daoId,
  amount,
  token,
  recipient,
  blockchain,
  clientInfo
);
```

---

## Troubleshooting

### Common Issues

#### Deployment Failures

**Error**: "Insufficient balance"

```bash
# Solution: Fund deployer wallet
# Minimum required: 0.002 ETH
```

**Error**: "Contract not found"

```bash
# Solution: Verify network configuration
# Ensure using correct RPC endpoint
```

**Error**: "Invalid owner address"

```bash
# Solution: Validate all owner addresses
# Ensure checksummed addresses
```

#### Safe Not Visible in App

1. **Check network prefix**
   - Use `basesep:` for Base Sepolia
   - Use `base:` for Base Mainnet

2. **Verify deployment**

   ```javascript
   const code = await provider.getCode(safeAddress);
   console.log('Is deployed:', code !== '0x');
   ```

3. **Wait for indexing**
   - Safe app may take 1-2 minutes to index new Safes

#### Treasury Access Issues

**"Network Error" messages**

- These are RPC connection warnings
- Don't affect functionality
- Gelato will handle actual blockchain interaction

**Button not changing after action**

1. Click "Refresh" button
2. Wait 1-2 seconds for state propagation
3. Check browser console for errors

**Can't see dashboard**

1. Verify you're logged in as an admin
2. Check DAO ID in URL is correct
3. Clear browser cache/cookies
4. Check console for debug logs

### Debugging Strategies

#### Enable Debug Logging

```typescript
// Enable verbose logging for treasury operations
const DEBUG_TREASURY = true;

if (DEBUG_TREASURY) {
  console.log('[Treasury] Operation:', operation);
  console.log('[Treasury] Access Status:', accessStatus);
  console.log('[Treasury] Validation Result:', validationResult);
}
```

#### Monitor Service Responses

```typescript
// Wrapper for service calls with logging
async function monitoredServiceCall<T>(
  serviceName: string,
  operation: () => Promise<ServiceResponse<T>>
): Promise<ServiceResponse<T>> {
  const startTime = Date.now();

  try {
    const result = await operation();
    const duration = Date.now() - startTime;

    console.log(`[${serviceName}] Duration: ${duration}ms`);
    console.log(`[${serviceName}] Success: ${result.success}`);

    if (!result.success) {
      console.error(`[${serviceName}] Error:`, result.error);
    }

    return result;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[${serviceName}] Exception after ${duration}ms:`, error);
    throw error;
  }
}
```

---

## Production Checklist

Before deploying to production:

- [ ] Test deployment on Base Sepolia
- [ ] Verify all owner addresses
- [ ] Confirm threshold requirements
- [ ] Document Safe address
- [ ] Test transaction signing
- [ ] Verify Safe in app interface
- [ ] Update DAO configuration
- [ ] Backup deployment details
- [ ] Test treasury protection workflow
- [ ] Verify grace period deletion
- [ ] Test recovery operations
- [ ] Validate notification delivery
- [ ] Monitor audit logs
- [ ] Performance testing completed
- [ ] Security review passed
- [ ] Documentation updated

### Features & Status

#### Current Features

- ✅ L2-optimized Safe deployment
- ✅ Multi-signature wallet creation
- ✅ Automatic DAO admin assignment as Safe owners
- ✅ Configurable signature threshold
- ✅ Base Sepolia testnet support
- ✅ Safe balance checking
- ✅ Transaction sending (for testing)
- ✅ Treasury protection system
- ✅ Grace period management
- ✅ Emergency recovery
- ✅ Multi-channel notifications

#### Planned Features

- 🔄 Base mainnet deployment
- 🔄 Transaction queue management
- 🔄 Treasury analytics dashboard
- 🔄 Automated fund distribution
- 🔄 Token management support

---

## Support Resources

### Documentation Links

- [Quick Start Guide](./quick-start.md) - Get started quickly
- [API Reference](./api-reference.md) - Complete API documentation
- [Integration Guide](./integration-guide.md) - Frontend and database integration
- [Complete User Guide](./TREASURY_USER_GUIDE.md) - End-user documentation
- [Security Documentation](./security/threat-model.md) - Security and threat model
- [Treasury System Overview](./README.md) - High-level overview

### Technical Support

- **Technical Issues**: Check deployment logs
- **Contract Questions**: Review [Safe documentation](https://docs.safe.global/)
- **Network Issues**: Verify Base network status
- **Development Support**: Contact engineering team

### API Reference

- Service method signatures and return types
- Error code reference
- Database schema documentation
- Webhook event specifications

### Getting Help

- GitHub Issues for bug reports
- Developer Discord for integration questions
- Support email for urgent issues
- Documentation feedback and suggestions

---

_For basic operations and getting started, see [Quick Start Guide](./quick-start.md)_
