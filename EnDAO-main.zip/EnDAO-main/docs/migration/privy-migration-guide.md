# Privy Authentication Migration Guide

## Purpose

Migration guide for updating backend services to support Privy-only authentication.

## Last Updated

October 2025

## Overview

The backend services have been refactored to support Privy-only authentication. The main changes are:

### Updated UserProfileService

The `UserProfileService` now has a new primary method for Privy authentication:

#### Primary Method: `createUserProfileFromAuth()`

```typescript
import { userProfileService } from '@/lib/services/user-profile.service';
import { getAuthContext } from '@/lib/auth/get-auth-context';

// In an API route
export async function POST(request: NextRequest) {
  const authContext = await getAuthContext(request);
  if (!authContext) {
    return NextResponse.json(
      { error: 'Authentication required' },
      { status: 401 }
    );
  }

  // Create user profile from Privy auth context
  const result = await userProfileService.createUserProfileFromAuth(
    authContext,
    {
      displayName: 'Custom Display Name',
      firstName: 'John',
      lastName: 'Doe',
      bio: 'A new user',
    },
    ['0x123...', '0xabc...'] // Optional: wallet addresses
  );

  if (result.success) {
    return NextResponse.json({ success: true, data: result.data });
  } else {
    return NextResponse.json({ error: result.error }, { status: 500 });
  }
}
```

### Updated User Profile Schema

The `UserProfile` type now includes Privy-specific fields:

```typescript
interface UserProfile {
  id: string; // Internal UID (for compatibility)
  privyUserId?: string; // Privy user ID - primary identifier
  email: string;
  displayName: string;

  // Privy wallet integration
  wallets?: string[]; // Array of wallet addresses
  primaryWallet?: string; // Main wallet address

  // ... existing fields
}
```

### Auth Context Usage

All new API endpoints should use the auth context pattern:

```typescript
import {
  getAuthContext,
  requireAuthContext,
} from '@/lib/auth/get-auth-context';

// Option 1: Manual check
const authContext = await getAuthContext(request);
if (!authContext) {
  return NextResponse.json(
    { error: 'Authentication required' },
    { status: 401 }
  );
}

// Option 2: Required (throws error if not authenticated)
try {
  const authContext = await requireAuthContext(request);
  // Use authContext.uid, authContext.privyUserId, etc.
} catch (error) {
  return NextResponse.json(
    { error: 'Authentication required' },
    { status: 401 }
  );
}
```

### Available Auth Context Fields

```typescript
interface AuthContext {
  uid: string; // Internal user ID
  privyUserId: string; // Privy user ID
  email?: string; // User email
  primaryWallet?: string; // Primary wallet address
}
```

## Migration Notes

### Deprecated Services

- `AuthService` - Marked as deprecated, use Privy auth context instead
- `createUserProfile(legacyUser, ...)` - Use `createUserProfileFromAuth(authContext, ...)` instead

### Legacy Compatibility

The following methods are maintained for compatibility:

- `createUserProfileWithUid()` - Legacy method, updated to support Privy fields
- `createUserProfile()` - Updated signature, but deprecated

### Database Schema

The `users` table now stores:

```javascript
{
  id: "privy_user_123",           // Internal UID
  privy_user_id: "privy_456",     // Privy identifier
  email: "user@example.com",
  display_name: "John Doe",
  wallets: ["0x123...", "0xabc..."], // Array of wallet addresses
  primary_wallet: "0x123...",     // Primary wallet
  // ... other profile fields
}
```

## Testing

A comprehensive test suite has been added:

```bash
# Run the new Privy integration tests
yarn test src/lib/services/__tests__/user-profile-privy.test.ts
```

## Security

- All profile creation now uses authenticated context from Privy middleware
- No legacy auth dependencies in service layer
- Wallet addresses are properly stored and validated
- Auth context is extracted from middleware headers for security
