# Analytics & Monitoring Setup

**Last Updated**: December 19, 2025

This document covers the PostHog (product analytics) and Sentry (error tracking) integrations for EnDAO.

---

## PostHog (Product Analytics)

**Dashboard**: [https://us.posthog.com](https://us.posthog.com)
**Project**: EnDAO (ID: 269587)

### Environment Variables

| Variable | Purpose | Location |
|----------|---------|----------|
| `NEXT_PUBLIC_POSTHOG_KEY` | Public API key | Vercel + `.env.local` |
| `NEXT_PUBLIC_POSTHOG_HOST` | API endpoint (`https://us.i.posthog.com`) | Vercel + `.env.local` |

### Client-Side Integration

**File**: `src/instrumentation-client.ts`

PostHog is initialized on the client side and proxied through `/ingest` to bypass ad blockers.

**Next.js Config** (`next.config.ts`):
```typescript
rewrites: [
  { source: '/ingest/static/:path*', destination: 'https://us-assets.i.posthog.com/static/:path*' },
  { source: '/ingest/:path*', destination: 'https://us.i.posthog.com/:path*' },
]
```

### Custom Events Tracked

| Event | Trigger | File |
|-------|---------|------|
| `user_signed_up` | New user creates account (first time only) | `src/lib/auth/auth-context.tsx` |
| `user_logged_in` | Returning user logs in | `src/lib/auth/auth-context.tsx` |
| `user_signed_out` | User logs out | `src/lib/auth/auth-context.tsx` |
| `dao_created` | New DAO created | `src/components/dao/create/create-dao-wizard-core.tsx` |
| `dao_creation_started` | User begins DAO creation wizard | `src/components/dao/create/create-dao-wizard-core.tsx` |
| `treasury_created` | Safe wallet created for DAO | `src/components/treasury/treasury-setup.tsx` |
| `proposal_submitted` | Proposal published | `src/hooks/proposals/use-proposal-submission.ts` |
| `proposal_draft_saved` | Draft auto-saved | `src/hooks/proposals/use-proposal-submission.ts` |
| `vote_cast` | User votes on proposal | `src/app/dao/[id]/proposals/[proposalId]/vote/page.tsx` |
| `invitation_accepted` | User accepts DAO invite | `src/app/dao/[id]/join/page.tsx` |
| `search_performed` | User searches on discover page | `src/app/discover/page.tsx` |
| `dao_discovered` | User clicks on a DAO from discover | `src/app/discover/components/dao-grid.tsx` |
| `error_boundary_triggered` | React error boundary catches error | `src/components/error-boundary.tsx` |

### Discord Integration

**Destination**: Discord webhook
**Channel**: #alerts (or configured channel)

**Events sending to Discord**:
- `user_signed_up` - New user registrations
- `$exception` - JavaScript errors
- `dao_created` - New DAOs created
- `treasury_created` - Treasury/Safe setup

**Configuration**:
- Filter: "Filter out internal and test users" = ON
- Trigger: "Run every time"

**To modify**: PostHog → Data Pipelines → Destinations → Discord

---

## Sentry (Error Tracking)

**Dashboard**: [https://sentry.io](https://sentry.io)
**Project**: en-dao

### Environment Variables

| Variable | Purpose | Location |
|----------|---------|----------|
| `NEXT_PUBLIC_SENTRY_DSN` | Client-side DSN | Vercel + `.env.local` |
| `SENTRY_AUTH_TOKEN` | Build-time source maps | Vercel |
| `SENTRY_ORG` | Organization slug | Vercel |
| `SENTRY_PROJECT` | Project slug | Vercel |

### Integration Files

| File | Purpose |
|------|---------|
| `src/instrumentation-client.ts` | Client-side Sentry init |
| `src/instrumentation.server.ts` | Server-side Sentry init |
| `src/instrumentation.edge.ts` | Edge runtime Sentry init |
| `next.config.ts` | Sentry webpack plugin config |

### Features Enabled

1. **Error Tracking** - Automatic capture of JavaScript errors
2. **User Feedback Widget** - "Report a Bug" button in bottom-right corner
3. **Session Replay** - 10% of sessions, 100% on error (configurable)
4. **Performance Monitoring** - Transaction tracing
5. **Source Maps** - Uploaded during build for readable stack traces

### User Feedback Widget

**Location**: Fixed button, bottom-right corner ("Report a Bug")

**Configuration** (`src/instrumentation-client.ts`):
```typescript
Sentry.feedbackIntegration({
  colorScheme: 'system',
  buttonLabel: 'Report a Bug',
  submitButtonLabel: 'Send Report',
  formTitle: 'Report a Bug',
  messagePlaceholder: 'Describe the issue...',
})
```

### Discord Alerts

**Alert 1: Production Errors**
- **Name**: `Production Errors → Discord`
- **Trigger**: New issue created
- **Filters**:
  - Environment = production
  - Level >= error
- **Action**: Send to Discord
- **Interval**: 1 hour

**Alert 2: User Feedback**
- **Name**: `User Feedback → Discord`
- **Trigger**: New issue created
- **Filter**: Issue category = feedback
- **Action**: Send to Discord
- **Interval**: 5 minutes

**To modify**: Sentry → Alerts → Alert Rules

---

## Middleware Configuration

Both PostHog and Sentry proxies are excluded from CSRF validation:

**File**: `src/middleware.ts`
```typescript
const publicRoutes = [
  '/ingest',     // PostHog proxy
  '/monitoring', // Sentry tunnel
  // ...
];
```

**File**: `src/middleware/security.ts`
```typescript
const skipCSRFRoutes = [
  '/ingest',     // PostHog analytics proxy
  '/monitoring', // Sentry tunnel route
  // ...
];
```

---

## Discord Webhooks

| Service | Channel | Webhook URL Location |
|---------|---------|---------------------|
| Sentry | #alerts | Sentry → Settings → Integrations → Discord |
| PostHog | #alerts | PostHog → Data Pipelines → Destinations → Discord |

---

## Common Tasks

### Add a New PostHog Event

1. Import PostHog: `import posthog from 'posthog-js'`
2. Capture event: `posthog.capture('event_name', { property: value })`
3. (Optional) Add to Discord alerts: PostHog → Data Pipelines → Destinations → Discord → Add event matcher

### Add a New Sentry Alert

1. Go to Sentry → Alerts → Create Alert
2. Select alert type (Issues, Metric, etc.)
3. Configure conditions and filters
4. Add Discord action with channel ID
5. Set action interval

### Update Discord Webhook

1. In Discord: Channel Settings → Integrations → Webhooks
2. Copy new webhook URL
3. Update in Sentry/PostHog integration settings

### Test Integrations

**PostHog**: Check Activity tab for recent events
**Sentry**: Use "Send Test Notification" in alert rules
**Discord**: Both services have test notification buttons

---

## Troubleshooting

### PostHog events not appearing
1. Check browser console for errors
2. Verify `/ingest` routes are in `publicRoutes`
3. Check PostHog Activity tab with filters cleared

### Sentry errors not appearing
1. Check `NEXT_PUBLIC_SENTRY_DSN` is set
2. Verify `/monitoring` is in CSRF skip list
3. Check Sentry Issues tab with filters cleared

### Discord notifications not working
1. Verify webhook URL is correct
2. Check channel ID (not channel name)
3. Ensure Discord server permissions allow webhooks
4. Test with "Send Test Notification" button
