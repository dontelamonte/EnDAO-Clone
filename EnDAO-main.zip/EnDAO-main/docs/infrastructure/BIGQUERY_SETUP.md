# BigQuery Export Setup for EnDAO

## Overview

This document describes how to set up BigQuery export for EnDAO analytics and reporting using Supabase as the data source.

**Why BigQuery?**

- Full SQL capabilities for complex analytics queries
- No custom sync code to maintain
- Integration with data visualization tools
- Cost-effective for analytics workloads

## Installation Steps

### Step 1: Set Up Supabase to BigQuery Pipeline

Use one of these approaches to sync Supabase PostgreSQL data to BigQuery:

**Option A: Using Supabase Webhooks + Cloud Functions**

```bash
# Deploy a Cloud Function to receive webhook events
gcloud functions deploy supabase-to-bigquery \
  --runtime nodejs18 \
  --trigger-http \
  --project=endao-mvp-e26a5
```

**Option B: Using Scheduled Data Transfer**

```bash
# Use BigQuery Data Transfer Service with PostgreSQL connector
# Or use third-party tools like Fivetran, Airbyte, or Stitch
```

### Step 2: Configure Tables for Export

Configure these tables for export to BigQuery:

| Table Name    | Reason                              |
| ------------- | ----------------------------------- |
| `daos`        | DAO analytics, discovery metrics    |
| `proposals`   | Proposal analytics, voting patterns |
| `votes`       | Voting analytics                    |
| `dao_members` | Membership analytics                |
| `activities`  | Activity trends, engagement metrics |
| `users`       | User analytics (anonymized)         |

### Step 3: BigQuery Dataset Configuration

Create the BigQuery dataset:

```bash
# Create dataset using bq command
bq mk --dataset endao-mvp-e26a5:endao_analytics

# Or via Cloud Console:
# 1. Go to https://console.cloud.google.com/bigquery
# 2. Click "Create dataset"
# 3. Name it "endao_analytics"
```

### Step 4: Table Mapping

Map Supabase tables to BigQuery:

1. `daos` → `endao_analytics.daos_raw`
2. `proposals` → `endao_analytics.proposals_raw`
3. `votes` → `endao_analytics.votes_raw`
4. `dao_members` → `endao_analytics.members_raw`
5. `activities` → `endao_analytics.activities_raw`

## Example Queries

Once data is in BigQuery, you can run complex analytics:

### Close Vote Analysis

```sql
-- Find proposals where the vote was close (45-55% range)
SELECT
  p.id as proposal_id,
  p.title as title,
  p.dao_id as dao_id,
  p.for_votes as for_votes,
  p.against_votes as against_votes,
  p.total_votes as total_votes,
  SAFE_DIVIDE(p.for_votes, p.total_votes) as vote_ratio
FROM `endao-mvp-e26a5.endao_analytics.proposals_raw` p
WHERE (p.status = 'passed' OR p.status = 'rejected')
  AND SAFE_DIVIDE(p.for_votes, p.total_votes) BETWEEN 0.45 AND 0.55
ORDER BY p.updated_at DESC
LIMIT 100;
```

### DAO Engagement Metrics

```sql
-- Most active DAOs by proposal count and participation
SELECT
  d.id as dao_id,
  d.name as dao_name,
  d.member_count as members,
  d.proposal_count as proposals,
  d.active_proposals as active_proposals,
  SAFE_DIVIDE(d.passed_proposals, d.proposal_count) as pass_rate
FROM `endao-mvp-e26a5.endao_analytics.daos_raw` d
WHERE d.status = 'active'
ORDER BY d.proposal_count DESC
LIMIT 50;
```

### Voting Patterns by Time

```sql
-- Voting activity by hour of day
SELECT
  EXTRACT(HOUR FROM v.voted_at) as hour_of_day,
  COUNT(*) as vote_count
FROM `endao-mvp-e26a5.endao_analytics.votes_raw` v
WHERE v.voted_at IS NOT NULL
GROUP BY hour_of_day
ORDER BY hour_of_day;
```

### Treasury Proposal Analysis

```sql
-- Treasury proposals and their outcomes
SELECT
  p.title,
  p.treasury_amount as amount,
  p.treasury_currency as currency,
  p.status,
  p.passed as passed,
  p.participation_rate as participation
FROM `endao-mvp-e26a5.endao_analytics.proposals_raw` p
WHERE p.type = 'funding'
  AND p.treasury_amount IS NOT NULL
ORDER BY p.created_at DESC;
```

## Cost Considerations

**BigQuery Pricing:**

- Storage: $0.02/GB/month (first 10GB free)
- Queries: $5/TB scanned (first 1TB/month free)

**Estimated Monthly Cost for EnDAO:**

- With ~1GB of data: ~$0.02/month storage
- With moderate query usage: ~$0-5/month

## Maintenance

### Backfill Existing Data

To backfill existing Supabase data to BigQuery:

```bash
# Option 1: Use a data transfer tool like Airbyte
# Configure a full sync job in your data pipeline

# Option 2: Export from Supabase and import to BigQuery
# Export tables from Supabase Dashboard → SQL Editor
# Import using bq load command

# Option 3: Use scheduled Cloud Function
gcloud scheduler jobs create http backfill-bigquery \
  --schedule="0 2 * * *" \
  --uri="https://YOUR_FUNCTION_URL/backfill" \
  --project=endao-mvp-e26a5
```

### Monitoring

- Check BigQuery Console for sync status
- Monitor Cloud Functions logs for errors
- Set up BigQuery alerts for query failures

## Security

- BigQuery access is controlled via IAM
- Consider creating a separate service account for analytics
- Use column-level security for sensitive fields (e.g., user emails)

---

_Last Updated: November 2025_
