# Proposal Auto-Finalization

## Purpose

This document describes the proposal auto-finalization system that automatically updates proposal statuses when voting periods end, preventing proposals from remaining in "active" status indefinitely.

## Last Updated

October 29, 2025

**Status**: ✅ Implemented (Client-Side)
**Version**: 1.0.0

## Overview

Automatic finalization of proposals that have reached their `endTime`. This prevents proposals from staying in "active" status indefinitely after voting has closed.

## Problem Solved

**Before**: Proposals remained in "active" status even after voting period ended, requiring manual admin intervention to finalize each proposal.

**After**: Proposals are automatically finalized when their voting period ends, updating status to:

- `passed` - Quorum reached AND approval threshold met
- `rejected` - Quorum reached BUT approval threshold NOT met (voted down)
- `expired` - Quorum NOT reached (insufficient participation)

## Implementation Approaches

### Current: Client-Side Auto-Finalization ✅

**How it works**:

1. `useAutoFinalize` hook checks for expired proposals when component mounts
2. Runs periodically (default: every 60 seconds) while component is active
3. Calls `autoFinalizeExpiredProposals()` service method
4. Updates proposals in Supabase automatically

**Advantages**:

- ✅ No infrastructure changes required
- ✅ Works immediately in development and production
- ✅ No additional cloud function costs
- ✅ Runs whenever users visit proposal pages

**Limitations**:

- Warning: Requires active users viewing proposals
- Warning: May not finalize immediately at endTime (depends on traffic)
- Warning: Multiple clients may attempt finalization (idempotent, so safe)

**Usage**:

```tsx
import { useAutoFinalize } from '@/hooks/proposals';

function ProposalsList({ daoId }) {
  // Auto-finalize expired proposals every minute
  useAutoFinalize(daoId, {
    enabled: true,
    interval: 60000, // 1 minute
    onFinalized: (count) => {
      console.log(`Auto-finalized ${count} proposals`);
      // Optionally refresh proposal list
    },
    onError: (error) => {
      console.error('Auto-finalization error:', error);
    },
  });

  return <div>...</div>;
}
```

### Future: Supabase Edge Function (Scheduled)

**Recommended for Production at Scale**

**How it would work**:

1. Scheduled Edge Function runs every 5-15 minutes via pg_cron
2. Queries all DAOs for expired active proposals
3. Finalizes proposals in batches
4. More reliable and consistent than client-side approach

**Implementation Plan**:

#### 1. Create Edge Function

```typescript
// supabase/functions/auto-finalize-proposals/index.ts
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

Deno.serve(async () => {
  const now = new Date().toISOString();

  // Query all active proposals that have ended
  const { data: expiredProposals, error } = await supabase
    .from('proposals')
    .select('*')
    .eq('status', 'active')
    .lte('end_time', now)
    .limit(100); // Process in batches

  if (error || !expiredProposals?.length) {
    console.log('No proposals to finalize');
    return new Response('No proposals to finalize');
  }

  let finalized = 0;

  for (const proposal of expiredProposals) {
    // Calculate voting results
    const { data: votes } = await supabase
      .from('votes')
      .select('*')
      .eq('proposal_id', proposal.id);

    const forVotes = votes?.filter((v) => v.option === 'for').length || 0;
    const totalVotes = votes?.length || 0;

    // Determine final status
    const quorumReached =
      totalVotes / proposal.eligible_voters >= proposal.quorum_percentage;
    const approvalMet =
      totalVotes > 0 && forVotes / totalVotes >= proposal.pass_threshold;
    const newStatus =
      approvalMet && quorumReached
        ? 'passed'
        : quorumReached
          ? 'rejected'
          : 'expired';

    // Update proposal
    await supabase
      .from('proposals')
      .update({
        status: newStatus,
        finalized_at: now,
        finalized_by: 'system-auto-finalize',
        is_force_finalized: false,
      })
      .eq('id', proposal.id);

    // Update DAO stats using RPC function
    await supabase.rpc('update_dao_proposal_stats', {
      p_dao_id: proposal.dao_id,
      p_old_status: 'active',
      p_new_status: newStatus,
    });

    finalized++;
  }

  console.log(`Auto-finalized ${finalized} proposals`);
  return new Response(`Auto-finalized ${finalized} proposals`);
});
```

#### 2. Deploy Function

```bash
# Deploy to Supabase
supabase functions deploy auto-finalize-proposals

# Set up cron schedule using pg_cron
# In Supabase SQL Editor:
select cron.schedule(
  'auto-finalize-proposals',
  '*/10 * * * *', -- every 10 minutes
  $$
  select
    net.http_post(
      url:='https://YOUR_PROJECT_REF.supabase.co/functions/v1/auto-finalize-proposals',
      headers:='{"Authorization": "Bearer YOUR_SERVICE_ROLE_KEY"}'::jsonb
    ) as request_id;
  $$
);
```

#### 3. Monitor Function

```bash
# View logs in Supabase Dashboard > Edge Functions > Logs

# Or via CLI
supabase functions logs auto-finalize-proposals
```

**Cost Estimate** (Supabase):

- Edge Function invocations: 144/day (every 10 minutes) = ~4,320/month
- Supabase Pro plan includes generous free tier
- **Cost**: FREE (well within free tier)

## Database Requirements

### PostgreSQL Composite Index

**Required for auto-finalization query**:

```sql
-- Index for efficient proposal queries by status and end time
CREATE INDEX idx_proposals_auto_finalize
ON proposals (dao_id, status, end_time)
WHERE status = 'active';
```

**Status**: ✅ Added to Supabase migrations

**Deploy**:

```bash
supabase db push
# or
supabase migration up
```

## Service Methods

### `autoFinalizeExpiredProposals(daoId: string)`

Finds and finalizes all active proposals that have passed their `endTime`.

**Parameters**:

- `daoId` - DAO ID to check for expired proposals

**Returns**:

```typescript
{
  success: boolean
  data?: {
    finalized: number // Count of finalized proposals
    errors: Array<{ proposalId: string; error: string }> // Any errors
  }
  error?: string
}
```

**Example**:

```typescript
const result = await proposalService.autoFinalizeExpiredProposals('dao-123');
if (result.success) {
  console.log(`Finalized ${result.data.finalized} proposals`);
}
```

## Testing

### Manual Test

```typescript
// In browser console or test file
import { ProposalService } from '@/lib/services/proposal.service';

const service = ProposalService.getInstance();
const result = await service.autoFinalizeExpiredProposals('your-dao-id');
console.log(result);
```

### Integration Test

```typescript
describe('Auto-finalization', () => {
  it('should finalize expired proposals', async () => {
    // Create test proposal with past endTime
    const proposal = await createTestProposal({
      status: 'active',
      endTime: new Date(Date.now() - 3600000), // 1 hour ago
    });

    // Run auto-finalization
    const result = await service.autoFinalizeExpiredProposals(daoId);

    // Verify finalization
    expect(result.success).toBe(true);
    expect(result.data.finalized).toBe(1);

    // Verify proposal status updated
    const updated = await service.getProposal(proposal.id);
    expect(updated.data.status).not.toBe('active');
  });
});
```

## Migration Path

### Phase 1: Client-Side (Current) ✅

- Implemented `useAutoFinalize` hook
- Works in production today
- No infrastructure changes needed

### Phase 2: Hybrid (Recommended Next Step)

- Keep client-side for immediate finalization
- Add Cloud Function for guaranteed finalization
- Best of both worlds

### Phase 3: Cloud Function Only (Future)

- Remove client-side auto-finalization
- Rely entirely on scheduled function
- Simpler, more predictable

## Monitoring

### Metrics to Track

1. **Finalization Latency**: Time between `endTime` and actual finalization
2. **Finalization Rate**: Percentage of proposals finalized automatically vs manually
3. **Error Rate**: Failed auto-finalization attempts
4. **User Experience**: User complaints about "stuck" active proposals

### Supabase Dashboard

**Database**:

- Query: `SELECT * FROM proposals WHERE status = 'active' AND end_time < now()`
- Should return 0 results (all finalized)

**Edge Functions** (when implemented):

- Execution count: Should run every 10 minutes
- Success rate: Should be >99%
- Execution time: Should be <10 seconds

## Troubleshooting

### Proposals Not Auto-Finalizing

**Client-Side**:

1. Check if `useAutoFinalize` hook is enabled
2. Verify interval is set correctly
3. Check browser console for errors
4. Ensure users are visiting proposal pages

**Edge Function**:

1. Check function is deployed: `supabase functions list`
2. View logs in Supabase Dashboard or: `supabase functions logs`
3. Verify PostgreSQL index exists
4. Check pg_cron schedule is active

### Performance Issues

**Too Many Proposals**:

- Batch processing in chunks of 100
- Consider multiple Edge Functions for different DAO sizes
- Add rate limiting if needed

**Database Costs**:

- Monitor read/write operations
- Client-side: ~2 reads per check per DAO
- Edge Function: ~100 reads per execution (batch)

## Security

### Access Control

- Client-side finalization uses service account (`system-auto-finalize`)
- Edge Function runs with service role privileges
- No user permissions required (automatic system operation)

### Audit Trail

All auto-finalizations are logged:

```typescript
{
  action: 'proposals_auto_finalized',
  daoId: 'dao-123',
  count: 5,
  errors: 0,
  finalizedBy: 'system-auto-finalize',
  timestamp: Timestamp
}
```

## Related Documentation

- [Proposal Lifecycle](/docs/features/PROPOSAL_LIFECYCLE.md)
- [Voting System](/docs/features/VOTING_SYSTEM.md)
- [Supabase Edge Functions](/docs/deployment/EDGE_FUNCTIONS.md)

## Changelog

### v1.0.0 (October 29, 2025)

- ✅ Initial implementation
- ✅ Client-side auto-finalization with `useAutoFinalize` hook
- ✅ Service method `autoFinalizeExpiredProposals()`
- ✅ PostgreSQL composite index added
- ✅ Documentation for Edge Function migration path
