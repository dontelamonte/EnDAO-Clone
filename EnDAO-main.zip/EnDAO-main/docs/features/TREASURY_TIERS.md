# Treasury Tier System

**Document Status**: Implementation Specification
**Last Updated**: December 5, 2025
**Related**: `/docs/architecture/TREASURY.md`, `/src/lib/services/treasury/`

---

## Overview

EnDAO's Treasury Tier System provides a progressive path from simple expense tracking to enterprise-grade multi-signature treasury management. Each tier is designed to match the needs and sophistication of different DAO types and growth stages.

### Tier Comparison

| Tier | Name        | Treasury Mode        | Spending Limits   | Target User              |
| ---- | ----------- | -------------------- | ----------------- | ------------------------ |
| 1    | Starter     | Disabled/Tracking    | N/A               | Community orgs, new DAOs |
| 2    | Growing     | Simple Safe (2-of-3) | App-layer only    | Small businesses         |
| 3    | Established | Safe + Ops Wallet    | On-chain (Zodiac) | Established nonprofits   |
| 4    | Enterprise  | Sub-DAOs + Dashboard | Full hierarchy    | Networks, federations    |

---

## Tier 1: Starter (Disabled/Tracking Mode)

**Purpose**: Allow DAOs to track finances without blockchain complexity or crypto requirements.

### Implementation

#### Type Extensions

```typescript
// packages/shared-types/src/dao.ts - import from @endao/shared-types
interface DAO {
  // ... existing fields

  // Treasury Tier System
  treasuryTier: 1 | 2 | 3 | 4;
  treasuryMode: 'disabled' | 'tracking' | 'safe';

  // Tier 1 specific
  trackingLedger?: {
    entries: LedgerEntry[];
    totalIn: number;
    totalOut: number;
  };
}

interface LedgerEntry {
  id: string;
  date: Timestamp;
  description: string;
  amount: number;
  category: 'income' | 'expense';
  attachments?: string[];
  createdBy: string;
}
```

### UI Requirements

- **Simple Ledger Interface**: Income/expense tracking with categories
- **No Blockchain Integration**: Pure database storage (Supabase)
- **Export Functionality**: CSV/PDF export for tax purposes
- **Upgrade CTA**: Prominent "Upgrade to Safe" button when first funding proposal is created

### Upgrade Trigger

```typescript
// src/lib/services/treasury/tier-upgrade.service.ts
async function checkTierUpgrade(
  daoId: string,
  proposalType: string
): Promise<void> {
  if (proposalType === 'funding') {
    const dao = await daoRepository.findById(daoId);
    if (dao.treasuryTier === 1) {
      // Prompt user to upgrade to Tier 2
      await notificationService.sendUpgradePrompt(daoId, {
        currentTier: 1,
        suggestedTier: 2,
        reason: 'First funding proposal requires treasury',
      });
    }
  }
}
```

---

## Tier 2: Growing (Simple Safe)

**Purpose**: Secure multi-signature treasury for DAOs handling on-chain funds.

### What Exists

Full Safe integration is already implemented in the codebase:

- Gnosis Safe deployment via `/src/lib/services/safe/`
- 2-of-3 default threshold
- Gasless deployment via Biconomy
- Multi-signature transaction execution

### What's Missing

Clear tier designation during DAO creation flow.

### Implementation

```typescript
// src/app/dao/new/page.tsx - Update creation flow
const tierOptions = [
  {
    tier: 1,
    name: 'Starter',
    description: 'Track finances without blockchain',
    features: [
      'Income/expense tracking',
      'Export reports',
      'No crypto required',
    ],
    recommended: daoType === 'community',
  },
  {
    tier: 2,
    name: 'Growing',
    description: 'Secure multi-sig treasury',
    features: ['Gnosis Safe vault', '2-of-3 signing', 'On-chain transactions'],
    recommended: daoType === 'commerce',
  },
];
```

### Safe Configuration (Existing)

- **Threshold**: 2-of-3 signers by default
- **Deployment**: Automatic Safe deployment on tier selection
- **Gas**: Gasless deployment via Biconomy MEE
- **Network**: Base mainnet (production)

---

## Tier 3: Established (Ops Wallet with Spending Limits)

**Purpose**: Enable day-to-day spending without full governance overhead while maintaining treasury security.

### Architecture

```
┌─────────────────────────────────────────────┐
│           Main Safe (Vault)                 │
│     Requires full governance proposal       │
│     Balance: Majority of funds              │
└──────────────────┬──────────────────────────┘
                   │
                   │ Periodic refill via proposal
                   ▼
┌─────────────────────────────────────────────┐
│           Ops Wallet (Quick Spend)          │
│  • maxDailySpend: $1,000                    │
│  • maxSingleTransaction: $500               │
│  • requiresApprovalAbove: $250              │
│  • Single-signer (treasurer role)           │
└─────────────────────────────────────────────┘
```

### Phase 1: App-Layer Enforcement (MVP)

Initial implementation uses app-layer validation before on-chain enforcement is added.

#### OpsWalletService

```typescript
// src/lib/services/treasury/ops-wallet.service.ts
interface OpsWalletConfig {
  mainSafeAddress: string;
  opsWalletAddress: string;
  maxDailySpend: number; // in USD
  maxSingleTransaction: number; // in USD
  requiresApprovalAbove: number; // in USD
  treasurerUserIds: string[]; // Single-signers
  refillThreshold: number; // Auto-request refill when balance below this
}

class OpsWalletService {
  async validateTransaction(
    daoId: string,
    amount: number,
    treasurerId: string
  ): Promise<ValidationResult> {
    const config = await this.getConfig(daoId);

    // Check single transaction limit
    if (amount > config.maxSingleTransaction) {
      return { valid: false, reason: 'Exceeds single transaction limit' };
    }

    // Check daily spend
    const todaySpend = await this.getDailySpend(daoId);
    if (todaySpend + amount > config.maxDailySpend) {
      return { valid: false, reason: 'Exceeds daily spend limit' };
    }

    // Check if requires additional approval
    if (amount > config.requiresApprovalAbove) {
      return { valid: true, requiresApproval: true };
    }

    return { valid: true, requiresApproval: false };
  }

  async executeOpsTransaction(
    daoId: string,
    recipient: string,
    amount: number,
    treasurerId: string
  ): Promise<TransactionResult> {
    const validation = await this.validateTransaction(
      daoId,
      amount,
      treasurerId
    );

    if (!validation.valid) {
      throw new Error(validation.reason);
    }

    if (validation.requiresApproval) {
      // Create approval request, notify other treasurer
      return this.createApprovalRequest(daoId, recipient, amount, treasurerId);
    }

    // Execute directly via ops wallet Safe
    return this.executeDirectly(daoId, recipient, amount);
  }
}
```

### Refill Flow (Vault → Ops Wallet)

```typescript
// src/lib/services/treasury/ops-refill.service.ts
interface RefillRequest {
  id: string;
  daoId: string;
  opsWalletAddress: string;
  requestedAmount: number;
  currentBalance: number;
  threshold: number;
  status: 'pending' | 'proposed' | 'approved' | 'executed' | 'rejected';
  proposalId?: string;
  createdAt: Timestamp;
  executedAt?: Timestamp;
}

class OpsRefillService {
  async checkRefillNeeded(daoId: string): Promise<boolean> {
    const config = await this.getOpsWalletConfig(daoId);
    const balance = await this.getOpsWalletBalance(config.opsWalletAddress);

    return balance < config.refillThreshold;
  }

  async initiateRefill(daoId: string): Promise<RefillRequest> {
    const config = await this.getOpsWalletConfig(daoId);
    const currentBalance = await this.getOpsWalletBalance(
      config.opsWalletAddress
    );

    // Calculate refill amount (bring back to max daily spend * 7 days)
    const targetBalance = config.maxDailySpend * 7;
    const refillAmount = targetBalance - currentBalance;

    // Create refill request
    const request: RefillRequest = {
      id: generateId(),
      daoId,
      opsWalletAddress: config.opsWalletAddress,
      requestedAmount: refillAmount,
      currentBalance,
      threshold: config.refillThreshold,
      status: 'pending',
      createdAt: Timestamp.now(),
    };

    await this.saveRefillRequest(request);

    // Auto-create funding proposal
    const proposal = await this.proposalService.create({
      daoId,
      type: 'funding',
      title: `Ops Wallet Refill: $${refillAmount.toLocaleString()}`,
      description: `Automatic refill request. Current balance: $${currentBalance.toLocaleString()}, Target: $${targetBalance.toLocaleString()}`,
      amount: refillAmount,
      recipientAddress: config.opsWalletAddress,
      metadata: {
        refillRequestId: request.id,
        autoGenerated: true,
      },
    });

    request.proposalId = proposal.id;
    request.status = 'proposed';
    await this.saveRefillRequest(request);

    // Notify treasurers
    await this.notificationService.notifyTreasurers(daoId, {
      type: 'ops_refill_needed',
      requestId: request.id,
      amount: refillAmount,
    });

    return request;
  }

  // Scheduled job to check all Ops Wallets
  async runRefillCheck(): Promise<void> {
    const daosWithOpsWallet = await this.daoRepository.findWithOpsWallet();

    for (const dao of daosWithOpsWallet) {
      const needsRefill = await this.checkRefillNeeded(dao.id);

      if (needsRefill) {
        const existingRequest = await this.getPendingRefillRequest(dao.id);

        if (!existingRequest) {
          await this.initiateRefill(dao.id);
        }
      }
    }
  }
}
```

### Phase 2: On-Chain Enforcement (Zodiac Modules)

Future enhancement using Zodiac modules for trustless spending limit enforcement.

**Contract**: `contracts/SpendingLimitsModule.sol`

**Key Features**:

- Daily spend limits enforced at contract level
- Single transaction maximums
- Multi-sig approval thresholds
- Automatic daily reset mechanism

**Note**: Phase 2 implementation deferred until Tier 3 is in active use.

---

## Tier 4: Enterprise (Sub-DAOs)

**Purpose**: Enable DAO networks and federations with hierarchical treasury management.

See `/docs/architecture/SUB_DAOS.md` for full Sub-DAO architecture specification.

**Key Features**:

- Parent DAO treasury consolidation
- Department-level budgets and autonomy
- Centralized reporting dashboard
- Cross-DAO fund transfers with approval workflows

---

## Upgrade Triggers Between Tiers

### Tier 1 → Tier 2

**Trigger**: First funding proposal created

**Process**:

1. System detects proposal type `funding` while `treasuryTier === 1`
2. Modal displayed: "Funding proposals require a treasury. Upgrade to Tier 2?"
3. User initiates Safe deployment process
4. DAO `treasuryTier` updated to `2`, `treasuryMode` set to `safe`

### Tier 2 → Tier 3

**Trigger**: Manual upgrade when daily operational spending becomes frequent

**Indicators**:

- More than 5 funding proposals per month
- Average proposal amount < $500 (suggests operational expenses)
- Admin feedback requesting faster spending approval

**Process**:

1. Admin navigates to Treasury Settings
2. Clicks "Enable Ops Wallet"
3. Configures spending limits and designates treasurers
4. System deploys secondary Safe for ops wallet
5. DAO `treasuryTier` updated to `3`

### Tier 3 → Tier 4

**Trigger**: Manual upgrade when departments need independent budgets

**Indicators**:

- More than 3 distinct budget categories in proposals
- Request for department-level financial autonomy
- Need for consolidated reporting across teams

**Process**:

1. Admin navigates to DAO Settings → Sub-DAOs
2. Clicks "Enable Sub-DAOs"
3. Creates initial sub-DAOs with budget allocations
4. DAO `treasuryTier` updated to `4`

---

## Testing Requirements

### Unit Tests

- `OpsWalletService.validateTransaction()` - All limit scenarios
- `OpsRefillService.checkRefillNeeded()` - Threshold detection
- `TierUpgradeService.checkTierUpgrade()` - Trigger logic

### Integration Tests

- Tier 1: Create ledger entry, export to CSV
- Tier 2: Deploy Safe, execute multi-sig transaction
- Tier 3: Execute ops transaction with approval flow, trigger refill

### E2E Tests (Playwright)

- Full user journey: Tier 1 → Create funding proposal → Upgrade to Tier 2 → Deploy Safe
- Ops wallet transaction flow: Treasurer initiates payment → Validation → Execution

---

## Implementation Checklist

### Tier 1 (Tracking Mode)

- [ ] Add `treasuryTier` and `trackingLedger` fields to DAO type
- [ ] Create Tier 1 ledger UI component
- [ ] Implement CSV/PDF export functionality
- [ ] Add tier upgrade prompt on first funding proposal

### Tier 2 (Simple Safe)

- [x] Safe deployment service (already implemented)
- [x] Multi-sig transaction execution (already implemented)
- [ ] Update DAO creation flow with tier selection
- [ ] Add tier indicator to DAO dashboard

### Tier 3 (Ops Wallet)

- [ ] Implement `OpsWalletService` with validation logic
- [ ] Create `OpsRefillService` with scheduled job
- [ ] Build Ops Wallet UI (transaction form, approval flow)
- [ ] Add Treasury Settings page for limit configuration

### Tier 4 (Enterprise)

- [ ] See Sub-DAO implementation checklist in `/docs/architecture/SUB_DAOS.md`

---

## Related Documentation

- `/docs/architecture/TREASURY.md` - Overall treasury architecture
- `/docs/architecture/SUB_DAOS.md` - Tier 4 implementation details
- `/docs/security/TREASURY_PROTECTION.md` - 4-layer security system
- `CLAUDE.md` - Treasury protection rules and testing requirements
