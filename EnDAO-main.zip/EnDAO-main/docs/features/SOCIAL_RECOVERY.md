# Social Recovery System

**Status**: MVP Blocker (Phase 1 Priority)
**Criticality**: HIGH - Security & Access Control
**Owner**: Platform Team

---

## 1. Purpose and Concept

Social Recovery allows DAO members to designate trusted guardians who can collectively restore access to the DAO's Gnosis Safe if the primary owner loses access. This provides a safety net without requiring centralized custodians.

**Key Principles**:

- **Collective Trust**: No single guardian can trigger recovery alone
- **Timelock Protection**: Admins have time to cancel fraudulent recovery attempts
- **Weight-Based Threshold**: Flexible guardian weighting (not just simple majority)
- **Transparent Audit**: All recovery actions are logged immutably

**Use Cases**:

- Primary owner loses private key or wallet access
- Owner incapacitated or unavailable for extended period
- Emergency access needed when primary owner unresponsive

---

## 2. Data Schema

### RecoveryConfig Interface

```typescript
interface RecoveryConfig {
  daoId: string;

  // Guardian Configuration
  guardians: Array<{
    userId: string; // EnDAO user ID
    email: string; // For recovery notifications
    addedAt: Timestamp;
    recoveryWeight: number; // 1-100, typically all equal (e.g., 3 guardians = 33.33 each)
  }>;

  // Recovery Thresholds
  recoveryThreshold: number; // Total weight needed to approve recovery (e.g., 60)
  timelockDuration: number; // Seconds before execution (recommended: 7 days = 604800)

  // Active Recovery State
  pendingRecovery?: {
    initiatedBy: string; // Guardian who started the process
    initiatedAt: Timestamp;
    newOwnerAddress: string; // Target Safe owner address
    guardianApprovals: Array<{
      guardianId: string;
      approvedAt: Timestamp;
    }>;
    totalWeight: number; // Current accumulated weight
    executesAt: Timestamp; // When recovery can be executed
    status: 'pending' | 'approved' | 'cancelled' | 'executed';
  };
}
```

**Storage Location**: `recovery-configs` collection (indexed by `daoId`)

---

## 3. Service Implementation

### SocialRecoveryService

**Location**: `src/lib/services/recovery/social-recovery.service.ts`

```typescript
class SocialRecoveryService {
  /**
   * Initiate a recovery request
   * @throws Error if requester is not a guardian
   */
  async initiateRecovery(
    daoId: string,
    requesterId: string,
    newOwnerAddress: string
  ): Promise<RecoveryRequest> {
    const config = await this.getConfig(daoId);

    // Validate requester is a guardian
    const guardian = config.guardians.find((g) => g.userId === requesterId);
    if (!guardian) throw new Error('Not a guardian');

    // Create pending recovery
    const request: PendingRecovery = {
      initiatedBy: requesterId,
      initiatedAt: Timestamp.now(),
      newOwnerAddress,
      guardianApprovals: [
        {
          guardianId: requesterId,
          approvedAt: Timestamp.now(),
        },
      ],
      totalWeight: guardian.recoveryWeight,
      executesAt: Timestamp.fromMillis(
        Date.now() + config.timelockDuration * 1000
      ),
      status: 'pending',
    };

    await this.saveRecovery(daoId, request);

    // Notify all other guardians
    await this.notifyGuardians(daoId, config.guardians, request);

    // Notify current DAO admins (they can cancel)
    await this.notifyAdmins(daoId, request);

    return request;
  }

  /**
   * Guardian approves a pending recovery
   * @throws Error if no pending recovery or guardian already approved
   */
  async approveRecovery(daoId: string, guardianId: string): Promise<void> {
    const config = await this.getConfig(daoId);
    const pending = config.pendingRecovery;

    if (!pending || pending.status !== 'pending') {
      throw new Error('No pending recovery');
    }

    const guardian = config.guardians.find((g) => g.userId === guardianId);
    if (!guardian) throw new Error('Not a guardian');

    // Check not already approved
    if (pending.guardianApprovals.some((a) => a.guardianId === guardianId)) {
      throw new Error('Already approved');
    }

    // Add approval
    pending.guardianApprovals.push({
      guardianId,
      approvedAt: Timestamp.now(),
    });
    pending.totalWeight += guardian.recoveryWeight;

    // Check if threshold met
    if (pending.totalWeight >= config.recoveryThreshold) {
      pending.status = 'approved';
      // Schedule execution after timelock
      await this.scheduleExecution(daoId, pending);
    }

    await this.saveRecovery(daoId, pending);
  }

  /**
   * Execute approved recovery (called after timelock)
   * @throws Error if timelock not elapsed or recovery not approved
   */
  async executeRecovery(daoId: string): Promise<void> {
    const config = await this.getConfig(daoId);
    const pending = config.pendingRecovery;

    if (pending?.status !== 'approved') {
      throw new Error('Recovery not approved');
    }

    if (Date.now() < pending.executesAt.toMillis()) {
      throw new Error('Timelock not elapsed');
    }

    // Execute Safe owner swap
    await this.swapSafeOwner(daoId, pending.newOwnerAddress);

    pending.status = 'executed';
    await this.saveRecovery(daoId, pending);

    await auditService.log(daoId, 'recovery_executed', {
      newOwner: pending.newOwnerAddress,
      guardianApprovals: pending.guardianApprovals.length,
    });
  }

  /**
   * Cancel pending recovery (admin only)
   * @throws Error if no pending recovery
   */
  async cancelRecovery(daoId: string, adminId: string): Promise<void> {
    const config = await this.getConfig(daoId);
    const pending = config.pendingRecovery;

    if (!pending || pending.status === 'executed') {
      throw new Error('No active recovery to cancel');
    }

    // Verify admin permissions
    await this.verifyAdminAccess(daoId, adminId);

    pending.status = 'cancelled';
    await this.saveRecovery(daoId, pending);

    await auditService.log(daoId, 'recovery_cancelled', {
      cancelledBy: adminId,
      pendingRecovery: pending,
    });

    // Notify all guardians of cancellation
    await this.notifyGuardians(daoId, config.guardians, {
      type: 'recovery_cancelled',
      cancelledBy: adminId,
    });
  }
}
```

---

## 4. Recovery Flow

### Phase 1: Initiation

1. **Guardian Access**: Any designated guardian can initiate recovery
2. **New Owner Specification**: Guardian provides new Safe owner address
3. **Automatic Approval**: Initiating guardian's approval is recorded automatically
4. **Weight Calculation**: System adds initiator's weight to `totalWeight`
5. **Notification Cascade**: All other guardians and current admins are notified

### Phase 2: Approval Collection

1. **Guardian Review**: Notified guardians review the recovery request
2. **Approval Recording**: Each guardian approves via dedicated endpoint
3. **Weight Accumulation**: System adds each guardian's weight to total
4. **Threshold Check**: When `totalWeight >= recoveryThreshold`, status changes to `approved`
5. **Timelock Start**: `executesAt` timestamp determines when execution is allowed

### Phase 3: Timelock Period

1. **Waiting Period**: Typically 7 days (configurable via `timelockDuration`)
2. **Admin Monitoring**: Current admins can cancel if recovery is fraudulent
3. **Cancellation Option**: Admins call `cancelRecovery()` to abort the process
4. **Status Visibility**: UI shows countdown to execution time

### Phase 4: Execution

1. **Timelock Validation**: System verifies `Date.now() >= executesAt`
2. **Approval Check**: Confirms `status === 'approved'`
3. **Safe Owner Swap**: Executes Gnosis Safe owner replacement transaction
4. **Status Update**: Marks recovery as `executed`
5. **Audit Log**: Immutable record of recovery execution
6. **Final Notifications**: All stakeholders notified of completion

---

## 5. UI Requirements

### 5.1 Guardian Nomination Page

**Route**: `/dao/[id]/settings/recovery`

**Features**:

- Add/remove guardians (admins only)
- Set guardian weights (default: equal distribution)
- Configure recovery threshold (recommended: 60%)
- Set timelock duration (recommended: 7 days)
- Display current guardian list with weights

### 5.2 Recovery Initiation (Guardian View)

**Route**: `/recovery/initiate/[daoId]`

**Features**:

- Verify guardian status
- Input new owner address (with ENS support)
- Display recovery threshold and timelock duration
- Confirm initiation with warnings

### 5.3 Approval Dashboard (Guardian View)

**Route**: `/recovery/pending`

**Features**:

- List all pending recovery requests for guardians
- Show current approval status (weight collected vs. threshold)
- One-click approval with confirmation modal
- Display DAO details and context

### 5.4 Admin Cancellation Interface

**Route**: `/dao/[id]/settings/recovery` (admin section)

**Features**:

- Alert banner when recovery is pending
- Countdown to execution time
- Cancellation button with multi-step confirmation
- Reason field for audit trail

### 5.5 Status Timeline Component

**Component**: `RecoveryStatusTimeline`

**Displays**:

- Initiation event with timestamp
- Guardian approvals (checkmarks with timestamps)
- Threshold progress bar (current weight / required weight)
- Timelock countdown (when approved)
- Cancellation event (if applicable)
- Execution event (when complete)

---

## 6. Timelock and Cancellation Logic

### Timelock Protection

**Purpose**: Prevents immediate execution, giving admins time to respond to unauthorized recovery attempts.

**Recommended Duration**: 7 days (604,800 seconds)

**Implementation**:

```typescript
// Set execution time on approval
const executesAt = Timestamp.fromMillis(
  Date.now() + config.timelockDuration * 1000
);

// Validate before execution
if (Date.now() < pending.executesAt.toMillis()) {
  throw new Error('Timelock not elapsed');
}
```

### Cancellation Logic

**Who Can Cancel**:

- DAO admins (any admin can cancel)
- Automatic cancellation if DAO is deleted

**When Cancellation is Allowed**:

- `status === 'pending'` (before threshold met)
- `status === 'approved'` (during timelock)
- NOT allowed after `status === 'executed'`

**Cancellation Flow**:

1. Admin calls `cancelRecovery(daoId, adminId)`
2. System verifies admin permissions
3. Recovery status set to `cancelled`
4. Audit log entry created
5. All guardians notified of cancellation
6. Recovery state cleared (or marked cancelled for history)

---

## 7. Security Considerations

1. **Guardian Selection**: Guardians should be truly independent and trusted
2. **Weight Distribution**: Avoid single guardian having >threshold weight
3. **Notification Channels**: Email notifications critical for timely awareness
4. **Timelock Duration**: Balance between security and recovery urgency
5. **Audit Trail**: All recovery events must be immutably logged
6. **Address Validation**: Verify new owner address before execution
7. **Admin Alerts**: Real-time notifications when recovery initiated

---

## 8. Future Enhancements (Phase 3)

### EnDAO Guardian Service

- EnDAO holds 1 guardian slot as paid service
- 24/7 monitoring and response SLA
- Identity verification before approving recovery
- Monthly fee based on treasury size ($100-$1000/mo)
- Enterprise-grade backup option for high-value DAOs

---

_Last Updated: December 5, 2025_
_Related Docs: Treasury Protection System, Gnosis Safe Integration_
