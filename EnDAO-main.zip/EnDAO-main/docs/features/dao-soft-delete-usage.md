# DAO Soft Delete Service Usage Guide

## Purpose

This guide provides implementation examples and usage patterns for the DAOSoftDeleteService, which manages the 7-day grace period before permanent DAO deletion with treasury protection.

## Last Updated

September 2025

The DAOSoftDeleteService manages the 7-day grace period before permanent DAO deletion, providing protection against accidental deletions and coordination with treasury services.

## Key Features

- **7-day grace period** before permanent deletion
- **Treasury freeze** during deletion process to protect funds
- **Automatic notifications** to Safe owners and DAO members
- **Recovery capability** during grace period
- **Audit trail** for all deletion activities
- **Integration** with TreasuryAccessControlService and TreasuryNotificationService

## Basic Usage

### 1. Initiate Deletion (Start Grace Period)

```typescript
import { daoSoftDeleteService } from '@/lib/services/dao/dao-soft-delete.service';

const result = await daoSoftDeleteService.initiateDeletion(
  'dao-id-123',
  'admin-user-id',
  'DAO no longer needed',
  authContext, // Optional: auth context for audit trail
  7 // Optional: grace period in days (default: 7)
);

if (result.success) {
  console.log('Deletion initiated:', result.data);
  // {
  //   success: true,
  //   deletionRecordId: 'deletion-record-id',
  //   gracePeriodStatus: { isActive: true, daysRemaining: 7, ... },
  //   treasuryFrozen: true,
  //   notificationsSent: true
  // }
}
```

### 2. Check Grace Period Status

```typescript
const statusResult =
  await daoSoftDeleteService.checkGracePeriodStatus('dao-id-123');

if (statusResult.success && statusResult.data) {
  const status = statusResult.data;
  console.log(`Days remaining: ${status.daysRemaining}`);
  console.log(`Can recover: ${status.canRecover}`);
  console.log(`Deletion date: ${status.scheduledDeletionDate}`);
}
```

### 3. Recover DAO (Cancel Deletion)

```typescript
const recoveryResult = await daoSoftDeleteService.recoverDAO(
  'dao-id-123',
  'admin-user-id',
  authContext,
  'False alarm - keeping the DAO' // Optional recovery reason
);

if (recoveryResult.success) {
  console.log('DAO recovered successfully:', recoveryResult.data);
  // {
  //   success: true,
  //   treasuryUnfrozen: true,
  //   notificationsSent: true,
  //   restoredData: { name: '...', status: 'active', ... }
  // }
}
```

### 4. Check if Recovery is Possible

```typescript
const canRecoverResult = await daoSoftDeleteService.canRecover('dao-id-123');

if (canRecoverResult.success && canRecoverResult.data) {
  console.log('DAO can be recovered');
} else {
  console.log('Recovery period has expired');
}
```

### 5. Execute Permanent Deletion (Admin Only)

```typescript
// Only callable after grace period expires
const deletionResult = await daoSoftDeleteService.executeDeletion(
  'dao-id-123',
  'admin-user-id',
  authContext
);

if (deletionResult.success) {
  console.log('DAO permanently deleted');
}
```

## Admin Dashboard Usage

### Get All DAOs Pending Deletion

```typescript
const pendingResult = await daoSoftDeleteService.getDAOsPendingDeletion();

if (pendingResult.success) {
  for (const item of pendingResult.data) {
    console.log(`DAO: ${item.dao.name}`);
    console.log(`Days remaining: ${item.gracePeriodStatus.daysRemaining}`);
    console.log(`Can recover: ${item.gracePeriodStatus.canRecover}`);
  }
}
```

### Get Deletion History

```typescript
const historyResult =
  await daoSoftDeleteService.getDeletionHistory('dao-id-123');

if (historyResult.success) {
  for (const record of historyResult.data) {
    console.log(`Status: ${record.status}`);
    console.log(`Initiated by: ${record.initiatedBy}`);
    console.log(`Reason: ${record.reason}`);
  }
}
```

## Integration with Treasury Services

The service automatically coordinates with treasury services:

### Treasury Freeze

- Automatically freezes treasury when deletion is initiated
- Prevents all treasury operations during grace period
- Unfreezes treasury when DAO is recovered

### Notifications

- Sends immediate notification to Safe owners
- Schedules reminder notifications (5 days, 3 days, 1 day)
- Sends recovery confirmation notifications
- Uses user-friendly language for non-crypto users

## Error Handling

All methods return `ServiceResponse<T>` with consistent error handling:

```typescript
const result = await daoSoftDeleteService.initiateDeletion(...)

if (!result.success) {
  console.error('Deletion failed:', result.error)

  // Common errors:
  // - "DAO not found"
  // - "DAO is already pending deletion"
  // - "Cannot delete DAO with status: deleted"
  // - "Only admins can initiate deletion"
}
```

## Database Collections

### `dao_deletion_tracking`

Tracks all deletion requests with:

- Grace period configuration
- Original DAO snapshot for recovery
- Status transitions (pending → executed/recovered)
- Audit trail with timestamps

### DAO Document Updates

Adds fields to existing DAO documents:

- `status: 'pending_deletion' | 'deleted'`
- `pendingDeletionSince: Timestamp`
- `recoveredAt: Timestamp` (if recovered)
- `recoveredBy: string` (if recovered)

## Security Considerations

1. **Admin-only operations**: Only DAO admins can initiate/recover deletions
2. **Grace period enforcement**: Cannot bypass the 7-day grace period
3. **Treasury protection**: Treasury is frozen during entire process
4. **Audit logging**: All actions are logged for accountability
5. **Notification transparency**: All stakeholders are notified

## Maintenance

### Cleanup Expired Records

```typescript
const cleanupResult = await daoSoftDeleteService.cleanupExpiredRecords(30);
console.log(`Cleaned up ${cleanupResult.data?.deletedCount} old records`);
```

## Status Flow

```
DAO Status Flow:
active → pending_deletion → deleted (permanent)
          ↓
       recovered → active
```

## Grace Period Timeline

```
Day 0: Deletion initiated
       - Treasury frozen
       - Notifications sent
       - Grace period starts

Day 2: Reminder notification (5 days remaining)
Day 4: Reminder notification (3 days remaining)
Day 6: Final warning notification (1 day remaining)

Day 7: Grace period expires
       - Can execute permanent deletion
       - Recovery no longer possible
```
