# Admin Permission Safeguards - Phase 2: Multi-Signature Approval Workflow

## Purpose

Documents the implementation of Phase 2 multi-signature approval workflow, including proposal creation, approval process, timelocks, and execution controls for critical admin actions.

## Last Updated

October 3, 2025

**Status**: ✅ Implementation Complete
**Date**: October 3, 2025
**Version**: 2.0.0

---

## Overview

Phase 2 implements the multi-signature approval workflow system that requires 2+ admins to approve critical admin actions (delete DAO, demote admin, etc.) with configurable timelocks.

Building on Phase 1's audit logging foundation, this phase adds the governance layer that prevents single-admin abuse of critical operations.

---

## Implementation Summary

### Files Created

#### 1. Type Definitions

**File**: `src/lib/services/admin/types/proposal.types.ts` (66 lines)

**Exports**:

- `ProposalStatus` enum (pending, approved, executed, cancelled, rejected, expired)
- `ActionTier` enum (tier_1, tier_2, tier_3, tier_4)
- `AdminActionProposal` interface
- `AdminApproval` interface
- `CreateProposalParams` interface
- `ApproveProposalParams` interface

**Key Concepts**:

- Proposal lifecycle: Pending → Approved → Executed
- Timelock enforcement: 72hr, 24hr, or 0hr based on tier
- Approval tracking: Array of admin approvals with timestamps

#### 2. Governance Logic Service

**File**: `src/lib/services/admin/admin-governance.service.ts` (162 lines)

**Singleton Service**: `AdminGovernanceService`

**Core Methods**:

- `getActionTier(action)` - Determines tier (1-4) for an action
- `getTimelockDuration(tier)` - Returns timelock in milliseconds
- `requiresMultiSig(dao, action)` - Checks if multi-sig is needed
- `calculateRequiredApprovals(dao, action)` - Returns approval threshold
- `requiresUnanimousApproval(dao, action)` - Special case for security downgrades

**Action Tier Classification**:

- **Tier 1 (72-hour timelock)**: DAO deletion, member ban
- **Tier 2 (24-hour timelock)**: Admin demotion, multi-sig disable, governance changes
- **Tier 3 (immediate)**: Member removal, role changes, settings updates
- **Tier 4 (immediate)**: Low-risk admin actions

**Multi-Sig Logic**:

- Disabled if `dao.governanceSettings.requireMultiSigForCritical = false`
- Bypassed if only 1 admin exists (impossible to get 2 approvals)
- Only Tier 1 & 2 actions require multi-sig
- Default threshold: 2-of-N approval

#### 3. Proposal Workflow Service

**File**: `src/lib/services/admin/admin-action-proposal.service.ts` (395 lines)

**Singleton Service**: `AdminActionProposalService`

**Core Methods**:

- `proposeAction(dao, params)` - Create a new proposal
- `approveProposal(dao, params)` - Approve a pending proposal
- `cancelProposal(dao, proposalId, adminId, adminName, reason)` - Cancel before execution
- `executeProposal(proposalId)` - Mark as executed (after timelock)
- `getPendingProposals(daoId, limit)` - Get active proposals for a DAO
- `getProposal(proposalId)` - Get proposal details by ID

**Workflow**:

1. **Initiation**: Admin creates proposal → auto-approves (1/N)
2. **Approval**: Other admins approve → increments counter
3. **Threshold Met**: When count >= required → status = APPROVED, timelock starts
4. **Timelock**: Countdown based on tier (72hr, 24hr, or 0hr)
5. **Execution**: After timelock expires → action can be executed
6. **Cancellation**: Any admin can cancel before execution

**Security Features**:

- Admin validation before all operations
- Initiator auto-approves their own proposal
- Prevents duplicate approvals from same admin
- Timelock enforcement with hour-precision error messages
- Comprehensive audit logging via `daoAdminAuditService`

### Files Updated

#### 4. Service Index

**File**: `src/lib/services/admin/index.ts` (+8 lines)

**New Exports**:

- `AdminGovernanceService` (class + singleton)
- `adminGovernanceService` (singleton instance)
- `AdminActionProposalService` (class + singleton)
- `adminActionProposalService` (singleton instance)
- Type exports: `AdminActionProposal`, `CreateProposalParams`, `ApproveProposalParams`, `AdminApproval`
- Enum exports: `ProposalStatus`, `ActionTier`

#### 5. DAO Types

**File**: `packages/shared-types/src/dao.ts` (+16 lines) - import from `@endao/shared-types`

**DAO Interface Updates**:

```typescript
governanceSettings?: {
  requireMultiSigForCritical: boolean  // Default: true when admins.length >= 2
  multiSigThreshold: number            // Default: 2 (2-of-N approval)
  enableAuditLog: boolean              // Default: true
  auditRetentionTier: 'free' | 'premium' | 'enterprise'  // Default: 'free'
}
```

**Re-Exports**:

- `AdminActionProposal`, `CreateProposalParams`, `ApproveProposalParams` types
- `ProposalStatus`, `ActionTier` enums

---

## Architecture Patterns

### 1. Service Orchestration Pattern

**AdminGovernanceService** determines requirements → **AdminActionProposalService** manages workflow

This separation allows:

- Easy governance rule changes (just update AdminGovernanceService)
- Workflow logic remains stable
- Clear single responsibility

### 2. Singleton Pattern

All services use singleton instances for consistent state management:

```typescript
export const adminGovernanceService = AdminGovernanceService.getInstance();
export const adminActionProposalService =
  AdminActionProposalService.getInstance();
```

### 3. ServiceResponse Pattern

Consistent error handling via `BaseService.safeExecute()`:

```typescript
return this.safeExecute(async () => {
  // Business logic
}, 'methodName');
```

### 4. Audit Integration Pattern

Every state change logged automatically:

```typescript
await daoAdminAuditService.logAction({
  daoId, adminId, action, reason,
  metadata: { proposalId, ... }
})
```

---

## Database Schema

### Table: `admin_action_proposals`

**Record Structure**:

```typescript
{
  id: string (auto-generated)
  daoId: string
  initiatorId: string
  initiatorName: string
  action: AdminActionType  // From Phase 1
  actionTier: ActionTier   // tier_1, tier_2, tier_3, tier_4
  targetId?: string
  targetName?: string
  reason: string (sanitized)
  metadata: Record<string, any>

  // Approval tracking
  approvalsRequired: number  // e.g., 2 for 2-of-N
  approvals: AdminApproval[]  // Array of { adminId, adminName, approvedAt, ipAddress? }

  // Status and timing
  status: ProposalStatus  // pending, approved, executed, cancelled, rejected, expired
  createdAt: Timestamp
  approvedAt?: Timestamp  // When threshold met
  scheduledExecutionTime?: Timestamp  // approvedAt + timelock
  executedAt?: Timestamp
  cancelledAt?: Timestamp
  cancelledBy?: string

  // Timelock duration
  timelockDuration: number  // 0, 86400000 (24hr), or 259200000 (72hr)
}
```

**Required Index**:

- `dao_id` (Ascending) + `status` (Ascending) + `created_at` (Descending)
- Used by: `getPendingProposals()`
- See: `/docs/deployment/DATABASE_INDEXES_ADMIN_PROPOSALS.md`

---

## Integration with Phase 1

### Audit Logging Integration

Every proposal lifecycle event is logged:

1. **Proposal Creation**: `logAction({ action, reason: "Proposed: ..." })`
2. **Approval**: `logAction({ action, reason: "Approved proposal: ..." })`
3. **Cancellation**: `logAction({ action, reason: "Cancelled proposal: ..." })`
4. **Execution**: `logAction({ action, reason: "Executed: ..." })`

This creates a complete audit trail for compliance and investigation.

### AdminActionType Reuse

Phase 2 uses the `AdminActionType` enum from Phase 1, ensuring consistency across audit logs and proposals.

---

## TypeScript Strict Mode Compliance

✅ All files pass TypeScript strict mode:

- No `any` types (except in Record<string, any> for metadata)
- Full type safety for all parameters
- Proper enum usage (regular imports, not type imports)
- Correct PostgreSQL timestamp handling

**Import Pattern**:

```typescript
// Enums must be regular imports (not type imports)
import { ProposalStatus } from './types/proposal.types';

// Interfaces can be type imports
import type { AdminActionProposal } from './types/proposal.types';
```

---

## Security Considerations

### 1. Admin Validation

Every method validates that the user is an admin before proceeding:

```typescript
if (!dao.admins.includes(params.adminId)) {
  throw new Error('Only admins can propose actions');
}
```

### 2. State Transition Validation

Proposals can only transition through valid states:

- PENDING → APPROVED (when threshold met)
- APPROVED → EXECUTED (after timelock)
- PENDING/APPROVED → CANCELLED (any time before execution)

### 3. Timelock Enforcement

Execution blocked until timelock expires:

```typescript
if (
  proposal.scheduledExecutionTime &&
  proposal.scheduledExecutionTime.seconds > now.seconds
) {
  const remainingSeconds =
    proposal.scheduledExecutionTime.seconds - now.seconds;
  throw new Error(
    `Timelock active. ${Math.ceil(remainingSeconds / 3600)} hours remaining`
  );
}
```

### 4. Duplicate Approval Prevention

Each admin can only approve once:

```typescript
const alreadyApproved = proposal.approvals.some(
  (a) => a.adminId === params.adminId
);
if (alreadyApproved) {
  throw new Error('You have already approved this proposal');
}
```

### 5. Database Timestamp Handling

Proper handling of PostgreSQL timestamps:

```typescript
// Using Supabase timestamp handling
createdAt: new Date().toISOString();
approvedAt: new Date().toISOString();
```

---

## Testing Requirements

### Unit Tests (To Be Created in Phase 3)

**AdminGovernanceService**:

- Test tier classification for all action types
- Test timelock duration calculations
- Test multi-sig requirements (enabled, disabled, single admin)
- Test required approval calculations
- Test unanimous approval detection

**AdminActionProposalService**:

- Test proposal creation with auto-approval
- Test approval workflow (1/2, 2/2)
- Test threshold detection and status change
- Test timelock calculation
- Test cancellation (before/after approval)
- Test execution (before/after timelock)
- Test error cases (duplicate approval, invalid state transitions)
- Test audit logging integration

### Integration Tests

**Multi-Admin Workflows**:

- Create proposal → Approve → Execute
- Create proposal → Cancel
- Create proposal → Approve → Wait timelock → Execute
- Test with different tier actions (Tier 1, Tier 2, Tier 3)

**Edge Cases**:

- Single admin DAO (should bypass multi-sig)
- DAO with multi-sig disabled (should bypass multi-sig)
- Proposal with unanimous requirement
- Timelock edge cases (0hr, 24hr, 72hr)

---

## Phase 8 Integration Notes

**Current Implementation**: Phase 2 only manages the approval workflow. Actual action execution (DAO deletion, admin demotion, etc.) is stubbed out and will be implemented in Phase 8.

**executeProposal() Method**: Currently marks proposals as executed but does NOT perform the actual action. Phase 8 will:

1. Call `executeProposal()` to validate timelock and state
2. Perform the actual action (e.g., delete DAO, demote admin)
3. Proposal remains marked as executed

**Integration Pattern**:

```typescript
// Phase 8 implementation (example)
async function deleteDAOWithApproval(proposalId: string) {
  // Validate and mark as executed
  await adminActionProposalService.executeProposal(proposalId);

  // Get proposal details
  const proposal = await adminActionProposalService.getProposal(proposalId);

  // Perform actual deletion
  await daoService.deleteDAO(proposal.daoId);
}
```

---

## Configuration Defaults

### DAO Governance Settings

When creating a new DAO:

```typescript
governanceSettings: {
  requireMultiSigForCritical: admins.length >= 2,  // Auto-enable if 2+ admins
  multiSigThreshold: 2,  // 2-of-N approval
  enableAuditLog: true,
  auditRetentionTier: 'free'
}
```

### Approval Threshold

- **Default**: 2-of-N (requires 2 admin approvals)
- **Maximum**: N (number of admins)
- **Special Case**: Disabling multi-sig requires unanimous approval (N-of-N)

---

## Known Limitations

### 1. No Rejection Mechanism

Phase 2 only supports approval and cancellation. Explicit rejection (with vote counting) will be added in Phase 4.

### 2. No Expiration Auto-Cleanup

Expired proposals (approved but never executed) remain in database. Auto-cleanup will be added in Phase 10 (background jobs).

### 3. No Real-Time Notifications

Admins are not notified when proposals are created or approved. Notification system will be added in Phase 9.

### 4. No Action Execution

Phase 2 only manages approvals. Actual execution integration happens in Phase 8.

---

## Next Steps

### Phase 3: Backend API Routes

Create Next.js API routes for:

- `POST /api/dao/[id]/admin/proposals` - Create proposal
- `POST /api/dao/[id]/admin/proposals/[proposalId]/approve` - Approve
- `POST /api/dao/[id]/admin/proposals/[proposalId]/cancel` - Cancel
- `GET /api/dao/[id]/admin/proposals` - List pending proposals

### Phase 4: Rejection and Voting

Add explicit rejection mechanism with vote counting:

- `rejectProposal()` method
- Rejection threshold (e.g., 2 rejections = auto-cancel)
- Vote tracking (approvals vs rejections)

### Phase 5: Frontend Components

Create React components:

- Proposal creation modal
- Pending proposals list
- Approval/cancel buttons
- Timelock countdown display

---

## Maintenance Notes

### Database Operations

- **Write Operations**: ~3-5 writes per proposal lifecycle
  - 1 write: Create proposal
  - 1+ writes: Approvals (one per admin)
  - 1 write: Mark as executed/cancelled
- **Read Operations**: ~2-10 reads per admin panel load
- **Index Maintenance**: Automatic via PostgreSQL, no manual intervention needed

### Monitoring

Monitor these metrics in Phase 10:

- Average time to approval
- Timelock expiration without execution (abandoned proposals)
- Cancellation rate
- Single-admin bypass rate (DAOs with multi-sig disabled)

---

## Version History

- **v2.0.0** (Oct 3, 2025): Phase 2 implementation complete
  - Multi-signature approval workflow
  - Tiered timelock system
  - Governance service layer
  - Integration with Phase 1 audit logging

---

## References

- **Phase 1 Documentation**: `ADMIN_PERMISSION_SAFEGUARDS_PHASE1.md`
- **Database Indexes**: `DATABASE_INDEXES_ADMIN_PROPOSALS.md`
- **Base Service Pattern**: `src/lib/services/base.service.ts`
- **Audit Service**: `src/lib/services/admin/dao-admin-audit.service.ts`
