# Architecture Enforcement Guide

## Purpose

This document outlines how the EnDAO codebase enforces architectural patterns and maintains code quality standards through automated tools, pre-commit hooks, and CI/CD pipelines.

## Last Updated

September 2025

---

## 🚨 Enforcement Mechanisms

### 1. Pre-Commit Hooks (Immediate Feedback)

**Location**: `.husky/pre-commit`
**Runs**: On every commit attempt

- **File Size Check**: Blocks commits with files >800 lines
- **Complexity Analysis**: Warns about functions with high cyclomatic complexity
- **Pattern Validation**: Ensures proper organization (services, hooks, components)
- **Security Scan**: Runs Semgrep on staged files

### 2. GitHub Actions (CI/CD Pipeline)

**Location**: `.github/workflows/architecture-check.yml`
**Runs**: On every PR and push to main branches

- Comprehensive file size analysis
- Code complexity metrics
- Architecture pattern compliance
- Generates reports for review
- Comments on PRs with violations

### 3. ESLint Rules (Editor Integration)

**Location**: `.eslintrc.json`
**Runs**: In IDE and during build

```json
{
  "rules": {
    "max-lines": ["error", 800],
    "max-lines-per-function": ["warn", 100],
    "complexity": ["error", 10],
    "max-statements": ["warn", 15],
    "max-params": ["warn", 4],
    "max-depth": ["error", 4]
  }
}
```

### 4. Architecture Monitoring Scripts

**Commands**: Available in `package.json`

```bash
yarn check:architecture  # Full architecture check
yarn check:files        # File size analysis
yarn check:complexity   # Complexity analysis
yarn analyze           # Generate detailed report
yarn analyze:html      # Visual report with charts
```

## 📏 Standards and Thresholds

### File Size Limits

| Level      | Lines   | Action               |
| ---------- | ------- | -------------------- |
| ✅ Good    | <300    | Ideal target         |
| ⚠️ Warning | 300-500 | Consider refactoring |
| 🚨 Error   | >800    | Blocks commit        |

### Complexity Thresholds

| Metric                | Threshold | Enforcement    |
| --------------------- | --------- | -------------- |
| Cyclomatic Complexity | 10        | ESLint error   |
| Function Length       | 100 lines | ESLint warning |
| Function Parameters   | 4         | ESLint warning |
| Nesting Depth         | 4         | ESLint error   |

### Bundle Size & Code Splitting

| Component Type    | Size Threshold | Action Required           |
| ----------------- | -------------- | ------------------------- |
| Page Component    | >500 lines     | Must use lazy loading     |
| Admin Features    | Any size       | Must be code split        |
| Modal/Tab Content | >300 lines     | Should use dynamic import |
| Form Components   | >400 lines     | Should be lazy loaded     |
| Initial Bundle    | >500KB         | Requires optimization     |

## 🏗️ Required Patterns

### 1. Service Organization

```
services/[domain]/
├── index.ts                    # Orchestrator
├── [domain]-crud.service.ts    # CRUD operations (<250 lines)
├── [domain]-validation.service.ts  # Validation (<200 lines)
├── [domain]-query.service.ts   # Complex queries (<200 lines)
└── [domain]-[specialized].service.ts  # Other concerns (<200 lines)
```

**Enforcement**: Services >500 lines are automatically flagged

### 2. Component Structure

```
components/[domain]/[feature]/
├── index.tsx                # Main component (<100 lines)
├── [feature]-context.tsx    # Context provider
├── [feature]-header.tsx     # Sub-component
├── [feature]-content.tsx    # Sub-component
└── [feature]-actions.tsx    # Sub-component
```

**Enforcement**: Components >500 lines trigger refactoring requirement

### 3. Hook Organization

```
hooks/[domain]/
├── index.ts                 # Clean exports
├── use-[domain]-base.ts     # Core functionality
├── use-[domain]-data.ts     # Data operations
└── use-[domain]-actions.ts  # User actions
```

**Enforcement**: Hooks in root `/hooks` folder are flagged

## 🔄 Refactoring Workflow

### When a File Exceeds Limits:

1. **Immediate Block** (>800 lines):

   ```bash
   ❌ File size check failed!
   💡 Large files detected. Follow the refactoring patterns:
      • See docs/REFACTORING_GUIDE.md for patterns
   ```

2. **Identify Pattern**:
   - UI Component → Use Pattern 1 (Compound Components)
   - Service → Use Pattern 3 (Service Extraction)
   - Hook → Use Pattern 4 (Hook Organization)

3. **Apply Refactoring**:

   ```bash
   # Example: Refactoring a large service
   yarn analyze -- --file src/lib/services/large.service.ts
   # Follow the suggested extraction pattern
   ```

4. **Validate Changes**:
   ```bash
   yarn check:architecture
   # Should pass all checks
   ```

## 🤖 Automated Helpers

### 1. Architecture Analysis

```bash
# Get suggestions for a specific file
yarn analyze -- --file path/to/large-file.ts

# Output:
# - Suggested extractions
# - Recommended patterns
# - Complexity hotspots
```

### 2. Pattern Templates

Located in `docs/templates/`:

- `service-template.ts` - Service boilerplate
- `component-template.tsx` - Component structure
- `hook-template.ts` - Hook pattern

### 3. Refactoring Checklist

```bash
# Run before refactoring
yarn analyze > before.txt

# After refactoring
yarn analyze > after.txt
diff before.txt after.txt

# Should show improvements in:
# - File count (more files)
# - Average size (smaller)
# - Complexity (lower)
```

## 🚀 Progressive Enhancement

### Phase 1: Current State

- ✅ File size enforcement
- ✅ Basic complexity checks
- ✅ Pre-commit hooks
- ✅ CI/CD integration

### Phase 2: Enhanced Automation (Planned)

- [ ] Auto-suggest refactoring patterns
- [ ] Generate boilerplate for extractions
- [ ] Track technical debt metrics
- [ ] Architecture score dashboard

### Phase 3: AI-Assisted Refactoring (Future)

- [ ] AI-powered extraction suggestions
- [ ] Automatic PR creation for refactoring
- [ ] Continuous architecture optimization
- [ ] Learning from successful patterns

## 📊 Monitoring and Reporting

### Weekly Architecture Report

Run every Monday:

```bash
yarn architecture:report
```

Generates:

- File size distribution
- Complexity trends
- Technical debt score
- Refactoring opportunities

### Dashboard Access

```bash
yarn analyze:html
# Opens interactive dashboard with:
# - Heat maps of complexity
# - File size charts
# - Trend analysis
# - Refactoring priorities
```

## 🎯 Success Metrics

### Target Goals

- **No files >500 lines**: 95% compliance
- **Average file size**: <200 lines
- **Cyclomatic complexity**: <10 for 90% of functions
- **Test coverage**: >80% for all modules

### Current Status

Track with:

```bash
yarn metrics:architecture
```

## 🆘 Getting Help

### When You're Blocked:

1. Check `docs/REFACTORING_GUIDE.md` for patterns
2. Run `yarn analyze` for specific suggestions
3. Use AI assistant with context from this guide
4. Request architecture review in PR

### Common Issues and Solutions:

**Issue**: "File too large but it's all related"
**Solution**: Apply compound component pattern or service orchestration

**Issue**: "Complexity is high but logic is necessary"
**Solution**: Extract helper functions, use early returns, simplify conditionals

**Issue**: "Don't know how to organize"
**Solution**: Follow domain-driven design, check existing patterns in codebase

## 🔐 Override Process

In rare cases where limits must be exceeded:

1. Add exception to `.architecturerc`:

```json
{
  "exceptions": {
    "src/path/to/file.ts": {
      "maxLines": 1000,
      "reason": "Legacy code, scheduled for refactor in Q2"
    }
  }
}
```

2. Get approval from tech lead
3. Create refactoring ticket
4. Set deadline for resolution

---

**Remember**: Good architecture is not about rules, it's about maintainability, readability, and team velocity. These enforcement mechanisms ensure we maintain high standards while moving fast.
