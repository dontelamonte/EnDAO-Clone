# Polyglot Architecture Decision Framework

**Date**: December 2025  
**Status**: Active Decision Framework  
**Replaces**: `polyglot-architecture-ladder.md` (speculative planning)  
**Purpose**: Evidence-based criteria for when to introduce non-TypeScript languages

---

## Executive Summary

EnDAO is a TypeScript-first platform. This document provides **measurable criteria** for when to introduce additional languages (Go, Rust, Python). The default answer is "stay TypeScript" until concrete evidence proves otherwise.

**Core Principle**: Prove TypeScript can't solve the problem before adding a new language. Each language addition adds:

- Hiring requirements (specialized expertise)
- DevOps complexity (multi-runtime deployments)
- Debugging overhead (distributed tracing across languages)
- Knowledge silos (team fragmentation)

**Current State**: TypeScript handles all production workloads. Event-driven architecture, notification processing, and treasury operations are live and stable.

---

## Table of Contents

1. [Current Infrastructure Inventory](#current-infrastructure-inventory)
2. [TypeScript-First Scaling Strategy](#typescript-first-scaling-strategy)
3. [Recommended Infrastructure Additions](#recommended-infrastructure-additions)
4. [Language Introduction Criteria](#language-introduction-criteria)
5. [Decision Trees by Problem Domain](#decision-trees-by-problem-domain)
6. [Technologies to Avoid](#technologies-to-avoid)
7. [Recommended Scaling Stack](#recommended-scaling-stack)
8. [Implementation Priority](#implementation-priority)
9. [Measurement & Monitoring](#measurement--monitoring)
10. [Team Readiness Requirements](#team-readiness-requirements)
11. [Migration Playbooks](#migration-playbooks)

---

## Current Infrastructure Inventory

Before considering polyglot, understand what already exists.

### Event-Driven Architecture (ADR-006) ✅ LIVE

```
┌─────────────────────────────────────────────────────────────┐
│  Domain Services (TypeScript)                               │
│  └─ Emit domain events on state changes                     │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│  DomainEventBus (TypeScript)                                │
│  ├─ Validates payload against Zod schemas                   │
│  ├─ Persists to database (durability)                       │
│  ├─ Dispatches to registered handlers                       │
│  └─ Handles replay for failed events                        │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│  Event Handlers (TypeScript)                                │
│  ├─ AuditLogHandler (priority 0)                            │
│  ├─ NotificationHandler (priority 10)                       │
│  │   ├─ User preference filtering                           │
│  │   ├─ Idempotency (prevents duplicates)                   │
│  │   └─ Target audience routing                             │
│  └─ AnalyticsHandler (priority 20)                          │
└──────────────┬──────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│  Supabase PostgreSQL (Persistence)                          │
│  └─ Events table with status tracking                       │
└─────────────────────────────────────────────────────────────┘
```

**Capabilities**:

- Event persistence and replay
- Handler priority ordering
- Idempotency via database
- User preference filtering
- Failure tracking and retry

**Location**: `src/lib/services/events/`

### Treasury Protection (4-Layer) ✅ LIVE

| Layer           | Implementation          | Language |
| --------------- | ----------------------- | -------- |
| Status Checks   | TypeScript service      | TS       |
| Treasury Freeze | TypeScript service      | TS       |
| Grace Period    | PostgreSQL + TypeScript | TS       |
| Execution Locks | PostgreSQL transactions | TS       |

**Capabilities**:

- Memory-safe BigInt operations via Ethers.js v6
- 2-of-3 multi-sig via Gnosis Safe SDK
- Full audit trail
- 7-day grace period on critical changes

**Location**: `src/lib/services/treasury/`

### Database & Queuing ✅ LIVE

| Component        | Technology            | Notes                              |
| ---------------- | --------------------- | ---------------------------------- |
| Primary Database | Supabase PostgreSQL   | RLS, real-time subscriptions       |
| Event Queue      | PostgreSQL table      | `domain_events` with status column |
| Caching          | None (not needed yet) | Add Redis when metrics justify     |

---

## TypeScript-First Scaling Strategy

Before any polyglot discussion, exhaust TypeScript-native solutions.

### Tier 0.5: TypeScript Scale-Out

**Timeline**: Before any polyglot work  
**Exit Criteria**: Demonstrate TypeScript bottleneck with metrics

#### Background Jobs: Trigger.dev

**Problem**: Next.js cron routes have cold starts, limited concurrency  
**Solution**: Trigger.dev (TypeScript, persistent workers)

```typescript
// trigger/notification-batch.ts
import { task } from '@trigger.dev/sdk/v3';
import { eventBus } from '@/lib/services/events';

export const processNotificationBatch = task({
  id: 'process-notification-batch',
  queue: {
    concurrencyLimit: 10, // 10 parallel workers
  },
  retry: {
    maxAttempts: 3,
    factor: 2,
    minTimeoutInMs: 1000,
  },
  run: async (payload: { eventIds: string[] }) => {
    for (const eventId of payload.eventIds) {
      await eventBus.replay(eventId);
    }
    return { processed: payload.eventIds.length };
  },
});
```

**Capabilities**:

- Persistent workers (no cold starts)
- Configurable concurrency (1-100+ parallel)
- Built-in retry with exponential backoff
- Dashboard for monitoring
- TypeScript end-to-end

**When to use**:

- Notification batches
- Email delivery queues
- Analytics aggregation
- Scheduled reports

#### Edge Functions: Vercel/Supabase

**Problem**: API route latency for geographically distributed users  
**Solution**: Edge Functions (TypeScript, global distribution)

```typescript
// app/api/v1/daos/[id]/route.ts
export const runtime = 'edge'; // Deploy to edge

export async function GET(request: Request) {
  // Runs at edge, <50ms global latency
}
```

**Capabilities**:

- Global distribution (300+ edge locations)
- Sub-50ms latency worldwide
- TypeScript/JavaScript runtime
- No cold starts

**When to use**:

- Public API endpoints
- Read-heavy operations
- Authentication checks

#### AI Integration: Vercel AI SDK

**Problem**: Need LLM integration for conversational AI features  
**Solution**: Vercel AI SDK (TypeScript, streaming, multi-provider)

```typescript
// app/api/ai/summarize/route.ts
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';

export async function POST(req: Request) {
  const { proposalText } = await req.json();

  const result = await streamText({
    model: openai('gpt-4-turbo'),
    prompt: `Summarize this governance proposal: ${proposalText}`,
  });

  return result.toDataStreamResponse();
}
```

**Capabilities**:

- Streaming responses
- Multi-provider (OpenAI, Anthropic, Google, etc.)
- React hooks for UI integration
- TypeScript end-to-end

**When to use**:

- Proposal Summarizer
- Plain Language Translator
- Governance Q&A
- Draft Assistant

#### Analytics: SQL + DuckDB-WASM

**Problem**: Complex analytics aggregations  
**Solution**: PostgreSQL materialized views + DuckDB-WASM for client-side analysis

```sql
-- Supabase materialized view
CREATE MATERIALIZED VIEW governance_metrics AS
SELECT
  dao_id,
  COUNT(*) FILTER (WHERE status = 'passed') as passed_proposals,
  COUNT(*) FILTER (WHERE status = 'failed') as failed_proposals,
  AVG(voter_turnout) as avg_turnout,
  DATE_TRUNC('month', created_at) as month
FROM proposals
GROUP BY dao_id, DATE_TRUNC('month', created_at);

-- Refresh on schedule
SELECT cron.schedule('refresh-metrics', '0 * * * *',
  'REFRESH MATERIALIZED VIEW governance_metrics');
```

**Capabilities**:

- PostgreSQL handles aggregation
- Materialized views for pre-computed metrics
- DuckDB-WASM for client-side analysis (no server needed)
- TypeScript for orchestration

**When to use**:

- Reporting Dashboard
- Governance health metrics
- Treasury analytics

#### Background Jobs Alternative: Inngest

**Problem**: Need event-driven background jobs with great DX  
**Solution**: Inngest (TypeScript, step functions, event-driven)

Inngest is an alternative to Trigger.dev with some advantages:

```typescript
// inngest/functions.ts
import { inngest } from './client';

export const processNotification = inngest.createFunction(
  { id: 'process-notification' },
  { event: 'notification/send' },
  async ({ event, step }) => {
    // Built-in step functions for reliability
    const user = await step.run('fetch-user', async () => {
      return await userRepository.findById(event.data.userId);
    });

    await step.run('send-email', async () => {
      return await emailService.send(user.email, event.data.message);
    });

    // Automatic retries, logging, observability
  }
);
```

**Inngest vs Trigger.dev:**

| Feature             | Trigger.dev | Inngest                 |
| ------------------- | ----------- | ----------------------- |
| Step functions      | Yes         | Yes (better DX)         |
| Event-driven        | Manual      | Native                  |
| Vercel integration  | Good        | Better                  |
| Pricing             | Usage-based | More generous free tier |
| Concurrency control | Yes         | Yes                     |
| Dashboard           | Good        | Good                    |

**Recommendation**: Evaluate both for your specific needs. Inngest has better Vercel integration; Trigger.dev has more mature scheduling.

---

## Recommended Infrastructure Additions

Infrastructure to add **before** considering polyglot languages.

### 1. Supabase Realtime (Already Available)

You're paying for Supabase Pro but may not be using Realtime subscriptions. This can eliminate complex notification polling:

```typescript
// Client-side: Live notifications without polling
import { useEffect } from 'react';
import { createClient } from '@/lib/supabase/client';

export function useRealtimeNotifications(userId: string) {
  const supabase = createClient();

  useEffect(() => {
    const channel = supabase
      .channel('user-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          // Show toast immediately
          showToast(payload.new.message);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);
}
```

**Use Cases:**

- Real-time voting updates (live vote counts)
- Instant notifications (no polling)
- Discussion comments appear immediately
- Treasury transaction status updates

**Cost:** Already included in Supabase Pro  
**Effort:** Low (1-2 days to implement)

### 2. Upstash Redis (Serverless, Vercel-Native)

For caching, rate limiting, and session storage. Works perfectly with Vercel's serverless model:

```typescript
// middleware.ts - API rate limiting
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';
import { NextRequest, NextResponse } from 'next/server';

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, '10 s'), // 10 requests per 10 seconds
});

export async function middleware(request: NextRequest) {
  // Only rate limit API routes
  if (request.nextUrl.pathname.startsWith('/api/')) {
    const ip =
      request.ip ?? request.headers.get('x-forwarded-for') ?? '127.0.0.1';
    const { success, limit, reset, remaining } = await ratelimit.limit(ip);

    if (!success) {
      return new NextResponse('Too Many Requests', {
        status: 429,
        headers: {
          'X-RateLimit-Limit': limit.toString(),
          'X-RateLimit-Remaining': remaining.toString(),
          'X-RateLimit-Reset': reset.toString(),
        },
      });
    }
  }

  return NextResponse.next();
}
```

```typescript
// Caching expensive queries
import { Redis } from '@upstash/redis';

const redis = Redis.fromEnv();

export async function getDAOMetrics(daoId: string) {
  const cacheKey = `dao:${daoId}:metrics`;

  // Try cache first
  const cached = await redis.get<DAOMetrics>(cacheKey);
  if (cached) return cached;

  // Compute expensive metrics
  const metrics = await computeDAOMetrics(daoId);

  // Cache for 5 minutes
  await redis.set(cacheKey, metrics, { ex: 300 });

  return metrics;
}
```

**Use Cases:**

- API rate limiting (essential for Public API in Tier 3)
- Caching expensive governance metrics
- Session storage
- Idempotency keys (faster than Postgres)
- Distributed locks

**Cost:** Free tier is generous (~10K requests/day), then ~$10-30/month  
**Effort:** Low (2-3 days to implement)

### 3. PostgreSQL Optimizations (Free Performance)

Before adding infrastructure, optimize what you have:

```sql
-- 1. Partial indexes for common queries (huge performance gain)
CREATE INDEX idx_proposals_active ON proposals (dao_id, created_at DESC)
WHERE status IN ('draft', 'active', 'voting');

CREATE INDEX idx_domain_events_pending ON domain_events (created_at)
WHERE status = 'pending';

-- 2. Covering indexes (enables index-only scans)
CREATE INDEX idx_votes_proposal_summary ON votes (proposal_id)
INCLUDE (vote_type, voter_id, created_at);

-- 3. Materialized views for dashboard metrics
CREATE MATERIALIZED VIEW dao_health_metrics AS
SELECT
  dao_id,
  COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '30 days') as proposals_30d,
  COUNT(*) FILTER (WHERE status = 'passed' AND created_at > NOW() - INTERVAL '30 days') as passed_30d,
  AVG(voter_turnout) FILTER (WHERE created_at > NOW() - INTERVAL '30 days') as avg_turnout_30d,
  COUNT(DISTINCT voter_id) FILTER (WHERE created_at > NOW() - INTERVAL '30 days') as active_voters_30d
FROM proposals p
LEFT JOIN votes v ON p.id = v.proposal_id
GROUP BY dao_id;

-- Refresh hourly
SELECT cron.schedule('refresh-dao-metrics', '0 * * * *',
  'REFRESH MATERIALIZED VIEW CONCURRENTLY dao_health_metrics');

-- 4. Connection pooling - use Supavisor pooler connection string
-- In .env:
-- DATABASE_URL=postgres://...pooler.supabase.com:6543/postgres?pgbouncer=true

-- 5. Analyze tables for query planner
ANALYZE proposals;
ANALYZE votes;
ANALYZE domain_events;
```

**Benefits:**

- 10-100x faster queries on large tables
- Reduced database CPU usage
- Better Vercel function performance (connection reuse)
- Dashboard loads instantly with materialized views

**Cost:** Free  
**Effort:** Low (1 day for indexes, 2-3 days for materialized views)

### 4. Edge Caching Patterns

For read-heavy public data, use Next.js caching:

```typescript
// app/api/daos/[id]/public/route.ts
import { unstable_cache } from 'next/cache';

// Cache function with tags for invalidation
const getCachedDAO = unstable_cache(
  async (daoId: string) => {
    const dao = await daoRepository.findById(daoId);
    return {
      id: dao.id,
      name: dao.name,
      description: dao.description,
      memberCount: dao.memberCount,
      proposalCount: dao.proposalCount,
      // Only public fields
    };
  },
  ['dao-public'], // Cache key prefix
  {
    revalidate: 60, // Cache for 60 seconds
    tags: ['daos'], // For manual invalidation
  }
);

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const dao = await getCachedDAO(params.id);

  return Response.json(dao, {
    headers: {
      'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=300',
    },
  });
}
```

```typescript
// Invalidate cache when DAO is updated
import { revalidateTag } from 'next/cache';

export async function updateDAO(daoId: string, data: UpdateDAOInput) {
  await daoRepository.update(daoId, data);
  revalidateTag('daos'); // Invalidate all DAO caches
}
```

**Use Cases:**

- Public DAO profiles
- Proposal listings (public view)
- Member directories
- Governance metrics dashboards

**Cost:** Free (included in Vercel)  
**Effort:** Low (1-2 days)

### 5. Cloudflare Workers (For Public API - Tier 3)

If/when you build the Public API, Cloudflare Workers may be better than a Go API gateway:

| Feature          | Vercel Edge   | Cloudflare Workers |
| ---------------- | ------------- | ------------------ |
| Cold starts      | ~50ms         | 0ms                |
| Global locations | 100+          | 300+               |
| CPU time limit   | 30s           | Unlimited (paid)   |
| Language         | TypeScript    | TypeScript         |
| Rate limiting    | DIY (Upstash) | Built-in           |
| DDoS protection  | Basic         | Enterprise-grade   |
| Cost at scale    | Higher        | Lower              |
| Database         | Supabase      | D1 + Supabase      |

```typescript
// Cloudflare Worker for Public API (TypeScript)
// workers/api-gateway/src/index.ts

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext) {
    const url = new URL(request.url);

    // Built-in rate limiting via Cloudflare
    // DDoS protection automatic

    if (url.pathname.startsWith('/api/v1/')) {
      // Proxy to your Vercel API or handle directly
      return handleAPIRequest(request, env);
    }

    return new Response('Not Found', { status: 404 });
  },
};

async function handleAPIRequest(request: Request, env: Env) {
  // Can call Supabase directly from edge
  const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY);

  // Or proxy to Vercel
  const vercelUrl = new URL(request.url);
  vercelUrl.hostname = 'your-app.vercel.app';
  return fetch(vercelUrl, request);
}
```

**When to use:**

- Public API with >1M requests/day
- Need enterprise DDoS protection
- Cost optimization at scale
- Global latency requirements

**Cost:** Free tier generous, then ~$5/month + usage  
**Effort:** Medium (1-2 weeks for full API gateway)

---

## Technologies to Avoid

These add complexity without proportional benefit for EnDAO's scale:

| Technology                        | Why Avoid                                                                                                                                                 |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Kubernetes**                    | Way too complex for team of 1 + AI. Use managed services (Vercel, Railway, Render). Only consider at 10+ microservices or strict compliance requirements. |
| **Microservices**                 | Monolith is fine until you have clear bounded contexts AND a team to maintain them. Distributed systems are hard.                                         |
| **GraphQL**                       | REST is simpler for your use case. You don't have the query complexity that justifies GraphQL's overhead.                                                 |
| **Self-hosted databases**         | Use Supabase. Self-hosting Postgres adds operational burden without benefit.                                                                              |
| **Multiple databases**            | PostgreSQL does everything you need (relational, JSON, full-text search, vectors via pgvector). Don't add MongoDB, DynamoDB, etc.                         |
| **Elixir/Phoenix**                | Great for real-time, but niche language with limited hiring pool. Supabase Realtime gives you 80% of the benefit.                                         |
| **Custom message queues**         | PostgreSQL + Trigger.dev/Inngest handles your scale. Don't add RabbitMQ, Kafka, etc.                                                                      |
| **Service mesh (Istio, Linkerd)** | Only needed for complex microservices. You don't have microservices.                                                                                      |

---

## Recommended Scaling Stack

### Tier 0-2: Current + Optimizations

```
┌─────────────────────────────────────────────────────────────┐
│  FRONTEND                                                   │
│  └─ Next.js 15 on Vercel                                    │
│     └─ Edge caching for public pages                        │
├─────────────────────────────────────────────────────────────┤
│  API LAYER                                                  │
│  └─ Next.js API Routes                                      │
│     └─ Vercel Edge for latency-sensitive endpoints          │
├─────────────────────────────────────────────────────────────┤
│  BACKGROUND JOBS                                            │
│  └─ Trigger.dev OR Inngest (TypeScript)                     │
│     └─ Notification batches, email delivery, analytics      │
├─────────────────────────────────────────────────────────────┤
│  REAL-TIME                                                  │
│  └─ Supabase Realtime                                       │
│     └─ Live notifications, vote counts, discussions         │
├─────────────────────────────────────────────────────────────┤
│  CACHING & RATE LIMITING                                    │
│  └─ Upstash Redis                                           │
│     └─ API rate limiting, query caching, idempotency        │
├─────────────────────────────────────────────────────────────┤
│  DATABASE                                                   │
│  └─ Supabase PostgreSQL                                     │
│     ├─ Optimized indexes                                    │
│     ├─ Materialized views for metrics                       │
│     ├─ Connection pooling (Supavisor)                       │
│     └─ pgvector for AI embeddings                           │
├─────────────────────────────────────────────────────────────┤
│  AI                                                         │
│  └─ Vercel AI SDK                                           │
│     └─ OpenAI/Anthropic for text generation                 │
├─────────────────────────────────────────────────────────────┤
│  AUTH                                                       │
│  └─ Privy (unchanged)                                       │
├─────────────────────────────────────────────────────────────┤
│  TREASURY                                                   │
│  └─ Gnosis Safe + Ethers.js v6 (unchanged)                  │
└─────────────────────────────────────────────────────────────┘
```

### Tier 3+: Scale Additions (Evidence Required)

```
┌─────────────────────────────────────────────────────────────┐
│  PUBLIC API GATEWAY (if >1M requests/day)                   │
│  └─ Cloudflare Workers                                      │
│     ├─ Built-in rate limiting                               │
│     ├─ DDoS protection                                      │
│     └─ Global edge deployment                               │
├─────────────────────────────────────────────────────────────┤
│  SEARCH (if needed)                                         │
│  └─ Supabase Full-Text Search OR Typesense                  │
│     └─ Proposal search, member search                       │
├─────────────────────────────────────────────────────────────┤
│  ANALYTICS (if complex reporting needed)                    │
│  └─ Supabase + Metabase OR built-in dashboard               │
│     └─ Cross-DAO analytics, enterprise roll-up              │
├─────────────────────────────────────────────────────────────┤
│  FILE STORAGE (if heavy file usage)                         │
│  └─ Supabase Storage + Cloudflare R2                        │
│     └─ Document attachments, evidence files                 │
├─────────────────────────────────────────────────────────────┤
│  DATABASE SCALING (if needed)                               │
│  └─ Supabase Read Replicas                                  │
│     └─ Analytics queries on replica                         │
└─────────────────────────────────────────────────────────────┘
```

### Tier 4+: Polyglot (Only if Evidence Demands)

```
┌─────────────────────────────────────────────────────────────┐
│  Only add if ALL introduction criteria are met:             │
├─────────────────────────────────────────────────────────────┤
│  Go Services (if TypeScript workers can't scale)            │
│  └─ High-throughput event processing                        │
│  └─ API gateway with custom logic                           │
├─────────────────────────────────────────────────────────────┤
│  Rust Services (if security audit recommends)               │
│  └─ Custom cryptographic operations                         │
│  └─ Zero-knowledge proof generation                         │
├─────────────────────────────────────────────────────────────┤
│  Python Services (if custom ML needed)                      │
│  └─ Custom model training                                   │
│  └─ Advanced NLP beyond hosted APIs                         │
└─────────────────────────────────────────────────────────────┘
```

---

## Implementation Priority

### Phase 1: Now (Free/Cheap, High Impact)

| Item                               | Effort     | Impact   | Cost            |
| ---------------------------------- | ---------- | -------- | --------------- |
| PostgreSQL index optimization      | 1 day      | High     | Free            |
| Supabase Realtime for live updates | 2 days     | High     | Free (included) |
| Edge caching for public pages      | 1 day      | Medium   | Free            |
| **Total**                          | **4 days** | **High** | **Free**        |

### Phase 2: Tier 1 (When Building Notification System)

| Item                                       | Effort       | Impact   | Cost              |
| ------------------------------------------ | ------------ | -------- | ----------------- |
| Upstash Redis for rate limiting            | 2 days       | High     | ~$10/month        |
| Trigger.dev OR Inngest for background jobs | 1 week       | High     | ~$0-50/month      |
| Materialized views for dashboard           | 3 days       | Medium   | Free              |
| **Total**                                  | **~2 weeks** | **High** | **~$10-60/month** |

### Phase 3: Tier 3 (When Building Public API)

| Item                                       | Effort         | Impact   | Cost              |
| ------------------------------------------ | -------------- | -------- | ----------------- |
| Evaluate Cloudflare Workers vs Vercel Edge | 3 days         | Medium   | ~$5/month         |
| Proper API rate limiting (per API key)     | 1 week         | High     | Included in Redis |
| API documentation (OpenAPI)                | 1 week         | High     | Free              |
| **Total**                                  | **~2.5 weeks** | **High** | **~$5/month**     |

### Phase 4: Only If Metrics Demand

| Item                    | Trigger                | Effort     | Cost           |
| ----------------------- | ---------------------- | ---------- | -------------- |
| Read replicas           | DB CPU > 80% sustained | 1 day      | ~$50/month     |
| Cloudflare R2 for files | File storage > 10GB    | 3 days     | ~$5/month      |
| Go services             | See criteria above     | 4-6 weeks  | ~$50-100/month |
| Rust services           | See criteria above     | 8-12 weeks | ~$50-100/month |
| Python services         | See criteria above     | 2-4 weeks  | ~$50-100/month |

---

Only introduce a new language when **all** criteria are met.

### Go: High-Concurrency Workers

#### Introduction Criteria (ALL must be true)

| Criterion                 | Threshold                            | How to Measure                          |
| ------------------------- | ------------------------------------ | --------------------------------------- |
| **Throughput bottleneck** | Trigger.dev can't handle load        | Task queue depth > 1000 for > 5 minutes |
| **Latency requirement**   | p99 latency > 2s with Trigger.dev    | Trigger.dev dashboard metrics           |
| **Cost efficiency**       | Trigger.dev costs > $500/month       | Trigger.dev billing                     |
| **Team readiness**        | 1+ engineer with Go experience       | Team roster                             |
| **Operational capacity**  | Can support multi-runtime deployment | DevOps checklist complete               |

#### Use Cases (Only if criteria met)

| Use Case                      | When Go Makes Sense                       |
| ----------------------------- | ----------------------------------------- |
| Notification burst processing | >10,000 notifications/minute sustained    |
| API gateway                   | >10,000 requests/second sustained         |
| Real-time event streaming     | WebSocket connections > 10,000 concurrent |
| Cross-DAO orchestration       | Federation with 100+ DAOs                 |

#### TypeScript Alternatives to Try First

1. **Trigger.dev** - Handles most background job needs
2. **Vercel Edge Functions** - Global, low-latency API
3. **Supabase Edge Functions** - Database-adjacent processing
4. **Cloudflare Workers** - Unlimited concurrency, global

### Rust: Security-Critical Operations

#### Introduction Criteria (ALL must be true)

| Criterion                   | Threshold                            | How to Measure        |
| --------------------------- | ------------------------------------ | --------------------- |
| **Security audit finding**  | Auditor specifically recommends      | External audit report |
| **Cryptographic operation** | TypeScript/WASM can't handle         | Benchmark comparison  |
| **Memory safety concern**   | Identified vulnerability             | Security review       |
| **Team readiness**          | 1+ engineer with Rust experience     | Team roster           |
| **Maintenance commitment**  | Can maintain Rust codebase long-term | Resource allocation   |

#### Use Cases (Only if criteria met)

| Use Case                         | When Rust Makes Sense             |
| -------------------------------- | --------------------------------- |
| Custom cryptographic operations  | Not covered by existing libraries |
| Zero-knowledge proof generation  | ZK circuit compilation            |
| On-chain validation modules      | Smart contract companion code     |
| Ultra-high-throughput validation | >100,000 validations/second       |

#### TypeScript Alternatives to Try First

1. **Ethers.js v6** - Already handles BigInt, signatures, encoding
2. **@noble/curves** - Pure TypeScript cryptography
3. **WASM modules** - Pre-compiled Rust as WASM (no Rust maintenance)
4. **Gnosis Safe SDK** - Handles multi-sig complexity

### Python: ML/AI Operations

#### Introduction Criteria (ALL must be true)

| Criterion                      | Threshold                             | How to Measure        |
| ------------------------------ | ------------------------------------- | --------------------- |
| **ML model requirement**       | Need custom model training/inference  | Feature specification |
| **Vercel AI SDK insufficient** | Can't use hosted models               | Technical evaluation  |
| **Data science operations**    | Complex statistical analysis          | Feature specification |
| **Team readiness**             | 1+ engineer with Python ML experience | Team roster           |
| **Infrastructure**             | Can support Python runtime            | DevOps checklist      |

#### Use Cases (Only if criteria met)

| Use Case                 | When Python Makes Sense          |
| ------------------------ | -------------------------------- |
| Custom ML model training | Fine-tuned models for governance |
| Advanced NLP             | Beyond hosted API capabilities   |
| Statistical analysis     | Complex data science operations  |
| AI agent orchestration   | Multi-agent coordination         |

#### TypeScript Alternatives to Try First

1. **Vercel AI SDK** - Multi-provider, streaming, TypeScript
2. **LangChain.js** - TypeScript LLM orchestration
3. **Hosted ML APIs** - OpenAI, Anthropic, Google, Hugging Face
4. **SQL analytics** - PostgreSQL handles most aggregations

---

## Decision Trees by Problem Domain

### Decision Tree: Background Jobs

```
Need background job processing?
│
├─ Is it a scheduled task (cron)?
│   ├─ Yes → Use Vercel Cron (simple, free)
│   │         └─ If latency matters → Use Trigger.dev scheduled tasks
│   └─ No → Continue ↓
│
├─ Is it triggered by an event?
│   ├─ Yes → Use existing DomainEventBus
│   │         └─ If throughput > 1000/min → Add Trigger.dev task
│   └─ No → Continue ↓
│
├─ Is it a long-running job (>30s)?
│   ├─ Yes → Use Trigger.dev task
│   │         └─ If Trigger.dev can't handle → Evaluate Go
│   └─ No → Use Next.js API route
│
└─ Default: Start with TypeScript, measure, then decide
```

### Decision Tree: API Scaling

```
Need to scale API?
│
├─ Is it read-heavy and cacheable?
│   ├─ Yes → Add caching layer (Vercel KV, Redis)
│   └─ No → Continue ↓
│
├─ Is latency the issue?
│   ├─ Yes → Move to Edge Functions (Vercel Edge, Supabase Edge)
│   └─ No → Continue ↓
│
├─ Is it throughput (requests/second)?
│   ├─ < 1,000 rps → Optimize TypeScript code
│   ├─ 1,000-10,000 rps → Add more Vercel instances, Edge Functions
│   ├─ > 10,000 rps sustained → Evaluate Go API gateway
│   └─ No → Continue ↓
│
└─ Default: Optimize TypeScript first, then scale horizontally
```

### Decision Tree: AI Features

```
Need AI capability?
│
├─ Is it text generation (summarize, translate, draft)?
│   ├─ Yes → Use Vercel AI SDK + hosted model (OpenAI, Anthropic)
│   └─ No → Continue ↓
│
├─ Is it embeddings/semantic search?
│   ├─ Yes → Use OpenAI embeddings + Supabase pgvector
│   └─ No → Continue ↓
│
├─ Is it custom model training?
│   ├─ Yes → Evaluate Python (meet criteria first)
│   └─ No → Continue ↓
│
├─ Is it multi-agent orchestration?
│   ├─ Yes → Start with LangChain.js (TypeScript)
│   │         └─ If insufficient → Evaluate Python
│   └─ No → Continue ↓
│
└─ Default: Use hosted AI APIs via TypeScript SDK
```

### Decision Tree: Real-Time Features

```
Need real-time updates?
│
├─ Is it database-driven (new records, status changes)?
│   ├─ Yes → Use Supabase Realtime
│   │         └─ Subscribe to postgres_changes
│   └─ No → Continue ↓
│
├─ Is it user-to-user messaging (chat)?
│   ├─ Yes → Use Supabase Realtime Broadcast
│   │         └─ If scale > 10K concurrent → Evaluate dedicated service
│   └─ No → Continue ↓
│
├─ Is it presence (who's online)?
│   ├─ Yes → Use Supabase Realtime Presence
│   └─ No → Continue ↓
│
├─ Is it high-frequency updates (>10/second)?
│   ├─ Yes → Evaluate WebSocket service
│   │         └─ Try Supabase first, Go service only if proven insufficient
│   └─ No → Use Supabase Realtime
│
└─ Default: Supabase Realtime handles most use cases
```

### Decision Tree: Caching

```
Need caching?
│
├─ Is it page-level caching (full page)?
│   ├─ Yes → Use Next.js ISR or static generation
│   └─ No → Continue ↓
│
├─ Is it API response caching?
│   ├─ Yes → Use unstable_cache + Cache-Control headers
│   │         └─ If invalidation is complex → Add Upstash Redis
│   └─ No → Continue ↓
│
├─ Is it session/auth caching?
│   ├─ Yes → Use Upstash Redis
│   └─ No → Continue ↓
│
├─ Is it rate limiting?
│   ├─ Yes → Use Upstash Ratelimit
│   └─ No → Continue ↓
│
├─ Is it expensive query results?
│   ├─ Yes, frequently accessed → Use Upstash Redis
│   ├─ Yes, rarely changes → Use PostgreSQL materialized view
│   └─ No → Continue ↓
│
└─ Default: Start without cache, add when metrics show need
```

### Decision Tree: Treasury/Financial Operations

```
Need financial operation?
│
├─ Is it a standard blockchain operation?
│   ├─ Yes → Use Ethers.js v6 (already in use)
│   └─ No → Continue ↓
│
├─ Is it multi-sig coordination?
│   ├─ Yes → Use Gnosis Safe SDK (already in use)
│   └─ No → Continue ↓
│
├─ Is it custom cryptography?
│   ├─ Yes → Use @noble/curves (TypeScript)
│   │         └─ If insufficient → Evaluate WASM
│   │              └─ If insufficient → Evaluate Rust
│   └─ No → Continue ↓
│
├─ Did security audit recommend different language?
│   ├─ Yes → Follow audit recommendation
│   └─ No → Stay TypeScript
│
└─ Default: TypeScript with existing libraries
```

---

## Measurement & Monitoring

You can't make evidence-based decisions without metrics.

### Metrics to Track Now

| Metric                     | Tool               | Threshold for Concern |
| -------------------------- | ------------------ | --------------------- |
| API latency p50/p95/p99    | Vercel Analytics   | p99 > 2s              |
| Event processing time      | Custom logging     | p99 > 5s              |
| Event queue depth          | Supabase query     | > 1000 pending        |
| Failed event rate          | Custom logging     | > 1%                  |
| Notification delivery time | Custom logging     | p99 > 30s             |
| Database connection pool   | Supabase dashboard | > 80% utilization     |
| Error rate                 | Vercel/Sentry      | > 0.1%                |

### Logging for Decision-Making

Add structured logging to critical paths:

```typescript
// In event processing
logger.info('Event processed', {
  eventId,
  eventType: type,
  processingTimeMs: Date.now() - startTime,
  handlerResults: results.map((r) => r.status),
});

// In notification delivery
logger.info('Notification batch complete', {
  batchSize,
  successCount,
  failedCount,
  totalTimeMs,
  avgTimePerNotificationMs: totalTimeMs / batchSize,
});
```

### Dashboard Queries

```sql
-- Event processing latency by type (last 24h)
SELECT
  type,
  COUNT(*) as count,
  AVG(EXTRACT(EPOCH FROM (completed_at - created_at))) as avg_seconds,
  PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY EXTRACT(EPOCH FROM (completed_at - created_at))) as p95_seconds,
  PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY EXTRACT(EPOCH FROM (completed_at - created_at))) as p99_seconds
FROM domain_events
WHERE created_at > NOW() - INTERVAL '24 hours'
  AND status = 'completed'
GROUP BY type
ORDER BY count DESC;

-- Event queue depth over time
SELECT
  DATE_TRUNC('hour', created_at) as hour,
  COUNT(*) FILTER (WHERE status = 'pending') as pending,
  COUNT(*) FILTER (WHERE status = 'processing') as processing,
  COUNT(*) FILTER (WHERE status = 'failed') as failed
FROM domain_events
WHERE created_at > NOW() - INTERVAL '7 days'
GROUP BY DATE_TRUNC('hour', created_at)
ORDER BY hour;
```

---

## Team Readiness Requirements

### Before Introducing Go

- [ ] 1+ engineer with production Go experience
- [ ] Go development environment standardized
- [ ] CI/CD pipeline supports Go builds
- [ ] Docker containerization working
- [ ] Monitoring/alerting for Go services
- [ ] On-call runbook for Go service failures
- [ ] gRPC or REST API contract defined
- [ ] TypeScript client generated for Go service

### Before Introducing Rust

- [ ] 1+ engineer with production Rust experience
- [ ] Rust development environment standardized
- [ ] CI/CD pipeline supports Rust builds
- [ ] Memory safety testing in CI
- [ ] Security audit scheduled within 3 months
- [ ] FFI or service boundary clearly defined
- [ ] Fallback plan if Rust service fails

### Before Introducing Python

- [ ] 1+ engineer with Python ML experience
- [ ] Python environment management (poetry/uv)
- [ ] CI/CD pipeline supports Python
- [ ] Dependency vulnerability scanning
- [ ] Model versioning strategy
- [ ] API contract (REST/gRPC) defined
- [ ] TypeScript client for Python service

---

## Migration Playbooks

### Playbook: TypeScript → Trigger.dev (Background Jobs)

**Timeline**: 1-2 weeks  
**Risk**: Low (same language, additive)

**Week 1: Setup**

1. Install Trigger.dev SDK
2. Configure project in Trigger.dev dashboard
3. Create first task (low-risk, non-critical)
4. Test in development

**Week 2: Migration**

1. Migrate notification batch processing
2. Migrate email retry queue
3. Migrate analytics aggregation
4. Monitor dashboard for issues
5. Remove old cron routes

**Rollback**: Revert to cron routes (code preserved in git)

### Playbook: TypeScript → Go (If Criteria Met)

**Timeline**: 4-6 weeks  
**Risk**: Medium (new language, new runtime)

**Week 1-2: Foundation**

1. Set up Go development environment
2. Create service skeleton with health checks
3. Define gRPC/REST contract
4. Generate TypeScript client
5. Docker containerization

**Week 3-4: Implementation**

1. Implement core logic
2. Add comprehensive tests
3. Set up CI/CD pipeline
4. Configure monitoring/alerting

**Week 5-6: Deployment**

1. Deploy to staging
2. Shadow traffic (run both, compare results)
3. Gradual traffic shift (10% → 50% → 100%)
4. Monitor for issues
5. Deprecate TypeScript version

**Rollback**: Feature flag to route traffic back to TypeScript

### Playbook: TypeScript → Rust (If Criteria Met)

**Timeline**: 8-12 weeks  
**Risk**: High (specialized language, critical path)

**Week 1-4: Foundation**

1. Security audit to confirm Rust recommendation
2. Set up Rust development environment
3. Create service skeleton
4. Define API contract (gRPC recommended)
5. Security review of dependencies

**Week 5-8: Implementation**

1. Implement core logic with extensive tests
2. Fuzz testing for edge cases
3. Memory safety verification
4. Performance benchmarks

**Week 9-10: Integration**

1. TypeScript client generation
2. Integration tests
3. Staging deployment
4. Shadow traffic validation

**Week 11-12: Deployment**

1. Security audit of implementation
2. Gradual traffic shift
3. 24/7 monitoring for first week
4. Deprecate TypeScript fallback

**Rollback**: Feature flag + TypeScript fallback always available

---

## Appendix A: Cost Comparison

### Recommended Stack (TypeScript + Infrastructure)

| Component              | Cost/Month   | Notes                                |
| ---------------------- | ------------ | ------------------------------------ |
| Vercel Pro             | $20          | Unlimited API routes, Edge, caching  |
| Supabase Pro           | $25          | Database, Realtime, Edge Functions   |
| Upstash Redis          | $0-30        | Free tier generous, then usage-based |
| Trigger.dev OR Inngest | $0-50        | Free tier generous                   |
| OpenAI API             | Variable     | Pay per use (~$10-50 typical)        |
| **Total**              | **~$55-175** | Scales with usage                    |

### With Tier 3 Additions

| Component             | Cost/Month    | Notes                         |
| --------------------- | ------------- | ----------------------------- |
| Everything above      | ~$55-175      | Base stack                    |
| Cloudflare Workers    | $5-25         | API gateway (if needed)       |
| Supabase Read Replica | $50           | Only if DB CPU > 80%          |
| Cloudflare R2         | $5-15         | File storage (if heavy usage) |
| **Total**             | **~$115-265** | Enterprise-ready              |

### Polyglot Stack (If Evidence Demands)

| Component             | Cost/Month    | Notes                   |
| --------------------- | ------------- | ----------------------- |
| Everything above      | ~$115-265     | Base + Tier 3           |
| Railway/Render        | $20-100       | Go/Rust/Python services |
| Additional monitoring | $50-100       | Distributed tracing     |
| **Total**             | **~$185-465** | Multi-language          |

### Kubernetes Stack (Avoid Unless Required)

| Component             | Cost/Month      | Notes                 |
| --------------------- | --------------- | --------------------- |
| Managed K8s (EKS/GKE) | $150-500        | Control plane + nodes |
| Load balancers        | $20-50          | Per service           |
| Monitoring (Datadog)  | $100-300        | Per host pricing      |
| DevOps time           | Priceless       | Significant overhead  |
| **Total**             | **~$300-1000+** | Usually overkill      |

### Decision Factor

Polyglot only makes sense when:

1. TypeScript + infrastructure can't handle the load (measured, not assumed)
2. AND cost of TypeScript inefficiency > cost of polyglot complexity
3. AND team has expertise to maintain multiple runtimes
4. AND you've exhausted all TypeScript optimizations

---

## Appendix B: Integration Patterns (If Polyglot Needed)

### Pattern 1: Event-Driven (Recommended)

```
┌─────────────────────┐     ┌─────────────────────┐
│  TypeScript Service │     │  Go/Rust/Python     │
│  (Primary)          │     │  Service            │
└─────────┬───────────┘     └──────────┬──────────┘
          │                            │
          │   ┌───────────────────┐    │
          └──►│  Message Queue    │◄───┘
              │  (Redis/Postgres) │
              └───────────────────┘
```

**Pros**: Loose coupling, failure isolation, async  
**Cons**: Eventual consistency, debugging complexity

### Pattern 2: Synchronous RPC (When Needed)

```
┌─────────────────────┐     ┌─────────────────────┐
│  TypeScript Service │────►│  Go/Rust Service    │
│  (Client)           │ gRPC│  (Server)           │
└─────────────────────┘     └─────────────────────┘
```

**Pros**: Type-safe contracts, immediate response  
**Cons**: Tight coupling, failure propagation

### Pattern 3: Sidecar (For Validation)

```
┌─────────────────────────────────────────────┐
│  Pod/Container                              │
│  ┌─────────────────┐  ┌─────────────────┐  │
│  │  TypeScript App │──│  Rust Sidecar   │  │
│  │  (Main)         │  │  (Validation)   │  │
│  └─────────────────┘  └─────────────────┘  │
└─────────────────────────────────────────────┘
```

**Pros**: Same network, low latency  
**Cons**: Deployment complexity

---

## Appendix C: Checklist for Language Decision

### Before Proposing New Language

- [ ] Have I tried all TypeScript alternatives?
- [ ] Do I have metrics proving TypeScript is the bottleneck?
- [ ] Is the bottleneck due to language, or architecture/algorithm?
- [ ] Have I consulted with someone experienced in the proposed language?
- [ ] Do we have (or can hire) expertise to maintain this long-term?
- [ ] What's the rollback plan if it doesn't work?
- [ ] Does this align with our roadmap priorities?

### Before Approving New Language

- [ ] All introduction criteria met (documented above)
- [ ] Team readiness checklist complete
- [ ] Migration playbook defined
- [ ] Rollback plan tested
- [ ] Monitoring/alerting configured
- [ ] On-call runbook written
- [ ] Security review scheduled (for Rust)

---

## Summary

### Immediate Actions (Do Now)

| Action                   | Why                                 | Effort |
| ------------------------ | ----------------------------------- | ------ |
| Add PostgreSQL indexes   | Free 10-100x query speedup          | 1 day  |
| Enable Supabase Realtime | Live updates, already paying for it | 2 days |
| Add edge caching         | Faster public pages                 | 1 day  |

### Near-Term Actions (Tier 1)

| Action                     | Why                    | Effort |
| -------------------------- | ---------------------- | ------ |
| Add Upstash Redis          | Rate limiting, caching | 2 days |
| Add Trigger.dev or Inngest | Background jobs        | 1 week |
| Add materialized views     | Dashboard performance  | 3 days |

### Polyglot Decision Summary

| Question                         | Answer                                                                 |
| -------------------------------- | ---------------------------------------------------------------------- |
| Should we use Go for workers?    | **Not yet** - Try Trigger.dev/Inngest first, measure, then decide      |
| Should we use Rust for treasury? | **Not yet** - Existing Ethers.js + Safe SDK is working; wait for audit |
| Should we use Python for AI?     | **Not yet** - Try Vercel AI SDK first                                  |
| Should we add Kubernetes?        | **No** - Use managed services (Vercel, Railway)                        |
| Should we add microservices?     | **No** - Monolith is fine for current scale                            |
| When should we revisit polyglot? | When metrics show TypeScript bottleneck                                |

### Scale Targets (TypeScript Stack)

This TypeScript-first stack should comfortably handle:

| Metric                           | Target Capacity |
| -------------------------------- | --------------- |
| DAOs                             | 10,000+         |
| Users                            | 100,000+        |
| API requests/day                 | 1,000,000+      |
| Background jobs/day              | 100,000+        |
| Concurrent WebSocket connections | 10,000+         |

**Default Position**: Stay TypeScript until evidence proves otherwise. Add infrastructure (Redis, background jobs) before adding languages.

---

_Last Updated: December 2025_  
_Status: Active Decision Framework_  
_Review Schedule: Quarterly or when metrics warrant_
