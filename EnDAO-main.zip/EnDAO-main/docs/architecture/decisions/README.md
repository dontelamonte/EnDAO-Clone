# Architecture Decision Records

This directory contains Architecture Decision Records (ADRs) for the EnDAO platform.

## What are ADRs?

Architecture Decision Records document significant architectural decisions made during the development of EnDAO. Each ADR captures:

- **Context**: The issue or decision that needs to be made
- **Decision**: What was decided and why
- **Consequences**: The positive and negative outcomes of the decision
- **Alternatives**: Other options that were considered

ADRs are immutable once accepted. If a decision changes, we create a new ADR that supersedes the old one.

## Template

Use the [template](./template.md) when creating new ADRs.

## Process

1. Copy `template.md` to a new file with the next available number: `XXX-short-title.md`
2. Fill out all sections with clear, concise information
3. Start with status "Proposed"
4. After review and acceptance, update status to "Accepted"
5. Update this README to include the new ADR in the index below

## Index

| ADR                                                    | Title                                  | Status   | Date       |
| ------------------------------------------------------ | -------------------------------------- | -------- | ---------- |
| [001](./001-initial-architecture.md)                   | Initial Architecture                   | Accepted | 2025-12-16 |
| [002](./002-ethers-adapter-pattern.md)                 | Ethers Adapter Pattern                 | Accepted | 2025-12-16 |
| [003](./003-safe-adapter-pattern.md)                   | Safe Adapter Pattern                   | Accepted | 2025-12-16 |
| [004](./004-privy-adapter-pattern.md)                  | Privy Adapter Pattern                  | Accepted | 2025-12-16 |
| [005](./005-voting-plugin-architecture.md)             | Voting Plugin Architecture             | Accepted | 2025-12-16 |
| [006](./006-event-driven-notification-architecture.md) | Event-Driven Notification Architecture | Accepted | 2025-12-18 |
