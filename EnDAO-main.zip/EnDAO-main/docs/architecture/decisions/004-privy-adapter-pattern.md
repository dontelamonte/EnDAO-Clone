# ADR 004: Privy SDK Adapter Pattern

## Status

Accepted

## Date

2025-12-16

## Context

EnDAO uses Privy for authentication and wallet management across both server-side (API routes) and client-side (React components). Privy provides:

1. **Server-Side Auth**: Token verification via `@privy-io/server-auth`
2. **Client-Side Signing**: Message signing via `@privy-io/react-auth`
3. **Wallet Management**: Wallet access and connection via `@privy-io/react-auth`

Current implementation has direct Privy SDK dependencies scattered throughout the codebase:

### Server-Side (privy-server.ts)

```typescript
import { PrivyClient } from '@privy-io/server-auth';
const verifiedClaims = await privyServer.verifyAuthToken(token);
```

### Client-Side

```typescript
import { useSignMessage, useWallets } from '@privy-io/react-auth';
const { signMessage } = useSignMessage();
const { wallets } = useWallets();
```

This creates challenges:

1. **SDK Coupling**: Business logic tightly coupled to Privy SDK APIs
2. **Testing Complexity**: Difficult to mock Privy hooks and client methods
3. **Migration Risk**: Future Privy SDK updates could break integrations
4. **Scattered Dependencies**: Privy imports throughout auth, signing, and wallet code

## Decision

We will create **three focused Privy adapters** that abstract different Privy SDK functionalities:

### 1. PrivyAuthAdapter (Server-Side)

Wraps `@privy-io/server-auth` for token verification:

```typescript
export interface PrivyAuthAdapter {
  verifyToken(token: string): Promise<VerifiedUser | null>;
  getUserById(userId: string): Promise<unknown>;
}

export interface VerifiedUser {
  userId: string;
  walletAddress?: string;
  email?: string;
}
```

### 2. PrivySigningAdapter (Client-Side Hook)

Wraps `useSignMessage` and `useSignTypedData` from `@privy-io/react-auth`:

```typescript
export interface PrivySigningAdapter {
  signMessage(options: SignMessageOptions): Promise<string>;
  signTypedData(options: SignTypedDataOptions): Promise<string>;
}

// Used via React hook
const signingAdapter = usePrivySigningAdapter();
```

### 3. PrivyWalletAdapter (Client-Side Hook)

Wraps `useWallets` from `@privy-io/react-auth`:

```typescript
export interface PrivyWalletAdapter {
  wallets: WalletInfo[];
  ready: boolean;
}

// Used via React hook
const { wallets, ready } = usePrivyWalletAdapter();
```

### Implementation Strategy

1. **Auth Adapter**: Singleton pattern for server-side (follows existing privy-server.ts pattern)
2. **Hook Adapters**: React hooks that wrap Privy hooks and normalize interfaces
3. **Normalized Interfaces**: Convert Privy-specific types to EnDAO domain types
4. **Error Handling**: Wrap Privy errors in descriptive error messages

## Consequences

### Positive

1. **Isolation**: Auth and wallet logic decoupled from Privy SDK details
2. **Testability**: Easy to mock adapters in unit tests
3. **Normalized Data**: Convert Privy types to EnDAO domain types
4. **Swappability**: Future auth provider changes isolated to adapters
5. **Clear Contracts**: Documents what Privy functionality EnDAO uses

### Negative

1. **Hook Indirection**: Client-side adapters add a hook wrapper layer
2. **Partial Abstraction**: Still exposes some Privy concepts (e.g., linked accounts)
3. **Maintenance**: Adapters must be updated when new Privy features are needed
4. **Learning Curve**: Developers must use adapters instead of Privy hooks directly

### Migration Path

1. **Phase 1**: Create adapters alongside existing Privy usage (non-breaking)
2. **Phase 2**: Migrate new authentication code to use adapters
3. **Phase 3**: Refactor existing auth middleware to use PrivyAuthAdapter
4. **Phase 4**: Refactor voting components to use signing/wallet adapters
5. **Phase 5**: Remove direct Privy imports (enforce via ESLint rule)

## Alternatives Considered

### Alternative 1: Direct Privy SDK Usage (Status Quo)

- **Rejected**: Tight coupling, difficult testing, scattered dependencies
- **Trade-off**: Simpler initially vs. long-term maintainability

### Alternative 2: Single Unified Privy Adapter

- **Rejected**: Mixes server-side and client-side concerns
- **Trade-off**: Fewer files vs. poor separation of concerns

### Alternative 3: Full Auth Abstraction (Provider-Agnostic)

- **Rejected**: Over-engineering, EnDAO is committed to Privy
- **Trade-off**: Complete flexibility vs. unnecessary complexity

### Alternative 4: Wrapper Functions (Non-Hook)

- **Rejected**: Doesn't work with React hooks pattern
- **Trade-off**: Simpler vs. React incompatibility

## References

- Privy Server Auth: https://docs.privy.io/guide/server/
- Privy React SDK: https://docs.privy.io/guide/react/
- Related: ADR-001 (Hybrid Voting), ADR-002 (Ethers Adapter)

## Notes

### Why Three Adapters?

1. **PrivyAuthAdapter**: Server-side only (uses 'server-only' package)
2. **PrivySigningAdapter**: Client-side only (needs React hooks)
3. **PrivyWalletAdapter**: Client-side only (needs React hooks)

Separating these ensures:

- Server code doesn't bundle client SDK
- Client code doesn't bundle server SDK
- Clear separation of concerns

### Normalized Interfaces

The adapters normalize Privy's complex types:

**Before (Privy SDK)**:

```typescript
const claims = await privyServer.verifyAuthToken(token);
const wallet = claims.linkedAccounts?.find((a) => a.type === 'wallet')?.address;
```

**After (Adapter)**:

```typescript
const user = await privyAuthAdapter.verifyToken(token);
const wallet = user.walletAddress;
```

### Testing Strategy

**Server-Side Mock**:

```typescript
const mockAuthAdapter: PrivyAuthAdapter = {
  verifyToken: jest.fn().mockResolvedValue({
    userId: 'did:privy:123',
    walletAddress: '0xabc...',
  }),
  getUserById: jest.fn(),
};
```

**Client-Side Mock**:

```typescript
jest.mock('@/lib/adapters/privy', () => ({
  usePrivySigningAdapter: () => ({
    signMessage: jest.fn().mockResolvedValue('0x123...'),
    signTypedData: jest.fn().mockResolvedValue('0x456...'),
  }),
}));
```

### Future Considerations

If EnDAO needs to support multiple auth providers (e.g., WalletConnect, MetaMask):

1. Create provider-agnostic interface (e.g., `AuthAdapter`)
2. Implement `PrivyAuthAdapter implements AuthAdapter`
3. Add `WalletConnectAuthAdapter implements AuthAdapter`
4. Use strategy pattern to select adapter

For now, Privy-specific adapters are sufficient.
