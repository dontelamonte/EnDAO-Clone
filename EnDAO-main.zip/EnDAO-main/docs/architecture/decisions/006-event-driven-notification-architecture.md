# ADR-006: Event-Driven Notification Architecture

**Date**: 2025-12-18
**Status**: Accepted
**Deciders**: Engineering (Claude Code assisted)

## Context

During a comprehensive architectural review of the notification, activity logging, and analytics systems, significant technical debt was discovered from the Firebase-to-Supabase migration:

### Current State Issues

| Problem                    | Notifications             | Activities        | Analytics                  |
| -------------------------- | ------------------------- | ----------------- | -------------------------- |
| **Service Bloat**          | 35 services               | 10+ services      | 8 services                 |
| **Data Fragmentation**     | 2 parallel systems        | 3 separate tables | 5 sources for member count |
| **In-Memory State**        | Queue, rate limits, dedup | Privacy filtering | N/A                        |
| **Single Source of Truth** | No                        | No                | No                         |
| **Production Ready**       | No                        | Partial           | Partial                    |

### Critical Problems

1. **Treasury notifications stored IN-MEMORY ONLY** - lost on server restart (data loss risk)
2. **User preferences NOT checked** before creating notifications
3. **3 activity tables** with unclear ownership (`dao_activities`, `user_activities`, `dao_admin_audit_logs`)
4. **5 different sources for member count** - inconsistent data across UI
5. **Materialized views never auto-refresh** - silently serve stale analytics
6. **53+ services** for three related concerns - massive cognitive overhead

### Root Cause

Firebase-to-PostgreSQL migration retained patterns appropriate for Firestore but suboptimal for PostgreSQL:

| Firebase Pattern                | PostgreSQL Reality                       |
| ------------------------------- | ---------------------------------------- |
| In-memory caching for real-time | Should use database + materialized views |
| Denormalized documents          | Should use normalized tables with JOINs  |
| Cloud Functions for processing  | Should use pg_cron or proper job queue   |
| Subcollections for activities   | Single table with RLS                    |
| Client-side aggregations        | SQL GROUP BY / views                     |

## Decision

Implement a **Domain Event Bus** architecture that:

1. **Centralizes event emission** - Single `eventBus.emit()` call per domain action
2. **Persists events to database** - `domain_events` table survives restarts
3. **Uses typed handlers** - Audit, Notification, Analytics handlers with clear responsibilities
4. **Enforces user preferences** - Check preferences before creating notifications
5. **Provides idempotency** - Prevent duplicate notifications during migration

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    DOMAIN SERVICES                          │
│  (ProposalService, MemberService, TreasuryService, etc.)    │
└─────────────────────────┬───────────────────────────────────┘
                          │ emit('proposal.created', payload)
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    EVENT BUS (DB-backed)                    │
│  - Persisted to `domain_events` table                       │
│  - Zod schema validation per event type                     │
│  - Idempotency keys prevent duplicates                      │
│  - Retry with exponential backoff                           │
└─────────────────────────┬───────────────────────────────────┘
                          │ dispatch to handlers
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
┌─────────────┐   ┌─────────────┐   ┌─────────────┐
│   AUDIT     │   │ NOTIFICATION│   │  ANALYTICS  │
│  HANDLER    │   │   HANDLER   │   │   HANDLER   │
│  (sync)     │   │   (async)   │   │   (async)   │
│  blocking   │   │ non-blocking│   │ non-blocking│
└─────────────┘   └─────────────┘   └─────────────┘
       │                 │                 │
       ▼                 ▼                 ▼
  audit_logs       notifications      dao_stats_*
```

### Key Design Decisions

#### 1. Database-Backed Event Queue

```sql
CREATE TABLE domain_events (
  id UUID PRIMARY KEY,
  type TEXT NOT NULL,                    -- 'proposal.created', etc.
  idempotency_key TEXT UNIQUE,           -- Prevents duplicate emissions
  payload JSONB NOT NULL,
  status TEXT DEFAULT 'pending',         -- pending/processing/completed/failed/dead_letter
  retry_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### 2. Handler Execution Rules

| Handler      | Mode  | Failure Behavior | Retries         |
| ------------ | ----- | ---------------- | --------------- |
| Audit        | Sync  | Blocks emit      | 5 (exponential) |
| Notification | Async | Non-blocking     | 3 (linear)      |
| Analytics    | Async | Non-blocking     | 2 (fixed)       |

#### 3. Preference Mapping

Every event type maps to a user preference key with defaults:

```typescript
EVENT_PREFERENCE_MAP = {
  'proposal.created': {
    preferenceKey: 'proposalCreated',
    defaultEnabled: true,
  },
  'proposal.passed': {
    preferenceKey: 'proposalStatusChanged',
    defaultEnabled: true,
  },
  'treasury.initiated': { preferenceKey: null }, // Always notify (no preference check)
  'treasury.signature_added': { preferenceKey: 'skip' }, // Never notify
};
```

#### 4. Feature Flags for Rollout

```typescript
EVENT_BUS_FLAGS = {
  enabled: 'eventBus.enabled',
  handlers: {
    audit: 'eventBus.handlers.audit',
    notification: 'eventBus.handlers.notification',
    analytics: 'eventBus.handlers.analytics',
  },
  dualPath: {
    enabled: 'eventBus.dualPath.enabled',
  },
};
```

### Service Consolidation

| Current                  | Target       | Reduction |
| ------------------------ | ------------ | --------- |
| 35 notification services | 5 services   | -86%      |
| 10 activity services     | 3 services   | -70%      |
| 8 analytics services     | 4 services   | -50%      |
| **53 total**             | **12 total** | **-77%**  |

## Consequences

### Positive

- **Data Durability**: Treasury notifications persist through restarts
- **User Respect**: Notifications honor user preferences
- **Single Source of Truth**: One event per domain action
- **Maintainability**: 77% reduction in service count
- **Debuggability**: All events logged to `domain_events` for replay/audit
- **Testability**: Handlers testable in isolation
- **Scalability**: Async handlers don't block request/response

### Negative

- **Initial Complexity**: Event bus infrastructure requires upfront investment
- **Migration Period**: Dual-path mode (old + new) during transition
- **Learning Curve**: Team must understand event-driven patterns
- **Database Load**: Additional writes to `domain_events` table

### Risks and Mitigations

| Risk                            | Mitigation                                           |
| ------------------------------- | ---------------------------------------------------- |
| Breaking existing notifications | Feature flags + dual-path with idempotency           |
| Data loss during migration      | Events persisted from Day 1, old tables kept         |
| Performance regression          | Async handlers, parallel execution                   |
| Duplicate notifications         | Idempotency keys in `notification_idempotency` table |

## Alternatives Considered

### Alternative 1: Keep Current Architecture + Fix Treasury Bug Only

- **Description**: Add database persistence for treasury notifications, leave everything else
- **Reason not chosen**: Doesn't address root cause (53+ services, no preferences, scattered triggers), accumulates more tech debt

### Alternative 2: Activity-to-Notification Bridge

- **Description**: Create a cron job that converts activities to notifications
- **Reason not chosen**: Adds latency, doesn't enforce preferences at emission time, doesn't reduce service complexity

### Alternative 3: Message Queue (RabbitMQ/Redis Streams)

- **Description**: Use external message broker for event distribution
- **Reason not chosen**: Adds operational complexity, PostgreSQL is sufficient for current scale, can migrate later if needed

## Implementation Notes

### Directory Structure

```
src/lib/services/events/
├── index.ts
├── types/
│   ├── domain-event.types.ts
│   └── event-schemas.ts              # Zod schemas per event type
├── domain-event-bus.service.ts
├── event-handler-registry.ts
├── event-persistence.service.ts
└── handlers/
    ├── base-event-handler.ts
    ├── audit-log.handler.ts
    ├── notification.handler.ts
    ├── analytics.handler.ts
    └── utils/
        ├── preference-mapping.ts
        └── idempotency.service.ts
```

### Database Migrations

- `070_domain_events.sql` - Event queue with retry state
- `071_event_handler_state.sql` - Per-handler processing state
- `072_notification_idempotency.sql` - Duplicate prevention
- `073_view_refresh_tracking.sql` - pg_cron scheduled view refresh

### Rollout Plan

1. **Week 1**: Database migrations + event bus infrastructure
2. **Week 2**: Enable audit handler only (logging, validation)
3. **Week 3**: Enable notification handler (parallel with old system)
4. **Week 4**: Remove old notification calls, enable analytics handler

### Usage Example

```typescript
// Before: Scattered notification calls
await routeDAONotification('proposal_created', title, message, { daoId })
await ActivityService.logDAOActivity(daoId, 'proposal_created', ...)
// ... plus 3 more calls in different files

// After: Single event emission
await eventBus.emit('proposal.created', { daoId, userId, proposalId }, {
  proposalId,
  proposalTitle,
  creatorId,
  creatorName,
  daoName,
})
// Handlers automatically: log audit, create notifications (with pref check), update stats
```

---

## Principle Alignment

| Aspect                 | Principle Addressed                 |
| ---------------------- | ----------------------------------- |
| Event bus pattern      | #5 Core + Plugin Model              |
| Handler interface      | #6 Small, powerful interfaces       |
| Isolated handlers      | #5 Isolation of Development         |
| Self-contained modules | #1 Small, independent modules       |
| Registry abstraction   | #3 Helper Libraries                 |
| Database persistence   | #4 Leverage PostgreSQL capabilities |

## Related ADRs

- [ADR-005: Voting Plugin Architecture](./005-voting-plugin-architecture.md) - Similar registry pattern for handlers
- [ADR-001: Initial Architecture](./001-initial-architecture.md) - Service layer patterns

## References

- Plan file: `/Users/jjones/.claude/plans/vectorized-hugging-tiger.md`
- Architectural review findings documented in plan file
