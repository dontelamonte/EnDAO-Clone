# ADR 002: Ethers.js Adapter Pattern

## Status

Accepted

## Date

2025-12-16

## Context

EnDAO currently uses ethers.js v6.15.0 directly throughout the codebase for signature verification, address validation, and amount parsing. This creates several challenges:

1. **SDK Version Lock-in**: Direct dependency on ethers.js v6 makes it difficult to upgrade or migrate to alternative libraries
2. **Testing Complexity**: Difficult to mock ethers.js functions in unit tests without complex mocking setup
3. **Migration Risk**: Future SDK updates (e.g., ethers v7) would require changes across the entire codebase
4. **Coupling**: Business logic is tightly coupled to a specific library implementation

### Example Current Usage

```typescript
// Signature verification scattered across codebase
import { verifyTypedData } from 'ethers';
const signer = verifyTypedData(domain, types, message, signature);

// Amount parsing in multiple services
import { parseEther } from 'ethers';
const amount = parseEther('1.5');
```

## Decision

We will create an **EthersAdapter** interface that abstracts all ethers.js operations used in EnDAO. The initial implementation (`EthersV6Adapter`) will wrap ethers.js v6 APIs.

### Adapter Interface

```typescript
export interface EthersAdapter {
  // Signature verification
  verifyEIP712Signature(domain, types, message, signature): string | null;
  verifyPersonalSignature(message, signature): string | null;

  // Hashing
  hashEIP712Message(domain, types, message): string;
  hashPersonalMessage(message): string;

  // Utilities
  validateAddress(address): boolean;
  parseAmount(amount): bigint;
  formatAmount(amount, decimals?): string;
  checksumAddress(address): string;
}
```

### Implementation Strategy

1. **Singleton Pattern**: Single adapter instance via `getEthersAdapter()`
2. **Error Wrapping**: All SDK errors wrapped in `AdapterError` for consistent handling
3. **Type Safety**: Full TypeScript support with proper type definitions
4. **Minimal Surface Area**: Only expose operations actually used in EnDAO

## Consequences

### Positive

1. **Isolation**: Business logic decoupled from ethers.js implementation details
2. **Testability**: Easy to create mock adapters for unit tests
3. **Swappability**: Future SDK migrations only require new adapter implementation
4. **Consistency**: Standardized error handling and API surface
5. **Documentation**: Clear contract of what operations are supported

### Negative

1. **Indirection**: Additional layer between business logic and SDK
2. **Maintenance**: Adapter must be updated when new ethers.js features are needed
3. **Learning Curve**: Developers must understand adapter pattern instead of using ethers.js directly

### Migration Path

1. **Phase 1**: Create adapter alongside existing ethers.js usage (non-breaking)
2. **Phase 2**: Migrate new code to use adapter
3. **Phase 3**: Gradually refactor existing code to use adapter
4. **Phase 4**: Remove direct ethers.js imports (enforce via ESLint rule)

## Alternatives Considered

### Alternative 1: Direct ethers.js Usage (Status Quo)

- **Rejected**: Makes future migrations painful, poor testability
- **Trade-off**: Simpler initial implementation vs. long-term maintainability

### Alternative 2: Wrapper Functions (Non-OOP)

- **Rejected**: Less structured, harder to swap implementations
- **Trade-off**: Simpler vs. less flexible

### Alternative 3: Full Abstraction Layer

- **Rejected**: Over-engineering, abstracts too much
- **Trade-off**: Complete isolation vs. unnecessary complexity

## References

- ethers.js v6 documentation: https://docs.ethers.org/v6/
- Adapter Pattern: https://refactoring.guru/design-patterns/adapter
- Related: ADR-001 (Hybrid Voting Architecture)

## Notes

The adapter only exposes operations currently used in EnDAO:

- Signature verification (EIP-712 and personal_sign)
- Message hashing
- Address validation and checksumming
- Amount parsing/formatting

Additional ethers.js features (e.g., contract interaction, providers) are NOT included as they are not needed for EnDAO's current use cases.
