# ADR-XXX: [Title]

**Date**: YYYY-MM-DD
**Status**: Proposed | Accepted | Deprecated | Superseded
**Deciders**: Engineering (Claude Code assisted)

## Context

[What is the issue/decision needed? Describe the forces at play, including technological, political, social, and project-related. Keep it factual and objective.]

## Decision

[What was decided? State the decision clearly and concisely. Include the reasoning behind the decision.]

## Consequences

[What are the results? List both positive and negative consequences. Be honest about trade-offs.]

### Positive

- [Benefit 1]
- [Benefit 2]

### Negative

- [Trade-off 1]
- [Trade-off 2]

## Alternatives Considered

[What other options were evaluated? For each alternative, briefly explain why it was not chosen.]

### Alternative 1: [Name]

- **Description**: [Brief description]
- **Reason not chosen**: [Why this wasn't selected]

### Alternative 2: [Name]

- **Description**: [Brief description]
- **Reason not chosen**: [Why this wasn't selected]
