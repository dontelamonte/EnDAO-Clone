# ADR-001: Initial Architecture

**Date**: 2025-12-16
**Status**: Accepted
**Deciders**: Engineering (Claude Code assisted)

## Guiding Principles

This architecture was designed following these core software architecture principles:

### 1. Core Architectural Philosophy

- **Small, independent modules**: Each module should be small enough for one person to write and maintain. Modules are "black boxes" interacted with only through documented APIs.
- **APIs as Contracts**: APIs hide implementation details but are forward-thinking enough to handle future needs.
- **Separation of Concerns**: Clearly distinguish between core logic, UI, storage, and integration code. Anything not owned by us (platform code, 3rd-party libs) should be wrapped in our own abstraction layer.

### 2. Risk Management Strategies

- **Anticipate change** in: Platforms, programming languages, hardware, personnel, and organizational priorities
- **Minimize dependency risk**: Wrap external libraries to prevent vendor lock-in
- **Reduce friction**: Favor code that is stable and explicit over "clever" short code that's brittle

### 3. Layered Architecture & Abstraction

- **Platform Layer Wrappers**: Create thin wrappers over platform APIs so migrations are easier
- **Helper Libraries**: Common utilities should live in reusable libraries

### 4. Data & Domain Modeling

- **Choose a Core Primitive**: Identify the simplest, most universal data unit (for EnDAO: DAO, Proposal, Vote, Member)
- **Distinguish between Primitive and Structure**: Keep primitives consistent to allow multiple structures without massive rewrites

### 5. Plugin-Based Extensibility

- **Core + Plugin Model**: Core stores and manages primitives; plugins implement specific features via stable APIs
- **Isolation of Development**: Teams can work on plugins without touching the core

### 6. API & Format Design

- **Small, powerful interfaces**: Keep APIs minimal while covering necessary use cases
- **Implementation freedom**: API should never leak implementation details

### 7. Tooling for Development

- **Build tools before full system**: Simulators, debuggers, test utilities let teams develop without waiting for the full system
- **Record & Replay**: Record system data for debugging, regression testing, and training

### 8. Migration & Integration Strategies

- **Never "big bang" replace old systems**: Migrate gradually by running both in parallel
- **Multiple Access Layers**: Expose APIs for different client needs (web, mobile, CLI)

### 9. Deployment Flexibility

- **Same core, multiple frontends**: Core logic usable in both GUI apps and headless/CLI tools
- **Scale independence**: Core should work on a single device or across distributed systems

---

## Context

EnDAO is a platform for institutional DAO governance, supporting both web and mobile clients. The platform needed an architecture that would:

1. Support code sharing between web and mobile applications
2. Provide secure data access with proper authorization
3. Enable feature rollout control
4. Protect treasury operations with multiple safety layers
5. Prevent security issues from browser code calling server-only functions

## Decision

We implemented a multi-layered architecture with the following key decisions:

### 1. Monorepo Structure

Organize code into `apps/web` (Next.js), `apps/mobile` (Expo), and `packages/shared-types` for shared TypeScript types. This enables code sharing while maintaining platform-specific implementations.

### 2. Repository Pattern

Implement data access through 25+ repository classes:

- **Client Repositories**: Enforce Row Level Security (RLS) for browser-safe operations
- **Admin Repositories**: Bypass RLS for server-only administrative operations

This separation prevents accidental privilege escalation and provides clear boundaries for security auditing.

### 3. BaseService Abstraction

All services extend `BaseService` and return `ServiceResponse<T>` for consistent error handling and response patterns across the application.

### 4. Browser-Safe Pattern

Client code must use hooks → API routes → services, never calling services directly. This prevents:

- Server-only code from running in the browser
- Accidental exposure of admin privileges
- CSRF vulnerabilities

### 5. Shared Types Package

Domain types live in `@endao/shared-types` to ensure type consistency between web and mobile platforms. This prevents type drift and enables safe refactoring.

### 6. Feature Flag System

Progressive rollout via `feature-flag.service.ts` enables:

- Safe deployment of experimental features
- A/B testing capabilities
- Quick rollback if issues arise

### 7. Treasury 4-Layer Protection

Critical treasury operations are protected by:

1. **Status checks**: Block archived/deleted DAOs
2. **Freeze system**: `TreasuryAccessControlService` gates all transactions
3. **Grace periods**: 7-day delay on critical changes
4. **Execution locks**: `TreasuryExecutionLockService` prevents race conditions

## Consequences

### Positive

- Clear separation of concerns between web and mobile
- Type safety across platforms prevents runtime errors
- Repository pattern provides security audit points
- Browser-safe pattern prevents entire classes of vulnerabilities
- Feature flags enable safe progressive rollout
- Treasury protection prevents catastrophic financial losses

### Negative

- Monorepo adds complexity to build and deployment
- Repository layer adds indirection (performance impact is minimal)
- Browser-safe pattern requires more boilerplate (hooks + API routes)
- Developers must remember to use shared types (enforced via linting)
- Feature flag system requires coordination for rollout

## Alternatives Considered

### Alternative 1: Separate Repositories

- **Description**: Maintain separate repositories for web, mobile, and shared code
- **Reason not chosen**: Increases coordination overhead, makes atomic changes difficult, and complicates dependency management

### Alternative 2: Direct Database Access from Services

- **Description**: Skip the repository layer and access Supabase directly from services
- **Reason not chosen**: Loses security boundary, makes RLS enforcement inconsistent, harder to audit data access patterns

### Alternative 3: Server Actions Instead of API Routes

- **Description**: Use Next.js Server Actions for browser-to-server communication
- **Reason not chosen**: Server Actions were experimental when project started, and API routes provide clearer CSRF protection patterns

### Alternative 4: Single Treasury Protection Layer

- **Description**: Rely only on database-level checks or only on application-level checks
- **Reason not chosen**: Defense-in-depth requires multiple layers. Single layer is vulnerable to bugs or bypass attempts.

---

## Principle Alignment

How each architectural decision aligns with our guiding principles:

| Decision                      | Primary Principles Addressed                              |
| ----------------------------- | --------------------------------------------------------- |
| Monorepo Structure            | #9 Deployment Flexibility (same core, multiple frontends) |
| Repository Pattern            | #1 Separation of Concerns, #3 Layered Architecture        |
| BaseService Abstraction       | #6 Small Interfaces, #3 Helper Libraries                  |
| Browser-Safe Pattern          | #1 APIs as Contracts, #2 Risk Management                  |
| Shared Types Package          | #4 Core Primitives, #8 Multiple Access Layers             |
| Feature Flag System           | #8 Never Big Bang, #2 Anticipate Change                   |
| Treasury 4-Layer Protection   | #2 Risk Management, #3 Layered Architecture               |
| Dependency Adapters (future)  | #1 Separation of Concerns, #2 Minimize Dependency Risk    |
| Voting Plugin System (future) | #5 Core + Plugin Model, #5 Isolation of Development       |

---

## Compliance Checklist

Use this checklist when making architectural decisions:

- [ ] Is each module small enough for one person to maintain? (Principle #1)
- [ ] Are third-party dependencies wrapped in our own abstraction? (Principle #2)
- [ ] Is the change layered appropriately (UI/Logic/Data)? (Principle #3)
- [ ] Does it use established core primitives? (Principle #4)
- [ ] Can it be implemented as a plugin without touching core? (Principle #5)
- [ ] Is the API minimal and implementation-agnostic? (Principle #6)
- [ ] Are there adequate test/debug tools? (Principle #7)
- [ ] Can it be migrated incrementally? (Principle #8)
- [ ] Does it work across web, mobile, and potential CLI? (Principle #9)

---

## Retrospective (December 2025)

After 6+ months in production, this section captures lessons learned and validates architectural decisions.

### What Worked Well

1. **Repository Pattern**: The client/admin repository split has prevented several security issues during code review. Clear boundaries made RLS enforcement consistent.

2. **Browser-Safe Pattern**: Zero security incidents from browser code calling server-only functions. The hook → API route → service pattern is now second nature to the team.

3. **Shared Types Package**: Type drift between web and mobile has been minimal. Refactoring is safer with compile-time checks across platforms.

4. **Treasury 4-Layer Protection**: The defense-in-depth approach caught edge cases that single-layer protection would have missed. Grace periods prevented accidental irreversible actions.

5. **Feature Flags**: Enabled safe rollout of advanced voting systems (quadratic, delegated, weighted) without risking production stability.

### What Could Be Improved

1. **File Size Creep**: Some services and components grew beyond maintainable sizes (17 files >800 lines). CI now enforces 800-line limits via `yarn check:files`.

2. **Service Layer Organization**: 34+ services at varying directory depths. Future work: reorganize into domain subdirectories with consistent naming.

3. **Adapter Adoption**: External dependency wrappers (Ethers, Safe, Privy) were added late. Earlier adoption would have simplified testing and reduced migration risk.

4. **Component Pattern Consistency**: Dual patterns exist (`/proposals/v2/` vs `/proposals/enhanced-edit/`). Complete v2 migration pending.

### Metrics

| Metric                  | Value   | Notes                          |
| ----------------------- | ------- | ------------------------------ |
| Files in src/           | 1,050   | Scanned by architecture checks |
| Total LOC               | 243,549 | Excluding tests                |
| Files >800 lines        | 17      | Priority for refactoring       |
| Complex functions (>10) | 271     | Flagged by complexity checks   |
| Security incidents      | 0       | Browser-safe pattern effective |
| Treasury incidents      | 0       | 4-layer protection effective   |
| Test coverage           | 80%+    | Branches, functions, lines     |

### Recommendations for Future Work

1. **Refactor oversized files** - Split the 17 files exceeding 800 lines using compound component and service extraction patterns

2. **Complete v2 migration** - Consolidate component patterns to reduce cognitive load

3. **Service domain organization** - Group services by domain (`lib/services/{domain}/`) with consistent kebab-case naming

4. **Expand adapter coverage** - Apply adapter pattern to remaining external dependencies (analytics, monitoring)
