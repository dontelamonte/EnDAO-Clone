# ADR-005: Voting Plugin Architecture

**Date**: 2025-12-16
**Status**: Accepted
**Deciders**: Engineering (Claude Code assisted)

## Context

The voting system in EnDAO supports multiple voting types:

- **Simple**: Standard yes/no/abstain voting
- **Ranked**: Instant-runoff voting with ranked choices
- **Weighted**: Token-weighted voting
- **Quadratic**: Square root of credits spent

Previously, voting logic was implemented with switch statements in `VotingEngineService` and `VoteCountingService`, making it difficult to:

1. Add new voting systems without modifying core services
2. Test voting strategies in isolation
3. Understand the specific rules for each voting type
4. Allow external teams to contribute new voting methods

## Decision

Implement a Plugin Architecture for voting strategies following Guideline #5 (Plugin-Based Extensibility):

### 1. Strategy Interface

All voting systems implement `IVotingStrategy`:

```typescript
interface IVotingStrategy {
  readonly id: VotingSystem;
  readonly name: string;
  readonly description: string;

  validateConfig(config: ProposalVotingConfig): ValidationResult;
  processVote(vote, member, config): ProcessedVote;
  calculateResults(
    proposalId,
    votes,
    config,
    eligibleVoters
  ): Promise<ProposalVotingResults>;
  checkQuorum(participationRate, quorumPercentage): boolean;
  checkPassed(results, config): boolean;
}
```

### 2. Strategy Registry

`VotingStrategyRegistry` provides:

- Singleton pattern for global access
- Core strategies registered at startup
- Runtime registration for custom strategies
- Lookup by voting system ID

```typescript
// Before: Switch statement
switch (votingSystem) {
  case 'ranked':
    return await getRankedResults();
  case 'weighted':
    return await getWeightedResults();
  // ...
}

// After: Registry lookup
const strategy = votingStrategyRegistry.getStrategy(votingSystem);
return strategy.calculateResults(proposalId, votes, config, eligibleVoters);
```

### 3. Directory Structure

```
src/lib/plugins/
├── index.ts
└── voting/
    ├── index.ts
    ├── voting-strategy.interface.ts
    ├── voting-strategy-registry.ts
    └── strategies/
        ├── index.ts
        ├── simple-voting.strategy.ts
        ├── ranked-voting.strategy.ts
        ├── weighted-voting.strategy.ts
        └── quadratic-voting.strategy.ts
```

## Consequences

### Positive

- **Open/Closed Principle**: Add new voting systems without modifying existing code
- **Single Responsibility**: Each strategy handles only its voting logic
- **Testability**: Strategies can be unit tested in isolation
- **Documentation**: Each strategy is self-documenting with name/description
- **Extensibility**: External contributors can add voting systems via plugins
- **Consistency**: All strategies implement the same interface

### Negative

- **Initial Complexity**: More files and abstractions than switch statements
- **Initialization**: Registry must be initialized before use
- **Learning Curve**: New developers must understand plugin pattern
- **Dynamic Loading**: Strategies are imported at runtime (minor performance impact)

## Alternatives Considered

### Alternative 1: Keep Switch Statements

- **Description**: Continue using switch statements in service methods
- **Reason not chosen**: Violates Open/Closed principle, makes testing harder, accumulates technical debt as voting systems grow

### Alternative 2: Factory Pattern Only

- **Description**: Use factories to create strategy instances without a registry
- **Reason not chosen**: No centralized management, harder to list available strategies, no runtime registration

### Alternative 3: Service Classes per Voting Type

- **Description**: Separate service classes like `SimpleVotingService`, `RankedVotingService`
- **Reason not chosen**: Duplicates base functionality, no common interface, harder to swap strategies

## Implementation Notes

### Registry Initialization

Initialize in app startup (e.g., `app/layout.tsx` or API route initialization):

```typescript
import { votingStrategyRegistry } from '@/lib/plugins/voting';

// Initialize once at startup
await votingStrategyRegistry.initialize();
```

### Adding a Custom Strategy

```typescript
import {
  BaseVotingStrategy,
  votingStrategyRegistry,
} from '@/lib/plugins/voting';

class ConvictionVotingStrategy extends BaseVotingStrategy {
  readonly id = 'conviction' as any; // Extend VotingSystem type
  readonly name = 'Conviction Voting';
  // ... implement methods
}

votingStrategyRegistry.register(new ConvictionVotingStrategy());
```

### Migration Path

1. ✅ Create plugin infrastructure
2. ✅ Implement core strategies (simple, ranked, weighted, quadratic)
3. ✅ Refactor `VotingEngineService.getVotingResultsBySystem` to use registry (hybrid mode)
4. ✅ Refactor `VoteCountingService.calculateVotingResults` to use registry
5. ✅ Add unit tests for each strategy (38 tests in `voting-strategies.test.ts`)
6. ✅ Hybrid approach preserves DB-aggregated results for performance

---

## Principle Alignment

| Aspect                 | Principle Addressed           |
| ---------------------- | ----------------------------- |
| Plugin architecture    | #5 Core + Plugin Model        |
| Strategy interface     | #6 Small, powerful interfaces |
| Isolated strategies    | #5 Isolation of Development   |
| Self-contained modules | #1 Small, independent modules |
| Registry abstraction   | #3 Helper Libraries           |
