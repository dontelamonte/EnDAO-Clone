# ADR 003: Safe SDK Adapter Pattern

## Status

Accepted

## Date

2025-12-16

## Context

EnDAO uses Gnosis Safe Protocol Kit v4 for multi-signature treasury management. The Safe SDK provides critical functionality:

1. **Safe Deployment**: Creating new multi-sig wallets for DAOs
2. **Transaction Management**: Creating and signing treasury transactions
3. **Safe Queries**: Getting owners, threshold, and nonce information

However, direct Safe SDK usage creates challenges:

1. **Version Lock-in**: Safe Protocol Kit v4 is required for ethers.js v6 compatibility
2. **Complex API**: Safe SDK has a large surface area, but EnDAO only uses a small subset
3. **Testing Difficulty**: Mocking Safe SDK operations requires complex setup
4. **Future Migration**: Safe SDK updates could break existing integrations

### Current Usage Pattern

```typescript
// Treasury service directly uses Safe SDK
import Safe from '@safe-global/protocol-kit';

const safe = await Safe.create({
  /* config */
});
const transaction = await safe.createTransaction(txData);
const txHash = await safe.getTransactionHash(transaction);
```

## Decision

We will create a **SafeAdapter** interface that abstracts Safe Protocol Kit operations used in EnDAO. The initial implementation (`SafeV4Adapter`) will wrap Safe Protocol Kit v4 APIs.

### Adapter Interface

```typescript
export interface SafeAdapter {
  // Deployment
  deploySafe(config: SafeDeploymentConfig, chainId): Promise<string>;
  predictSafeAddress(config: SafeDeploymentConfig, chainId): Promise<string>;

  // Transaction management
  createTransaction(
    safeAddress,
    txData,
    chainId
  ): Promise<{ safeTxHash; transaction }>;
  getTransactionHash(safeAddress, transaction): Promise<string>;

  // Query
  getSafeInfo(safeAddress, chainId): Promise<SafeInfo>;
  getOwners(safeAddress, chainId): Promise<string[]>;
}
```

### Implementation Strategy

1. **Skeleton First**: Create interface and adapter structure with TODO markers
2. **Gradual Implementation**: Implement methods as treasury features are refactored
3. **Singleton Pattern**: Single adapter instance via `getSafeAdapter()`
4. **Error Wrapping**: All SDK errors wrapped in `AdapterError`

### Normalized Interfaces

```typescript
export interface SafeDeploymentConfig {
  owners: string[];
  threshold: number;
  saltNonce?: string;
}

export interface SafeInfo {
  address: string;
  owners: string[];
  threshold: number;
  nonce: number;
}
```

## Consequences

### Positive

1. **Isolation**: Treasury logic decoupled from Safe SDK implementation details
2. **Simplified API**: Exposes only operations EnDAO needs
3. **Testability**: Easy to create mock Safe adapters for unit tests
4. **Version Flexibility**: Future Safe SDK updates isolated to adapter
5. **Clear Contract**: Documents exactly what Safe operations are supported

### Negative

1. **Implementation Complexity**: Safe SDK integration is non-trivial
2. **Partial Implementation**: Some methods marked TODO initially
3. **Abstraction Overhead**: Additional layer adds slight complexity
4. **Learning Curve**: Developers must understand adapter pattern

### Migration Path

1. **Phase 1**: Create adapter structure with TODO implementations (non-breaking)
2. **Phase 2**: Implement core methods (deploySafe, createTransaction)
3. **Phase 3**: Migrate treasury services to use adapter
4. **Phase 4**: Complete remaining adapter methods as needed

## Alternatives Considered

### Alternative 1: Direct Safe SDK Usage (Status Quo)

- **Rejected**: Tight coupling, difficult testing, version lock-in
- **Trade-off**: Simpler initially vs. long-term maintainability

### Alternative 2: Full Treasury Abstraction

- **Rejected**: Over-engineering, abstracts beyond Safe to generic "treasury"
- **Trade-off**: Complete flexibility vs. unnecessary complexity

### Alternative 3: Service Layer Only

- **Rejected**: Doesn't solve SDK coupling or testing issues
- **Trade-off**: Less abstraction vs. poor isolation

## References

- Safe Protocol Kit v4: https://docs.safe.global/sdk/protocol-kit
- EnDAO Treasury Architecture: docs/architecture/treasury-protection.md
- Related: ADR-001 (Hybrid Voting), ADR-002 (Ethers Adapter)

## Notes

### Implementation Priority

High priority methods (implement first):

1. `createTransaction` - Core treasury functionality
2. `getTransactionHash` - Transaction tracking
3. `getSafeInfo` - Query existing Safes

Lower priority methods (implement later): 4. `deploySafe` - DAO creation (less frequent) 5. `predictSafeAddress` - Pre-deployment preview

### Safe SDK Complexity

The Safe SDK is complex because it supports:

- Multiple chains
- Different Safe versions
- Various provider types
- Transaction batching
- Signature collection

The adapter hides this complexity and exposes a simple interface focused on EnDAO's specific needs.

### Testing Strategy

Mock adapter for unit tests:

```typescript
const mockSafeAdapter: SafeAdapter = {
  deploySafe: jest.fn().mockResolvedValue('0x123...'),
  createTransaction: jest
    .fn()
    .mockResolvedValue({ safeTxHash: '0xabc...', transaction: {} }),
  // ...
};
```
