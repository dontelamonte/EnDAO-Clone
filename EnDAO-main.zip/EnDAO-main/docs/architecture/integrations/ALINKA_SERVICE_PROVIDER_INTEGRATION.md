# Alinka as Service Provider for EnDAO DAOs

## Executive Summary

This document details how Alinka (Village Micro Fund's entrepreneurship platform) can serve as a service provider or white-label provider for DAOs within EnDAO. The platforms remain separate entities with distinct user bases, but DAOs can leverage Alinka's ecosystem of service providers, educators, mentors, and loan products.

**Key Design Principle**: Access works at TWO levels:
1. **DAO Level** - Organizations use Alinka services (treasury-funded, governance-approved)
2. **Individual Level** - DAO members access Alinka services personally, with membership benefits

DAO membership acts as a **credential** that unlocks benefits: discounts, pre-approval for loans, priority access, and community rates.

---

## Integration Model Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              EnDAO Platform                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────────────────┐  │
│  │     DAO A    │    │    DAO B     │    │           DAO C              │  │
│  │  (Treasury)  │    │  (Treasury)  │    │         (Treasury)           │  │
│  └──────┬───────┘    └──────┬───────┘    └────────────┬─────────────────┘  │
│         │                   │                         │                     │
│         └───────────────────┼─────────────────────────┘                     │
│                             │                                               │
│                  ┌──────────▼──────────┐                                    │
│                  │  Integration Layer   │                                    │
│                  │  (API Gateway)       │                                    │
│                  └──────────┬──────────┘                                    │
└─────────────────────────────┼───────────────────────────────────────────────┘
                              │
                    ┌─────────▼─────────┐
                    │   Alinka Partner  │
                    │       API         │
                    └─────────┬─────────┘
                              │
┌─────────────────────────────┼───────────────────────────────────────────────┐
│                             │          Alinka Platform                       │
│         ┌───────────────────┼───────────────────────────────┐               │
│         │                   │                               │               │
│  ┌──────▼──────┐    ┌──────▼──────┐    ┌──────▼──────┐    ┌▼─────────────┐ │
│  │  Services   │    │   Courses   │    │   Mentors   │    │    Loans     │ │
│  │ Marketplace │    │  (Learning) │    │  (Experts)  │    │  (Finance)   │ │
│  └─────────────┘    └─────────────┘    └─────────────┘    └──────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Dual-Level Access Model

### The Two Access Levels

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                  EnDAO                                           │
│                                                                                  │
│   ┌────────────────────────────────────────────────────────────────────────┐    │
│   │                           DAO (Organization)                            │    │
│   │                                                                         │    │
│   │   Treasury ────────────────────────────────┐                           │    │
│   │                                            │                           │    │
│   │   ┌─────────┐  ┌─────────┐  ┌─────────┐   │   DAO-LEVEL ACCESS        │    │
│   │   │ Member  │  │ Member  │  │ Member  │   │   • Bounties              │    │
│   │   │  Alice  │  │   Bob   │  │ Charlie │   │   • Bulk education        │    │
│   │   └────┬────┘  └────┬────┘  └────┬────┘   │   • DAO loans             │    │
│   │        │            │            │        │   • Group mentorship      │    │
│   └────────┼────────────┼────────────┼────────┼─────────────────────────────┘    │
│            │            │            │        │                                  │
│            │            │            │        │                                  │
│            ▼            ▼            ▼        ▼                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    INDIVIDUAL-LEVEL ACCESS                               │   │
│   │                    (with DAO membership benefits)                        │   │
│   │                                                                          │   │
│   │   • Personal courses (10-20% member discount)                           │   │
│   │   • Individual loans (DAO membership = credit boost)                    │   │
│   │   • 1:1 mentoring (member rates)                                        │   │
│   │   • Service purchases (community pricing)                               │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              Alinka Platform                                     │
│                                                                                  │
│   Recognizes EnDAO users with:                                                  │
│   • Verified DAO membership status                                              │
│   • DAO tier/reputation (affects discount level)                                │
│   • Individual reputation within DAO                                            │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Access Level Comparison

| Aspect | DAO-Level | Individual-Level |
|--------|-----------|------------------|
| **Who pays** | DAO Treasury | Individual (own wallet) |
| **Governance** | Requires proposal/vote | No governance needed |
| **Benefits** | Bulk discounts, custom terms | Member discount, priority access |
| **Use cases** | Bounties, grants, org loans | Personal development, side projects |
| **Approval** | DAO admin/vote | Self-service |

### DAO Membership as a Credential

When an EnDAO user accesses Alinka, their **membership status** travels with them:

```typescript
interface DAOMembershipCredential {
  // Identity
  userId: string;
  walletAddress: string;

  // DAO Memberships (user can be in multiple DAOs)
  memberships: {
    daoId: string;
    daoName: string;
    role: 'member' | 'admin' | 'owner';
    joinedAt: string;
    isActive: boolean;

    // DAO reputation (affects benefits)
    daoTier: 'starter' | 'growing' | 'established' | 'enterprise';
    daoMemberCount: number;
    daoTreasuryValue?: number;  // Optional, for loan pre-qualification
  }[];

  // Individual reputation
  proposalsCreated: number;
  proposalsCompleted: number;
  bountiesCompleted: number;
  reputation: number;  // 0-100 score
}
```

**Benefits Scale with DAO Tier**:

| DAO Tier | Member Count | Course Discount | Loan Rate Reduction | Priority Support |
|----------|--------------|-----------------|---------------------|------------------|
| Starter | 1-10 | 5% | - | - |
| Growing | 11-50 | 10% | 0.5% | Email |
| Established | 51-200 | 15% | 1.0% | Chat |
| Enterprise | 200+ | 20% | 1.5% | Dedicated |

---

## Use Cases by Access Level

### DAO-Level Use Cases

These require treasury funding and/or governance approval:

| Use Case | Description | Governance |
|----------|-------------|------------|
| **Bounties** | DAO posts work for Alinka providers | Proposal vote |
| **Bulk Education** | Fund courses for N members | Proposal vote |
| **DAO Loans** | Organization borrows for operations | Proposal vote |
| **Group Mentorship** | Sponsor cohort mentoring sessions | Admin approval |
| **Service Contracts** | Hire Alinka providers for DAO projects | Proposal vote |

### Individual-Level Use Cases

These are self-service, funded by the individual:

| Use Case | Description | DAO Benefit |
|----------|-------------|-------------|
| **Personal Courses** | Member buys course for themselves | Member discount (5-20%) |
| **Individual Loans** | Member applies for personal loan | Credit boost from membership |
| **1:1 Mentoring** | Member books mentor session | Member rate |
| **Service Purchases** | Member hires provider for side project | Community pricing |
| **Loan Co-Signing** | DAO vouches for member's loan | Lower rates, higher limits |

---

## Individual Access: Detailed Flows

### Individual Course Purchase (with DAO Member Discount)

```
┌──────────────────────────────────────────────────────────────────────────┐
│  Alice (DAO member) wants to take "Digital Marketing Masterclass"        │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  1. Alice browses courses on Alinka (or via EnDAO integration)           │
│     - Course price: $79                                                  │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  2. Alice clicks "Enroll" - Alinka checks her EnDAO membership           │
│     - API call: GET /partner/endao/verify-membership                     │
│     - Response: { daoTier: 'established', discount: 15% }                │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  3. Alinka shows discounted price                                        │
│     - Original: $79                                                      │
│     - DAO Member Discount (15%): -$11.85                                 │
│     - Final Price: $67.15                                                │
│     - Badge: "EnDAO Member - Established Tier"                           │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  4. Alice pays with her own wallet/card (NOT DAO treasury)               │
│     - Payment goes to Alinka                                             │
│     - Alice enrolled in course                                           │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  5. Optional: Progress visible in EnDAO (if Alice opts in)               │
│     - DAO can see aggregate: "12 members taking courses"                 │
│     - Individual progress private unless shared                          │
└──────────────────────────────────────────────────────────────────────────┘
```

### Individual Loan Application (with DAO Membership Credit Boost)

```
┌──────────────────────────────────────────────────────────────────────────┐
│  Bob (DAO member) needs $2,000 loan for equipment                        │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  1. Bob starts loan application on Alinka                                │
│     - Personal info, business details, loan amount                       │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  2. Bob connects his EnDAO identity (wallet or OAuth)                    │
│     - Alinka verifies DAO membership                                     │
│     - Pulls: membership duration, role, reputation score                 │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  3. Alinka credit assessment includes DAO factors                        │
│                                                                          │
│     Traditional Factors:          DAO Membership Factors:                │
│     • Income/revenue              • Member for 8 months ✓                │
│     • Business history            • Admin role ✓                         │
│     • Existing debt               • 3 bounties completed ✓               │
│                                   • DAO tier: Established ✓              │
│                                   • Reputation score: 78/100             │
│                                                                          │
│     Result: "DAO Membership Credit Boost" applied                        │
│     • Base rate: 12% APR                                                 │
│     • With boost: 10.5% APR (-1.5%)                                      │
│     • Max loan increased: $2,000 → $3,000                                │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  4. Bob accepts loan terms, funds disbursed to his wallet                │
│     - Loan is Bob's personal obligation                                  │
│     - DAO is NOT liable (no co-signing in this flow)                     │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  5. Repayment tracked in Alinka, optional visibility in EnDAO            │
│     - Bob can show "loan in good standing" badge in DAO profile          │
│     - Default would affect his EnDAO reputation (if opted in)            │
└──────────────────────────────────────────────────────────────────────────┘
```

### DAO Co-Signed Loan (Individual Loan with DAO Backing)

For higher-trust scenarios, a DAO can formally back a member's loan:

```
┌──────────────────────────────────────────────────────────────────────────┐
│  Charlie needs $10,000 loan - too much for individual, asks DAO support  │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  1. Charlie creates "Loan Co-Sign Request" proposal in DAO               │
│     - Amount: $10,000                                                    │
│     - Purpose: Expand catering business                                  │
│     - DAO backing level: 50% guarantee ($5,000 max liability)            │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  2. DAO votes on co-sign request                                         │
│     - Reviews Charlie's history, business plan                           │
│     - Vote passes with 75% approval                                      │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  3. DAO treasury locks $5,000 as collateral                              │
│     - Funds held in escrow (not transferred to Alinka)                   │
│     - Released when loan repaid, or used if Charlie defaults             │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  4. Alinka sees DAO backing, offers better terms                         │
│     - Rate: 8% APR (vs 12% without backing)                              │
│     - Higher limit approved due to collateral                            │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  5. Charlie repays loan                                                  │
│     - Monthly payments to Alinka                                         │
│     - DAO treasury collateral released when paid off                     │
│     - If default: Alinka claims from DAO escrow (up to $5,000)           │
└──────────────────────────────────────────────────────────────────────────┘
```

### Individual Service Purchase (Member Pricing)

```
┌──────────────────────────────────────────────────────────────────────────┐
│  Alice needs logo design for her side project (not DAO business)         │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  1. Alice browses Alinka service marketplace                             │
│     - Finds "Brand Identity Design" service - $150                       │
│     - Provider: Jessica Williams (4.7★ rating)                           │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  2. Alice logs in with EnDAO identity                                    │
│     - Alinka verifies membership                                         │
│     - Shows "Community Member" badge on her profile                      │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  3. Member pricing applied                                               │
│     - Standard price: $150                                               │
│     - EnDAO member price: $135 (10% off)                                 │
│     - Provider sees Alice is verified DAO member (trust signal)          │
└──────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  4. Transaction completed                                                │
│     - Alice pays from personal wallet                                    │
│     - Service delivered                                                  │
│     - Alice can leave review (visible in both platforms)                 │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## DAO-Level Use Cases (Original)

### 1. Bounty Fulfillment by Alinka Service Providers

**Scenario**: A DAO posts a bounty for "Design a logo for our community project - $200"

**Flow**:
```
1. DAO Admin creates bounty proposal in EnDAO
   ├── Bounty details: requirements, reward, deadline
   └── Optional: Tag as "Alinka-eligible"

2. Bounty passes DAO governance vote → status: "live"

3. EnDAO notifies Alinka Partner API of new bounty
   └── POST /partner/endao/bounties/sync

4. Alinka displays bounty to qualified service providers
   └── Filtered by: skills match, availability, ratings

5. Alinka provider applies through Alinka
   └── Application synced back to EnDAO

6. DAO admin selects provider (in EnDAO UI)
   └── Provider notified in both platforms

7. Provider completes work, submits in Alinka
   └── Submission synced to EnDAO

8. DAO admin approves in EnDAO
   └── Treasury payout triggered

9. Funds flow: DAO Treasury → Alinka Provider Wallet
   └── Via crypto (direct) or Stripe Connect (fiat)
```

### 2. DAO-Funded Education Programs

**Scenario**: A DAO wants to provide business training to members via Alinka courses

**Flow**:
```
1. DAO admin browses Alinka course catalog (embedded or linked)

2. Creates "Education Grant" proposal
   ├── Course: "Business Fundamentals" by Dr. Sarah Johnson
   ├── Budget: $500 (covers 10 member enrollments)
   └── Eligibility: Active DAO members

3. Proposal passes → DAO purchases course credits via API
   └── POST /partner/endao/courses/{courseId}/bulk-enroll

4. DAO members claim enrollment vouchers
   └── Voucher creates Alinka account (if new)
   └── Links to EnDAO identity

5. Members complete course on Alinka platform

6. Progress/completion synced to EnDAO
   └── Optional: Issue on-chain credential/badge
```

### 3. DAO Organization Loan (DAO Borrows from Alinka)

**Scenario**: A DAO needs capital for operations, expansion, or projects

**Flow**:
```
1. DAO admin creates "Organization Loan Request" proposal
   ├── Amount: $25,000
   ├── Purpose: "Launch community co-working space"
   ├── Repayment: From treasury (membership dues, revenue)
   └── Collateral: DAO treasury balance as backing

2. Proposal goes through DAO governance vote
   ├── Members review business plan
   ├── Vote passes with required threshold
   └── Proposal status: approved

3. EnDAO submits loan application to Alinka
   ├── POST /partner/endao/dao-loans/apply
   ├── Includes: DAO financials, treasury balance, member count
   └── Alinka receives application

4. Alinka performs organizational credit assessment
   ├── Treasury history and balance
   ├── Revenue streams (if any)
   ├── Member engagement metrics
   ├── DAO tier and reputation
   └── EnDAO partnership standing

5. Alinka approves with terms
   ├── Amount: $25,000
   ├── Rate: 9% APR (reduced from 12% for established DAO)
   ├── Term: 24 months
   └── Monthly payment: $1,140

6. DAO governance confirms terms (second vote if needed)
   └── Treasury signs acceptance

7. Funds disbursed to DAO treasury
   ├── Direct to Safe multi-sig address
   └── Transaction recorded in both platforms

8. Automated repayment tracking
   ├── Monthly payment reminders
   ├── Treasury can set up recurring payments
   └── Repayment status visible in DAO dashboard

9. Loan completion
   └── Full repayment releases any locked collateral
```

### 4. DAO-Backed Member Microloans

**Scenario**: A DAO creates a loan fund to back member businesses

**Flow**:
```
1. DAO creates "Community Loan Fund" with treasury allocation
   └── $10,000 pool for member microloans

2. DAO member applies for loan
   └── Application in EnDAO → forwarded to Alinka

3. Alinka performs credit assessment
   └── Business metrics, history, etc.

4. Loan approved/rejected notification
   └── If approved: terms, interest rate, repayment schedule

5. DAO governance votes to fund specific loan
   └── Proposal: "Fund $1,000 loan for Member X"

6. Treasury → Member's Alinka wallet

7. Repayments tracked in Alinka
   └── Principal + interest return to DAO treasury
```

### 4. Mentorship Programs

**Scenario**: DAO sponsors mentor sessions for members

**Flow**:
```
1. DAO allocates mentorship budget
   └── E.g., 20 hours of mentoring @ $50/hr = $1,000

2. Members browse Alinka mentors (filtered by specialty)

3. Member books session → deducted from DAO budget

4. Session conducted via Alinka

5. Usage tracked and reported to DAO
```

---

## Technical Architecture

### A. Identity Linking (Critical)

Users need linked identities across both platforms without requiring dual accounts.

**Option 1: Wallet-Based Identity (Recommended)**
```typescript
// Both platforms support crypto wallets
// User connects same wallet to both platforms

// EnDAO side (Privy)
interface EnDAOUser {
  id: string;
  privyId: string;
  walletAddress: string;  // 0x...
}

// Alinka side
interface AlinkaUser {
  id: string;
  firebaseUid: string;
  cryptoWalletAddress: string;  // Same 0x...
}

// Linking query
SELECT e.*, a.*
FROM endao_users e
JOIN alinka_users a ON LOWER(e.wallet_address) = LOWER(a.crypto_wallet_address)
WHERE e.wallet_address = '0x...'
```

**Option 2: OAuth Bridge**
```typescript
// Alinka becomes OAuth provider for EnDAO
// User authorizes EnDAO to access Alinka identity

// EnDAO stores link
interface PartnerLink {
  endaoUserId: string;
  provider: 'alinka';
  externalUserId: string;  // Alinka user ID
  linkedAt: string;
  scopes: string[];        // What EnDAO can access
}
```

**Option 3: Email Matching (Fallback)**
```typescript
// Match users by verified email
// Less secure, but simpler for non-crypto users
```

### B. Partner API Design (Alinka Side)

Alinka exposes a Partner API for EnDAO integration at two levels:

#### Membership Verification API (Individual Access)

```typescript
// ============================================
// MEMBERSHIP VERIFICATION (for individual access)
// ============================================

// Verify user's DAO membership and get benefits
// Called when Alinka user connects EnDAO identity
POST /partner/endao/verify-membership
{
  walletAddress: string;         // User's wallet (primary identifier)
  // OR
  endaoUserId: string;           // EnDAO user ID (if OAuth flow)
}
Response: {
  verified: boolean;
  user: {
    endaoUserId: string;
    walletAddress: string;
    displayName: string;
  };
  memberships: [{
    daoId: string;
    daoName: string;
    daoSlug: string;
    role: 'member' | 'admin' | 'owner';
    joinedAt: string;
    isActive: boolean;

    // DAO tier determines benefits
    daoTier: 'starter' | 'growing' | 'established' | 'enterprise';
    daoMemberCount: number;
  }];

  // Aggregated benefits (highest from all memberships)
  benefits: {
    courseDiscount: number;        // Percentage (5-20)
    serviceDiscount: number;       // Percentage (5-15)
    loanRateReduction: number;     // Percentage points (0-1.5)
    loanLimitMultiplier: number;   // 1.0 - 1.5
    prioritySupport: boolean;
    tier: 'starter' | 'growing' | 'established' | 'enterprise';
  };

  // Individual reputation
  reputation: {
    score: number;                  // 0-100
    bountiesCompleted: number;
    proposalsCreated: number;
    memberSince: string;
  };
}

// Get real-time membership status (for checkout verification)
GET /partner/endao/verify-membership?wallet={address}
Response: { verified: boolean, tier: string, discount: number }

// ============================================
// DAO CO-SIGN / BACKING VERIFICATION
// ============================================

// Check if DAO has approved backing for a member's loan
GET /partner/endao/loan-backing/{endaoUserId}
Query: { daoId?: string, amount: number }
Response: {
  backings: [{
    daoId: string;
    daoName: string;
    proposalId: string;
    maxBackingAmount: number;
    backingPercentage: number;      // e.g., 50% guarantee
    escrowStatus: 'locked' | 'pending' | 'released';
    expiresAt: string;
  }]
}

// Notify EnDAO that backing was used (loan funded)
POST /partner/endao/loan-backing/{proposalId}/activate
{
  loanId: string;                   // Alinka loan ID
  amount: number;
  backingUsed: number;
}

// Notify EnDAO of loan repayment (release escrow)
POST /partner/endao/loan-backing/{proposalId}/release
{
  loanId: string;
  status: 'repaid' | 'defaulted';
  defaultAmount?: number;           // If defaulted, how much to claim
}
```

#### DAO-Level Partner API (Organization Access)

```typescript
// Base URL: https://api.alinka.com/partner/v1

// Authentication
Headers: {
  'X-Partner-ID': 'endao',
  'X-Partner-Secret': 'xxx',
  'X-Request-Signature': 'HMAC-SHA256(...)'
}

// ============================================
// BOUNTIES / SERVICES
// ============================================

// Sync bounty from EnDAO to Alinka
POST /bounties
{
  externalId: string;          // EnDAO proposal ID
  daoId: string;
  daoName: string;
  title: string;
  description: string;
  requirements: string;
  deliverables: string[];
  skills: string[];
  reward: {
    amount: number;
    currency: 'USD' | 'USDC' | 'ETH';
  };
  deadline: string;            // ISO 8601
  eligibility: 'public' | 'dao_members_only';
}
Response: { alinkaProjectId: string }

// Get applications from Alinka providers
GET /bounties/{alinkaProjectId}/applications
Response: {
  applications: [{
    id: string;
    providerId: string;
    providerName: string;
    providerRating: number;
    portfolioUrl: string;
    message: string;
    appliedAt: string;
  }]
}

// Notify Alinka of provider selection
POST /bounties/{alinkaProjectId}/select
{ applicationId: string }

// Submit work completion
POST /bounties/{alinkaProjectId}/submit
{
  submissionUrl: string;
  notes: string;
}

// Notify Alinka of approval/rejection
POST /bounties/{alinkaProjectId}/review
{
  approved: boolean;
  notes: string;
}

// Confirm payout
POST /bounties/{alinkaProjectId}/payout
{
  txHash: string;
  amount: number;
  currency: string;
}

// ============================================
// COURSES / EDUCATION
// ============================================

// List available courses
GET /courses
Query: { category?, level?, search? }
Response: {
  courses: [{
    id: string;
    title: string;
    description: string;
    instructor: string;
    price: number;
    rating: number;
    level: 'Beginner' | 'Intermediate' | 'Advanced';
    duration: string;
  }]
}

// Get course details
GET /courses/{courseId}

// Bulk enroll DAO members
POST /courses/{courseId}/bulk-enroll
{
  daoId: string;
  enrollments: [{
    externalUserId: string;     // EnDAO user ID
    email: string;              // For account creation if needed
    walletAddress?: string;     // For identity linking
  }];
  paymentMethod: 'crypto' | 'invoice';
  paymentDetails: { /* varies */ };
}
Response: {
  enrollmentVouchers: [{
    externalUserId: string;
    voucherCode: string;
    redeemUrl: string;
    expiresAt: string;
  }]
}

// Get enrollment progress (webhook or poll)
GET /enrollments?daoId={daoId}
Response: {
  enrollments: [{
    externalUserId: string;
    courseId: string;
    progress: number;           // 0-100
    status: 'active' | 'completed' | 'dropped';
    completedAt?: string;
  }]
}

// ============================================
// MENTORS
// ============================================

// List mentors
GET /mentors
Query: { specialty?, languages?, isFeatured? }
Response: {
  mentors: [{
    id: string;
    name: string;
    specialty: string;
    hourlyRate: number;
    rating: number;
    expertise: string[];
    languages: string[];
  }]
}

// Book session
POST /mentors/{mentorId}/book
{
  daoId: string;
  memberId: string;
  duration: number;              // hours
  scheduledAt: string;           // ISO 8601
  paymentSource: 'dao_treasury' | 'member_wallet';
}

// ============================================
// LOANS: DAO Organization Loans (DAO borrows from Alinka)
// ============================================

// DAO applies for organizational loan
POST /dao-loans/apply
{
  daoId: string;
  daoName: string;
  proposalId: string;              // EnDAO proposal that approved this
  amount: number;
  purpose: string;
  term: string;                    // e.g., "24 months"

  // DAO financial info
  daoFinancials: {
    treasuryBalance: number;
    treasuryAddress: string;
    memberCount: number;
    monthlyRevenue?: number;       // If applicable
    existingObligations?: number;
  };

  // Repayment plan
  repaymentSource: string;         // e.g., "membership dues", "service revenue"

  // Contact
  contactUserId: string;
  contactEmail: string;
}
Response: {
  applicationId: string;
  status: 'pending';
  estimatedReviewTime: string;
}

// Get DAO loan status
GET /dao-loans/{applicationId}
Response: {
  applicationId: string;
  daoId: string;
  status: 'pending' | 'approved' | 'rejected' | 'active' | 'completed';
  terms?: {
    approvedAmount: number;
    interestRate: number;
    termMonths: number;
    monthlyPayment: number;
  };
  disbursement?: {
    txHash: string;
    disbursedAt: string;
  };
  repayment?: {
    totalRepaid: number;
    remainingBalance: number;
    nextPaymentDue: string;
    paymentsMade: number;
    paymentsRemaining: number;
  };
}

// Accept loan terms (after Alinka approval)
POST /dao-loans/{applicationId}/accept
{
  treasurySignature: string;       // Multi-sig approval from DAO treasury
  disbursementAddress: string;     // Treasury Safe address
}

// Make loan repayment
POST /dao-loans/{applicationId}/repay
{
  amount: number;
  txHash: string;                  // Crypto payment tx hash
}

// ============================================
// LOANS: Member Loans (backed by DAO or individual)
// ============================================

// Submit member loan application (individual or DAO-backed)
POST /member-loans/apply
{
  // Applicant info
  applicantId: string;             // EnDAO user ID
  applicantEmail: string;
  applicantWallet: string;

  // Loan details
  loanType: string;
  amount: number;
  term: string;
  purpose: string;

  // Business info
  businessInfo: {
    name: string;
    description: string;
    revenue?: number;
    employees?: number;
  };

  // DAO backing (optional - for co-signed loans)
  daoBacking?: {
    daoId: string;
    proposalId: string;            // Proposal that approved backing
    maxBackingAmount: number;
    backingPercentage: number;     // e.g., 50
  };
}
Response: {
  applicationId: string;
  status: 'pending';
  hasDAOBacking: boolean;
  membershipBenefits: {
    rateReduction: number;
    creditBoost: boolean;
  };
}

// Get member loan status
GET /member-loans/{applicationId}

// ============================================
// LOAN WEBHOOKS (Alinka → EnDAO)
// ============================================

// Configured in partner settings, sent to EnDAO webhook endpoint

// Loan status changed
{
  event: 'loan.status.changed',
  loanType: 'dao' | 'member',
  data: {
    applicationId: string;
    daoId?: string;
    applicantId?: string;
    previousStatus: string;
    newStatus: string;
    terms?: { /* if approved */ };
  }
}

// Repayment received
{
  event: 'loan.repayment.received',
  data: {
    applicationId: string;
    loanType: 'dao' | 'member';
    amount: number;
    remainingBalance: number;
    isFullyRepaid: boolean;
  }
}

// Default notice (triggers escrow claim for backed loans)
{
  event: 'loan.default.notice',
  data: {
    applicationId: string;
    loanType: 'dao' | 'member';
    defaultAmount: number;
    daoBackingClaim?: {
      daoId: string;
      proposalId: string;
      claimAmount: number;
    };
  }
}
```

### C. EnDAO Integration Layer

New components needed in EnDAO:

```
src/lib/services/integrations/alinka/
├── index.ts                    # AlinkaIntegrationService
├── alinka-client.ts            # HTTP client for Partner API
├── alinka-bounty.service.ts    # Bounty sync logic
├── alinka-education.service.ts # Course enrollment logic
├── alinka-lending.service.ts   # Loan coordination
└── alinka-identity.service.ts  # User identity linking

src/app/api/webhooks/alinka/
├── route.ts                    # Webhook receiver
├── bounty-events.ts            # Handle bounty updates
├── enrollment-events.ts        # Handle course progress
└── loan-events.ts              # Handle loan events
```

**AlinkaIntegrationService Interface**:
```typescript
export class AlinkaIntegrationService extends BaseService {
  // Configuration
  async isEnabledForDAO(daoId: string): Promise<boolean>;
  async configureIntegration(daoId: string, config: AlinkaConfig): Promise<void>;

  // Bounties
  async syncBountyToAlinka(proposalId: string): Promise<string>; // Returns alinkaProjectId
  async getAlinkaApplications(proposalId: string): Promise<AlinkaApplication[]>;
  async notifyProviderSelection(proposalId: string, applicationId: string): Promise<void>;
  async notifyBountyApproval(proposalId: string, approved: boolean): Promise<void>;
  async notifyPayout(proposalId: string, txHash: string): Promise<void>;

  // Education
  async listCourses(filters?: CourseFilters): Promise<AlinkaCourse[]>;
  async enrollDAOMembers(courseId: string, memberIds: string[]): Promise<EnrollmentVoucher[]>;
  async getMemberProgress(daoId: string): Promise<EnrollmentProgress[]>;

  // Mentorship
  async listMentors(filters?: MentorFilters): Promise<AlinkaMentor[]>;
  async bookSession(mentorId: string, memberId: string, details: SessionDetails): Promise<Booking>;

  // Loans
  async submitLoanApplication(application: LoanApplication): Promise<string>;
  async getLoanStatus(applicationId: string): Promise<LoanStatus>;
  async fundLoan(applicationId: string, txHash: string): Promise<void>;

  // Identity
  async linkUserIdentity(endaoUserId: string, alinkaUserId: string): Promise<void>;
  async findLinkedUser(endaoUserId: string): Promise<AlinkaUser | null>;
}
```

### D. Webhook Events (Alinka → EnDAO)

```typescript
// POST /api/webhooks/alinka
// Headers: X-Alinka-Signature: HMAC-SHA256(payload, secret)

// Bounty application received
{
  event: 'bounty.application.received',
  data: {
    externalBountyId: string;      // EnDAO proposal ID
    alinkaProjectId: string;
    application: {
      id: string;
      providerId: string;
      providerName: string;
      providerRating: number;
      message: string;
      portfolioUrl?: string;
    }
  }
}

// Work submitted
{
  event: 'bounty.work.submitted',
  data: {
    externalBountyId: string;
    submissionUrl: string;
    submissionNotes: string;
    submittedAt: string;
  }
}

// Course enrollment progress
{
  event: 'course.progress.updated',
  data: {
    daoId: string;
    externalUserId: string;
    courseId: string;
    progress: number;
    status: 'active' | 'completed';
  }
}

// Loan status changed
{
  event: 'loan.status.changed',
  data: {
    applicationId: string;
    daoId: string;
    applicantId: string;
    status: 'approved' | 'rejected' | 'active' | 'completed';
    details: { /* varies by status */ }
  }
}

// Loan repayment received
{
  event: 'loan.repayment.received',
  data: {
    applicationId: string;
    daoId: string;
    amount: number;
    currency: string;
    remainingBalance: number;
    repaymentMethod: 'crypto' | 'fiat';
    txHash?: string;
  }
}
```

---

## Database Schema Changes

### EnDAO Side

```sql
-- Migration: 092_alinka_integration.sql

-- ============================================
-- INDIVIDUAL-LEVEL: Member benefit tracking
-- ============================================

-- Track when users verify their EnDAO identity on Alinka
CREATE TABLE alinka_member_verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wallet_address TEXT NOT NULL,
  alinka_user_id TEXT,                    -- Alinka's user ID (if known)
  verified_at TIMESTAMPTZ DEFAULT NOW(),
  last_verified_at TIMESTAMPTZ DEFAULT NOW(),
  verification_count INTEGER DEFAULT 1,
  -- Cached tier for quick lookups
  current_tier TEXT DEFAULT 'starter',
  current_discount_percent NUMERIC(4,2) DEFAULT 5.00,
  metadata JSONB DEFAULT '{}',
  UNIQUE(user_id)
);

-- Track individual purchases made with DAO member benefits
CREATE TABLE alinka_member_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  purchase_type TEXT NOT NULL CHECK (purchase_type IN ('course', 'service', 'mentoring', 'loan')),
  alinka_item_id TEXT NOT NULL,           -- Course ID, service ID, etc.
  alinka_transaction_id TEXT,             -- Alinka's transaction reference
  original_price NUMERIC(10,2),
  discount_applied NUMERIC(10,2),
  final_price NUMERIC(10,2),
  discount_tier TEXT,                     -- Which tier discount was applied
  dao_id UUID REFERENCES daos(id),        -- Which DAO membership provided the discount
  purchased_at TIMESTAMPTZ DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

-- ============================================
-- DAO-LEVEL: Loan co-signing and backing
-- ============================================

-- Track DAO-backed loans for members
CREATE TABLE dao_loan_backings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID NOT NULL REFERENCES daos(id),
  beneficiary_user_id UUID NOT NULL REFERENCES users(id),
  proposal_id UUID NOT NULL REFERENCES proposals(id),

  -- Backing terms (from approved proposal)
  max_backing_amount NUMERIC(12,2) NOT NULL,
  backing_percentage NUMERIC(5,2) NOT NULL,  -- e.g., 50.00 = 50% guarantee

  -- Escrow tracking
  escrow_amount NUMERIC(12,2),
  escrow_status TEXT DEFAULT 'pending' CHECK (escrow_status IN ('pending', 'locked', 'released', 'claimed')),
  escrow_locked_at TIMESTAMPTZ,
  escrow_tx_hash TEXT,

  -- Linked Alinka loan
  alinka_loan_id TEXT,
  loan_amount NUMERIC(12,2),
  loan_status TEXT DEFAULT 'pending',

  -- Resolution
  resolved_at TIMESTAMPTZ,
  resolution_type TEXT CHECK (resolution_type IN ('repaid', 'defaulted_partial', 'defaulted_full', 'cancelled')),
  claimed_amount NUMERIC(12,2),

  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,                 -- Backing offer expiration

  UNIQUE(proposal_id)
);

-- ============================================
-- DAO-LEVEL: Organization loans FROM Alinka
-- ============================================

-- Track loans taken by DAOs themselves (not members)
CREATE TABLE dao_organization_loans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID NOT NULL REFERENCES daos(id),
  proposal_id UUID REFERENCES proposals(id),    -- Governance proposal that approved it

  -- Application
  alinka_application_id TEXT UNIQUE,
  loan_type TEXT NOT NULL,
  requested_amount NUMERIC(12,2) NOT NULL,
  purpose TEXT,

  -- Terms (populated when approved)
  approved_amount NUMERIC(12,2),
  interest_rate NUMERIC(5,2),
  term_months INTEGER,
  monthly_payment NUMERIC(12,2),

  -- Status tracking
  status TEXT DEFAULT 'draft' CHECK (status IN (
    'draft',              -- Being prepared
    'pending_governance', -- Awaiting DAO vote
    'pending_alinka',     -- Submitted to Alinka
    'approved',           -- Alinka approved
    'rejected',           -- Alinka rejected
    'active',             -- Funds disbursed
    'repaying',           -- Making payments
    'completed',          -- Fully repaid
    'defaulted'           -- In default
  )),

  -- Disbursement
  disbursed_at TIMESTAMPTZ,
  disbursement_tx_hash TEXT,
  disbursement_address TEXT,              -- Treasury address that received funds

  -- Repayment tracking
  total_repaid NUMERIC(12,2) DEFAULT 0,
  next_payment_due TIMESTAMPTZ,
  payments_made INTEGER DEFAULT 0,
  payments_remaining INTEGER,

  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  metadata JSONB DEFAULT '{}'
);

-- ============================================
-- DAO-LEVEL: Existing tables (organization access)
-- ============================================

-- Partner integration configuration per DAO
CREATE TABLE partner_integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID NOT NULL REFERENCES daos(id) ON DELETE CASCADE,
  partner TEXT NOT NULL CHECK (partner IN ('alinka')),
  is_enabled BOOLEAN DEFAULT FALSE,
  config JSONB DEFAULT '{}',
  api_key_hash TEXT,               -- Hashed API key for this DAO
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(dao_id, partner)
);

-- User identity links
CREATE TABLE user_partner_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  partner TEXT NOT NULL CHECK (partner IN ('alinka')),
  external_user_id TEXT NOT NULL,
  linked_wallet_address TEXT,
  linked_at TIMESTAMPTZ DEFAULT NOW(),
  metadata JSONB DEFAULT '{}',
  UNIQUE(user_id, partner),
  UNIQUE(partner, external_user_id)
);

-- External bounty/project tracking
CREATE TABLE partner_bounty_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  proposal_id UUID NOT NULL REFERENCES proposals(id) ON DELETE CASCADE,
  partner TEXT NOT NULL CHECK (partner IN ('alinka')),
  external_project_id TEXT NOT NULL,
  sync_status TEXT DEFAULT 'synced',
  last_synced_at TIMESTAMPTZ DEFAULT NOW(),
  metadata JSONB DEFAULT '{}',
  UNIQUE(proposal_id, partner)
);

-- Course enrollments funded by DAOs
CREATE TABLE dao_course_enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID NOT NULL REFERENCES daos(id),
  user_id UUID NOT NULL REFERENCES users(id),
  partner TEXT NOT NULL CHECK (partner IN ('alinka')),
  external_course_id TEXT NOT NULL,
  voucher_code TEXT,
  enrollment_status TEXT DEFAULT 'pending',
  progress INTEGER DEFAULT 0,
  funding_proposal_id UUID REFERENCES proposals(id),
  enrolled_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Loan applications backed by DAO
CREATE TABLE dao_backed_loans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dao_id UUID NOT NULL REFERENCES daos(id),
  applicant_user_id UUID NOT NULL REFERENCES users(id),
  partner TEXT NOT NULL CHECK (partner IN ('alinka')),
  external_application_id TEXT NOT NULL,
  loan_amount NUMERIC(12,2),
  loan_currency TEXT DEFAULT 'USD',
  loan_status TEXT DEFAULT 'pending',
  funding_proposal_id UUID REFERENCES proposals(id),
  funded_at TIMESTAMPTZ,
  funding_tx_hash TEXT,
  repaid_amount NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(partner, external_application_id)
);

-- Indexes
CREATE INDEX idx_partner_integrations_dao ON partner_integrations(dao_id);
CREATE INDEX idx_user_partner_links_user ON user_partner_links(user_id);
CREATE INDEX idx_partner_bounty_links_proposal ON partner_bounty_links(proposal_id);
CREATE INDEX idx_dao_course_enrollments_dao ON dao_course_enrollments(dao_id);
CREATE INDEX idx_dao_backed_loans_dao ON dao_backed_loans(dao_id);

-- Enable RLS
ALTER TABLE partner_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_partner_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE partner_bounty_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE dao_course_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE dao_backed_loans ENABLE ROW LEVEL SECURITY;

-- RLS Policies (similar patterns to existing tables)
-- [policies omitted for brevity - follow existing patterns]
```

### Alinka Side

```sql
-- New table for partner/external projects

CREATE TABLE partner_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  partner TEXT NOT NULL CHECK (partner IN ('endao')),
  external_id TEXT NOT NULL,           -- EnDAO proposal ID
  partner_dao_id TEXT,                 -- EnDAO DAO ID
  partner_dao_name TEXT,

  -- Project details
  title TEXT NOT NULL,
  description TEXT,
  requirements TEXT,
  deliverables TEXT[],
  skills TEXT[],
  reward_amount NUMERIC(12,2),
  reward_currency TEXT DEFAULT 'USD',
  deadline TIMESTAMPTZ,

  -- Status tracking
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'claimed', 'submitted', 'completed', 'cancelled')),
  selected_provider_id UUID REFERENCES users(id),
  submission_url TEXT,
  submission_notes TEXT,
  completed_at TIMESTAMPTZ,

  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(partner, external_id)
);

CREATE TABLE partner_project_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES partner_projects(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  portfolio_url TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'selected', 'rejected')),
  applied_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(project_id, provider_id)
);

-- Index
CREATE INDEX idx_partner_projects_partner ON partner_projects(partner, external_id);
CREATE INDEX idx_partner_projects_status ON partner_projects(status);
```

---

## UI Components (EnDAO)

### DAO Admin: Partner Integration Settings

```typescript
// src/components/dao/settings/partner-integrations-tab.tsx

export function PartnerIntegrationsTab({ daoId }: { daoId: string }) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Partner Integrations</h3>
        <p className="text-sm text-muted-foreground">
          Connect your DAO to external service providers
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlinkaLogo className="h-8 w-8" />
              <div>
                <CardTitle>Alinka</CardTitle>
                <CardDescription>
                  Access service providers, courses, mentors, and loans
                </CardDescription>
              </div>
            </div>
            <Switch
              checked={isEnabled}
              onCheckedChange={handleToggle}
            />
          </div>
        </CardHeader>

        {isEnabled && (
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Bounty Marketplace</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Education Programs</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Mentorship Access</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm">Microloan Programs</span>
              </div>
            </div>

            <Separator />

            <Button variant="outline" asChild>
              <Link href={`/dao/${daoId}/settings/integrations/alinka`}>
                Configure Integration
              </Link>
            </Button>
          </CardContent>
        )}
      </Card>
    </div>
  );
}
```

### Bounty Creation with Alinka Option

```typescript
// In bounty creation form, add option to cross-post to Alinka

<FormField
  control={form.control}
  name="crossPostToAlinka"
  render={({ field }) => (
    <FormItem className="flex items-center justify-between rounded-lg border p-4">
      <div className="space-y-0.5">
        <FormLabel>Cross-post to Alinka</FormLabel>
        <FormDescription>
          Make this bounty visible to Alinka's network of service providers
        </FormDescription>
      </div>
      <FormControl>
        <Switch
          checked={field.value}
          onCheckedChange={field.onChange}
          disabled={!alinkaEnabled}
        />
      </FormControl>
    </FormItem>
  )}
/>
```

### Course Catalog Browser

```typescript
// src/components/dao/education/alinka-course-catalog.tsx

export function AlinkaCourseDialog({ daoId, onEnroll }) {
  const [courses, setCourses] = useState<AlinkaCourse[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<AlinkaCourse | null>(null);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button>
          <GraduationCap className="mr-2 h-4 w-4" />
          Browse Alinka Courses
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Alinka Course Catalog</DialogTitle>
          <DialogDescription>
            Fund courses for your DAO members
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {courses.map((course) => (
            <CourseCard
              key={course.id}
              course={course}
              onSelect={() => setSelectedCourse(course)}
            />
          ))}
        </div>

        {selectedCourse && (
          <EnrollmentForm
            course={selectedCourse}
            daoId={daoId}
            onEnroll={onEnroll}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
```

---

## White-Label Option

For DAOs that want a deeper integration, Alinka could offer white-label embedding:

### Option A: Embedded iFrame (Simple)

```typescript
// Alinka provides embeddable components
<iframe
  src={`https://embed.alinka.com/courses?partner=endao&dao=${daoId}&theme=dark`}
  className="w-full h-[600px] border-0 rounded-lg"
  allow="payment"
/>
```

### Option B: React Component Library (Advanced)

```typescript
// Alinka publishes @alinka/react-components
import {
  AlinkaCourseList,
  AlinkaMentorBrowser,
  AlinkaServiceMarketplace
} from '@alinka/react-components';

// EnDAO wraps with DAO context
<AlinkaProvider
  partnerId="endao"
  daoId={daoId}
  theme={endaoTheme}
>
  <AlinkaCourseList
    onEnroll={(course) => handleEnrollment(course)}
  />
</AlinkaProvider>
```

### Option C: Full White-Label (Enterprise)

```
- Custom domain: learning.your-dao.org
- Alinka infrastructure, DAO branding
- Separate billing relationship
- Data sovereignty options
```

---

## Payment Flows

### 1. Bounty Payout (DAO Treasury → Alinka Provider)

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  DAO Admin  │────▶│   EnDAO     │────▶│   Gnosis    │────▶│   Alinka    │
│  approves   │     │  triggers   │     │   Safe TX   │     │  Provider   │
│  submission │     │  payout     │     │             │     │  Wallet     │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                               │
                                               │ 0x... txHash
                                               │
                                               ▼
                                        ┌─────────────┐
                                        │   EnDAO     │
                                        │  records    │
                                        │  completion │
                                        └─────────────┘
                                               │
                                               │ webhook
                                               ▼
                                        ┌─────────────┐
                                        │   Alinka    │
                                        │  confirms   │
                                        │  receipt    │
                                        └─────────────┘
```

**Options**:
- **Direct Crypto**: Send USDC/ETH to provider's linked wallet
- **Via Alinka**: Send to Alinka escrow, Alinka distributes (takes fee)
- **Stripe Connect**: Alinka as connected account (for fiat settlement)

### 2. Course Enrollment (DAO Treasury → Alinka)

```
1. DAO creates "Education Grant" proposal with course budget
2. Proposal passes governance vote
3. Treasury sends funds to Alinka (bulk purchase)
4. Alinka issues enrollment vouchers
5. Members redeem vouchers on Alinka
6. Course completion tracked and reported
```

### 3. Loan Funding (DAO Treasury → Member via Alinka)

```
1. Member applies for loan (underwritten by DAO)
2. Alinka assesses creditworthiness
3. DAO governance votes to approve funding
4. Treasury sends loan amount to Alinka
5. Alinka disburses to member
6. Repayments collected by Alinka
7. Principal + interest returned to DAO treasury
```

---

## Security Considerations

1. **API Authentication**: HMAC-SHA256 signed requests between platforms
2. **Webhook Verification**: Signature validation on all incoming webhooks
3. **Rate Limiting**: Protect both APIs from abuse
4. **Data Minimization**: Only share necessary user data
5. **Audit Logging**: All cross-platform operations logged
6. **Treasury Protection**: All payouts go through existing treasury security layers

---

## Complete Access Matrix

| Feature | Individual Access | DAO-Level Access |
|---------|-------------------|------------------|
| **Courses** | Buy with member discount (5-20% off) | Bulk purchase, fund member enrollments |
| **Services** | Hire providers at community rates | Post bounties for DAO projects |
| **Mentoring** | Book 1:1 at member rates | Sponsor cohort programs |
| **Loans - Personal** | Apply with DAO credit boost | Co-sign/back member loans |
| **Loans - Organization** | N/A | DAO borrows for operations |
| **Authentication** | Wallet-based identity verification | API key + HMAC signing |
| **Payment** | Personal wallet/card | DAO treasury (multi-sig) |
| **Governance** | None (self-service) | Proposal vote required |

---

## Implementation Phases

### Phase 1: Foundation & Identity (4-6 weeks)
- [ ] Partner API design finalization (both sides)
- [ ] Wallet-based identity linking
- [ ] Membership verification endpoint (individual access)
- [ ] Webhook infrastructure
- [ ] Basic EnDAO ↔ Alinka user mapping

### Phase 2: Individual Access (4-5 weeks)
- [ ] Member discount verification flow
- [ ] Course purchase with member pricing
- [ ] Service marketplace member rates
- [ ] Individual loan credit boost integration
- [ ] Member purchase tracking (analytics)

### Phase 3: DAO-Level Bounties (3-4 weeks)
- [ ] Bounty sync (EnDAO → Alinka → EnDAO)
- [ ] Application management in EnDAO UI
- [ ] Payout integration with treasury
- [ ] Provider ratings/reviews sync

### Phase 4: DAO Education & Mentorship (3-4 weeks)
- [ ] Course catalog browsing
- [ ] Bulk enrollment system
- [ ] Voucher redemption flow
- [ ] Progress tracking and reporting
- [ ] Group mentorship booking

### Phase 5: Loan Programs (5-6 weeks)
- [ ] DAO organization loans (DAO borrows)
- [ ] Member loans with DAO backing
- [ ] Escrow/collateral management
- [ ] Repayment tracking integration
- [ ] Default handling and claims

### Phase 6: White-Label & Polish (4-5 weeks)
- [ ] Embedded components (iframe/React)
- [ ] Custom theming per DAO
- [ ] Analytics dashboard
- [ ] Documentation and onboarding

---

## Success Metrics

| Metric | Target |
|--------|--------|
| DAOs with Alinka enabled | 50+ in 6 months |
| Bounties cross-posted | 100+ per month |
| Course enrollments funded | 500+ per quarter |
| Loan applications | 50+ per quarter |
| Provider satisfaction | >4.5/5 rating |

---

## Next Steps

1. **Alignment Meeting**: EnDAO + Alinka teams to review this spec
2. **API Contract Finalization**: Agree on endpoints, auth, webhooks
3. **Pilot DAO Selection**: 3-5 DAOs for beta testing
4. **Development Sprint Planning**: Break into 2-week sprints
5. **Legal Review**: Data sharing agreement, terms of service updates

---

## Value Proposition Summary

### For EnDAO Users (Individuals)

| Benefit | Description |
|---------|-------------|
| **Discounted Learning** | 5-20% off courses based on DAO membership tier |
| **Better Loan Terms** | DAO membership = credit boost, lower rates, higher limits |
| **Community Pricing** | Member rates on services and mentoring |
| **Portable Reputation** | DAO activity builds credit history across platforms |
| **No Extra Account** | Wallet-based identity - one login for both platforms |

### For DAOs (Organizations)

| Benefit | Description |
|---------|-------------|
| **Access to Talent** | Tap into Alinka's service provider network for bounties |
| **Member Development** | Fund education programs without building LMS |
| **Financial Tools** | Offer microloans to members, or borrow for DAO operations |
| **Turnkey Services** | Mentorship programs without recruiting mentors |
| **Member Retention** | Benefits that make DAO membership more valuable |

### For Alinka

| Benefit | Description |
|---------|-------------|
| **New User Channel** | Access to EnDAO's DAO member base |
| **Organizational Customers** | B2B revenue from DAO treasuries |
| **Reduced Risk** | DAO-backed loans have lower default rates |
| **Community Effects** | DAO members bring peers to platform |
| **Partnership Revenue** | Revenue share on partner-referred transactions |

### For the Ecosystem

| Benefit | Description |
|---------|-------------|
| **Bridges Web2 ↔ Web3** | Traditional entrepreneurs access DAO benefits |
| **Financial Inclusion** | DAO membership enables credit access |
| **Skill Development** | Funded education creates better service providers |
| **Economic Mobility** | Loans + education + mentorship = upward mobility |

---

## Future Roadmap Use Cases

The following use cases leverage EnDAO's upcoming features from the platform and token roadmaps. These represent deeper integration opportunities as both platforms mature.

---

### Token Ecosystem Integration (EDG/TCR/TEQ)

#### 1. Alinka Providers on EnDAO ServiceMarketplace (TCR + TEQ)

**Context**: EnDAO's ServiceMarketplace introduces "double-dip" compensation where service providers earn both TCR (stablecoin payment) and TEQ (soulbound labor equity).

**Opportunity**: Alinka service providers can register on EnDAO's ServiceMarketplace, making their services discoverable by all EnDAO DAOs while earning both payment and equity.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         EnDAO ServiceMarketplace                                 │
│                                                                                  │
│   ┌──────────────────────────────────────────────────────────────────────────┐  │
│   │                    Service Provider Registry                              │  │
│   │                                                                           │  │
│   │   ┌────────────────┐  ┌────────────────┐  ┌────────────────┐            │  │
│   │   │ Independent    │  │   Alinka       │  │   Guild        │            │  │
│   │   │ Providers      │  │   Providers    │  │   Collectives  │            │  │
│   │   │                │  │   (Imported)   │  │                │            │  │
│   │   └────────────────┘  └────────────────┘  └────────────────┘            │  │
│   └──────────────────────────────────────────────────────────────────────────┘  │
│                                      │                                          │
│                                      ▼                                          │
│   ┌──────────────────────────────────────────────────────────────────────────┐  │
│   │                       Work Completion                                     │  │
│   │                                                                           │  │
│   │   Provider completes bounty/service ───────▶ Receives:                   │  │
│   │                                              • TCR (immediate payment)    │  │
│   │                                              • TEQ (labor equity token)   │  │
│   └──────────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Benefits**:
- Alinka providers access larger client base (all EnDAO DAOs)
- Providers build portable labor equity (TEQ) across platforms
- DAOs get verified, rated providers from Alinka's network
- Alinka earns referral revenue on cross-platform work

**Flow**:
```
1. Alinka provider opts into "EnDAO ServiceMarketplace" in their Alinka profile
2. Provider profile synced to EnDAO (skills, ratings, portfolio)
3. Provider appears in ServiceMarketplace searches
4. DAO hires provider through EnDAO
5. Payment: TCR (immediate) + TEQ (vested over engagement)
6. Work history visible in both platforms
```

---

#### 2. TEQ Labor Equity for Alinka Service Work

**Context**: TEQ (Token of Labor Equity) is a soulbound (non-transferable) token representing accumulated work contribution in the EnDAO ecosystem.

**Opportunity**: Any work done through the Alinka-EnDAO integration earns TEQ, creating a cross-platform labor equity system.

**Use Cases**:

| Work Type | TEQ Earned | Vesting |
|-----------|-----------|---------|
| Bounty completion | 1 TEQ per $100 work | 25% immediate, 75% over 6mo |
| Course instruction | 0.5 TEQ per student completion | Monthly |
| Mentorship hours | 0.25 TEQ per hour | Weekly |
| Loan repayment (on time) | 0.1 TEQ per payment | At payment |

**Benefits of TEQ**:
- **Reputation Signal**: High TEQ = proven track record
- **Governance Weight**: TEQ may influence DAO voting power
- **Access Tiers**: TEQ unlocks premium features
- **Credit Enhancement**: TEQ contributes to loan creditworthiness

```typescript
// TEQ calculation for Alinka work
interface TEQEarning {
  source: 'alinka_bounty' | 'alinka_course' | 'alinka_mentorship' | 'alinka_loan_repayment';
  userId: string;
  amount: number;           // TEQ amount
  vestingSchedule: {
    immediate: number;      // Percentage
    vestingPeriod: number;  // Days
    vestingRate: number;    // Percentage per period
  };
  metadata: {
    alinkaTransactionId: string;
    workDescription: string;
    completedAt: string;
  };
}
```

---

#### 3. TCR as Cross-Platform Payment Rail

**Context**: TCR (Treasury Credit) is EnDAO's stablecoin-pegged payment utility token for the labor marketplace.

**Opportunity**: DAOs pay for Alinka services in TCR, creating a unified payment experience and potential fee savings.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Payment Flow Options                                  │
│                                                                                  │
│   Option A: Traditional (Current)                                               │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐                 │
│   │   DAO    │───▶│   USDC   │───▶│  Alinka  │───▶│ Provider │                 │
│   │ Treasury │    │          │    │  escrow  │    │          │                 │
│   └──────────┘    └──────────┘    └──────────┘    └──────────┘                 │
│                                                                                  │
│   Option B: TCR Payment (Future)                                                │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐                                 │
│   │   DAO    │───▶│   TCR    │───▶│ Provider │                                 │
│   │ Treasury │    │(1:1 USD) │    │ (direct) │                                 │
│   └──────────┘    └──────────┘    └──────────┘                                 │
│                                                                                  │
│   Benefits of TCR:                                                              │
│   • No Alinka escrow fees                                                       │
│   • Instant settlement                                                          │
│   • Provider can hold TCR or convert to USDC                                    │
│   • Transaction history on-chain                                                │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Implementation**:
```typescript
interface AlinkaPaymentOptions {
  methods: {
    traditional: {
      currencies: ['USD', 'USDC', 'ETH'];
      escrowRequired: true;
      alinkaFee: '2.5%';
    };
    tcr: {
      currency: 'TCR';
      escrowRequired: false;  // Smart contract handles
      fee: '0.5%';            // Protocol fee only
      providerOptions: 'hold' | 'convert_usdc' | 'convert_fiat';
    };
  };
}
```

---

#### 4. EDG Staking for Alinka Benefits

**Context**: EDG (EnDAO Governance Token) provides fee discounts when staked and governance participation.

**Opportunity**: Users staking EDG receive premium benefits on Alinka services.

| EDG Staked | Alinka Benefit |
|------------|----------------|
| 100+ EDG | 5% additional discount on courses |
| 500+ EDG | Priority support queue |
| 1,000+ EDG | 0.5% loan rate reduction |
| 5,000+ EDG | Featured provider status (for service providers) |
| 10,000+ EDG | Custom integration support for DAO |

**Verification Flow**:
```
1. User connects wallet to Alinka
2. Alinka calls EnDAO: GET /partner/edg-stake?wallet={address}
3. EnDAO returns: { stakedAmount: 1500, tier: 'gold', benefits: [...] }
4. Alinka applies benefits to user's account
```

---

### LaborOracle Integration

**Context**: EnDAO's LaborOracle provides decentralized rate management for labor valuation—fair market rates for various skills and services.

**Opportunity**: Alinka can use LaborOracle data to standardize pricing and ensure fair rates for services.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           LaborOracle Integration                                │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                         EnDAO LaborOracle                                │   │
│   │                                                                          │   │
│   │   Aggregates market rates from:                                         │   │
│   │   • Completed bounties across all DAOs                                  │   │
│   │   • ServiceMarketplace transactions                                     │   │
│   │   • External rate feeds (Upwork, Fiverr, etc.)                          │   │
│   │                                                                          │   │
│   │   Outputs:                                                               │   │
│   │   • Fair market rates by skill category                                 │   │
│   │   • Regional adjustments                                                │   │
│   │   • Experience-level multipliers                                        │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                      │                                          │
│                                      ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                         Alinka Uses LaborOracle                          │   │
│   │                                                                          │   │
│   │   • Course pricing benchmarking                                         │   │
│   │   • Service rate suggestions for providers                              │   │
│   │   • Loan affordability calculations                                     │   │
│   │   • "Fair Price" badges on listings                                     │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**API Integration**:
```typescript
// EnDAO exposes LaborOracle rates
GET /api/labor-oracle/rates?skill={skill}&region={region}&experience={level}

Response: {
  skill: 'graphic_design',
  region: 'global',
  experienceLevel: 'intermediate',
  rates: {
    hourly: { min: 35, median: 55, max: 85, currency: 'USD' },
    project: { small: 200, medium: 800, large: 3000 }
  },
  lastUpdated: '2026-01-26T00:00:00Z',
  dataPoints: 1250
}
```

**Use Cases**:
1. **Rate Suggestions**: When Alinka provider sets rates, show LaborOracle benchmark
2. **Fair Price Badges**: Listings within 20% of median get "Fair Price" badge
3. **DAO Budget Planning**: DAOs use oracle rates to estimate project costs
4. **Loan Underwriting**: Verify borrower's claimed income against market rates

---

### Service Provider Collectives and DAO-to-DAO Integration

#### 5. Alinka Provider Collectives as Independent DAOs

**Important Clarification**: Alinka is a platform/marketplace, not a DAO itself. Therefore, service provider groups do **not** form Sub-DAOs under Alinka. Instead, they form their own **independent DAOs** when they want collective governance.

> **Note on Sub-DAOs**: EnDAO supports Sub-DAO architecture for organizations that need nested governance (e.g., departments within a company, regional chapters within a national organization). However, this is not applicable to Alinka integration since there is no parent Alinka DAO for providers to nest under.

**Opportunity**: Groups of Alinka service providers can form their own independent DAOs for collective bargaining, shared resources, and governance.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                     Provider Collective (Independent DAO)                        │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    "Alinka Design Guild" DAO                             │   │
│   │                    (Independent organization)                            │   │
│   │                                                                          │   │
│   │   Members: 25 Alinka graphic designers                                  │   │
│   │   Treasury: Shared revenue pool (10% of member earnings)                │   │
│   │                                                                          │   │
│   │   Benefits:                                                              │   │
│   │   • Collective bargaining for large projects                            │   │
│   │   • Shared tools/subscriptions                                          │   │
│   │   • Peer review and quality assurance                                   │   │
│   │   • Group health/benefits fund                                          │   │
│   │   • Marketing as a collective                                           │   │
│   │                                                                          │   │
│   │   Governance:                                                            │   │
│   │   • Vote on accepting large projects                                    │   │
│   │   • Allocate shared treasury                                            │   │
│   │   • Set quality standards                                               │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│                        DAO owns its own:                                        │
│                        • Treasury infrastructure (Safe)                        │
│                        • Governance framework                                  │
│                        • ServiceMarketplace presence                           │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Formation Flow**:
```
1. 5+ Alinka providers agree to form guild
2. Create independent DAO on EnDAO (their own governance setup)
3. Link Alinka provider accounts to DAO membership
4. DAO appears as "collective" in ServiceMarketplace
5. Clients can hire the guild (work distributed internally)
6. Revenue flows: Client → DAO treasury → Member payouts
```

**Collective DAO Types for Alinka Providers**:

| Guild Type | Focus | Example |
|------------|-------|---------|
| **Skill Guild** | Single skill specialization | Alinka Dev Guild, Design Guild |
| **Regional Guild** | Geographic focus | East Africa Guild, LATAM Guild |
| **Vertical Guild** | Industry focus | Healthcare Tech Guild |
| **Mentorship Guild** | Collective of mentors | Alinka Mentor Collective |

**Internal Sub-DAOs Within Provider Collectives**:

Once a service provider collective forms their own independent DAO, they can utilize EnDAO's Sub-DAO feature for their internal management and governance structure. This is entirely at the collective's discretion.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                  "Alinka Design Guild" DAO (Independent)                         │
│                                                                                  │
│   ┌───────────────────┐  ┌───────────────────┐  ┌───────────────────┐          │
│   │  Brand Design     │  │  UI/UX Design     │  │  Motion Graphics  │          │
│   │  Sub-DAO          │  │  Sub-DAO          │  │  Sub-DAO          │          │
│   │                   │  │                   │  │                   │          │
│   │  • 8 members      │  │  • 10 members     │  │  • 7 members      │          │
│   │  • Own budget     │  │  • Own budget     │  │  • Own budget     │          │
│   │  • Specialized    │  │  • Specialized    │  │  • Specialized    │          │
│   │    governance     │  │    governance     │  │    governance     │          │
│   └───────────────────┘  └───────────────────┘  └───────────────────┘          │
│                                                                                  │
│   Parent DAO Governance:                                                        │
│   • Overall treasury management                                                 │
│   • Cross-team project allocation                                               │
│   • Collective membership standards                                             │
│   • Sub-DAO budget delegation                                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Example Use Cases for Sub-DAOs Within a Collective**:

| Sub-DAO Purpose | Description |
|-----------------|-------------|
| **Skill Specialization** | Divide a design guild into brand, UI/UX, and motion teams |
| **Regional Chapters** | A global collective with regional Sub-DAOs for local coordination |
| **Project Teams** | Temporary Sub-DAOs for large multi-phase projects |
| **Apprenticeship Program** | Sub-DAO for mentees with limited voting rights until graduation |

---

#### 6. DAO-to-DAO Service Contracts

**Context**: EnDAO enables formal relationships between DAOs, including service contracts and collaborations.

**Opportunity**: One DAO can hire another DAO (which sources from Alinka) for services, creating B2B relationships.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                       DAO-to-DAO Service Contract                                │
│                                                                                  │
│   ┌─────────────────────────────────────────┐                                   │
│   │         Client DAO                       │                                   │
│   │         "TechStartup DAO"                │                                   │
│   │                                          │                                   │
│   │         Needs: Full rebrand              │                                   │
│   │         Budget: $15,000                  │                                   │
│   └──────────────────┬──────────────────────┘                                   │
│                      │                                                           │
│                      │ DAO-to-DAO Contract                                      │
│                      ▼                                                           │
│   ┌─────────────────────────────────────────┐                                   │
│   │         Provider DAO                     │                                   │
│   │         "Alinka Design Guild"            │                                   │
│   │                                          │                                   │
│   │         Scope: Logo, brand guide,        │                                   │
│   │                website, templates        │                                   │
│   │         Timeline: 8 weeks                │                                   │
│   └──────────────────┬──────────────────────┘                                   │
│                      │                                                           │
│                      │ Internal allocation                                       │
│                      ▼                                                           │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    Guild Member Allocation                               │   │
│   │                                                                          │   │
│   │   • Alice (Logo): $4,000                                                │   │
│   │   • Bob (Brand Guide): $3,000                                           │   │
│   │   • Charlie (Website): $5,000                                           │   │
│   │   • Guild Treasury (10%): $1,500                                        │   │
│   │   • Project Manager (5%): $750                                          │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Contract Structure**:
```typescript
interface DAOtoDAOContract {
  id: string;
  clientDaoId: string;
  providerDaoId: string;

  // Scope
  title: string;
  description: string;
  deliverables: string[];
  milestones: {
    name: string;
    amount: number;
    deadline: string;
    status: 'pending' | 'submitted' | 'approved' | 'paid';
  }[];

  // Terms
  totalAmount: number;
  currency: 'TCR' | 'USDC' | 'USD';
  paymentSchedule: 'milestone' | 'monthly' | 'completion';

  // Governance
  clientApprovalThreshold: number;   // % of client DAO to approve milestones
  providerAcceptanceVote: string;    // Proposal ID in provider DAO

  // Dispute resolution
  arbitrationMethod: 'dao_vote' | 'third_party' | 'smart_contract';
}
```

---

#### 7. Cross-DAO Mentorship Marketplace

**Context**: DAO-to-DAO relationships enable members of one DAO to provide services to another.

**Opportunity**: Alinka mentors from one DAO can advise members of another DAO, with both parties earning TEQ.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    Cross-DAO Mentorship Flow                                     │
│                                                                                  │
│   ┌────────────────────────┐              ┌────────────────────────┐            │
│   │   Mentor's Home DAO    │              │   Mentee's Home DAO    │            │
│   │   "Alinka Mentors"     │              │   "NewFounders DAO"    │            │
│   │                        │              │                        │            │
│   │   Sarah (Mentor)       │              │   Alex (Mentee)        │            │
│   │   • Business strategy  │◄────────────▶│   • Needs guidance     │            │
│   │   • 4.9★ rating        │  Mentorship  │   • Pre-seed startup   │            │
│   │   • $75/hour           │   Session    │                        │            │
│   └────────────────────────┘              └────────────────────────┘            │
│              │                                        │                          │
│              │                                        │                          │
│              ▼                                        ▼                          │
│   ┌────────────────────────────────────────────────────────────────────────┐    │
│   │                         Compensation                                    │    │
│   │                                                                         │    │
│   │   Sarah receives:                    Alex's DAO pays:                  │    │
│   │   • $75 TCR (session payment)        • $75 from treasury               │    │
│   │   • 0.25 TEQ (mentorship equity)     • OR Alex pays personally         │    │
│   │                                                                         │    │
│   │   Alex receives:                                                        │    │
│   │   • 0.1 TEQ (learning equity)        (Being mentored builds equity!)   │    │
│   └────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Cross-DAO Benefits**:
- Mentors access larger client base across all DAOs
- Mentees access specialized expertise not in their DAO
- Both parties earn TEQ (ecosystem equity)
- DAOs can establish mentorship partnerships

---

### Capital and Lending Innovations

#### 8. DAO Treasury Loans TO Alinka (Reverse Lending)

**Context**: DAOs accumulate treasury balances that may exceed operational needs.

**Opportunity**: DAOs with excess treasury can provide capital to Alinka's loan fund, earning yield while supporting micro-entrepreneurship.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                      DAO → Alinka Capital Flow                                   │
│                                                                                  │
│   ┌────────────────────────────┐                                                │
│   │   DAO Treasury             │                                                │
│   │   Balance: $500,000        │                                                │
│   │   Operational need: $200K  │                                                │
│   │   Excess: $300K            │                                                │
│   └──────────────┬─────────────┘                                                │
│                  │                                                               │
│                  │ Proposal: "Allocate $100K to Alinka Loan Fund"               │
│                  │ Expected yield: 8% APY                                       │
│                  │ Term: 12 months, quarterly liquidity                         │
│                  ▼                                                               │
│   ┌────────────────────────────────────────────────────────────────────────┐    │
│   │                    Alinka Loan Fund                                     │    │
│   │                                                                         │    │
│   │   Capital sources:                                                      │    │
│   │   • Traditional investors: $2M                                         │    │
│   │   • DAO treasuries: $500K (from 5 DAOs)                                │    │
│   │   • Impact funds: $1M                                                  │    │
│   │                                                                         │    │
│   │   Deployed to:                                                          │    │
│   │   • 500+ microloans                                                     │    │
│   │   • Average size: $3,000                                               │    │
│   │   • Default rate: 4%                                                    │    │
│   │   • Net yield: 12%                                                      │    │
│   └────────────────────────────────────────────────────────────────────────┘    │
│                  │                                                               │
│                  │ Returns (quarterly)                                          │
│                  ▼                                                               │
│   ┌────────────────────────────┐                                                │
│   │   DAO Treasury             │                                                │
│   │   Receives: ~$2K/quarter   │                                                │
│   │   (8% APY on $100K)        │                                                │
│   └────────────────────────────┘                                                │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Structure Options**:

| Option | Risk | Yield | Liquidity |
|--------|------|-------|-----------|
| **Senior Tranche** | Low (first loss protection) | 5-6% APY | Monthly |
| **Mezzanine** | Medium | 8-10% APY | Quarterly |
| **First Loss** | High (absorbs defaults first) | 12-15% APY | Annual |

**DAO Benefits**:
- Earn yield on idle treasury
- Support aligned mission (micro-entrepreneurship)
- Diversify treasury beyond crypto holdings
- Social impact reporting for DAO members

---

#### 9. TEQ Vesting for Loan Repayment (Pay-to-Own)

**Context**: TEQ represents labor equity. Loan repayment is a form of financial discipline that benefits the ecosystem.

**Opportunity**: Borrowers earn TEQ for on-time loan repayments, creating a "pay-to-own" model where responsible borrowing builds equity.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    Pay-to-Own: TEQ for Loan Repayment                            │
│                                                                                  │
│   Borrower takes $5,000 loan, 12 months, 10% APR                                │
│   Monthly payment: $440                                                          │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │   Month │ Payment │ On-Time? │ TEQ Earned │ Cumulative TEQ │            │   │
│   │   ──────┼─────────┼──────────┼────────────┼────────────────│            │   │
│   │      1  │   $440  │    ✓     │    0.1     │      0.1       │            │   │
│   │      2  │   $440  │    ✓     │    0.1     │      0.2       │            │   │
│   │      3  │   $440  │    ✓     │    0.1     │      0.3       │            │   │
│   │     ... │   ...   │   ...    │    ...     │      ...       │            │   │
│   │     12  │   $440  │    ✓     │    0.1     │      1.2       │            │   │
│   │         │         │          │            │                │            │   │
│   │   BONUS: All 12 on-time = +0.5 TEQ completion bonus                     │   │
│   │   TOTAL: 1.7 TEQ for successful loan repayment                          │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│   TEQ Benefits for Borrower:                                                    │
│   • Better terms on next loan (TEQ = creditworthiness)                         │
│   • Access to larger loan amounts                                               │
│   • Reputation in EnDAO ecosystem                                               │
│   • Potential governance participation                                          │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Incentive Alignment**:
- **Borrower**: Earn equity while repaying (loan becomes investment)
- **Lender (Alinka/DAO)**: Lower default rates due to TEQ incentive
- **Ecosystem**: TEQ circulation increases engagement

---

### Ecosystem Growth

#### 10. DAO Incubator Program (Alinka → EnDAO Pipeline)

**Context**: Many Alinka users are entrepreneurs who could benefit from DAO structure for their growing businesses.

**Opportunity**: Alinka helps entrepreneurs form DAOs on EnDAO, creating a user acquisition pipeline.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    Alinka → EnDAO Incubator Pipeline                             │
│                                                                                  │
│   Stage 1: Alinka User                                                          │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │   Entrepreneur on Alinka:                                                │   │
│   │   • Completed 3+ courses                                                │   │
│   │   • Has active loan (in good standing)                                  │   │
│   │   • Building team of 3+ people                                          │   │
│   │   • Revenue: $2K+/month                                                 │   │
│   └──────────────────────────────────┬──────────────────────────────────────┘   │
│                                      │                                          │
│                                      │ Qualifies for DAO Incubator             │
│                                      ▼                                          │
│   Stage 2: Incubator Program                                                    │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │   4-week program (via Alinka courses + mentorship):                      │   │
│   │   Week 1: DAO fundamentals, governance models                           │   │
│   │   Week 2: Treasury management, multi-sig setup                          │   │
│   │   Week 3: Proposal systems, voting mechanisms                           │   │
│   │   Week 4: Legal structures (Wyoming DUNA, etc.)                         │   │
│   └──────────────────────────────────┬──────────────────────────────────────┘   │
│                                      │                                          │
│                                      │ Graduate                                 │
│                                      ▼                                          │
│   Stage 3: DAO Formation                                                        │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │   • Create DAO on EnDAO (assisted setup)                                │   │
│   │   • Treasury deployment (Safe multi-sig)                                │   │
│   │   • Initial governance configuration                                    │   │
│   │   • Alinka integration pre-enabled                                      │   │
│   │   • First 3 months: Mentorship support included                         │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│   Outcome: New DAO with:                                                        │
│   • Trained leadership                                                          │
│   • Established treasury                                                        │
│   • Active Alinka integration                                                   │
│   • Mentorship relationship                                                     │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Benefits**:
- **For Entrepreneurs**: Structured path to formalize business
- **For Alinka**: Higher-value customers (DAOs vs individuals)
- **For EnDAO**: User acquisition channel
- **For Ecosystem**: More DAOs = more network effects

---

#### 11. Cross-Platform Reputation Aggregation

**Context**: Both platforms have reputation systems. Combined reputation is more valuable than either alone.

**Opportunity**: Create unified "Economic Reputation Score" that aggregates data from both platforms.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    Unified Economic Reputation Score                             │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                     EnDAO Signals                                        │   │
│   │                                                                          │   │
│   │   • DAO membership duration and count                                   │   │
│   │   • Proposals created/passed                                            │   │
│   │   • Bounties completed                                                  │   │
│   │   • Voting participation                                                │   │
│   │   • Treasury contributions                                              │   │
│   │   • TEQ balance                                                         │   │
│   │   • EDG stake                                                           │   │
│   └────────────────────────────────────┬────────────────────────────────────┘   │
│                                        │                                        │
│                                        ▼                                        │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    Reputation Engine                                     │   │
│   │                                                                          │   │
│   │   Weighted aggregation with privacy controls                            │   │
│   │                                                                          │   │
│   │   Output: Economic Reputation Score (0-1000)                            │   │
│   │                                                                          │   │
│   │   Components:                                                            │   │
│   │   • Financial Responsibility: 25%                                       │   │
│   │   • Work Quality: 25%                                                   │   │
│   │   • Community Participation: 20%                                        │   │
│   │   • Skill Verification: 15%                                             │   │
│   │   • Tenure: 15%                                                         │   │
│   └────────────────────────────────────┬────────────────────────────────────┘   │
│                                        │                                        │
│                                        ▼                                        │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                     Alinka Signals                                       │   │
│   │                                                                          │   │
│   │   • Courses completed                                                   │   │
│   │   • Service provider ratings                                            │   │
│   │   • Loan repayment history                                              │   │
│   │   • Mentorship given/received                                           │   │
│   │   • Business metrics (if shared)                                        │   │
│   │   • Platform tenure                                                     │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│   Use Cases:                                                                    │
│   • Loan pre-qualification                                                      │
│   • Service provider ranking                                                    │
│   • DAO membership applications                                                 │
│   • Access tier determination                                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Privacy Controls**:
```typescript
interface ReputationShareSettings {
  userId: string;

  // What to share between platforms
  shareWithEnDAO: {
    loanHistory: boolean;          // Default: false
    courseCompletions: boolean;    // Default: true
    serviceRatings: boolean;       // Default: true
    businessMetrics: boolean;      // Default: false
  };

  shareWithAlinka: {
    daoMemberships: boolean;       // Default: true
    bountyHistory: boolean;        // Default: true
    votingRecord: boolean;         // Default: false
    treasuryContributions: boolean; // Default: false
  };
}
```

---

#### 12. Enterprise Federation: Compliance Services

**Context**: EnDAO's Federation tier targets enterprise customers with compliance needs.

**Opportunity**: Alinka can provide compliance services (tax, legal, regulatory) for enterprise DAOs in the federation.

**Services**:

| Service | Description | Delivery |
|---------|-------------|----------|
| **Tax Compliance** | Crypto tax reporting, treasury accounting | Annual/Quarterly |
| **Legal Entity Setup** | Wyoming DUNA formation, corporate structure | One-time |
| **Regulatory Advisory** | Securities law, money transmission | As needed |
| **Audit Preparation** | Documentation, financial statements | Annual |
| **KYC/AML** | Member verification for regulated activities | Ongoing |

**Integration**:
```
EnDAO Federation DAO → Compliance Request → Alinka Legal/Finance Network
                                                      │
                                        ┌─────────────┼─────────────┐
                                        │             │             │
                                        ▼             ▼             ▼
                                   Tax Prep      Legal Docs    Regulatory
                                   Partner       Partner       Advisor
```

---

### Summary: Roadmap-Aligned Use Cases

| Use Case | EnDAO Feature | Timeline |
|----------|---------------|----------|
| TCR Payment Rail | Token Phase 2 | Q3 2026 |
| TEQ for Alinka Work | Token Phase 2 | Q3 2026 |
| EDG Staking Benefits | Token Phase 1 | Q2 2026 |
| LaborOracle Rates | Token Phase 2 | Q3 2026 |
| Provider Collective DAOs | Platform Tier 3 | Q4 2026 |
| DAO-to-DAO Contracts | Platform Tier 3 | Q4 2026 |
| Cross-DAO Mentorship | Platform Tier 3 | Q4 2026 |
| DAO Treasury Lending | Platform Tier 2 | Q3 2026 |
| TEQ for Loan Repayment | Token Phase 2 | Q3 2026 |
| DAO Incubator | Platform Tier 1 | Q2 2026 |
| Reputation Aggregation | Platform Tier 2 | Q3 2026 |
| Federation Compliance | Platform Tier 4 | 2027 |

---

## Payment Strategy: Fiat-First with Multi-Currency Support

### Philosophy: Meet Users Where They Are

**Reality Check**: Most users—especially in emerging markets where Village Micro Fund operates—expect to pay in their local currency via familiar methods (credit card, bank transfer, mobile money). Crypto payment options are valuable for those who want them, but should never be a barrier to participation.

**Core Principle**: Fiat is the default. Crypto is an enhancement.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Payment Experience Hierarchy                              │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  Layer 1: FIAT (Default - Zero Learning Curve)                          │   │
│   │                                                                          │   │
│   │  • Credit/Debit Card (Stripe)                                           │   │
│   │  • Bank Transfer (ACH, SEPA, local rails)                               │   │
│   │  • Mobile Money (M-Pesa, GCash, regional options)                       │   │
│   │  • Local Payment Methods (per region)                                   │   │
│   │                                                                          │   │
│   │  User sees: Familiar checkout, local currency, normal receipts         │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                      │                                          │
│                                      ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  Layer 2: STABLECOIN (Opt-In - For Crypto-Comfortable Users)            │   │
│   │                                                                          │   │
│   │  • USDC/USDT direct payments                                            │   │
│   │  • TCR (EnDAO's stablecoin-pegged token) for fee discounts              │   │
│   │  • Cross-border payments without forex fees                             │   │
│   │                                                                          │   │
│   │  User sees: "Pay with crypto" option, clear instructions                │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                      │                                          │
│                                      ▼                                          │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  Layer 3: VOLATILE CRYPTO (Advanced - For DeFi-Native Users)            │   │
│   │                                                                          │   │
│   │  • ETH, SOL, MATIC native payments                                      │   │
│   │  • Auto-convert to stablecoin on receipt                                │   │
│   │  • DEX integration for token swaps                                      │   │
│   │                                                                          │   │
│   │  User sees: "Advanced options" disclosure                               │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Payment Flow Architecture

```
User initiates payment
         │
         ▼
┌─────────────────────┐
│  Currency Selection │
│                     │
│  [USD ▼]  $100.00   │  ← Local currency default, auto-detected
│                     │
│  Payment Method:    │
│  ○ Card (Visa/MC)   │  ← Fiat options first
│  ○ Bank Transfer    │
│  ○ Mobile Money     │
│  ─────────────────  │
│  ○ USDC             │  ← Crypto options below divider
│  ○ Other Crypto     │
└─────────────────────┘
         │
         ├─── Fiat Selected ──────────────────────────────┐
         │                                                │
         │    ┌────────────────────────────────────────┐  │
         │    │          Stripe / Local PSP            │  │
         │    │                                        │  │
         │    │  • Process in user's local currency   │  │
         │    │  • Settlement in merchant's currency  │  │
         │    │  • Standard receipts/invoices         │  │
         │    │  • Familiar refund process            │  │
         │    └────────────────────────────────────────┘  │
         │                                                │
         │                                                ▼
         │                                     ┌──────────────────┐
         │                                     │  Funds arrive in │
         │                                     │  DAO Treasury    │
         │                                     │  (as stablecoin) │
         │                                     └──────────────────┘
         │                                                ▲
         │                                                │
         ├─── Crypto Selected ────────────────────────────┘
         │
         │    ┌────────────────────────────────────────┐
         │    │       On-Chain Payment                 │
         │    │                                        │
         │    │  • Direct wallet transfer              │
         │    │  • Auto-convert to USDC if volatile   │
         │    │  • On-chain receipt (tx hash)         │
         │    └────────────────────────────────────────┘
```

### Fiat-to-Treasury Bridge

When a user pays in fiat, EnDAO (via Stripe Crypto On-ramp or Circle) converts to stablecoin and deposits to the DAO's Safe treasury:

```typescript
interface FiatPaymentConfig {
  // User-facing
  supportedCurrencies: string[];        // ['USD', 'EUR', 'GBP', 'KES', 'PHP', ...]
  supportedMethods: PaymentMethod[];    // card, bank, mobile_money
  localPaymentProviders: {              // Region-specific
    africa: 'flutterwave' | 'paystack';
    asia: 'stripe' | 'razorpay';
    latam: 'stripe' | 'mercadopago';
    global: 'stripe';
  };

  // Backend conversion
  settlementCurrency: 'USDC' | 'USDT';  // What hits the treasury
  conversionProvider: 'stripe_onramp' | 'circle' | 'moonpay';

  // Transparency
  showConversionRate: boolean;          // "Your $100 → 99.50 USDC"
  feeBreakdown: boolean;                // Show Stripe fee + conversion fee
}

interface FiatPaymentReceipt {
  // User-friendly receipt
  userPaid: {
    amount: number;
    currency: string;                   // 'KES', 'PHP', 'USD'
    method: string;                     // 'M-Pesa', 'GCash', 'Visa ****1234'
  };

  // What the DAO received
  treasuryReceived: {
    amount: number;
    currency: 'USDC';
    txHash: string;                     // On-chain proof
  };

  // Fees (transparent)
  fees: {
    paymentProcessor: number;           // Stripe fee in user's currency
    conversion: number;                 // Forex + crypto conversion
    platform: number;                   // EnDAO platform fee
  };
}
```

### Why Fiat-First Matters for Alinka Integration

1. **Target Demographic**: Alinka serves micro-entrepreneurs in emerging markets. Most have never used crypto and shouldn't need to learn just to take a course or get a loan.

2. **Reduced Friction**: A farmer in Kenya paying for a business course via M-Pesa shouldn't see wallet connection prompts.

3. **Regulatory Compliance**: Fiat payments come with built-in KYC/AML from payment processors, simplifying compliance.

4. **Trust Building**: Familiar payment methods build trust. Crypto adoption can follow naturally for those interested.

5. **Conversion Opportunity**: Users who start with fiat may later opt into crypto as they become comfortable with the platform.

---

## International Payment Support

### Multi-Currency Architecture

EnDAO and Alinka serve a global user base. Payment infrastructure must support:

- **Display Currency**: User's local currency (always)
- **Settlement Currency**: What the merchant/DAO receives
- **Treasury Currency**: On-chain storage (USDC/stablecoin)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                     Multi-Currency Payment Flow                                  │
│                                                                                  │
│   User in Kenya          User in Philippines          User in USA               │
│   Sees: KES 15,000       Sees: PHP 5,500             Sees: $100                 │
│   Pays: M-Pesa           Pays: GCash                 Pays: Visa                 │
│         │                      │                            │                   │
│         ▼                      ▼                            ▼                   │
│   ┌─────────────┐        ┌─────────────┐            ┌─────────────┐            │
│   │ Flutterwave │        │   PayMongo  │            │   Stripe    │            │
│   └──────┬──────┘        └──────┬──────┘            └──────┬──────┘            │
│          │                      │                          │                    │
│          └──────────────────────┼──────────────────────────┘                    │
│                                 │                                               │
│                                 ▼                                               │
│                    ┌────────────────────────┐                                   │
│                    │    Settlement Layer    │                                   │
│                    │                        │                                   │
│                    │  All converted to USD  │                                   │
│                    └───────────┬────────────┘                                   │
│                                │                                                │
│                                ▼                                                │
│                    ┌────────────────────────┐                                   │
│                    │  Crypto On-Ramp        │                                   │
│                    │  (Circle / Stripe)     │                                   │
│                    │                        │                                   │
│                    │  USD → USDC            │                                   │
│                    └───────────┬────────────┘                                   │
│                                │                                                │
│                                ▼                                                │
│                    ┌────────────────────────┐                                   │
│                    │   DAO Treasury (Safe)  │                                   │
│                    │                        │                                   │
│                    │   Balance: 2,850 USDC  │                                   │
│                    └────────────────────────┘                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Regional Payment Method Support

| Region | Primary Methods | Payment Provider | Currencies |
|--------|-----------------|------------------|------------|
| **Africa** | M-Pesa, Mobile Money, Bank Transfer | Flutterwave, Paystack | KES, NGN, GHS, ZAR, UGX |
| **Southeast Asia** | GCash, GrabPay, Bank Transfer | PayMongo, Stripe | PHP, IDR, MYR, THB, VND |
| **Latin America** | PIX, OXXO, Bank Transfer | Stripe, MercadoPago | BRL, MXN, ARS, COP, PEN |
| **Europe** | SEPA, iDEAL, Bancontact | Stripe | EUR, GBP, CHF, PLN, SEK |
| **North America** | Card, ACH, Apple/Google Pay | Stripe | USD, CAD |
| **Middle East** | Card, Bank Transfer | Stripe, Tap | AED, SAR, EGP |
| **South Asia** | UPI, Paytm, Bank Transfer | Razorpay, Stripe | INR, PKR, BDT |

### Currency Configuration

```typescript
interface RegionalPaymentConfig {
  region: string;
  supportedCurrencies: {
    code: string;           // 'KES', 'PHP', 'USD'
    symbol: string;         // 'KSh', '₱', '$'
    displayName: string;    // 'Kenyan Shilling'
    decimals: number;       // 2 for most, 0 for some
    minAmount: number;      // Minimum payment in currency
    maxAmount: number;      // Maximum single payment
  }[];

  paymentMethods: {
    type: 'card' | 'bank' | 'mobile_money' | 'wallet';
    name: string;           // 'M-Pesa', 'GCash', 'Visa'
    provider: string;       // 'flutterwave', 'stripe'
    enabled: boolean;
    processingTime: string; // 'instant', '1-3 days'
    fees: {
      fixed: number;        // Fixed fee in local currency
      percentage: number;   // % of transaction
    };
  }[];
}

// Example: Kenyan Configuration
const kenyaConfig: RegionalPaymentConfig = {
  region: 'KE',
  supportedCurrencies: [{
    code: 'KES',
    symbol: 'KSh',
    displayName: 'Kenyan Shilling',
    decimals: 2,
    minAmount: 500,        // ~$3.50 USD minimum
    maxAmount: 1500000,    // ~$10,500 USD maximum
  }],
  paymentMethods: [
    {
      type: 'mobile_money',
      name: 'M-Pesa',
      provider: 'flutterwave',
      enabled: true,
      processingTime: 'instant',
      fees: { fixed: 0, percentage: 1.4 },
    },
    {
      type: 'card',
      name: 'Visa/Mastercard',
      provider: 'flutterwave',
      enabled: true,
      processingTime: 'instant',
      fees: { fixed: 0, percentage: 3.5 },
    },
    {
      type: 'bank',
      name: 'Bank Transfer',
      provider: 'flutterwave',
      enabled: true,
      processingTime: '1-2 days',
      fees: { fixed: 100, percentage: 0 },
    },
  ],
};
```

### Cross-Border Considerations

**For Alinka Service Providers**:

When a DAO in the US hires a service provider in the Philippines:

1. **DAO Treasury**: Holds USDC (stable value)
2. **Service Agreement**: Price quoted in USD (universal reference)
3. **Payment Execution**: USDC sent on-chain
4. **Provider Receives**: Can hold USDC or off-ramp to PHP via local exchange

```
US-based DAO                           PH-based Provider
     │                                        │
     │  Service Agreement: $500               │
     │                                        │
     │  ┌────────────────────────────────┐   │
     │  │     On-Chain Payment           │   │
     │  │                                │   │
     │  │  500 USDC → provider.eth      │   │
     │  └────────────────────────────────┘   │
     │                                        │
     │                                        ▼
     │                               ┌──────────────────┐
     │                               │  Provider Choice │
     │                               │                  │
     │                               │  □ Hold as USDC  │
     │                               │  □ Off-ramp PHP  │
     │                               │    (~₱28,000)    │
     │                               └──────────────────┘
```

**For Alinka Course Purchases**:

When a user in Kenya buys an Alinka course:

1. **User Pays**: KES 15,000 via M-Pesa
2. **Flutterwave**: Converts to USD, settles to Alinka
3. **Alinka Records**: $100 USD course purchase
4. **If DAO-Funded**: Alinka invoices DAO treasury in USDC

---

## White-Label EnDAO Integration

### Overview

Alinka (or any partner) can deploy customized EnDAO instances for their user base while maintaining the full governance and treasury infrastructure.

**Use Cases**:
- **Alinka Cooperatives**: Alinka-branded DAOs for service provider cooperatives
- **Financial Institution Partners**: Banks/MFIs offering DAO products to clients
- **NGO Deployments**: Aid organizations creating community DAOs
- **Corporate Clients**: Enterprises deploying internal governance

### White-Label Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         White-Label Deployment Model                             │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    EnDAO Core Infrastructure                             │   │
│   │                                                                          │   │
│   │  • Governance Engine         • Treasury (Safe) Integration              │   │
│   │  • Voting System             • Token Infrastructure (EDG/TCR/TEQ)       │   │
│   │  • Proposal Workflows        • API Layer                                │   │
│   │  • Member Management         • Notification System                      │   │
│   └──────────────────────────────────┬──────────────────────────────────────┘   │
│                                      │                                          │
│          ┌───────────────────────────┼───────────────────────────┐              │
│          │                           │                           │              │
│          ▼                           ▼                           ▼              │
│   ┌──────────────┐           ┌──────────────┐           ┌──────────────┐       │
│   │   EnDAO.ai   │           │   Alinka     │           │   Partner    │       │
│   │  (Default)   │           │  White-Label │           │  White-Label │       │
│   │              │           │              │           │              │       │
│   │  Standard    │           │  • Logo      │           │  • Custom    │       │
│   │  branding    │           │  • Colors    │           │    branding  │       │
│   │              │           │  • Domain    │           │  • Domain    │       │
│   │  endao.ai    │           │  • Templates │           │  • Templates │       │
│   │              │           │              │           │              │       │
│   │  daos.       │           │  coops.      │           │  partner.    │       │
│   │  alinka.org  │           │  alinka.org  │           │  example.com │       │
│   └──────────────┘           └──────────────┘           └──────────────┘       │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### White-Label Configuration

```typescript
interface WhiteLabelConfig {
  // Identity
  partnerId: string;
  partnerName: string;

  // Branding
  branding: {
    logo: {
      primary: string;      // URL to logo
      dark: string;         // Dark mode variant
      favicon: string;      // Browser icon
    };
    colors: {
      primary: string;      // '#8B4513' (Alinka brown)
      secondary: string;
      accent: string;
      background: string;
      text: string;
    };
    fonts: {
      heading: string;
      body: string;
    };
    customCss?: string;     // Additional CSS overrides
  };

  // Domain
  domain: {
    custom: string;         // 'coops.alinka.org'
    subdomain?: string;     // Alternative: 'alinka.endao.ai'
  };

  // Templates
  templates: {
    daoTypes: string[];     // ['cooperative', 'savings_group', 'producer_org']
    proposalTypes: string[]; // ['grant', 'loan_request', 'member_admit']
    onboardingFlows: string[]; // Custom onboarding per DAO type
  };

  // Features
  features: {
    enableTokens: boolean;      // EDG/TCR/TEQ functionality
    enableMarketplace: boolean; // Service marketplace
    enableLoans: boolean;       // Alinka loan integration
    enableCourses: boolean;     // Alinka course integration
    customModules: string[];    // Partner-specific features
  };

  // Admin Access
  partnerAdmin: {
    observerAccess: boolean;    // Can view all DAOs in deployment
    rollupDashboard: boolean;   // Aggregated metrics view
    supportAccess: boolean;     // Help desk integration
  };

  // Data Isolation
  dataIsolation: 'shared' | 'dedicated';
  // 'shared': Uses main EnDAO database with partition
  // 'dedicated': Separate database instance (enterprise)
}
```

### Alinka-Specific White-Label

```typescript
const alinkaWhiteLabelConfig: WhiteLabelConfig = {
  partnerId: 'alinka',
  partnerName: 'Alinka',

  branding: {
    logo: {
      primary: 'https://alinka.org/assets/logo.png',
      dark: 'https://alinka.org/assets/logo-dark.png',
      favicon: 'https://alinka.org/assets/favicon.ico',
    },
    colors: {
      primary: '#8B4513',       // Saddle brown
      secondary: '#D2691E',     // Chocolate
      accent: '#CD853F',        // Peru
      background: '#FDF5E6',    // Old lace
      text: '#2C1810',          // Dark brown
    },
    fonts: {
      heading: 'Poppins',
      body: 'Inter',
    },
  },

  domain: {
    custom: 'coops.alinka.org',
  },

  templates: {
    daoTypes: [
      'service_provider_cooperative',
      'producer_organization',
      'savings_group',
      'learning_community',
      'mentor_network',
    ],
    proposalTypes: [
      'member_admission',
      'loan_request',
      'grant_application',
      'service_offering',
      'course_development',
    ],
    onboardingFlows: [
      'cooperative_formation',     // Guide for forming a cooperative
      'provider_onboarding',       // Service provider joining process
      'savings_group_setup',       // Community savings group creation
    ],
  },

  features: {
    enableTokens: true,            // Full token support
    enableMarketplace: true,       // Alinka services via marketplace
    enableLoans: true,             // Alinka loan integration
    enableCourses: true,           // Alinka course integration
    customModules: [
      'alinka_loan_widget',        // Embedded loan application
      'alinka_course_catalog',     // Course browser
      'alinka_mentor_match',       // Mentor discovery
      'business_metrics_tracker',  // Entrepreneur KPIs
    ],
  },

  partnerAdmin: {
    observerAccess: true,          // Alinka can observe all DAOs
    rollupDashboard: true,         // Aggregated cooperative metrics
    supportAccess: true,           // Integrated support
  },

  dataIsolation: 'shared',         // Shared infrastructure, logical isolation
};
```

### Roll-Up Dashboard for Partners

Partners get a consolidated view across all DAOs in their white-label deployment:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                     Alinka Partner Dashboard                                     │
│                     coops.alinka.org/admin                                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐        │
│   │   47        │   │   1,248     │   │  $145,000   │   │    89%      │        │
│   │   DAOs      │   │   Members   │   │  Treasury   │   │  Active     │        │
│   │   Active    │   │   Total     │   │  Combined   │   │  Rate       │        │
│   └─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘        │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    DAOs by Type                                          │   │
│   │                                                                          │   │
│   │   Service Cooperatives    ████████████████████  23 (49%)                │   │
│   │   Producer Organizations  ████████████          12 (26%)                │   │
│   │   Savings Groups          ██████████            10 (21%)                │   │
│   │   Learning Communities    ██                     2 (4%)                 │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    Recent Activity                                       │   │
│   │                                                                          │   │
│   │   🟢 Nakuru Artisans Coop - New member joined - 2h ago                  │   │
│   │   🔵 Manila Tutors Guild - Proposal passed - 5h ago                     │   │
│   │   💰 Accra Tech Services - Treasury deposit $2,400 - 8h ago             │   │
│   │   📚 Lagos Learning Hub - Course bulk purchase - 1d ago                 │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    Alinka Integration Metrics                            │   │
│   │                                                                          │   │
│   │   Loans Originated via DAOs:        $89,000 (23 loans)                  │   │
│   │   Courses Purchased:                412 enrollments                      │   │
│   │   Service Contracts:                67 completed                         │   │
│   │   Mentor Sessions:                  156 hours                            │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### White-Label Revenue Model

```typescript
interface WhiteLabelPricing {
  // Base platform fee shared between EnDAO and partner
  platformFeeShare: {
    standard: { endao: 60, partner: 40 };    // % split
    enterprise: { endao: 50, partner: 50 };  // Higher volume = better split
  };

  // Additional revenue streams for partner
  partnerRevenue: {
    customModules: boolean;      // Partner can charge for custom features
    supportTier: boolean;        // Partner provides premium support
    onboarding: boolean;         // Partner charges for setup assistance
  };

  // Volume discounts
  volumeTiers: {
    starter: { daosUpTo: 10, discount: 0 };
    growth: { daosUpTo: 50, discount: 15 };
    scale: { daosUpTo: 200, discount: 25 };
    enterprise: { daosUpTo: Infinity, discount: 35 };
  };
}
```

### Implementation Timeline

| Phase | Capabilities | Timeline |
|-------|--------------|----------|
| **Phase 1: Basic Theming** | Logo, colors, custom domain | Q2 2026 |
| **Phase 2: Template Library** | Partner-specific DAO types, proposal templates | Q2 2026 |
| **Phase 3: Partner Dashboard** | Observer access, roll-up metrics | Q3 2026 |
| **Phase 4: Custom Modules** | Partner-built integrations, embedded widgets | Q4 2026 |
| **Phase 5: Dedicated Instances** | Full data isolation for enterprise partners | 2027 |

---

## Platform Architecture

EnDAO and Alinka are separate products under the same parent organization (Village Micro Fund). Users may use one, the other, or both. The integration is **optional** - neither platform requires the other to function.

### Current Platform State

| Platform | Web | Mobile | Backend | Auth |
|----------|-----|--------|---------|------|
| **EnDAO** | ✅ Next.js 15 | 🚧 Expo (in development) | Supabase/PostgreSQL | Privy |
| **Alinka** | 🚧 Planned | ✅ Expo | PostgreSQL + MongoDB | Firebase Auth |

### Platform Relationship Model

```
┌─────────────────────────────────────────────────────────────────┐
│                    Village Micro Fund                            │
│                                                                  │
│   ┌─────────────────────┐       ┌─────────────────────────┐     │
│   │       EnDAO         │       │        Alinka           │     │
│   │   (Governance)      │◄─────►│   (Entrepreneurship)    │     │
│   │                     │ opt-in│                         │     │
│   │   Web ✅  Mobile 🚧 │       │   Mobile ✅  Web 🚧     │     │
│   └─────────────────────┘       └─────────────────────────┘     │
│                                                                  │
│   Users can use one, the other, or both                         │
└─────────────────────────────────────────────────────────────────┘
```

**Key Principle**: Each platform operates independently. Integration features enhance the experience for users who choose to use both, but are never required.

---

### Layer 1: Shared Identity (Foundation)

The foundation of cross-platform integration is a unified or linked identity system.

| Component | Purpose | Implementation |
|-----------|---------|----------------|
| **SSO Bridge** | One login works for both | OAuth 2.0 between Privy ↔ Firebase, or migrate to shared provider |
| **Linked Accounts** | Optional - user chooses to connect | `linked_accounts` table: `{user_id, platform, external_id}` |
| **Shared Profile Service** | Basic profile data synced if linked | API endpoint each platform exposes |

**User Journey (Account Linking)**:

```
User signs up on Alinka
    ↓
Uses Alinka independently (no EnDAO knowledge needed)
    ↓
Later, discovers DAO governance features
    ↓
"Sign in with Alinka" on EnDAO (SSO)
    ↓
Accounts now linked - credentials carry over automatically
```

#### SSO Implementation Options

Three viable approaches for cross-platform authentication, each with distinct tradeoffs:

**Option 1: Migrate Both to Privy**

Alinka adopts Privy as its auth provider, matching EnDAO.

| Pros | Cons |
|------|------|
| Single auth provider = simpler architecture | Alinka migration effort required |
| Privy handles crypto + email + social natively | Firebase Auth features may need replacement |
| Shared user identity out of the box | Learning curve for Alinka team |
| Wallet connectivity for future crypto features | Privy costs scale with users |
| Proven at scale in EnDAO | Dependency on single vendor |

**Option 2: OAuth Bridge (Federation)**

Each platform keeps its auth provider; they trust each other's tokens via OAuth 2.0.

| Pros | Cons |
|------|------|
| No migration required | More complex architecture |
| Each platform controls own auth | Token exchange latency |
| Gradual rollout possible | Must maintain two auth systems |
| Teams work independently | Session sync complexity |
| Lower immediate cost | Security surface area larger |

```
┌─────────────┐         ┌─────────────┐
│   EnDAO     │         │   Alinka    │
│   (Privy)   │◄──OAuth─►│  (Firebase) │
└──────┬──────┘         └──────┬──────┘
       │                       │
       └───────────┬───────────┘
                   ▼
          ┌───────────────┐
          │ Linked Account │
          │    Service     │
          └───────────────┘
```

**Option 3: Shared Auth Service (New Provider)**

Both platforms migrate to a neutral third provider (Auth0, Clerk, Supabase Auth, etc.).

| Pros | Cons |
|------|------|
| True unified identity | Both platforms must migrate |
| Vendor-neutral choice | Higher upfront effort |
| Can choose best-fit provider | Coordination between teams |
| Clean architecture | Temporary parallel auth during migration |
| Scales to additional VMF products | Selection process takes time |

**Recommendation**: Decision deferred. Factors to consider:
- Alinka's timeline for web app (affects auth requirements)
- Crypto wallet needs for Alinka users
- Team bandwidth for migration work
- Long-term VMF product roadmap (more products = shared auth more valuable)

---

### Layer 2: Cross-Platform Discovery

Users of one platform can discover relevant features from the other.

| Feature | In EnDAO | In Alinka |
|---------|----------|-----------|
| **Service Discovery** | "Hire from Alinka" when creating bounty proposals | N/A |
| **Governance Discovery** | N/A | "Create a DAO for your collective" for provider groups |
| **Credential Display** | Alinka certifications shown on member profiles | DAO memberships shown on provider profiles |
| **Cross-Promotion** | Alinka courses suggested for skill gaps | EnDAO suggested for groups seeking governance |

**Implementation**: Feature flags control visibility. Discovery features only appear when:
1. User has linked accounts, OR
2. Platform-level integration is enabled for that DAO/provider group

---

### Layer 3: Integration API

Each platform exposes a limited, purpose-built API for the other.

**EnDAO Integration API** (exposed to Alinka):

```typescript
interface EnDAOIntegrationAPI {
  // Verify user is member of a DAO
  verifyMembership(userId: string, daoId: string): Promise<{
    isMember: boolean;
    role: 'admin' | 'member' | 'observer' | null;
    joinedAt: string | null;
  }>;

  // Get user's DAO memberships (for profile display)
  getUserDAOs(userId: string): Promise<{
    daoId: string;
    daoName: string;
    role: string;
    memberSince: string;
  }[]>;

  // Get active bounty/service proposals (for provider matching)
  getActiveServiceRequests(daoId: string): Promise<{
    proposalId: string;
    title: string;
    budget: number;
    skills: string[];
    deadline: string;
  }[]>;

  // Verify DAO exists and is active
  verifyDAO(daoId: string): Promise<{
    exists: boolean;
    name: string;
    status: 'active' | 'archived' | 'deleted';
  }>;
}
```

**Alinka Integration API** (exposed to EnDAO):

```typescript
interface AlinkaIntegrationAPI {
  // Get provider profile and credentials
  getProviderProfile(userId: string): Promise<{
    displayName: string;
    skills: string[];
    certifications: Certification[];
    rating: number;
    completedProjects: number;
  }>;

  // Search available providers for bounty matching
  searchProviders(criteria: {
    skills: string[];
    availability: 'immediate' | 'within_week' | 'within_month';
    budgetRange?: { min: number; max: number };
  }): Promise<ProviderSummary[]>;

  // Verify course/certification completion
  verifyCertification(userId: string, certificationId: string): Promise<{
    valid: boolean;
    courseName: string;
    completedAt: string;
    expiresAt: string | null;
  }>;

  // Get loan eligibility (for treasury-backed financing)
  checkLoanEligibility(userId: string, amount: number): Promise<{
    eligible: boolean;
    maxAmount: number;
    reason?: string;
  }>;
}
```

**API Security**:
- Mutual TLS or API keys for service-to-service calls
- Rate limiting per platform
- Audit logging for all cross-platform requests
- Data minimization - only expose what's needed

---

### Layer 4: Mobile Deep Linking

Both apps register URL schemes for cross-app navigation.

**EnDAO Deep Links** (`endao://`):

| Path | Purpose | Example |
|------|---------|---------|
| `/dao/{id}` | Open DAO page | `endao://dao/abc123` |
| `/proposal/{id}` | Open proposal | `endao://proposal/xyz789` |
| `/member/{id}` | Open member profile | `endao://member/user456` |
| `/connect-alinka` | Initiate account linking | `endao://connect-alinka?token=...` |

**Alinka Deep Links** (`alinka://`):

| Path | Purpose | Example |
|------|---------|---------|
| `/provider/{id}` | Open provider profile | `alinka://provider/abc123` |
| `/course/{id}` | Open course details | `alinka://course/xyz789` |
| `/service/{id}` | Open service listing | `alinka://service/svc456` |
| `/connect-endao` | Initiate account linking | `alinka://connect-endao?token=...` |

**Fallback Behavior**:
- If target app not installed → Open web version (when available)
- If web not available → App store / Play store link
- Universal links for iOS, App Links for Android

---

### Layer 5: Shared Infrastructure

Components owned collaboratively or by Village Micro Fund.

| Component | Owner | Purpose |
|-----------|-------|---------|
| `@vmf/shared-types` | Shared npm package | TypeScript types for integration APIs |
| `@vmf/ui-components` | Optional shared package | Common UI patterns (if desired) |
| Deep Link Registry | Both platforms | Maintain and test cross-app navigation |
| Integration API Docs | Both platforms | OpenAPI specs for integration endpoints |

**Shared Types Example**:

```typescript
// @vmf/shared-types

// Common user identity across platforms
export interface LinkedIdentity {
  vmfUserId: string;           // Village Micro Fund canonical ID
  endaoUserId?: string;        // EnDAO-specific ID
  alinkaUserId?: string;       // Alinka-specific ID
  linkedAt?: string;           // When accounts were connected
}

// Credential that can be displayed on either platform
export interface CrossPlatformCredential {
  source: 'endao' | 'alinka';
  type: 'dao_membership' | 'certification' | 'course_completion';
  name: string;
  issuedAt: string;
  expiresAt?: string;
  verificationUrl: string;
}

// Service request that Alinka providers can fulfill
export interface ServiceRequest {
  id: string;
  daoId: string;
  daoName: string;
  title: string;
  description: string;
  budget: { amount: number; currency: string };
  skills: string[];
  deadline: string;
  status: 'open' | 'in_progress' | 'completed' | 'cancelled';
}
```

---

### Platform Development Requirements

What each platform needs to build for full integration:

**EnDAO Requirements**:

| Component | Priority | Status |
|-----------|----------|--------|
| Mobile app (Expo) | High | 🚧 In development |
| Alinka integration API endpoints | Medium | Not started |
| Deep link handling | Medium | Not started |
| Account linking UI | Medium | Not started |
| Alinka provider search in bounty flow | Low | Not started |

**Alinka Requirements**:

| Component | Priority | Status |
|-----------|----------|--------|
| Web application | Medium | 🚧 Planned |
| EnDAO integration API endpoints | Medium | Not started |
| SSO support (Privy or OAuth) | Medium | Not started |
| Deep link handling | Medium | Not started |
| Account linking UI | Medium | Not started |
| DAO membership display | Low | Not started |

**Shared Requirements**:

| Component | Priority | Owner |
|-----------|----------|-------|
| SSO architecture decision | High | VMF / Both teams |
| `@vmf/shared-types` package | Medium | VMF |
| Integration API specifications | Medium | Both teams |
| Deep link registry documentation | Low | Both teams |

---

## Platform Integration Opportunities

Beyond the core service integrations, several EnDAO platform features offer significant value for Alinka's fiat-first, non-crypto user base.

### Email Participation

Critical for users who won't check apps daily. Enables governance participation through familiar email workflows.

**Capabilities**:

| Feature | Description | Alinka Use Case |
|---------|-------------|-----------------|
| **Vote via Email Reply** | Reply "Yes" or "No" to cast vote | Cooperative members vote without app login |
| **Weekly Digest** | Automated governance summary email | Keep entrepreneurs informed of DAO activity |
| **Comment via Reply** | Email replies route to discussion threads | Participate in loan discussions via inbox |
| **SMS Critical Alerts** | Text messages for urgent governance events | Treasury alerts, vote deadlines, security events |

**Implementation**:

```typescript
interface EmailParticipationConfig {
  // Per-DAO settings
  enableEmailVoting: boolean;
  enableEmailComments: boolean;
  digestFrequency: 'daily' | 'weekly' | 'none';

  // SMS (premium feature)
  smsEnabled: boolean;
  smsCategories: ('voting' | 'treasury' | 'security')[];

  // Security
  requireSignedToken: boolean;    // Prevent email spoofing
  rateLimitPerHour: number;       // Prevent spam
}
```

**Alinka Benefits**:
- Entrepreneurs in low-connectivity areas can participate via basic email
- Mobile money users already comfortable with SMS-based transactions
- Reduces barriers for non-technical cooperative members
- Increases governance participation rates

---

### Calendar Sync

Governance deadlines visible in familiar calendar applications.

**Capabilities**:

| Event Type | Calendar Entry | Alinka Use Case |
|------------|----------------|-----------------|
| **Proposal Vote Deadline** | "Vote ends: Budget Proposal" with 24h reminder | Cooperative never misses important votes |
| **Loan Repayment Due** | Recurring events for loan schedule | Entrepreneur sees obligations in calendar |
| **Course Enrollment Window** | Application period start/end | Members plan training schedule |
| **Governance Meeting** | Scheduled meeting with agenda link | Cooperative coordination |

**Implementation**:

```typescript
interface CalendarIntegration {
  // iCal feed URL (per user or per DAO)
  icalFeedUrl: string;

  // Sync options
  syncProviders: ('google' | 'outlook' | 'apple' | 'ical')[];

  // Event types to include
  eventTypes: {
    proposalDeadlines: boolean;
    treasuryEvents: boolean;
    meetingSchedules: boolean;
    memberMilestones: boolean;
    loanSchedules: boolean;       // Alinka-specific
    courseDeadlines: boolean;     // Alinka-specific
  };

  // Reminder settings
  defaultReminders: {
    voteDeadline: '24h' | '48h' | '1w';
    paymentDue: '3d' | '1w';
  };
}
```

**Alinka Benefits**:
- Entrepreneurs manage business + governance in one calendar
- Loan repayment reminders reduce defaults
- Course enrollment windows don't get missed
- Cooperative meetings visible to all members

---

### Implementation Tracking

Visibility into execution of approved proposals - from vote passage to completion.

**Capabilities**:

| Status | Description | Alinka Use Case |
|--------|-------------|-----------------|
| **Awaiting Start** | Proposal passed, not yet begun | Loan approved, awaiting disbursement |
| **In Progress** | Active execution | Course curriculum being developed |
| **Blocked** | Issue preventing progress | Vendor payment stuck, needs resolution |
| **Completed** | Evidence attached, verified done | Bounty work delivered and confirmed |

**Implementation**:

```typescript
interface ImplementationTracking {
  proposalId: string;

  // Status workflow
  status: 'awaiting_start' | 'in_progress' | 'blocked' | 'completed';

  // Assignment
  assignedTo: string;             // Member responsible
  assignedAt: Timestamp;

  // Progress
  progressNotes: string[];
  blockerDescription?: string;

  // Completion
  evidenceUrls: string[];         // Proof of completion
  completedAt?: Timestamp;
  verifiedBy?: string;            // Admin who verified

  // Alinka-specific
  alinkaServiceType?: 'loan' | 'course' | 'bounty' | 'mentorship';
  externalReferenceId?: string;   // Alinka loan ID, course ID, etc.
}
```

**Alinka Benefits**:
- Track loan disbursement from approval to funds received
- Monitor bounty fulfillment with evidence attachment
- Verify course completion with certification documents
- Accountability for all governance decisions

---

### Data Management System

Comprehensive data handling for growing platform complexity - covering import, organization, and reporting.

#### Data Import & Migration

Efficiently onboard users and historical data from Alinka systems.

```typescript
interface DataImportConfig {
  // Supported import types
  importTypes: {
    members: {
      sources: ('csv' | 'json' | 'api_sync')[];
      fieldMapping: Record<string, string>;  // Alinka field → EnDAO field
      deduplication: 'email' | 'phone' | 'name_fuzzy';
    };
    transactions: {
      sources: ('csv' | 'bank_statement' | 'api_sync')[];
      reconciliation: boolean;
    };
    serviceHistory: {
      sources: ('alinka_api' | 'csv')[];
      preserveTimestamps: boolean;
    };
  };

  // Validation
  validation: {
    requiredFields: string[];
    formatValidation: boolean;
    duplicateHandling: 'skip' | 'merge' | 'flag';
  };

  // Scheduling
  syncSchedule?: {
    frequency: 'realtime' | 'hourly' | 'daily';
    source: 'alinka_api';
    lastSync: Timestamp;
  };
}
```

#### Document Organization

Structured storage and retrieval for governance documents.

```typescript
interface DocumentManagement {
  // Document types
  documentTypes: {
    governance: ('bylaws' | 'minutes' | 'resolutions')[];
    financial: ('budgets' | 'statements' | 'receipts')[];
    compliance: ('filings' | 'licenses' | 'audits')[];
    alinka: ('loan_applications' | 'business_plans' | 'certifications')[];
  };

  // Organization
  tagging: {
    autoTag: boolean;              // AI-assisted categorization (optional)
    requiredTags: string[];        // Mandatory metadata
    customTags: boolean;           // User-defined tags
  };

  // Versioning
  versionControl: {
    enabled: boolean;
    maxVersions: number;
    diffView: boolean;
  };

  // Search
  search: {
    fullText: boolean;             // Search within document content
    tagFiltering: boolean;
    dateRangeFiltering: boolean;
  };

  // Retention
  retention: {
    defaultPeriod: '7y' | '10y' | 'indefinite';
    complianceHolds: boolean;      // Prevent deletion during audits
  };
}
```

#### Reporting Integration

Cross-platform analytics combining Alinka service data with EnDAO governance metrics.

```typescript
interface ReportingIntegration {
  // Report types
  reportTypes: {
    governance: {
      proposalMetrics: boolean;    // Pass rate, participation, timing
      memberActivity: boolean;     // Engagement levels
      treasuryHealth: boolean;     // Balance, flow, burn rate
    };
    alinka: {
      loanPerformance: boolean;    // Disbursement, repayment, defaults
      courseEnrollment: boolean;   // Completion rates, satisfaction
      serviceUtilization: boolean; // Provider engagement
    };
    combined: {
      impactMetrics: boolean;      // Cross-platform outcomes
      cohortAnalysis: boolean;     // DAO member journey
    };
  };

  // Scheduling
  scheduling: {
    automated: boolean;
    frequency: 'weekly' | 'monthly' | 'quarterly';
    recipients: string[];          // Email distribution
  };

  // Export
  export: {
    formats: ('pdf' | 'csv' | 'xlsx')[];
    branding: boolean;             // White-label report headers
    complianceReady: boolean;      // Audit-formatted exports
  };

  // Partner Dashboard
  partnerRollup: {
    enabled: boolean;
    aggregationLevel: 'dao' | 'region' | 'cohort';
    benchmarking: boolean;         // Compare DAOs within portfolio
  };
}
```

**Alinka Benefits**:
- Single source of truth for member data across platforms
- Loan applications stored with proposals for complete audit trail
- Impact reports combining governance + service outcomes
- Partner dashboard shows portfolio-wide performance

---

### AI Agent Integration (Future)

When EnDAO's AI Agent infrastructure matures (Tier 4), several agents offer high value for Alinka integrations.

| Agent | Alinka Use Case | Authority Scope |
|-------|-----------------|-----------------|
| **Secretary Agent** | Auto-generate cooperative meeting minutes, track loan committee decisions | Read-only, human approves output |
| **Analyst Agent** | Risk assessment for loan proposals, flag applications similar to past defaults | Advisory only |
| **Treasury Agent** | Execute routine Alinka service payments within pre-approved limits | Spend within voted parameters |
| **Delegate Agent** | Auto-vote for busy entrepreneurs based on stated preferences | Revocable delegation |
| **Compliance Agent** | Track CTA/BOI filings for cooperatives, prepare regulatory reports | Read + prepare, human certifies |

**Prerequisites**:
- EnDAO Tier 3 AI Infrastructure (API key auth, agent member type, delegation registry)
- EnDAO Tier 4 Agent implementation
- Human-in-loop triggers for high-stakes decisions

**Timeline**: Agent integration available after EnDAO Tier 4 completion (2027+)

---

## Appendix: Glossary

| Term | Definition |
|------|------------|
| **DAO-Level Access** | Services purchased by DAO treasury with governance approval |
| **Individual-Level Access** | Services purchased by members personally with membership benefits |
| **Credit Boost** | Better loan terms due to verified DAO membership |
| **Member Discount** | Price reduction on Alinka services for verified DAO members |
| **Co-Signed Loan** | Member loan with DAO treasury as partial guarantor |
| **Organization Loan** | Loan taken by the DAO itself for operational purposes |
| **Membership Credential** | Verifiable proof of DAO membership status and tier |
| **Escrow** | Treasury funds locked as collateral for loan backing |
| **EDG** | EnDAO Governance Token - protocol governance and fee discounts |
| **TCR** | Treasury Credit - stablecoin-pegged payment token for services |
| **TEQ** | Token of Labor Equity - soulbound token representing work contribution |
| **LaborOracle** | Decentralized rate feed for fair market labor pricing |
| **Sub-DAO** | Nested organization within a parent DAO. Note: Not applicable to Alinka integration since Alinka is a platform, not a parent DAO. Service providers form independent DAOs instead. |
| **ServiceMarketplace** | EnDAO's platform for DAO-to-provider service transactions |
| **Double-Dip** | Earning both TCR (payment) and TEQ (equity) for work |
| **Fiat-First** | Payment strategy prioritizing traditional currency methods (card, bank) with crypto as optional |
| **Fiat-to-Treasury Bridge** | Service converting fiat payments to stablecoin for deposit in DAO treasury |
| **Crypto On-Ramp** | Service (Stripe/Circle) that converts fiat currency to cryptocurrency |
| **Off-Ramp** | Conversion of cryptocurrency back to local fiat currency |
| **Mobile Money** | Phone-based payment systems (M-Pesa, GCash) popular in emerging markets |
| **White-Label** | Customized deployment with partner branding, domain, and templates |
| **Roll-Up Dashboard** | Aggregated view of metrics across all DAOs in a partner deployment |
| **Partner Admin** | Observer-level access for white-label partners to monitor their DAOs |
| **Data Isolation** | Separation of data between white-label deployments (shared or dedicated) |
| **Email Participation** | Governance participation via email replies - voting, commenting, and digest |
| **Calendar Sync** | Integration of governance deadlines and events with external calendar apps |
| **Implementation Tracking** | Status workflow for post-proposal execution (awaiting → in progress → completed) |
| **Data Management System** | Comprehensive handling of data import, document organization, and reporting |
| **AI Agent** | Autonomous AI participant in governance with scoped authority and human oversight |
| **Secretary Agent** | AI agent for meeting minutes, action items, and routine Q&A |
| **Analyst Agent** | AI agent for proposal risk assessment and impact analysis |
| **Treasury Agent** | AI agent for routine treasury operations within voted parameters |
| **Delegate Agent** | AI agent that votes on behalf of members per stated preferences |
| **Compliance Agent** | AI agent for regulatory monitoring and filing preparation |
| **SSO (Single Sign-On)** | Authentication allowing one login to access multiple platforms |
| **OAuth** | Authorization protocol enabling platforms to trust each other's tokens |
| **Deep Linking** | URL scheme (e.g., `endao://`, `alinka://`) for navigating directly into mobile apps |
| **Linked Accounts** | User accounts on different platforms connected to share identity/data |
| **Integration API** | Purpose-built API endpoints for cross-platform data exchange |
| **@vmf/shared-types** | Shared TypeScript package for common types across VMF platforms |
| **Privy** | Authentication provider used by EnDAO supporting crypto + email + social login |
| **Firebase Auth** | Google's authentication service currently used by Alinka |
| **Account Linking** | Process of connecting existing accounts across platforms for unified experience |

---

*Document Version: 2.4*
*Last Updated: January 2026*
*Authors: EnDAO Engineering Team*

**Version History**:
- v2.4 - Added Platform Architecture section: SSO options (Privy migration, OAuth bridge, shared provider) with pros/cons, cross-platform discovery, Integration APIs, deep linking, shared infrastructure requirements
- v2.3 - Clarified that Alinka service provider collectives form independent DAOs, not Sub-DAOs (Alinka is a platform, not a parent DAO). Added that collectives CAN use Sub-DAOs internally for their own governance structure.
- v2.2 - Added Platform Integration Opportunities: Email Participation, Calendar Sync, Implementation Tracking, Data Management System, AI Agent Integration (Future)
- v2.1 - Added Payment Strategy (Fiat-First), International Payment Support, White-Label Integration sections
- v2.0 - Added Future Roadmap Use Cases aligned with TOKEN_ROADMAP.md
- v1.0 - Initial integration design
