# Ghana Chamber of Cannabis Industry - White-Label Platform

**Status**: Active Partnership - MVP Scoping
**Date**: February 2026
**Partners**: Ghana Chamber of Cannabis Industry (GCCI), The Kingdom Collective Group (KCG), EnDAO/Allinka
**Classification**: CONFIDENTIAL

---

## Partnership Context

The Kingdom Collective Group (KCG) and the Ghana Chamber of Cannabis Industry (GCCI), in conjunction with the Africa International Chamber of Commerce and Industry (AICCI), have established a formal strategic partnership to develop a sustainable cannabis and hemp ecosystem in Ghana. The partnership spans 36 months with provisions for renewal.

EnDAO/Allinka's role is **platform development partner** - building a Chamber-branded white-label digital platform on top of and integrated with the existing EnDAO and Allinka platforms. The platform supports implementation of systems and workflows defined under the KCG-GCCI Strategic Partnership Agreement.

### Key Partnership Outcomes

1. **National Hemp Licensing System** - Ghana's 11-license classification framework
2. **Hemp-to-Market Workforce & Impact Model** - Seed-to-sale, training-to-trade, capital-to-consumer ecosystem
3. **Kingdom Wealth Hub-Ghana** - Centralized cultivation, processing, training, and investment hub
4. **Parliamentary Presentation** - National adoption and funding (targeted June 2025)
5. **Bi-National Delegation** - Ghana-Georgia (USA) exchange programs for trade and knowledge transfer

### Funding Contingency

All obligations are contingent upon successful capital raising by both GCCI and KCG. No work commences until sufficient funding is secured to the reasonable satisfaction of both parties.

---

## MVP Functional Requirements

The MVP is intentionally phase-limited for speed, regulatory alignment, and cost control. The following modules are **in scope** for Phase 1.

### A. Chamber Profile & Authority Layer

| Requirement | EnDAO Feature |
|-------------|---------------|
| Branded Chamber landing page (logo, colors, mission) | White-label theming system |
| Chamber verification badge (apex authority) | Organization verification badges |
| Public vs. member-only content controls | Role-based content visibility |
| Announcements, advisories, regulatory updates | DAO announcement/notification system |

### B. Member & Operator Management

**Role-based onboarding and approval for:**
- Farmers / Cultivators
- Processors / Manufacturers
- Exporters / Distributors
- Testing & QA providers
- Trainers / Educational partners
- Investors / Strategic partners

| Requirement | EnDAO Feature |
|-------------|---------------|
| Vetting workflow (documents, status, approval) | Membership approval with document upload |
| Member profile with compliance status | User profiles with activity logs |
| Role-based access control | Existing RBAC system |

### C. Licensing & Regulatory Workflow (MVP Priority)

This is the highest-priority module, aligned to the **11-License Classification System**:

**Cultivation Licenses:**
- Small-Scale (up to 5 acres)
- Medium-Scale (5-20 acres)
- Large-Scale (20+ acres)
- Research & Development

**Processing Licenses:**
- Primary Processing (fiber, seeds)
- Secondary Processing (oils, extracts)
- Advanced Manufacturing (finished products)

**Distribution & Specialized Licenses:**
- Import-Export
- Educational/Training Provider
- Testing & Quality Assurance
- Seed Production & Genetics

| Requirement | EnDAO Feature |
|-------------|---------------|
| License type selection (11 types) | Proposal/workflow templates per license type |
| Digital intake and document upload | Secure document management |
| Status tracking (Draft -> Submitted -> Under Review -> Active -> Renewal) | Proposal lifecycle states |
| Renewal alerts and compliance reminders | Notification system |
| Chamber admin dashboard for oversight | Admin dashboard with escalation |

### D. Training & Certification (LMS-Enabled)

The Cannabis & Hemp Grower Academy is the educational backbone, powered by a blended LMS and hands-on training. KCG will develop 50 master trainers through a Train-the-Trainer model.

| Requirement | EnDAO/Allinka Feature |
|-------------|----------------------|
| License-aligned course catalog (11 pathways) | Allinka course catalog integration |
| Certification tracking by license type | Allinka certification system |
| Chamber-approved trainers and curricula | Vetted provider directory |
| Blended model support (online + field-based) | Allinka LMS + in-person tracking |

### E. Capital Access & Investment Readiness (Matching Only)

Supports the **Kingdom Impact Fund** structure - a co-ownership model for 1,000+ members targeting Ghanaian nationals, diaspora, and international investors.

| Requirement | EnDAO Feature |
|-------------|---------------|
| Capital intake forms (loan, grant, equity) | Structured proposal forms |
| Criteria-based matching (no custody of funds) | Matching/referral workflow |
| Investor opportunity listings (read-only or referral) | Public listing directory |
| Chamber visibility into capital readiness pipeline | Admin reporting dashboard |

**Explicit constraint**: No custody of funds, no automated approvals, no digital wallets in MVP.

### F. Equipment Rental/Purchase Module

Addresses a critical bottleneck in regulated production by enabling shared access to capital-intensive equipment.

| Requirement | EnDAO Feature |
|-------------|---------------|
| Equipment listings by category (cultivation, processing, testing, logistics) | Asset/resource directory |
| Availability indication (rent, lease, purchase) | Listing metadata |
| Equipment owner profiles (cooperatives, vendors) | Provider profiles |
| Request/inquiry workflow (no automated payments) | Inquiry/proposal workflow |
| Chamber oversight and approval of listed providers | Admin approval layer |

**Explicit constraints**: No automated payments, no escrow, no IoT tracking, no smart contracts in MVP.

### G. Compliance, Transparency & Governance

| Requirement | EnDAO Feature |
|-------------|---------------|
| Compliance checklist by license type | Checklist/milestone tracking |
| Chamber compliance dashboard | Admin compliance view |
| Activity logs for audits | Existing audit trail system |
| Optional EnDAO governance overlay | Permissioned, phase-gated DAO governance |

---

## Explicit MVP Exclusions

The following are **out of scope for Phase 1** to control regulatory risk, timeline, and cost:

- Custody of funds or digital wallets
- Automated loan or license approvals
- On-chain transactions or tokenization
- Equipment payments, escrow, or smart leasing
- Full marketplace functionality
- Advanced analytics or AI underwriting

---

## Phase Outlook

### Phase 2 - Regulated Transactions & Operational Scaling

- Custodial wallets or payment rails (via licensed partners)
- Equipment payments, leasing, or escrow
- Limited marketplace transactions (Chamber-approved vendors)
- Enhanced compliance automation (rule-based, non-AI)

### Phase 3 - Advanced Automation & Capital Enablement

- Automated loan/license decision support (human-in-the-loop)
- On-chain governance, tokenization, or asset tracking
- Advanced analytics, reporting, AI-assisted underwriting
- Cross-border settlement or trade-finance extensions

---

## Integration Architecture

### How EnDAO + Allinka Serves the KCG Model

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Hemp-to-Market Workforce & Impact Model           │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │  GROWER      │  │  GROWER      │  │  LICENSING   │             │
│  │  ZONES       │  │  ACADEMY     │  │  HUB         │             │
│  │              │  │              │  │              │             │
│  │  Cooperative  │  │  LMS +       │  │  11-License  │             │
│  │  cultivation  │  │  field       │  │  intake,     │             │
│  │  management   │  │  training    │  │  tracking,   │             │
│  │              │  │              │  │  compliance  │             │
│  │  EnDAO:      │  │  Allinka:    │  │  EnDAO:      │             │
│  │  DAO treasury │  │  Courses,    │  │  Workflow    │             │
│  │  governance   │  │  certs,      │  │  engine,     │             │
│  │  membership   │  │  trainers    │  │  dashboards  │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐                                │
│  │  PROCESSING  │  │  AGRITOURISM │                                │
│  │  FACILITIES  │  │  & CAPITAL   │                                │
│  │              │  │              │                                │
│  │  Equipment   │  │  Investment  │                                │
│  │  sharing,    │  │  readiness,  │                                │
│  │  vendor      │  │  fund        │                                │
│  │  management  │  │  matching    │                                │
│  │              │  │              │                                │
│  │  EnDAO:      │  │  EnDAO:      │                                │
│  │  Equipment   │  │  Capital     │                                │
│  │  module      │  │  intake,     │                                │
│  │              │  │  matching    │                                │
│  └──────────────┘  └──────────────┘                                │
└─────────────────────────────────────────────────────────────────────┘
```

### White-Label Configuration

```typescript
interface GCCIWhiteLabelConfig {
  branding: {
    name: "Ghana Chamber of Cannabis Industry";
    logo: "gcci-logo.png";
    colors: { primary: "#2D5016", accent: "#8BC34A" };
    domain: "platform.gcci.gh";
  };

  memberRoles: [
    "farmer-cultivator",
    "processor-manufacturer",
    "exporter-distributor",
    "testing-qa-provider",
    "trainer-educational-partner",
    "investor-strategic-partner",
  ];

  licenseTypes: [
    // Cultivation
    "small-scale-cultivation",
    "medium-scale-cultivation",
    "large-scale-cultivation",
    "research-development-cultivation",
    // Processing
    "primary-processing",
    "secondary-processing",
    "advanced-manufacturing",
    // Distribution & Specialized
    "import-export",
    "educational-training-provider",
    "testing-quality-assurance",
    "seed-production-genetics",
  ];

  equipmentCategories: [
    "cultivation-equipment",
    "processing-equipment",
    "testing-qa-equipment",
    "logistics-storage",
  ];

  complianceFeatures: {
    requireMemberVetting: true;
    documentUpload: true;
    auditTrailEnabled: true;
    renewalAlerts: true;
    chamberApprovalRequired: true;
  };

  governance: {
    jointSteeringCommittee: true;  // KCG + AICCI balanced representation
    quarterlyReporting: true;
  };
}
```

---

## MVP Success Criteria

The MVP is considered successful if it:

1. Supports at least 3 license pathways end-to-end
2. Enables Chamber-led vetting, training, and oversight
3. Demonstrates equipment access coordination
4. Is stable, auditable, and expandable without re-architecture

---

## IP & Authority Boundaries

All national licensing frameworks, training curricula, workforce models, and Hub-and-Spoke methodologies are the **intellectual property of The Kingdom Collective Group (KCG)** and are implemented within the platform under license or authorization. IP is not transferred, reassigned, sublicensed, or redefined through platform implementation.

---

## Budget Framework

### Pricing Basis

This MVP is built on top of two existing production platforms — EnDAO (governance, treasury, membership) and Allinka (education, courses). Approximately 40% of the MVP has working foundations in existing code. The budget reflects customization, extension, and new module development — not a ground-up build. This accelerates delivery and reduces cost while maintaining enterprise-grade quality.

### Phase 1 MVP Cost Breakdown

**A. Product & UX Design**

- User journey mapping (Chamber administrators + operators)
- Licensing and equipment workflows
- White-label theming (branding, colors, custom domain)

**Estimated Cost: $18,000 – $22,000**

*Basis: Core UX patterns and component library exist. Work is adapting flows to GCCI-specific journeys (license application, equipment inquiry, member vetting), not designing a UI system from scratch.*

---

**B. Platform Engineering**

- Multi-tenant architecture (tenant isolation, custom domain routing)
- Role-based access control (6 member roles + Chamber admin)
- Secure document storage (PDFs, DOCX, versioning, secure viewer)
- Equipment module (listing, inquiry workflow, admin approval)
- 11-license workflow engine (intake, document upload, status lifecycle, renewal alerts)
- Member vetting and approval pipeline

**Estimated Cost: $65,000 – $85,000**

*Basis: RBAC framework, proposal workflow engine, invitation/vetting system, audit trail, and admin dashboards exist. The license workflow extends the proposal lifecycle. Equipment module and multi-tenant isolation are new builds. Document storage extends existing image upload infrastructure to support PDFs and business documents.*

---

**C. LMS & Certification Integration**

- Course hosting and tracking (11 license-aligned pathways)
- Certification logic (issuance, expiration, renewal tracking)
- Trainer management (Chamber-approved trainers, qualification tracking)

**Estimated Cost: $25,000 – $35,000**

*Basis: Allinka provides course catalog, enrollment, and progress tracking foundations. New builds: certification issuance engine, trainer approval workflow, and lesson-level module delivery. Blended learning (field-based attendance) deferred to Phase 2.*

---

**D. Governance & Compliance Layer**

- Admin dashboards (Chamber oversight, member pipeline, license status)
- Compliance tracking (checklists by license type, renewal reminders)
- Audit logs (activity tracking for regulatory audits)
- EnDAO governance integration (permissioned DAO overlay, activated when Chamber is ready)

| Sub-Item | Cost |
|----------|------|
| Admin dashboards & compliance tracking | $10,000 – $14,000 |
| EnDAO governance overlay (proposals, voting, treasury visibility) | $5,000 – $8,000 |

**Estimated Cost: $15,000 – $22,000**

*Basis: EnDAO's audit trail system is 95% complete. Admin dashboard components exist and need Chamber-specific views. Compliance checklists are a new but lightweight data model. The governance overlay is built into the platform and activated when the Chamber chooses to enable member-facing governance features.*

---

**E. Security & Regulatory Readiness**

- Data privacy controls (Ghana Data Protection Act 843 alignment)
- User vetting safeguards (document verification, access controls, encrypted storage)
- Regulatory audit preparedness (exportable logs, compliance reporting)

**Estimated Cost: $12,000 – $15,000**

*Basis: EnDAO ships with RLS on all tables, CSRF protection, input validation with SQL injection and XSS detection, and 2-year audit log retention. Work is extending these controls to cover document storage, adding Act 843-specific data retention policies, and producing exportable compliance reports. Independent penetration testing, if required, is an additional $8,000–$15,000 depending on scope and is recommended but not included in this line item.*

---

**F. Deployment, Training & Support**

- Pilot deployment (Ghana — hosting, CI/CD, monitoring setup)
- Admin and Chamber staff training (documentation, video walkthroughs)
- 90-day post-launch support (bug fixes, patches, technical support)

**Estimated Cost: $15,000 – $21,000**

*Basis: CI/CD pipelines, monitoring (Sentry + PostHog), and deployment workflows exist. Work is configuring for GCCI's environment, producing admin training materials, and providing 90 days of technical support after launch.*

---

### TOTAL Phase 1 MVP Estimated Cost: $150,000 – $200,000

**Includes:**
- Platform customization and new module development (categories A–D)
- Security hardening and regulatory readiness (category E)
- Pilot deployment, staff training, and 90-day post-launch support (category F)

**Not included (billed separately):**
- Hosting & infrastructure (~$500–$1,500/month)
- Independent penetration testing ($8,000–$15,000 if required)
- No custody of funds, no on-chain transactions, no marketplace in Phase 1

---

**G. Timeline & Assumptions**

**Estimated build duration: 14–18 weeks**

| Phase | Duration | Activities |
|-------|----------|------------|
| Weeks 1–3 | Design & Architecture | UX flows, tenant architecture, database schema, white-label config |
| Weeks 3–12 | Core Engineering | License workflow, equipment module, RBAC, document storage, multi-tenant |
| Weeks 5–14 | LMS Integration (parallel) | Course delivery, certification engine, trainer management |
| Weeks 10–15 | Governance & Compliance (parallel) | Admin dashboards, compliance checklists, audit exports |
| Weeks 13–16 | Security & QA | Privacy controls, vetting safeguards, integration testing |
| Weeks 15–18 | Deployment & Training | Pilot launch, staff training, documentation handoff |

**Key dependencies and assumptions:**

- **Capital readiness** — Development does not begin until first milestone payment is received
- **Content readiness** — GCCI provides license type definitions, compliance requirements, training curricula, and branding assets before Week 3. Content delays shift the timeline 1:1.
- **Decision readiness** — GCCI designates a single point of contact with authority to approve designs and features within 5 business days of submission. Delayed approvals shift the timeline.
- **Scope is fixed** — The 11 license types, 6 member roles, and 4 equipment categories defined in this document are the MVP scope. Additions require a written change order with revised pricing and timeline.
- **3–4 license pathways at launch** — MVP is validated with 3–4 complete pathways (e.g., Small-Scale Cultivation, Primary Processing, Educational/Training Provider). Remaining pathways are configured using the same engine post-launch.
- **English only** — No localization in Phase 1. Twi, Ga, Ewe support is a Phase 2 item.
- **Web only** — No native mobile app in Phase 1. Mobile-responsive web for operator access; dedicated mobile app is a Phase 2 consideration.
- **No fund custody** — Capital matching module is referral/matching only. No wallets, no escrow, no payment processing.

---

### Post-Launch Maintenance

After the 90-day included support period, ongoing platform maintenance is available on a monthly retainer basis.

| Item | Monthly Cost (USD) |
|------|--------------------|
| Maintenance & support (bug fixes, security patches, minor updates) | $3,000 – $5,000 |
| Hosting & infrastructure | $500 – $1,500 |

---

### Phase 2 & Phase 3 (Future — Separate Authorization Required)

| Phase | Scope | Indicative Estimate (USD) |
|-------|-------|--------------------------|
| **Phase 2** | Equipment payments & leasing, mobile app, blended learning (field-based), remaining license pathways, i18n (Twi/Ga/Ewe), enhanced compliance automation | $80,000 – $130,000 |
| **Phase 3** | On-chain governance & treasury, AI-assisted compliance, analytics dashboards, cross-border trade features | $100,000 – $160,000 |

*Phase 2 and Phase 3 require separate approval, regulatory clearance, and funding confirmation before any development begins.*

### Market Rate Reference Data

The following industry benchmarks contextualize the budget estimates above.

**Custom Enterprise SaaS Development (from scratch, 2025-2026):**

| Complexity | Cost Range | Timeline |
|------------|-----------|----------|
| MVP | $60,000 – $100,000 | 3-6 months |
| Mid-tier SaaS | $80,000 – $150,000 | 4-8 months |
| Enterprise / complex | $150,000 – $500,000+ | 6-12+ months |
| Regulated industry premium | +20-30% above base | — |

Sources: [Ptolemay](https://www.ptolemay.com/post/saas-development-costs), [Imenso Software](https://www.imensosoftware.com/blog/cost-to-build-a-saas-product-from-scratch-in-2025-complete-guide/), [Cubix](https://www.cubix.co/blog/saas-development-costs/), [Bacancy Technology](https://www.bacancytechnology.com/blog/saas-development-costs)

**Certification Management Software Implementation:**

| Scope | Cost Range |
|-------|-----------|
| Mid-to-large organization, straightforward requirements | $150,000 – $350,000 |
| Ongoing per-user costs | $75 – $200/user/month |

Source: [Cobalt (Dynamics 365)](https://cobalt.net/certification-management-software/)

**Enterprise Custom Software by Category:**

| Category | Cost Range |
|----------|-----------|
| Operations management systems | $200,000 – $400,000 |
| Digital process automation | ~$300,000 average |
| Enterprise with compliance requirements | $200,000 – $500,000+ |

Sources: [Senlainc](https://senlainc.com/blog/custom-software-development-costs/), [Enorness](https://enorness.com/blog/software-development/custom-software-development-cost/), [Appello](https://appello.com.au/articles/the-true-cost-of-custom-software-development-expert-analysis-price-guide)

**Cannabis & Hemp Licensing Platforms (existing market):**

| Platform | Type | Pricing |
|----------|------|---------|
| [Tyler Technologies](https://www.tylertech.com/solutions/public-administration/regulatory/cannabis-licensing) | Government cannabis licensing | Enterprise (custom quote) |
| [Accela](https://www.accela.com/solutions/cannabis-regulation/) | Government cannabis regulation | Enterprise (custom quote) |
| [Simplifya](https://www.simplifya.com) | Operator compliance verification | ~$289/license/month |

**Association Management Software Market:**

The membership and association software market is projected to grow from $6.28B (2024) to $9.56B (2031). Off-the-shelf AMS platforms range from $29/month (basic) to $15,000+ setup fees for enterprise solutions (iMIS, Fonteva/Salesforce). Source: [Capterra](https://www.capterra.com/association-management-software/), [JoinIt](https://joinit.com/blog/the-best-membership-software-for-associations), [Neon One](https://neonone.com/resources/blog/best-membership-management-software-nonprofits-neo/)

---

## Codebase Readiness Assessment

Internal analysis of existing EnDAO and Allinka codebases against GCCI MVP requirements.

### EnDAO Platform — What Exists

| Feature | Readiness | Notes |
|---------|-----------|-------|
| **RBAC (Platform Admin)** | 90% | 2 admin roles, 13 granular permissions — extend with Chamber roles |
| **RBAC (DAO Members)** | 40% | 3 generic roles (member/admin/owner) — need 6 GCCI-specific roles |
| **Audit Trail** | 95% | Comprehensive: event severity, actor context, IP, risk assessment, compliance metadata |
| **Admin Dashboards** | 70% | 17 components, system stats API — customize for Chamber context |
| **Proposal Workflow** | 70% | Full lifecycle (draft→review→active→passed) — foundation for license workflow |
| **Invitation/Vetting System** | 50% | 9 service files, status tracking — extend for document-based vetting |
| **Security (Auth, RLS, CSRF)** | 85% | Privy auth, RLS on all tables, CSRF, input sanitization |
| **Treasury Protection** | 90% | 4-layer protection (status, freeze, grace period, execution locks) |
| **White-Label Theming** | 60% | DAO logos, colors, org templates — need tenant-level config |
| **Document Storage** | 30% | Images only (avatars, logos) — need PDFs, DOCX, versioning |
| **Multi-Tenancy** | 0% | Single-instance — major architecture addition |
| **Equipment Module** | 0% | No asset management — build from scratch |
| **11-License Workflow** | 0% | No license engine — build using proposal workflow as foundation |

### Allinka Platform — What Exists

| Feature | Readiness | Notes |
|---------|-----------|-------|
| **Course Catalog** | 70% | Title, description, instructor, duration, level, category — no modules/lessons |
| **Enrollment & Progress** | 60% | 0-100% progress tracking — no lesson-level granularity |
| **User Auth & Profiles** | 80% | Supabase Auth, profile with business fields |
| **API Layer** | 70% | Express.js, well-structured routes — add GCCI endpoints |
| **Mentor System** | 30% | Commercial model (hourly rates) — wrong model for Chamber trainers |
| **Dashboard UI** | 50% | Business metrics focused — repurpose for LMS metrics |
| **Certification System** | 0% | No certificates, no issuance, no expiration tracking |
| **Lesson/Module Structure** | 0% | Courses are catalog items only, no curriculum delivery |
| **Video Player** | 0% | No video component or progress tracking |
| **Trainer Approval** | 0% | No Chamber-approved trainer workflow |
| **Blended Learning** | 0% | No field-based or attendance tracking |
| **Admin Portal** | 0% | No admin UI or management endpoints |
| **Multi-Tenant** | 0% | No tenant isolation |

### Critical Gaps (Must Build)

1. **Multi-Tenant Architecture** — Data isolation, custom domains, tenant-level branding
2. **11-License Workflow Engine** — Application intake, document upload, status lifecycle, renewal alerts
3. **Equipment Module** — Listings, inquiry workflow, admin approval, 4 equipment categories
4. **6 Custom Member Roles** — Role-specific permissions, vetting workflows, dashboards
5. **Document Storage Extension** — PDFs, DOCX, XLSX support with versioning and secure viewer
6. **Certification System** — Issuance, expiration, renewal, verification portal
7. **Lesson Delivery System** — Modules, video player, quizzes, progress tracking
8. **Trainer Management** — Approval workflow, course assignment, qualification tracking

### Strong Foundations (Accelerators)

1. **Proposal Workflow** → adaptable for license applications
2. **Invitation System** → foundation for member vetting
3. **Audit Logs** → already meets compliance requirements
4. **Admin Dashboard** → strong base for Chamber oversight
5. **RBAC Framework** → extensible permission system
6. **Course Catalog + Enrollment** → starting point for LMS
7. **API Infrastructure** → well-structured Express.js backend
8. **Auth + Profile System** → Supabase Auth ready to extend

### Build Estimate

Approximately 40% of the MVP has foundations in existing code. The remaining 60% requires new development, with the license workflow engine and multi-tenant architecture being the most complex additions.

---

## Technical Risks & Mitigation

| Risk | Impact | Mitigation |
|------|--------|------------|
| **Data sovereignty** — Ghana may require data hosted in-country or Africa. Supabase/Vercel are US-hosted. | Could block government adoption or Parliamentary endorsement | Budget for Ghana/EU region deployment option. Confirm requirements with GCCI legal counsel before architecture decisions. |
| **Ghana Data Protection Act (Act 843)** — Platform handles PII, business financials, land ownership docs | Non-compliance could expose all parties to regulatory action | Include legal review of Act 843 requirements in Phase 1 security budget. Build data retention and deletion policies. |
| **Regulatory framework changes** — Cannabis legislation still evolving. Parliamentary presentation originally targeted June 2025. | Scope shift mid-build if license types, requirements, or approval workflows change | Contract should include change order provisions. Build license types as configurable data, not hardcoded logic. |
| **Connectivity in rural Ghana** — Intermittent internet for farmer-facing users | Farmers can't complete applications, training, or compliance tasks | Consider offline-capable mobile experience for Phase 2. MVP can start web-only with Chamber admin as intermediary for rural users. |
| **Document sensitivity** — License applications contain PII, financials, land records | Data breach liability, reputational damage to Chamber | Client-side encryption for sensitive documents. Document retention policies. Access logging on all document views. |
| **Identity verification** — Vetting workflow says "document upload" but doesn't address verification method | Delays if Chamber expects automated KYC; cost increase if third-party provider needed | Clarify with GCCI: manual review by Chamber staff (included in MVP) vs. third-party KYC integration (additional cost). |
| **SMS/USSD access** — Small-scale farmers may not have smartphones | Excludes primary target users from self-service | Phase 1 uses web app with Chamber staff assisting rural users. Phase 2 can add SMS notifications and USSD fallback. |
| **Language/localization** — Neither platform has i18n infrastructure | Limits adoption outside English-speaking urban users | English-only for MVP. Budget i18n framework in Phase 2 for Twi, Ga, Ewe support. |

---

## Business & Presentation Considerations

### Pilot Scope Opportunity

The success criteria require "at least 3 license pathways end-to-end" but the budget builds all 11. Consider whether Phase 1 should deliver 3-4 pathways (e.g., Small-Scale Cultivation, Primary Processing, Educational/Training Provider) with the remaining pathways added in Phase 2. This could reduce MVP cost by 15-20% and accelerate delivery.

### Platform Sustainability

The budget does not address how the platform sustains itself post-launch:
- **Per-user/per-license fees** — Chamber charges operators for license processing
- **Chamber membership dues** — Annual membership includes platform access
- **Government subsidy** — Parliamentary funding covers platform costs
- **Transaction fees on equipment rentals** (Phase 2)

This question will likely come from informed buyers evaluating long-term ROI.

### Capital Matching Liability

The capital intake/matching module explicitly excludes fund custody, but hosting investor-operator matching data creates potential liability. Clarify: who owns the matching data? What disclaimers are required? Consider requiring GCCI to provide legal sign-off on the matching workflow before building it.

### Post-Launch Ownership

KCG/GCCI have no in-house technical team mentioned. The optional maintenance retainer covers bug fixes and patches, but not:
- Feature requests or scope expansion
- Database administration and scaling
- Security incident response (beyond patching)
- Platform migration or handoff to a new vendor

Knowledge transfer and documentation deliverables should be defined in the contract.

---

## Internal Risk Assessment

**Classification**: INTERNAL — Not for client distribution

### Pre-Contract Protections

| Risk | Protection |
|------|------------|
| **Funding contingency not honored** — Work begins before capital is secured | Contract must require milestone-based payments with first payment before any development starts. No work on spec. |
| **Scope creep** — "Just one more feature" during build | Fixed-scope contract with explicit change order process. Any additions outside the MVP spec require written approval and revised pricing. |
| **IP confusion** — Partnership agreement states KCG owns all IP for frameworks, curricula, methodologies | Clearly separate: (1) KCG IP (licensing framework, training curricula, Hub-and-Spoke model) from (2) EnDAO/Allinka IP (platform code, architecture, white-label engine). Platform code remains our IP, licensed for use. |
| **Liability for platform decisions** — Chamber uses platform to deny licenses, operators sue | Contract must include limitation of liability clause. We build the tool; Chamber makes all licensing decisions. Platform is not a substitute for legal or regulatory advice. |
| **Regulatory association** — Cannabis industry carries reputational and legal risk in some jurisdictions | Ensure contract specifies we are a technology vendor, not a cannabis industry participant. No equity stake in GCCI or KCG operations. |
| **Payment default** — Client stops paying mid-project | Milestone structure: 30% upfront, 30% at mid-point delivery, 30% at MVP completion, 10% after 30-day acceptance period. Code not deployed to production until each milestone is paid. |
| **Dependency on Parliamentary outcome** — If Parliamentary presentation fails, funding may dry up | Contract is with KCG/GCCI directly, not contingent on Parliamentary approval. If they have funding, we build. Their funding source is their risk. |

### Post-Contract Protections

| Risk | Protection |
|------|------------|
| **Platform used beyond agreed scope** — White-label resold to other Chambers without our involvement | License agreement limits deployment to GCCI platform only. Additional Chamber deployments require separate licensing or revenue share. |
| **Maintenance dependency** — We become the only people who can keep it running | Deliver full documentation, deployment runbooks, and admin training as part of Phase 1. If they choose not to retain us, they can hire elsewhere. |
| **Security incident** — Breach occurs after our 90-day support period | Post-support SLA clearly ends our responsibility. Recommend they retain us or hire managed security. If they decline, get written acknowledgment. |
| **Late payment on retainer** — Maintenance retainer invoices go unpaid | Net-30 payment terms. If 60 days overdue, maintenance pauses with written notice. Platform stays live but no patches, no support. |
| **Feature ownership disputes** — Client claims custom features we built are "their" code | Contract specifies: platform engine and white-label framework remain EnDAO/Allinka IP. Client-specific configurations (branding, license types, content) belong to client. Custom features built for this engagement are licensed to client but owned by us unless explicitly transferred. |

### Contract Essentials Checklist

- [ ] Milestone-based payment schedule (no work before first payment)
- [ ] Fixed scope with written change order process
- [ ] IP ownership clause (platform code = ours, client content = theirs)
- [ ] Limitation of liability (we're a tech vendor, not a cannabis operator)
- [ ] 90-day post-launch support included, then optional retainer
- [ ] Acceptance criteria for MVP delivery (tied to success criteria in this doc)
- [ ] Data ownership clause (client owns their data, we own the platform)
- [ ] Termination clause (what happens if either party exits mid-project)
- [ ] White-label licensing terms (one Chamber deployment; additional deployments = new agreement)
- [ ] Security incident responsibility boundaries
- [ ] Force majeure (regulatory changes, funding collapse, political instability)

---

## Related Documents

- [KCG x GCCI Strategic Partnership Agreement](confidential) - Full partnership terms
- [MVP Functional Requirements](confidential) - Detailed functional scope and budget template
- [Alinka Service Provider Integration](./ALINKA_SERVICE_PROVIDER_INTEGRATION.md) - Platform integration architecture
- Platform Roadmap - White-label capabilities timeline

---

*Document updated from partnership agreement and MVP functional requirements - February 2026*
