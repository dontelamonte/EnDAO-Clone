# Token Architecture

**Version**: 2.0
**Last Updated**: December 5, 2025
**Status**: Phase 1 Design Complete

## Overview

EnDAO's three-token system provides governance (EDG), payment utility (TCR), and soulbound equity (TEQ) to create a sustainable labor marketplace with aligned incentives.

---

## Token Summary Matrix

| Token   | Full Name            | Purpose                             | Transferable | Standard                   | Phase |
| ------- | -------------------- | ----------------------------------- | ------------ | -------------------------- | ----- |
| **EDG** | EnDAO Governance     | Protocol governance + fee discounts | ✅ Yes       | ERC-20Votes + ERC-4626     | 1     |
| **TCR** | TimeCredits          | Labor payment utility               | ✅ Yes       | ERC-20 + ERC-2612          | 1     |
| **TEQ** | Time-Equity Protocol | Soulbound membership equity         | ❌ No        | ERC-20 (Soulbound) + Votes | 2     |

---

## 1. EDG Governance Token

### Purpose

EDG enables protocol governance before marketplace exists. Holders vote on:

- Treasury allocation decisions
- Rate setting for LaborOracle
- Committee (Sub-DAO) admission
- Protocol parameter changes

### Technical Specification

```solidity
// contracts/EDG.sol
contract EDG is ERC20, ERC20Votes, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");

    constructor() ERC20("EnDAO Governance", "EDG") ERC20Permit("EDG") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    function mint(address to, uint256 amount) external onlyRole(MINTER_ROLE) {
        _mint(to, amount);
    }

    // ERC-20Votes requires these overrides
    function _update(address from, address to, uint256 value)
        internal override(ERC20, ERC20Votes)
    {
        super._update(from, to, value);
    }

    function nonces(address owner) public view override(ERC20Permit, Nonces) returns (uint256) {
        return super.nonces(owner);
    }
}
```

### Staking Vault (ERC-4626)

```solidity
// contracts/EDGVault.sol
contract EDGVault is ERC4626 {
    uint256 public constant GOLD_THRESHOLD = 50_000 ether;
    uint256 public constant SILVER_THRESHOLD = 10_000 ether;

    function getDiscountTier(address user) public view returns (uint256) {
        uint256 balance = balanceOf(user);
        if (balance >= GOLD_THRESHOLD) return 100;  // 100% fee discount
        if (balance >= SILVER_THRESHOLD) return 50; // 50% fee discount
        return 0;
    }

    // Integration point: FeeRouter checks this before calculating fees
    function calculateDiscountedFee(address user, uint256 baseFee) external view returns (uint256) {
        uint256 discount = getDiscountTier(user);
        return (baseFee * (100 - discount)) / 100;
    }
}
```

### Distribution Strategy

**Total Supply**: 1,000,000,000 EDG (1 billion)

| Allocation          | Amount      | %   | Vesting               | Cliff     |
| ------------------- | ----------- | --- | --------------------- | --------- |
| Team & Founders     | 100,000,000 | 10% | 48 months             | 12 months |
| Early Contributors  | 150,000,000 | 15% | 24 months             | 6 months  |
| Community Treasury  | 250,000,000 | 25% | Governance-controlled | None      |
| Protocol Reserves   | 200,000,000 | 20% | 60 months             | 24 months |
| Ecosystem Growth    | 150,000,000 | 15% | 36 months             | None      |
| Liquidity Provision | 100,000,000 | 10% | Immediate             | None      |
| Airdrops & Rewards  | 50,000,000  | 5%  | 12 months             | None      |

### Voting Power Calculation

```typescript
// src/lib/services/governance/voting-power.service.ts
interface VotingPowerCalculation {
  edgBalance: bigint; // Raw EDG balance
  stakedBalance: bigint; // EDG in vault
  delegatedPower: bigint; // Power delegated from others
  delegatedAway: bigint; // Power delegated to others
  totalVotingPower: bigint; // Final calculation
  percentageOfTotal: number; // % of total voting power
}

class VotingPowerService {
  // Voting power = (balance + staked * 1.5) + delegated - delegatedAway
  async calculateVotingPower(address: string): Promise<VotingPowerCalculation> {
    const [balance, staked, delegated, delegatedAway] = await Promise.all([
      this.edgContract.balanceOf(address),
      this.edgVault.balanceOf(address),
      this.getDelegatedToMe(address),
      this.getDelegatedFromMe(address),
    ]);

    // Staking multiplier: 1.5x for staked tokens
    const stakingMultiplier = 150n; // 1.5x in basis points
    const rawPower = balance + (staked * stakingMultiplier) / 100n;
    const totalVotingPower = rawPower + delegated - delegatedAway;

    const totalSupplyPower = await this.getTotalVotingPower();
    const percentageOfTotal =
      Number((totalVotingPower * 10000n) / totalSupplyPower) / 100;

    return {
      edgBalance: balance,
      stakedBalance: staked,
      delegatedPower: delegated,
      delegatedAway,
      totalVotingPower,
      percentageOfTotal,
    };
  }
}
```

---

## 2. TCR TimeCredits Token

### Purpose

Payment utility token for labor marketplace. **1 TCR = $1.00 USD** equivalent.

### Technical Specification

```solidity
// contracts/TCR.sol
contract TCR is ERC20, ERC20Permit, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BRIDGE_ROLE = keccak256("BRIDGE_ROLE");

    constructor() ERC20("TimeCredits", "TCR") ERC20Permit("TCR") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    // Mint by marketplace (work completion) or bridge (fiat on-ramp)
    function mint(address to, uint256 amount) external {
        require(
            hasRole(MINTER_ROLE, msg.sender) || hasRole(BRIDGE_ROLE, msg.sender),
            "Unauthorized"
        );
        _mint(to, amount);
    }

    // Burn for off-ramp
    function burn(uint256 amount) external {
        _burn(msg.sender, amount);
    }
}
```

### Fiat Bridge Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   User's Bank   │────▶│  Bridge Service  │────▶│   TCR Token     │
│   (Stripe/ACH)  │     │  (Centralized)   │     │   (On-chain)    │
└─────────────────┘     └──────────────────┘     └─────────────────┘
         │                       │                        │
         │  $100 USD            │  Verify deposit        │  Mint 100 TCR
         │                       │  KYC check             │  to user wallet
         ▼                       ▼                        ▼
    Fiat account           BRIDGE_ROLE calls           ERC-20 balance
    debited                 tcr.mint(user, 100e18)     updated
```

### Collateralization Requirements

| Collateral Type | Ratio | Accepted Assets        |
| --------------- | ----- | ---------------------- |
| Fiat Reserves   | 100%  | USD (bank), USDC, USDT |
| Stablecoin      | 100%  | USDC, DAI, FRAX        |
| Volatile        | 150%  | ETH, BTC (with oracle) |

### Bridge Service Implementation

```typescript
// src/lib/services/bridge/tcr-bridge.service.ts
interface BridgeConfig {
  minDepositAmount: number; // $10 minimum
  maxDepositAmount: number; // $100,000 per transaction
  dailyLimit: number; // $1,000,000 per day
  kycThreshold: number; // $10,000 requires KYC
}

class TCRBridgeService {
  async initiateDeposit(
    userId: string,
    amount: number,
    paymentMethod: 'ach' | 'wire' | 'stablecoin'
  ): Promise<DepositRequest> {
    // Validate user and KYC
    const user = await this.userService.getUser(userId);
    if (amount >= this.config.kycThreshold && !user.kycVerified) {
      throw new Error('KYC required for deposits over $10,000');
    }

    // Check daily limits
    const todayVolume = await this.getDailyVolume(userId);
    if (todayVolume + amount > this.config.dailyLimit) {
      throw new Error('Daily limit exceeded');
    }

    // Create deposit request
    return await this.createDepositRequest({
      userId,
      amount,
      paymentMethod,
      status: 'pending',
      estimatedCompletion: this.estimateCompletion(paymentMethod),
    });
  }

  async confirmDeposit(requestId: string): Promise<void> {
    const request = await this.getRequest(requestId);

    // Verify funds received
    await this.verifyFundsReceived(request);

    // Mint TCR to user's wallet
    const userWallet = await this.walletService.getUserWallet(request.userId);
    await this.tcrContract.mint(userWallet, request.amount * 1e18);

    // Update status and record for compliance
    await this.updateRequest(requestId, { status: 'completed' });
    await this.complianceService.recordMint({
      userId: request.userId,
      amount: request.amount,
      source: request.paymentMethod,
      timestamp: new Date(),
    });
  }
}
```

---

## 3. TEQ Time-Equity Token

### Purpose

Soulbound membership equity. Cannot be transferred, only earned through labor.

### Technical Specification

```solidity
// contracts/TEQ.sol
contract TEQ is ERC20, ERC20Votes, AccessControl {
    error Soulbound();
    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");

    // Track cumulative labor value for each holder
    mapping(address => uint256) public cumulativeLaborValueUSD;

    constructor() ERC20("Time-Equity Protocol", "TEQ") ERC20Permit("TEQ") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    function mint(address to, uint256 amount, uint256 laborValueUSD)
        external onlyRole(CONTROLLER_ROLE)
    {
        cumulativeLaborValueUSD[to] += laborValueUSD;
        _mint(to, amount);
        emit EquityMinted(to, amount, laborValueUSD, cumulativeLaborValueUSD[to]);
    }

    // SOULBOUND: Block all transfers
    function _update(address from, address to, uint256 value)
        internal override(ERC20, ERC20Votes)
    {
        // Allow mint (from == 0) and burn (to == 0), block transfers
        if (from != address(0) && to != address(0)) {
            revert Soulbound();
        }
        super._update(from, to, value);
    }

    event EquityMinted(address indexed to, uint256 amount, uint256 laborValueUSD, uint256 cumulative);
}
```

### Liquidity Events

TEQ holders can exit through:

1. **Treasury Buybacks**: DUNA votes to buy back TEQ at Cost-Plus valuation
2. **Dividends**: DUNA distributes surplus revenue proportionally to TEQ holders
3. **Redemption Window**: Annual 30-day window for redemption requests

### Redemption Service

```typescript
// src/lib/services/teq/redemption.service.ts
interface RedemptionWindow {
  windowId: string;
  startDate: Date;
  endDate: Date;
  redemptionRate: number; // TCR per TEQ
  maxRedemptionPool: number; // Total TCR available
  status: 'upcoming' | 'active' | 'processing' | 'complete';
}

class TEQRedemptionService {
  async createRedemptionWindow(
    year: number,
    redemptionPoolTCR: number
  ): Promise<RedemptionWindow> {
    const teqSupply = await this.teqContract.totalSupply();
    const historicalDemand = await this.getHistoricalDemandRate();

    // Base rate: pool / (supply * expected demand rate)
    const expectedDemand = (Number(teqSupply) / 1e18) * historicalDemand;
    const redemptionRate = Math.min(redemptionPoolTCR / expectedDemand, 1.0);

    return {
      windowId: `redemption-${year}`,
      startDate: new Date(`${year}-03-01`),
      endDate: new Date(`${year}-03-31`),
      redemptionRate,
      maxRedemptionPool: redemptionPoolTCR,
      status: 'upcoming',
    };
  }

  async requestRedemption(
    userId: string,
    teqAmount: number
  ): Promise<RedemptionRequest> {
    const activeWindow = await this.getActiveWindow();
    if (!activeWindow || activeWindow.status !== 'active') {
      throw new Error('No active redemption window');
    }

    // Calculate TCR payout
    const tcrPayout = teqAmount * activeWindow.redemptionRate;

    // Check pool capacity
    if (
      activeWindow.totalRequested + tcrPayout >
      activeWindow.maxRedemptionPool
    ) {
      throw new Error('Redemption pool exhausted');
    }

    // Lock TEQ and create request
    const userWallet = await this.walletService.getUserWallet(userId);
    await this.teqContract.lockForRedemption(
      userWallet,
      BigInt(teqAmount) * 10n ** 18n
    );

    return await this.createRequest({
      userId,
      teqAmount,
      tcrPayout,
      windowId: activeWindow.windowId,
      status: 'pending',
    });
  }
}
```

---

## 4. LaborOracle (Cost-Plus Valuation)

### Purpose

Replaces complex "Health Score" with `Hours × Market Rate`.

```solidity
// contracts/LaborOracle.sol
contract LaborOracle is AccessControl {
    bytes32 public constant UPDATER_ROLE = keccak256("UPDATER_ROLE");

    struct JobType {
        uint256 ratePerHour;      // In USD cents (e.g., 5000 = $50/hr)
        uint256 maxRateCap;       // Anti-gaming: max rate allowed
        uint256 maxHoursPerWeek;  // Anti-gaming: max hours per contributor
        bool requiresAttestation; // Requires EAS attestation
        bool isActive;
    }

    mapping(uint256 => JobType) public jobTypes;
    mapping(address => mapping(uint256 => uint256)) public weeklyHours; // user => week => hours

    function calculateEquityValue(
        address contributor,
        uint256 jobTypeId,
        uint256 hoursWorked
    ) external returns (uint256 equityValue) {
        JobType storage job = jobTypes[jobTypeId];
        require(job.isActive, "Job type inactive");

        // Anti-gaming: Check weekly hour cap
        uint256 currentWeek = block.timestamp / 1 weeks;
        uint256 newWeeklyTotal = weeklyHours[contributor][currentWeek] + hoursWorked;
        require(newWeeklyTotal <= job.maxHoursPerWeek, "Exceeds weekly cap");

        weeklyHours[contributor][currentWeek] = newWeeklyTotal;

        // Calculate: hours × rate (in cents) / 100 = USD value
        equityValue = (hoursWorked * job.ratePerHour) / 100;

        return equityValue;
    }
}
```

### Initial Job Types

| ID  | Category      | Rate/Hour | Max Cap | Max Hours/Week |
| --- | ------------- | --------- | ------- | -------------- |
| 1   | General Labor | $50       | $75     | 40             |
| 2   | Skilled Trade | $75       | $125    | 40             |
| 3   | Professional  | $100      | $200    | 40             |
| 4   | Executive     | $150      | $300    | 30             |
| 5   | Advisory      | $200      | $500    | 20             |

---

## 5. ServiceMarketplace (Double-Dip Integration)

```solidity
// contracts/ServiceMarketplace.sol
contract ServiceMarketplace is ReentrancyGuard, AccessControl {
    IERC20 public tcr;
    TEQ public teq;
    LaborOracle public laborOracle;
    EDGVault public edgVault;
    address public treasury;
    uint256 public protocolFeeBps = 300; // 3%

    struct Job {
        address client;
        address provider;
        uint256 amount;          // TCR amount
        uint256 jobTypeId;
        uint256 hoursWorked;
        JobStatus status;
    }

    enum JobStatus { Created, InProgress, Completed, Disputed, Cancelled }

    mapping(uint256 => Job) public jobs;
    uint256 public nextJobId;

    function completeJob(uint256 jobId, uint256 actualHours) external nonReentrant {
        Job storage job = jobs[jobId];
        require(msg.sender == job.client, "Only client");
        require(job.status == JobStatus.InProgress, "Invalid status");

        job.hoursWorked = actualHours;
        job.status = JobStatus.Completed;

        // Calculate fee with EDG discount
        uint256 baseFee = (job.amount * protocolFeeBps) / 10000;
        uint256 actualFee = edgVault.calculateDiscountedFee(job.client, baseFee);
        uint256 payout = job.amount - actualFee;

        // THE DOUBLE-DIP:
        // 1. Pay provider in TCR
        tcr.transfer(job.provider, payout);

        // 2. Send fee to treasury
        if (actualFee > 0) {
            tcr.transfer(treasury, actualFee);
        }

        // 3. Calculate and mint equity (TEQ)
        uint256 equityValue = laborOracle.calculateEquityValue(
            job.provider,
            job.jobTypeId,
            actualHours
        );
        teq.mint(job.provider, equityValue * 1e18, equityValue);

        emit JobCompleted(jobId, payout, equityValue, actualFee);
    }

    event JobCompleted(uint256 indexed jobId, uint256 payout, uint256 equityValue, uint256 fee);
}
```

---

## 6. Token Integration Points

### 6.1 Integration with Existing Voting System

```typescript
// src/lib/services/proposal/token-weighted-voting.service.ts
interface TokenWeightedVote {
  proposalId: string;
  voterId: string;
  choice: 'for' | 'against' | 'abstain';
  votingPower: bigint;
  tokenType: 'edg' | 'teq' | 'both';
  timestamp: Timestamp;
}

class TokenWeightedVotingService {
  async castTokenWeightedVote(
    proposalId: string,
    voterId: string,
    choice: 'for' | 'against' | 'abstain'
  ): Promise<TokenWeightedVote> {
    const proposal = await this.proposalRepository.findById(proposalId);

    // Get voting power based on proposal type
    let votingPower: bigint;
    if (proposal.type === 'protocol_governance') {
      // Protocol governance uses EDG
      votingPower = await this.votingPowerService
        .calculateVotingPower(voterId)
        .then((r) => r.totalVotingPower);
    } else if (proposal.type === 'dao_internal') {
      // Internal DAO governance uses TEQ or equal weight
      const dao = await this.daoRepository.findById(proposal.daoId);
      if (dao.votingSystem === 'token_weighted') {
        votingPower = await this.teqContract.balanceOf(
          await this.walletService.getUserWallet(voterId)
        );
      } else {
        votingPower = 1n; // Equal weight
      }
    }

    const vote: TokenWeightedVote = {
      proposalId,
      voterId,
      choice,
      votingPower,
      tokenType: proposal.type === 'protocol_governance' ? 'edg' : 'teq',
      timestamp: Timestamp.now(),
    };

    await this.voteRepository.save(vote);
    await this.updateProposalTallies(proposalId, choice, votingPower);

    return vote;
  }
}
```

### 6.2 Integration with FeeRouter

| Existing Component | Integration Point                                                     |
| ------------------ | --------------------------------------------------------------------- |
| `FeeRouter.sol`    | Call `edgVault.getDiscountTier(user)` before fee calculation          |
| Proposal voting    | Weight votes by EDG balance: `votingPower = edgBalance / totalSupply` |
| DAO admin actions  | Require EDG stake for treasury admin role                             |

```solidity
// contracts/FeeRouterV2.sol
contract FeeRouterV2 is FeeRouter {
    EDGVault public edgVault;

    function calculateFee(
        address payer,
        uint256 amount,
        uint256 baseFeeBps
    ) public view returns (uint256 fee, uint256 discount) {
        uint256 discountTier = edgVault.getDiscountTier(payer);

        // Gold: 100% discount, Silver: 50% discount
        uint256 discountedFeeBps = baseFeeBps * (100 - discountTier) / 100;
        fee = (amount * discountedFeeBps) / 10000;
        discount = (amount * baseFeeBps / 10000) - fee;

        return (fee, discount);
    }
}
```

---

## Implementation Phases

### Phase 1 (Q1 2026)

- Deploy EDG token and vault
- Implement EDG staking for fee discounts
- Deploy TCR token and bridge service
- Integrate EDG voting into existing proposal system

### Phase 2 (Q2 2026)

- Deploy TEQ token with soulbound mechanism
- Implement LaborOracle with initial job types
- Deploy ServiceMarketplace contract
- Launch first redemption window

### Phase 3 (Q3 2026)

- Scale liquidity across multiple DEXs
- Enable quadratic voting with EDG
- Expand job types and attestation system
- Launch dividend distribution mechanism

---

## Security Considerations

1. **Token Minting**: All minting operations require multi-sig approval via governance
2. **Bridge Security**: Centralized bridge requires KYC/AML compliance and reserves audit
3. **Soulbound Enforcement**: TEQ transfer blocking at contract level prevents secondary markets
4. **Oracle Manipulation**: LaborOracle rate caps and weekly hour limits prevent gaming
5. **Redemption Controls**: Annual windows with pool limits prevent bank runs

---

## Related Documentation

- `/docs/VOTING_SYSTEM.md` - Token-weighted voting integration
- `/docs/TREASURY_PROTECTION.md` - EDG staking requirements for treasury operations
- `/docs/security/RLS_POLICIES.md` - Token balance verification rules
- Master spec: `~/.claude/plans/polished-leaping-snail.md` (Section 2)
