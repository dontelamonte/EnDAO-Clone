# Smart Contracts Overview

Comprehensive reference for EnDAO smart contracts deployed on Base mainnet.

## Contract Directory

| Contract                    | Purpose                           | Phase   | Status   |
| --------------------------- | --------------------------------- | ------- | -------- |
| **EDG** (Governance Token)  | Protocol governance and staking   | Phase 1 | Priority |
| **TCR** (TimeCredits Token) | Marketplace currency (stablecoin) | Phase 1 | Planned  |
| **TEQ** (Time-Equity Token) | Labor equity and profit-sharing   | Phase 2 | Planned  |
| **LaborOracle**             | Cost-plus labor valuation         | Phase 2 | Planned  |
| **ServiceMarketplace**      | Escrow and Double-Dip logic       | Phase 2 | Planned  |
| **SpendingLimitsModule**    | Zodiac module for treasury limits | Phase 2 | Planned  |
| **EDGVault**                | Staking and fee discounts         | Phase 1 | Planned  |
| **EDGVesting**              | Token vesting schedules           | Phase 1 | Planned  |
| **FeeRouterV2**             | Protocol fees with EDG discounts  | Phase 1 | Active   |

## Deployment Addresses

### Base Mainnet (Production)

| Contract              | Address                                      | Notes  |
| --------------------- | -------------------------------------------- | ------ |
| FeeRouterV2           | `0xf8786857eD04621d6e81959aAb36e422F687E4c8` | Active |
| EnDAO Safe (Treasury) | `0x00dc44400adb57a85364c97442bd5e95faa861e7` | Active |

**Network**: Base Mainnet (Chain ID: 8453)

### Phase 1 Contracts (Pending Deployment)

- EDG Token
- TCR Token
- EDGVault
- EDGVesting

### Phase 2 Contracts (Pending Development)

- TEQ Token
- LaborOracle
- ServiceMarketplace
- SpendingLimitsModule

## Contract Role Matrix

| Contract                 | Role                 | Initial Holder     | Final Holder       | Capabilities              |
| ------------------------ | -------------------- | ------------------ | ------------------ | ------------------------- |
| **EDG**                  | `MINTER_ROLE`        | Multi-sig          | Governor           | Mint governance tokens    |
| **EDG**                  | `DEFAULT_ADMIN_ROLE` | Multi-sig          | TimelockController | Manage roles and config   |
| **TCR**                  | `MINTER_ROLE`        | ServiceMarketplace | ServiceMarketplace | Mint stablecoin credits   |
| **TCR**                  | `BRIDGE_ROLE`        | Bridge service     | Bridge service     | Fiat on/off-ramp minting  |
| **TCR**                  | `DEFAULT_ADMIN_ROLE` | Multi-sig          | TimelockController | Manage roles              |
| **TEQ**                  | `CONTROLLER_ROLE`    | ServiceMarketplace | ServiceMarketplace | Mint equity tokens        |
| **TEQ**                  | `DEFAULT_ADMIN_ROLE` | Multi-sig          | Governor           | Manage equity config      |
| **LaborOracle**          | `UPDATER_ROLE`       | Multi-sig          | Governor           | Update job rates and caps |
| **LaborOracle**          | `DEFAULT_ADMIN_ROLE` | Multi-sig          | TimelockController | Manage roles              |
| **ServiceMarketplace**   | `DEFAULT_ADMIN_ROLE` | Multi-sig          | Governor           | Configure fees and limits |
| **SpendingLimitsModule** | `OWNER_ROLE`         | Multi-sig          | DAO Safe           | Configure spending limits |

## Role Definitions

### `DEFAULT_ADMIN_ROLE`

**Purpose**: Top-level access control management
**Capabilities**: Grant/revoke all roles, modify core contract parameters
**Security**: Protected by multi-sig (initially) → TimelockController (post-launch)

### `MINTER_ROLE`

**Purpose**: Token supply management
**Capabilities**: Mint new tokens to specified addresses
**Security**: Limited to specific contracts or governance-controlled addresses

### `BRIDGE_ROLE`

**Purpose**: Fiat-to-crypto bridge operations
**Capabilities**: Mint TCR when fiat deposits verified, burn TCR on withdrawals
**Security**: Bridge service with KYC/AML compliance

### `UPDATER_ROLE`

**Purpose**: Oracle data management
**Capabilities**: Update labor rates, caps, and job type configurations
**Security**: Multi-sig with governance oversight

### `CONTROLLER_ROLE`

**Purpose**: Equity token lifecycle management
**Capabilities**: Mint TEQ for verified labor, manage equity parameters
**Security**: ServiceMarketplace contract only

## Security Architecture

### Access Control Hierarchy

```
┌─────────────────────────────────────────────┐
│       TimelockController (48h delay)        │
│          DEFAULT_ADMIN_ROLE                 │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│           Governor Contract                  │
│      (EDG token-weighted voting)            │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│        Multi-sig (Emergency Actions)         │
│         Initial UPDATER_ROLE holder         │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│    Operational Contracts & Services         │
│  ServiceMarketplace, Bridge, LaborOracle    │
└─────────────────────────────────────────────┘
```

### Multi-sig Configuration

**Initial Setup**: 3-of-5 Gnosis Safe
**Signers**: Core team members with hardware wallet requirement
**Upgrade Path**: Transition to TimelockController after governance launch

### Timelock Delays

| Action Type       | Delay    | Rationale                            |
| ----------------- | -------- | ------------------------------------ |
| Role changes      | 48 hours | Community review period              |
| Parameter updates | 24 hours | Emergency response capability        |
| Contract upgrades | 72 hours | Critical security review             |
| Emergency actions | 0 hours  | Multi-sig only, post-mortem required |

## Integration Points

### FeeRouter Integration

**Current**: `FeeRouterV2` routes protocol fees to EnDAO Safe
**Planned**: EDG staking discounts via EDGVault integration

```solidity
// Fee calculation with EDG discount
uint256 baseFee = (amount * protocolFeeBps) / 10000;
uint256 actualFee = edgVault.calculateDiscountedFee(payer, baseFee);
// Gold tier: 100% discount, Silver: 50% discount
```

### Treasury Integration

**Main Safe**: Gnosis Safe with 2-of-3 threshold (Tier 2+)
**Ops Wallet**: Single-signer with spending limits (Tier 3+)
**SpendingLimitsModule**: Zodiac module for on-chain enforcement

### Governance Integration

**Protocol Governance**: EDG token-weighted voting
**DAO Internal**: TEQ token-weighted or equal voting
**Voting Power**: `balance + (staked * 1.5x) + delegated - delegatedAway`

## Anti-Gaming Protections

### LaborOracle Safeguards

| Protection        | Implementation             | Threshold           |
| ----------------- | -------------------------- | ------------------- |
| Rate Caps         | `maxRateCap` per job type  | $500/hr max         |
| Hour Caps         | `maxHoursPerWeek` tracking | 60 hrs/week max     |
| Attestation       | Supervisor verification    | Required >$5,000/mo |
| Governance Freeze | Emergency pause            | ENDAO vote          |

### ServiceMarketplace Safeguards

| Protection      | Implementation                       | Purpose                |
| --------------- | ------------------------------------ | ---------------------- |
| Escrow          | TCR locked until completion          | Prevent non-payment    |
| Attestation     | EAS verification for high-value jobs | Prevent fraud          |
| Rate validation | Cross-check with LaborOracle         | Prevent rate inflation |
| Daily limits    | Per-user transaction caps            | Prevent wash trading   |

## Development Workflow

### Contract Development

1. **Specification**: Document requirements in `/docs/contracts/`
2. **Implementation**: Write contract in `contracts/` (Foundry or Hardhat)
3. **Testing**: Unit tests with 100% coverage requirement
4. **Audit**: External security audit for production deployment
5. **Deployment**: Multi-sig controlled deployment via scripts
6. **Verification**: Etherscan/Basescan verification

### Upgrade Process

**Proxy Pattern**: Use OpenZeppelin's UUPS upgradeable pattern
**Governance**: All upgrades require Governor approval + Timelock delay
**Testing**: Upgrade simulations on testnet before production

### Emergency Procedures

**Pause Mechanism**: Multi-sig can pause critical functions
**Recovery**: 72-hour timelock for contract recovery actions
**Communication**: Immediate notification via Discord, Twitter, governance forum

## Testing Requirements

| Test Type           | Coverage          | Framework       |
| ------------------- | ----------------- | --------------- |
| Unit Tests          | 100%              | Foundry/Hardhat |
| Integration Tests   | Critical paths    | Foundry         |
| Fuzzing             | State transitions | Echidna         |
| Formal Verification | Core logic        | Certora         |
| Gas Optimization    | <100k gas/tx      | Foundry         |

## References

- [LaborOracle Documentation](/docs/contracts/LABOR_MARKETPLACE.md)
- [ServiceMarketplace Documentation](/docs/contracts/LABOR_MARKETPLACE.md)
- [Master Specification](/.claude/plans/polished-leaping-snail.md)

---

**Last Updated**: December 5, 2025
**Maintainer**: EnDAO Engineering Team
