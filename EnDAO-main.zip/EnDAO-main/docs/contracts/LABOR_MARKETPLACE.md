# Labor Marketplace Contracts

Smart contracts for labor valuation, marketplace escrow, and equity distribution.

## Architecture Overview

The Labor Marketplace consists of two primary contracts:

1. **LaborOracle**: Cost-plus labor valuation with anti-gaming protections
2. **ServiceMarketplace**: Escrow system with "Double-Dip" equity rewards

```
┌─────────────────────────────────────────────────────────────────┐
│                     LABOR MARKETPLACE FLOW                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. CLIENT CREATES JOB                                           │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  ServiceMarketplace.createJob()                          │   │
│  │  • Client deposits TCR to escrow                         │   │
│  │  • Job type selected from LaborOracle registry           │   │
│  │  • Provider assigned                                     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  2. PROVIDER COMPLETES WORK                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Job status: Created → InProgress → Completed            │   │
│  │  • Hours tracked and verified                            │   │
│  │  • Quality rating collected (0.8x - 1.2x multiplier)     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  3. THE DOUBLE-DIP (PAYMENT + EQUITY)                            │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  ServiceMarketplace.completeJob()                        │   │
│  │  ├── Pay provider in TCR (stablecoin)                    │   │
│  │  ├── Send protocol fee to treasury                       │   │
│  │  └── Mint TEQ equity tokens to provider                  │   │
│  │                                                           │   │
│  │  LaborOracle.calculateEquityValue()                      │   │
│  │  • Hours × Rate × Quality Multiplier                     │   │
│  │  • Anti-gaming checks (rate caps, hour limits)           │   │
│  │  • Attestation requirement for high earners              │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## LaborOracle Contract

**Purpose**: Replace complex "Health Score" with transparent `Hours × Market Rate` valuation.

### Contract Interface

```solidity
// contracts/LaborOracle.sol
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/AccessControl.sol";

contract LaborOracle is AccessControl {
    bytes32 public constant UPDATER_ROLE = keccak256("UPDATER_ROLE");

    struct JobType {
        uint256 ratePerHour;      // In USD cents (e.g., 5000 = $50/hr)
        uint256 maxRateCap;       // Anti-gaming: max rate allowed
        uint256 maxHoursPerWeek;  // Anti-gaming: max hours per contributor
        bool requiresAttestation; // Requires EAS attestation
        bool isActive;
    }

    mapping(uint256 => JobType) public jobTypes;
    mapping(address => mapping(uint256 => uint256)) public weeklyHours; // user => week => hours

    function setJobType(
        uint256 jobTypeId,
        uint256 ratePerHour,
        uint256 maxRateCap,
        uint256 maxHoursPerWeek,
        bool requiresAttestation
    ) external onlyRole(UPDATER_ROLE) {
        require(ratePerHour <= maxRateCap, "Rate exceeds cap");
        jobTypes[jobTypeId] = JobType({
            ratePerHour: ratePerHour,
            maxRateCap: maxRateCap,
            maxHoursPerWeek: maxHoursPerWeek,
            requiresAttestation: requiresAttestation,
            isActive: true
        });
        emit JobTypeUpdated(jobTypeId, ratePerHour, maxRateCap, maxHoursPerWeek);
    }

    function calculateEquityValue(
        address contributor,
        uint256 jobTypeId,
        uint256 hoursWorked
    ) external returns (uint256 equityValue) {
        JobType storage job = jobTypes[jobTypeId];
        require(job.isActive, "Job type inactive");

        // Anti-gaming: Check weekly hour cap
        uint256 currentWeek = block.timestamp / 1 weeks;
        uint256 newWeeklyTotal = weeklyHours[contributor][currentWeek] + hoursWorked;
        require(newWeeklyTotal <= job.maxHoursPerWeek, "Exceeds weekly cap");

        weeklyHours[contributor][currentWeek] = newWeeklyTotal;

        // Calculate: hours × rate (in cents) / 100 = USD value
        equityValue = (hoursWorked * job.ratePerHour) / 100;

        return equityValue;
    }

    event JobTypeUpdated(uint256 indexed jobTypeId, uint256 rate, uint256 maxCap, uint256 maxHours);
}
```

### Job Type Registry (Beta Configuration)

| Job Type ID | Category      | Rate/Hour | Max Cap | Max Hours/Week | Attestation Required |
| ----------- | ------------- | --------- | ------- | -------------- | -------------------- |
| 1           | General Labor | $50       | $75     | 40             | No                   |
| 2           | Skilled Trade | $75       | $125    | 40             | No                   |
| 3           | Professional  | $100      | $200    | 40             | Yes (>$5k/mo)        |
| 4           | Executive     | $150      | $300    | 30             | Yes (always)         |
| 5           | Advisory      | $200      | $500    | 20             | Yes (always)         |

### Anti-Gaming Framework

#### 1. Rate Caps

**Purpose**: Prevent rate inflation by limiting maximum hourly rates per job category.

**Implementation**:

- `maxRateCap` field in JobType struct
- Enforced at setJobType() validation
- Governance-controlled via UPDATER_ROLE

**Example**:

```solidity
// Prevent setting Professional rate > $200/hr
jobTypes[3].maxRateCap = 20000; // $200 in cents
// This call would revert:
setJobType(3, 25000, 20000, 40, true); // Rate exceeds cap
```

#### 2. Hour Caps

**Purpose**: Prevent hour inflation and wash trading.

**Implementation**:

- `maxHoursPerWeek` per job type
- Weekly tracking via `weeklyHours[contributor][currentWeek]`
- Resets automatically each Monday (block.timestamp / 1 weeks)

**Example**:

```solidity
// Professional can't log >40 hours/week
uint256 currentWeek = block.timestamp / 1 weeks;
uint256 logged = weeklyHours[contributor][currentWeek]; // 35 hours
uint256 newHours = 10; // Trying to log 10 more
require(logged + newHours <= 40, "Exceeds weekly cap"); // Would revert
```

#### 3. Attestation Requirement

**Purpose**: Require supervisor verification for high-earning roles.

**Implementation**:

- `requiresAttestation` flag in JobType
- Integration with Ethereum Attestation Service (EAS)
- Triggered by either:
  - Job type always requires (Executive, Advisory)
  - Monthly earnings exceed $5,000 (Professional tier)

**EAS Schema** (Planned):

```typescript
interface LaborAttestation {
  contributor: address; // Worker wallet
  supervisor: address; // Supervisor wallet
  jobTypeId: uint256; // Job type
  hoursWorked: uint256; // Hours verified
  period: uint256; // Week number
  qualityRating: uint256; // 80-120 (0.8x - 1.2x multiplier)
  attestationUID: bytes32; // EAS attestation ID
}
```

#### 4. Governance Freeze

**Purpose**: Emergency stop mechanism for detected abuse.

**Implementation**:

- `pause()` function via UPDATER_ROLE
- Freezes all `calculateEquityValue()` calls
- Requires ENDAO governance vote to activate
- Automatic unfreeze after investigation period (7 days)

### Equity Value Calculation

**Formula**:

```
TEQ Minted = Hours Worked × Hourly Rate × Quality Multiplier

Where:
- Hours Worked: Verified by attestation or client confirmation (1-60 per week)
- Hourly Rate: From LaborOracle job type registry (e.g., $100/hr for Professional)
- Quality Multiplier: 0.8x - 1.2x based on client rating (default 1.0x)
```

**Example Calculations**:

```typescript
// Example 1: Professional (no attestation yet)
JobType: Professional (ID 3)
Rate: $100/hr
Hours: 20 hours/week
Quality: 1.0x (default)

TEQ = 20 × $100 × 1.0 = $2,000 in equity value
TEQ Tokens = 2000 * 1e18 (decimal adjusted)

// Example 2: Executive with quality bonus
JobType: Executive (ID 4)
Rate: $150/hr
Hours: 25 hours/week
Quality: 1.2x (excellent rating)

TEQ = 25 × $150 × 1.2 = $4,500 in equity value
TEQ Tokens = 4500 * 1e18

// Example 3: Hour cap violation (rejected)
JobType: Professional (ID 3)
Rate: $100/hr
Hours: 45 hours/week (exceeds 40hr cap)
Result: Transaction reverts with "Exceeds weekly cap"
```

---

## ServiceMarketplace Contract

**Purpose**: Escrow system enabling "Double-Dip" where providers earn both TCR payment AND TEQ equity.

### Contract Interface

```solidity
// contracts/ServiceMarketplace.sol
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";
import "./interfaces/IERC20.sol";
import "./TEQ.sol";
import "./LaborOracle.sol";
import "./EDGVault.sol";

contract ServiceMarketplace is ReentrancyGuard, AccessControl {
    IERC20 public tcr;
    TEQ public teq;
    LaborOracle public laborOracle;
    EDGVault public edgVault;
    address public treasury;
    uint256 public protocolFeeBps = 300; // 3%

    struct Job {
        address client;
        address provider;
        uint256 amount;          // TCR amount
        uint256 jobTypeId;
        uint256 hoursWorked;
        JobStatus status;
    }

    enum JobStatus { Created, InProgress, Completed, Disputed, Cancelled }

    mapping(uint256 => Job) public jobs;
    uint256 public nextJobId;

    function createJob(
        address provider,
        uint256 amount,
        uint256 jobTypeId,
        uint256 estimatedHours
    ) external nonReentrant returns (uint256 jobId) {
        // Transfer TCR to escrow
        tcr.transferFrom(msg.sender, address(this), amount);

        jobId = nextJobId++;
        jobs[jobId] = Job({
            client: msg.sender,
            provider: provider,
            amount: amount,
            jobTypeId: jobTypeId,
            hoursWorked: estimatedHours,
            status: JobStatus.Created
        });

        emit JobCreated(jobId, msg.sender, provider, amount, jobTypeId);
    }

    function completeJob(uint256 jobId, uint256 actualHours) external nonReentrant {
        Job storage job = jobs[jobId];
        require(msg.sender == job.client, "Only client");
        require(job.status == JobStatus.InProgress, "Invalid status");

        job.hoursWorked = actualHours;
        job.status = JobStatus.Completed;

        // Calculate fee with EDG discount
        uint256 baseFee = (job.amount * protocolFeeBps) / 10000;
        uint256 actualFee = edgVault.calculateDiscountedFee(job.client, baseFee);
        uint256 payout = job.amount - actualFee;

        // THE DOUBLE-DIP:
        // 1. Pay provider in TCR
        tcr.transfer(job.provider, payout);

        // 2. Send fee to treasury
        if (actualFee > 0) {
            tcr.transfer(treasury, actualFee);
        }

        // 3. Calculate and mint equity (TEQ)
        uint256 equityValue = laborOracle.calculateEquityValue(
            job.provider,
            job.jobTypeId,
            actualHours
        );
        teq.mint(job.provider, equityValue * 1e18, equityValue);

        emit JobCompleted(jobId, payout, equityValue, actualFee);
    }

    event JobCreated(uint256 indexed jobId, address client, address provider, uint256 amount, uint256 jobTypeId);
    event JobCompleted(uint256 indexed jobId, uint256 payout, uint256 equityValue, uint256 fee);
}
```

### The Double-Dip Explained

**Concept**: Service providers receive BOTH immediate payment (TCR) AND long-term equity (TEQ) for the same work.

**Benefits**:

1. **Immediate Liquidity**: TCR provides stable purchasing power
2. **Long-term Alignment**: TEQ creates ownership stake in platform success
3. **Cost-Plus Valuation**: Equity based on fair market rates, not speculative pricing
4. **No Dilution Surprise**: Transparent, predictable equity allocation

**Example Flow**:

```typescript
// Job: Website Development
Client: DAOCorp
Provider: Alice
Job Type: Professional (ID 3, $100/hr)
Hours: 40 hours
TCR Amount: 4000 TCR ($4,000)
Protocol Fee: 3% = 120 TCR
EDG Discount: Client has Gold tier = 100% fee discount

// Execution:
1. Client deposits 4000 TCR to escrow ✓
2. Alice completes 40 hours of work ✓
3. Client approves completion ✓

// Payouts:
TCR to Alice: 4000 TCR (no fee due to Gold discount)
TCR to Treasury: 0 TCR (fee waived)
TEQ to Alice: 4000 TEQ (40 hrs × $100/hr × 1.0 quality)

// Result:
Alice receives:
- 4000 TCR (immediate payment, $4,000 purchasing power)
- 4000 TEQ (equity stake, future profit-sharing rights)
```

### Job Status Lifecycle

```
┌─────────────────────────────────────────────────────────────┐
│                    JOB STATUS FLOW                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  CREATED                                                    │
│  ├── Client creates job                                     │
│  ├── TCR locked in escrow                                   │
│  └── Provider assigned                                      │
│       │                                                     │
│       ▼                                                     │
│  IN_PROGRESS                                                │
│  ├── Provider accepts job                                   │
│  ├── Work begins                                            │
│  └── Hours tracked                                          │
│       │                                                     │
│       ▼                                                     │
│  ┌─────────────────────────────────────────┐               │
│  │         Completion Options              │               │
│  ├─────────────────────────────────────────┤               │
│  │                                         │               │
│  │  SUCCESS PATH                           │               │
│  │  ├── Client approves                    │               │
│  │  ├── TCR + TEQ released                 │               │
│  │  └── Status: COMPLETED ✓                │               │
│  │                                         │               │
│  │  DISPUTE PATH                           │               │
│  │  ├── Client/provider disagrees          │               │
│  │  ├── Arbitration initiated              │               │
│  │  └── Status: DISPUTED ⚠️                │               │
│  │                                         │               │
│  │  CANCELLATION PATH                      │               │
│  │  ├── Mutual agreement                   │               │
│  │  ├── TCR refunded to client             │               │
│  │  └── Status: CANCELLED ✗                │               │
│  │                                         │               │
│  └─────────────────────────────────────────┘               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Protocol Fee Structure

| Fee Type         | Base Rate | EDG Discount Tiers              | Recipient        |
| ---------------- | --------- | ------------------------------- | ---------------- |
| Service Fee      | 3%        | Gold: 100% off, Silver: 50% off | EnDAO Treasury   |
| Dispute Fee      | 5%        | No discount                     | Arbitration pool |
| Cancellation Fee | 1%        | No discount                     | Restock fee      |

**Fee Calculation**:

```solidity
// Base fee
uint256 baseFee = (amount * 300) / 10000; // 3%

// Apply EDG discount
uint256 discountTier = edgVault.getDiscountTier(client);
// Gold (tier 100): baseFee * 0 / 100 = 0 (100% off)
// Silver (tier 50): baseFee * 50 / 100 = 50% fee
uint256 actualFee = baseFee * (100 - discountTier) / 100;
```

---

## Integration with Existing Systems

### TEQ Token Integration

**TEQ Minting Authority**: ServiceMarketplace contract has `CONTROLLER_ROLE`

```solidity
// TEQ.sol
function mint(address to, uint256 amount, uint256 laborValueUSD)
    external
    onlyRole(CONTROLLER_ROLE)
{
    cumulativeLaborValueUSD[to] += laborValueUSD;
    _mint(to, amount);
    emit EquityMinted(to, amount, laborValueUSD, cumulativeLaborValueUSD[to]);
}
```

### TCR Bridge Integration

**Minting Authority**: Bridge service has `BRIDGE_ROLE` for fiat on/off-ramp

```solidity
// TCR.sol
function mint(address to, uint256 amount)
    external
    onlyRole(BRIDGE_ROLE)
{
    _mint(to, amount);
}

function burn(address from, uint256 amount)
    external
    onlyRole(BRIDGE_ROLE)
{
    _burn(from, amount);
}
```

### Database Integration

**Labor Stats Tracking** (`packages/shared-types/src/user.ts` - import from `@endao/shared-types`):

```typescript
interface UserProfile {
  laborStats?: {
    totalHoursWorked: number;
    totalTCREarned: string;
    totalTEQEarned: string;
    averageHourlyRate: number;
    jobTypes: Record<number, number>; // jobTypeId -> hours
  };
}
```

**Job Repository** (`src/lib/repositories/job.repository.ts`):

```typescript
interface Job {
  id: string;
  chainJobId: number; // Maps to on-chain job ID
  daoId: string;
  clientId: string;
  providerId: string;
  amount: string;
  jobTypeId: number;
  status: 'created' | 'in_progress' | 'completed' | 'disputed' | 'cancelled';
  createdAt: Timestamp;
  completedAt?: Timestamp;
  transactionHash?: string;
}
```

---

## Testing Requirements

### LaborOracle Tests

- Rate cap enforcement
- Hour cap tracking and reset
- Weekly rollover logic
- Multi-user hour tracking
- Attestation requirement triggers
- Governance freeze functionality

### ServiceMarketplace Tests

- Escrow deposit and withdrawal
- Job status transitions
- Fee calculation with EDG discounts
- TEQ minting integration
- Dispute resolution flow
- Cancellation refund logic

### Integration Tests

- End-to-end job completion flow
- TCR + TEQ double-dip execution
- Multi-job concurrent processing
- Gas optimization benchmarks

**Coverage Target**: 100% for both contracts

---

## Security Considerations

### Access Control

- `UPDATER_ROLE` for LaborOracle limited to governance multi-sig
- `CONTROLLER_ROLE` for TEQ minting limited to ServiceMarketplace
- `DEFAULT_ADMIN_ROLE` protected by TimelockController

### Reentrancy Protection

- All external calls use `nonReentrant` modifier
- Checks-Effects-Interactions pattern enforced
- No external calls before state updates

### Rate Limit Protections

- Weekly hour caps prevent wash trading
- Rate caps prevent inflation attacks
- Attestation requirement for high earners

### Dispute Resolution

**Planned**: Integration with Kleros or similar arbitration protocol
**Fallback**: Manual multi-sig resolution during beta phase

---

**Last Updated**: December 5, 2025
**Phase**: Phase 2 (Planned Development)
**Status**: Specification Complete, Awaiting Implementation
