# SpendingLimitsModule (Zodiac)

On-chain spending limit enforcement for treasury operations via Gnosis Safe Zodiac modules.

## Overview

**Purpose**: Enforce daily spending limits and transaction thresholds at the smart contract level for Tier 3+ DAOs.

**Architecture**: Zodiac module attached to Gnosis Safe, enabling secure delegation of treasury operations to Ops Wallet with programmatic enforcement of spending rules.

**Phase**: Phase 2 (On-chain enforcement)
**Phase 1 Alternative**: App-layer validation via `OpsWalletService` (interim solution)

---

## Two-Phase Implementation Strategy

### Phase 1: App-Layer Enforcement (MVP)

**Location**: `src/lib/services/treasury/ops-wallet.service.ts`

**Characteristics**:

- Validation runs in Next.js API routes before Safe transaction creation
- Database tracking of daily spend totals
- Client-side UX warnings for limit violations
- **Limitation**: Can be bypassed by direct Safe interaction (not through EnDAO platform)

**Use Case**: Tier 3 DAOs during beta testing period

### Phase 2: On-Chain Enforcement (Production)

**Location**: `contracts/SpendingLimitsModule.sol` (Zodiac module)

**Characteristics**:

- Validation enforced by Ethereum smart contract
- Cannot be bypassed regardless of transaction origin
- Gas cost for enforcement (~50k gas per transaction)
- **Benefit**: Trustless, protocol-enforced spending rules

**Use Case**: Tier 3+ DAOs requiring maximum security and decentralization

---

## Architecture: Ops Wallet Pattern

```
┌─────────────────────────────────────────────────────────────────┐
│                      TREASURY TIER 3                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  MAIN SAFE (VAULT)                                               │
│  ┌───────────────────────────────────────────────────────┐      │
│  │  • 2-of-3 multi-sig                                    │      │
│  │  • Holds majority of funds                             │      │
│  │  • Requires full governance proposal for spending      │      │
│  │  • Balance: $100,000+                                  │      │
│  └────────────────────┬──────────────────────────────────┘      │
│                       │                                          │
│                       │ Periodic refill via proposal             │
│                       │ (e.g., $5,000/month)                     │
│                       ▼                                          │
│  OPS WALLET (QUICK SPEND)                                        │
│  ┌───────────────────────────────────────────────────────┐      │
│  │  • Single-signer (treasurer role)                     │      │
│  │  • SpendingLimitsModule enforces rules:               │      │
│  │    - maxDailySpend: $1,000                             │      │
│  │    - maxSingleTransaction: $500                        │      │
│  │    - requiresApprovalAbove: $250                       │      │
│  │  • Balance: $5,000 (refilled monthly)                  │      │
│  └───────────────────────────────────────────────────────┘      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## SpendingLimitsModule Contract

### Zodiac Module Interface

```solidity
// contracts/SpendingLimitsModule.sol
// SPDX-License-Identifier: LGPL-3.0-only
pragma solidity ^0.8.20;

import "@gnosis.pm/zodiac/contracts/core/Module.sol";

contract SpendingLimitsModule is Module {
    struct SpendingConfig {
        uint256 maxDailySpend;           // In wei or token units
        uint256 maxSingleTransaction;
        uint256 requiresApprovalAbove;
        address[] approvers;
        uint256 approvalThreshold;
    }

    struct DailyUsage {
        uint256 amount;
        uint256 resetTimestamp;
    }

    mapping(address => SpendingConfig) public configs;  // token => config
    mapping(address => DailyUsage) public dailyUsage;   // token => usage

    function setUp(bytes memory initParams) public override {
        __Ownable_init();
        (address _owner, address _avatar, address _target) = abi.decode(
            initParams,
            (address, address, address)
        );
        setAvatar(_avatar);
        setTarget(_target);
        transferOwnership(_owner);
    }

    function executeTransaction(
        address to,
        uint256 value,
        bytes calldata data,
        Enum.Operation operation,
        address token
    ) external returns (bool success) {
        SpendingConfig storage config = configs[token];

        // Reset daily usage if new day
        if (block.timestamp >= dailyUsage[token].resetTimestamp + 1 days) {
            dailyUsage[token] = DailyUsage({
                amount: 0,
                resetTimestamp: block.timestamp
            });
        }

        uint256 amount = token == address(0) ? value : _extractAmount(data);

        // Check single transaction limit
        require(
            amount <= config.maxSingleTransaction,
            "Exceeds single transaction limit"
        );

        // Check daily limit
        require(
            dailyUsage[token].amount + amount <= config.maxDailySpend,
            "Exceeds daily spend limit"
        );

        // Update daily usage
        dailyUsage[token].amount += amount;

        // If above approval threshold, require multi-sig approval
        if (amount > config.requiresApprovalAbove) {
            require(
                _hasApproval(msg.sender, config),
                "Requires additional approval"
            );
        }

        // Execute via Safe
        success = exec(to, value, data, operation);
        require(success, "Module transaction failed");

        emit TransactionExecuted(to, value, token, amount);
    }

    function _extractAmount(bytes calldata data) private pure returns (uint256) {
        // Decode ERC20 transfer data to extract amount
        // Assumes standard transfer(address,uint256) or transferFrom signature
        if (data.length >= 68) {
            return abi.decode(data[4:68], (uint256));
        }
        return 0;
    }

    function _hasApproval(address requester, SpendingConfig storage config)
        private
        view
        returns (bool)
    {
        // Check if requester is in approvers list
        for (uint256 i = 0; i < config.approvers.length; i++) {
            if (config.approvers[i] == requester) {
                return true;
            }
        }
        return false;
    }

    function setSpendingConfig(
        address token,
        uint256 maxDailySpend,
        uint256 maxSingleTransaction,
        uint256 requiresApprovalAbove,
        address[] calldata approvers,
        uint256 approvalThreshold
    ) external onlyOwner {
        configs[token] = SpendingConfig({
            maxDailySpend: maxDailySpend,
            maxSingleTransaction: maxSingleTransaction,
            requiresApprovalAbove: requiresApprovalAbove,
            approvers: approvers,
            approvalThreshold: approvalThreshold
        });

        emit ConfigUpdated(token, maxDailySpend, maxSingleTransaction);
    }

    event TransactionExecuted(address to, uint256 value, address token, uint256 amount);
    event ConfigUpdated(address token, uint256 maxDaily, uint256 maxSingle);
}
```

---

## Configuration Examples

### Tier 3: Established DAO

**Typical Configuration**:

```typescript
// Default config for established nonprofit/small business
const tier3Config = {
  mainSafeAddress: '0x...MainSafe',
  opsWalletAddress: '0x...OpsWallet',
  maxDailySpend: 1000, // $1,000 USD
  maxSingleTransaction: 500, // $500 USD
  requiresApprovalAbove: 250, // $250 USD
  treasurerUserIds: ['user123'], // Single treasurer
  refillThreshold: 1000, // Refill when balance < $1,000
};
```

**On-Chain Configuration** (USDC on Base):

```solidity
// USDC address on Base: 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913
setSpendingConfig(
    0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913,  // USDC token
    1000 * 1e6,                                  // $1,000 daily (6 decimals)
    500 * 1e6,                                   // $500 single tx
    250 * 1e6,                                   // $250 approval threshold
    [0x...Treasurer1, 0x...Treasurer2],          // Approvers
    1                                            // Require 1 approval
)
```

### Tier 4: Enterprise DAO

**Typical Configuration**:

```typescript
// Enterprise config with higher limits
const tier4Config = {
  mainSafeAddress: '0x...MainSafe',
  opsWalletAddress: '0x...OpsWallet',
  maxDailySpend: 10000, // $10,000 USD
  maxSingleTransaction: 5000, // $5,000 USD
  requiresApprovalAbove: 1000, // $1,000 USD
  treasurerUserIds: ['user123', 'user456'], // Multiple treasurers
  refillThreshold: 5000, // Refill when balance < $5,000
};
```

---

## Phase 1: App-Layer Implementation

### OpsWalletService (TypeScript)

**Location**: `src/lib/services/treasury/ops-wallet.service.ts`

```typescript
interface OpsWalletConfig {
  mainSafeAddress: string;
  opsWalletAddress: string;
  maxDailySpend: number; // in USD
  maxSingleTransaction: number; // in USD
  requiresApprovalAbove: number; // in USD
  treasurerUserIds: string[]; // Single-signers
  refillThreshold: number; // Auto-request refill when balance below this
}

class OpsWalletService {
  async validateTransaction(
    daoId: string,
    amount: number,
    treasurerId: string
  ): Promise<ValidationResult> {
    const config = await this.getConfig(daoId);

    // Check single transaction limit
    if (amount > config.maxSingleTransaction) {
      return { valid: false, reason: 'Exceeds single transaction limit' };
    }

    // Check daily spend
    const todaySpend = await this.getDailySpend(daoId);
    if (todaySpend + amount > config.maxDailySpend) {
      return { valid: false, reason: 'Exceeds daily spend limit' };
    }

    // Check if requires additional approval
    if (amount > config.requiresApprovalAbove) {
      return { valid: true, requiresApproval: true };
    }

    return { valid: true, requiresApproval: false };
  }

  async executeOpsTransaction(
    daoId: string,
    recipient: string,
    amount: number,
    treasurerId: string
  ): Promise<TransactionResult> {
    const validation = await this.validateTransaction(
      daoId,
      amount,
      treasurerId
    );

    if (!validation.valid) {
      throw new Error(validation.reason);
    }

    if (validation.requiresApproval) {
      // Create approval request, notify other treasurer
      return this.createApprovalRequest(daoId, recipient, amount, treasurerId);
    }

    // Execute directly via ops wallet Safe
    return this.executeDirectly(daoId, recipient, amount);
  }

  async getDailySpend(daoId: string): Promise<number> {
    // Query database for today's transactions
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data } = await supabase
      .from('treasury_transactions')
      .select('amount')
      .eq('dao_id', daoId)
      .eq('wallet_type', 'ops')
      .gte('timestamp', today.toISOString());

    return data?.reduce((sum, row) => sum + row.amount, 0) ?? 0;
  }
}
```

### API Route Integration

**Location**: `src/app/api/treasury/ops-wallet/execute/route.ts`

```typescript
export async function POST(req: Request) {
  const { daoId, recipient, amount } = await req.json();
  const userId = req.headers.get('x-auth-uid');

  // Validate user is treasurer
  const dao = await daoRepository.findById(daoId);
  const member = await daoMemberRepository.findByDaoAndUser(daoId, userId);

  if (member.role !== 'treasurer' && member.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  // Validate spending limits (Phase 1: App-layer)
  const validation = await opsWalletService.validateTransaction(
    daoId,
    amount,
    userId
  );

  if (!validation.valid) {
    return NextResponse.json({ error: validation.reason }, { status: 400 });
  }

  if (validation.requiresApproval) {
    // Create approval request instead of executing
    const approvalRequest = await opsWalletService.createApprovalRequest(
      daoId,
      recipient,
      amount,
      userId
    );
    return NextResponse.json({
      requiresApproval: true,
      requestId: approvalRequest.id,
    });
  }

  // Execute transaction
  const result = await treasuryService.executeOpsWalletTransaction({
    daoId,
    recipient,
    amount,
    executedBy: userId,
  });

  return NextResponse.json(result);
}
```

---

## Transaction Flow Diagrams

### Auto-Approved Transaction (< $250)

```
┌──────────────────────────────────────────────────────────────┐
│              AUTO-APPROVED OPS TRANSACTION                    │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  1. TREASURER INITIATES                                       │
│  ┌─────────────┐                                              │
│  │ Treasurer   │──▶ "Pay supplier $150"                       │
│  └─────────────┘                                              │
│                                                               │
│  2. VALIDATION                                                │
│  ┌──────────────────────────────────────┐                    │
│  │  OpsWalletService.validateTransaction │                    │
│  │  ├─ Single tx: $150 < $500 ✓          │                    │
│  │  ├─ Daily: $150 + $200 = $350 < $1000 ✓│                   │
│  │  └─ Approval: $150 < $250 (auto) ✓    │                    │
│  └──────────────────────────────────────┘                    │
│                                                               │
│  3. EXECUTION                                                 │
│  ┌────────────────────────────────────────────┐              │
│  │  Safe.execTransaction()                    │              │
│  │  • Treasurer signs with Privy               │              │
│  │  • Transaction broadcast to Base           │              │
│  │  • 150 USDC transferred                    │              │
│  └────────────────────────────────────────────┘              │
│                                                               │
│  4. RECORDING                                                 │
│  ┌────────────────────────────────────────────┐              │
│  │  LedgerRecordingService.recordTransaction   │              │
│  │  • Category: Operating Expense             │              │
│  │  • Daily total updated: $350               │              │
│  │  • Receipt attached                        │              │
│  └────────────────────────────────────────────┘              │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

### Approval-Required Transaction (> $250)

```
┌──────────────────────────────────────────────────────────────┐
│            APPROVAL-REQUIRED OPS TRANSACTION                  │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  1. TREASURER INITIATES                                       │
│  ┌─────────────┐                                              │
│  │ Treasurer1  │──▶ "Pay contractor $400"                     │
│  └─────────────┘                                              │
│                                                               │
│  2. VALIDATION                                                │
│  ┌──────────────────────────────────────┐                    │
│  │  OpsWalletService.validateTransaction │                    │
│  │  ├─ Single tx: $400 < $500 ✓          │                    │
│  │  ├─ Daily: $400 + $350 = $750 < $1000 ✓│                   │
│  │  └─ Approval: $400 > $250 ⚠️ REQUIRED │                    │
│  └──────────────────────────────────────┘                    │
│                                                               │
│  3. APPROVAL REQUEST                                          │
│  ┌────────────────────────────────────────────┐              │
│  │  createApprovalRequest()                   │              │
│  │  • Notification sent to Treasurer2         │              │
│  │  • Email: "Approve $400 payment?"          │              │
│  │  • Push notification via FCM              │              │
│  └────────────────────────────────────────────┘              │
│                                                               │
│  4. TREASURER2 APPROVES                                       │
│  ┌────────────────────────────────────────────┐              │
│  │  OpsWalletService.approveRequest()         │              │
│  │  • Treasurer2 reviews details              │              │
│  │  • Clicks "Approve"                        │              │
│  │  • Both treasurers sign transaction        │              │
│  └────────────────────────────────────────────┘              │
│                                                               │
│  5. EXECUTION (same as auto-approved)                         │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

---

## Refill Mechanism

### Automatic Refill Request

```typescript
// Triggered when ops wallet balance falls below threshold
async function checkRefillNeeded(daoId: string): Promise<void> {
  const config = await opsWalletService.getConfig(daoId);
  const balance = await treasuryService.getOpsWalletBalance(daoId);

  if (balance < config.refillThreshold) {
    // Create governance proposal to refill ops wallet
    await proposalService.createProposal({
      daoId,
      type: 'funding',
      title: 'Refill Ops Wallet',
      description: `Ops wallet balance ($${balance}) below threshold ($${config.refillThreshold}). Requesting refill.`,
      amount: config.maxDailySpend * 5, // 5 days of max spending
      recipient: config.opsWalletAddress,
      executionMethod: 'treasury',
      autoGenerated: true,
    });
  }
}
```

---

## Security Considerations

### Phase 1 Limitations

**Bypass Risk**: App-layer validation can be bypassed by interacting directly with Safe
**Mitigation**:

- Clear documentation that ops wallet is for platform transactions only
- Monitoring for off-platform transactions
- Audit logs for all treasury operations

### Phase 2 Guarantees

**On-Chain Enforcement**: SpendingLimitsModule is cryptographically enforced
**Cannot Bypass**: Even Safe owners cannot exceed limits without disabling module
**Audit Trail**: All transactions emit events for transparency

### Emergency Override

**Scenario**: Critical payment needed that exceeds limits

**Phase 1 Solution**:

```typescript
// Admin can override in emergency
if (member.role === 'admin' && emergencyOverride === true) {
  // Execute without validation, log audit trail
  await auditLogService.logEmergencyOverride(daoId, amount, userId, reason);
}
```

**Phase 2 Solution**:

```solidity
// Disable module temporarily via Safe multi-sig
safe.disableModule(prevModule, spendingLimitsModule);
// Execute emergency transaction
// Re-enable module
safe.enableModule(spendingLimitsModule);
```

---

## Migration Path: Phase 1 → Phase 2

### Step 1: Deploy SpendingLimitsModule

```bash
# Deploy module to Base mainnet
forge create SpendingLimitsModule --rpc-url $BASE_RPC

# Verify on Basescan
forge verify-contract $MODULE_ADDRESS SpendingLimitsModule
```

### Step 2: Enable Module on Safe

```typescript
// Via Safe Transaction Service
const enableModuleTx = await safe.createEnableModuleTx(moduleAddress);
await safeService.proposeTransaction(safeAddress, enableModuleTx);
// Multi-sig signs and executes
```

### Step 3: Configure Spending Limits

```typescript
// Set initial config via module
const configTx = {
  to: moduleAddress,
  data: spendingLimitsModule.interface.encodeFunctionData('setSpendingConfig', [
    USDC_ADDRESS,
    ethers.parseUnits('1000', 6), // $1,000 daily
    ethers.parseUnits('500', 6), // $500 single tx
    ethers.parseUnits('250', 6), // $250 approval threshold
    [treasurer1, treasurer2],
    1,
  ]),
};
await safeService.proposeTransaction(safeAddress, configTx);
```

### Step 4: Update Frontend

```typescript
// Detect if DAO has module enabled
const hasSpendingModule = await opsWalletService.hasOnChainEnforcement(daoId);

if (hasSpendingModule) {
  // Use module for validation
  await executeViaModule(transaction);
} else {
  // Use app-layer validation (Phase 1)
  await executeViaAppLayer(transaction);
}
```

---

**Last Updated**: December 5, 2025
**Phase**: Phase 2 (On-chain), Phase 1 (App-layer interim)
**Status**: Phase 1 implementation in progress
