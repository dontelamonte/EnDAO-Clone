# Competitive Positioning & Market Intelligence Research

**Date**: December 6, 2025
**Sources**: Perplexity Deep Research + Gemini Deep Research + Internal Synthesis
**Purpose**: Define EnDAO's competitive positioning, moat strategy, and segment-specific requirements

**Related Research**:

- [OGP Civic Tech Research](./OGP_CIVIC_TECH_RESEARCH.md) - Direct civic engagement competitors
- [Institutional Tools Research](./INSTITUTIONAL_TOOLS_RESEARCH.md) - Adjacent collaboration tools
- [Digital PB & AI Research](./DIGITAL_PB_AI_RESEARCH.md) - Deliberative democracy & AI integration

---

## Executive Summary

### Core Thesis

> **The market opportunity is not another software interface, but hybrid infrastructure that bridges DAO operational efficiency with traditional legal entity requirements.**

The "long tail" of institutional entities (HOAs, investment clubs, nonprofits, co-ops) operates in a **"governance void"** - relying on spreadsheets and email chains that create operational fragility and legal liability. This void is rapidly expanding due to regulatory pressure (Corporate Transparency Act), rendering manual governance obsolete and dangerous.

### The "Mullet Strategy"

**Web2 Front / Web3 Back**

| Layer     | User Experience                             | Technical Reality                                     |
| --------- | ------------------------------------------- | ----------------------------------------------------- |
| **Front** | Familiar fintech dashboard (like Brex/Ramp) | Email login, SSO, no crypto terminology               |
| **Back**  | Invisible blockchain infrastructure         | Account abstraction, immutable audit trails, gas-free |

Users never see "gas," "on-chain," or "signatures." They click "Vote" and the system handles cryptographic signing invisibly.

### Core Positioning Statements

> **"Diligent-level governance + crypto-grade transparency packaged in Notion-simple UX"**

> **"The operating system for the next generation of institutions"**

### Market Opportunity

| Current State                                            | EnDAO Solution                                      |
| -------------------------------------------------------- | --------------------------------------------------- |
| 88% of spreadsheets contain significant errors           | Automated, error-proof ledgers                      |
| Fragmented tooling (QuickBooks + Sheets + Email + Drive) | Unified governance + treasury platform              |
| "Key Person" risk (knowledge leaves with volunteers)     | Persistent, immutable organizational state          |
| Manual CTA compliance (30-day filing window)             | Governance event triggers automatic filing          |
| Treasury opacity (no vote-to-payment linkage)            | Programmatic execution: vote passes → funds release |

---

## The Governance Void: Why "Non-Consumption" is the Real Competitor

### The Spreadsheet Dependency Crisis

**The primary competitor is not incumbent software - it's the ad-hoc reliance on tools never designed for governance.**

| Risk                | Impact                                             | Evidence                                          |
| ------------------- | -------------------------------------------------- | ------------------------------------------------- |
| **Data Integrity**  | 88% of spreadsheets contain significant errors     | Formula corruptions, data entry mistakes          |
| **Legal Liability** | Incorrect K-1s, dues assessments, budget forecasts | IRS scrutiny, special assessments, litigation     |
| **Security**        | PII transmitted via unencrypted email attachments  | GDPR/CCPA violations, data breaches               |
| **Continuity**      | "Key Person" risk when volunteers leave            | New boards inherit disconnected files, no context |

### The Communication Fracture

| Problem              | Impact                                                           |
| -------------------- | ---------------------------------------------------------------- |
| **Phishing Vector**  | Email is primary attack surface; scammers impersonate treasurers |
| **Voting Integrity** | Email/SurveyMonkey lacks identity verification, non-repudiation  |
| **Execution Gap**    | Decisions (votes) are disconnected from actions (payments)       |

### The Regulatory Precipice: CTA Compliance Shock

The Corporate Transparency Act creates **urgent, immediate demand** for governance automation:

| Requirement                               | Challenge                                                   | EnDAO Solution                                |
| ----------------------------------------- | ----------------------------------------------------------- | --------------------------------------------- |
| BOI reports for all incorporated entities | Disclose PII for all individuals with "substantial control" | Automated officer registry                    |
| $500/day civil penalties                  | Non-compliance is expensive                                 | Compliance reminders + filing automation      |
| 30-day update window                      | Any board change requires FinCEN filing                     | Governance event = automatic compliance event |
| Dynamic reporting                         | Not one-time; every election/resignation triggers update    | Vote result → automatic BOI update            |

**Key Insight**: Existing tools treat governance and compliance as separate silos. The CTA links them: **a governance event IS a compliance event**.

---

## Competitive Landscape: The Four Categories

### Competitive Matrix Overview

| Feature                    | Traditional Board (Diligent) | Vertical SaaS (PayHOA) | Crypto-Native (Aragon) | Civic Tech (Loomio) | **EnDAO Opportunity**       |
| -------------------------- | ---------------------------- | ---------------------- | ---------------------- | ------------------- | --------------------------- |
| **Governance Depth**       | High (Formal)                | Low                    | High (Programmatic)    | High (Deliberative) | Programmatic + Deliberative |
| **Operational Ops**        | Low                          | High                   | Low                    | Low                 | Integrated (Banking)        |
| **UX/Usability**           | Medium                       | High                   | Low                    | Medium              | Web2 Feel, Web3 Rails       |
| **Compliance (Tax/Legal)** | High                         | High                   | Low                    | Low                 | Automated Compliance        |
| **Cost Structure**         | $$$ (High)                   | $$ (Medium)            | $ (Gas fees)           | $ (Low)             | Freemium → Transactional    |
| **Execution**              | Manual                       | Manual                 | Programmatic           | Manual              | Programmatic                |

### Category 1: Enterprise Board Portals (Diligent, BoardEffect, OnBoard)

**Strengths**:

- Military-grade encryption, SOC2 compliance
- Excellent "Board Book" workflow for PDF compilation
- Granular access controls

**Weaknesses for EnDAO's Segments**:

- **Prohibitive pricing**: $10K-$20K+/year (prohibitive for $50K nonprofit budget)
- **Director-only design**: Built for 10-15 directors, not 1000s of members
- **Operational disconnect**: No dues collection, vendor payments, operational execution
- **Legacy UX**: Reviews cite clunky interfaces, steep learning curves

### Category 2: Vertical-Specific SaaS (PayHOA, RunHOA, Bivio)

**Strengths**:

- Deep workflow specialization (architectural requests, K-1 generation)
- Cost-accessible ($50-200/month for HOAs, $350-550/year for investment clubs)

**Weaknesses**:

- **Governance as afterthought**: Voting is simple survey feature, no proposal logic
- **Data silos**: No interoperability, walled gardens
- **Banking limitations**: Third-party payment integrations, no embedded treasury
- **No execution**: Decisions don't trigger actions

### Category 3: Crypto-Native DAO Tools (Aragon, Snapshot, Tally, DAOhaus)

**Strengths**:

- Immutable audit trails on public blockchain
- Programmatic execution (vote → automatic fund release)
- Transparency and tamper-proof records

**Weaknesses for Traditional Institutions**:

- **UX friction**: Wallet management, gas fees, MetaMask complexity
- **Legal blindspots**: No IRS tax filings, no FinCEN BOI reporting, no "legal wrappers"
- **Token-centric**: 1 token = 1 vote conflicts with democratic (1 person = 1 vote) structures
- **Assumes crypto literacy**: Non-starter for typical HOA board member

### Category 4: Civic Tech / Deliberation (Loomio, Decidim, Consul)

**Strengths**:

- Sophisticated deliberation (ranked-choice, quadratic voting, amendments)
- Designed to prevent groupthink, encourage engagement

**Weaknesses**:

- **The Execution Gap**: Vote to authorize expenditure doesn't trigger bank transfer
- **No treasury integration**: Human must "swivel chair" to banking portal
- **Business model risk**: Open-source/donation-based = slower development

---

## Segment Deep Dive: Psychographics & Requirements

### HOAs: The "Litigious Micro-Government"

**Context**: 77 million Americans governed by HOAs, billions in annual assessments. Characterized by **high conflict, low trust**.

| Pain Point              | Business Impact                                       | EnDAO Solution                                  |
| ----------------------- | ----------------------------------------------------- | ----------------------------------------------- |
| **Conflict & Mistrust** | 30% of HOA lawsuits involve rule enforcement disputes | Verifiable voting with audit trails             |
| **Board Turnover**      | Institutional knowledge leaves with volunteers        | Persistent organizational state                 |
| **Compliance Burden**   | Patchwork of state laws + federal CTA                 | Automated compliance workflows                  |
| **Financial Disputes**  | Accusations of impropriety, embezzlement              | Read-only member access to sanitized financials |

**Critical Requirements**:

- Weighted voting by ownership interest (square footage)
- Architectural Review workflow: Submission → Committee → Board Vote → Auto-Notification
- Immutable enforcement records (violations, hearings, fines)

**Pricing Sensitivity**: High ($39-100/month acceptable)

### Investment Clubs: The "Tax & Equity Tangle"

**Context**: Micro-funds where individuals pool capital. Gateway to more complex DAO structures, held back by administrative friction.

| Pain Point                    | Business Impact                                       | EnDAO Solution                             |
| ----------------------------- | ----------------------------------------------------- | ------------------------------------------ |
| **Unit Valuation Complexity** | Mathematical complexity of tracking buy-ins/cash-outs | Automated unitized accounting              |
| **Tax Preparation Stress**    | K-1 generation is #1 treasurer stressor               | Integrated tax engine (Form 1065, K-1s)    |
| **Brokerage Disconnect**      | Manual trade entry from brokerage to ledger           | Direct brokerage API integration           |
| **Hybrid Assets**             | Want both equities and crypto                         | Unified portfolio view (Schwab + Coinbase) |

**Critical Requirements**:

- SEC/FINRA compliant record-keeping
- Automated capital calls and pro-rata allocations
- Tax-ready dataset from categorized transactions

**Pricing Sensitivity**: Medium (value compliance automation)

### Nonprofits (501(c)(3)): The "Stewardship Mandate"

**Context**: Strict fiduciary duties, intense public scrutiny on fund use.

| Pain Point                      | Business Impact                                              | EnDAO Solution                             |
| ------------------------------- | ------------------------------------------------------------ | ------------------------------------------ |
| **Restricted Fund Commingling** | Donors give with restrictions; commingling = compliance risk | Fund accounting with programmatic controls |
| **Board Disengagement**         | Materials sent via email often unread                        | Mobile-first engagement tools              |
| **Data Security**               | Handle vulnerable population data                            | SOC2-level security                        |
| **Impact Reporting**            | Donors want proof of outcomes                                | Decision → expenditure → impact linking    |

**Critical Requirements**:

- Restricted vs. unrestricted fund tracking
- COI disclosure workflows
- Form 990 data preparation

**Pricing Sensitivity**: High (volunteer-run, budget-constrained)

### Cooperatives: Democratic Control at Scale

| Pain Point                        | Business Impact                            | EnDAO Solution                                   |
| --------------------------------- | ------------------------------------------ | ------------------------------------------------ |
| **Democratic Voting Enforcement** | "One member, one vote" compliance          | Configurable voting rules by class               |
| **Member Equity Tracking**        | Manual account management                  | Automated equity ledger                          |
| **Patronage Dividends**           | Complex calculations tied to participation | Integrated calculation + approval + distribution |

**Pricing Sensitivity**: Medium

### Enterprise Consortiums / Joint Ventures: High-Stakes Collaboration

| Pain Point                  | Business Impact                            | EnDAO Solution                                |
| --------------------------- | ------------------------------------------ | --------------------------------------------- |
| **IP Leakage Fear**         | Sharing data risks trade secret theft      | Granular permissions, watermarking, ZK proofs |
| **Governance Deadlocks**    | 50/50 JVs stall without dispute resolution | Clear governance frameworks                   |
| **IT Integration Friction** | Merging ERPs is slow and costly            | Neutral "third place" for shared assets       |

**Critical Requirements**:

- Smart contract execution for revenue splits, royalty payments
- Organization-level permission model
- Agreement-linked governance records

**Pricing Sensitivity**: Low (outcome-focused)

---

## Moat & Defensibility Strategy

### The "Data Gravity" Moat

**Once an entity manages its history AND money on EnDAO, leaving becomes nearly impossible.**

| Gravity Source            | Switching Cost                                                                   |
| ------------------------- | -------------------------------------------------------------------------------- |
| **Historical Continuity** | Need 5-year-old minutes to defend lawsuit → losing history = losing legal shield |
| **Treasury Integration**  | Closing bank accounts, re-issuing cards, updating every vendor payment           |
| **Compliance Records**    | CTA filings, tax histories, audit trails                                         |

### Wedge Feature Strategies

| Wedge                       | Entry Point                                 | Upsell Path                                    |
| --------------------------- | ------------------------------------------- | ---------------------------------------------- |
| **CTA Compliance Tool**     | Free/low-cost BOI filing for HOAs           | "Avoid $500/day fines" → full governance suite |
| **Smart Corporate Card**    | Expense control for nonprofits (Brex-style) | Card with governance controls → full platform  |
| **Individual Member Tools** | Free tracking for homeowners/club members   | Bottom-up pressure on board to adopt           |

### Viral Growth Loops

**Replicate Expensify/Loomio bottom-up adoption:**

| Segment              | Individual Hook                                      | Viral Mechanism                        |
| -------------------- | ---------------------------------------------------- | -------------------------------------- |
| **HOAs**             | Free dues tracking, architectural request submission | Members pressure board to adopt        |
| **Investment Clubs** | Free personal portfolio slice tracking               | Invite club to view shared performance |
| **Nonprofits**       | Free donor acknowledgment letters                    | Board adopts for full donor management |

---

## Business Model: The "Compounder" Strategy

### Revenue Architecture

**Lower barriers to entry, capture value from financial flows and compliance events.**

| Revenue Stream        | Mechanism                             | Margin    |
| --------------------- | ------------------------------------- | --------- |
| **Core SaaS**         | Tiered subscription by members/AUM    | Medium    |
| **Interchange**       | 1.5% on every card transaction        | High      |
| **Yield Spread**      | Offer 4% on reserves, earn 4.5%       | High      |
| **Compliance Upsell** | Tax Filing Pack (K-1s, Form 990, BOI) | Very High |
| **White-label**       | Branded deployment for associations   | High      |

### Pricing Tiers

| Tier              | Target                              | Key Features                                | Price       | Hidden Revenue      |
| ----------------- | ----------------------------------- | ------------------------------------------- | ----------- | ------------------- |
| **Free**          | <5 members                          | Basic voting, limited treasury view         | $0          | Viral adoption      |
| **Community**     | 5-50 members (Small HOAs, clubs)    | Full voting, treasury, compliance reminders | $49/mo      | Interchange         |
| **Institutional** | 50-500 members (Nonprofits, co-ops) | AI minutes, advanced voting, integrations   | $149-299/mo | Yield + Interchange |
| **Consortium**    | 500+ members (Enterprise)           | Multi-org, API, custom compliance           | $999+/mo    | Full stack          |

### Competitor Pricing Reference

| Competitor | Model              | Price Point               |
| ---------- | ------------------ | ------------------------- |
| Diligent   | Per Board/User     | $10K-$20K+/year           |
| PayHOA     | Per Unit (Tiered)  | $50-200/month             |
| RunHOA     | Flat Fee           | $399/year                 |
| Bivio      | Flat Fee + Tax     | $350-550/year             |
| Brex/Ramp  | Interchange + SaaS | Free (interchange-funded) |

---

## Emerging Trends & Threats

### AI Agents: The New "Board Secretary"

| Application          | Function                                                        | EnDAO Opportunity                   |
| -------------------- | --------------------------------------------------------------- | ----------------------------------- |
| **Bureaucrat Agent** | Schedule meetings, take minutes, check bylaws, answer questions | Reduce volunteer burnout            |
| **Compliance Agent** | Monitor filing deadlines, prepare documents                     | Automated regulatory management     |
| **Agentic Voting**   | Members delegate to AI ("vote for ESG-aligned proposals")       | Infrastructure for AI participation |

**Threat**: If EnDAO is purely UI, generic AI assistants could "read" spreadsheets and answer governance questions. **Solution**: Own the execution layer (payments, filings) - AI can't replicate that.

### Crypto/TradFi Convergence

| Trend                       | Opportunity                                                 |
| --------------------------- | ----------------------------------------------------------- |
| **Real World Assets (RWA)** | Investment clubs want tokenized real estate, private credit |
| **Stablecoin Treasury**     | 4-5% yield vs 0.1% checking - attractive for reserves       |
| **Hybrid Portfolios**       | Unified view across equities + crypto                       |

### Regulatory Headwinds

| Trend                           | Implication                                                                        |
| ------------------------------- | ---------------------------------------------------------------------------------- |
| **FinCEN/SEC scrutiny on DAOs** | Compliance-first design protects EnDAO; competitors (Tally, Snapshot) may struggle |
| **EU AI Act**                   | Board-level AI governance requirements create feature opportunity                  |
| **State HOA law fragmentation** | First-mover on state-specific templates wins market                                |

---

## Product Differentiation Summary

### The EnDAO Position

| Dimension          | EnDAO                                 | Why It Wins                    |
| ------------------ | ------------------------------------- | ------------------------------ |
| **UX**             | Web2 feel (Notion-simple)             | No crypto expertise needed     |
| **Infrastructure** | Web3 rails (immutable, programmatic)  | Audit-proof, execution-enabled |
| **Compliance**     | Legal-entity aware + automated filing | CTA, 501(c)(3), state laws     |
| **Treasury**       | Embedded banking + governance-linked  | Vote → payment chain           |
| **Scale**          | Member-rich (1000s of voters)         | Not limited to 10-15 directors |
| **Pricing**        | Transparent, segment-appropriate      | No sales calls for lower tiers |

### vs Each Competitor Category

| vs Category               | EnDAO Advantage                                       |
| ------------------------- | ----------------------------------------------------- |
| **vs Enterprise Portals** | 10-100x cheaper, member-rich, operational integration |
| **vs Vertical SaaS**      | Governance-first, execution-enabled, interoperable    |
| **vs Crypto-Native**      | No crypto expertise, legal wrappers, compliance       |
| **vs Civic Tech**         | Treasury integration, execution, sustainable model    |

---

## Strategic Imperatives

### Immediate (Product)

1. **CTA Compliance Wedge**: Ship BOI auto-filing as standalone hook
2. **Governance Templates**: HOA, 501(c)(3), co-op, investment club presets
3. **Treasury-Governance Link**: Vote passes → funds release automatically

### Near-Term (Go-to-Market)

1. **Bottom-Up Viral**: Free tier for individual members to create board pressure
2. **Transparent Pricing**: Published tiers, no enterprise sales calls for lower tiers
3. **Compliance Marketing**: "Avoid $500/day CTA fines" as acquisition message

### Mid-Term (Moat Building)

1. **Embedded Banking**: Partner with BaaS for FDIC-insured accounts
2. **Card Issuance**: Interchange revenue from organizational spend
3. **Yield Product**: Stablecoin/Treasury yield for reserve funds

### Long-Term (Platform)

1. **AI Agents**: Bureaucrat agent for meeting management
2. **Hybrid Assets**: Unified view of traditional + tokenized assets
3. **Template Marketplace**: Community-contributed governance templates

---

## Appendix: Key Strategic Quotes

> "The primary competitor is not an incumbent software provider, but 'non-consumption' - the ad-hoc reliance on general-purpose tools never designed for institutional governance."

> "EnDAO should adopt a 'Mullet Strategy': presenting a familiar, compliant, user-friendly Web2 interface in front, while utilizing immutable, efficient Web3 rails in back."

> "Governance without capital control is merely suggestion. The most defensible 'rail' EnDAO can build is the movement of money."

> "The CTA effectively links governance and compliance: a governance event (election) IS a compliance event (filing)."

> "Once an entity manages its history AND its money on EnDAO, the friction of leaving becomes insurmountable."

> "EnDAO can position itself not just as a software provider, but as the essential operating system for the next generation of human organization."

---

_Research compiled December 6, 2025. Sources: Perplexity Deep Research, Gemini Deep Research, internal synthesis._
