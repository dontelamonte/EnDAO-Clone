# OGP Civic Tech Platform Research Report

**Date**: December 6, 2025
**Purpose**: Deep-dive research into civic engagement platforms from the Open Government Partnership (OGP) tools list to identify features, patterns, and insights applicable to EnDAO.

---

## Executive Summary

Research conducted on 8 leading civic engagement platforms reveals common patterns in successful democratic participation tools. EnDAO's unique advantage is combining civic engagement UX with treasury execution—no other platform in this space has this capability.

**Key Findings**:

1. **Discussion before voting** is critical (Loomio, ConsiderIt)
2. **Flat argument structures** prevent toxicity (YourPriorities)
3. **Implementation tracking** builds trust (Consul)
4. **Real consequences** drive engagement (DemocracyOS, YourPriorities)
5. **Email participation** dramatically increases engagement (Loomio)

**EnDAO's Competitive Moat**: Treasury execution + token ownership. Civic tech platforms vote on decisions but can't execute them. EnDAO votes AND executes via Gnosis Safe.

---

## Platform Deep Dives

### 1. Loomio

**Overview**: Deliberation-focused platform used by 100K+ groups worldwide. Core philosophy: conversations first, voting second.

**Scale**: 100,000+ groups, organizations like Enspiral, social enterprises, cooperatives

**Key Features**:

| Feature                          | Description                                                  | EnDAO Relevance        |
| -------------------------------- | ------------------------------------------------------------ | ---------------------- |
| **Discussion → Proposal Flow**   | Conversations evolve into formal proposals when ready        | HIGH - Adopt pattern   |
| **Sense Check Polls**            | Quick temperature checks before formal votes                 | HIGH - Already planned |
| **Consent Voting**               | Agree/Abstain/Disagree/Block with mandatory reason for Block | HIGH - Already planned |
| **Email-In Participation**       | Reply to notification emails to vote/comment                 | HIGH - Add to roadmap  |
| **Mandatory Outcome Statements** | Force articulation of "what happens next" before closing     | HIGH - Add to roadmap  |
| **Thread Tagging**               | Organize discussions by topic                                | MEDIUM                 |

**Voting Types Supported**:

- Yes/No/Abstain
- Consent (Agree/Abstain/Disagree/Block)
- Ranked Choice
- Dot Voting (distribute points)
- Score Polls (rate options 1-10)

**What They Don't Have**:

- Treasury management
- Token-based ownership
- On-chain execution

**Key Insight**: Loomio's success comes from making deliberation the default, not an afterthought. Their "Sense Check" feature surfaces blockers before formal votes, reducing failed proposals.

**Quote from Research**: "Email participation dramatically increases engagement from busy members who won't open the app."

---

### 2. CitizenLab (now Go Vocal)

**Overview**: Enterprise civic engagement platform used by 500+ governments serving 90M+ citizens. Heavy focus on AI-assisted moderation and representation analytics.

**Scale**: 500+ governments, 90M+ citizens, 400+ employees

**Key Features**:

| Feature                      | Description                                              | EnDAO Relevance                   |
| ---------------------------- | -------------------------------------------------------- | --------------------------------- |
| **Multi-Phase Engagement**   | Discovery → Co-Creation → Prioritization → Feedback Loop | MEDIUM - Complex but valuable     |
| **NLP Clustering**           | Auto-categorize similar proposals, surface duplicates    | MEDIUM - Future feature           |
| **Representation Dashboard** | Demographic participation parity metrics                 | LOW - Enterprise feature          |
| **Enterprise RBAC**          | Moderator, Evaluator, Manager, Administrator roles       | HIGH - Build hidden, expose later |
| **12x Engagement Increase**  | Measured impact of notification systems                  | Validates notification priority   |

**Engagement Phases**:

1. **Discovery**: Ideation, brainstorming, open submissions
2. **Co-Creation**: Collaborative drafting, refinement
3. **Prioritization**: Voting, ranking, budget allocation
4. **Feedback Loop**: Implementation tracking, status updates

**Role System**:
| Role | Permissions |
|------|-------------|
| Administrator | Full platform access |
| Moderator | Manage content, hide inappropriate posts |
| Evaluator | Officially respond to proposals, add government position |
| Manager | Configure projects, manage participants |

**Metrics Reported**:

- 56% higher trust in local government
- 12x engagement increase with proper notifications
- 3x faster policy development cycles

**What They Don't Have**:

- Treasury execution
- Crypto/blockchain integration
- Small organization support (enterprise-focused)

**Key Insight**: CitizenLab's success with governments validates the importance of multi-phase engagement and implementation tracking. Their NLP clustering reduces duplicate proposals significantly.

---

### 3. Consul

**Overview**: Open-source participatory democracy platform used by 250+ institutions in 39 countries, serving 90M+ citizens. Famous for participatory budgeting.

**Scale**: 250+ institutions, 39 countries, 90M+ citizens

**Key Features**:

| Feature                        | Description                                                             | EnDAO Relevance             |
| ------------------------------ | ----------------------------------------------------------------------- | --------------------------- |
| **Participatory Budgeting**    | "Knapsack voting" - allocate within budget constraint                   | HIGH - Unique with treasury |
| **4-Phase Proposal Lifecycle** | Creation → Support → Debate → Voting → Implementation                   | HIGH - Structured process   |
| **Mandatory 30-Day Review**    | Government must respond within 30 days                                  | MEDIUM - Accountability     |
| **Implementation Tracking**    | Post-vote project status dashboard                                      | HIGH - Critical for trust   |
| **6 Admin Roles**              | Administrator, Moderator, Evaluator, Manager, Poll Officer, SDG Officer | MEDIUM - Enterprise feature |

**Proposal Lifecycle**:

```
1. Creation (citizen submits)
2. Support Phase (gather signatures/endorsements)
3. Debate (public discussion period)
4. Voting (formal vote)
5. Implementation (tracking dashboard)
```

**Participatory Budgeting Flow**:

- City sets budget pool (e.g., $1M for neighborhood improvements)
- Citizens submit project proposals with cost estimates
- Voting period with budget constraint
- Projects funded in order of votes until budget exhausted
- Implementation tracking for funded projects

**Critical Lesson Learned**:

> "Citizens complained loudly when proposals passed but there was no visibility into implementation. Trust erodes when votes feel ignored."

**What They Don't Have**:

- Automatic treasury execution
- Smart contract integration
- Private organization support

**Key Insight**: Consul's participatory budgeting is perfect for EnDAO—we can vote AND execute treasury allocations automatically. This is a unique competitive advantage.

---

### 4. Pol.is

**Overview**: Real-time opinion mapping tool using machine learning to identify consensus across opinion groups. Famous for vTaiwan deliberations.

**Scale**: Used by Taiwan government (vTaiwan), academic institutions, civic organizations

**Key Features**:

| Feature                      | Description                                  | EnDAO Relevance            |
| ---------------------------- | -------------------------------------------- | -------------------------- |
| **PCA + K-means Clustering** | Identifies opinion groups mathematically     | LOW - Specialized tool     |
| **Consensus Surfacing**      | Shows statements that groups agree on        | MEDIUM - Pre-deliberation  |
| **Embeddable Widget**        | iframe integration with XID user mapping     | LOW - Optional integration |
| **No Decision Tool**         | Explicitly not for voting, only deliberation | Different use case         |

**How It Works**:

1. Facilitator poses a question
2. Participants submit statements (agree/disagree/pass)
3. Algorithm clusters participants by opinion patterns
4. Visualizes opinion landscape showing:
   - Distinct groups with different views
   - "Bridging" statements that all groups agree on
   - Areas of genuine consensus vs. division

**vTaiwan Success**:

- 80% of deliberations led to government action
- Used for Uber regulation, alcohol sales, telemedicine policy
- Reduced polarization by surfacing unexpected areas of agreement

**Integration Pattern**:

```html
<iframe src="https://pol.is/e/[conversation-id]?xid=[user-id]"></iframe>
```

**What They Don't Have**:

- Voting/decision mechanism
- Treasury integration
- Organization management

**Key Insight**: Pol.is is a pre-deliberation tool, not a decision tool. Could be embedded for contentious topics before formal proposals, but adds complexity. **Deferred from roadmap** per user feedback.

---

### 5. ConsiderIt

**Overview**: Research-backed deliberation platform focused on pro/con visualization and depolarization. Academic origins with published research on reducing perceived polarization.

**Scale**: Used by municipalities, universities, civic organizations

**Key Features**:

| Feature                     | Description                                      | EnDAO Relevance             |
| --------------------------- | ------------------------------------------------ | --------------------------- |
| **Opinion Spectrum Slider** | 0-100 visual slider with histogram of others     | HIGH - Reduces polarization |
| **Pro/Con Visualization**   | Split-screen FOR/AGAINST argument lists          | HIGH - Core deliberation UX |
| **Argument Adoption**       | Endorse others' arguments instead of duplicating | HIGH - Reduces redundancy   |
| **Histogram Distribution**  | See where others placed their slider             | HIGH - Social proof         |
| **Research-Backed**         | Published studies on depolarization effects      | Validates approach          |

**How Pro/Con Works**:

```
┌─────────────────────────────────────────┐
│           PROPOSAL: [Title]             │
├───────────────────┬─────────────────────┤
│   FOR (Points)    │  AGAINST (Points)   │
├───────────────────┼─────────────────────┤
│ ▲ 45 Point A      │ ▲ 32 Point X        │
│ ▲ 38 Point B      │ ▲ 28 Point Y        │
│ ▲ 22 Point C      │ ▲ 15 Point Z        │
└───────────────────┴─────────────────────┘
```

**Opinion Spectrum**:

- Slider from 0 (strongly oppose) to 100 (strongly support)
- After submitting, see histogram of where others placed theirs
- Key finding: Most people are in the middle, not at extremes
- Reduces perceived polarization

**Argument Adoption**:

- Instead of writing "I agree with what John said"
- Click "Adopt this argument" to endorse existing points
- Reduces duplicate arguments
- Shows which arguments resonate most

**Research Findings**:

- Showing opinion distribution reduces perceived polarization
- Flat argument structure (no replies) prevents flame wars
- Pro/con separation keeps debate organized

**Technical Notes**:

- Ruby on Rails backend, React frontend
- AGPL open-source license
- Self-hostable

**What They Don't Have**:

- Treasury management
- Mobile app
- Enterprise features

**Key Insight**: ConsiderIt's research validates that UI structure affects discourse quality. Flat arguments + visible spectrum = less polarization. **Adopted for EnDAO roadmap.**

---

### 6. Ethelo

**Overview**: Decision-making platform with patented "fair decision" algorithm optimizing for low polarization, not just majority support. Used by Arbitrum DAO for grant evaluation.

**Scale**: Enterprise customers, Arbitrum DAO ($200M+ treasury)

**Key Features**:

| Feature                     | Description                               | EnDAO Relevance            |
| --------------------------- | ----------------------------------------- | -------------------------- |
| **Fair Decision Algorithm** | Optimizes for Support × (1 - Conflict)    | MEDIUM - Academic interest |
| **Four Metrics**            | Ethelo Score, Support, Approval, Conflict | MEDIUM - Interesting model |
| **Budget Constraints**      | Handle allocation within limits           | HIGH - Already planning    |
| **Arbitrum Case Study**     | 87.5% approval for grant decisions        | Validates crypto use case  |

**Ethelo Score Calculation**:

```
Ethelo Score = Support × (1 - Conflict)

Where:
- Support = % of positive votes
- Conflict = variance in opinion intensity
- High Support + Low Conflict = Best outcome
```

**Why It Matters**:

- Traditional majority voting can pass divisive proposals
- Ethelo finds options that most people can live with
- Reduces "tyranny of the majority"

**Arbitrum DAO Case Study**:

- Used for grant evaluation process
- 87.5% approval rate for final decisions
- Handled $200M+ treasury allocations
- Reduced governance disputes

**What They Don't Have**:

- Open-source (commercial license)
- Self-service onboarding
- Small organization pricing

**Key Insight**: Fair decision algorithm is academically interesting but adds complexity. **Deferred from roadmap** per user feedback—standard voting sufficient for MVP.

---

### 7. YourPriorities

**Overview**: Civic engagement platform famous for Iceland's Better Reykjavik, where 40% of the population participated. Emphasizes intrinsic motivation over gamification.

**Scale**: Iceland (40% population), 200+ languages supported

**Key Features**:

| Feature                   | Description                              | EnDAO Relevance              |
| ------------------------- | ---------------------------------------- | ---------------------------- |
| **Split-Screen Debate**   | FOR/AGAINST points voted separately      | HIGH - Toxicity prevention   |
| **No Comment-on-Comment** | Arguments stand alone, no nested threads | HIGH - Core design principle |
| **No Gamification**       | Relies on intrinsic motivation           | HIGH - Philosophy alignment  |
| **Speech-to-Text**        | 200 language support                     | LOW - Accessibility feature  |
| **40% Participation**     | Iceland's Better Reykjavik success       | Validates approach           |

**Toxicity Prevention by Design**:

Traditional comment threads:

```
Person A: "I think X"
  └─ Person B: "That's wrong because..."
      └─ Person A: "You don't understand..."
          └─ [flame war]
```

YourPriorities approach:

```
FOR Points (independent)    AGAINST Points (independent)
├─ Point A (voted)          ├─ Point X (voted)
├─ Point B (voted)          ├─ Point Y (voted)
└─ Point C (voted)          └─ Point Z (voted)
```

**Why No Gamification?**:

- Iceland's 40% participation came from seeing ideas become real policy
- Real consequences > badges and points
- EnDAO has built-in consequences: treasury execution

**Better Reykjavik Results**:

- 40% of Reykjavik population participated
- 700+ citizen ideas implemented into policy
- Minimal moderation required
- Arguments evaluated on merit, not personality

**What They Don't Have**:

- Treasury management
- Token-based voting weight
- Enterprise features

**Key Insight**: YourPriorities proves that **real consequences drive engagement**. EnDAO already has this—votes execute treasury transactions. Adopt their toxicity-prevention design patterns.

---

### 8. DemocracyOS

**Overview**: Pioneer civic tech platform from Argentina, famous for Buenos Aires digital democracy initiative. Currently unmaintained—cautionary tale about sustainability.

**Scale**: Buenos Aires (14M metro), 35+ deployments worldwide (historical)

**Key Features**:

| Feature                     | Description                             | EnDAO Relevance          |
| --------------------------- | --------------------------------------- | ------------------------ |
| **Legislative Integration** | Direct connection to lawmaking          | HIGH - Real consequences |
| **Buenos Aires Success**    | 6,000 online votes → actual bill passed | Validates model          |
| **Open Source**             | MIT license, Node.js/MongoDB            | Technical reference      |
| **Currently Unmaintained**  | Team pivoted to consulting              | Cautionary tale          |

**Buenos Aires Case Study**:

- Minority party couldn't pass legislation through traditional means
- Launched digital consultation on 16 proposed laws
- 6,000+ citizens voted online
- Opposition couldn't ignore clear public mandate
- Bill passed despite minority party status

**Why It Worked**:

- Real legislative consequences
- Institutional partnership (actual lawmakers used results)
- Media attention drove participation
- Clear connection: vote → law

**Why It Failed (Eventually)**:

- Team pivoted to Democracy Earth (blockchain focus)
- Codebase became unmaintained
- Decidim overtook it due to better architecture
- No sustainable business model

**Lesson for EnDAO**:

> "Institutional partnership required for success. Tools alone don't create change—they need to connect to real decision-making power."

EnDAO has this advantage: treasury execution provides built-in institutional consequence.

**What Replaced It**:

- Decidim (more modular, better maintained)
- Consul (larger community, more features)

**Key Insight**: DemocracyOS proves that **real consequences drive engagement**, but also shows the risk of pivoting away from core product. Keep shipping platform features, don't get distracted by consulting.

---

## Synthesis: Feature Adoption Recommendations

### Tier 1: Immediate Adoption (Already Planned, Validated)

| Feature              | Source             | Status         |
| -------------------- | ------------------ | -------------- |
| Discussion Threads   | Loomio, ConsiderIt | In ROADMAP 1.6 |
| In-App Notifications | All platforms      | In ROADMAP 1.7 |
| Consent Voting       | Loomio             | In ROADMAP 2.4 |
| Quick Polls          | Loomio             | In ROADMAP 2.6 |
| Email Digests        | Loomio, CitizenLab | In ROADMAP 2.7 |

### Tier 2: Add to Roadmap (High Value)

| Feature                        | Source                     | Added to ROADMAP |
| ------------------------------ | -------------------------- | ---------------- |
| Pro/Con Argument Lists         | ConsiderIt, YourPriorities | 1.6 (enhanced)   |
| Q&A Section (AMA format)       | Custom design              | 1.6 (enhanced)   |
| Email-In Participation         | Loomio                     | 2.7 (enhanced)   |
| Mandatory Outcome Statements   | Loomio                     | 2.9 (new)        |
| Implementation Status Tracking | Consul                     | 2.10 (new)       |
| Opinion Spectrum Slider        | ConsiderIt                 | 2.11 (new)       |
| Participatory Budgeting        | Consul                     | 2.12 (new)       |
| Proposal Templates             | Initial assessment         | 2.13 (new)       |

### Tier 3: Future/Enterprise (Lower Priority)

| Feature                  | Source             | Added to ROADMAP       |
| ------------------------ | ------------------ | ---------------------- |
| Scoped Role Permissions  | CitizenLab, Consul | 4.5 (hidden initially) |
| Representation Dashboard | CitizenLab         | 4.6                    |
| NLP Duplicate Detection  | CitizenLab         | 4.7                    |
| NLP Topic Clustering     | CitizenLab         | 4.7                    |

### Deferred (Not Adding)

| Feature                 | Source | Reason                           |
| ----------------------- | ------ | -------------------------------- |
| Pol.is Integration      | Pol.is | Niche use case, adds complexity  |
| Fair Decision Algorithm | Ethelo | Academic interest, not core need |

---

## EnDAO's Unique Position

### What No Other Civic Tech Platform Has

| Capability                 | EnDAO | Loomio | CitizenLab | Consul | Others |
| -------------------------- | ----- | ------ | ---------- | ------ | ------ |
| Treasury Execution         | ✅    | ❌     | ❌         | ❌     | ❌     |
| Token-Based Ownership      | ✅    | ❌     | ❌         | ❌     | ❌     |
| Gasless Transactions       | ✅    | ❌     | ❌         | ❌     | ❌     |
| Smart Contract Integration | ✅    | ❌     | ❌         | ❌     | ❌     |
| Multi-Sig Security         | ✅    | ❌     | ❌         | ❌     | ❌     |

### The Synthesis Opportunity

Take the best UX patterns from civic tech:

- **Loomio**: Discussion-first flow, consent voting, email participation
- **ConsiderIt**: Pro/con visualization, opinion spectrum
- **Consul**: Implementation tracking, participatory budgeting
- **YourPriorities**: Toxicity prevention, intrinsic motivation design

Combine with EnDAO's unique capabilities:

- **Treasury execution**: Votes actually move funds
- **Token ownership**: Members have real stake
- **Gasless UX**: Accessible to non-crypto users
- **Safe integration**: Institutional-grade security

**Result**: "The institutional rails that make governance decisions actually happen"

---

## Appendix: Research Sources

### Primary Sources

- OGP Online Tools List: https://www.opengovpartnership.org/documents/taking-the-ogp-co-creation-process-online-online-tools-platforms/
- Platform documentation and websites
- Case studies and published research

### Platforms Researched

1. Loomio - https://www.loomio.com/
2. CitizenLab (Go Vocal) - https://www.govocal.com/
3. Consul - https://consulproject.org/
4. Pol.is - https://pol.is/
5. ConsiderIt - https://consider.it/
6. Ethelo - https://ethelo.com/
7. YourPriorities - https://citizens.is/
8. DemocracyOS - https://democracyos.org/ (archived)

### Additional Platforms Reviewed (Quick Assessment)

- Deliberatorium, Delib.net, Discuto
- Google Forms, Poll Everywhere, Slido, Mentimeter
- Mural, Trello, Etherpad
- Zoom, Teams, Jitsi

---

_Report generated as part of EnDAO product development. All research conducted December 6, 2025._
