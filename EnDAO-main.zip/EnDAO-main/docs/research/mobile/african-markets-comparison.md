# African Markets Comparison for Mobile Education/Business/Fintech Platform (2025-2026)

## Purpose

Practical, fact-based comparison of 10+ African markets for mobile platform deployment, covering trust mechanisms, DAO governance patterns, treasury/collective fund management, education/onboarding, and regulatory compliance.

## Last Updated

2026-01-31

**Research Date:** January 31, 2026

---

## Executive Summary

### Key Findings

1. **Kenya + Nigeria pattern covers ~40% of Sub-Saharan Africa's digital economy** but breaks significantly when expanding to:
   - Francophone West Africa (different dominant players, language)
   - South Africa (bank-first, not mobile money-first)
   - Ethiopia (single-provider market with Telebirr monopoly)
   - Egypt (different regulatory regime, Arabic language)

2. **Flutterwave is NOT truly pan-African**: Covers 34 countries but has varying depth. Paystack only in 3-4 markets (Nigeria, Ghana, South Africa, Kenya).

3. **Minimum payment integration for 80% coverage**: Flutterwave + M-Pesa (Kenya/Tanzania) + Orange Money (Francophone) + Telebirr (Ethiopia) + InstaPay (Egypt).

4. **Francophone gap is REAL**: Orange Money dominates, Wave disrupting, but English-only app will struggle. French translation essential for Senegal, Ivory Coast, DRC, Cameroon.

5. **Infrastructure challenges**: No Supabase Africa edge locations, South Africa AWS region discontinued for new projects, nearest hop is Europe (~600ms+ latency).

---

## Market-by-Market Analysis

### 🇰🇪 Kenya - The Mobile Money Gold Standard

#### Mobile Money Landscape

- **Dominant Provider:** [M-Pesa (Safaricom)](https://techcabal.com/2025/11/19/more-kenyans-m-pesa-safaricom-mobile-network/) - 91% penetration ([FinTech Magazine](https://fintechmagazine.com/news/kenya-leads-the-world-in-mobile-money-penetration))
- **Market Share:** 47.7M active subscriptions (June 2025), [60M+ active users](https://electroiq.com/stats/m-pesa-statistics/)
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT - 91% penetration vs ~30% bank account penetration
- **Transaction Volume:** [KES 88.1 billion ($676.9M) revenue](https://juatechafrica.com/kenya-mobile-market-2025/), 2.4M businesses accepting M-Pesa
- **Competitors:** Airtel Money (~15% share), Telkom T-Kash (minimal)

**Practical Note:** M-Pesa has evolved from fintech to "financial plumbing" - infrastructure for the nation. Agent network (319,300) larger than all banks combined.

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** YES - Full coverage, strong integration
- **[Paystack](https://radarr.africa/paystack-vs-flutterwave-vs-paypal/):** YES - One of only 3-4 Paystack markets
- **Coverage Gap:** None for major providers

#### Currency

- **ISO Code:** KES (Kenyan Shilling)
- **Typical Transaction Sizes:**
  - Mobile money daily limit: KES 500,000 (~$3,850)
  - Maximum wallet balance: KES 500,000
  - Most common transactions: KES 100-5,000 ($0.77-$38.50)
- **Exchange Rate:** ~130 KES = 1 USD (fluctuates)

#### Language

- **Primary Business Languages:** English (official), Swahili (national)
- **English-Only Viability:** ✅ WORKS - Kenya has [high English proficiency](https://www.africanexponent.com/top-10-african-countries-with-the-best-english-proficiency-and-speakers-in-2025/) (593/800 EF score, 3rd in Africa)
- **Localization Need:** LOW - English + Swahili covers 99%+

#### Data/Connectivity

- **Mobile Data Cost:** [$0.59-$0.84 per GB](https://nairametrics.com/2025/01/14/tariff-increase-cost-of-data-in-nigeria-ghana-south-africa-and-kenya-compared/)
- **Network Coverage:** [99.4% population, 4G at 78%](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/africa/)
- **Device Specs:** 71% 3G/4G smartphones, [24% smartphone penetration overall](https://telecomlead.com/4g-lte/africa-mobile-internet-usage-gap-widens-as-smartphone-affordability-and-legacy-networks-slow-digital-inclusion-124248)
- **Median Device Cost:** ~$39 (26% of monthly GDP per capita)

#### Regulatory

- **Data Protection:** [Kenya Data Protection Act](https://practiceguides.chambers.com/practice-guides/fintech-2025/kenya) - moderate GDPR alignment
- **Fintech Licensing:** [Central Bank of Kenya](https://iclg.com/practice-areas/fintech-laws-and-regulations/kenya) regulates Payment Service Providers (PSP), Digital Credit Providers (2022 regulations curb predatory lending)
- **Mobile Money:** Telecommunications providers must be [licensed under KICA + authorized by CBK](https://mman.co.ke/content/fintech-regulation-kenya)
- **Virtual Assets:** Draft Virtual Asset Service Providers Bill, 2025 (pending)

#### App Stores

- **Google Play Dominance:** HIGH (99%+ of legal downloads)
- **Sideloading Culture:** LOW-MODERATE (used for cracked apps, not mainstream)
- **Restrictions:** None specific to Kenya; [Google verification rules apply globally from 2027](https://www.medianama.com/2025/08/223-google-blocks-android-apk-sideloading-2026/)

---

### 🇳🇬 Nigeria - Fintech Powerhouse, Regulatory Complexity

#### Mobile Money Landscape

- **Dominant Providers:** [MTN Mobile Money (MoMo)](https://news.broadcastmediaafrica.com/2025/11/19/mtn-surpasses-300-million-subscribers-with-strong-growth-driven-by-nigeria-and-ghana/), OPay, PalmPay
- **Market Share:** MTN has significant user base but exact MoMo penetration unclear; overall mobile money adoption lower than Kenya
- **Mobile Money vs Bank Cards:** MIXED - Nigeria has higher bank account penetration (~50%) than Kenya, but mobile money growing rapidly post-2020 regulations
- **Key Player:** OPay and PalmPay have captured significant market share with aggressive promotions

**Critical Difference from Kenya:** Nigeria's mobile money market is more fragmented, with multiple competing platforms and higher traditional banking penetration.

#### Payment Aggregators

- **[Flutterwave](https://techcabal.com/2025/10/16/flutterwave-cross-border-payments-in-africa/):** YES - Founded in Nigeria, strongest market
- **[Paystack](https://radarr.africa/paystack-vs-flutterwave-vs-paypal/):** YES - Founded in Nigeria (acquired by Stripe)
- **Coverage Gap:** None for major providers

#### Currency

- **ISO Code:** NGN (Nigerian Naira)
- **Typical Transaction Sizes:** Highly variable due to inflation
- **Exchange Rate:** ~1,600 NGN = 1 USD (volatile, devaluing)
- **Transaction Limits:** [CBN sets strict KYC-based limits](https://www.globallegalinsights.com/practice-areas/fintech-laws-and-regulations/nigeria/) (2022 regulations)

#### Language

- **Primary Business Language:** English (official)
- **English-Only Viability:** ✅ WORKS - Nigeria has [high English proficiency](https://thenationonlineng.net/full-list-2025-10-best-english-speaking-countries-in-africa/) (568/800 EF score, 5th in Africa)
- **Localization Need:** LOW - English is lingua franca; 500+ local languages but English dominates business
- **Note:** Pidgin English widely spoken but not required for business apps

#### Data/Connectivity

- **Mobile Data Cost:** [$0.39-$0.71 per GB](https://technext24.com/2025/02/18/nigerias-internet-costs-and-7-countries/) (cheapest in Africa)
- **Network Coverage:** 4G coverage ~70%, but significant urban-rural gap
- **Device Specs:** High smartphone penetration in cities, feature phones still common in rural areas
- **Connectivity Challenge:** Frequent power outages affect data access

#### Regulatory

- **Data Protection:** [Nigeria Data Protection Act (NDPA) 2023 + GAID 2025](https://practiceguides.chambers.com/practice-guides/fintech-2025/nigeria/trends-and-developments/O20012) - strict localization requirements
- **Fintech Licensing:** [Central Bank of Nigeria (CBN)](https://www.legal500.com/developments/thought-leadership/types-of-fintech-licenses-required-for-operation-in-nigeria/) - Payment Service Provider (PSP) license required
- **Mobile Money:** [CBN Guidelines on Mobile Money Services (2015)](https://www.legal500.com/developments/thought-leadership/types-of-fintech-licenses-required-for-operation-in-nigeria/) still in effect
- **Data Localization:** MANDATORY for financial services (expensive - requires local data centers)
- **Recent:** [NRNOA/NRNIA accounts](https://www.globallegalinsights.com/practice-areas/fintech-laws-and-regulations/nigeria/) for diaspora remittances (Jan 2025)

**Critical:** Nigeria has the MOST complex regulatory environment in Sub-Saharan Africa. Data localization is enforced and expensive.

#### App Stores

- **Google Play Dominance:** HIGH but with significant sideloading
- **Sideloading Culture:** MODERATE-HIGH (APKs shared via WhatsApp, Telegram common)
- **Restrictions:** None specific; [global Google verification from 2027](https://www.medianama.com/2025/08/223-google-blocks-android-apk-sideloading-2026/)

---

### 🇬🇭 Ghana - Mobile Money Mature Market

#### Mobile Money Landscape

- **Dominant Provider:** [MTN Mobile Money (MoMo)](https://asetenapa.com/ghana-mobile-money-statistics/) - 73% market share, 13M+ customers
- **Market Share:** [15.2M active mobile money users](https://www.imarcgroup.com/ghana-mobile-money-market), 59.7% adult penetration
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT - 74.1M registered accounts
- **Regulatory Score:** [95.06% on GSMA Mobile Money Regulatory Index](https://www.imarcgroup.com/ghana-mobile-money-market) (1st globally)
- **Competitors:** Vodafone Cash, AirtelTigo Money

**Key Strength:** Ghana has the world's BEST mobile money regulatory environment.

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** YES - Strong presence
- **[Paystack](https://radarr.africa/paystack-vs-flutterwave-vs-paypal/):** YES - One of 3-4 Paystack markets
- **Coverage Gap:** None for major providers

#### Currency

- **ISO Code:** GHS (Ghanaian Cedi)
- **Typical Transaction Sizes:**
  - [Bank of Ghana increased limits by 50% (balance) and 60% (transactions)](https://www.techinafrica.com/mobile-money-trends-in-african-marketplaces-2025/) in March 2024
- **Exchange Rate:** ~16 GHS = 1 USD (relatively stable vs Naira)

#### Language

- **Primary Business Language:** English (official)
- **English-Only Viability:** ✅ WORKS - English widely spoken
- **Localization Need:** LOW - Local languages (Akan, Ewe, Ga) not required for business apps

#### Data/Connectivity

- **Mobile Data Cost:** [$0.40-$0.85 per GB](https://nairametrics.com/2025/01/14/tariff-increase-cost-of-data-in-nigeria-ghana-south-africa-and-kenya-compared/)
- **Network Coverage:** 4G coverage ~75%, good urban coverage
- **Device Specs:** Similar to Kenya - mix of budget smartphones and feature phones

#### Regulatory

- **Data Protection:** [Data Protection Act (Act 843)](https://gdprlocal.com/gdpr-and-data-protection-laws-in-africa-a-comparison/) - moderate GDPR alignment
- **Fintech Licensing:** Bank of Ghana regulates payment systems
- **Mobile Money:** World-leading regulatory framework per GSMA

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** LOW-MODERATE
- **Restrictions:** None specific

---

### 🇿🇦 South Africa - Bank-First, Card-Dominant Market

#### Mobile Money Landscape

- **Critical Difference:** South Africa is NOT a mobile money market like Kenya/Nigeria
- **Dominant Players:** Banks (Standard Bank, FNB, Capitec) with banking apps + cards
- **Mobile Payments:** [SnapScan, Zapper (QR-based)](https://netcash.co.za/blog/top-online-payment-methods-in-south-africa-2025-update/), Google Wallet, Apple Pay, Samsung Pay
- **Mobile Money vs Bank Cards:** BANK CARDS DOMINANT - 80%+ bank account penetration
- **Trend:** [Contactless card payments growing](https://gadgeteer.co.za/how-snapscan-and-zapper-are-surviving-south-africas-tap-to-pay-onslaught-for-now-they-are-for-one-good-reason/), QR apps declining

**Critical:** Don't assume mobile money = South Africa. This is a banked, card-first market.

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** YES - Coverage available
- **[Paystack](https://radarr.africa/paystack-vs-flutterwave-vs-paypal/):** YES - One of 3-4 Paystack markets
- **Coverage Gap:** Both providers support South Africa but CARD payments more important than mobile money

#### Currency

- **ISO Code:** ZAR (South African Rand)
- **Exchange Rate:** ~18 ZAR = 1 USD (stable)

#### Language

- **Primary Business Language:** English (one of 11 official languages)
- **English-Only Viability:** ✅ WORKS - [Highest English proficiency in Africa](https://www.burunditimes.com/ef-index-2025-south-africa-and-zimbabwe-lead-africa-in-english-proficiency/) (602/800 EF score, joint-1st)
- **Localization Need:** LOW - English + Afrikaans covers business; Zulu, Xhosa for consumer apps (optional)

#### Data/Connectivity

- **Mobile Data Cost:** More expensive than West Africa (~$2-3 per GB)
- **Network Coverage:** Best in Africa - 5G available in major cities, 99.3% smartphone ownership among internet users
- **Device Specs:** [High-end device market](https://netcash.co.za/blog/mobile-wallet-trends-in-south-africa-whats-next-for-2026/) - iOS significant (unlike rest of Africa)

#### Regulatory

- **Data Protection:** [POPIA (Protection of Personal Information Act)](https://popia.co.za/) - MOST mature in Africa, close to GDPR
- **Key Updates:** [April 2025 amendments](https://www.oaklaw.co.za/how-south-african-data-protection-laws-impact-your-business-operations-in-2025/) - stricter consent, [mandatory breach reporting via eServices Portal](https://www.insideprivacy.com/data-security/data-breaches/south-africa-introduces-mandatory-e-portal-reporting-for-data-breaches/)
- **Enforcement:** Strong - [Information Regulator partnered with CIPC](https://secureprivacy.ai/blog/south-africa-popia-compliance) for public compliance status
- **Fintech Licensing:** Regulated by SARB (South African Reserve Bank)

**Critical:** South Africa has the MOST mature data protection regime in Africa. POPIA compliance non-negotiable.

#### App Stores

- **Google Play Dominance:** HIGH but iOS has significant share (~20% vs <5% in Nigeria/Kenya)
- **Sideloading Culture:** LOW (affluent market, users buy apps)
- **Restrictions:** None specific

---

### 🇹🇿 Tanzania - East Africa Mobile Money Hub

#### Mobile Money Landscape

- **Market Share:** Vodacom M-Pesa (39%), [Tigo Pesa (30%), Airtel Money (20%)](https://www.tanzaniainvest.com/mobile-money), Halopesa (7%)
- **Growth:** [92% subscription growth 2020-2024](https://www.ecofinagency.com/news-digital/2711-50895-tanzania-s-mobile-money-goes-global-vodacom-partners-with-visa-alipay-and-mtn), projected USD 221 billion by 2033
- **Cross-Border:** [M-Pesa Global Payments](https://telcomagazine.com/news/vodacom-expands-global-payments-with-m-pesa-upgrades) (Nov 2025) - Visa terminals, Alipay China, MTN Uganda, TerraPay Dubai
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** YES - Covered
- **Paystack:** NO - Not in Tanzania
- **Coverage Gap:** Paystack gap; need Flutterwave or direct mobile money integration

#### Currency

- **ISO Code:** TZS (Tanzanian Shilling)
- **Exchange Rate:** ~2,500 TZS = 1 USD

#### Language

- **Primary Business Languages:** Swahili (national), English (official)
- **English-Only Viability:** ⚠️ PARTIAL - English works in cities/business, but Swahili essential for mass market
- **Localization Need:** MODERATE - Swahili translation recommended for consumer apps

#### Data/Connectivity

- **Mobile Data Cost:** [$0.71 per GB](https://travelpander.com/how-much-is-a-data-plan-in-africa/)
- **Network Coverage:** Improving but urban-rural gap significant

#### Regulatory

- **Data Protection:** Basic framework, less mature than Kenya/Nigeria
- **Fintech Licensing:** TCRA (Tanzania Communications Regulatory Authority) + Bank of Tanzania

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** MODERATE

---

### 🇺🇬 Uganda - MTN-Dominated Market

#### Mobile Money Landscape

- **Dominant Provider:** MTN Mobile Money (MoMo) - clear market leader
- **Cross-Border:** [Airtel Money enables transfers to Rwanda, Tanzania, Zambia, Malawi](https://www.jitimu.com/2024/12/airtel-international-money-transfer-send-to-rwanda-tanzania-zambia-malawi/); M-Pesa to Uganda from Kenya/Tanzania
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** YES - Covered
- **Paystack:** NO - Not in Uganda
- **Coverage Gap:** Paystack gap

#### Currency

- **ISO Code:** UGX (Ugandan Shilling)
- **Exchange Rate:** ~3,700 UGX = 1 USD

#### Language

- **Primary Business Language:** English (official)
- **English-Only Viability:** ✅ WORKS - English widely used in business
- **Localization Need:** LOW - Luganda for consumer apps (optional)

#### Data/Connectivity

- **Mobile Data Cost:** [$0.02 per GB](https://intelpoint.co/insights/uganda-and-mauritius-offer-africas-cheapest-1gb-data-at-0-02-while-madagascar-ranks-highest-in-the-top-20-at-0-32/) (cheapest in Africa along with Mauritius)

#### Regulatory

- **Data Protection:** Basic framework
- **Fintech Licensing:** Bank of Uganda

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** MODERATE

---

### 🇷🇼 Rwanda - Tech-Forward, Mobile Money Hub

#### Mobile Money Landscape

- **Providers:** MTN Mobile Money (MoMo), Airtel Money
- **Cross-Border:** [Airtel to Rwanda from Kenya](https://www.jitimu.com/2024/12/airtel-international-money-transfer-send-to-rwanda-tanzania-zambia-malawi/); M-Pesa from Kenya
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** YES - Covered (charges 4.8% local cards, 3.5% mobile money)
- **Paystack:** NO - Not in Rwanda
- **Coverage Gap:** Paystack gap

#### Currency

- **ISO Code:** RWF (Rwandan Franc)
- **Exchange Rate:** ~1,300 RWF = 1 USD

#### Language

- **Primary Business Languages:** Kinyarwanda (national), English (official since 2003), French (legacy)
- **English-Only Viability:** ✅ WORKS - Rwanda switched to English as education language; young professionals fluent
- **Localization Need:** LOW-MODERATE - Kinyarwanda for mass market, English for business

#### Data/Connectivity

- **Mobile Data Cost:** Moderate (~$1-2 per GB)
- **Network Coverage:** Best in East Africa after Kenya - government prioritizes ICT infrastructure

#### Regulatory

- **Data Protection:** Moderate framework, government tech-friendly
- **Fintech Licensing:** National Bank of Rwanda

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** LOW (formal market, strong governance)

---

### 🇸🇳 Senegal - Francophone Mobile Money Leader

#### Mobile Money Landscape

- **Dominant Providers:** [Orange Money (strong), Wave (disruptor)](https://medium.com/@oussama.zaghdoud/orange-money-west-africas-digital-payment-champion-60690ab6f22b)
- **Wave Impact:** [Disrupting with zero-fee model](https://triplepundit.com/2025/wave-mobile-money-cote-divoire/), surpassing legacy players in user satisfaction
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT

**Critical:** Wave is THE disruptor in Francophone West Africa. Zero fees = rapid adoption.

#### Payment Aggregators

- **[Flutterwave](https://techcabal.com/2025/10/16/flutterwave-cross-border-payments-in-africa/):** YES - Expanded to Senegal in H1 2025
- **Paystack:** NO - Not in Senegal
- **Coverage Gap:** Major Paystack gap; Wave integration more important than Flutterwave

#### Currency

- **ISO Code:** XOF (West African CFA Franc - WAEMU)
- **Exchange Rate:** ~600 XOF = 1 USD (fixed to Euro, stable)
- **Key Advantage:** CFA currency zone stability attracts foreign investment

#### Language

- **Primary Business Language:** French (official), Wolof (national)
- **English-Only Viability:** ❌ DOES NOT WORK - [Low English proficiency](https://www.pulse.com.gh/story/best-english-speaking-countries-africa-2026011312513213815), French essential
- **Localization Need:** HIGH - French REQUIRED for business, Wolof for consumer apps

**Critical:** This is where Kenya/Nigeria pattern breaks. French translation is MANDATORY.

#### Data/Connectivity

- **Mobile Data Cost:** Moderate (~$1-2 per GB)
- **Network Coverage:** Good in Dakar, mixed rural

#### Regulatory

- **Data Protection:** WAEMU-level regulations, less strict than GDPR/POPIA
- **Fintech Licensing:** BCEAO (Central Bank of West African States) regulates

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** MODERATE

---

### 🇨🇮 Ivory Coast (Côte d'Ivoire) - Francophone Economic Hub

#### Mobile Money Landscape

- **Dominant Providers:** [Orange Money, MTN MoMo, Wave](https://www.afriex.com/resource-posts/africas-mobile-money-titans-top-providers-powering-financial-inclusion-by-region)
- **Wave Disruption:** ["Preferred payment solution" by 2021](https://www.promptloop.com/directory/what-does-wave-do), [launched commercial bank](https://www.ecofinagency.com/news-finances/2610-49842-wave-launches-commercial-bank-in-cote-d-ivoire) in Côte d'Ivoire (2025)
- **Growth:** [Expected >20% YoY growth](https://www.techinafrica.com/mobile-money-trends-in-african-marketplaces-2025/)
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT

#### Payment Aggregators

- **[Flutterwave](https://techcabal.com/2025/10/16/flutterwave-cross-border-payments-in-africa/):** YES - Expanded to Cameroon in H1 2025 (likely covers Ivory Coast too)
- **Paystack:** NO - Not in Ivory Coast
- **Coverage Gap:** Major Paystack gap

#### Currency

- **ISO Code:** XOF (West African CFA Franc - WAEMU, shared with Senegal)
- **Exchange Rate:** ~600 XOF = 1 USD (stable)

#### Language

- **Primary Business Language:** French (official)
- **English-Only Viability:** ❌ DOES NOT WORK - [Low English proficiency](https://www.pulse.com.gh/story/best-english-speaking-countries-africa-2026011312513213815) (393/800 EF score)
- **Localization Need:** HIGH - French REQUIRED

#### Data/Connectivity

- **Mobile Data Cost:** Moderate (~$1-2 per GB)
- **Network Coverage:** Good in Abidjan, mixed elsewhere

#### Regulatory

- **Data Protection:** WAEMU-level regulations
- **Fintech Licensing:** BCEAO regulates

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** MODERATE

---

### 🇪🇬 Egypt - MENA Gateway, Different Ecosystem

#### Mobile Money Landscape

- **Different Model:** NOT mobile money-first like Sub-Saharan Africa
- **Key Players:** [Fawry (dominant), InstaPay (instant payments)](https://www.mordorintelligence.com/industry-reports/egypt-mobile-payment-market)
- **Fawry:** [6M daily transactions](https://www.transfi.com/blog/egypts-payment-rails-how-they-work---meeza-instapay-mobile-wallet-growth), 370K agent network, BNPL services
- **InstaPay:** [EGP 112.7B ($3.65B) in first year](https://www.lightspark.com/knowledge/egypt-instant-payments), 70% outside banking hours
- **Mobile Money vs Bank Cards:** MIXED - bank cards + digital wallets, NOT telco-based mobile money

**Critical:** Egypt's payment ecosystem is completely different from Sub-Saharan Africa. Instant bank transfers (InstaPay) > mobile money.

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** Unclear - Egypt coverage not explicitly mentioned
- **Paystack:** NO
- **Coverage Gap:** MAJOR - need Fawry/InstaPay integration, not traditional mobile money

#### Currency

- **ISO Code:** EGP (Egyptian Pound)
- **Typical Transaction Sizes:**
  - InstaPay fee: [0.1% (min 50 piasters, max EGP 20)](https://www.lightspark.com/knowledge/egypt-instant-payments) since April 2025
- **Exchange Rate:** ~31 EGP = 1 USD (devalued significantly 2022-2024)

#### Language

- **Primary Business Language:** Arabic (official), English (business)
- **English-Only Viability:** ⚠️ PARTIAL - English works for urban/educated users, but Arabic essential for mass market
- **Localization Need:** HIGH - Arabic REQUIRED for consumer apps, English sufficient for B2B

**Critical:** Egypt requires RIGHT-TO-LEFT (RTL) UI support for Arabic. Not just translation.

#### Data/Connectivity

- **Mobile Data Cost:** [$0.93 per GB](https://travelpander.com/how-much-is-a-data-plan-in-africa/)
- **Network Coverage:** Good in Cairo/Alexandria, mixed elsewhere
- **Device Specs:** Mix of smartphones and feature phones

#### Regulatory

- **Data Protection:** [Personal Data Protection Law (2020), executive regulations 2025](https://practiceguides.chambers.com/practice-guides/fintech-2025/egypt)
- **Fintech Licensing:** [Central Bank of Egypt (CBE) - new Central Bank Law No. 194 of 2020](https://iclg.com/practice-areas/fintech-laws-and-regulations/egypt)
- **Recent:** [Tokenization regulations (March 2023)](https://www.lexology.com/library/detail.aspx?g=4ade2855-28cb-47ee-a7ce-d4f81ed67c84), [PSP governance rules (Sept 2025)](https://practiceguides.chambers.com/practice-guides/fintech-2025/egypt)
- **E-KYC:** [Electronic KYC project H1 2025](https://practiceguides.chambers.com/practice-guides/fintech-2025/egypt)

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** MODERATE-HIGH (Arabic APK sharing common)

---

### 🇪🇹 Ethiopia - Telebirr Monopoly Market

#### Mobile Money Landscape

- **Monopoly Provider:** [Telebirr (Ethio Telecom)](https://techafricanews.com/2025/07/25/ethio-telecom-achieves-83-2m-subscribers-and-73-revenue-surge-as-lead-strategy-concludes/) - 54.8M users (largest in Africa by single provider)
- **Market Share:** [99.1% network coverage](https://www.gsma.com/about-us/regions/sub-saharan-africa/wp-content/uploads/2024/10/GSMA_Ethiopia-Report_Oct-2024_v2-1.pdf), no meaningful competition
- **Transaction Volume:** [2.38 trillion birr](https://www.addisinsight.net/2024/09/19/ethiotelecom-aims-to-expand-telebirr-service-to-55-million-subscribers-by-2025/) in FY2025
- **Ecosystem:** 310K merchants, 320K agents, [13.22B birr in micro-loans](https://exscape.et/digital-ethiopia-2025-building-a-smarter-faster-more-connected-country/)
- **Mobile Money vs Bank Cards:** Mobile money DOMINANT (Telebirr only option for most)

**Critical:** Ethiopia is a single-provider market. Integration = Telebirr or nothing. No competition = potential regulatory/pricing risk.

#### Payment Aggregators

- **[Flutterwave](https://research.contrary.com/company/flutterwave):** NO - Not in Ethiopia (34 countries, Ethiopia not mentioned)
- **Paystack:** NO
- **Coverage Gap:** TOTAL - must integrate Telebirr directly

#### Currency

- **ISO Code:** ETB (Ethiopian Birr)
- **Exchange Rate:** ~120 ETB = 1 USD (official; black market significantly different)

#### Language

- **Primary Business Language:** Amharic (official), English (business/education)
- **English-Only Viability:** ⚠️ PARTIAL - English literacy lower than Kenya/Nigeria, Amharic essential for mass market
- **Localization Need:** HIGH - Amharic REQUIRED (also uses Ge'ez script, not Latin alphabet)

**Critical:** Amharic uses different script (Ge'ez/Ethiopic). Requires font support, not just translation.

#### Data/Connectivity

- **Mobile Data Cost:** Low (government subsidized telecom)
- **Network Coverage:** [99.4% population, 86.5% geographic](https://www.mordorintelligence.com/industry-reports/ethiopia-telecom-mno-market)
- **Device Specs:** [Ethio Telecom partnered with Siinqee Bank](https://techafricanews.com/2025/04/28/ethio-telecom-siinqee-bank-alliance-to-drive-smartphone-penetration-and-digital-finance/) (April 2025) to drive smartphone penetration

#### Regulatory

- **Data Protection:** Limited framework, government controls telecom
- **Fintech Licensing:** National Bank of Ethiopia, but Telebirr monopoly makes this moot
- **Political Risk:** Single-party state; regulatory changes can be abrupt

#### App Stores

- **Google Play Dominance:** HIGH
- **Sideloading Culture:** MODERATE
- **Risk:** Government can block apps/services (has happened in past)

---

## Additional Markets (Brief Overview)

### Cameroon 🇨🇲

- **Mobile Money:** MTN MoMo, Orange Money dominant
- **Language:** French (official), English (official in some regions) - BILINGUAL country
- **Payment Aggregators:** [Flutterwave (H1 2025)](https://techcabal.com/2025/10/16/flutterwave-cross-border-payments-in-africa/), pawaPay
- **Currency:** XAF (Central African CFA Franc) - different from XOF (West African CFA)
- **Localization:** French REQUIRED

### DRC (Democratic Republic of Congo) 🇨🇩

- **Mobile Money:** MTN MoMo, Orange Money, Airtel Money
- **Language:** French (official) - [Low English proficiency](https://www.pulse.com.gh/story/best-english-speaking-countries-africa-2026011312513213815)
- **Payment Aggregators:** [Flutterwave, pawaPay, Yellow Card](https://www.afriex.com/resource-posts/africas-mobile-money-titans-top-providers-powering-financial-inclusion-by-region)
- **Currency:** CDF (Congolese Franc) - highly volatile
- **Challenges:** Political instability, infrastructure gaps
- **Localization:** French REQUIRED

---

## Social Coordination & Trust Mechanisms

> How do communities in each market coordinate, build trust, and make collective decisions — and what does this mean for DAO governance design?

### Traditional Savings Groups as Proto-DAOs

Every market has a traditional rotating savings and credit association (ROSCA) that functions as a proto-DAO with treasury management, governance, and membership rules:

| Market       | Name               | Key Characteristics                                                                                                |
| ------------ | ------------------ | ------------------------------------------------------------------------------------------------------------------ |
| Kenya        | **Chama**          | 1 in 3 Kenyans is a member; digital platforms (OneKitty, Chamatek) send updates to WhatsApp/Telegram               |
| Nigeria      | **Ajo/Esusu**      | 80% of population in informal savings; 58% of GDP is informal; 70% of market traders are women                     |
| Ghana        | **Susu**           | Collectors operate from marketplace kiosks; Naa Sika platform (50K+ users) runs via WhatsApp + USSD                |
| South Africa | **Stokvel**        | Half of adults are members; 800,000 stokvels; ~R50B ($2.7B) invested annually                                      |
| Tanzania     | **Upatu/Vikoba**   | Women-led; members "buy shares" at weekly meetings; loans at 5-10% interest over 3 months                          |
| Uganda       | **VSLA**           | Ensibuuko has trained 3,900+ VSLAs (239,000 members); PostBank zero-cost group accounts (5,000 groups in year one) |
| Rwanda       | **VSLA**           | ForAfrika onboarded 35 VSLA groups on Amatsinda.rw platform (targeting 90 by end 2025); native language interface  |
| Senegal      | **Tontine**        | ~$200M/year; MaTontine (since 2015) partners with telecoms; SMS for non-smartphone users                           |
| Ivory Coast  | **Tontine**        | Maman Tontine and Tontiin integrate with Wave and Orange Money                                                     |
| Egypt        | **Gam3iya**        | Spans ALL economic classes; MoneyFellows raised $60M total; ElGameya semifinalist at GITEX Africa 2024             |
| Ethiopia     | **Equb**           | eQUB won Best FinTech at MWC Barcelona 2024; available in English + 4 local languages                              |
| Cameroon     | **Njangi/Tontine** | Widespread among women traders in Douala and Yaounde markets                                                       |

### Communication Platform Dominance

**WhatsApp dominates everywhere except Ethiopia:**

| Market       | WhatsApp Penetration                    | Telegram Role                         | SMS/USSD Relevance                                                    |
| ------------ | --------------------------------------- | ------------------------------------- | --------------------------------------------------------------------- |
| Kenya        | 97% of internet users                   | Growing (crypto/fintech)              | Relevant via USSD for non-smartphone                                  |
| Nigeria      | 95%+                                    | Growing (crypto, youth)               | Critical — PalmPay launched USSD Oct 2024                             |
| Ghana        | 90%+                                    | Marginal                              | Important for rural populations                                       |
| South Africa | 96% (avg 24h55m/month)                  | Niche                                 | Moderate                                                              |
| Tanzania     | Dominant                                | Minimal                               | **77% of mobile money runs on USSD**                                  |
| Uganda       | Dominant (lower smartphone penetration) | Minimal                               | **"Largest technology" for mobile money**                             |
| Rwanda       | Dominant                                | Minimal                               | Declining as digital payments hit 300% GDP                            |
| Senegal      | Dominant                                | Minimal                               | **Essential — only 20% have smartphones; ~1% for women under $5/day** |
| Ivory Coast  | Dominant                                | Minimal                               | Important                                                             |
| Egypt        | Dominant                                | Minimal                               | Moderate                                                              |
| **Ethiopia** | **12% satisfaction**                    | **Dominant (75% Gen-Z satisfaction)** | Important                                                             |
| Cameroon     | Dominant (second to Facebook)           | Minimal                               | Growing                                                               |

**Ethiopia exception explained**: Telegram dominates because it (1) uses less data (43MB vs 103MB download), (2) works better on 2G/3G, (3) perceived security from government surveillance, (4) resilient during internet shutdowns, (5) supports unlimited channel members vs WhatsApp's 256 limit. **Hulugram**, a localized Telegram fork, has 1M+ downloads with Amharic, Oromo, and Tigrinya support.

### Voice-First Culture

Voice is not optional — it is the primary communication medium across African markets:

- **Senegal**: Nearly 50% illiteracy; WhatsApp voice notes enable farmer participation in 15,000-member agricultural network (32 WhatsApp groups)
- **Nigeria**: 500+ languages, varying literacy; voice notes preferred for expressiveness; #EndSARS coordinated via voice messages
- **Kenya**: Oral traditions "transposed onto social media platforms"; voice default for emotional/nuanced discussions
- **South Africa**: 11 official languages; voice notes bridge language barriers in multilingual stokvel groups
- **Tanzania**: Voice coordinates vikoba meetings; text supplements logistics
- **Global context**: 7 billion WhatsApp voice messages sent daily

**EnDAO Design Implication**: Voice-note proposals, voice-based voting confirmations, and audio summaries of treasury actions should be first-class features, not afterthoughts.

### Trust Building Patterns (The Trust Stack)

Trust is built in consistent layers across all 12 markets:

1. **Physical proximity** — Initial meetings are always in-person
2. **Social vouching** — Existing members invite and guarantee new ones (stokvels are invitation-only; chamas require social guarantorship)
3. **Graduated commitment** — Small contributions before large ones; new members prove reliability
4. **Reputation tracking** — Contribution history = creditworthiness (M-Pesa transaction history as informal reputation in Kenya; MoneyFellows uses behavioral data and credit scores in Egypt)
5. **Transparency of records** — The single biggest driver of digital adoption across every market

Key examples of trust dynamics:

- **Nigeria (Esusu)**: "Operates solely on an oath of allegiance and mutual trust"; failure "damages one's social standing"; the **alajo** (professional collector) model adds personal accountability
- **South Africa (Stokvel)**: Ubuntu philosophy ("I am because we are") underpins collective savings. **Warning**: WhatsApp stokvels associated with pyramid schemes — EnDAO's audit trail directly addresses this trust gap
- **Rwanda (VSLA)**: "Digitising our VSLA group has motivated us to save money, knowing that it is very secure. Today, more members of the community are showing interest in joining our group because we are very transparent and organised."
- **Tanzania (Vikoba)**: CHOMOKA app sends "feedback to group members via text messages immediately once meetings are closed" — reducing fraud

### Group Decision-Making Patterns

| Pattern                            | Markets                      | Description                                                                                              | EnDAO Mapping                                                         |
| ---------------------------------- | ---------------------------- | -------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| **Consensus + Elder Authority**    | All markets                  | Group leaders (chairperson, treasurer) hold significant authority; flat governance is culturally foreign | Role-based permissions with clear "chairperson" and "treasurer" roles |
| **Rotation-Based Fairness**        | Kenya, Nigeria, Senegal      | Payout order decided by ballot or consensus                                                              | Rotating proposal rights, fair distribution mechanisms                |
| **Weekly/Monthly Meeting Cadence** | All markets                  | Major decisions at physical meetings; digital fills gaps                                                 | Default proposal/voting cycles aligned to weekly cadence              |
| **Physical-First, Digital-Second** | All markets                  | Digital coordination supplements but doesn't replace face-to-face governance                             | "Meeting mode" for in-person sessions with digital record-keeping     |
| **Graduated Membership**           | Kenya, South Africa, Nigeria | New members start with small commitments                                                                 | Progressive trust/permission levels in DAO onboarding                 |

### Women as Primary Users

Women lead savings circles across all markets:

- **Nigeria**: 70% of market traders are women
- **Tanzania**: "The overwhelming majority of vikoba participants are women"
- **Senegal**: MaTontine's target group is "women living under $5/day"
- **South Africa**: Women are majority stokvel organizers
- **Uganda/Rwanda**: VSLAs primarily serve women in rural communities

**EnDAO Design Implication**: UX must be designed for and tested with women users first. Governance language should avoid male-coded authority terms. The savings circle → DAO pipeline is fundamentally a women's financial empowerment story.

### Mobile Money as Treasury Rails

Mobile money is not just a payment method — it IS the treasury infrastructure:

| Market              | Key Platform     | Scale                                       | Integration Priority         |
| ------------------- | ---------------- | ------------------------------------------- | ---------------------------- |
| Kenya               | M-Pesa           | 60M users, $67.3B processed (2024)          | **Critical**                 |
| Senegal/Ivory Coast | Wave             | 8M users, 1% flat fee                       | **Critical** for francophone |
| Tanzania            | M-Pesa/Tigo Pesa | 61.88M subscriptions (92% growth 2020-2024) | High                         |
| Uganda              | MTN MoMo         | $133B market (25.7% CAGR projected)         | High                         |
| Rwanda              | MTN MoMo         | Digital payments at 300% of GDP             | High                         |
| Nigeria             | OPay/PalmPay     | Growing rapidly                             | High                         |
| Egypt               | MoneyFellows     | $60M raised; regulatory cooperation         | Medium                       |
| Ethiopia            | Telebirr         | Government-backed monopoly                  | Medium                       |

**EnDAO Design Implication**: Fiat-to-crypto treasury must integrate with M-Pesa, Wave, Orange Money, MTN MoMo — not just card payments.

### Cross-Cutting Design Implications

1. **Position EnDAO as "your chama/stokvel/tontine, but with transparent records and voting"** — the savings circle is the universal mental model for collective treasury management
2. **USSD/SMS floor is mandatory**: Tanzania (77% USSD), Uganda (USSD-dominant), Senegal (1% smartphone for target women). Critical governance actions (vote yes/no, approve treasury) must have SMS/USSD fallback
3. **Admin/Elder authority is expected**: Progressive decentralization is the path, not starting flat. Role-based permissions more familiar than equal-weight multisig
4. **Weekly cadence defaults**: Proposal and voting cycles should default to weekly, matching physical meeting rhythms
5. **Ethiopia requires separate strategy**: Telegram-first (not WhatsApp), Hulugram integration, offline-capable voting for internet shutdowns
6. **Transparency is the killer feature**: Every digitization effort (CircleFunds, CHOMOKA, Amatsinda, MoneyFellows, StokFella) found that transparent records directly drive membership growth
7. **Data poverty shapes everything**: Sub-Saharan Africa averages 5 GB/month per smartphone (vs 21 GB global); 2G/3G accounts for nearly half of connections; offline-first architecture required

### Sources — Social Coordination & Trust

- [WhatsApp Usage Across Africa - AskYazi](https://www.askyazi.com/useful-data-sources-for-africa/whatsapp-usage-across-africa-key-statistics-insights-for-2025)
- [Telegram Success in Ethiopia - Sagaci Research](https://sagaciresearch.com/preferred-social-media-and-communication-apps-across-africa-what-makes-telegram-a-success-in-ethiopia/)
- [WhatsApp Voice Notes in Senegal Farming - Rest of World](https://restofworld.org/2023/whatsapp-voice-notes-farming-senegal/)
- [Security and Trust in Africa's Digital Financial Inclusion - Carnegie](https://carnegieendowment.org/research/2024/03/security-and-trust-in-africas-digital-financial-inclusion-landscape)
- [African Financing Models - WEF](https://weforum.org/agenda/2024/10/financial-inclusion-african-financing-models)
- [CircleFunds Revolutionizing Ajo - The Nation](https://thenationonlineng.net/from-traditional-to-digital-how-a-nigerian-fintech-circlefunds-is-revolutionising-thrift-ajo-or-esusu-in-africa/)
- [Digital Stokvels - StokFella](https://www.stokfella.com/digital-stokvels-the-new-frontier-of-collective-saving)
- [Naa Sika Digital Susu](https://naasika.com/)
- [Tanzania Mobile Money Market - IFC](https://www.ifc.org/content/dam/ifc/doc/2024/evolution-of-the-mobile-money-payment-market-in-tanzania.pdf)
- [Digitalising VSLAs in Rwanda - ForAfrika](https://www.forafrika.org/rwanda/digitalising-hope-how-digitalising-vsla-groups-is-promoting-financial-inclusion-among-rural-communities-in-rwanda/)
- [Hulugram Super App - TechSafari](https://techsafari.beehiiv.com/p/hulugram)
- [eQUB Digital Equb - ITC](https://www.intracen.org/news-and-events/news/equb-brings-ethiopias-traditional-saving-system-into-the-digital-age)
- [MoneyFellows - TechCrunch](https://techcrunch.com/2025/05/04/moneyfellows-raises-13m-to-take-its-group-savings-model-outside-egypt/)
- [MaTontine Senegal - Amarante Consulting](https://amaranteconsulting.com/en/matontine-digitizing-traditional-savings-groups-for-financial-inclusion/)
- [Mobile Economy Africa 2025 - GSMA](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/africa/)

---

## DAO Governance & Cooperative Traditions

> How do traditional governance structures, cooperative movements, and crypto adoption patterns map to DAO design in each market?

### Per-Market Governance Deep Dive

#### Kenya — SACCO Ecosystem + Silicon Savannah

- **Traditional system**: Chama (investment group) — 1 in 3 Kenyans is a member
- **Cooperative sector**: **22,000 registered cooperatives**, 14+ million members. SACCOs hold KES 638 billion ($5.3B) in deposits (2023). Kenya Cooperative Bank is the largest in Africa
- **Governance structure**: Chairperson, secretary, treasurer — elected positions. Written constitutions define contribution, payout, and meeting rules
- **Crypto adoption**: **Chainalysis #19 (2024)**. VASP Bill expected 2025. $638M in on-chain value (2024). iHub community of 16,000+ innovators
- **Digital tools**: OneKitty, Chamatek, SACCOlink — digital platforms for group management
- **EnDAO analogy**: Chama = DAO, SACCO = regulated DAO, chairperson/treasurer = multi-sig signers

#### Nigeria — Informal Finance Powerhouse

- **Traditional system**: Ajo (Yoruba), Adashe (Hausa), Esusu (Igbo) — **58% of GDP is informal**
- **Governance**: The **Alajo** (collector/administrator) is central — collects daily/weekly, takes small commission. Trust enforced through clan-based social control. "If you benefit from the collective, the collective has a right to redress"
- **Crypto adoption**: Africa's crypto leader — **#2 globally (2024), #6 (2025)**. $92.1B in on-chain value. **25.9M stablecoin users** (world's highest). Investments and Securities Act (March 2025) recognizes crypto
- **Youth**: Median age 18.1 years, Lagos has ~2,000 tech startups, ecosystem valued at $9.8B
- **EnDAO analogy**: Alajo = treasury manager/multi-sig signer. Clan accountability = reputation-based governance

#### Ghana — Susu Democracy

- **Traditional system**: Susu ("little by little" in Twi) — democratic with elected board members. "Abusing the system is unthinkable due to high social and reputational costs"
- **Organization**: Ghana Co-operative Susu Collectors Association (GCSCA, est. 1990) provides oversight
- **Crypto adoption**: **Chainalysis #29 (2024)**. $3B in crypto traded (3M people, ~9% of population). Virtual Assets Regulatory Office (VARO) established; crypto bill targeting December 2025 legalization
- **EnDAO analogy**: Susu board = governance council. GCSCA oversight = regulatory compliance layer

#### South Africa — Stokvel Constitution Model

- **Traditional system**: Stokvel — **R50B ($2.7B)/year**, **800,000+ groups**, **11M members**
- **Governance**: Founding members draft a **constitution** defining objectives, membership, contributions, payouts, meetings, and governance. Executive committee: chairperson, secretary, treasurer — all elected. **NASASA** (National Stokvel Association) self-regulates 125,000+ groups
- **Types**: Savings, burial societies, investment stokvels (stock market), grocery stokvels (bulk purchasing)
- **Crypto adoption**: **Chainalysis #30 (2024)**. **FSCA granted licenses to 248 crypto firms** (2024). Travel Rule compliance operationalized 2025. Project Khokha CBDC pilot
- **EnDAO analogy**: Stokvel constitution = DAO charter/smart contract. NASASA = industry self-regulation. Investment stokvel = treasury management DAO. Burial society = mutual aid DAO

#### Tanzania — Upatu + SACCO Gap

- **Traditional system**: Upatu — community savings, mutual trust. **Kijumbe** (group leader) manages operations
- **Cooperative sector**: 1,283 SACCOs with 6% member penetration (TCDC 2023). Many still use outdated desktop applications — significant digitization gap
- **Crypto**: Not in Chainalysis top 30. Gray area — Bank of Tanzania warnings but no formal ban
- **EnDAO analogy**: Kijumbe = DAO admin/multi-sig holder. Upatu rules = governance parameters

#### Uganda — SACCO Explosion

- **Traditional system**: VSLAs as dominant informal system
- **Cooperative sector**: Explosive growth — from ~4,000 SACCOs (2015) to **30,000+ SACCOs** (March 2025). 5.6M cooperative members. Regulated by UMRA (Uganda Microfinance Regulatory Authority)
- **Crypto**: Moderate. Growing P2P activity via Yellow Card, Binance P2P
- **EnDAO opportunity**: Massive SACCO digitization need

#### Rwanda — Digital Governance Leader

- **Traditional system**: **Ibimina** (savings groups) and **Imihigo** — a cultural governance vow meaning "to deliver," embedded in institutional frameworks
- **Organization**: Rwanda Cooperative Agency (RCA) registers and arbitrates. State-supported cooperative model
- **Digital governance**: **IremboGov** platform for citizen services. 99% mobile broadband coverage. Government aims to raise digital literacy from 53% to 80% by 2027
- **Crypto**: Low. Focus on blockchain-for-development, not trading
- **EnDAO opportunity**: Most digitally ready government infrastructure; ideal pilot market for formal DAO recognition

#### Senegal — Tontine Matriarchy

- **Traditional system**: Tontines known as **natt** (Wolof), **tegge** (Wolof), **pidd** (Fulani), **ndon** (Serer). Across West Africa, **30M women save $3B annually** through tontines
- **Governance**: Recommendation-based membership. Clear rules enforced with discipline — fines for missed meetings, exclusion for disruption. Manager role carries social status. Three types: mutual (welfare), commercial (profit), financial (interest-bearing)
- **Regulatory**: BCEAO (Central Bank of West African States) oversees CFA franc zone. Crypto in gray area
- **EnDAO analogy**: Tontine manager = DAO facilitator. Recommendation-based membership = permissioned DAO. Fines = slashing mechanisms

#### Ivory Coast — COCOVICO Model

- **Traditional system**: Tontines, same as Senegal. Notable: **COCOVICO** — cooperative of Abidjan market women who built a market with **200 shops and 700 stalls** through tontine-pooled capital
- **Regulatory**: BCEAO gray area. CFA franc stability reduces crypto urgency
- **EnDAO opportunity**: Proof that tontine-pooled capital can fund real infrastructure — the DAO treasury use case is already proven

#### Egypt — Gameya Nation (Crypto Banned)

- **Traditional system**: Gameya — **43% of Egyptians participate** (highest rate in this research). Spans all economic classes
- **Digital transformation**: Money Fellows completed **2M+ savings circles**, **$1.5B in transactions**, achieved profitability. Competitors: Tahweesha, ElGameya
- **Crypto**: **Effectively banned.** CBE Law No. 194/2020 prohibits issuance/trade/promotion without license (none issued). Dar al-Ifta fatwa classifying crypto as haram (non-binding but culturally influential)
- **EnDAO challenge**: Must operate as digital cooperative/gameya platform, not "crypto" or "DAO"

#### Ethiopia — Equb + Telegram + Rising Crypto

- **Traditional system**: **Equb** (ROSCA) and **Idir** (mutual aid for funerals/emergencies). Equb payouts can exceed **5M birr ($500K+)**. "Much of the construction boom in Addis is being financed with equb." 41% of members use payouts for business expansion
- **Digital**: eQUB app grew to 110,000 users. Won Best FinTech at MWC Barcelona 2024
- **Crypto**: Surging — **Chainalysis #12 (2025)**, up from #26. Driven by stablecoin use amid currency devaluation. Grassroots, retail-driven
- **EnDAO analogy**: Equb lottery = randomized treasury distribution. Idir = mutual insurance DAO. Equb's ethical governance = values-aligned DAO constitution

#### Cameroon — Tontine as Primary Credit

- **Traditional system**: Tontines are **the primary source of credit** for many poor Cameroonians, especially women and young people. Government has tolerated but not regulated them
- **Types**: Financial, goods/services, credit-savings, emergency-savings, school-banks, savings for development
- **Crypto**: Low. BEAC (Bank of Central African States) gray area. Central African Republic briefly adopted Bitcoin (2022) then reversed
- **Regulatory**: CEMAC variant of CFA franc zone

### Cross-Cutting Governance Patterns

**Universal elements across all 12 markets:**

1. **Constitution/Rules-Based Governance**: Every system has written or oral rules → maps to DAO governance parameters and smart contracts
2. **Elected Leadership with Defined Roles**: Chairperson/secretary/treasurer is universal → maps to multi-sig signers and role-based access control
3. **Trust as Infrastructure**: Social trust and reputation are both strength (low overhead) and vulnerability (embezzlement risk) → DAOs offer transparent on-chain records that augment trust
4. **Consensus Decision-Making**: One-member-one-vote is default → maps to equal-weight DAO voting
5. **Peer Enforcement**: Fines, exclusion, social pressure → maps to slashing, reputation scoring, permissioned membership

### Regional Differentiation

| Dimension              | East Africa (KE, TZ, UG, RW, ET) | West Africa (NG, GH, SN, CI, CM) | Southern (ZA)        | North (EG)            |
| ---------------------- | -------------------------------- | -------------------------------- | -------------------- | --------------------- |
| **Dominant system**    | Chama/SACCO                      | Ajo/Susu/Tontine                 | Stokvel              | Gameya                |
| **Formalization**      | High (SACCO regulation)          | Low-Medium                       | Medium (NASASA)      | Low (digitizing fast) |
| **Digital readiness**  | High (M-Pesa ecosystem)          | Medium (mobile money growing)    | High                 | Medium-High           |
| **Crypto adoption**    | High (KE, ET climbing)           | Very High (NG leads Africa)      | High (institutional) | Very Low (banned)     |
| **Gender dynamics**    | Mixed                            | Female-dominated (70%+ women)    | Mixed                | Mixed                 |
| **Regulatory clarity** | Improving (KE bill)              | Improving (NG, GH)               | Best in Africa (ZA)  | Hostile (EG)          |

### Market Prioritization for EnDAO

**Tier 1 — Immediate opportunity** (high collective governance + crypto adoption + regulatory clarity):

- **Kenya**: SACCO ecosystem + crypto bill + M-Pesa + Silicon Savannah
- **Nigeria**: Massive informal finance + #6 crypto adoption + 238M population
- **South Africa**: Stokvel culture + regulated crypto market + institutional interest

**Tier 2 — Growing rapidly** (strong traditions + emerging crypto/regulation):

- **Ghana**: Susu tradition + $3B crypto trading + regulation imminent
- **Ethiopia**: Equb culture + #12 crypto adoption + 135M population
- **Rwanda**: Digital governance leader + progressive stance + strategic beachhead

**Tier 3 — Longer-term** (strong traditions but lower digital/crypto readiness):

- Tanzania, Uganda: Strong VSLA/SACCO traditions but lower crypto adoption
- Senegal, Ivory Coast, Cameroon: Deep tontine culture but CFA franc stability reduces crypto urgency
- Egypt: Highest gameya participation (43%) but crypto effectively banned

### Localization Concept Mapping

| EnDAO Concept  | Kenya                         | Nigeria               | South Africa                    | Francophone           | Ethiopia                | Egypt                   |
| -------------- | ----------------------------- | --------------------- | ------------------------------- | --------------------- | ----------------------- | ----------------------- |
| DAO            | "Digital Chama"               | "Smart Ajo"           | "Digital Stokvel"               | "eTontine"            | "Digital Equb"          | "Smart Gameya"          |
| Treasury       | "Group savings"               | "Ajo pool"            | "Stokvel fund"                  | "Caisse commune"      | "Equb pot"              | "Gameya fund"           |
| Multi-sig      | "3-of-5 committee"            | "Alajo + 2 witnesses" | "Chair + Treasurer + Secretary" | "Manager + 2 membres" | "Trust circle approval" | "Three-person sign-off" |
| Vote           | "Chama meeting vote"          | "Clan consensus"      | "Stokvel AGM resolution"        | "Tontine assembly"    | "Equb draw decision"    | "Group agreement"       |
| Smart contract | "Self-enforcing constitution" | "Automated Alajo"     | "Digital constitution"          | "Regles automatiques" | "Rules on autopilot"    | "Gameya contract"       |

### Sources — DAO Governance & Cooperative Traditions

- [Chainalysis 2024 Global Crypto Adoption Index](https://www.chainalysis.com/blog/2024-global-crypto-adoption-index/)
- [Chainalysis 2025 Sub-Saharan Africa Report](https://www.chainalysis.com/blog/subsaharan-africa-crypto-adoption-2025/)
- [Chama (Investment) - Wikipedia](<https://en.wikipedia.org/wiki/Chama_(investment)>)
- [Esusu (Nigeria) - Global Informality Project](<https://www.in-formality.com/wiki/index.php?title=Esusu_(Nigeria)>)
- [NASASA - National Stokvel Association](https://www.nasasa.co.za/)
- [Ghana Susu - GEO](https://geo.coop/articles/ghana-susu-reimagining-financial-development)
- [eQUB - ITC](https://www.intracen.org/news-and-events/news/equb-brings-ethiopias-traditional-saving-system-into-the-digital-age)
- [Tontines - Fair Observer](https://www.fairobserver.com/region/africa/tontines-informal-financial-sector-and-sustainable-development-cameroon/)
- [Tontines - D+C](https://www.dandc.eu/en/article/self-organised-savings-communities-tontines-are-example-economic-social-and-cultural)
- [Money Fellows - FinTech Weekly](https://www.fintechweekly.com/magazine/articles/egypt-fintech-money-fellows-1-5-billion-transactions)
- [Kenya SACCO Sector 2025 - Sacco Review](https://saccoreview.co.ke/kenyas-cooperative-sector-in-2025-progress-promise-and-peril/)
- [Nigeria Crypto Regulation - IBA](https://www.ibanet.org/Updated-overview-of-Nigerian-cryptocurrency-landscape)
- [South Africa FSCA Licensing](https://www.techinafrica.com/south-africa-leads-crypto-regulation-new-casp-licenses/)
- [Rwanda Digital Governance](https://globaldev.blog/bridging-the-divide-rwandas-quest-for-equitable-digital-governance/)
- [Uganda SACCOs - UMRA](https://umra.go.ug/)
- [GSMA Mobile Economy Africa 2025](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/africa/)

---

## Treasury & Collective Fund Management

> How do communities pool, manage, lend, and distribute collective funds — and what does this mean for DAO treasury design?

### Per-Market Treasury Patterns

#### Kenya — Digital Chama Treasury

- **Scale**: 300,000+ chamas hold KES 300B+ (~$2.3B) in assets. 98.9% of SACCO members prefer digital channels
- **Digital tools**: ChamaPesa (M-Pesa integration, exploring "Chamacoin" blockchain), Chama Systems (merry-go-round automation), Fibo360 (SACCO/chama loan management)
- **Fund sizes**: KES 5,000/month (social chamas) to KES 50,000+/month (investment chamas)
- **M-Pesa business**: 675,000+ businesses use Lipa Na M-Pesa, processing KES 1.974T ($15.2B) annually
- **Limits**: KES 250,000/tx (~$1,920); KES 500,000/day; KES 500,000 max balance. PesaLink enables bank transfers up to KES 500,000
- **Multi-sig**: SACCOs require 3 signatories (Chairperson, Treasurer, Secretary) via minuted resolution. Minimum 10 members to register; 30+ recommended
- **Lending**: Fuliza (33.4M users, KES 2.9T disbursed, ~395% APR); M-Shwari (32M users, ~90% APR); 91% of digital loan users borrow via M-Pesa

#### Nigeria — Ajo Pool + Fintech Boom

- **Traditional**: Ajo collector visits daily/weekly; professional intermediary model. Fund sizes from NGN 5K-50K/week (traders) to NGN 100K-1M+/month (professional groups)
- **Digital tools**: AjoMoney digitizes ROSCA for MSMEs and corporate employees
- **Mobile money**: Fragmented — MoMo PSB (MTN), OPay, PalmPay, Kuda. Lower penetration than East Africa due to bank-led regulation
- **Lending**: FairMoney (up to NGN 5M SME loans, 10M+ downloads), Branch (NGN 2K-500K), Carbon. 438 approved digital lenders (Nov 2025). Some charge up to 198% APR
- **Cross-border**: US-Nigeria is SSA's largest corridor at $21B (2024). 2.29% fee on $500

#### Ghana — Susu Formalization

- **Scale**: ~15% of adults still rely on susu collectors. Bank of Ghana formalized sector in 2011 (Tier 4 regulations)
- **Digital tools**: SusuPaa (online payments, automated cycles, WhatsApp/SMS reminders), Pesewa Susu (MTN + Republic Bank auto-sweep from MoMo)
- **Mobile money**: MTN MoMo dominant. Five merchant tiers (Nano to Platinum). Transfer fees: 0.5% (GHC 1-50); 1% (above GHC 50)
- **Gender**: 36% of women now save formally (nearly doubled since 2021), but men still 7 points ahead
- **Cross-border**: MTN MoMo NOT licensed for cross-border to Nigeria. BrijX pilot (Feb 2025) tests GHC-NGN swaps

#### South Africa — Stokvel Sophistication

- **Scale**: 810,000+ stokvels, 11.5M members, R50B+ ($2.7B)/year. FNB stokvel deposits surged 66% to R13.3B (Dec 2024). Digital stokvel savings grew 84% to R10.7B
- **Digital tools**: StokFella (400+ groups, WhatsApp assistant "Nomsa"), FNB/Nedbank fee-free digital stokvel accounts with governance features
- **Multi-sig**: 2-3 signatories for bank withdrawals. Banks offer built-in governance: contribution tracking, payout scheduling, multi-approval
- **Lending**: National Credit Act caps — 5%/month micro loans (first), 3%/month subsequent; 11.25% prescribed rate (Jan 2025). 1,500+ registered micro-lenders
- **Evolution**: Stokvels expanding into shares, unit trusts, and business ventures

#### Tanzania — VICOBA + Mobile Money Boom

- **Model**: VICOBA (Village Community Banks) — 25-30 members, 12-month cycles, weekly savings, loans from pool, ~70% women
- **Digital tools**: M-Koba (Tanzania Commercial Bank + Vodacom M-Pesa) digitizes VICOBA with family/friends and formal group accounts
- **Mobile money**: $80B (2024), projected $221B by 2033. Transactions grew 26.73% to 6.41B in 2024. **77% via USSD**
- **Cross-border**: Rwanda-Tanzania pilot (Nov 2025) linking national payment switches

#### Uganda — VSLA + SACCO Explosion

- **Model**: VSLA (CARE International methodology) — weekly savings + social fund for emergencies
- **Mobile money**: MTN MoMo dominant. Cross-border to Kenya, Rwanda, Tanzania, Burundi operational since 2015-2019
- **SACCOs**: From ~4,000 (2015) to 30,000+ (March 2025). Massive digitization opportunity

#### Rwanda — Ikimina Formalization

- **Scale**: ~40% of adults in informal savings groups (ibimina). 416 Umurenge SACCOs (within 5km of 90%+ of population), though membership dropped from 36% to 28% as mobile money grew
- **Key development**: Equity Bank Ikimina Account (Dec 2025) — up to 7% p.a. interest, loans at 30% of savings as collateral, unlimited withdrawals, no maintenance fees
- **Mobile money**: 77% of adults have registered wallets (~6.9M). 86% have used mobile money. Gender gap closing
- **Digitization**: 416 SACCOs in final stages of full digitization (delayed 15+ years)

#### Senegal — Tontine + Wave Economy

- **Scale**: ~$200M/year in tontine value. 30M women save $3B annually through tontines across West Africa
- **Digital tools**: MaTontine (since 2015, builds credit scores), Maman Tontine (Wave + Orange Money, operates in 4 countries)
- **Mobile money**: 90%+ of adults own a wallet vs. 26% with bank accounts. Wave dominates. New mobile money tax debated (2025)
- **BCEAO**: Key rate 3.25%. E-money issuers CANNOT offer credit or pay interest. Instant payment system (PI-SPI) live Sept 2025 across 8 WAEMU nations

#### Ivory Coast — Orange Money Pioneer

- **First Orange Money market** (2008). Tontines pervasive — COCOVICO cooperative used tontine savings for 200 shops + 700 stalls
- **Digital tools**: Maman Tontine, Tontiin with Orange Money and Wave integration
- **BCEAO licensing deadline**: August 31, 2025 for all payment providers

#### Egypt — Digital Gameya at Scale

- **Digital tools**: MoneyFellows (2M+ savings circles, $1.5B in transactions, profitable), Tahweesha, ElGameya
- **Mobile money**: Vodafone Cash (14M active users, 65% e-wallet share), Fawry (6M+ daily transactions, 370K agents), InstaPay (EGP 112.7B/$3.65B in year one, 70% outside banking hours)
- **Market**: $14.2B (2024), projected $32.8B by 2032. 50%+ unbanked. CBE Fintech Sandbox active
- **MNT-Halan**: Egypt's largest non-bank lender targeting unbanked/underbanked

#### Ethiopia — eQUB Growth

- **Digital tools**: eQUB (registered 2020, 2.0 launched 2024) — English + 4 local languages, automatic record-keeping, merchant partnerships (Dodai EVs). Seqela enables equb payouts as in-kind purchases
- **Scale**: Monthly savings exceed 8 figures in ETB. 20-25% month-over-month growth. Pan-African expansion planned (susu, esusu variants)

#### Cameroon — Njangi Digital

- **Digital tools**: Tontiin digitizes njangi with MTN MoMo + Orange Money integration — payment tracking, mobile money disbursement, emergency loans after 4 contributions
- **MTN MoMo**: 5M+ active users, 13M accounts across Central Africa. Transfer fee: 0.5% (max 500 FCFA). Withdrawal: 2% (max 3,500 FCFA)

### Cross-Cutting Treasury Patterns

#### Pattern 1: Multi-Sig Maps to DAO Multi-Sig

Every market has evolved multi-approval spending controls that map directly to Gnosis Safe:

| Market       | Traditional Pattern                             | Digital Equivalent                         |
| ------------ | ----------------------------------------------- | ------------------------------------------ |
| Kenya        | 3 SACCO signatories (Chair/Treasurer/Secretary) | ChamaPesa group admin approvals            |
| South Africa | 2-3 stokvel signatories for withdrawals         | FNB/Nedbank digital stokvel approval flows |
| Rwanda       | Elected officials + neighbor guarantees         | Equity Ikimina Account group controls      |
| West Africa  | Tontine president + treasurer                   | Tontiin/MaTontine admin approvals          |

#### Pattern 2: Rotating vs. Accumulating Treasury Models

| Model                         | How It Works                                                | DAO Parallel                                |
| ----------------------------- | ----------------------------------------------------------- | ------------------------------------------- |
| **Rotating (Merry-Go-Round)** | Fixed contributions, members take turns receiving pot       | Round-robin grants/bounties                 |
| **Accumulating (Investment)** | Pool contributions, invest collectively, share at cycle end | Treasury that deploys capital via proposals |
| **Hybrid**                    | Core savings + emergency/social fund                        | Operating treasury + emergency reserve      |

Most groups use **12-month cycles** with end-of-cycle distribution — natural fit for DAO epoch-based treasury management.

#### Pattern 3: Cross-Border Treasury Movement

**Costs remain high**: Sub-Saharan Africa averages **8.78% for $200** (Q1 2025), vs. 3% SDG target.

**Emerging infrastructure**:

- **PAPSS**: 19 countries, 150+ banks, 14 payment switches. PAPSSCard (June 2025), African Currency Marketplace (July 2025). Projected to save **$5B/year**
- **EAC masterplan** (May 2025): Rwanda-Tanzania pilot linking national payment switches
- **BCEAO PI-SPI**: Live September 2025 across 8 WAEMU nations
- **East Africa cross-border**: $329B (2025), projected $1T by 2035

**DAO relevance**: Cross-border operations face 5-20% friction costs. Stablecoin rails offer genuine cost advantage, especially for intra-African transfers.

#### Pattern 4: Interest Rate Landscape

| Jurisdiction        | Key Rate / Cap                                                | Impact on DAO Lending                  |
| ------------------- | ------------------------------------------------------------- | -------------------------------------- |
| WAEMU (8 countries) | 3.25% key rate; EMIs cannot lend or pay interest              | Must partner with licensed entities    |
| Kenya               | No statutory cap (repealed 2019); digital lenders unregulated | Flexible but reputational risk         |
| Nigeria             | FCCPC monitoring; fines up to NGN 100M                        | New 2025 regulations require licensing |
| South Africa        | NCA: 5%/month micro, 11.25% prescribed rate                   | Strict consumer protection             |
| Egypt               | CBE sandbox; no specific mobile lending cap                   | Innovation-friendly but evolving       |

### Key Treasury Numbers

| Metric                                    | Value                             |
| ----------------------------------------- | --------------------------------- |
| South Africa stokvel deposits (FNB, 2024) | R13.3 billion                     |
| Kenya M-Pesa business payments (FY2025)   | KES 1.974T ($15.2B)               |
| West Africa tontine volume (women)        | $3B/year, 30M women               |
| Kenya Fuliza disbursements (total)        | KES 2.9T ($22.4B)                 |
| Africa remittances (2024)                 | $96.4 billion                     |
| SSA remittance cost (Q1 2025)             | 8.78% avg for $200                |
| PAPSS projected savings                   | $5B/year                          |
| Rwanda mobile money wallets               | 77% of adults                     |
| Egypt mobile payments market              | $14.2B (2024) → $32.8B (2032)     |
| Tanzania mobile money market              | $80B (2024) → $221B (2033)        |
| Orange Money monthly active users         | 34 million                        |
| WAEMU financial inclusion                 | 72.3% (2023, up from 47% in 2016) |

### Sources — Treasury & Collective Funds

- [Moneyweb - FNB Stokvel Deposits](https://www.moneyweb.co.za/news/companies-and-deals/fnb-stokvel-deposits-soar-to-r13-3bn/)
- [M-Pesa Charges](https://mpesa.co.ke/mpesa-charges)
- [TechCabal - Fuliza M-Shwari Lending](https://techcabal.com/2025/05/27/fuliza-m-shwari-ncba-digital-lending-7-7-billion/)
- [World Bank - Remittance Flows 2024](https://blogs.worldbank.org/en/peoplemove/in-2024--remittance-flows-to-low--and-middle-income-countries-ar)
- [World Bank RPW - Remittance Costs](https://remittanceprices.worldbank.org/sites/default/files/rpw_main_report_and_annex_q224.pdf)
- [African Business - PAPSS Network](https://african.business/2025/11/african-banker/africas-payment-revolution-papss-network-expands-powering-continental-trade-dream)
- [D+C - Tontines](https://www.dandc.eu/en/article/self-organised-savings-communities-tontines-are-example-economic-social-and-cultural)
- [ITC - eQUB](https://www.intracen.org/news-and-events/news/equb-brings-ethiopias-traditional-saving-system-into-the-digital-age)
- [MaTontine - Amarante](https://amaranteconsulting.com/en/matontine-digitizing-traditional-savings-groups-for-financial-inclusion/)
- [FinDev Gateway - Rwanda Mobile Money](https://www.findevgateway.org/blog/2025/07/closing-of-mobile-money-gender-gap-in-rwanda)
- [Equity Bank Ikimina Account](https://allafrica.com/stories/202512150221.html)
- [IMARC - Tanzania Mobile Money](https://www.imarcgroup.com/tanzania-mobile-money-market)

---

## Education & DAO Onboarding Patterns

### Per-Market Education Profiles

#### Kenya

**Digital Literacy**: 53% internet penetration, M-Pesa literacy near-universal (96% of adults have used mobile money). Smartphone adoption ~62%. Urban populations comfortable with complex apps; rural users rely on USSD and SMS.

**Financial Literacy**: Chama culture provides pre-existing understanding of group governance, contributions, and shared treasuries. Kenya's Capital Markets Authority and FSD Kenya run literacy programs. Concepts of savings, lending, and group decision-making widely understood.

**Effective Teaching Modalities**: WhatsApp-based learning (dominant), short video (YouTube/TikTok), community workshops through chama networks, church-based groups, FM radio for rural reach.

**Analogies That Work**:

- Treasury -> **"Chama account"** / "Group M-Pesa"
- Multi-sig -> **"Three signatories"** (chamas already require this for bank withdrawals)
- Proposals -> **"Agenda item at the meeting"** / "Motion"
- Voting -> **"Show of hands"** / "Secret ballot"
- Smart contracts -> **"Chama constitution"** / "Group bylaws"
- Token -> **"Membership card"**

**Content Tiers**:

- Tier 1 (Nairobi, Mombasa): Full web app, video onboarding
- Tier 2 (county capitals): Lite app, WhatsApp guides
- Tier 3 (rural): USSD flows, SMS, community radio
- Tier 4 (remote): Agent-assisted through chama leaders

**Language**: English (official), Swahili (national). UI in English; Swahili for mass-market onboarding.

#### Nigeria

**Digital Literacy**: 55% internet penetration but highly concentrated in Lagos, Abuja, and southern cities. OPay, PalmPay, and MTN MoMo driving digital financial inclusion. Young population (median age 18) with strong social media adoption.

**Financial Literacy**: Esusu/Ajo/Adashe traditions provide group savings understanding. Cooperative societies formalized. High crypto awareness (ranked #6 globally for adoption) but deep distrust due to Ponzi schemes (MMM Nigeria collapse affected millions).

**Effective Teaching Modalities**: WhatsApp + short video (TikTok, YouTube). Twitter/X Spaces for tech-savvy users. Community workshops through churches, cooperatives, and market associations. Nigerian Pidgin reaches ~75M speakers -- critical for mass adoption.

**Analogies That Work**:

- Treasury -> **"Esusu fund"** / "Ajo money"
- Multi-sig -> **"Three officers must sign"** (cooperative standard)
- Proposals -> **"Item on the agenda"** / "Motion at meeting"
- Voting -> **"Casting your vote"** / "Raise your hand"
- Smart contracts -> **"Society constitution"** / "Rules wey everybody agree"
- Token -> **"Membership ID"** / "Share certificate"

**Critical**: Avoid ANY language that sounds like crypto investment returns or "passive income." The Ponzi scheme association will kill trust immediately.

**Language**: English (official), Nigerian Pidgin (~75M speakers -- critical for mass adoption), Yoruba, Igbo, Hausa.

#### Ghana

**Digital Literacy**: Moderate-high in urban areas. MTN MoMo widely adopted (~17M active accounts for ~32M population). Smartphone penetration ~58%. Preference for simplicity; complex registration flows cause abandonment.

**Financial Literacy**: Strong Susu tradition (daily collection by Susu collectors). Credit unions popular. Group savings deeply understood.

**Analogies That Work**:

- Treasury -> **"Susu box"** / "Group contributions"
- Multi-sig -> **"Executive committee approval"** (church and association standard)
- Proposals -> **"Matter arising"** (standard AGM language)
- Smart contracts -> **"Club constitution"**

**Language**: English (official), Twi/Akan (~50% of population). UI in English; Twi for mass-market.

#### South Africa

**Digital Literacy**: Highest smartphone penetration in SSA (~80%). Strong app culture. Banking apps (Capitec, FNB) have millions of users. However, extreme inequality means significant rural/township segments have limited digital skills. Load shedding (power cuts) disrupts connectivity.

**Financial Literacy**: Mixed. Stokvels are massive -- estimated 800,000+ managing ~R50B (~$2.7B). Strong parliamentary tradition means governance concepts are familiar.

**Analogies That Work**:

- Treasury -> **"Stokvel pool"** / "Society fund"
- Multi-sig -> **"Three signatories"** (stokvels already require this for bank withdrawals)
- Proposals -> **"Point of order"** / "Motion" (parliamentary language)
- Voting -> **"Secret ballot"** (strong democratic culture)

**Language**: English (business), IsiZulu (~25%), IsiXhosa (~16%), Afrikaans (~13%). UI in English; onboarding in English, IsiZulu, IsiXhosa.

#### Tanzania

**Digital Literacy**: M-Pesa and Tigo Pesa widely adopted. Smartphone penetration ~35%. USSD is primary digital financial tool. Swahili-first -- English content fails outside educated urban elite.

**Financial Literacy**: ~11,000 registered cooperatives. VICOBA (Village Community Banks) and SACCOS widespread. Group savings governance deeply familiar.

**Analogies That Work** (Swahili):

- Treasury -> **"Mfuko wa kikundi"** (group fund)
- Multi-sig -> **"Wasaini watatu"** (three signatories)
- Proposals -> **"Hoja"** (motion) / "Ajenda ya mkutano" (meeting agenda item)
- Smart contracts -> **"Katiba ya kikundi"** (group constitution)

**Language**: Swahili (national, ~95% speak it). UI MUST have Swahili as primary option.

#### Uganda

**Digital Literacy**: Moderate. Mobile money widely used. Smartphone penetration ~30%. Young, tech-curious population but infrastructure limits access.

**Financial Literacy**: Strong VSLA culture. VSLAs operate in virtually every community with well-understood governance: elected leaders, contribution schedules, loan committees, transparent fund management.

**Best Analogy in All of Africa**: **VSLA "three keys to the lockbox" -> multi-sig**. VSLAs literally use a locked box with 3 keys held by different members -- this is a PERFECT analogy for multi-sig wallets.

**Analogies That Work**:

- Treasury -> **"VSLA box"** / "Group savings box"
- Multi-sig -> **"Three keys to the box"** (VSLA standard -- the single best multi-sig analogy found across all markets)
- Proposals -> **"Request to the group"** / "Agenda point"
- Smart contracts -> **"Group bylaws"** (every VSLA has written bylaws)

**Language**: English (official), Luganda (central region), Swahili (growing).

#### Rwanda

**Digital Literacy**: Aggressive government digitalization (Irembo platform). Smartphone ~38%. Internet concentrated in Kigali.

**Financial Literacy**: Government-mandated Umurenge SACCOs (one per sector). Tontines (Ibimina) common.

**Unique Onboarding Channel**: **Umuganda** (mandatory monthly community service days) provides a ready-made workshop channel.

**Analogies That Work** (Kinyarwanda):

- Treasury -> **"Ikimina"** (tontine fund)
- Multi-sig -> **"Abakozi batatu basinyisha"** (three officers must sign)
- Smart contracts -> **"Amategeko y'itsinda"** (group rules)

**Language**: Kinyarwanda (national, ~99% speak it). Rwanda is unusually linguistically homogeneous -- simplifies localization.

#### Senegal

**Digital Literacy**: ~50% internet penetration. Orange Money dominant. Vibrant Dakar startup scene. French-first.

**Financial Literacy**: Strong Tontine tradition (called "Natt" or "Mbotaay" in Wolof). Women-led tontines are economic pillars.

**Analogies That Work** (Wolof/French):

- Treasury -> **"Caisse du natt"** / "Caisse commune"
- Multi-sig -> **"Trois signatures obligatoires"**
- Smart contracts -> **"Reglement interieur"** (internal rules)

**Language**: French (official, required for UI), Wolof (~80% speak it). UI MUST be in French.

#### Ivory Coast

Similar to Senegal. Tontine culture strong. Agricultural cooperative networks (cocoa) as distribution channel. French-first. Dioula/Bambara for wider reach.

#### Egypt

**Digital Literacy**: High urban literacy. ~50M internet users. Fintech growing (Fawry, InstaPay). Government regulatory environment creates caution around anything crypto-adjacent.

**Financial Literacy**: Gameya (rotating savings) widely practiced. Professional syndicates (engineers, doctors, lawyers) have sophisticated governance.

**Analogies That Work** (Arabic):

- Treasury -> **"Sandouq al-gameya"** (association fund)
- Multi-sig -> **"Tawqi'at muta'addida"** (multiple signatures)
- Smart contracts -> **"La'iha dakhiliya"** (internal bylaws)

**Language**: **Arabic (Egyptian dialect) is mandatory.** First market requiring **RTL support** in UI.

#### Ethiopia

**Digital Literacy**: ~25% internet penetration but growing fast (telecom liberalization). Telebirr growing. Smartphone ~25%.

**Financial Literacy**: Strong Iqub and Idir traditions. Idir governance maps almost perfectly to DAO governance: elected leaders, bylaws, regular meetings, fund management, dispute resolution.

**Unique**: Telegram is dominant communication platform (estimated 30M+ users -- more than any other African country).

**Analogies That Work** (Amharic):

- Treasury -> **"Ye-Iqub genzeb"** (Iqub money) / **"Ye-Idir satin"** (Idir box)
- Multi-sig -> **"Sost firma"** (three signatures -- Idirs require this)
- Smart contracts -> **"Ye-Idir hig"** (Idir rules)

**Language**: Amharic (official), Afaan Oromo (~35%). **Amharic requires Ge'ez script support** -- unique requirement. Consider Telegram as primary onboarding channel.

#### Cameroon

**Digital Literacy**: Moderate. Bilingual (French/English) creating unique challenges. Political tension between Anglophone/Francophone regions affects platform perception.

**Financial Literacy**: Njangi tradition extremely strong with formalized governance (president, secretary, treasurer, written rules).

**Analogies That Work**:

- Treasury -> **"Njangi fund"** / "Caisse du njangi"
- Multi-sig -> **"The three executives must sign"**
- Smart contracts -> **"Njangi rules"** / "Reglement du njangi"

**Language**: French (~80%), English (Anglophone ~20%), Cameroon Pidgin. UI in both French and English. Sensitivity required: allow user choice upfront, do not default by region.

---

### Cross-Cutting Onboarding Patterns

#### The Universal Analogy: Savings Groups = DAOs

Across ALL 12 markets, savings group governance maps directly to DAO concepts:

| Market       | Local Term   | Key Governance Feature                            |
| ------------ | ------------ | ------------------------------------------------- |
| Kenya        | Chama        | Constitution, officers, regular meetings          |
| Nigeria      | Esusu/Ajo    | Rotating credit, collective accountability        |
| Ghana        | Susu         | Daily collections, discipline                     |
| South Africa | Stokvel      | Multiple signatories, transparent fund management |
| Tanzania     | VICOBA       | Village banking, group lending                    |
| Uganda       | VSLA         | **Three-key lockbox** (perfect multi-sig)         |
| Rwanda       | Ikimina      | Structured tontine, government SACCOs             |
| Senegal      | Natt/Tontine | Women-led, deeply social                          |
| Ivory Coast  | Tontine      | Agricultural cooperative governance               |
| Egypt        | Gameya       | Rotating credit                                   |
| Ethiopia     | Iqub/Idir    | Full governance (bylaws, elections, disputes)     |
| Cameroon     | Njangi       | Formalized governance with written rules          |

**EnDAO's onboarding lead message: "You already know how to run a DAO. You've been doing it."**

#### Recommended Onboarding Flow

1. **Recognition** (30 seconds): "Do you participate in a [Chama/Stokvel/Njangi/etc.]? EnDAO is the digital version."
2. **Mapping** (2 minutes): Visual showing local savings group concepts mapped to EnDAO features using local terminology.
3. **Guided First Action** (5 minutes): Create or join a group. Low-stakes, immediately valuable.
4. **Progressive Disclosure**: Introduce treasury, proposals, voting only after user has group and members. Never front-load.

#### Language & Localization Priority

**Phase 1 (Launch)**: English, French, Arabic + RTL
**Phase 2 (Scale)**: Swahili, Nigerian Pidgin, Amharic + Ge'ez, Kinyarwanda
**Phase 3 (Deep Penetration)**: IsiZulu, IsiXhosa, Wolof, Luganda, Afaan Oromo

#### Connectivity-Adaptive Content Strategy

| Tier                     | Users | Primary Channel     | EnDAO Strategy                           |
| ------------------------ | ----- | ------------------- | ---------------------------------------- |
| Tier 1 (Urban broadband) | ~30%  | Web app             | Standard web onboarding, video           |
| Tier 2 (3G/4G)           | ~35%  | WhatsApp + Lite app | WhatsApp onboarding bot, PWA             |
| Tier 3 (2G/intermittent) | ~25%  | SMS + USSD          | SMS 7-day drip course, USSD companion    |
| Tier 4 (Offline)         | ~10%  | Agent/community     | Train-the-trainer kits for group leaders |

#### Content Channel Ranking by Market

| Market       | #1 Channel       | #2 Channel              |              #3 Channel |
| ------------ | ---------------- | ----------------------- | ----------------------: |
| Kenya        | WhatsApp         | Short video             |     Community workshops |
| Nigeria      | WhatsApp + video | Twitter/X Spaces        |        Church workshops |
| Ghana        | WhatsApp         | Community radio         |               Workshops |
| South Africa | YouTube          | WhatsApp                |        Stokvel meetings |
| Tanzania     | Radio            | WhatsApp                |        SACCOS workshops |
| Uganda       | VSLA meetings    | WhatsApp                |                   Radio |
| Rwanda       | WhatsApp         | Umuganda workshops      |                   Radio |
| Senegal      | WhatsApp         | Community radio (Wolof) |          Women's groups |
| Ivory Coast  | WhatsApp         | Facebook                |    Cooperative meetings |
| Egypt        | YouTube/Facebook | WhatsApp                | Professional syndicates |
| Ethiopia     | **Telegram**     | Radio                   |      Idir/Iqub meetings |
| Cameroon     | WhatsApp         | YouTube                 |         Njangi meetings |

#### Trust-Building for Crypto-Skeptic Users

1. **Never lead with blockchain/crypto**: Lead with the problem ("Managing your group's money more transparently")
2. **Use institutional language**: "Digital governance platform" not "DAO tool." "Shared treasury" not "smart contract wallet"
3. **Show familiar faces**: Testimonials from local group leaders, not crypto influencers
4. **Demonstrate before explaining**: Let users see a working group before explaining how it works
5. **Anchor to existing trust**: Partner with cooperatives, churches, professional associations
6. **Transparent about what it is NOT**: "This is not an investment platform. This is a management tool."
7. **Offline-first credibility**: Support phone number, physical events, local organization partnerships

#### Implementation Recommendations

**Immediate (No Code Changes)**:

- Market-specific onboarding scripts using analogies above
- WhatsApp-shareable image guides (<500KB) in English, French, Arabic
- "You Already Know DAOs" content series per market

**Short-Term (UI/UX)**:

- Phone-number-first authentication (email is a barrier)
- Progressive disclosure: hide advanced features until group established
- Connectivity detection with auto-switch to low-bandwidth mode
- WhatsApp onboarding bot for group creation

**Medium-Term (Architecture)**:

- RTL support for Arabic (Egypt)
- i18n framework supporting Ge'ez script (Ethiopia)
- Offline-capable PWA for Tier 3 users
- USSD companion interface for Tier 3/4
- SMS notification fallback

**Long-Term (Ecosystem)**:

- Train-the-trainer program targeting savings group leaders
- Partnership with cooperative apex bodies per market
- Local language content creation program
- Agent network (M-Pesa agent model) for in-person support

### Sources

- GSMA State of the Industry 2024, Digital Inclusion reports
- FSD Africa Group Savings Studies 2023
- World Bank Findex 2021/2024
- Chainalysis Geography of Cryptocurrency Report 2024
- DataReportal Digital 2024 country reports
- CGAP Savings Groups and Cooperative research
- National cooperative registries (Kenya, Tanzania, Rwanda)
- MoneyFellows (Egypt) public data

---

## Regulatory & Compliance Deep Dive

### Per-Market Regulatory Profiles

#### Kenya

**Data Protection**: Data Protection Act 2019. ODPC (Office of Data Protection Commissioner) active. Cross-border transfers require adequate protection (ODPC whitelist). Penalties up to KES 5M ($38k) or 1% of annual turnover.

**Crypto/Blockchain**: Legal but unregulated. CBK cautionary notices (2015, 2018) but no ban. Capital Markets Act review underway for crypto framework. Kenya's regulatory sandbox available (CMA/CBK). Most crypto-friendly Tier 1 market.

**Fintech Licensing**: PSP license from CBK under National Payment Systems Act 2011. E-money issuer license required for custodial services. Capital requirements: KES 50-300M; timeline: 6-18 months. CBK Regulatory Sandbox operational.

**Cooperative/Association Law**: Co-operative Societies Act (Cap 490). ~24,000 registered cooperatives. Chama Investment Association provides registration framework. SACCOs regulated by SASRA. DAO mapping: Cooperative society or investment group registration.

**AML/CFT**: Proceeds of Crime and Anti-Money Laundering Act 2009. FRC (Financial Reporting Centre) active. Not on FATF gray list.

#### Nigeria

**Data Protection**: Nigeria Data Protection Act (NDPA) 2023, replaced NDPR 2019. NDPC (Nigeria Data Protection Commission) enforcement increasing. **Data localization mandatory** -- personal data of Nigerian citizens must be stored in-country. Penalties up to 2% of annual gross revenue or NGN 10M.

**Crypto/Blockchain**: Legal & regulated (2024). CBN lifted bank ban Dec 2023. SEC VASP licensing framework operative June 2024 (Busha, Quidax licensed). eNaira CBDC launched Oct 2021 (low adoption). CGT 10% on crypto gains.

**Fintech Licensing**: CBN PSP/PSSP licensing. SEC VASP license for crypto. Capital requirements substantial (NGN 2-5B for PSP). Multiple regulatory bodies (CBN, SEC, FCCPC). Timeline: 12-24 months.

**Cooperative/Association Law**: Cooperative Societies Act (varies by state). Companies and Allied Matters Act (CAMA) 2020 allows incorporated trustees. Strong cooperative movement, especially in southwest.

**AML/CFT**: Money Laundering (Prevention and Prohibition) Act 2022. NFIU (Nigerian Financial Intelligence Unit) active. FATF gray list status (since 2023) -- significant implications for international banking.

#### Ghana

**Data Protection**: Data Protection Act 2012 (Act 843). Data Protection Commission established. Penalties relatively low (GH₵6,000 / ~$400) -- under review for increase. Cross-border transfers require adequate protection.

**Crypto/Blockchain**: Legal but unregulated. BOG cautionary (2018). SEC exploring licensing framework via sandbox. e-Cedi CBDC pilot (2022-2024). No specific crypto tax law.

**Fintech Licensing**: BoG Regulatory and Innovation Sandbox operational since 2021. E-money issuer or PSP license required. Capital: GHS 2-5M; timeline: 6-18 months.

**Cooperative/Association Law**: Co-operative Societies Act 1968 (NLCD 252). Companies Act 2019 allows companies limited by guarantee. Susu collector registration available for smaller groups.

**AML/CFT**: Anti-Money Laundering Act 2020 (Act 1044). FIC active. Not on FATF gray list. Member of GIABA.

#### South Africa

**Data Protection**: **POPIA** -- most mature data protection regime in Africa. Fully enforced July 2021. Information Regulator active, has issued enforcement notices. Penalties up to ZAR 10M ($550k) and/or imprisonment. Modeled on GDPR principles.

**Crypto/Blockchain**: **Most advanced crypto regulatory framework in Africa.** FSCA declared crypto assets as financial products (Oct 2022). CASPs must be licensed as FSPs under FAIS Act. 60+ CASPs licensed. CGT 18-45%. Clear licensing path -- EnDAO should engage FSCA early.

**Fintech Licensing**: FSP license under FAIS Act for crypto. National Payment System Act registration for fiat payments. IFWG innovation hub available as sandbox. Capital: ZAR 50k-1M; timeline: 6-12 months.

**Cooperative/Association Law**: Co-operatives Act 2005. 800,000+ stokvels via NASASA. Non-Profit Company (NPC) under Companies Act 2008. Strong governance mandates (AGMs, audited accounts).

**AML/CFT**: FICA (Financial Intelligence Centre Act 2001). CASPs are accountable institutions. South Africa was on FATF gray list Feb 2023 - early 2025. Enhanced due diligence applied.

#### Tanzania

**Data Protection**: Personal Data Protection Act 2022 (Act No. 11). **Data localization required** for certain categories. Penalties up to TZS 100M (~$38k). New law, enforcement still being established.

**Crypto/Blockchain**: BOT warned against crypto (2019). Not explicitly banned but discouraged. No framework. President Samia has signaled openness to blockchain but regulatory framework lags.

**Fintech Licensing**: National Payment Systems Act 2015. BoT licenses PSPs. Capital: TZS 1-5B; timeline: 12-24 months.

**Cooperative/Association Law**: Cooperative Societies Act 2003. ~5,000+ SACCOS. VICOBA widespread. SACCOS registration natural fit for community DAOs.

**AML/CFT**: Anti-Money Laundering Act 2006. Was on FATF gray list 2022-early 2024.

**Platform Regulation**: Online Content Regulations 2020 require registration of online content providers. May apply to EnDAO.

#### Uganda

**Data Protection**: Data Protection and Privacy Act 2019. PDPO under NITA-U. Limited enforcement capacity. Penalties up to UGX 4.8M (~$1,300).

**Crypto/Blockchain**: Not banned, not regulated. BOU cautious but engaged. Blockchain Association of Uganda active. Regulatory vacuum allows early entry with self-regulation.

**Fintech Licensing**: National Payment Systems Act 2020. BoU licenses. Capital: UGX 500M-2B.

**Cooperative/Association Law**: Cooperative Societies Act (Cap 112). VSLAs extremely widespread, often unregistered -- direct analog to small community DAOs.

**AML/CFT**: Anti-Money Laundering Act 2013. Not on FATF gray list.

#### Rwanda

**Data Protection**: Law No. 058/2021. NCSA (National Cyber Security Authority) handles enforcement. Government/critical data must be stored domestically. Penalties up to RWF 5M (~$4,500) or 5% of turnover. Strong governance institutions.

**Crypto/Blockchain**: Not explicitly regulated. BNR cautious but KIFC (Kigali International Financial Centre) positioned as regional fintech hub with interest in digital assets. Engage KIFC and BNR.

**Fintech Licensing**: Law No. 044/2023 on Payment Systems. BNR licenses. Rwanda has one of the fastest business registration processes in Africa. Timeline: 6-12 months.

**Cooperative/Association Law**: Law No. 50/2007 on Cooperatives. Rwanda Cooperative Agency (RCA). Modernized cooperative laws, tech-forward.

**AML/CFT**: Law No. 032/2008. Not on FATF gray list. Proactive on compliance.

#### Senegal (WAEMU/BCEAO Framework)

**Data Protection**: Loi n° 2008-12. CDP (Commission de Protection des Donnees Personnelles). Cross-border transfers need CDP authorization. Penalties up to FCFA 100M (~$160k).

**Crypto/Blockchain**: BCEAO declared crypto not legal tender (2017). Not explicitly banned. No national or WAEMU-level exchange licensing. Regulation will likely come at WAEMU level.

**Fintech Licensing**: BCEAO Instruction No. 008-05-2015 governs e-money in WAEMU. License from BCEAO required. Capital: FCFA 300M-1B; timeline: 12-24 months. **A BCEAO license covers all 8 WAEMU countries.**

**Cooperative/Association Law**: **OHADA Uniform Act on Cooperatives (2010)** -- single legal framework across **17 francophone African countries**. Major advantage for pan-francophone deployment.

**AML/CFT**: WAEMU AML/CFT Directive. **Senegal is on FATF gray list (since 2021)** -- significant compliance implications.

#### Ivory Coast

Same BCEAO/WAEMU and OHADA frameworks as Senegal. ARTCI handles data protection (Law No. 2013-450). Not on FATF gray list. Growing tech ecosystem in Abidjan.

#### Egypt

**Data Protection**: Personal Data Protection Law No. 151/2020. DPC not yet fully operational. **Significant cross-border restrictions** -- transfers need regulator approval. Data localization for sensitive data. Penalties up to EGP 5M (~$100k) and imprisonment.

**Crypto/Blockchain**: **BANNED.** CBE Banking Law No. 194/2020 (Article 206) criminalizes creating, promoting, or operating crypto platforms. One of the strictest anti-crypto positions in Africa. **EnDAO must operate fiat-only in Egypt.**

**Fintech Licensing**: CBE PSP license or FRA license. CBE Regulatory Sandbox since 2019. Meeza national payment scheme. Capital requirements substantial; timeline: 12-24 months.

**Cooperative/Association Law**: Law No. 110/1975 on Cooperatives. **Law No. 149/2019 on NGOs is highly restrictive** -- foreign funding heavily scrutinized. Local partnership essential.

**AML/CFT**: Anti-Money Laundering Law No. 80/2002. Under MENAFATF evaluation.

**Platform Regulation**: Extensive regulation including Cybercrime Law No. 175/2018. Significant compliance burden.

#### Ethiopia

**Data Protection**: **No comprehensive law** as of early 2025. Draft under discussion. Rely on constitutional privacy rights (Article 26) and contractual safeguards.

**Crypto/Blockchain**: **BANNED.** NBE Proclamation No. 1293/2023 prohibits trading, holding, or transacting in crypto. Criminal penalties. **EnDAO must operate fiat-only.**

**Fintech Licensing**: NBE licenses under National Payment System Proclamation. Foreign ownership restrictions in financial services. Challenging regulatory environment.

**Cooperative/Association Law**: Cooperative Societies Proclamation No. 985/2017. Edir and Ekub traditions have strong cultural fit. Federal Cooperative Agency oversees.

**AML/CFT**: Proclamation No. 780/2013. **On FATF gray list (since 2023).**

#### Cameroon (CEMAC/BEAC Framework)

**Data Protection**: Law No. 2024-017 (new). Enforcement infrastructure being built.

**Crypto/Blockchain**: BEAC warned against crypto for CEMAC zone. Not explicitly banned nationally. Growing crypto community despite ambiguity.

**Fintech Licensing**: BEAC Regulation No. 02/18/CEMAC governs e-money. Similar framework to WAEMU/BCEAO.

**Cooperative/Association Law**: Same OHADA framework as Senegal/Ivory Coast.

**AML/CFT**: CEMAC AML Regulation. **On FATF gray list (since 2023).**

---

### Pan-African Regulatory Strategy

#### Market Tiering

**Tier 1 -- Launch Markets** (clearest regulatory path, strongest cultural fit):

1. **Kenya**: Most crypto-friendly, chama culture, M-Pesa, sandbox available
2. **South Africa**: Most advanced regulatory framework, FSCA CASP licensing clear, stokvel culture
3. **Rwanda**: Business-friendly, fast registration, tech-forward government, KIFC hub

**Tier 2 -- Growth Markets** (large opportunity, navigable complexity): 4. **Nigeria**: Largest market by volume, SEC VASP framework emerging, enter via sandbox 5. **Ghana**: Moderate regulatory environment, BoG sandbox, e-Cedi potential 6. **Uganda**: Regulatory vacuum allows early entry with self-regulation, VSLA market large

**Tier 3 -- OHADA Zone** (unified legal framework advantage): 7. **Senegal**: BCEAO license covers WAEMU zone. OHADA cooperative law covers 17 countries 8. **Ivory Coast**: Same framework as Senegal, larger economy 9. **Cameroon**: OHADA + CEMAC framework, gateway to francophone Central Africa

**Tier 4 -- Restricted Markets** (crypto bans, fiat-only): 10. **Egypt**: Crypto banned. Large market justifies separate fiat-only strategy 11. **Ethiopia**: Crypto banned. Edir culture strong. Foreign ownership restrictions 12. **Tanzania**: Cautious environment. Enter after clearer framework emerges

#### Recommended Legal Structures

| Structure                          | Use Case                              | Jurisdictions                                |
| ---------------------------------- | ------------------------------------- | -------------------------------------------- |
| Cooperative Society                | Community groups, savings pools       | All 12 markets                               |
| OHADA Cooperative                  | Pan-francophone unified structure     | Senegal, Ivory Coast, Cameroon (+ 14 others) |
| Company Limited by Guarantee / NPC | Larger DAOs, institutional governance | Kenya, South Africa, Nigeria, Ghana          |
| SACCO                              | Financial cooperatives with lending   | Kenya, Tanzania, Uganda, Rwanda              |
| Incorporated Trustees              | Non-profit DAOs                       | Nigeria                                      |

#### Licensing Strategy

1. **Non-custodial first**: Launch with non-custodial wallet integration (users hold own keys via Safe/multi-sig). Minimizes licensing requirements.
2. **Sandbox entry**: Apply simultaneously for Kenya (CBK/CMA), Nigeria (SEC/CBN), Ghana (BoG), South Africa (IFWG).
3. **PSP licensing**: Pursue in Tier 1 markets for fiat on/off ramps.
4. **OHADA leverage**: Single OHADA cooperative registration provides legal personality across 17 francophone countries.

#### Compliance Architecture

```
┌─────────────────────────────────────────────┐
│            EnDAO Compliance Layer            │
├─────────────────────────────────────────────┤
│  KYC/CDD Module                             │
│  ├─ Tier 1: Phone + Name (low-value)        │
│  ├─ Tier 2: ID + Address (medium-value)     │
│  └─ Tier 3: Enhanced DD (high-value/PEPs)   │
├─────────────────────────────────────────────┤
│  AML Monitoring                             │
│  ├─ Transaction monitoring rules             │
│  ├─ STR auto-generation per jurisdiction     │
│  └─ FATF gray-list enhanced rules           │
│     (Nigeria, Senegal, Cameroon, Ethiopia)  │
├─────────────────────────────────────────────┤
│  Data Residency                             │
│  ├─ East Africa (Nairobi/Kigali)            │
│  ├─ West Africa (Lagos/Accra)               │
│  └─ Southern Africa (Johannesburg)          │
├─────────────────────────────────────────────┤
│  Jurisdiction Feature Flags                 │
│  ├─ Crypto features: ON/OFF per market      │
│  ├─ Egypt/Ethiopia: fiat-only mode          │
│  └─ Data localization compliance            │
└─────────────────────────────────────────────┘
```

#### Data Residency Recommendation

Deploy three regional clusters:

1. **East Africa** (Nairobi or Kigali): Kenya, Tanzania, Uganda, Rwanda, Ethiopia
2. **West Africa** (Lagos or Accra): Nigeria, Ghana, Senegal, Ivory Coast, Cameroon
3. **Southern Africa** (Johannesburg): South Africa

#### Key Risks

| Risk                         | Markets Affected                                | Mitigation                                        |
| ---------------------------- | ----------------------------------------------- | ------------------------------------------------- |
| FATF gray list               | Nigeria, Senegal, Cameroon, Ethiopia            | Enhanced due diligence, monitor FATF plenaries    |
| Crypto bans                  | Egypt, Ethiopia                                 | Fiat-only mode with jurisdiction feature flags    |
| Regulatory reversal          | Nigeria (CBN history of reversals)              | Flexible architecture, sandbox participation      |
| Association law restrictions | Egypt (foreign funding scrutiny)                | Local partnership, cooperative structure          |
| Currency controls            | Nigeria (naira), Ethiopia (birr), Egypt (pound) | Forex restrictions affect cross-border fund flows |

#### Immediate Next Steps

1. Engage local legal counsel in Kenya and South Africa for Tier 1 entry
2. Apply for regulatory sandboxes in Kenya (CMA), South Africa (IFWG), Nigeria (SEC), Ghana (BoG)
3. Implement tiered KYC aligned with mobile money tiers per market
4. Build jurisdiction configuration system enabling/disabling crypto features per market
5. Establish OHADA cooperative legal entity for francophone entry
6. Deploy regional data infrastructure per three-cluster model

### Sources

- Central bank circulars and regulations (CBK, CBN, BOG, SARB, BOT, BOU, BNR, BCEAO, BEAC, CBE, NBE)
- FATF Mutual Evaluation Reports and gray list updates 2022-2025
- DLA Piper Global Data Protection Laws of the World 2024
- UNCTAD Data Protection Legislation database
- IMF Country Reports 2024
- OHADA Uniform Act on Cooperatives (2010)
- GSMA Mobile Money Regulatory Index 2024
- National cooperative and association legislation per jurisdiction

> **Disclaimer**: This research reflects the regulatory landscape as of early 2025. Formal legal opinions from licensed practitioners in each jurisdiction are required before market entry.

---

## Strategic Answers to Key Questions

### 1. Kenya + Nigeria First: What Coverage?

**Answer:** ~40% of Sub-Saharan Africa's digital economy, but pattern BREAKS at:

| Market Type                 | Works?     | Why/Why Not                                                                    |
| --------------------------- | ---------- | ------------------------------------------------------------------------------ |
| **Ghana**                   | ✅ YES     | English, MTN MoMo (similar to Nigeria), Flutterwave/Paystack both work         |
| **South Africa**            | ⚠️ PARTIAL | English works, but BANK CARDS not mobile money, POPIA compliance required      |
| **Tanzania/Uganda/Rwanda**  | ⚠️ PARTIAL | M-Pesa/MTN MoMo work, but Paystack gap, Swahili recommended for Tanzania       |
| **Francophone West Africa** | ❌ NO      | French REQUIRED, Orange Money/Wave different from M-Pesa/MTN, Flutterwave only |
| **Egypt**                   | ❌ NO      | Arabic REQUIRED, InstaPay not mobile money, different regulatory regime        |
| **Ethiopia**                | ❌ NO      | Amharic + Ge'ez script, Telebirr monopoly, no Flutterwave/Paystack             |

**Conclusion:** Kenya + Nigeria covers Anglophone East/West Africa well, but misses:

- 21 Francophone countries (300M+ French speakers)
- Egypt/North Africa (Arabic-speaking MENA)
- Ethiopia (unique market)

---

### 2. Expansion Breakpoints

#### What Breaks: Language

| Region                                    | Language | Translation Required             | Script Issues            |
| ----------------------------------------- | -------- | -------------------------------- | ------------------------ |
| **Kenya, Nigeria, Ghana, Uganda, Rwanda** | English  | ❌ No (optional local languages) | None                     |
| **Senegal, Ivory Coast, DRC, Cameroon**   | French   | ✅ YES - MANDATORY               | None                     |
| **Egypt**                                 | Arabic   | ✅ YES - MANDATORY               | RTL (right-to-left) UI   |
| **Ethiopia**                              | Amharic  | ✅ YES - MANDATORY               | Ge'ez script (non-Latin) |

#### What Breaks: Payment Systems

| Region                       | Dominant Provider  | Flutterwave | Paystack | Alternative                    |
| ---------------------------- | ------------------ | ----------- | -------- | ------------------------------ |
| **Kenya**                    | M-Pesa             | ✅ YES      | ✅ YES   | Direct M-Pesa API              |
| **Nigeria**                  | MTN MoMo, OPay     | ✅ YES      | ✅ YES   | -                              |
| **Ghana**                    | MTN MoMo           | ✅ YES      | ✅ YES   | -                              |
| **Tanzania, Uganda, Rwanda** | M-Pesa, MTN MoMo   | ✅ YES      | ❌ NO    | Direct integrations            |
| **Senegal, Ivory Coast**     | Orange Money, Wave | ✅ YES      | ❌ NO    | Wave API, Orange Money         |
| **South Africa**             | Bank cards         | ✅ YES      | ✅ YES   | Card processors more important |
| **Egypt**                    | InstaPay, Fawry    | ❌ Unclear  | ❌ NO    | Fawry, InstaPay APIs           |
| **Ethiopia**                 | Telebirr           | ❌ NO       | ❌ NO    | Telebirr API (monopoly)        |

#### What Breaks: Regulation

| Market                   | Data Protection                   | Localization             | Complexity               |
| ------------------------ | --------------------------------- | ------------------------ | ------------------------ |
| **Kenya, Ghana, Uganda** | Moderate                          | None                     | LOW                      |
| **Nigeria**              | NDPA + GAID 2025                  | MANDATORY (data centers) | HIGH                     |
| **South Africa**         | POPIA (strictest)                 | None                     | MODERATE-HIGH            |
| **Francophone (WAEMU)**  | WAEMU-level                       | None                     | LOW                      |
| **Egypt**                | Personal Data Protection Law 2020 | None                     | MODERATE                 |
| **Ethiopia**             | Limited                           | None                     | LOW (but political risk) |

---

### 3. Flutterwave: Truly Pan-African?

**Answer:** NO - Coverage has gaps and depth varies significantly.

#### Flutterwave Coverage Analysis (2025)

**Strong Coverage (34 countries, but quality varies):**

- ✅ **Tier 1 (Deep integration):** Nigeria, Ghana, Kenya, South Africa
- ⚠️ **Tier 2 (Present but limited):** Tanzania, Uganda, Senegal, Cameroon, Zambia, Rwanda
- ❓ **Tier 3 (Unclear):** Egypt, Ethiopia - NOT explicitly mentioned

**Confirmed Gaps:**

- ❌ Ethiopia - No Flutterwave (must use Telebirr)
- ❌ Egypt - Unclear coverage, Fawry dominates
- ❌ Many Francophone Central Africa countries

**Pricing Inconsistency:**

- Nigeria: ~1.4% local (capped ₦2,000), 3.8% international
- Rwanda: 4.8% cards, 3.5% mobile money/wallets
- **Lesson:** Pricing NOT standardized; check per-country

**Conclusion:** Flutterwave is the BEST pan-African aggregator (vs Paystack's 3-4 countries), but "34 countries" is marketing. Real coverage tiers:

- **10-12 countries:** Deep, production-ready
- **15-20 countries:** Basic coverage, test first
- **Rest:** Regulatory approval ≠ functional integration

---

### 4. Minimum Payment Integrations for 80% Coverage

**Answer:** 4-5 integrations cover ~80% of Sub-Saharan Africa + North Africa

| Integration              | Coverage                             | Countries                                                                                     | % of SSA Pop                                  |
| ------------------------ | ------------------------------------ | --------------------------------------------------------------------------------------------- | --------------------------------------------- |
| **1. Flutterwave**       | Anglophone Africa + some Francophone | Nigeria, Ghana, Kenya, South Africa, Tanzania, Uganda, Rwanda, Senegal, Ivory Coast, Cameroon | ~45%                                          |
| **2. M-Pesa Direct API** | Kenya + Tanzania (Vodacom)           | Kenya, Tanzania                                                                               | ~8% (but Kenya = largest mobile money market) |
| **3. Orange Money**      | Francophone West/Central Africa      | Senegal, Ivory Coast, Mali, Guinea, DRC, Cameroon + 11 more                                   | ~20%                                          |
| **4. Telebirr**          | Ethiopia                             | Ethiopia only                                                                                 | ~8%                                           |
| **5. InstaPay/Fawry**    | Egypt                                | Egypt only                                                                                    | ~7% (but MENA gateway)                        |

**Total:** ~88% of target markets

**Alternative Minimal Set (3 integrations, ~70% coverage):**

1. **Flutterwave** - Nigeria, Ghana, Kenya, South Africa core
2. **Orange Money** - Francophone Africa
3. **Telebirr** - Ethiopia

**Recommended Production Set (6 integrations, ~95% coverage):**

1. **Flutterwave** - Primary aggregator
2. **M-Pesa Kenya Direct** - Safaricom's direct API (more reliable than aggregator)
3. **MTN MoMo API** - Direct integration for Nigeria, Ghana, Uganda, Cameroon
4. **Orange Money** - Francophone Africa
5. **Wave** - Senegal, Ivory Coast (zero fees = high adoption)
6. **Telebirr** - Ethiopia

---

### 5. Technical Infrastructure Differences

#### CDN & Edge Locations

**Supabase:**

- ❌ [No Africa edge locations](https://supabase.com/docs/guides/platform/regions)
- ❌ [South Africa (afs1) AWS region discontinued](https://github.com/orgs/supabase/discussions/2949) for new projects
- ⚠️ Nearest hop: **Europe** (full continent away)
- ⚠️ [Cold start latency: ~600ms+](https://github.com/orgs/supabase/discussions/29301), internal network latency >500ms

**Workarounds:**

- Use [Supabase Edge Functions](https://supabase.com/docs/guides/functions/regional-invocation) (global distribution, but still routes to Europe for database)
- [Storage CDN](https://supabase.com/docs/guides/storage/cdn/fundamentals) helps for assets (cached globally)
- Consider CloudFlare Workers + Supabase for Africa latency optimization

**Cloudflare (Better for Africa):**

- ✅ CDN POPs in: Johannesburg, Cape Town, Durban (South Africa), Lagos (Nigeria), Nairobi (Kenya), Cairo (Egypt), Kigali (Rwanda), Dar es Salaam (Tanzania), Kampala (Uganda), Accra (Ghana), Abidjan (Ivory Coast)
- ✅ Much better latency for API routes if using Cloudflare Workers

**AWS:**

- ✅ Cape Town region (af-south-1) exists but [not supported by Supabase for new projects](https://github.com/orgs/supabase/discussions/2949)
- If self-hosting: af-south-1 helps South Africa, but expensive

**Recommendation for EnDAO:**

- **Option 1:** Supabase Europe + Cloudflare Workers for API routes + aggressive caching
- **Option 2:** Self-host on AWS af-south-1 (Cape Town) for South Africa, Supabase Europe for rest
- **Option 3:** Multi-region: AWS af-south-1 (Southern Africa), AWS eu-west-1 (Dublin) for North/West Africa

#### API Latency Estimates (from user to Supabase Europe)

| Market                                 | Latency   | User Experience                     |
| -------------------------------------- | --------- | ----------------------------------- |
| **South Africa**                       | 180-250ms | Acceptable (geographically closest) |
| **Kenya**                              | 250-350ms | Noticeable delay on writes          |
| **Nigeria**                            | 300-400ms | Frustrating for real-time features  |
| **Egypt**                              | 100-150ms | Better (closer to Europe)           |
| **West Africa (Senegal, Ivory Coast)** | 350-450ms | Poor without caching                |

**Mobile App Optimization Needed:**

- Aggressive local caching (SQLite)
- Optimistic UI updates
- Background sync queues
- Offline-first architecture (critical for Africa)

---

### 6. Francophone Africa Gap

**Size of Gap:**

- **21 Francophone countries** in Africa (out of 55 total)
- **300M+ French speakers** (largest French-speaking population globally)
- **Key Markets:** Senegal, Ivory Coast, Cameroon, DRC, Mali, Guinea, Burkina Faso, Niger, Benin, Togo, Madagascar, Gabon, Chad, CAR, Republic of Congo, Comoros, Djibouti, Equatorial Guinea

**What Works:**
✅ Flutterwave (expanded to Senegal, Cameroon, Ivory Coast in 2025)
✅ Orange Money (dominant, 110M+ subscribers across 17 countries)
✅ MTN MoMo (strong in Cameroon, Ivory Coast)
✅ Wave (disruptor in Senegal, Ivory Coast, Cameroon - zero fees)

**What Breaks:**
❌ English-only UI - [Low English proficiency](https://www.pulse.com.gh/story/best-english-speaking-countries-africa-2026011312513213815) (Ivory Coast: 393/800, Togo: 397/800)
❌ Paystack - Not present in any Francophone country
❌ Assumptions from Anglophone Africa (Kenya patterns don't transfer)

**Unique Opportunities:**

- **CFA Franc Stability:** [XOF (West Africa) and XAF (Central Africa)](https://www.milestoneloc.com/french-speaking-countries-in-africa/) - fixed to Euro, no currency volatility like Naira/Cedi
- **Wave Disruption:** [Zero-fee model](https://triplepundit.com/2025/wave-mobile-money-cote-divoire/) = rapid adoption in Senegal/Ivory Coast - opportunity for education/SME platforms
- **WAEMU Integration:** [8-country economic union](https://www.fabs.africa/about-fabs/) (Benin, Burkina Faso, Ivory Coast, Guinea-Bissau, Mali, Niger, Senegal, Togo) = single regulatory framework

**Minimum for Francophone Success:**

1. French translation (MANDATORY - not optional)
2. Orange Money integration (dominant in 17 countries)
3. Wave integration for Senegal, Ivory Coast, Cameroon (high growth)
4. Flutterwave as backup/aggregator
5. XOF/XAF currency support

**Growth Projections:**

- [Senegal, Ivory Coast: >20% YoY growth expected](https://www.techinafrica.com/mobile-money-trends-in-african-marketplaces-2025/)
- [Africa mobile payments: $3.5B (2021) → $14-20B (2025)](https://www.mckinsey.com/industries/financial-services/our-insights/the-future-of-payments-in-africa)

**Conclusion:** Francophone Africa is NOT an afterthought - it's 40% of Sub-Saharan Africa's population and has BETTER payment infrastructure stability (CFA franc) than Anglophone markets. French translation + Orange Money/Wave = table stakes.

---

## Cross-Market Reference Tables

### Payment Coverage Matrix

| Market       | Flutterwave | Paystack | M-Pesa     | MTN MoMo   | Orange Money | Wave | Telebirr    | InstaPay | Dominant Method |
| ------------ | ----------- | -------- | ---------- | ---------- | ------------ | ---- | ----------- | -------- | --------------- |
| Kenya        | ✅ YES      | ✅ YES   | ✅✅ (91%) | -          | -            | -    | -           | -        | M-Pesa          |
| Nigeria      | ✅✅ HQ     | ✅✅ HQ  | -          | ✅         | -            | -    | -           | -        | MTN MoMo, OPay  |
| Ghana        | ✅ YES      | ✅ YES   | -          | ✅✅ (73%) | -            | -    | -           | -        | MTN MoMo        |
| South Africa | ✅ YES      | ✅ YES   | -          | -          | -            | -    | -           | -        | Bank Cards      |
| Tanzania     | ✅ YES      | ❌ NO    | ✅ (39%)   | -          | -            | -    | -           | -        | M-Pesa, Tigo    |
| Uganda       | ✅ YES      | ❌ NO    | ✅         | ✅         | -            | -    | -           | -        | MTN MoMo        |
| Rwanda       | ✅ YES      | ❌ NO    | ✅         | ✅         | -            | -    | -           | -        | MTN MoMo        |
| Senegal      | ✅ YES      | ❌ NO    | -          | -          | ✅           | ✅✅ | -           | -        | Orange, Wave    |
| Ivory Coast  | ✅ YES      | ❌ NO    | -          | ✅         | ✅           | ✅✅ | -           | -        | Orange, Wave    |
| Egypt        | ❓ Unknown  | ❌ NO    | -          | -          | -            | -    | -           | ✅✅     | InstaPay, Fawry |
| Ethiopia     | ❌ NO       | ❌ NO    | -          | -          | -            | -    | ✅✅ (100%) | -        | Telebirr        |

**Legend:** ✅✅ = Dominant/HQ, ✅ = Available, ❌ = Not available, ❓ = Unclear

---

### Localization Requirements

| Market       | English Works?          | Translation Required               | Additional Localization | Script Issues    |
| ------------ | ----------------------- | ---------------------------------- | ----------------------- | ---------------- |
| Kenya        | ✅ YES                  | None (Swahili optional)            | None                    | None             |
| Nigeria      | ✅ YES                  | None                               | None                    | None             |
| Ghana        | ✅ YES                  | None                               | None                    | None             |
| South Africa | ✅ YES (best in Africa) | None (Afrikaans optional)          | None                    | None             |
| Tanzania     | ⚠️ PARTIAL              | Swahili (recommended)              | None                    | None             |
| Uganda       | ✅ YES                  | None (Luganda optional)            | None                    | None             |
| Rwanda       | ✅ YES                  | None (Kinyarwanda for mass market) | None                    | None             |
| Senegal      | ❌ NO                   | **French REQUIRED**                | Wolof for consumer      | None             |
| Ivory Coast  | ❌ NO                   | **French REQUIRED**                | None                    | None             |
| Egypt        | ⚠️ PARTIAL              | **Arabic REQUIRED** (mass market)  | None                    | **RTL UI**       |
| Ethiopia     | ⚠️ PARTIAL              | **Amharic REQUIRED** (mass market) | None                    | **Ge'ez script** |

---

### KYC Requirements by Market

KYC tiering across Africa largely follows FATF recommendations but varies significantly in implementation. Most markets have adopted risk-based approaches with tiered limits. Digital KYC acceptance has accelerated post-COVID, though regulatory frameworks lag behind adoption.

| Market       | Tier 1 (Basic)                             | Tier 2 (Enhanced)                                | Tier 3 (Full)                                    | Documents Accepted                                            | Digital KYC Allowed?                | eKYC Providers                         |
| ------------ | ------------------------------------------ | ------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------------------- | ----------------------------------- | -------------------------------------- |
| Kenya        | Name, ID number, selfie; daily limit ~$500 | Full ID verification, address; limit ~$3,000/day | Full CDD, source of funds, biometrics; unlimited | National ID (Huduma Namba), Passport, KRA PIN                 | Yes (gazetted 2022)                 | Smile ID, Onfido, IPRS integration     |
| Nigeria      | BVN + phone; ₦300k daily limit             | BVN + NIN + address; ₦5M daily                   | Full CDD + reference + source of funds           | BVN, NIN, Voter's card, Driver's license, Passport            | Yes (CBN Tier 3 requires in-person) | Smile ID, Youverify, Prembly, VerifyMe |
| Ghana        | Ghana Card number; GH₵1k daily             | Ghana Card + address proof; GH₵10k daily         | Full CDD + employer + source of funds            | Ghana Card (mandatory), Passport, Voter ID (being phased out) | Yes (BOG 2021 guidelines)           | Smile ID, Appruve, Ghana Card NIA API  |
| South Africa | Name, ID, selfie; R5k/day                  | Full FICA verification; R25k/day                 | Full FICA + source of wealth                     | SA ID, Passport, Asylum permit                                | Yes (FIC Amendment Act 2022)        | Idenfy, Onfido, XDS, TransUnion        |
| Tanzania     | NIDA ID; TZS 3M daily                      | NIDA + TIN + address; TZS 10M daily              | Full CDD + financials                            | NIDA National ID, Passport, Voter ID                          | Partial (biometric via NIDA DB)     | NIDA API, Smile ID                     |
| Uganda       | National ID; UGX 4M daily                  | NIN + address + employer; UGX 20M daily          | Full CDD + source of funds                       | National ID (Ndaga Muntu), Passport                           | Yes (NIRA integration 2023)         | NIRA API, Smile ID                     |
| Rwanda       | National ID; RWF 500k daily                | NID + address; RWF 5M daily                      | Full CDD + financial history                     | National ID (Irembo-linked), Passport                         | Yes (advanced; Irembo platform)     | Irembo eKYC, Smile ID                  |
| Senegal      | National ID; XOF 200k daily                | CNI + address + employer; XOF 2M daily           | Full CDD                                         | Carte Nationale d'Identite, Passport, ECOWAS ID               | Partial (pilot stage)               | Smile ID, WAVE KYC                     |
| Ivory Coast  | CNI; XOF 200k daily                        | CNI + address; XOF 2M daily                      | Full CDD + source of funds                       | CNI, Passport, Attestation d'Identite, ECOWAS ID              | Partial                             | Smile ID, GreenTec                     |
| Egypt        | National ID; EGP 30k/month                 | NID + address + employer; EGP 100k/month         | Full CDD + financials                            | National ID (mandatory), Passport                             | Yes (CBE e-KYC 2020 regulation)     | Veridium, Fawry eKYC, valU             |
| Ethiopia     | Fayda Digital ID; ETB 50k daily            | Fayda + kebele ID + TIN; ETB 200k daily          | Full CDD + reference                             | Fayda Digital ID, Kebele ID, Passport                         | Yes (Fayda biometric system 2024)   | Fayda/National ID API                  |
| Cameroon     | National ID; XAF 500k daily                | CNI + address; XAF 2M daily                      | Full CDD                                         | CNI, Passport, Voter Card                                     | Limited                             | Smile ID                               |

> Sources: Central bank circulars (CBN, CBK, BOG, SARB, BCC); FATF Mutual Evaluation Reports 2022-2024; GSMA Mobile Money Regulatory Index 2024.

---

### Mobile Money Transaction Limits

Mobile money is the primary financial infrastructure for DAO participation in most African markets. Values reflect Tier 2 (standard verified) accounts in USD equivalents as of late 2024.

| Market       | Provider         | Daily Limit (Individual) | Daily Limit (Business) | Monthly Limit      | Min Transaction | Wallet Max Balance |
| ------------ | ---------------- | ------------------------ | ---------------------- | ------------------ | --------------- | ------------------ |
| Kenya        | M-Pesa           | $2,300 (KES 300k)        | $5,400 (KES 700k)      | $11,500 (KES 1.5M) | $0.08 (KES 10)  | $2,300 (KES 300k)  |
| Kenya        | Airtel Money     | $1,500 (KES 200k)        | $3,800 (KES 500k)      | $7,700 (KES 1M)    | $0.08 (KES 10)  | $1,500 (KES 200k)  |
| Nigeria      | OPay             | $630 (₦1M)               | $3,150 (₦5M)           | $12,600 (₦20M)     | $0.06 (₦100)    | $1,890 (₦3M)       |
| Nigeria      | PalmPay          | $630 (₦1M)               | $3,150 (₦5M)           | $12,600 (₦20M)     | $0.06 (₦100)    | $1,890 (₦3M)       |
| Ghana        | MTN MoMo         | $2,600 (GH₵40k)          | $6,500 (GH₵100k)       | $32,500 (GH₵500k)  | $0.07 (GH₵1)    | $6,500 (GH₵100k)   |
| South Africa | Vodapay          | $550 (R10k)              | $2,750 (R50k)          | $13,750 (R250k)    | $0.28 (R5)      | $2,750 (R50k)      |
| Tanzania     | M-Pesa (Vodacom) | $1,300 (TZS 3M)          | $8,600 (TZS 20M)       | $12,900 (TZS 30M)  | $0.21 (TZS 500) | $4,300 (TZS 10M)   |
| Uganda       | MTN MoMo         | $1,050 (UGX 4M)          | $5,250 (UGX 20M)       | $13,100 (UGX 50M)  | $0.13 (UGX 500) | $2,600 (UGX 10M)   |
| Rwanda       | MTN MoMo         | $1,850 (RWF 2.5M)        | $7,400 (RWF 10M)       | $22,200 (RWF 30M)  | $0.07 (RWF 100) | $3,700 (RWF 5M)    |
| Senegal      | Orange Money     | $610 (XOF 400k)          | $3,050 (XOF 2M)        | $7,600 (XOF 5M)    | $0.15 (XOF 100) | $3,050 (XOF 2M)    |
| Senegal      | Wave             | $760 (XOF 500k)          | $3,050 (XOF 2M)        | $7,600 (XOF 5M)    | $0.02 (XOF 10)  | $3,050 (XOF 2M)    |
| Ivory Coast  | Orange Money     | $610 (XOF 400k)          | $3,050 (XOF 2M)        | $7,600 (XOF 5M)    | $0.15 (XOF 100) | $3,050 (XOF 2M)    |
| Egypt        | Vodafone Cash    | $610 (EGP 30k)           | $2,030 (EGP 100k)      | $4,060 (EGP 200k)  | $0.20 (EGP 10)  | $2,030 (EGP 100k)  |
| Ethiopia     | Telebirr         | $450 (ETB 50k)           | $1,800 (ETB 200k)      | $4,500 (ETB 500k)  | $0.09 (ETB 10)  | $900 (ETB 100k)    |
| Cameroon     | MTN MoMo         | $830 (XAF 500k)          | $3,320 (XAF 2M)        | $8,300 (XAF 5M)    | $0.17 (XAF 100) | $3,320 (XAF 2M)    |

> Sources: GSMA State of the Industry Report 2024; operator tariff guides; central bank mobile money regulations. USD conversions at Dec 2024 rates.

---

### Crypto Regulation Status

Africa's crypto regulatory landscape ranges from progressive (South Africa, Nigeria 2024) to restrictive (Egypt, Ethiopia, Cameroon). The trend is toward regulation rather than prohibition, driven by high P2P adoption.

| Market       | Legal Status             | Central Bank Position                                   | CBDC Status                              | P2P Trading Legal?                    | Exchange Licensing                                               | Tax Treatment                                |
| ------------ | ------------------------ | ------------------------------------------------------- | ---------------------------------------- | ------------------------------------- | ---------------------------------------------------------------- | -------------------------------------------- |
| Kenya        | Legal (unregulated)      | CBK cautionary (2015, 2018); no ban                     | Research phase (2024)                    | Yes                                   | No framework yet; Capital Markets Act review underway            | No specific guidance; falls under income tax |
| Nigeria      | Legal & regulated (2024) | CBN lifted bank ban (Dec 2023); SEC regulates VASPs     | eNaira (launched Oct 2021, low adoption) | Yes                                   | SEC VASP licensing framework (June 2024); Busha, Quidax licensed | CGT applies; 10% on gains                    |
| Ghana        | Legal (unregulated)      | BOG cautionary (2018); SEC sandbox for VASPs            | e-Cedi pilot (2022-2024)                 | Yes (grey area)                       | SEC exploring licensing framework                                | No specific crypto tax law                   |
| South Africa | Legal & regulated        | SARB permits; FSCA regulates as financial product       | Research only                            | Yes                                   | FSCA CASP licensing (Oct 2022); 59 approved, 200+ applications   | CGT 18-45%; income tax if trading            |
| Tanzania     | Restricted               | BOT ban on crypto for banks (2019); under review (2024) | Exploratory                              | Tolerated (P2P active)                | No framework                                                     | No guidance                                  |
| Uganda       | Legal (unregulated)      | BOU cautionary (2017); no ban                           | Research phase                           | Yes                                   | No framework; proposed bill (2024)                               | No specific guidance                         |
| Rwanda       | Legal (cautious)         | BNR cautionary; fintech sandbox available               | Research via BNR                         | Yes                                   | Sandbox available; no full framework                             | No specific guidance                         |
| Senegal      | Ambiguous                | BCEAO ban on crypto for banks (2017)                    | BCEAO exploring regional CBDC            | Tolerated (high P2P)                  | No national framework; BCEAO regional oversight                  | No guidance                                  |
| Ivory Coast  | Ambiguous                | BCEAO ban on crypto for banks (2017)                    | BCEAO regional approach                  | Tolerated (P2P active)                | No framework                                                     | No guidance                                  |
| Egypt        | Restricted               | CBE ban on trading crypto (2018, reiterated 2020)       | Under study by CBE                       | Technically illegal; widely practiced | Banned; no licensing                                             | Not applicable (banned)                      |
| Ethiopia     | Prohibited (de facto)    | NBE prohibits crypto transactions (2024 proclamation)   | Research phase (Digital Birr)            | Illegal but practiced                 | Banned                                                           | Not applicable                               |
| Cameroon     | Ambiguous                | BEAC/COBAC cautionary for CEMAC zone                    | BEAC exploring                           | Tolerated (P2P)                       | No framework                                                     | No guidance                                  |

> Sources: Central bank official communications; IMF Country Reports 2024; Chainalysis Geography of Cryptocurrency Report 2024; Global Legal Research Directorate.

---

### Interest Rate Caps on Micro-Loans

Interest rate caps directly affect DAO micro-lending and treasury yield features. Markets with strict caps may limit certain DeFi-adjacent features.

| Market       | Cap Exists?           | Rate                                                                         | Applies To                                                 | Effective Date                          | Enforcement                                 |
| ------------ | --------------------- | ---------------------------------------------------------------------------- | ---------------------------------------------------------- | --------------------------------------- | ------------------------------------------- |
| Kenya        | Yes (reinstated 2021) | CBK rate + 4% (~16.5% p.a.); digital lenders: pricing disclosure required    | Banks; Digital Credit Providers (CBK regulated since 2022) | CBK Act 2021; DCP Regulations Sept 2022 | CBK; complaints portal active               |
| Nigeria      | Yes (guidelines)      | Effective 2024: max 2% per month on microloans; 30% p.a. formal lenders      | Microfinance banks, digital lenders (FCCPC regulated)      | FCCPC guidelines 2024                   | FCCPC + CBN; enforcement increasing         |
| Ghana        | No formal cap         | Market-determined; avg. 25-35% p.a. for MFIs                                 | N/A                                                        | N/A                                     | BOG supervises MFIs                         |
| South Africa | Yes (NCA)             | Varies by loan type: short-term 5%/month + fees; unsecured 27.5% p.a. + fees | All credit providers under NCA                             | National Credit Act 2005, amended 2023  | National Credit Regulator (NCR)             |
| Tanzania     | No formal cap         | Market-determined; avg. 18-24% p.a. banks, 30-60% MFIs                       | N/A                                                        | N/A                                     | BOT guidance only                           |
| Uganda       | No formal cap         | Market-determined; avg. 18-25% p.a. banks                                    | N/A                                                        | N/A                                     | BOU monitors; Tier 4 MFIs loosely regulated |
| Rwanda       | Soft cap (guidance)   | BNR guideline: base rate + spread; avg. 16-17% p.a.                          | Banks and MFIs                                             | BNR prudential guidelines               | BNR supervision                             |
| Senegal      | Yes (BCEAO)           | Usury rate: 15% p.a.; MFIs: 24% p.a.                                         | All lenders in WAEMU zone                                  | BCEAO regulation ongoing                | BCEAO + national DRS-SFD                    |
| Ivory Coast  | Yes (BCEAO)           | Same BCEAO usury framework: 15% general, 24% MFI                             | All lenders in WAEMU zone                                  | BCEAO regulation                        | BCEAO + APSFD-CI                            |
| Egypt        | Yes (regulated)       | CBE sets; consumer finance rates regulated; microfinance disclosure mandated | Banks, consumer finance, MFIs (FRA regulated)              | FRA regulations 2020                    | Financial Regulatory Authority (FRA)        |
| Ethiopia     | Soft cap              | NBE guidance; MFI rates 15-24% p.a.                                          | MFIs and banks                                             | NBE directives                          | NBE                                         |
| Cameroon     | Yes (BEAC/COBAC)      | CEMAC usury rate: ~15% p.a. general; MFIs higher ceiling                     | All CEMAC zone lenders                                     | COBAC regulation                        | COBAC + MINFI                               |

> Sources: Central bank rate schedules; World Bank Financial Inclusion Database 2024; CGAP regulatory reviews; national credit legislation.

---

### Mobile Money Interoperability Status

Interoperability is critical for DAO treasuries that need to accept contributions from multiple wallet providers. East Africa leads; West Africa is catching up via regional switches.

| Market       | Wallet-to-Wallet Cross-Provider?                   | Wallet-to-Bank?                    | Regional Integration                   | QR Payments                     | NFC Adoption               |
| ------------ | -------------------------------------------------- | ---------------------------------- | -------------------------------------- | ------------------------------- | -------------------------- |
| Kenya        | Yes (PesaLink, IPSL switch since 2023)             | Yes (mature; IPSL real-time)       | EAC: M-Pesa cross-border to TZ, UG, RW | Growing (Lipa na M-Pesa QR)     | Low (<5%)                  |
| Nigeria      | Yes (NIP/NIBSS; instant)                           | Yes (mature; NIBSS infrastructure) | PAPSS pilot (AfCFTA)                   | Growing (mCash, NIBSS QR)       | Low-moderate (POS-based)   |
| Ghana        | Yes (GhIPSS; universal QR code)                    | Yes (GhIPSS real-time)             | PAPSS connected (2024)                 | Strong (universal GhQR)         | Low                        |
| South Africa | Limited (bank-to-wallet varies)                    | Yes (EFT, RTC)                     | SADC RTGS; PAPSS pilot                 | Moderate (Masterpass, SnapScan) | Moderate (10-15%)          |
| Tanzania     | Yes (TIPS national switch since 2022)              | Yes (via TIPS)                     | EAC: cross-border with KE, UG, RW      | Early stage                     | Very low                   |
| Uganda       | Yes (UG national switch; limited)                  | Partial (improving)                | EAC: cross-border active               | Early stage                     | Very low                   |
| Rwanda       | Yes (RSwitch interoperability)                     | Yes (RSwitch integrated)           | EAC: cross-border active               | Growing (Irembo QR)             | Very low                   |
| Senegal      | Limited (Wave dominates; Orange interop improving) | Partial                            | ECOWAS/WAEMU: GIMTEL regional switch   | Low                             | Very low                   |
| Ivory Coast  | Limited (similar to Senegal)                       | Partial                            | ECOWAS/WAEMU: GIMTEL                   | Low                             | Very low                   |
| Egypt        | Yes (InstaPay switch, Meeza)                       | Yes (InstaPay; Meeza card network) | Not connected regionally               | Growing (Meeza QR)              | Moderate (Meeza NFC cards) |
| Ethiopia     | Limited (Ethswitch improving)                      | Partial (Ethswitch)                | Not yet connected                      | Early (Telebirr QR)             | Very low                   |
| Cameroon     | Limited (operator-specific)                        | Limited                            | CEMAC: GIMAC regional switch           | Very low                        | Very low                   |

> Sources: GSMA Interoperability Tracker 2024; national payment switch reports (IPSL, NIBSS, GhIPSS, TIPS, RSwitch, InstaPay); AfCFTA PAPSS progress reports.

---

### Data Cost per GB

Data affordability directly impacts DAO participation rates. The "1 for 2" benchmark (1GB for <2% of monthly income) is met by few African markets.

| Market       | Avg Cost/GB (USD) | Cheapest Bundle                                     | Social Media Bundle               | Zero-Rated Services            | Avg Monthly Data Usage |
| ------------ | ----------------- | --------------------------------------------------- | --------------------------------- | ------------------------------ | ---------------------- |
| Kenya        | $0.60             | Safaricom 1GB/24hr: $0.30                           | WhatsApp bundle 1GB: $0.15        | M-Pesa app, some health sites  | 2.5 GB                 |
| Nigeria      | $0.70             | MTN 1GB/30d: $0.60; Glo specials lower              | WhatsApp/Instagram bundles: $0.30 | Some educational portals       | 2.0 GB                 |
| Ghana        | $0.80             | MTN 1GB/30d: $0.65                                  | Social media 1.5GB: $0.40         | Limited                        | 1.8 GB                 |
| South Africa | $2.00             | Telkom 1GB/30d: $0.90; Rain data-only cheaper       | Social bundles: $0.50             | Wikipedia (some), govt sites   | 3.5 GB                 |
| Tanzania     | $0.50             | Vodacom 1GB/30d: $0.40                              | Social 1GB: $0.20                 | Limited                        | 1.5 GB                 |
| Uganda       | $1.20             | MTN 1GB/30d: $0.80                                  | Social bundles: $0.30             | Limited (OTT tax removed 2023) | 1.2 GB                 |
| Rwanda       | $0.80             | MTN 1GB/30d: $0.60                                  | Social: $0.30                     | Irembo platform                | 1.5 GB                 |
| Senegal      | $1.50             | Orange 1GB/30d: $1.10                               | Social: $0.40                     | Limited                        | 1.0 GB                 |
| Ivory Coast  | $1.80             | Orange 1GB/30d: $1.30                               | Social: $0.50                     | Limited                        | 0.9 GB                 |
| Egypt        | $0.50             | Vodafone 1GB/30d: $0.30; WE mega bundles            | Social 2GB: $0.30                 | Some govt services             | 3.0 GB                 |
| Ethiopia     | $0.80             | Ethio Telecom 1GB/30d: $0.50; Safaricom competitive | Social: $0.25                     | Limited                        | 0.8 GB                 |
| Cameroon     | $1.50             | MTN 1GB/30d: $1.00                                  | Social: $0.40                     | Limited                        | 0.8 GB                 |

> Sources: Alliance for Affordable Internet (A4AI) 2024; ITU ICT Price Baskets 2024; Cable.co.uk Worldwide Mobile Data Pricing; operator published tariffs Q4 2024.

---

### Smartphone Penetration & Connectivity

These metrics define the minimum viable platform requirements. Markets with high feature phone and USSD usage require USSD-first or SMS fallback for governance participation.

| Market       | Smartphone % | 4G Coverage %            | Internet % | Feature Phone % | USSD-Capable % | Avg Speed                |
| ------------ | ------------ | ------------------------ | ---------- | --------------- | -------------- | ------------------------ |
| Kenya        | 62%          | 85% (urban >95%)         | 53%        | 30%             | 95%+           | 15 Mbps (4G)             |
| Nigeria      | 50%          | 75% (urban >90%)         | 55%        | 35%             | 90%+           | 12 Mbps (4G)             |
| Ghana        | 58%          | 80%                      | 53%        | 32%             | 92%+           | 13 Mbps (4G)             |
| South Africa | 80%          | 90%+                     | 72%        | 12%             | 85%+           | 25 Mbps (4G); 5G growing |
| Tanzania     | 35%          | 60%                      | 35%        | 50%             | 95%+           | 8 Mbps (4G)              |
| Uganda       | 30%          | 55%                      | 33%        | 52%             | 93%+           | 7 Mbps (4G)              |
| Rwanda       | 38%          | 95% (ambitious coverage) | 38%        | 45%             | 90%+           | 10 Mbps (4G)             |
| Senegal      | 48%          | 70%                      | 58%        | 38%             | 90%+           | 11 Mbps (4G)             |
| Ivory Coast  | 45%          | 65%                      | 46%        | 40%             | 88%+           | 9 Mbps (4G)              |
| Egypt        | 70%          | 88%                      | 72%        | 18%             | 85%+           | 18 Mbps (4G)             |
| Ethiopia     | 25%          | 40%                      | 25%        | 55%             | 92%+           | 6 Mbps (4G)              |
| Cameroon     | 40%          | 55%                      | 38%        | 42%             | 88%+           | 7 Mbps (4G)              |

> Sources: GSMA Intelligence Q3 2024; ITU World Telecommunication Indicators 2024; Ookla Speedtest Global Index; DataReportal Digital 2024 country reports.

---

### Data Protection Laws

Data protection compliance is mandatory for any platform handling member PII, wallet addresses, and governance records. Adequacy decisions and cross-border transfer rules affect multi-country DAO deployments.

| Market       | Law Name                                  | Enacted                        | DPA Established?                 | Cross-Border Transfer Rules                           | Consent Requirements                               | Penalties                                        |
| ------------ | ----------------------------------------- | ------------------------------ | -------------------------------- | ----------------------------------------------------- | -------------------------------------------------- | ------------------------------------------------ |
| Kenya        | Data Protection Act 2019                  | Nov 2019                       | Yes - ODPC                       | Adequate protection required; ODPC whitelist          | Explicit, informed, opt-in; purpose limitation     | Up to KES 5M ($38k) or 1% of annual turnover     |
| Nigeria      | Nigeria Data Protection Act (NDPA) 2023   | June 2023                      | Yes - NDPC                       | Adequacy assessment or contractual safeguards         | Explicit consent; lawful basis required            | Up to 2% of annual gross revenue or NGN 10M      |
| Ghana        | Data Protection Act 2012 (Act 843)        | 2012                           | Yes - Data Protection Commission | Adequate level of protection required; DPC approval   | Consent must be informed and freely given          | Up to GH₵6,000 ($400); under review for increase |
| South Africa | POPIA                                     | July 2020 (enforced July 2021) | Yes - Information Regulator      | Adequate protection; binding corporate rules; consent | Explicit, specific, informed consent               | Up to ZAR 10M ($550k) and/or imprisonment        |
| Tanzania     | Personal Data Protection Act (proposed)   | Draft stage (2023-2024)        | No (proposed)                    | Pending                                               | Pending                                            | Pending                                          |
| Uganda       | Data Protection and Privacy Act 2019      | 2019                           | Yes - NITA-U                     | Adequate protection; minister's approval              | Consent required; purpose limitation               | Up to UGX 4.8M ($1,300) per offense              |
| Rwanda       | Law No. 058/2021                          | Oct 2021                       | Yes - NCSA                       | Adequate protection or contractual clauses            | Prior, express, informed consent                   | Up to RWF 5M ($4,700) or 5% of turnover          |
| Senegal      | Law No. 2008-12                           | Jan 2008                       | Yes - CDP                        | CDP authorization required                            | Prior consent; purpose limitation                  | Up to XOF 100M ($160k) and/or imprisonment       |
| Ivory Coast  | Law No. 2013-450                          | June 2013                      | Yes - ARTCI                      | ARTCI authorization required                          | Prior consent                                      | Up to XOF 10M ($16k) and/or imprisonment         |
| Egypt        | Personal Data Protection Law No. 151/2020 | July 2020 (exec regs pending)  | Pending                          | Regulator approval or adequate jurisdiction           | Explicit consent; special rules for sensitive data | Up to EGP 5M ($100k) and/or imprisonment         |
| Ethiopia     | Proposed (draft)                          | Not yet enacted (draft 2023)   | No                               | Pending                                               | Pending                                            | Pending                                          |
| Cameroon     | Law No. 2010/012 (partial)                | Dec 2010                       | Partial - ANTIC                  | Limited provisions                                    | Basic consent provisions                           | Criminal penalties; fines under cybercrime law   |

> Sources: African Union Malabo Convention ratification tracker; DLA Piper Global Data Protection Laws 2024; UNCTAD Data Protection Legislation database.

---

### Group Savings Traditions (Chamas, Tontines, Stokvels)

Traditional group savings structures represent the cultural foundation for DAO treasuries in Africa. These pre-existing trust networks are the primary adoption vector.

| Market       | Local Name       | Avg Members | Avg Fund Size    | Meeting Frequency            | Digital Adoption Rate    | Key Platforms                                     |
| ------------ | ---------------- | ----------- | ---------------- | ---------------------------- | ------------------------ | ------------------------------------------------- |
| Kenya        | Chama            | 15-30       | $200-2,000/month | Weekly/Monthly               | ~35% (highest in Africa) | ChamaDAO, M-Changa, Chamaa App                    |
| Nigeria      | Ajo/Esusu/Adashe | 10-25       | $30-$315/month   | Weekly/Monthly               | ~15%                     | CowryWise groups, PiggyVest, Ajo+                 |
| Ghana        | Susu             | 10-20       | $33-$325/month   | Daily/Weekly collection      | ~10%                     | Susu mobile collectors digitizing, MTN MoMo group |
| South Africa | Stokvel          | 12-50       | $28-$275/month   | Monthly                      | ~25%                     | StokvelHub, Stokfella, NedGroup stokvel accounts  |
| Tanzania     | Vikoba/VICOBA    | 20-50       | $85-$860/month   | Weekly/Monthly               | ~8%                      | VICOBA App (pilot), M-Pesa Weka                   |
| Uganda       | VSLA/SACCO       | 15-30       | $53-$530/month   | Weekly                       | ~10%                     | Ensibuuko (SACCO platform), Numida                |
| Rwanda       | Ibimina/Tontine  | 10-25       | $37-$370/month   | Weekly/Monthly               | ~15%                     | RSwitch integration; M-Pesa groups                |
| Senegal      | Tontine          | 10-40       | $80-$800/month   | Weekly/Monthly (tour system) | ~5%                      | Djamo groups, Wave groups                         |
| Ivory Coast  | Tontine          | 10-30       | $80-$480/month   | Weekly/Monthly               | ~5%                      | Orange Money tontine feature                      |
| Egypt        | Gam'eya          | 8-20        | $20-$200/month   | Monthly (rotating)           | ~20%                     | MoneyFellows (leading digital gam'eya), Fawry     |
| Ethiopia     | Equb             | 12-50       | $4.50-$45/month  | Weekly/Monthly               | <5%                      | Telebirr groups (early); mostly manual            |
| Cameroon     | Tontine/Njangui  | 10-30       | $83-$830/month   | Monthly (strict)             | <5%                      | MTN MoMo group pay; mostly manual                 |

> Sources: FSD Africa Group Savings Study 2023; CGAP Savings Groups report; Kenya Chama census (KAIG 2023); NASASA (National Stokvel Association of SA); World Bank Findex 2021/2024 update.

### Key Takeaways from Reference Tables

1. **Priority Tier 1 markets** (regulation + infrastructure + group savings culture): Kenya, South Africa, Nigeria, Ghana, Rwanda
2. **USSD fallback is non-negotiable** for Tanzania, Uganda, Ethiopia, Cameroon (smartphone <40%)
3. **Mobile money integration** is more critical than bank/card rails in all markets except South Africa and Egypt
4. **Francophone West Africa** (Senegal, Ivory Coast, Cameroon) shares BCEAO/BEAC regulatory frameworks -- deploy as a bloc
5. **Crypto regulatory risk** is highest in Egypt and Ethiopia; DAO features should abstract away crypto terminology
6. **Group savings digital adoption** is highest in Kenya (~35%) and South Africa (~25%) -- start here for treasury features
7. **Data protection compliance** requires attention in Kenya (ODPC active), Nigeria (NDPC enforcement increasing), and South Africa (POPIA fully enforced)

---

## Recommended Deployment Strategy for EnDAO Mobile

### Phase 1: Anglophone Core (Months 1-6)

**Markets:** Kenya, Nigeria, Ghana
**Why:**

- English-only works
- Flutterwave + Paystack both available
- M-Pesa (Kenya), MTN MoMo (Nigeria/Ghana) dominant
- Combined population: ~350M
- Highest fintech adoption

**Integrations:**

1. Flutterwave (all three markets)
2. Paystack (backup/alternative)
3. M-Pesa Kenya direct API (reliability)

**Regulatory:**

- Kenya: Moderate (CBK PSP license if handling funds)
- Nigeria: HIGH - budget for data localization if scaling
- Ghana: Low (best regulatory environment globally for mobile money)

**Localization:** English only, test with local beta users

---

### Phase 2: East Africa Expansion (Months 6-12)

**Markets:** Tanzania, Uganda, Rwanda
**Why:**

- Similar to Kenya (M-Pesa/MTN MoMo ecosystems)
- Cross-border mobile money integration exists
- Growing smartphone adoption

**Integrations:**

1. Flutterwave (all)
2. M-Pesa Tanzania (Vodacom)
3. MTN MoMo Uganda/Rwanda

**New Challenge:** Paystack not available - Flutterwave only

**Localization:**

- Tanzania: Add Swahili (recommended, not mandatory)
- Uganda/Rwanda: English sufficient

---

### Phase 3: South Africa Premium Market (Months 9-15)

**Markets:** South Africa
**Why:**

- Highest smartphone penetration (99.3%)
- Wealthiest market (higher ARPU potential)
- English proficiency best in Africa

**Integration Strategy DIFFERENT:**

- De-emphasize mobile money
- Prioritize bank card payments (Flutterwave/Paystack card processing)
- Add SnapScan/Zapper if B2C retail

**Regulatory:** POPIA compliance MANDATORY - budget 2-3 months legal review

**Localization:** English (Afrikaans optional for Afrikaner market)

---

### Phase 4: Francophone West Africa (Months 12-18)

**Markets:** Senegal, Ivory Coast, Cameroon
**Why:**

- 300M+ French speakers across Francophone Africa
- CFA franc stability (no currency volatility)
- Wave disruption = opportunity
- [Expected >20% YoY growth](https://www.techinafrica.com/mobile-money-trends-in-african-marketplaces-2025/)

**Integrations:**

1. Orange Money (dominant, 17 countries)
2. Wave (zero fees = high adoption in Senegal/Ivory Coast)
3. MTN MoMo (Cameroon, Ivory Coast)
4. Flutterwave (backup)

**Critical New Requirement:** **French translation MANDATORY** - budget 1-2 months for translation + QA

**Localization:**

- French required (professional translation, not Google Translate)
- Wolof for Senegal consumer market (optional)

**Regulatory:** WAEMU-level (easier than Nigeria/South Africa)

---

### Phase 5: Specialty Markets (Months 18-24+)

**Markets:** Egypt, Ethiopia
**Why Later:**

- Completely different ecosystems
- Egypt: Arabic + RTL UI + InstaPay (not mobile money)
- Ethiopia: Amharic + Ge'ez script + Telebirr monopoly

#### Egypt 🇪🇬

**When to Enter:**

- If targeting MENA expansion (gateway to Middle East)
- If B2B focus (English works for business users)

**Integrations:**

- InstaPay (instant bank transfers)
- Fawry (dominant payment platform)
- Skip Flutterwave/Paystack

**Localization:**

- Arabic REQUIRED for consumer market
- RTL (right-to-left) UI redesign
- English sufficient for B2B

**Regulatory:** CBE oversight, tokenization rules, moderate complexity

#### Ethiopia 🇪🇹

**When to Enter:**

- If Telebirr opens API access
- After testing in other markets (political risk)

**Integrations:**

- Telebirr ONLY (monopoly)
- No Flutterwave/Paystack

**Localization:**

- Amharic REQUIRED
- Ge'ez script support (different alphabet)

**Regulatory:** Low formal complexity, HIGH political risk (government controls telecom)

---

## Technical Recommendations for EnDAO Mobile

### 1. Payment Integration Priority

**MVP (80% coverage):**

```
1. Flutterwave (primary aggregator)
   - Covers: Nigeria, Ghana, Kenya, South Africa, Tanzania, Uganda, Rwanda, Senegal, Ivory Coast, Cameroon

2. M-Pesa Kenya Direct API (reliability)
   - Covers: Kenya (91% penetration = can't rely on aggregator alone)

3. Orange Money Direct API (Francophone)
   - Covers: 17 countries in Francophone Africa

4. Telebirr (if entering Ethiopia)
   - Covers: Ethiopia only (but 54.8M users, mandatory for that market)
```

**Production (95% coverage):**

```
Add:
5. MTN MoMo Direct API
   - Better rates than aggregators for Nigeria, Ghana, Uganda, Cameroon

6. Wave (Senegal, Ivory Coast)
   - Zero fees = high user adoption

7. Paystack (backup for Nigeria, Ghana, Kenya, South Africa)
   - Lower fees than Flutterwave for local transactions
```

### 2. Infrastructure Architecture

**Problem:** No Supabase Africa edge, nearest hop Europe (~600ms+ latency)

**Recommended Architecture:**

```
Layer 1: Cloudflare Workers (API Routes)
├─ POPs: Lagos, Nairobi, Johannesburg, Cairo, Kigali, Dar es Salaam, Kampala, Accra, Abidjan
├─ Use for: /api/mobile/v1/* routes (CRUD operations)
└─ Latency: <100ms for most African users

Layer 2: Supabase (Database & Auth)
├─ Region: Europe (eu-west-1 Dublin OR eu-central-1 Frankfurt)
├─ Use for: Auth, Realtime, Storage
└─ Latency: 180-450ms depending on market

Layer 3: Mobile App (Offline-First)
├─ Local SQLite cache for read-heavy data
├─ Background sync queue for writes
├─ Optimistic UI updates
└─ Conflict resolution strategy
```

**Alternative (if budget allows):**

- AWS af-south-1 (Cape Town) for Southern Africa cluster
- AWS eu-west-1 (Dublin) for West/North Africa cluster
- Multi-region Postgres with Supabase Realtime replication

### 3. Mobile App Optimization for Africa

```typescript
// Critical patterns for African markets

// 1. Offline-First Data Sync
interface SyncQueue {
  operations: PendingOperation[];
  retry: ExponentialBackoff;
  conflictResolution: 'last-write-wins' | 'server-wins' | 'client-wins';
}

// 2. Adaptive Image Loading
const getImageQuality = (networkSpeed: NetworkSpeed) => {
  switch (networkSpeed) {
    case '2g':
      return 'thumbnail'; // 50x50
    case '3g':
      return 'low'; // 200x200
    case '4g':
      return 'medium'; // 800x800
    case '5g':
      return 'high'; // Original
  }
};

// 3. Progressive Enhancement
if (navigator.connection.effectiveType === '2g') {
  // Disable real-time features, use polling
  disableRealtime();
  enablePolling({ interval: 30000 });
} else {
  // Enable Supabase Realtime
  enableRealtime();
}

// 4. Aggressive Caching
const cacheStrategy = {
  proposals: '7 days', // Read-heavy
  treasuryData: '1 day', // Moderate updates
  userProfile: '30 days', // Rarely changes
  notifications: 'no-cache', // Real-time critical
};

// 5. Background Sync Queue
const syncQueue = new BackgroundSyncQueue({
  maxRetries: 5,
  retryDelay: [1000, 5000, 15000, 60000, 300000], // Exponential backoff
  persistenceAdapter: new SQLiteAdapter(),
});
```

### 4. Localization Strategy

**Recommended Approach:**

```typescript
// packages/shared-types/src/i18n/locales.ts
export const SUPPORTED_LOCALES = {
  // Phase 1: Anglophone
  'en-KE': { name: 'English (Kenya)', fallback: 'en' },
  'en-NG': { name: 'English (Nigeria)', fallback: 'en' },
  'en-GH': { name: 'English (Ghana)', fallback: 'en' },

  // Phase 2: East Africa
  'sw-TZ': { name: 'Swahili (Tanzania)', fallback: 'en' },
  'sw-KE': { name: 'Swahili (Kenya)', fallback: 'en' },

  // Phase 3: South Africa
  'en-ZA': { name: 'English (South Africa)', fallback: 'en' },
  'af-ZA': { name: 'Afrikaans (South Africa)', fallback: 'en' }, // Optional

  // Phase 4: Francophone
  'fr-SN': { name: 'Français (Senegal)', fallback: 'fr' },
  'fr-CI': { name: "Français (Côte d'Ivoire)", fallback: 'fr' },
  'fr-CM': { name: 'Français (Cameroun)', fallback: 'fr' },

  // Phase 5: Specialty
  'ar-EG': { name: 'العربية (Egypt)', fallback: 'ar', rtl: true },
  'am-ET': { name: 'አማርኛ (Ethiopia)', fallback: 'en', script: 'Ethi' },
};

// Mobile app: Auto-detect locale based on SIM card country + device language
const detectLocale = () => {
  const simCountry = getSimCountryCode(); // TZ, KE, NG, etc.
  const deviceLang = getDeviceLanguage(); // en, sw, fr, ar, am

  // Match SIM country + device language
  const locale = `${deviceLang}-${simCountry}`;
  return SUPPORTED_LOCALES[locale] ? locale : 'en';
};
```

**Translation Process:**

1. Use i18n library (react-i18next for mobile)
2. Extract strings to JSON files per locale
3. Professional translation services (NOT Google Translate) for:
   - French (Francophone Africa)
   - Arabic (Egypt) - includes RTL UI redesign
   - Amharic (Ethiopia) - includes Ge'ez script support
4. Community review for local dialects (Wolof in Senegal, etc.)

### 5. Payment Integration Code Structure

```typescript
// apps/mobile/src/lib/payments/payment-provider-factory.ts
export class PaymentProviderFactory {
  static getProvider(
    country: CountryCode,
    method: PaymentMethod
  ): PaymentProvider {
    // Kenya: M-Pesa dominant
    if (country === 'KE' && method === 'mobile-money') {
      return new MPesaProvider(); // Direct API, not aggregator
    }

    // Nigeria: Multiple providers
    if (country === 'NG') {
      if (method === 'mobile-money') {
        return new FlutterwaveProvider(); // MTN MoMo, OPay, etc.
      }
      if (method === 'card') {
        return new PaystackProvider(); // Lower fees for cards
      }
    }

    // Ghana: MTN MoMo + cards
    if (country === 'GH') {
      if (method === 'mobile-money') {
        return new MTNMoMoProvider(); // Direct API
      }
      return new PaystackProvider();
    }

    // Francophone: Orange Money + Wave
    if (['SN', 'CI', 'CM'].includes(country)) {
      if (method === 'mobile-money') {
        return new OrangeMoneyProvider(); // Primary
        // return new WaveProvider() // Alternative (zero fees)
      }
      return new FlutterwaveProvider(); // Backup
    }

    // Ethiopia: Telebirr only
    if (country === 'ET') {
      return new TelebirrProvider(); // Monopoly
    }

    // Egypt: InstaPay, not mobile money
    if (country === 'EG') {
      return new InstaPayProvider(); // OR new FawryProvider()
    }

    // South Africa: Cards, not mobile money
    if (country === 'ZA') {
      return new PaystackProvider(); // Card processing
    }

    // Default: Flutterwave (widest coverage)
    return new FlutterwaveProvider();
  }
}

// Usage in mobile app
const provider = PaymentProviderFactory.getProvider(
  userCountry,
  'mobile-money'
);
const result = await provider.initiate({
  amount: 1000,
  currency: getCurrency(userCountry),
  phoneNumber: user.phone,
  reference: generateReference(),
});
```

### 6. Currency Handling

```typescript
// packages/shared-types/src/currencies.ts
export const CURRENCY_CONFIG: Record<CountryCode, CurrencyConfig> = {
  KE: { code: 'KES', symbol: 'KSh', decimals: 2, exchangeRate: 130 },
  NG: { code: 'NGN', symbol: '₦', decimals: 2, exchangeRate: 1600 },
  GH: { code: 'GHS', symbol: '₵', decimals: 2, exchangeRate: 16 },
  ZA: { code: 'ZAR', symbol: 'R', decimals: 2, exchangeRate: 18 },
  TZ: { code: 'TZS', symbol: 'TSh', decimals: 2, exchangeRate: 2500 },
  UG: { code: 'UGX', symbol: 'USh', decimals: 0, exchangeRate: 3700 },
  RW: { code: 'RWF', symbol: 'FRw', decimals: 0, exchangeRate: 1300 },

  // Francophone West Africa (WAEMU) - same currency
  SN: {
    code: 'XOF',
    symbol: 'CFA',
    decimals: 0,
    exchangeRate: 600,
    zone: 'WAEMU',
  },
  CI: {
    code: 'XOF',
    symbol: 'CFA',
    decimals: 0,
    exchangeRate: 600,
    zone: 'WAEMU',
  },

  // Francophone Central Africa - different CFA
  CM: {
    code: 'XAF',
    symbol: 'FCFA',
    decimals: 0,
    exchangeRate: 600,
    zone: 'CEMAC',
  },

  EG: { code: 'EGP', symbol: '£', decimals: 2, exchangeRate: 31 },
  ET: { code: 'ETB', symbol: 'Br', decimals: 2, exchangeRate: 120 },
};

// Mobile money transaction limits
export const TRANSACTION_LIMITS: Record<CountryCode, TransactionLimits> = {
  KE: {
    dailyLimit: 500000, // KES
    perTransaction: 250000,
    maxBalance: 500000,
  },
  // ... others
};
```

---

## Testing Checklist for Each Market

Before launching in a new market, test:

### Payment Integration

- [ ] Mobile money payment initiation
- [ ] Payment callback/webhook handling
- [ ] Refund flows (if applicable)
- [ ] Currency conversion (if cross-border)
- [ ] Transaction limits validation
- [ ] Failed payment UX
- [ ] Duplicate transaction prevention

### Localization

- [ ] All UI strings translated
- [ ] Currency formatting correct
- [ ] Date/time formatting (24h vs 12h)
- [ ] Phone number validation (country-specific)
- [ ] RTL layout (Arabic only)
- [ ] Font rendering (Ge'ez script for Amharic)
- [ ] Locale auto-detection from SIM

### Connectivity

- [ ] Offline mode works
- [ ] Sync queue handles retries
- [ ] Image loading degrades gracefully
- [ ] API timeouts set appropriately (>10s for Africa)
- [ ] Real-time features optional (can disable on 2G)

### Regulatory

- [ ] Data protection compliance (POPIA for South Africa, NDPA for Nigeria)
- [ ] Data localization (Nigeria ONLY)
- [ ] Age verification (POPIA: 18+ consent, GDPR: 16+)
- [ ] Fintech licensing (if handling funds directly)
- [ ] Terms of Service + Privacy Policy translated

### User Testing

- [ ] Beta test with 20-50 local users per market
- [ ] Test on LOW-END devices (not flagship phones)
- [ ] Test on 3G network (not WiFi)
- [ ] Test with local SIM cards (not international roaming)
- [ ] Payment flow with REAL money (small amounts)

---

## Key Takeaways for EnDAO Mobile

### ✅ What Works Across Markets

1. **Android-first strategy** - Google Play dominates all markets (iOS <5% except South Africa ~20%)
2. **Mobile-first design** - Desktop secondary/optional
3. **Offline-first architecture** - MANDATORY for Africa (not optional)
4. **SMS fallbacks** - For notifications when data unavailable
5. **Low data consumption** - Compress everything, lazy load, cache aggressively

### ❌ What Doesn't Work

1. **English-only for all of Africa** - Breaks in Francophone (French), Egypt (Arabic), Ethiopia (Amharic)
2. **Single payment provider** - Flutterwave or Paystack alone leaves gaps
3. **Assuming mobile money everywhere** - South Africa is card-first, Egypt is bank transfer-first
4. **High-bandwidth features** - Video, large images, heavy animations
5. **Real-time-only** - Must work with polling as fallback (2G/3G networks)

### ⚠️ Critical Gotchas

1. **Nigeria data localization** - Most expensive regulatory requirement, plan ahead
2. **South Africa POPIA** - Most mature data protection law, requires legal review
3. **Ethiopia political risk** - Government controls telecom, can block apps
4. **Egypt RTL UI** - Arabic requires UI redesign, not just translation
5. **Kenya M-Pesa dominance** - 91% penetration means aggregator NOT sufficient, need direct API

---

## Sources & References

All data sourced from 2025-2026 publications:

### Mobile Money & Fintech

- [M-Pesa Kenya Statistics 2025](https://techcabal.com/2025/11/19/more-kenyans-m-pesa-safaricom-mobile-network/)
- [Kenya Mobile Money Penetration](https://fintechmagazine.com/news/kenya-leads-the-world-in-mobile-money-penetration)
- [MTN Mobile Money Growth](https://news.broadcastmediaafrica.com/2025/11/19/mtn-surpasses-300-million-subscribers-with-strong-growth-driven-by-nigeria-and-ghana/)
- [Ghana Mobile Money Statistics](https://asetenapa.com/ghana-mobile-money-statistics/)
- [Flutterwave vs Paystack Coverage](https://radarr.africa/paystack-vs-flutterwave-vs-paypal/)
- [Orange Money Francophone Africa](https://medium.com/@oussama.zaghdoud/orange-money-west-africas-digital-payment-champion-60690ab6f22b)
- [Wave Mobile Money](https://triplepundit.com/2025/wave-mobile-money-cote-divoire/)
- [Telebirr Ethiopia](https://techafricanews.com/2025/07/25/ethio-telecom-achieves-83-2m-subscribers-and-73-revenue-surge-as-lead-strategy-concludes/)

### Data Costs & Connectivity

- [Mobile Data Costs Africa](https://nairametrics.com/2025/01/14/tariff-increase-cost-of-data-in-nigeria-ghana-south-africa-and-kenya-compared/)
- [Africa Mobile Economy 2025](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/africa/)
- [Smartphone Penetration Africa](https://telecomlead.com/4g-lte/africa-mobile-internet-usage-gap-widens-as-smartphone-affordability-and-legacy-networks-slow-digital-inclusion-124248)

### Regulatory & Data Protection

- [Kenya Fintech Regulations 2025](https://practiceguides.chambers.com/practice-guides/fintech-2025/kenya)
- [Nigeria Fintech Laws](https://www.globallegalinsights.com/practice-areas/fintech-laws-and-regulations/nigeria/)
- [South Africa POPIA 2025](https://www.oaklaw.co.za/how-south-african-data-protection-laws-impact-your-business-operations-in-2025/)
- [Egypt Fintech Regulations](https://iclg.com/practice-areas/fintech-laws-and-regulations/egypt)
- [Africa Data Protection Laws](https://gdprlocal.com/gdpr-and-data-protection-laws-in-africa-a-comparison/)

### Language & Localization

- [English Proficiency Africa 2025](https://www.africanexponent.com/top-10-african-countries-with-the-best-english-proficiency-and-speakers-in-2025/)
- [Francophone Africa Business](https://www.fabs.africa/about-fabs/)

### Infrastructure & Payments

- [Supabase Regions](https://supabase.com/docs/guides/platform/regions)
- [Tanzania M-Pesa Global Payments](https://telcomagazine.com/news/vodacom-expands-global-payments-with-m-pesa-upgrades)
- [South Africa Mobile Payments](https://netcash.co.za/blog/top-online-payment-methods-in-south-africa-2025-update/)
- [Egypt InstaPay](https://www.lightspark.com/knowledge/egypt-instant-payments)

---

**Document Version:** 1.0
**Last Updated:** January 31, 2026
**Compiled by:** EnDAO Research Team
**Purpose:** African market expansion strategy for mobile platform
