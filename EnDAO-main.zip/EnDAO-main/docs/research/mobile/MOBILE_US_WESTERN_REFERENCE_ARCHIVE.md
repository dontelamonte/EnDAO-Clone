# EnDAO: Mobile Development for US, Western & Global Markets

**Date:** January 30, 2026
**Context:** Best practices for iOS and Android development targeting US and Western markets (EU, UK, Canada, Australia), with global expansion considerations. Companion document to the Africa-focused mobile plan.

---

## Table of Contents

1. [iOS Best Practices](#1-ios-best-practices)
2. [US/Western Android Best Practices](#2-uswestern-android-best-practices)
3. [Privacy & Regulatory Compliance](#3-privacy--regulatory-compliance)
4. [Payments & Monetization](#4-payments--monetization)
5. [Build, Testing & CI/CD](#5-build-testing--cicd)
6. [Global Readiness (Appendix)](#6-global-readiness-appendix)

---

## 1. iOS Best Practices

### Target: iOS 16.0 minimum

iOS 16+ covers ~95% of active devices in Western markets. Expo SDK 52 supports iOS 15.1+ minimum, but targeting 16 lets you use modern APIs without compatibility shims.

### App Store Size & Performance

- **Download size limit**: 200 MB over cellular (iOS 15+). Target under 50 MB for best conversion.
- **Bitcode**: Deprecated and removed as of Xcode 14. Do not enable.
- **On-Demand Resources**: Available via native modules for heavy assets (onboarding videos, localized legal docs).
- **Hermes engine**: Default in Expo 52, produces smaller bundles than JSC.

### Memory & Background Execution

- iOS aggressively terminates background apps. Budget ~1.5 GB max on older devices (iPhone SE 2nd gen, 3 GB RAM).
- Use `react-native-screens` (included in Expo Router) for native screen management.
- **No long-running background services** — unlike Android. Governance notifications must be push-driven, not poll-driven.
- `BGTaskScheduler` for periodic tasks requires a native module or config plugin.

### WidgetKit

WidgetKit requires a native iOS extension written in SwiftUI. Useful widgets for EnDAO:

- Active proposal countdown timer
- DAO treasury balance
- Quick vote action (interactive widgets, iOS 17+)

Community package `expo-apple-targets` or manual native code via config plugins.

### App Store Review — Key Guidelines

**Guideline 3.1.1 (In-App Purchase)**:

- Crypto transactions that are peer-to-peer (treasury contributions, on-chain governance) are generally exempt.
- Donations to third parties (not the developer) typically allow external payment (Stripe, Apple Pay directly).
- **Post-DMA (EU only)**: Alternative payment methods allowed. Does NOT apply to US, UK, Canada, or Australia as of January 2026.

**Guideline 4.2 (Minimum Functionality)**:

- Apps that are just web wrappers get rejected. Must offer genuinely native functionality: push notifications, biometric auth, offline proposal viewing, widgets.

**Guideline 5.1 (Privacy)**:

- Must have a privacy policy accessible in-app and in App Store listing.
- Wallet addresses, voting history, DAO membership are potentially sensitive — disclose clearly.
- IPv6 compatibility required (all Apple review is done on IPv6).

### Apple Human Interface Guidelines

**Common React Native violations**:

1. **Back swipe**: Never disable the iOS swipe-from-left-edge gesture.
2. **Navigation**: Use bottom tab bar + stack navigation. Avoid Android-style top tabs or hamburger menus as primary navigation.
3. **Large titles**: Use `headerLargeTitle: true` for top-level screens (collapsible on scroll).
4. **Safe areas**: Use `react-native-safe-area-context`. Dynamic Island (iPhone 14 Pro+) and home indicator must be respected.
5. **Sheet presentations**: Use `@gorhom/bottom-sheet` for quick actions (voting, approving transactions) instead of full-screen modals.

**Haptic feedback** (`expo-haptics`): `.impactLight` for button taps, `.notificationSuccess` for completed votes, `.impactHeavy` for destructive actions. Western users expect haptics on iOS.

### iOS Accessibility

- All interactive elements need `accessibilityLabel`, `accessible={true}`, and `accessibilityRole`.
- **Dynamic Type**: `allowFontScaling={true}` (default). Set `maxFontSizeMultiplier` to prevent layout breakage.
- **Reduce Motion**: Check `AccessibilityInfo.isReduceMotionEnabled`.
- **Touch targets**: Minimum 44x44 points (Apple guideline, stricter than WCAG's 24x24).
- **Audit tools**: Xcode Accessibility Inspector, Accessibility Audit in Xcode.

### Apple Pay Integration

Use **Stripe React Native SDK** (`@stripe/stripe-react-native`). No first-party `expo-apple-pay` exists.

```typescript
import { useStripe } from '@stripe/stripe-react-native';
const { initPaymentSheet, presentPaymentSheet } = useStripe();

await initPaymentSheet({
  paymentIntentClientSecret: clientSecret,
  merchantDisplayName: 'EnDAO',
  applePay: { merchantCountryCode: 'US' },
  googlePay: { merchantCountryCode: 'US', testEnv: __DEV__ },
});

const { error } = await presentPaymentSheet();
```

~75% of US iPhone users have Apple Pay configured. Conversion rates 2-3x higher than manual card entry.

### iOS Security

- **Keychain**: Store sensitive data via `expo-secure-store` (maps to Keychain). Set `keychainAccessible` to `WHEN_UNLOCKED_THIS_DEVICE_ONLY`.
- **Face ID/Touch ID**: Use `expo-local-authentication`. `Info.plist` must include `NSFaceIDUsageDescription`.
- **App Attest**: Verify requests from legitimate app instances. Not directly available in Expo; requires native module.
- **ATS**: All network connections require HTTPS (TLS 1.2+). Do not add exceptions for production.

### Push Notifications (APNs)

Use `expo-notifications` with an APNs Key (`.p8` file).

**Notification categories** for actionable notifications:

- `PROPOSAL_VOTE`: Vote Yes / Vote No / View Details
- `TREASURY_ALERT`: Review / Dismiss

**Focus modes** (iOS 15+): Use `interruptionLevel: 'timeSensitive'` for proposal deadlines and treasury approvals.

**Provisional authorization**: Deliver silently to Notification Center without explicit permission. Good for onboarding.

### Privacy

**App Tracking Transparency (ATT)**: Required if using IDFA. Configure PostHog to avoid IDFA collection (~75% denial rate in Western markets).

**Privacy manifests** (required since Spring 2024): `PrivacyInfo.xcprivacy` declaring Required Reason APIs, tracking domains, and collected data types. Expo SDK 52 includes tooling via `app.json`:

```json
{
  "expo": {
    "ios": {
      "privacyManifests": {
        "NSPrivacyAccessedAPITypes": [
          {
            "NSPrivacyAccessedAPIType": "NSPrivacyAccessedAPICategoryUserDefaults",
            "NSPrivacyAccessedAPITypeReasons": ["CA92.1"]
          }
        ],
        "NSPrivacyCollectedDataTypes": [
          {
            "NSPrivacyCollectedDataType": "NSPrivacyCollectedDataTypeEmailAddress",
            "NSPrivacyCollectedDataTypeLinked": true,
            "NSPrivacyCollectedDataTypeTracking": false,
            "NSPrivacyCollectedDataTypePurposes": [
              "NSPrivacyCollectedDataTypePurposeAppFunctionality"
            ]
          }
        ]
      }
    }
  }
}
```

Third-party SDKs (Stripe, PostHog, Sentry, Privy) must include their own privacy manifests.

**Privacy nutrition labels** for App Store Connect:

| Data Type      | Collection       | Usage             | Linked to Identity |
| -------------- | ---------------- | ----------------- | ------------------ |
| Email          | Yes (Privy auth) | App Functionality | Yes                |
| Wallet Address | Yes              | App Functionality | Yes                |
| User ID        | Yes              | App Functionality | Yes                |
| Usage Data     | Yes (PostHog)    | Analytics         | Potentially        |
| Diagnostics    | Yes (Sentry)     | App Functionality | No                 |

---

## 2. US/Western Android Best Practices

### Device Landscape

US/Western Android is fundamentally different from African Android:

- **Devices**: $500-1300 flagships, 8-12 GB RAM, 128-512 GB storage
- **Samsung Galaxy S series** dominates US, Google Pixel is the reference
- **Target Android 12+** for Material You, **Android 14+ primary audience**

### Material Design 3 / Material You

Dynamic theming from user wallpaper is expected on modern Android. Options for React Native:

- `expo-material3-theme` — Extracts device Material You colors
- React Native Paper v5 — Full MD3 component library
- NativeWind + Tailwind — Custom approach with dynamic color tokens

### Edge-to-Edge Displays (Mandatory)

React Native 0.76+ (Expo SDK 52) supports edge-to-edge via `react-native-edge-to-edge`. Content must draw behind system bars.

### Foldable Support — Mandatory by August 2026

**Android 16 (API 36) mandate**: Starting August 2026, Google Play requires apps targeting API 36 to handle orientation/resize changes on large screens. Apps MUST be responsive.

For EnDAO, foldables are genuinely useful:

- **Proposal Review**: Side-by-side proposal text + voting panel
- **Treasury Dashboard**: Full overview with charts and transaction lists
- **Discussion Threads**: Master-detail layout

```typescript
// NativeWind responsive layout
<View className="flex-1 md:flex-row">
  <View className="flex-1 md:w-2/3"><ProposalContent /></View>
  <View className="md:w-1/3"><VotingPanel /></View>
</View>
```

### Performance

- **Baseline Profiles**: Pre-compile hot code paths. `expo-baseline-profile` config plugin or manual setup.
- **Cold start target**: Sub-1 second.
- **120fps**: Many flagship Android devices support 120Hz. Avoid heavy JS work on the main thread.
- **R8/ProGuard**: Enabled by default in release builds. Code shrinking + obfuscation.

### Biometric Authentication — CRITICAL WARNING

**`expo-local-authentication` is NOT secure enough for financial/governance apps.** It uses an event-based approach where biometric success is a callback boolean — this can be tampered with.

**Secure approach** (result-based / crypto-based):

1. Generate a cryptographic key in Android Keystore with `setUserAuthenticationRequired(true)`
2. Supply a `CryptoObject` to BiometricPrompt's `authenticate` method
3. Use the authenticated key for a cryptographic operation (sign/decrypt)
4. Send the cryptographic proof to the backend

**Recommended libraries** (in order of security):

1. **`react-native-biometrics`** — Keypair/signature flows, strongest for backend verification
2. **`react-native-keychain`** — Full Keystore integration, biometric gating
3. **`react-native-sensitive-info`** — Rebuilt on Fabric, StrongBox + Secure Enclave support
4. **`expo-secure-store`** — Keystore-encrypted SharedPreferences (adequate for non-critical tokens)

| Library                          | Android Backend                                   | Security Level |
| -------------------------------- | ------------------------------------------------- | -------------- |
| `expo-secure-store`              | Keystore-encrypted SharedPreferences              | Medium         |
| `react-native-encrypted-storage` | EncryptedSharedPreferences                        | Medium         |
| `react-native-sensitive-info`    | Keystore + StrongBox + EncryptedSharedPreferences | High           |
| `react-native-keychain`          | Android Keystore directly                         | Highest        |

### Network Security — SSL Pinning

For a governance/financial app:

```xml
<!-- android/app/src/main/res/xml/network_security_config.xml -->
<network-security-config>
  <domain-config cleartextTrafficPermitted="false">
    <domain includeSubdomains="true">endao.ai</domain>
    <pin-set>
      <pin digest="SHA-256">YOUR_PIN_HERE</pin>
    </pin-set>
  </domain-config>
</network-security-config>
```

Set `android:usesCleartextTraffic="false"` in AndroidManifest.xml.

### Play Integrity API

Replaces SafetyNet. Verifies device is not rooted, app binary is genuine, Google Play account is legitimate. Important for voting and treasury functions where tampered clients could be a governance attack vector. Requires a native module bridge.

### Google Play Policies

- **Financial Services Policy**: Governance apps with treasury features must comply with financial services disclosure requirements.
- **AAB format mandatory**: EAS Build produces AAB by default for production.
- **Staged rollouts**: Start at 5%, monitor crash rates, increase to 25% → 100%.

### Wear OS

**Do NOT build a Wear OS companion app.** Standard push notifications automatically bridge to watches. Ensure notifications are well-structured (short titles, actionable content) for good watch display.

### Key Differences: Western vs African Android

| Dimension       | African Market                    | Western Market                              |
| --------------- | --------------------------------- | ------------------------------------------- |
| Devices         | Sub-$150, 2-3GB RAM               | $500-1300, 8-12GB RAM                       |
| Network         | 3G/4G, offline-first              | 5G/WiFi assumed, real-time                  |
| APK Size        | <30MB critical                    | 50-80MB acceptable                          |
| Android Version | Android 8-9 minimum               | Android 12+ for Material You                |
| Design          | Basic Material, performance-first | Material You dynamic theming                |
| Payments        | Mobile money, USSD                | Google Pay, Stripe                          |
| Security        | Basic encryption, PIN             | Biometric + Keystore crypto, Play Integrity |
| Accessibility   | Basic readability                 | WCAG 2.2 AA, EAA compliance                 |
| Large screens   | Irrelevant                        | Mandatory adaptive layout by Aug 2026       |

---

## 3. Privacy & Regulatory Compliance

### US Privacy Laws

#### CCPA/CPRA (California)

**Threshold**: Annual revenue >$25M, OR data on >100,000 consumers, OR >50% revenue from data. Plan for compliance from day one.

**Engineering actions now**:

- "Download My Data" feature (JSON export)
- "Delete My Account" flow that purges PII from Supabase but preserves anonymized on-chain records
- Privacy settings screen with opt-out toggles
- "Do Not Sell or Share" toggle (safe harbor)
- Honor Global Privacy Control (GPC) signals

#### State Privacy Laws — Texas is the Most Dangerous

~20 US states have enacted comprehensive privacy laws. Texas has **no revenue or volume threshold** — if you have Texas users, you are covered. Delaware has very low thresholds (35K consumers).

**Practical approach**: Build one unified privacy framework satisfying the strictest requirements (CPRA + Texas + Colorado universal opt-out).

#### Age Restrictions

**Recommendation: Set minimum age to 18.** This:

- Eliminates COPPA compliance burden entirely
- Satisfies all EU member state requirements
- Avoids emerging US state laws raising age to 16-18
- Is defensible (governance + financial decisions are adult activities)

**Implementation**: Date-of-birth field during signup (NOT a checkbox). If under 18, block and do NOT store the DOB. Store only the fact that age was verified, not the actual DOB.

### EU/UK GDPR

#### Consent

- Pre-ticked boxes are NOT valid consent
- Separate consent for separate purposes (analytics vs terms of service)
- PostHog, Sentry, and analytics must not fire until consent is obtained
- First-launch consent screen with granular toggles: Essential (always on), Analytics (opt-in), Error Reporting (opt-in)
- Do NOT use dark patterns

#### Data Residency — EU-US Data Privacy Framework

DPF adopted July 2023. Allows EU→US data transfer if self-certified. Under legal challenge (potential Schrems III). **Risk mitigation**: Consider offering EU data residency (Supabase has EU regions).

#### Right to Erasure

**Must delete**: Profile data, messages, comments, notifications, session data, analytics
**Can retain**: Anonymized voting records (replace user ID with "deleted-user-xxxx"), on-chain treasury records (technically immutable)

Build a GDPR Erasure service: anonymize user record → delete PII → replace display names → request deletion from PostHog/Sentry → log the erasure.

#### UK GDPR

Substantively identical to EU GDPR. No additional engineering needed.

### Accessibility Laws

#### ADA (US)

No explicit ADA regulation for mobile apps, but courts increasingly hold apps are "places of public accommodation." 4,000+ digital accessibility lawsuits per year.

**For a governance app, voting must be accessible** — legal risk and ethical failure if members cannot cast votes due to accessibility barriers.

#### European Accessibility Act (EAA) — Enforceable Since June 2025

Requires EN 301 549 compliance (incorporates WCAG 2.1 AA plus mobile-specific requirements). Applies regardless of where the business is headquartered.

#### WCAG 2.2 AA — Practical Baseline

Key new criteria for mobile:

| Criterion                       | Requirement                          | Relevance                                 |
| ------------------------------- | ------------------------------------ | ----------------------------------------- |
| 2.5.7 Dragging Movements        | Single-pointer alternative to drag   | Treasury dashboards, reordering proposals |
| 2.5.8 Target Size               | 24x24 CSS pixels minimum             | All buttons, especially voting            |
| 3.3.7 Redundant Entry           | Don't ask for same info twice        | Multi-step proposal creation              |
| 3.3.8 Accessible Authentication | No cognitive function test for login | Privy wallet connection flow              |

### EU Digital Markets Act (DMA)

- Alternative payment processors allowed in EU (Apple and Google must allow external payments)
- Alternative app stores in EU — minimal practical impact; stick with standard distribution
- Implement region-based payment routing: EU users get direct Stripe payment, US users through standard flow

### Financial Regulations

**Money Transmitter Licensing (US)**: If the app never has custody of funds (all transactions signed by users' wallets, executed on-chain), risk is lower. Structure the app as a read/write interface, not a custodian.

**MiCA (EU)**: Crypto-asset service providers need authorization. If the app is purely an interface to on-chain smart contracts without custody, authorization likely not needed.

**PSD2/SCA (EU)**: Stripe handles SCA compliance automatically through PaymentSheet.

**Engineering actions to minimize regulatory exposure**:

- Never hold custody of user funds
- Do not facilitate direct fiat-to-crypto conversion (use third-party on-ramps)
- Do not issue tokens
- Add clear disclaimers: EnDAO is governance software, not a financial service
- **Consult a fintech/crypto attorney before launching treasury features in the EU**

### Engineering vs Legal Counsel

**Engineering can implement now**:

| Action                                | Priority |
| ------------------------------------- | -------- |
| Age gate (18+, DOB-based)             | High     |
| Privacy settings with opt-out toggles | High     |
| "Download My Data" export             | High     |
| "Delete My Account" flow              | High     |
| Consent management on first launch    | High     |
| Honor GPC signals                     | High     |
| Accessibility audit (WCAG 2.2 AA)     | High     |
| VoiceOver/TalkBack testing for voting | Critical |
| Touch target sizing (44x44 minimum)   | Medium   |
| Color contrast audit                  | Medium   |
| Reduce-motion support                 | Medium   |
| Region-based payment routing          | Medium   |

**Requires legal counsel**:

- Treasury features and money transmitter licensing
- EU MiCA compliance for crypto treasury features
- Token-related securities analysis
- EU-US DPF self-certification
- Terms of Service drafting

---

## 4. Payments & Monetization

### Apple Pay / Google Pay

**Primary integration**: Stripe React Native SDK (`@stripe/stripe-react-native`)

```typescript
// app.json plugin config
{
  "expo": {
    "plugins": [
      ["@stripe/stripe-react-native", {
        "merchantIdentifier": "merchant.ai.endao",
        "enableGooglePay": true
      }]
    ]
  }
}
```

Use `PaymentSheet` (not custom UI):

```typescript
await initPaymentSheet({
  paymentIntentClientSecret: clientSecret,
  merchantDisplayName: 'EnDAO',
  applePay: { merchantCountryCode: 'US' },
  googlePay: { merchantCountryCode: 'US', testEnv: __DEV__ },
});
```

**Adoption**: ~75% US iPhone users, ~40-50% US Android users have wallet payment configured. Higher in UK (~80%+ Apple Pay).

### Stripe in Western Markets

- **Payment Element**: Automatically shows Apple Pay, Google Pay, SEPA, iDEAL, Bancontact based on customer location. Handles 3D Secure / SCA automatically.
- **Stripe Crypto On-ramp**: Available in US, UK, select EU. Supports ETH, SOL, USDC. ~1.5% fee. Stripe handles KYC.
- **Stripe Connect**: For multi-entity DAOs. Create Connected Accounts per DAO for direct charges. Most DAOs are not separate legal entities — simpler model is single Stripe account with metadata tracking.

### In-App Purchase Rules

**Apple IAP NOT required for**:

- Charitable donations to registered nonprofits
- Person-to-person payments (treasury contributions between DAO members)
- Crypto asset purchases/transfers
- Financial services

**For EnDAO**: Frame contributions as peer-to-peer financial transactions (like Venmo/Cash App). Do NOT frame as "tipping" or "unlocking features."

**EU DMA**: Apps in EEA can use Stripe directly for all transactions, bypassing Apple IAP.

**Google Play**: Similar rules, slightly more lenient. Donations and P2P exempt.

### EU-Specific Payments

**PSD2 SCA**: Mandatory for EU payments >30 EUR. Stripe handles automatically via PaymentSheet.

**SEPA Direct Debit**: Lower fees (~€0.35 per transaction vs ~1.5% + €0.25 for cards). Good for recurring EU contributions. 5-7 day settlement delay.

**Local methods worth supporting**:

- **iDEAL** (Netherlands) — 60%+ of Dutch online payments. Yes.
- **Bancontact** (Belgium) — dominant. Yes.
- **Sofort/Klarna** (Germany) — declining. Only if significant German users.

All auto-detected by Stripe Payment Element when enabled in Dashboard.

### Crypto Payment Considerations

**On-ramp providers**:

| Provider              | Coverage          | Fees       | Fit                        |
| --------------------- | ----------------- | ---------- | -------------------------- |
| Stripe Crypto On-ramp | US, UK, select EU | ~1.5%      | Best Stripe ecosystem fit  |
| MoonPay               | 160+ countries    | 1-4.5%     | Widest coverage            |
| Transak               | 100+ countries    | 1-5%       | React Native SDK available |
| Ramp Network          | EU, UK focus      | 0.49-2.49% | Competitive EU rates       |

**Recommendation**: Start with Stripe On-ramp + Transak as fallback.

**Tax reporting**: Crypto donations >$250 require written acknowledgment (US). If EnDAO/DAOs are NOT 501(c)(3), contributions are NOT tax-deductible. Issue clear language on receipts.

### Recurring Giving

- Use Stripe Subscriptions directly (not Apple/Google subscription billing for donations).
- Default to monthly, suggest amounts with anchoring ($10, **$25**, $50).
- Stripe Smart Retries for failed payment recovery.
- Offer "pause for 1 month" instead of cancel.

### Payment Architecture

```
EnDAO Mobile App (Expo/React Native)
├── Stripe PaymentSheet (Apple Pay + Google Pay)
├── Stripe Crypto On-ramp (US/UK/EU)
└── Transak fallback (broader coverage)
         │
         ▼
/api/payments/* (Next.js)
├── PaymentIntent creation
├── Webhook handling
├── Donation receipts
└── Subscription management
         │
    ┌────┼────┐
    ▼    ▼    ▼
 Stripe  Supabase  Treasury (Safe)
```

---

## 5. Build, Testing & CI/CD

### EAS Build Profiles

```json
// eas.json
{
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal",
      "env": {
        "APP_ENV": "development",
        "API_URL": "http://localhost:3000/api"
      }
    },
    "preview": {
      "distribution": "internal",
      "env": { "APP_ENV": "staging", "API_URL": "https://staging.endao.ai/api" }
    },
    "production": {
      "autoIncrement": true,
      "env": { "APP_ENV": "production", "API_URL": "https://endao.ai/api" }
    }
  }
}
```

### Code Signing

- **iOS**: EAS managed credentials (recommended). Apple Developer Program membership required.
- **Android**: Generate keystore once, store securely, upload to EAS. Never regenerate — lost keys require weeks-long Google Play support process.

### GitHub Actions CI/CD

```yaml
# .github/workflows/build-and-submit.yml
name: Build and Submit
on:
  push:
    tags: ['v*']
  workflow_dispatch:
    inputs:
      platform:
        type: choice
        options: [all, ios, android]
      profile:
        type: choice
        options: [development, preview, production]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: yarn }
      - run: yarn install --frozen-lockfile
      - uses: expo/expo-github-action@v8
        with: { eas-version: latest, token: '${{ secrets.EXPO_TOKEN }}' }
      - run: yarn test --ci
        working-directory: apps/mobile
      - run: eas build --platform ${{ inputs.platform || 'all' }} --profile ${{ inputs.profile || 'production' }} --non-interactive --no-wait
        working-directory: apps/mobile
```

Preview builds on PRs:

```yaml
# .github/workflows/preview.yml
on:
  pull_request:
    paths: ['apps/mobile/**', 'packages/shared-types/**']
```

### Testing Strategy

**Unit**: Jest + React Native Testing Library (consistent with web app)

**E2E: Maestro (recommended over Detox and Appium)**

| Tool        | Pros                                                      | Cons                   |
| ----------- | --------------------------------------------------------- | ---------------------- |
| **Maestro** | YAML-based, fast setup, cross-platform, visual assertions | Newer ecosystem        |
| Detox       | Deep RN integration                                       | Complex setup, slow CI |
| Appium      | Massive ecosystem                                         | Extremely slow, flaky  |

```yaml
# e2e/flows/create-proposal.yaml
appId: ai.endao.mobile
---
- launchApp
- runFlow: login.yaml
- tapOn: 'Proposals'
- tapOn: 'Create Proposal'
- inputText:
    id: 'proposal-title'
    text: 'Q1 Budget Allocation'
- tapOn: 'Submit for Review'
- assertVisible: 'Proposal created'
```

### Device Matrix (US/Western)

**iOS** (covers 95%+ of active users):

- iPhone 16 Pro, iPhone 15, iPhone 14, iPhone SE (3rd gen), iPhone 12

**Android**:

- Samsung Galaxy S24, Galaxy A54, Google Pixel 8, Pixel 7a, OnePlus 12

**Cloud testing**: Maestro Cloud for E2E, Firebase Test Lab for free Android smoke tests, BrowserStack for periodic full-matrix regression.

### OTA Updates (EAS Update)

```json
{
  "expo": {
    "updates": {
      "url": "https://u.expo.dev/YOUR_PROJECT_ID",
      "enabled": true,
      "checkAutomatically": "ON_LOAD",
      "codeSigningCertificate": "./code-signing/certificate.pem"
    },
    "runtimeVersion": { "policy": "fingerprint" }
  }
}
```

**OTA-updatable** (JS bundle): Component changes, business logic, styles, API endpoints, bug fixes, new screens
**Requires store release** (native): New native modules, app.json changes, native library versions, SDK upgrades

**CodePush is deprecated.** EAS Update is the clear successor for Expo projects.

### Performance Monitoring

**Sentry** for crashes + performance. Source maps uploaded automatically via EAS plugin.

**Crash rate thresholds**:

| Metric      | iOS          | Android   | Impact              |
| ----------- | ------------ | --------- | ------------------- |
| Crash rate  | < 1%         | < 1.09%   | Ranking, featuring  |
| ANR rate    | N/A          | < 0.47%   | Play Store warnings |
| Launch time | < 400ms warm | < 1s cold | Retention           |

**Automated rollout halt**: Monitor Sentry crash-free rate every 4 hours. Alert and halt rollout if below 99%.

### Release Management

**Phased rollouts**:

- iOS: 1% → 2% → 5% → 10% → 20% → 50% → 100% over 7 days
- Android: Start at 5%, manually increase

**Hotfix workflow**:

1. JS-only fix: `eas update --channel production --message "Hotfix: description"` — reaches users within minutes
2. Native fix: EAS Build → EAS Submit → Request expedited iOS review (typically 24 hours)

### App Size Targets

| Size       | Western Market Impact                   |
| ---------- | --------------------------------------- |
| < 30 MB    | Ideal                                   |
| 30-100 MB  | Acceptable                              |
| 100-200 MB | iOS cellular download warning at 200 MB |
| > 200 MB   | Avoid                                   |

Typical Expo 52 app with Hermes: 20-40 MB. Target under 50 MB.

---

## 6. Global Readiness (Appendix)

### "Build Now" Checklist — Cheap Now, Expensive Later

| Item                                               | Effort | Why Now                                         |
| -------------------------------------------------- | ------ | ----------------------------------------------- |
| Externalize all strings (i18n framework)           | Medium | Retrofitting across 100+ components is brutal   |
| Use `start`/`end` not `left`/`right` in all styles | Low    | Find-and-replace now while codebase is smaller  |
| `Intl.NumberFormat` for all numbers                | Low    | One utility function. Never hardcode separators |
| `Intl.DateTimeFormat` for all dates                | Low    | Store UTC, display local                        |
| Wrap currency display in `formatCurrency()`        | Low    | Trivial now, painful later                      |
| Flexible text layouts (no fixed widths on text)    | Low    | PR review habit                                 |
| Consent management system                          | Medium | Legal requirement for Africa + EU               |
| Account deletion cascade                           | Medium | Required by multiple privacy laws               |
| Single "Display Name" field (not first/last)       | Low    | Already likely in place                         |
| Abstract payment provider interface                | Low    | Just an interface/type definition               |

### i18n Framework Setup (Even English-only)

```typescript
// apps/mobile/src/i18n/index.ts
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import * as Localization from 'expo-localization';

i18n.use(initReactI18next).init({
  lng: Localization.getLocales()[0]?.languageCode ?? 'en',
  fallbackLng: 'en',
  resources: { en: { translation: require('./locales/en.json') } },
  interpolation: { escapeValue: false },
});
```

### Formatting Utilities

```typescript
// apps/mobile/src/utils/format.ts
import * as Localization from 'expo-localization';

export function formatNumber(value: number, locale?: string): string {
  const l = locale ?? Localization.getLocales()[0]?.languageTag ?? 'en-US';
  return new Intl.NumberFormat(l).format(value);
}

export function formatCurrency(
  amount: number,
  currencyCode: string,
  locale?: string
): string {
  const l = locale ?? Localization.getLocales()[0]?.languageTag ?? 'en-US';
  return new Intl.NumberFormat(l, {
    style: 'currency',
    currency: currencyCode,
  }).format(amount);
}

export function formatDate(
  date: Date | string,
  locale?: string,
  options?: Intl.DateTimeFormatOptions
): string {
  const l = locale ?? Localization.getLocales()[0]?.languageTag ?? 'en-US';
  const d = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat(l, options).format(d);
}
```

### RTL Support

- Use `start`/`end` instead of `left`/`right` everywhere: `marginLeft` → `marginStart`, `paddingRight` → `paddingEnd`
- `I18nManager.forceRTL()` requires app restart on iOS
- Icons that imply direction (arrows, back buttons) must flip; non-directional icons (home, settings) do not

### Text Expansion

| Language | Expansion vs English    |
| -------- | ----------------------- |
| German   | +30%                    |
| Finnish  | +30-40%                 |
| French   | +15-20%                 |
| Arabic   | +25%                    |
| Japanese | -30% (fewer characters) |
| Chinese  | -50%                    |

Use `flexShrink`, `flexWrap`, `numberOfLines` with ellipsis. Never set fixed widths on text-containing elements.

### Calendar Systems

Store all dates as UTC ISO 8601. Use `Intl.DateTimeFormat` with `calendar` option for display:

- Islamic (Hijri): `calendar: 'islamic'` for Middle Eastern locales
- Buddhist: `calendar: 'buddhist'` for Thailand (Gregorian + 543 years)
- Japanese Imperial: `calendar: 'japanese'` (rarely needed)

### Regional App Distribution — Skip These

- **China**: Crypto/DAO platforms are non-viable (regulatory ban). Engineering cost of removing Google dependencies is not justified.
- **Russia**: Sanctions compliance makes this legally risky.
- **Iran**: US sanctions make this legally impossible.
- **HarmonyOS NEXT**: No React Native support, minimal market share outside China.

Standard distribution (App Store + Google Play) covers all practical target markets.

### Global Privacy — Highest Common Denominator

Build to the strictest reasonable baseline:

1. Explicit consent for data collection (per-purpose)
2. Right to erasure (delete account + all data)
3. Data portability (machine-readable export)
4. Consent records with timestamps
5. DPAs with all processors
6. Privacy policy in local languages per market

Skip China (PIPL data localization) and Russia unless explicitly targeting those markets.

### CDN & Edge Strategy

- **Current stack** (Vercel + Supabase): Static assets fast globally via Vercel edge. Database is single-region (latency bottleneck).
- **Priority**: Supabase read replica in an African region when meaningful traffic exists.
- Governance operations (voting, proposals) are not latency-sensitive — 500ms round trip is acceptable.
- Real-time features (live vote counts) benefit most from edge optimization.

### Priority Matrix

**Do now** (low effort, high impact):

- i18n framework, logical style properties, Intl formatting, consent + deletion architecture

**Do when targeting market** (medium effort):

- M-Pesa/mobile money (Africa — already relevant)
- Supabase read replica
- RTL layout testing (MENA markets)

**Do not build** (unless forced):

- China data localization, HarmonyOS app, Russia/Iran distribution, multi-region database

---

## Key Differences: iOS/Western vs Android/African

| Aspect        | iOS / Western                             | Android / African                      |
| ------------- | ----------------------------------------- | -------------------------------------- |
| Payment       | Apple Pay dominant, IAP rules             | Mobile money, USSD, no IAP gatekeeping |
| Devices       | Uniform (iPhone 12-16), 4-8 GB RAM        | Extreme fragmentation, 1-3 GB RAM      |
| Network       | Reliable LTE/5G/Wi-Fi                     | Offline-first critical, 2G/3G          |
| App size      | Under 50 MB ideal                         | Under 15 MB critical                   |
| Auth          | Face ID / Touch ID expected               | PIN/pattern, SMS OTP                   |
| Notifications | Focus modes filter aggressively           | Largely unfiltered                     |
| Privacy       | ATT, privacy manifests, GDPR              | Less regulatory enforcement            |
| Store review  | Strict, 24-48 hour cycles                 | Less strict, faster                    |
| Background    | Severely limited by iOS                   | More permissive (foreground services)  |
| Updates       | Most users on latest 2 iOS versions       | Massive version fragmentation          |
| Accessibility | VoiceOver + Dynamic Type legally expected | TalkBack less commonly tested          |
| Currency      | USD, EUR, GBP — Stripe handles all        | Local currency complexity              |

---

_Research compiled January 30, 2026. Based on web research, official documentation, and current package ecosystem analysis._
