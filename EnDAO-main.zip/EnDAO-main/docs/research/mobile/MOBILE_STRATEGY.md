# EnDAO Mobile Strategy: Dual-Track MVP → Scale

> **Single source of truth** for mobile architecture, multi-market expansion, and development sequencing.

## Purpose

Defines EnDAO's mobile and multi-market expansion strategy as two parallel tracks (US/Western and Africa) sharing common infrastructure but diverging on UX, payments, connectivity, and device targets. Each track progresses independently from MVP to scale.

## Last Updated

2026-02-07

---

## Quick Start

```bash
# From monorepo root
yarn install

# Start mobile development
cd apps/mobile
yarn start      # Expo dev server
yarn ios        # iOS Simulator
yarn android    # Android Emulator
```

**Configuration**: Copy `.env.example` to `.env.local`, set `EXPO_PUBLIC_PRIVY_APP_ID` and API URL.

**Architecture**: `Mobile App → API Routes (/api/mobile/v1/*) → Service Layer → Supabase`. Mobile NEVER directly accesses Supabase.

---

## Implementation Status

| Phase                           | Status                     | Delivered                                                              |
| ------------------------------- | -------------------------- | ---------------------------------------------------------------------- |
| **Phase 0**: Monorepo           | ✅ COMPLETE (Dec 7, 2025)  | `@endao/shared-types`, workspace setup                                 |
| **Phase 1**: Core Foundation    | ✅ COMPLETE                | Auth, DAO list/detail, proposals, profile, settings, deep linking      |
| **Phase 2**: Signed Voting      | ✅ COMPLETE                | EIP-712 typed data signing, mobile API routes                          |
| **Phase 3**: Content & Creation | ✅ COMPLETE                | Discussions, DAO creation wizard, treasury view                        |
| **Phase 4**: Advanced Features  | ✅ COMPLETE                | Admin dashboard, activity feed, treasury signing, image upload         |
| **Phase 7**: Quality            | ✅ COMPLETE (Dec 16, 2025) | Console cleanup, offline caching, push notifications, badge management |

**What's Built (24 features)**: Auth, DAO list/detail, proposal list/detail, user profile (view/edit), settings, push notifications, offline caching, offline action queue, deep linking, theme system, signed voting (EIP-712), discussion screens, DAO creation, treasury view, member directory, avatar upload, DAO logo upload, activity feed, treasury signing, admin dashboard

**What's Pending for App Store**:

- EAS build config (`eas.json`, profiles, store metadata)
- Sentry React Native SDK
- PostHog React Native SDK
- Developer accounts (Apple/Google)

**Shared Foundation (Strategy Alignment)**:

- Market config schema (`market_configs` table, DAO columns)
- Currency formatting utility (`Intl.NumberFormat`)
- PaymentProvider interface (abstract Stripe)
- String externalization (key-based system)
- `@endao/shared-validators` package

---

## 1. Vision & North Star

EnDAO is building the institutional DAO layer for business — governance infrastructure that scales from community savings groups to enterprise networks. Our research shows two distinct markets with overlapping infrastructure but divergent user experiences:

- **US/Western**: Native app users on modern devices with reliable connectivity, expecting familiar fintech UX
- **Africa**: 1.4 billion people, 80%+ on Android, mobile money as default financial infrastructure, intermittent connectivity, devices with 3-4GB RAM

The research tells us the end state. We build toward it incrementally. Each track ships independently. Neither blocks the other.

---

## 2. What We Have Today

Honest inventory of what exists as of January 2026:

**Mobile app (`apps/mobile/`)**:

- Expo 52 scaffold with 8 screens
- Privy auth (email + SMS OTP)
- Push notifications (Expo Notifications)
- EIP-712 voting
- Basic AsyncStorage cache + offline queue
- React Navigation with bottom tabs

**Web app (`apps/web/`)**:

- Production Next.js 15 at endao.ai
- API routes that mobile already consumes (`/api/mobile/v1/*`)
- Stripe payments (USD only)
- Full governance: proposals, voting, treasury, membership
- Sentry + PostHog monitoring

**What does NOT exist** (as of Feb 2026):

- No EAS build config (`eas.json`) — required for App Store
- No Sentry/PostHog React Native SDKs — required for production monitoring
- No i18n or string externalization — prep for multi-language
- No payments on mobile — US Scale phase
- No market differentiation (all DAOs implicitly US/USD) — Shared Foundation
- No PWA (no service worker, no manifest) — Africa Track
- No `@endao/shared-validators` package — Shared Foundation
- No expo-sqlite/MMKV (using AsyncStorage) — US Hardening

---

## 3. Architecture: What's Shared, What Diverges

### Shared (build once, both tracks use)

- **Backend API routes** — `/api/mobile/v1/*` and `/api/payments/*`
- **Supabase schema + RLS** — same database, same security model
- **`@endao/shared-types`** — TypeScript types, `Intl` formatting utilities
- **`@endao/shared-validators`** — Zod schemas for forms and API validation
- **Auth** — Privy works for both (email, SMS OTP, wallet)
- **Core governance logic** — proposals, voting, membership, treasury views

### Diverges by track

| Concern        | US Track                     | Africa Track                                        |
| -------------- | ---------------------------- | --------------------------------------------------- |
| Platform       | Expo native app              | PWA first, native only if needed                    |
| Connectivity   | Online assumed               | Offline-first, 3 tiers (full/low-bandwidth/offline) |
| Payments       | Stripe                       | Flutterwave → M-Pesa → Orange Money                 |
| Device targets | iPhone 12+, flagship Android | Tecno/Infinix, 3-4GB RAM                            |
| App size       | <50MB fine                   | <30MB critical                                      |
| Onboarding     | Standard app onboarding      | Analogy-driven ("Like your Chama/Susu")             |
| Auth UX        | Biometrics + email           | SMS OTP primary, PIN fallback                       |
| Notifications  | Push                         | Push + SMS fallback                                 |
| Language       | English                      | English → French → Swahili                          |
| Sharing        | iOS/Android share sheet      | WhatsApp deep links                                 |

### What does NOT get shared

| Category      | Reason                                                                                           |
| ------------- | ------------------------------------------------------------------------------------------------ |
| UI components | Shadcn/Tailwind (web) vs React Native StyleSheet (mobile) — fundamentally different renderers    |
| Service layer | Services are server-only. Mobile calls API routes. Sharing would break the browser-safe boundary |
| Hooks         | Web hooks use Next.js router, SWR. Mobile hooks use React Navigation, native modules             |
| Navigation    | Web uses file-based routing. Mobile uses React Navigation stack/tab config                       |
| API client    | Web uses `useCSRFAPI` with CSRF tokens. Mobile uses bearer tokens                                |

---

## 4. Shared Foundation

Things to build once before either track ships. This is the minimum shared infrastructure — not a monolithic sprint.

| Task                        | Details                                                                                                                                |
| --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Market config schema        | Add `market_country`, `market_currency` to `daos` table. Create `market_configs` reference table. Backfill existing DAOs as `US`/`USD` |
| `PaymentProvider` interface | Define interface, wrap existing Stripe code as `StripePaymentProvider`. Even with only one implementation, this prevents coupling      |
| Currency formatting         | `Intl.NumberFormat` utility in `@endao/shared-types`. Replace all `$${amount}` patterns                                                |
| String key system           | Externalize English strings using key-based system (`t('proposals.vote_button')`). Not full i18n — just externalized keys              |
| Shared validators           | Create `@endao/shared-validators` with Zod schemas extracted from existing API route validation                                        |

---

## 5. US Track: MVP → Scale

### US MVP

Ship the existing scaffold as a real app. Goal: governance on your phone for US users.

- **EAS build config** — `eas.json`, app icons, splash screen, store listing metadata
- **Core governance flows** — browse DAOs, view proposals, cast votes, view treasury summary
- **Auth** — Privy (already done), email + SMS OTP
- **Push notifications** — already wired up via Expo Notifications
- **Monitoring** — Sentry React Native SDK, PostHog React Native SDK
- **Basic offline** — current AsyncStorage cache is fine for read-only MVP
- **Navigation** — React Navigation with bottom tabs (Home, DAOs, Notifications, Profile)

**Exit criteria**: App Store + Play Store submission. A US DAO member can browse, read proposals, and vote from their phone.

### US Hardening

Make it production-grade.

- **expo-sqlite** replacing AsyncStorage — Drizzle ORM for type-safe queries, MMKV for key-value (auth tokens, preferences)
- **Biometric security** — `react-native-biometrics` with Keystore/Secure Enclave key pair. Treasury operations require fresh biometric verification
- **Certificate pinning** — `network_security_config.xml` (Android) + `react-native-ssl-public-key-pinning` (cross-platform)
- **Testing** — Jest unit tests for sync logic, Maestro E2E for critical flows
- **Deep linking** — `endao.ai/dao/:slug` opens in app if installed
- **Custom sync engine** — outbox pattern: writes to local outbox table, background push when online, pull with `?since={last_sync_timestamp}`
- **Widgets** — iOS proposal countdown, treasury balance (nice-to-have)

### US Scale

- **Stripe in-app payments** — contributions, membership fees
- **EU/UK compliance** — Cookie consent banner (conditional on `market_config.requires_cookie_consent`), PostHog gated on consent, market configs for `GB`/`GBP`, `DE`/`EUR`, `FR`/`EUR`
- **Foldable/large screen** — mandatory for Google Play by August 2026. Responsive layouts, `react-native-safe-area-context`
- **Additional Western markets** — add rows to `market_configs`, create legal MDX files

---

## 6. Africa Track: MVP → Scale

### Africa MVP

PWA on existing Next.js. No native app needed yet. Goal: a Ghanaian community group can create a DAO and manage governance from their phone.

**First market: Ghana** — easiest regulatory path in Africa (GSMA #1 globally for mobile money regulation), English-speaking, MTN MoMo via Flutterwave, patterns transfer directly to Nigeria.

- **PWA baseline** — Serwist service worker, `manifest.json`, app shell caching. NetworkFirst strategy for API calls, precache for JS/CSS/critical images
- **Flutterwave payment integration** — `FlutterwavePaymentProvider` implementation, MTN MoMo for Ghana
- **Bandwidth optimization** — lazy-load below-fold components, WebP images with `<picture>` fallback, paginated API responses (`?limit=10` default)
- **Offline read caching** — governance data (proposals, votes, members) cached via Serwist
- **Offline write queue** — IndexedDB-backed queue for votes and comments, synced when online
- **Touch targets** — 56dp minimum for primary actions, high-contrast text (AAA 7:1 for body)

**Exit criteria**: A Ghanaian DAO can be created, members can browse proposals, vote, and contribute via mobile money — all from a phone browser with no app install.

### Africa Hardening

Expand to more markets and improve resilience.

- **Kenya + Nigeria market configs** — Kenya requires M-Pesa awareness (Flutterwave abstraction initially), Nigeria has mandatory data localization (monitor enforcement)
- **Connection quality detection** — adapt API payload size to 2G/3G/4G. Three tiers: full (4G+), low-bandwidth (3G, compressed responses, no images), offline (local cache only)
- **Data-saver mode** — text-only proposal previews, images loaded on tap, compressed API responses
- **String externalization** — prep for i18n by ensuring all UI text uses key-based system
- **Onboarding flow** — analogy-driven: "Like your Chama" (Kenya), "Like your Susu" (Ghana), "Like your Esusu" (Nigeria). Women are 60-80% of savings group participants — they are the primary design persona
- **WhatsApp sharing** — deep links for proposal sharing, invite links. WhatsApp is universal across SSA (except Ethiopia → Telegram)
- **SMS notifications** — via Africa's Talking as fallback when push notifications are unreliable

### Africa Native (only if PWA proves insufficient)

**Trigger conditions** (any one sufficient):

- PWA push notifications unreliable on target Android versions
- Biometric treasury approval needed (WebAuthn insufficient)
- Partner organizations require Play Store presence
- Offline write sync needs exceed IndexedDB queue reliability

When triggered:

- Full Expo app sharing API routes with web (no new backend)
- expo-sqlite + SQLCipher for encrypted local database
- Full sync engine (outbox pattern) with ~10 synced tables
- EAS Africa build profile — `build:africa` target <30MB APK, ProGuard aggressive mode
- FlashList for large proposal lists
- M-Pesa Daraja direct integration (Kenya) — lower fees, real-time confirmation vs Flutterwave abstraction

### Africa Scale

- **Full i18n** — `react-i18next` on both platforms with shared JSON files. Priority: French (Francophone Africa, ~300M speakers) → Swahili (East Africa, ~80M) → Arabic + RTL (Egypt) → Amharic + Ge'ez script (Ethiopia)
- **USSD/SMS voting** — for feature phone users and zero-data scenarios. Balance checks via USSD shortcodes
- **Orange Money** — Francophone Africa (17 countries, 110M+ subscribers). Separate from Flutterwave. Required for Senegal, Ivory Coast, Cameroon, DRC
- **Data residency** — Nigeria mandatory (NDPR), Kenya monitoring (DPA 2019). Evaluate Supabase regional projects or encrypted PII minimization
- **Fiat-only mode** — Egypt and Ethiopia ban/restrict crypto. Crypto terminology hidden, fiat-only UI. This is a first-class feature, not a degraded mode
- **Voice memo proposals** — voice-first culture across much of SSA. Proposals and discussion contributions via audio
- **Agent banking partnerships** — for cash-in/cash-out in areas with low mobile money penetration
- **Telebirr (Ethiopia)** and **InstaPay/Fawry (Egypt)** — standalone payment integrations for markets that justify individual investment

---

## 7. Foundations: Bake In From Day One

Zero-cost decisions that prevent rework on both tracks. These aren't features — they're habits.

| Foundation                                  | What                                                       | Why                                                                              |
| ------------------------------------------- | ---------------------------------------------------------- | -------------------------------------------------------------------------------- |
| `Intl.NumberFormat` / `Intl.DateTimeFormat` | Never hardcode `$` or date formats                         | Every market has different currency symbols and date conventions                 |
| CSS logical properties                      | `margin-inline-start` not `margin-left`                    | Free RTL support when Arabic is needed                                           |
| String keys                                 | `t('proposals.vote_button')` even with English-only values | Francophone Africa is 40% of SSA. French WILL be needed. Don't hardcode          |
| 56dp touch targets                          | Minimum for primary action buttons everywhere              | Good accessibility universally. No downside to larger targets                    |
| Android-first testing                       | Test on Android before iOS                                 | 80%+ of global target users are Android. Most Africa devices are low-end Android |
| DAO-level market config                     | Market lives on the org, not the user                      | A Kenyan DAO operates in KES regardless of where a member browses from           |

---

## 8. Research-Informed Design Principles

Distilled from the African markets deep-dive research. These inform the Africa Track primarily but several apply universally.

1. **"You already know how to run a DAO"** — Onboarding via familiar analogies. Chama (Kenya), Susu (Ghana), Esusu (Nigeria), Tontine (Francophone Africa). The concept of collective governance and pooled funds is ancient and universal in these markets
2. **Women are 60-80% of savings group participants** — They are the primary design persona, not a secondary audience. UI, onboarding, and trust signals should center their experience
3. **Mobile money IS the treasury** — M-Pesa, MTN MoMo, Orange Money aren't payment methods — they're the financial infrastructure. Treasury integration should feel as natural as checking an M-Pesa balance
4. **Voice-first culture** — Voice memos for proposals and discussions. Many users are more comfortable speaking than typing, especially in multilingual contexts
5. **Three connectivity tiers, not binary** — Full (4G+), low-bandwidth (3G, compressed), offline (cached). Most users experience all three in a single day
6. **Crypto banned/restricted in some markets** — Egypt and Ethiopia prohibit or restrict crypto. Fiat-only mode is a first-class feature. Don't assume crypto visibility is universal
7. **Platform assumptions vary** — WhatsApp is universal in SSA except Ethiopia (Telegram). Don't hardcode sharing channels
8. **OHADA Uniform Act** — Covers 17 francophone countries with one legal framework for business associations. Reduces legal complexity for Francophone Africa expansion
9. **"Three keys to the lockbox"** — Uganda VSLA analogy for multi-sig. The best explanation for non-technical users of why multiple approvals protect shared funds
10. **Market tiers for expansion planning**:
    - Tier 1 (established fintech): Kenya, South Africa, Rwanda
    - Tier 2 (large market, regulatory complexity): Nigeria, Ghana, Uganda
    - Tier 3 (language/payment barrier): OHADA zone (Francophone West Africa)
    - Tier 4 (restricted/unique infrastructure): Egypt, Ethiopia

---

## 9. Architectural Decisions

### 9a. Market Architecture

**Decision:** DAO-level market configuration using ISO 3166-1 alpha-2 country codes. `market_country` and `market_currency` columns on the `daos` table. A `market_configs` reference table holds per-market defaults.

**How market is assigned:** The DAO creator explicitly selects the country of operation during DAO creation ("Where does this organization primarily operate?"). This is a deliberate choice, not geolocation. A diaspora member in London can create a Kenya-market DAO. An NGO in the US can create a Nigeria-market DAO. The selection determines payment rails, default currency, legal documents, and feature availability — not who can join.

**Current state:** Not yet implemented. The `daos` table has no `market_country` or `market_currency` columns. All DAOs implicitly operate as US/USD. This is added as part of the Shared Foundation.

**Alternatives considered:**

- **Geolocation** — Rejected. VPNs make it unreliable. Creator intent matters more than physical location
- **User-level market** — Rejected. A DAO's treasury operates in one currency. Members don't choose their DAO's market
- **Separate deployments per region** — Rejected. Doubles infrastructure cost and fragments the codebase
- **RLS isolation by market** — Rejected. Cross-market DAOs are a valid future use case (diaspora organizations)

### 9b. Offline Storage (Mobile Native)

**Decision:** `expo-sqlite` with SQLCipher encryption. Drizzle ORM for type-safe queries. MMKV for key-value storage (auth tokens, preferences, feature flags).

**Alternatives considered:**

- **WatermelonDB** — Better built-in reactivity, but JSI adapter fragile across Expo SDK upgrades
- **AsyncStorage** — Slow (JSON serialization), no encryption, known data-wipe bug on Android
- **op-sqlite** — Fastest raw performance, less ecosystem support, no built-in encryption

**Caveat:** Drizzle ORM has a known memory leak in reactive queries (GitHub #4519). Avoid long-lived subscriptions; use explicit `query()` calls.

### 9c. Sync Strategy

**Decision:** Custom sync engine using outbox pattern for MVP. Evaluate PowerSync self-hosted when sync complexity exceeds ~10 tables or conflict resolution becomes non-trivial.

**How it works:**

1. Writes go to local `outbox` table with status `pending`
2. Background job pushes pending writes to API when online
3. Reads pull from API with `?since={last_sync_timestamp}` and upsert locally
4. Conflict resolution: last-write-wins for most entities; votes use server-authoritative merge (server rejects duplicates)

**Alternatives considered:**

- **PowerSync** — Excellent Postgres integration, but adds cloud dependency. FSL license converts to Apache-2.0 after 2 years
- **ElectricSQL** — No offline write support at time of evaluation
- **Replicache** — Client-side only, requires custom server integration

### 9d. App Size

**Decision:** Market-specific EAS build profiles. Africa APK target: <30MB. US/Western AAB target: <50MB.

Not a universal constraint. African markets have real per-MB data costs. US users on WiFi don't care about 50MB vs 80MB.

**Implementation:**

- `build:africa` — excludes heavy assets, ProGuard aggressive mode
- `build:us` — full asset set, standard optimization
- Shared: tree-shaking, Hermes bytecode (default in Expo 52)

### 9e. Touch Targets & Accessibility

**Decision:** 56x56dp minimum for primary action buttons everywhere. 44x44pt for secondary. AAA contrast (7:1) for body text, AA (4.5:1) for secondary/disabled.

Universal standard, not market-specific. Recommended by Praekelt Foundation and GSMA guidelines.

### 9f. Biometric Security

**Decision:** `react-native-biometrics` for native apps. Crypto-based authentication using Android Keystore / iOS Secure Enclave.

**Rejected:** `expo-local-authentication` — only confirms "yes, a fingerprint matched" without cryptographic proof. Insufficient for a financial application.

**Implementation:**

- On enrollment: generate RSA-2048 key pair, store public key on server
- On login: server sends challenge nonce, biometric unlock signs it, server verifies
- Treasury operations require fresh biometric verification

### 9g. Certificate Pinning

**Decision:** Both `network_security_config.xml` (Android native) AND `react-native-ssl-public-key-pinning` (cross-platform runtime). Defense in depth for a financial app.

**Pin rotation:** Pin backup key hash alongside active key. Rotate via OTA update before certificate expiry.

### 9h. Payment Architecture

**Decision:** `PaymentProvider` interface with per-provider implementations. Provider resolved from DAO's market config. Separate webhook routes per provider.

```
Client → POST /api/payments/create-intent { daoId, amount }
Server → dao.market_config → resolve provider → Stripe or Flutterwave
Server ← provider.createIntent(amount, currency)
Client ← { clientSecret, provider: "stripe" | "flutterwave" }
Client → renders provider-specific checkout UI
```

Webhook routes: `POST /api/webhooks/stripe`, `POST /api/webhooks/flutterwave`. Both normalize into shared `PaymentEvent` type.

### 9i. Internationalization (i18n)

**Decision:** Do NOT add i18n framework yet. Use `Intl.NumberFormat` and `Intl.DateTimeFormat` for locale-aware formatting now. CSS logical properties. Externalize all user-facing strings from day one using key-based system.

When a second language is needed (likely French for Francophone Africa), add `react-i18next` with shared JSON files in `packages/shared-i18n`.

**Priority languages:** French (~300M speakers) > Swahili (~80M) > Arabic + RTL (Egypt) > Amharic (Ethiopia).

### 9j. PWA for Africa Web

**Decision:** Serwist 9.5.x with `@serwist/next`. NetworkFirst for API calls. Precache for app shell. IndexedDB queue for offline writes with Background Sync as Chrome-only enhancement.

**PWA ships before native for Africa because:**

1. Zero install friction (critical for first-time DAO members)
2. Works on any device with a browser (including KaiOS)
3. No App Store review delays
4. Instant updates without user action
5. Shared codebase with web

**Caveat:** Serwist has known incompatibility with Turbopack. Use Webpack mode for builds if Next.js 16 defaults to Turbopack.

### 9k. Monorepo Shared Packages

| Package                       | Contents                                                         | Consumers                           |
| ----------------------------- | ---------------------------------------------------------------- | ----------------------------------- |
| `@endao/shared-types`         | TypeScript types, interfaces, enums, `Intl` formatting utilities | Web, Mobile, API routes             |
| `@endao/shared-validators`    | Zod schemas for forms and API validation                         | Web forms, Mobile forms, API routes |
| `@endao/shared-i18n` (future) | JSON translation files                                           | Web, Mobile                         |

### 9l. Platform Minimums

**Decision:** iOS 16.0 minimum. Android API 26 (Android 8.0) minimum. Material You conditional on Android 12+ (API 31).

Android API 26 covers ~95% of active devices globally, ~90% in Sub-Saharan Africa. Raising to API 28+ loses ~8% of African users.

---

## 10. Pan-African Market Architecture

### Market Clusters

| Cluster              | Countries                           | Payment                                          | Language                | Key Fact                                                                                         |
| -------------------- | ----------------------------------- | ------------------------------------------------ | ----------------------- | ------------------------------------------------------------------------------------------------ |
| **Anglophone West**  | Ghana, Nigeria                      | Flutterwave (MTN MoMo, cards, bank transfer)     | English                 | Ghana = easiest regulatory path. Nigeria = largest market, most complex regulation               |
| **East Africa**      | Kenya, Tanzania, Uganda, Rwanda     | M-Pesa (different APIs per country), Flutterwave | English, Swahili for TZ | M-Pesa Kenya (Safaricom) and Tanzania (Vodacom) are separate operators with different APIs       |
| **Francophone West** | Senegal, Ivory Coast, Cameroon, DRC | Orange Money, Wave, Flutterwave (partial)        | French required         | 40% of SSA. CFA franc pegged to Euro. OHADA Uniform Act covers 17 countries                      |
| **Southern Africa**  | South Africa                        | Stripe (cards, Apple Pay, Google Pay)            | English                 | Not a mobile money market. Bank cards dominant. POPIA (GDPR-level). Treat as Western-style       |
| **Ethiopia**         | Ethiopia                            | Telebirr (monopoly)                              | Amharic (Ge'ez script)  | Flutterwave/Paystack don't operate. Non-Latin alphabet. Crypto restricted. Telegram not WhatsApp |
| **North Africa**     | Egypt                               | InstaPay, Fawry                                  | Arabic + RTL UI         | Completely different payment infrastructure. Crypto banned. RTL UI redesign required             |

### Three integrations cover ~80% of SSA

1. **Flutterwave** — Anglophone Africa + some Francophone. Ghana, Nigeria, Kenya (M-Pesa via Flutterwave)
2. **Orange Money** — Francophone Africa. 17 countries, 110M+ subscribers
3. **M-Pesa Daraja** — Kenya direct integration when Flutterwave abstraction is insufficient

### Expansion Sequence

| Step | Market                                                | Rationale                                                                                    |
| ---- | ----------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| 1    | **Ghana**                                             | Easiest regulatory path. English. MTN MoMo via Flutterwave. Patterns transfer to Nigeria     |
| 2    | **Nigeria**                                           | Largest market (~220M). Same language, same provider. Complex regulation (data localization) |
| 3    | **Kenya**                                             | M-Pesa Daraja direct integration. Gateway to East Africa                                     |
| 4    | **East Africa** (Tanzania, Uganda, Rwanda)            | Similar to Kenya. M-Pesa Tanzania is Vodacom (separate API). Swahili helpful                 |
| 5    | **South Africa**                                      | Card-first. POPIA. High ARPU. Western-style. Stripe works                                    |
| 6    | **Francophone West** (Senegal, Ivory Coast, Cameroon) | French + Orange Money — two new capabilities simultaneously                                  |
| 7    | **Ethiopia / Egypt**                                  | Specialty markets. Unique payment + non-Latin script each                                    |

---

## 11. Regulatory & Data Protection

| Market                 | Law                      | Licensing                                        | Key Requirements                                                             |
| ---------------------- | ------------------------ | ------------------------------------------------ | ---------------------------------------------------------------------------- |
| **US**                 | State-level (CCPA in CA) | State money transmitter licenses                 | Varies by state. No single federal privacy law                               |
| **Ghana**              | Data Protection Act 2012 | Bank of Ghana e-money license (if holding funds) | Register with Data Protection Commission. Lightest in Africa                 |
| **Nigeria**            | NDPR 2019                | CBN PSP license                                  | **Mandatory data localization** — personal data must be in Nigeria           |
| **Kenya**              | Data Protection Act 2019 | CBK payment service provider license             | Monitor ODPC enforcement. May require in-country storage                     |
| **South Africa**       | POPIA                    | FSCA license                                     | GDPR-level with real enforcement                                             |
| **UK**                 | UK GDPR + DPA 2018       | FCA authorization                                | Post-Brexit UK GDPR. Cookie consent required                                 |
| **EU**                 | GDPR                     | Country-specific                                 | Cookie consent mandatory. Right to erasure. DPA with Supabase required       |
| **Francophone Africa** | Varies (lighter)         | Central bank (BCEAO for WAEMU)                   | CFA franc zone has unified monetary authority. French legal content required |

---

## 12. Technology Decisions Summary

| Category              | Choice                                   | Status                     | Alternative Considered                       | Notes                               |
| --------------------- | ---------------------------------------- | -------------------------- | -------------------------------------------- | ----------------------------------- |
| Local DB (mobile)     | expo-sqlite + Drizzle ORM                | Confirmed                  | WatermelonDB (fragile Expo plugin)           | Watch Drizzle #4519 memory leak     |
| Key-value (mobile)    | MMKV                                     | Confirmed                  | AsyncStorage (slow, data wipe bug)           | 30x faster reads                    |
| Sync engine           | Custom outbox pattern                    | MVP                        | PowerSync self-hosted (evaluate later)       | ~2-4 weeks for ~10 tables           |
| PWA framework         | Serwist 9.5.x                            | Confirmed                  | next-pwa (unmaintained)                      | Watch Turbopack compat              |
| Payment (US)          | Stripe                                   | Confirmed                  | —                                            | Already in production               |
| Payment (Africa)      | Flutterwave                              | Confirmed                  | Direct M-Pesa API (more work, less coverage) | Covers M-Pesa, cards, bank transfer |
| Payment (EU)          | Stripe (SEPA/iDEAL auto)                 | Confirmed                  | Separate provider                            | Stripe handles EU methods natively  |
| i18n framework        | Deferred                                 | —                          | react-i18next (when needed)                  | Use `Intl` APIs now                 |
| Biometric auth        | react-native-biometrics                  | Confirmed                  | expo-local-authentication (no crypto proof)  | Keystore/Secure Enclave backed      |
| Certificate pinning   | network_security_config + RN SSL pinning | Confirmed                  | Runtime-only (insufficient)                  | Defense in depth                    |
| Monorepo tooling      | yarn workspaces + Turborepo              | Confirmed                  | Nx (overkill)                                | Already in use                      |
| CI/CD (mobile)        | GitHub Actions + EAS Build               | Confirmed                  | Fastlane (less Expo integration)             | EAS manages signing                 |
| Monitoring            | Sentry + PostHog                         | Confirmed (both platforms) | —                                            | Already in use on web               |
| iOS minimum           | 16.0                                     | Confirmed                  | 15.0 (marginal gain)                         | ~95% active devices                 |
| Android minimum       | API 26 (8.0)                             | Confirmed                  | API 28 (loses ~8% Africa)                    | ~95% global, ~90% Africa            |
| UI framework (mobile) | React Native + Expo 52                   | Confirmed                  | Flutter (different language)                 | Already scaffolded                  |
| Navigation (mobile)   | React Navigation                         | Confirmed                  | Expo Router (less mature)                    | Industry standard                   |

---

## 13. Risk Register

| Risk                                        | Impact                                      | Likelihood              | Mitigation                                                                                                             |
| ------------------------------------------- | ------------------------------------------- | ----------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| Drizzle memory leak (#4519)                 | Mobile crashes on long sessions             | Medium                  | Avoid reactive subscriptions. Explicit queries. Monitor heap. Patch when fixed                                         |
| Serwist + Turbopack incompatibility         | PWA breaks on Next.js 16                    | Medium                  | Webpack mode for production builds. Track Serwist GitHub                                                               |
| MMKV Android issues (Expo 52)               | KV corruption on specific Android versions  | Low                     | Pin version. Test on physical devices. Encrypted AsyncStorage fallback                                                 |
| Supabase latency from Africa                | ~250ms RTT to US-East                       | High                    | Aggressive caching. PWA precache. Paginated responses. Evaluate regional read replicas if >400ms                       |
| Kenya data residency (DPA 2019)             | May require in-country data storage         | Medium                  | Monitor ODPC enforcement. Minimize PII. Anonymize analytics                                                            |
| Flutterwave API stability                   | Payment failures during outages             | Medium                  | Retry with exponential backoff. Alert on webhook failures. PayStack as backup                                          |
| Google Play foldable requirement (Aug 2026) | App rejected from Play Store                | High (deadline)         | Responsive layouts from day one. Schedule compliance review by June 2026                                               |
| Expo SDK upgrade breakage                   | Native module incompatibility               | Medium                  | Pin SDK per release. Test upgrades on branch. Budget 1 week per major upgrade                                          |
| Background Sync browser support             | Offline writes don't sync on Safari/Firefox | High (known)            | IndexedDB queue is primary. Background Sync is Chrome-only enhancement. Sync on next foreground                        |
| Nigeria data localization enforcement       | Must host data in-country                   | Medium                  | Monitor NITDA enforcement. Evaluate Supabase regional project or PII encryption/minimization                           |
| Crypto restrictions (Egypt/Ethiopia)        | App rejected or legally problematic         | High (in those markets) | Fiat-only mode as first-class feature. Hide all crypto terminology. Don't enter these markets until fiat-only is solid |

---

## 14. Appendix

### A. Database Schema (market_configs)

```sql
CREATE TABLE market_configs (
  country_code TEXT PRIMARY KEY,
  country_name TEXT NOT NULL,
  currency_code TEXT NOT NULL,
  currency_symbol TEXT NOT NULL,
  default_payment_provider TEXT NOT NULL DEFAULT 'stripe',
  supported_payment_providers TEXT[] NOT NULL DEFAULT '{stripe}',
  requires_cookie_consent BOOLEAN NOT NULL DEFAULT false,
  data_residency_notes TEXT,
  min_donation_amount INTEGER NOT NULL DEFAULT 100,
  max_donation_amount INTEGER NOT NULL DEFAULT 100000000,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO market_configs (country_code, country_name, currency_code, currency_symbol, default_payment_provider, supported_payment_providers, requires_cookie_consent, min_donation_amount) VALUES
  ('US', 'United States', 'USD', '$', 'stripe', '{stripe}', false, 100),
  ('GH', 'Ghana', 'GHS', 'GH₵', 'flutterwave', '{flutterwave}', false, 500),
  ('KE', 'Kenya', 'KES', 'KSh', 'flutterwave', '{flutterwave,mpesa_daraja}', false, 1000),
  ('NG', 'Nigeria', 'NGN', '₦', 'flutterwave', '{flutterwave}', false, 10000),
  ('ZA', 'South Africa', 'ZAR', 'R', 'stripe', '{stripe}', true, 500),
  ('GB', 'United Kingdom', 'GBP', '£', 'stripe', '{stripe}', true, 100),
  ('DE', 'Germany', 'EUR', '€', 'stripe', '{stripe}', true, 100),
  ('FR', 'France', 'EUR', '€', 'stripe', '{stripe}', true, 100);

ALTER TABLE daos
  ADD COLUMN market_country TEXT NOT NULL DEFAULT 'US' REFERENCES market_configs(country_code),
  ADD COLUMN market_currency TEXT NOT NULL DEFAULT 'USD';

ALTER TABLE donations
  ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD',
  ADD COLUMN payment_provider TEXT NOT NULL DEFAULT 'stripe';

ALTER TABLE treasury_transactions
  ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD';
```

### B. TypeScript Types (market)

```typescript
// packages/shared-types/src/market.ts

export interface MarketConfig {
  countryCode: string;
  countryName: string;
  currencyCode: string;
  currencySymbol: string;
  defaultPaymentProvider: PaymentProviderType;
  supportedPaymentProviders: PaymentProviderType[];
  requiresCookieConsent: boolean;
  dataResidencyNotes: string | null;
  minDonationAmount: number;
  maxDonationAmount: number;
  timezone: string;
}

export type PaymentProviderType = 'stripe' | 'flutterwave';

export type SupportedCountry =
  | 'US'
  | 'GH'
  | 'KE'
  | 'NG'
  | 'ZA'
  | 'GB'
  | 'DE'
  | 'FR';
```

### C. PaymentProvider Interface

```typescript
// src/lib/services/payment/payment-provider.interface.ts

export interface PaymentProvider {
  readonly type: PaymentProviderType;

  createPaymentIntent(params: {
    amount: number;
    currency: string;
    metadata: Record<string, string>;
  }): Promise<{ clientSecret: string; externalId: string }>;

  verifyWebhookSignature(payload: string | Buffer, signature: string): boolean;

  normalizeWebhookEvent(payload: unknown): PaymentEvent;
}
```

### D. Currency Formatting Utility

```typescript
// packages/shared-types/src/formatting.ts

export function formatCurrency(
  amount: number,
  currencyCode: string,
  locale?: string
): string {
  return new Intl.NumberFormat(locale ?? 'en', {
    style: 'currency',
    currency: currencyCode,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount / 100);
}

export function formatDate(
  date: Date | string,
  locale?: string,
  options?: Intl.DateTimeFormatOptions
): string {
  return new Intl.DateTimeFormat(locale ?? 'en', {
    dateStyle: 'medium',
    ...options,
  }).format(new Date(date));
}
```

### E. Legal Content Organization

```
docs/legal/
├── us/
│   ├── terms-of-service.mdx
│   └── privacy-policy.mdx
├── gh/
│   ├── terms-of-service.mdx
│   └── privacy-policy.mdx
├── ke/
│   ├── terms-of-service.mdx
│   └── privacy-policy.mdx
├── ng/
│   ├── terms-of-service.mdx
│   └── privacy-policy.mdx
├── za/
│   ├── terms-of-service.mdx
│   └── privacy-policy.mdx
├── gb/
│   ├── terms-of-service.mdx
│   └── privacy-policy.mdx
└── eu/
    ├── terms-of-service.mdx
    ├── privacy-policy.mdx
    └── cookie-policy.mdx
```

---

## 15. What This Document Supersedes

| Deprecated File                                          | Reason                                   |
| -------------------------------------------------------- | ---------------------------------------- |
| `docs/research/mobile/MOBILE_GAP_ANALYSIS_AFRICA.md`     | Findings incorporated into this strategy |
| `docs/research/mobile/MOBILE_GAP_ANALYSIS_US_WESTERN.md` | Findings incorporated into this strategy |
| `docs/research/mobile/MOBILE_GAP_RESOLUTION.md`          | All decisions finalized in Section 9     |

**Retained as background research archives:**

| File                                     | Purpose                                                                                  |
| ---------------------------------------- | ---------------------------------------------------------------------------------------- |
| `MOBILE_AFRICA_REFERENCE_ARCHIVE.md`     | Raw research on African mobile market constraints                                        |
| `MOBILE_US_WESTERN_REFERENCE_ARCHIVE.md` | Raw research on US/Western mobile market requirements                                    |
| `african-markets-comparison.md`          | In-depth 12-market African research (trust, governance, treasury, education, regulatory) |

---

## Appendix F: Push Notifications Implementation

### Architecture

**Service Layer** (`apps/mobile/src/services/notifications.ts`):

- `register()` — Register device with push token
- `unregister()` — Unregister on logout
- `getPreferences()` / `updatePreferences()` — Notification prefs
- `addNotificationResponseListener()` — Handle notification taps
- `getBadgeCount()` / `clearBadge()` — Badge management

**Hook Layer** (`apps/mobile/src/hooks/useNotifications.ts`):

- Auto-registers device when user logs in
- Auto-unregisters on logout
- Handles deep linking from notification taps
- Clears badge on notification tap

### Deep Linking

| Data Field   | Navigation Route |
| ------------ | ---------------- |
| `proposalId` | `/proposal/[id]` |
| `daoId`      | `/dao/[id]`      |

### Default Preferences

```typescript
{
  enabled: true,
  proposalCreated: true,
  voteReminders: true,
  proposalResults: true,
  membershipChanges: false
}
```

### Backend Endpoints

- `POST /api/mobile/v1/devices` — Register device
- `DELETE /api/mobile/v1/devices/:id` — Unregister device
- `GET /api/mobile/v1/notifications/prefs` — Get preferences
- `PATCH /api/mobile/v1/notifications/prefs` — Update preferences

### Configuration

```json
// app.json
{
  "notification": {
    "icon": "./assets/notification-icon.png",
    "color": "#0f172a"
  },
  "plugins": [
    [
      "expo-notifications",
      { "icon": "./assets/notification-icon.png", "color": "#0f172a" }
    ]
  ],
  "android": { "permissions": ["RECEIVE_BOOT_COMPLETED"] }
}
```

---

## Appendix G: Signed Voting (Mobile)

All mobile votes are cryptographically signed using Privy embedded wallets, matching web implementation.

### Flow

1. User selects vote option (For/Against/Abstain)
2. App creates `VoteMessage` (proposalId, daoId, choice, voter, strength, timestamp, nonce)
3. Privy Expo SDK signs via EIP-712 typed data (fallback: `personal_sign`)
4. Signed vote submitted to `POST /api/proposals/[id]/vote`
5. Server verifies signature and records vote

### Privy SDK Hooks

| Hook                 | Purpose                                |
| -------------------- | -------------------------------------- |
| `useSignTypedData()` | EIP-712 structured signing (preferred) |
| `useSignMessage()`   | `personal_sign` fallback               |
| `useWallets()`       | Access embedded wallet address         |

### Security

- **30-minute expiry**: Vote messages expire (prevents replay)
- **Nonce protection**: Unique nonce per vote
- **Wallet verification**: Server verifies wallet belongs to user

---

## Appendix H: Image Upload (Mobile)

Mobile uploads reuse web API endpoints with server-side processing.

### Flow

1. User taps "Change Photo" / "Upload Logo"
2. `expo-image-picker` opens camera roll/camera
3. User selects/captures image
4. App creates FormData with file + metadata
5. POST to `/api/upload/avatar` or `/api/upload/dao-logo`
6. Server validates (magic bytes, size, MIME type)
7. Server converts to WebP and generates responsive sizes
8. Server uploads to Supabase Storage
9. App updates state with new URL

### Specs

| Feature  | Avatar               | DAO Logo                  |
| -------- | -------------------- | ------------------------- |
| Max Size | 5MB                  | 5MB                       |
| Formats  | JPEG, PNG, WebP, GIF | JPEG, PNG, WebP, GIF      |
| Output   | WebP                 | WebP                      |
| Sizes    | Multiple responsive  | 64px, 128px, 256px, 512px |

---

_This document is the single source of truth for EnDAO's mobile and multi-market strategy. Update it here; do not create parallel documents._
