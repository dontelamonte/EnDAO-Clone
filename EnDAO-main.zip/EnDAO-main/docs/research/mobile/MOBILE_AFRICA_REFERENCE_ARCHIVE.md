# EnDAO Mobile Multi-Market Development Plan

**Date:** January 30, 2026
**Status:** Research Complete — Ready for Implementation Planning
**Research Completed:** Offline-First Architecture ✅ | Security & Privacy ✅ | Payments ✅ | Localization ✅ | Build/Testing ✅ | Allinka Integration ✅
**Scope:** Multi-market mobile app serving US and African user bases from a single codebase

---

## Current Codebase State

### What Exists (Solid Foundation)

- Expo 52 + React Native 0.76.6, New Architecture enabled
- 8 screens via Expo Router (auth, home, profile, settings, DAO/proposal detail)
- Privy auth (email/SMS/wallet OTP)
- API client that correctly routes through Next.js API (`/api/mobile/v1/*`) — mobile never touches Supabase
- Partial offline: AsyncStorage cache with TTLs, NetInfo network monitoring, offline queue for votes/profile updates
- Push notifications with deep linking, preferences, badge management
- EIP-712 signed voting with personal_sign fallback
- Shared types via `@endao/shared-types` monorepo package
- Centralized theme/design token system
- 28 TypeScript/TSX source files, ~140KB total

### What's Missing (Comprehensive)

#### Build Infrastructure

1. `eas.json` with US and Africa build profiles
2. Convert `app.json` → `app.config.ts` (dynamic, market-aware)
3. All asset files (icon, splash, adaptive-icon, notification-icon)
4. `google-services.json` for FCM
5. iOS certificates/provisioning profiles
6. CI/CD pipeline

#### Offline-First Upgrade

7. WatermelonDB integration (replace AsyncStorage cache for structured data)
8. Sync engine compatible with `/api/mobile/v1/*` endpoints
9. Conflict resolution strategy
10. Longer cache TTLs / persistent offline data

#### Bandwidth Optimization

11. Connection quality detection (not just online/offline)
12. Data-saver mode toggle
13. API payload compression (gzip)
14. Image optimization pipeline
15. Data usage tracking/display

#### Localization

16. `expo-localization` + `react-i18next` setup
17. String extraction from all 28 source files
18. Translation files for English, French, Swahili
19. RTL layout support for Arabic (later phase)
20. UI reviewed for text expansion

#### Payments

21. Flutterwave SDK for Africa (mobile money)
22. Stripe integration for US (card payments)
23. Market-aware payment routing
24. Shared payment layer for Allinka

#### Allinka Integration

25. Second API base URL or gateway
26. Shared auth mechanism
27. Education content screens
28. Unified navigation between EnDAO + Allinka features

#### Testing

29. Jest setup + unit tests for hooks/services
30. E2E framework (Detox or Maestro)
31. Low-end device test matrix

#### Production Readiness

32. Error reporting (Sentry)
33. Analytics (PostHog mobile SDK)
34. Feature flag system (PostHog or LaunchDarkly)
35. App Store / Play Store listings
36. Privacy policy / terms of service

#### SMS/USSD (Backend-Side)

37. Africa's Talking integration for SMS notifications
38. USSD menu backend (if adoption warrants)

#### Security, Privacy & Compliance

39. Data encryption at rest and in transit (beyond TLS)
40. GDPR compliance (EU users may interact via African diaspora)
41. Africa-specific data protection laws (Kenya Data Protection Act, Nigeria NDPR, South Africa POPIA)
42. Secure key/credential storage on device
43. Certificate pinning for API communications
44. Biometric authentication integration
45. Data minimization — collect only what's needed
46. Right to deletion / data portability
47. Audit logging for sensitive operations
48. PII handling for government partnership readiness
49. Secure offline data storage (encrypted SQLite)
50. Token refresh and session security
51. Input validation and sanitization on mobile
52. Dependency vulnerability scanning
53. Penetration testing readiness
54. Privacy policy per jurisdiction
55. Consent management framework
56. Data residency considerations (where data is stored geographically)
57. Secure push notification payloads (no PII in notification content)
58. Anti-tampering / app integrity checks
59. Secure deep linking validation

---

## Multi-Market Architecture (One Repo, Not Two)

The Expo monorepo handles both markets through three mechanisms:

### 1. EAS Build Profiles

Different build configurations from the same code:

- `us-production` — iOS + Android, standard APK/IPA
- `africa-production` — Android-focused, optimized APK size, lower minSdkVersion

### 2. Feature Flags (Runtime)

PostHog or equivalent, keyed to region/build variant:

- Data-saver mode default ON/OFF
- Payment provider (Stripe vs Flutterwave)
- USSD/SMS fallbacks
- Localization defaults

### 3. Market-Aware App Config

`app.config.ts` reads `MARKET=us|africa` environment variable to set:

- App name/bundle ID (different store listings)
- Default language
- Min SDK version
- Payment providers
- Default theme/branding

---

## Research Required Before Implementation

The following areas require thorough best-practice research before any code is written:

### Offline-First Architecture ✅ RESEARCH COMPLETE

#### Database Selection: WatermelonDB + MMKV

| Feature             | WatermelonDB                    | op-sqlite        | expo-sqlite      | MMKV            | Realm                     |
| ------------------- | ------------------------------- | ---------------- | ---------------- | --------------- | ------------------------- |
| **Type**            | Reactive ORM on SQLite          | Raw SQLite (JSI) | Raw SQLite (JSI) | Key-value store | Object database           |
| **Sync engine**     | Built-in (pull/push)            | None             | None             | None            | Atlas Device Sync (paid)  |
| **Reactivity**      | Full (observable queries)       | Manual           | Manual           | Manual          | Live objects              |
| **Expo 52 compat**  | Broken without community plugin | Works            | Native support   | Works           | Works but increases APK   |
| **Memory overhead** | Moderate (lazy loading)         | Low              | Low              | Very low        | High (zero-copy B+ trees) |

**Decision: WatermelonDB** for structured governance data (proposals, votes, members, treasury). Lazy-loads queries in <1ms even with 10k records. Observable queries auto-update vote counts and proposal statuses in UI. SQLite underneath for straightforward migrations.

**Decision: MMKV** alongside WatermelonDB for auth tokens, user preferences, cache TTL metadata. 30x faster than AsyncStorage, synchronous, battle-tested by WeChat (1B+ users).

**Decision: Do NOT use Realm** — increases APK size significantly, RAM overhead problematic on 3GB devices.

**Decision: Do NOT use AsyncStorage** — 6MB Android limit, known data wipe bug on budget devices at 4-6MB. Must be replaced entirely.

**⚠️ Expo 52 Compatibility:** WatermelonDB JSI adapter broken with RN 0.76 New Architecture ([GitHub #1892](https://github.com/Nozbe/WatermelonDB/issues/1892)). Fix: use [`@lovesworking/watermelondb-expo-plugin-sdk-52-plus`](https://github.com/LovesWorking/watermelondb-expo-plugin-sdk-52-plus) and enable `experimentalDecorators` in `tsconfig.json`.

**⚠️ Supply Chain Risk:** This plugin has a single anonymous maintainer with build-time access (Expo config plugin runs during `expo prebuild`). **Action required: fork into `@endao/watermelondb-expo-plugin`** before production use. Pin to the exact commit hash, audit the plugin source (~200 lines), and monitor upstream for security patches.

**PowerSync alternative noted:** Integrates directly with Supabase via Postgres WAL, handles sync backend automatically. Trade-off: paid service with restrictive license. WatermelonDB gives full control but requires building sync logic.

#### Sync Protocol: Per-Column Last-Write-Wins

**Decision: Do NOT use CRDTs.** Server-authoritative architecture (Supabase) makes CRDTs unnecessary complexity. WatermelonDB's built-in per-column LWW is the simplest robust approach.

WatermelonDB sync cycle:

1. **Pull**: Client sends `last_pulled_at` timestamp → server returns all changes since then
2. **Push**: Client sends local changes → server applies and returns conflicts
3. **Resolve**: Per-column merge — server wins EXCEPT for columns client changed since last sync

| Data Type         | Sync Strategy                     | Rationale                                                            |
| ----------------- | --------------------------------- | -------------------------------------------------------------------- |
| **Votes**         | Append-only, no conflict possible | Immutable once cast. Server rejects duplicates via unique constraint |
| **Proposals**     | Per-column LWW (default)          | Title/description/status are independent fields                      |
| **Member lists**  | Server-authoritative pull-only    | Membership changes require admin action                              |
| **Treasury info** | Read-only cache, no local writes  | Financial data from blockchain/Safe only                             |
| **Comments**      | Append-only with server ordering  | New comments append, edits use LWW on body                           |

#### Conflict Resolution: Proposal Edits

When two users edit the same proposal offline, per-column LWW resolves automatically (User A edits description, User B edits title → both preserved). If both edit the same field, last-to-sync wins. Store the losing version in `_draft_description` so users can manually reconcile. Show toast: "This proposal was updated by another member."

#### Cache Invalidation: SWR with Tiered TTLs

| Data Type               | TTL        | Strategy                          |
| ----------------------- | ---------- | --------------------------------- |
| Member lists            | 1 hour     | SWR                               |
| DAO settings/config     | 1 hour     | SWR                               |
| Proposal list           | 5 minutes  | SWR                               |
| Active proposal details | 2 minutes  | SWR + push notification           |
| Vote counts             | 30 seconds | SWR when viewing, push for active |
| Treasury balances       | 15 minutes | SWR                               |
| User profile            | 30 minutes | SWR                               |

Add 5-10% random jitter to TTLs to prevent thundering herd after push notifications.

#### Low-End Device Performance Mitigations

**Known issues:**

- Android significantly slower than iOS with WatermelonDB ([#1394](https://github.com/Nozbe/WatermelonDB/issues/1394))
- Initial sync can spike to 1-2GB memory ([#948](https://github.com/Nozbe/WatermelonDB/issues/948)) — WILL crash 3GB devices

**Required mitigations:**

1. **Paginated initial sync**: 500 records per batch, never full database at once
2. **WAL mode** for SQLite (reduces write lock contention)
3. **FlatList pagination**: Never load >20-30 items at once on budget devices
4. **Storage budget**: WatermelonDB target 20-50MB, MMKV <5MB, image cache <20MB with LRU eviction, total app footprint <100MB
5. **Storage pressure detection**: Check free disk before sync — skip if <500MB, essential-only if <1GB
6. **Must test on real hardware**: Tecno Spark, Infinix Smart, Samsung Galaxy A04 (no published MediaTek + 3GB RAM benchmarks exist)

#### Background Sync: expo-background-task

`expo-background-fetch` is deprecated. Use `expo-background-task` (Expo SDK 53+) with WorkManager (Android) / BGTaskScheduler (iOS):

- **Minimum interval**: 15 minutes (Android WorkManager hard minimum)
- **Single worker**: One background task per app on both platforms
- **No guarantees**: OS decides when to run; stops at <20% battery on iOS
- **Network-aware**: Skip background sync on 2G/3G (data cost concern for Africa)
- **Lightweight pull**: Background pulls only changed record IDs + timestamps; full content fetched when user opens app
- **Foreground sync on app open**: Real sync happens when user opens app; background just keeps data "warm"

If still on Expo 52 (not yet 53), use `expo-background-fetch` temporarily with same pattern.

#### Architecture Diagram

```
┌─────────────────────────────────────────┐
│              UI Layer                    │
│  React Native + Expo 52/53              │
├─────────────────────────────────────────┤
│         State Management                │
│  WatermelonDB observables (reactive)    │
│  MMKV (auth tokens, TTL metadata)       │
├─────────────────────────────────────────┤
│           Sync Layer                    │
│  WatermelonDB sync protocol             │
│  Per-column LWW conflict resolution     │
│  Paginated initial sync (500 records)   │
│  Delta sync for background updates      │
├─────────────────────────────────────────┤
│        Cache Invalidation               │
│  SWR pattern with tiered TTLs           │
│  MMKV stores last-sync timestamps       │
│  Push notifications for urgent updates  │
├─────────────────────────────────────────┤
│       Background Processing             │
│  expo-background-task (SDK 53)          │
│  15-min minimum interval                │
│  Network-aware (skip on 2G/3G)          │
│  Storage-aware (skip if <500MB free)    │
├─────────────────────────────────────────┤
│         Transport Layer                 │
│  REST API: /api/mobile/v1/sync/*        │
│  Compressed JSON payloads               │
│  Exponential backoff on failure          │
└─────────────────────────────────────────┘
```

#### Key Sources

- [WatermelonDB Sync Implementation](https://watermelondb.dev/docs/Implementation/SyncImpl)
- [WatermelonDB Expo 52 Issue #1892](https://github.com/Nozbe/WatermelonDB/issues/1892)
- [Community Expo 52+ Plugin](https://github.com/LovesWorking/watermelondb-expo-plugin-sdk-52-plus)
- [PowerSync + Supabase](https://www.powersync.com/blog/bringing-offline-first-to-supabase)
- [react-native-mmkv](https://github.com/mrousavy/react-native-mmkv)
- [expo-background-task Docs](https://docs.expo.dev/versions/latest/sdk/background-task/)
- [AsyncStorage 6MB Limit Issue](https://github.com/react-native-async-storage/async-storage/issues/83)
- [AsyncStorage Data Wipe Bug](https://github.com/react-native-async-storage/async-storage/issues/537)

### Bandwidth & Performance Optimization

- React Native performance on 3-4GB RAM Android devices
- Bundle size optimization for Expo/React Native
- API compression best practices (gzip, Brotli, Protocol Buffers)
- Image optimization for low-bandwidth (WebP, progressive loading, blur hashes)
- Background sync frequency tuning

### Security & Data Privacy ✅ RESEARCH COMPLETE

#### Certificate Pinning

Use [`react-native-ssl-public-key-pinning`](https://github.com/nickhirakawa/react-native-ssl-public-key-pinning) — pins public key hashes (SPKI SHA-256) rather than full certificates. Survives certificate renewal without app update. Verify pinning works by testing against a self-signed cert (should fail). Have a pin rotation strategy: include current + next certificate pin.

#### Encrypted Local Storage

- **Tokens/credentials**: `expo-secure-store` → iOS Keychain / Android EncryptedSharedPreferences
- **Database**: SQLCipher (via WatermelonDB's SQLite adapter) for encrypting governance data at rest
- **NEVER** store tokens in AsyncStorage (unencrypted)
- **Key management**: Derive encryption key from user's biometric-protected Keychain entry

#### Biometric Authentication: `expo-local-authentication`

Uses Biometric Prompt (Android) / FaceID+TouchID (iOS). Biometric data never leaves device secure hardware. EnDAO never processes biometric data directly.

**When to require biometric re-auth:**

| Operation                | Re-auth | Timeout           |
| ------------------------ | ------- | ----------------- |
| App unlock               | Yes     | 10 min inactivity |
| View treasury balance    | No      | —                 |
| Initiate treasury tx     | Yes     | Always            |
| Cast vote                | Yes     | Always            |
| Change security settings | Yes     | Always            |
| Export keys              | Yes     | Always            |
| View member PII          | Yes     | 5 min             |

iOS: Add `NSFaceIDUsageDescription` to `app.json`. Cannot test FaceID in Expo Go — requires dev build.

#### Session Security

| Token               | Lifetime   | Storage             | Purpose                  |
| ------------------- | ---------- | ------------------- | ------------------------ |
| Access token (JWT)  | 5-15 min   | In-memory only      | API auth                 |
| Refresh token       | 7-30 days  | `expo-secure-store` | Obtain new access tokens |
| Privy session token | Per config | `expo-secure-store` | Privy auth state         |

**Rules:** Token rotation (new refresh token with each access refresh). Revoke all refresh tokens on logout/password change. Use PKCE for OAuth2. Multi-device session management with remote revocation via push.

#### Push Notification Security

Research shows 11 of 21 secure messaging apps leaked PII to FCM. **Use push-to-sync pattern:**

```
Server → FCM/APNs: { "data": { "type": "new_proposal", "sync": true } }
App receives → fetches content via authenticated API → shows local notification
```

**Never include** names, emails, amounts, wallet addresses, or vote choices in push payloads.

| Notification Type | Visible Content                 | Fetch on Tap          |
| ----------------- | ------------------------------- | --------------------- |
| New proposal      | "New proposal in [DAO Name]"    | Title, details        |
| Vote reminder     | "Voting ends soon"              | Which proposal, tally |
| Treasury tx       | "Transaction requires approval" | Amount, recipient     |
| Member joined     | "New member in [DAO Name]"      | Name, email           |

#### App Integrity & Anti-Tampering

- **iOS**: Apple App Attest via [`@expo/app-integrity`](https://docs.expo.dev/versions/latest/sdk/app-integrity/) (iOS 14+, no Simulator) — use the official `@expo/` scoped package only (v0.1.9+), NOT community `expo-app-integrity`
- **Android**: Google Play Integrity API (returns device integrity verdicts including root/tamper flags)
- **Alternative**: Firebase App Check (`@react-native-firebase/app-check`) wraps both
- **Code obfuscation**: Hermes bytecode (default in RN 0.76+) compiles JS to bytecode; ProGuard/R8 for Android native; Jscrambler for commercial-grade obfuscation
- **LLM threat noted**: Attackers use LLMs to decode Hermes bytecode — additional layers recommended

#### African Data Protection Laws

| Country          | Law       | Authority | Breach Notification       | Cross-border                         | Penalties                                |
| ---------------- | --------- | --------- | ------------------------- | ------------------------------------ | ---------------------------------------- |
| **Kenya**        | DPA 2019  | ODPC      | 72 hours                  | Restricted; local copy required      | KES 5M or 1% revenue                     |
| **Nigeria**      | NDPA 2023 | NDPC      | 72 hours                  | Prohibited by default; requires SCCs | NGN 10M or 2% revenue; 1yr prison        |
| **South Africa** | POPIA     | SAIR      | ASAP (not just high risk) | Requires adequate protection         | ZAR 10M or 10% turnover; **10yr prison** |
| **Tanzania**     | PDPA 2022 | PDPC      | Required                  | Requires Commission permit           | Mandatory registration                   |
| **Uganda**       | DPPA 2019 | PDPO      | Required                  | Records required per transfer        | Extraterritorial (confirmed 2025)        |

**All jurisdictions require opt-in consent.** No opt-out is sufficient for EnDAO's use case (PII + financial).

**Kenya data residency**: Requires local copy of data. Must use a Supabase/hosting region with Kenya presence or establish data mirroring.

**Malabo Convention**: Only 16/55 AU states ratified. Cannot rely as unified framework — must comply per country.

**Common requirements across all:**

1. Registration with national authority
2. Consent before processing
3. Data Protection Officer appointment
4. DPIAs for high-risk processing
5. Breach notification (48-72 hours)
6. Cross-border transfer restrictions
7. Data subject rights (access, correction, deletion)

#### GDPR for Mobile (Diaspora Users)

| Right                      | Implementation                                                              |
| -------------------------- | --------------------------------------------------------------------------- |
| Right to Erasure (Art. 17) | In-app delete button. Delete server + local device + queue offline deletion |
| Data Portability (Art. 20) | Export JSON/CSV via API. Within 1 month.                                    |
| Consent                    | Active opt-in, no pre-ticked. Withdrawable. Granular per purpose.           |
| Breach Notification        | 72 hours to authority                                                       |

**Apple ATT required for iOS.** Gate PostHog/Sentry SDK initialization behind consent.

**DPAs needed with:** Supabase, Privy, Flutterwave, Expo Push/FCM, PostHog, Sentry.

#### Consent Management

Use CMP SDK (e.g., [Usercentrics React Native SDK](https://usercentrics.com/in-app-sdk/)):

- Geo-aware flows based on jurisdiction
- Granular consent (analytics, marketing, functional)
- Stored consent records for audits
- All target jurisdictions require opt-in

**Minimum age: 18** (governance/financial app). Simple age gate at onboarding.

#### Data Minimization

| Data            | Collect?                      | Justification                   |
| --------------- | ----------------------------- | ------------------------------- |
| Email           | Yes                           | Account identity, notifications |
| Phone number    | Only for mobile money         | Payment verification            |
| Full legal name | Only for KYC/treasury signers | Regulatory                      |
| Display name    | Yes                           | Governance participation        |
| Wallet address  | Yes                           | Core functionality              |
| Device ID       | Hashed only                   | Fraud prevention                |
| Location        | No                            | Not needed                      |
| Contacts        | No                            | Not needed                      |
| Biometric data  | Never stored by app           | OS-level only                   |

#### Dependency Security

**Shai-Hulud 2.0 attack (Nov 24, 2025)**: 796 npm packages compromised across PostHog, Zapier, Postman, and others — 20M+ weekly downloads affected. Worm spread via trojanized `preinstall` scripts that exfiltrated npm tokens and propagated to all packages the victim maintained. **PostHog was directly affected** — `posthog-js`, `posthog-node`, and `posthog-react-native` packages were all compromised. PostHog has since remediated with npm trusted publisher model (GitHub Actions → npm, no human token in the loop). Snyk advisory: [SHA1-Hulud](https://security.snyk.io/sha1-hulud-npm-supply-chain-incident-nov-2025).

**For government partnership contexts:** The PostHog incident must be documented in any security audit. PostHog's response was professional and fast (detected + remediated within hours), but the fact remains it happened. Self-hosting PostHog mitigates future npm-level supply chain risk for the analytics pipeline.

**Mitigations (hardened):**

1. `npm install --ignore-scripts`, explicitly allow-list trusted packages
2. Commit `yarn-lock.yaml`, use `--frozen-lockfile` in CI
3. **Add to `.npmrc`: `minimumReleaseAge=3d`** — blocks packages published < 3 days ago (catches most supply chain attacks)
4. Run `npx snyk test --all-projects` in CI
5. Add [Socket.dev](https://socket.dev) GitHub app (detects supply chain attacks in PRs)
6. **Pin exact versions** for all deps (no `^` or `~`) — use `yarn config set save-exact true`
7. Renovate/Dependabot for automated updates with lockfile verification
8. Strip `console.log` in production via `babel-plugin-transform-remove-console`
9. **Audit `preinstall`/`postinstall` scripts** in all direct dependencies before adding

#### Government Partnership Readiness

**Start with ISO 27001** (broader international recognition for African markets), then add SOC 2 Type II for US/enterprise. Budget 6-12 months for initial certification.

**Requirements:** Audit trails (partially addressed by blockchain), data sovereignty (Kenya local storage), RBAC with MFA, annual pen tests, incident response plan, business continuity documentation.

#### Incident Response

Design for strictest requirement: **48 hours from discovery to full notification**.

**Mobile-specific capabilities:**

1. Remote session revocation (revoke all refresh tokens)
2. Remote data wipe (push silent notification → local deletion)
3. Force app update (expo-updates OTA without app store review)
4. Kill switch (feature flag to disable treasury ops immediately)
5. Forensic logging (server-side audit logs for breach reconstruction)

#### Financial Data Security

Use Flutterwave hosted checkout — EnDAO is **SAQ-A** (simplest PCI level). Never let card numbers touch EnDAO servers or mobile code. Mobile money (M-Pesa, MTN MoMo) is server-to-server; user completes via USSD/STK push on their phone.

#### Priority Implementation Order

| Priority | Area                                              |
| -------- | ------------------------------------------------- |
| **P0**   | Encrypted storage (expo-secure-store + SQLCipher) |
| **P0**   | Consent management with geo-aware flows           |
| **P0**   | Biometric re-auth for votes and treasury          |
| **P1**   | Certificate pinning                               |
| **P1**   | Push-to-sync (no PII in notifications)            |
| **P1**   | Session security (Keychain tokens, rotation)      |
| **P1**   | Data residency compliance (Kenya local copy)      |
| **P2**   | App integrity (App Attest / Play Integrity)       |
| **P2**   | Dependency scanning in CI (Snyk)                  |
| **P2**   | Deep link security (Universal Links)              |
| **P2**   | Right to erasure / data portability               |
| **P3**   | ISO 27001 certification                           |
| **P3**   | Code obfuscation (Jscrambler)                     |
| **P3**   | Incident response plan documentation              |

#### Key Sources

- [OWASP Mobile Top 10](https://owasp.org/www-project-mobile-top-10/)
- [react-native-ssl-public-key-pinning](https://github.com/nickhirakawa/react-native-ssl-public-key-pinning)
- [expo-local-authentication](https://docs.expo.dev/versions/latest/sdk/local-authentication/)
- [@expo/app-integrity](https://docs.expo.dev/versions/latest/sdk/app-integrity/)
- [Kenya DPA 2019](http://kenyalaw.org/kl/fileadmin/pdfdownloads/Acts/2019/TheDataProtectionAct__No24of2019.pdf)
- [Nigeria NDPA Guide](https://www.cookieyes.com/blog/nigeria-data-protection-act-ndpa/)
- [South Africa POPIA](https://www.dlapiperdataprotection.com/index.html?t=law&c=ZA)
- [Snyk SHA1-Hulud Advisory](https://security.snyk.io/sha1-hulud-npm-supply-chain-incident-nov-2025)
- [React Native Security Docs](https://reactnative.dev/docs/security)

### Payment Integration ✅ RESEARCH COMPLETE

#### Flutterwave for Africa

**SDK Status:** `flutterwave-react-native` (v1.0.4, ~3 years stale). WebView-based (depends on `react-native-webview`). Flutterwave updates Node/Python SDKs actively but React Native SDK is minimally maintained.

**Recommendation:** Use official SDK for prototyping, but plan to use **API-direct approach** for production. WebView pattern is fine architecturally (delegates PCI scope), but stale SDK may hit Expo 52+ / New Architecture issues.

**Integration patterns (ranked):**

1. **WebView via official SDK** — Fastest prototype. `PayWithFlutterwave` component with `onRedirect`.
2. **API-direct + custom WebView** — Backend calls `POST /v3/payments` for checkout link, open in controlled WebView. More UX control.
3. **API-direct server-to-server** — For M-Pesa/mobile money. No WebView needed. Call `POST /v3/charges?type=mpesa`, receive webhook.

**Payment methods by country:**

| Country      | Cards         | Mobile Money          | Bank Transfer | M-Pesa    | USSD |
| ------------ | ------------- | --------------------- | ------------- | --------- | ---- |
| Kenya        | Visa/MC       | -                     | -             | Yes (KES) | -    |
| Nigeria      | Visa/MC/Verve | -                     | Yes (Nibss)   | -         | Yes  |
| South Africa | Visa/MC       | -                     | Yes           | -         | -    |
| Ghana        | Visa/MC       | MTN, Airtel, Vodafone | -             | -         | -    |
| Uganda       | Visa/MC       | MTN, Airtel           | -             | -         | -    |
| Tanzania     | Visa/MC       | -                     | -             | Yes       | -    |

**Fees:** Local cards 1.4-3.8% + ~$0.13. International 4.8%. M-Pesa 2.9%. Chargeback ~$4/dispute. No setup/monthly fee.

**Settlement:** Local T+1, International T+5, Mobile money within 24hrs.

#### M-Pesa STK Push Flow (Server-to-Server)

1. Backend calls `POST /v3/charges?type=mpesa` with phone, amount, currency KES, tx_ref
2. Flutterwave triggers STK Push (Lipa Na M-PESA) to customer's phone
3. API returns `status: "pending"`, `auth_model: "LIPA_MPESA"`
4. Customer sees native OS prompt, enters M-PESA PIN
5. Webhook fires to your callback URL
6. Verify via `GET /v3/transactions/:id/verify`

**Customer never leaves your app.** STK push is a native SIM toolkit prompt.

**UX patterns African users expect:**

- Phone number as primary identifier (not email)
- Amount confirmation before triggering STK push
- "Waiting for M-PESA..." screen with ~60s countdown
- Manual "I've completed payment" fallback button
- Receipt/transaction code display

**Timeout handling:** STK push timeout 1-3 min. Error 1032 = no response. Never send duplicate STK pushes — wait 2-3 min for expiry. Show "Payment timed out. Try again?" with retry.

#### Stripe for US Market

[`@stripe/stripe-react-native`](https://github.com/stripe/stripe-react-native) — **actively maintained** by Stripe. New Architecture support from v0.45.0. Use Expo config plugin for EAS Build (merchantIdentifier for Apple Pay, enableGooglePay). Android requires compileSdkVersion 34 + Kotlin 2.x+.

**Supports:** Card (Visa/MC/Amex), ACH, Apple Pay, Google Pay, Link (1-click).

**Stripe Connect for marketplace:** "Collect then transfer" model for service provider payments. Connected Accounts for providers (Stripe handles KYC). `application_fee_amount` for platform fees.

**Stripe Crypto Onramp:** React Native supported via Embedded Components. Stripe is merchant of record (handles fraud, disputes, KYC, sanctions). Requires separate onramp application (~48hr review).

#### Provider Abstraction Pattern

```typescript
interface PaymentProvider {
  createPaymentIntent(params: PaymentParams): Promise<PaymentIntent>;
  verifyPayment(reference: string): Promise<PaymentStatus>;
  handleWebhook(payload: unknown, signature: string): Promise<WebhookResult>;
  refund(transactionId: string, amount?: number): Promise<RefundResult>;
}

// Region-based routing
function resolveProvider(currency: string): PaymentProvider {
  const africaCurrencies = ['KES', 'NGN', 'ZAR', 'GHS', 'UGX', 'TZS', 'RWF'];
  return africaCurrencies.includes(currency)
    ? new FlutterwavePaymentProvider()
    : new StripePaymentProvider();
}
```

Build this abstraction from day one so all phases plug into the same architecture. Unified `payment_transactions` table regardless of provider.

#### PCI DSS Scope

Using Stripe SDK or Flutterwave WebView checkout = **SAQ A** (simplest, ~22 questions). Card numbers never touch your servers. Flutterwave is Level 1 PCI-DSS certified + ISO 27001.

#### Mobile Money Fraud Patterns

- **SIM swap attacks**: Verify phone ownership at registration, monitor device changes
- **Social engineering**: Always show amount + recipient clearly before STK push
- **Replay attacks**: Unique `tx_ref` per transaction, never reuse

#### Money Transmission Licensing

**Critical:** If EnDAO only facilitates payments (donations flow directly to DAO treasury via processor), you likely fall under **payment processor exemption**. If holding/pooling/transferring funds between users, you may need MTL.

| Jurisdiction | License                       | Capital Required        |
| ------------ | ----------------------------- | ----------------------- |
| US           | Money Transmitter (per state) | Varies                  |
| Kenya        | Payment SP                    | KES 5M (~$45K)          |
| Nigeria      | PSSP (gateway)                | N100M (~$69K)           |
| South Africa | FSP                           | $5K-10K app, 4-8 months |

**Recommendation:** Structure as platform facilitating payments, not custodian. Consult fintech attorney before launch.

#### Offline Payment Considerations

Payments require real-time authorization — cannot execute offline. But CAN:

1. Queue intent locally (amount, purpose, recipient)
2. Execute when online — "Payment will process when you're back online"
3. Only safe for non-time-sensitive (donations, membership), not marketplace

**USSD fallback (Nigeria):** Flutterwave generates USSD string customer dials (works without internet). 70% of instant payment transactions in sub-Saharan Africa use USSD.

#### Implementation Phases

1. **US Market**: Stripe RN SDK — cards, ACH, Apple/Google Pay
2. **Kenya**: Flutterwave API-direct for M-Pesa (server-to-server STK push)
3. **Nigeria**: Flutterwave cards, bank transfer, USSD
4. **Crypto bridge**: Stripe Crypto Onramp for fiat→crypto donations
5. **Marketplace**: Stripe Connect (US), Flutterwave sub-accounts (Africa)

#### Key Sources

- [Flutterwave M-PESA API](https://developer.flutterwave.com/v3.0/docs/m-pesa)
- [Flutterwave Mobile Money](https://developer.flutterwave.com/docs/mobile-money)
- [Flutterwave Webhooks](https://developer.flutterwave.com/docs/webhooks)
- [Stripe React Native SDK](https://docs.stripe.com/sdks/react-native)
- [Stripe Crypto Onramp](https://docs.stripe.com/crypto/onramp)
- [Stripe Connect Marketplace](https://docs.stripe.com/connect/marketplace?platform=react-native)
- [Flutterwave USSD API](https://developer.flutterwave.com/docs/ussd)
- [Offline-First Fintech in Africa](https://financeinafrica.com/insights/offline-first-fintech-without-internet/)

### Localization & Accessibility ✅ RESEARCH COMPLETE

#### Framework: react-i18next + expo-localization + i18next

Best ecosystem, namespace support, lazy loading, ICU plugin, Expo 52 confirmed. `i18n-js` is legacy. `expo-localization` only detects locale — use alongside react-i18next, not alone.

**Namespace organization:**

```
src/i18n/locales/{lang}/
  common.json       # Buttons, labels, errors, nav
  auth.json          # Login, signup, wallet
  governance.json    # Proposals, voting, quorum
  treasury.json      # Transactions, balances, multi-sig
  notifications.json # Push, in-app, email prefs
```

**Lazy loading:** `i18next-resources-to-backend` with dynamic `import()` — only active language + requested namespaces loaded. Critical for data-conscious users.

**Pluralization:**

| Language | Forms                                    | Notes                   |
| -------- | ---------------------------------------- | ----------------------- |
| English  | 2 (one, other)                           | Standard                |
| French   | 2 (one, other)                           | 0 is singular in French |
| Swahili  | 2 (one, other)                           | Standard                |
| Arabic   | **6** (zero, one, two, few, many, other) | Must provide all 6      |

Use i18next native suffixes. Add `i18next-icu` only if needed for nested plurals/gender — adds bundle weight.

**Bundle translations in APK** — translation JSON files are tiny (~5-50KB per language per namespace, total <500KB for 4 languages x 5 namespaces). Do NOT download over network. Use OTA updates for corrections only.

#### RTL Layout for Arabic — Build From Day One

Retrofitting RTL is significantly more expensive than building with it from the start.

**Mandatory style rules:**

- NEVER: `paddingLeft/Right`, `marginLeft/Right`, `left/right`, `textAlign: 'left'/'right'`
- ALWAYS: `paddingStart/End`, `marginStart/End`, `start/end`, `textAlign: 'auto'`

**Known issues (Expo 52 / RN 0.76):**

- iOS requires full app restart for RTL changes (fixed in RN 0.79+)
- `I18nManager.forceRTL()` requires `Updates.reloadAsync()`
- Expo Router Drawer reversed in dev mode (GitHub #38545)

**RTL pitfalls:** Flip directional icons conditionally (`scaleX: -1`), reverse horizontal animations, replace absolute `left/right` with `start/end`, test every third-party component.

**No extra library needed** — React Native's built-in `I18nManager` + logical properties handles everything.

#### Translation Workflow

**TMS: Crowdin** — Word-based pricing (free tier available), community translation support (matters for Swahili), GitHub Action sync, React Native SDK with OTA.

**Swahili quality:** Do NOT rely on MT alone. Use MT as first draft, mandatory human review by native speaker from target country (Kenyan vs Tanzanian Swahili differ). Create governance term glossary before translation begins. Source translators via Sawatech (Africa/MENA specialists, ISO 17100) or university linguistics departments.

**Workflow:** Developer writes English → GitHub push → Crowdin syncs new keys → Translators work (MT pre-fill + human review) → Crowdin opens PR with translated JSON → Developer merges → Ships in next build.

#### Cultural Adaptation

**Date formatting:** Use `Intl.DateTimeFormat` with correct locale tags. Install `@formatjs/intl-datetimeformat` + `@formatjs/intl-numberformat` polyfills for Android (incomplete Intl support).

| Region                  | Date Format                          | Currency Format              |
| ----------------------- | ------------------------------------ | ---------------------------- |
| Kenya/Nigeria (English) | DD/MM/YYYY                           | KSh 1,000.00 / ₦1,000.00     |
| South Africa            | YYYY/MM/DD                           | R 1 000,00 (space thousands) |
| Francophone Africa      | DD/MM/YYYY                           | 1 000 CFA                    |
| Arabic North Africa     | DD/MM/YYYY (Eastern Arabic numerals) | varies                       |

**Name formatting:** Some East African cultures use patronymic naming. Use single "Full Name" field or flexible name fields. Don't assume family-name/given-name structure.

#### Text Expansion

| Language | vs English    | Impact                            |
| -------- | ------------- | --------------------------------- |
| Swahili  | 20-30% longer | Buttons overflow, labels truncate |
| French   | 15-30% longer | Similar                           |
| Arabic   | 0-20% shorter | Excess whitespace                 |

**Rules:** Never use fixed widths on text. Use `flexShrink: 1` + `flexWrap: 'wrap'`. Allow `numberOfLines={2}` in tight spaces. Test with pseudo-localization (accented characters + padding reveals truncation and untranslated strings).

**Fonts:** Latin (English/French/Swahili) — system fonts sufficient. Arabic — consider bundling Noto Sans Arabic for consistent cross-platform rendering.

#### Accessibility for Agricultural Workers

**Touch targets:** **56x56dp minimum** for primary actions (calloused hands, outdoor use). 12dp minimum spacing between interactive elements.

**Color contrast:** **WCAG AAA (7:1 ratio)** for body text — outdoor sunlight washes screens. Dark text on light backgrounds more readable in sunlight.

**Low-literacy adaptations:**

- Icons alongside ALL text labels (not as replacements)
- `expo-speech` for text-to-speech (read proposals aloud)
- `expo-haptics` for tactile feedback on actions
- Avoid ALL CAPS (screen readers spell letter by letter)
- Simple, short sentences in all translations

**Accessibility props on every interactive element:**

```typescript
accessibilityRole="button"
accessibilityLabel={t('governance:submit_proposal')}  // Translated
accessibilityHint="Double tap to submit"
accessibilityState={{ disabled: isSubmitting }}
```

**Linting:** `eslint-plugin-react-native-a11y` (extend `plugin:react-native-a11y/all`).

#### Fallback Language Chain

```
sw → en, fr → en, ar → en, default → en
```

Log missing keys in dev. Set translation coverage thresholds per release: 90%+ French, 70%+ Swahili (progressive rollout).

#### Key Sources

- [Expo Localization Docs](https://docs.expo.dev/guides/localization/)
- [react-i18next Multiple Translation Files](https://react.i18next.com/guides/multiple-translation-files)
- [i18next Plurals](https://www.i18next.com/translation-function/plurals)
- [React Native I18nManager](https://reactnative.dev/docs/i18nmanager)
- [GeekyAnts RTL Guide](https://geekyants.com/blog/implementing-rtl-right-to-left-in-react-native-expo---a-step-by-step-guide)
- [React Native Accessibility](https://reactnative.dev/docs/accessibility)
- [Crowdin](https://crowdin.com/)
- [Sawatech African Languages](https://sawa-tech.com/languages/)

### Testing, Build, Performance & Monitoring

#### APK Size Optimization (Target: <30MB)

- **AAB format** for Play Store (Google generates optimized APKs per device)
- **APK format** for direct distribution in Africa (sideloading is common)
- Use **arm64-v8a + armeabi-v7a** for Africa APK, arm64-v8a only for US
- **ProGuard/R8** shrinking enabled via `expo-build-properties`:
  ```json
  [
    "expo-build-properties",
    {
      "android": {
        "enableProguardInReleaseBuilds": true,
        "enableShrinkResourcesInReleaseBuilds": true
      }
    }
  ]
  ```
- **WebP images** (30% smaller than PNG, 25-34% smaller than JPEG)
- **Hermes bytecode** — non-negotiable for budget device performance:
  - Eliminates JS parsing/compilation on device (3-8 seconds saved on Tecno Pop 7)
  - Memory-mapped bytecode via `mmap()` — doesn't load entire bundle into RAM
  - 60% faster cold starts vs JSC
- **Known Hermes issues (Expo 52)**:
  - Limited Proxy support — MobX `observable` may need config changes (Immer works fine)
  - No full ICU — need `intl-pluralrules` polyfill for African locale formatting
  - BigInt supported as of RN 0.76 (matters for blockchain ops)
  - Source maps require Hermes-specific `.hbc.map` uploads to Sentry

#### Performance on Low-End Devices (3-4GB RAM Android)

**Memory target: <150MB app usage**

- **FlashList** (not FlatList) — recycles views, ~50% less memory, maintains 60fps where FlatList drops to 30-40fps:
  ```tsx
  <FlashList
    data={proposals}
    renderItem={renderProposal}
    estimatedItemSize={120}
    drawDistance={250}
  />
  ```
- **expo-image** (backed by SDWebImage/Coil) — handles disk/memory caching, progressive loading, blurhash placeholders
- **Lazy loading** with `React.lazy()` + `Suspense` for non-critical screens
- **Native driver animations** — always `useNativeDriver: true` for Animated API, or Reanimated 3 worklets
- **Move heavy computation off JS thread** — crypto operations to native modules, large `JSON.parse` to chunked/streamed
- **`React.memo`** for expensive list items and FlashList `renderItem`; skip for cheap components (memo overhead exceeds render cost)

**Startup time targets:**

| Phase                        | Target             | Notes                               |
| ---------------------------- | ------------------ | ----------------------------------- |
| Cold start to interactive    | < 3 seconds        | Hermes bytecode helps most          |
| First meaningful paint       | < 1.5 seconds      | Show skeleton/splash immediately    |
| Network-dependent content    | < 5 seconds on 3G  | Cache aggressively, show stale data |
| App download (first install) | < 60 seconds on 3G | 30MB APK ≈ 55s at 550kbps           |

**Startup optimization:**

- `expo-splash-screen` to hold splash until first screen ready (prevents blank white screen)
- Defer analytics, error reporting, feature flags AFTER first screen via `InteractionManager.runAfterInteractions()`
- Minimal initial route — show cached data, then refresh

**Profiling tools:**

1. React Native Perf Monitor (shake device > Show Perf Monitor)
2. `npx react-devtools` Profiler tab for slow renders
3. Android Studio Profiler via USB for CPU/memory/network
4. Hermes sampling profiler for JS thread hotspots

#### Unit Testing: Jest + React Native Testing Library

```bash
npx expo install jest-expo @testing-library/react-native @testing-library/jest-native
```

`jest.config.js`:

```javascript
module.exports = {
  preset: 'jest-expo',
  setupFilesAfterSetup: ['@testing-library/jest-native/extend-expect'],
  transformIgnorePatterns: [
    'node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@sentry/react-native|native-base|react-native-svg)',
  ],
  moduleNameMapper: { '^@/(.*)$': '<rootDir>/src/$1' },
};
```

Test hooks that call APIs (matching EnDAO's browser-safe architecture):

```tsx
import { renderHook, waitFor } from '@testing-library/react-native';
import { useProposals } from '@/hooks/use-proposals';
jest.mock('@/lib/api-client', () => ({
  apiClient: { get: jest.fn().mockResolvedValue({ data: mockProposals }) },
}));
test('useProposals fetches proposals for a DAO', async () => {
  const { result } = renderHook(() => useProposals('dao-123'));
  await waitFor(() => expect(result.current.loading).toBe(false));
  expect(result.current.proposals).toHaveLength(3);
});
```

#### E2E Testing: Maestro (Clear Winner for Expo)

| Tool        | Expo Managed              | Setup Complexity | Reliability    | Community    |
| ----------- | ------------------------- | ---------------- | -------------- | ------------ |
| **Maestro** | Full support              | Low (YAML flows) | High           | Growing fast |
| Detox       | Requires eject/dev client | High             | Medium (flaky) | Plateaued    |
| Appium      | Works but slow            | Very high        | Medium         | Legacy       |

**Why Maestro:** No code instrumentation, works with Expo dev builds and production APKs, YAML-based tests, built-in `toggleAirplaneMode` for offline testing, `maestro cloud` device farm, recommended by Expo docs and RN consultancies (Infinite Red, Callstack).

```yaml
# Example Maestro test
appId: com.endao.app
---
- launchApp
- tapOn: 'Sign In'
- inputText:
    id: 'email-input'
    text: 'test@endao.ai'
- tapOn: 'Continue'
- assertVisible: 'My DAOs'
```

**Offline E2E test:**

```yaml
- launchApp
- tapOn: 'Proposals'
- assertVisible: 'Cached proposals'
- runScript: 'adb shell svc wifi disable && adb shell svc data disable'
- tapOn: 'Vote Yes'
- assertVisible: 'Vote queued'
- runScript: 'adb shell svc wifi enable'
- assertVisible: 'Vote submitted'
```

#### Device Testing

**Cloud device farms:**

| Service                 | Tecno/Infinix/Itel                    | Pricing                 | Notes                        |
| ----------------------- | ------------------------------------- | ----------------------- | ---------------------------- |
| **BrowserStack**        | Yes (Tecno Spark, Infinix Hot, Camon) | $99/mo                  | Best African device coverage |
| Firebase Test Lab       | Limited (some Samsung budget)         | Free tier: 10 tests/day | Good for Pixel/Samsung       |
| Samsung Remote Test Lab | Galaxy A-series                       | Free                    | Samsung only                 |

**Physical test lab (~$250 total):**

1. **Tecno Spark 20C** (~$70) — Unisoc CPU, 3GB RAM, 720p — entry-level user
2. **Infinix Hot 40i** (~$90) — MediaTek Helio G36, 4GB RAM — mid-range user
3. **Samsung Galaxy A15** (~$90) — MediaTek Dimensity 6100+, 4GB RAM — aspirational user

Buy from Jumia or Amazon (available internationally).

**Network condition simulation:**

```bash
# 3G profile: 750kbps down, 250kbps up, 200ms latency
# Use Charles Proxy or mitmproxy for throttling
adb shell tc qdisc add dev wlan0 root tbf rate 750kbit burst 32kbit latency 200ms
```

#### Security Testing

- **MobSF** (Mobile Security Framework): Open source, static analysis. Upload APK for insecure storage, hardcoded secrets, weak crypto checks:
  ```bash
  docker run -it --rm -p 8000:8000 opensecurity/mobile-security-framework-mobsf:latest
  ```
- **OWASP ZAP**: Dynamic analysis — proxy app traffic through ZAP for API vulnerability scanning
- **Expo-specific checks**: Verify `expo-secure-store` for tokens (not AsyncStorage), no sensitive data in `expo-constants`

#### CI/CD: GitHub Actions + EAS Build

```yaml
# .github/workflows/mobile-build.yml
name: Mobile Build & Test
on:
  push:
    branches: [main]
    paths: ['apps/mobile/**']
  pull_request:
    paths: ['apps/mobile/**']

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: 'yarn' }
      - run: yarn install --frozen-lockfile
      - run: yarn --filter mobile test
      - run: yarn --filter mobile type-check

  build-preview:
    needs: test
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: 'yarn' }
      - uses: expo/expo-github-action@v8
        with: { eas-version: latest, token: '${{ secrets.EXPO_TOKEN }}' }
      - run: yarn install --frozen-lockfile
      - run: cd apps/mobile && eas build --profile preview --platform android --non-interactive
      - uses: expo/expo-github-action/preview-comment@v8

  build-production:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    strategy:
      matrix:
        profile: [us-production, africa-production]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: 'yarn' }
      - uses: expo/expo-github-action@v8
        with: { eas-version: latest, token: '${{ secrets.EXPO_TOKEN }}' }
      - run: yarn install --frozen-lockfile
      - run: cd apps/mobile && eas build --profile ${{ matrix.profile }} --platform android --non-interactive

  e2e:
    needs: build-preview
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install Maestro
        run: curl -Ls "https://get.maestro.mobile.dev" | bash
      - name: Setup Android Emulator
        uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 30
          target: google_apis
          arch: x86_64
          script: |
            eas build:list --profile preview --platform android --limit 1 --json | jq -r '.[0].artifacts.buildUrl' | xargs wget -O app.apk
            adb install app.apk
            maestro test tests/e2e/mobile/
```

**Profile triggers by tag:**

```yaml
on:
  push:
    tags:
      - 'mobile-v*-us' # triggers us-production
      - 'mobile-v*-africa' # triggers africa-production
      - 'mobile-v*' # triggers both
```

**Code signing:** EAS manages signing via `eas credentials` (stored encrypted on Expo servers). For self-managed: store Android keystore as base64-encoded GitHub secret.

#### OTA Updates: EAS Update

- JS bundle + asset changes over the air — no app store review needed
- **`fingerprint` runtime version policy** (recommended): auto-computes hash of native dependencies, prevents incompatible OTA updates
- **Market-specific channels:**
  ```bash
  eas update --channel africa-production --message "Improved offline support"
  eas update --channel us-production --message "Updated payment flow"
  ```
- **Update size:** Typical 500KB-5MB (delta updates, vs 30MB full APK)
- **Metered data prompt** for African users:
  ```tsx
  const update = await Updates.checkForUpdateAsync();
  if (update.isAvailable) {
    const confirmed = await showUpdateDialog(update); // "Update available (2.3MB). Download now?"
    if (confirmed) {
      await Updates.fetchUpdateAsync();
      await Updates.reloadAsync();
    }
  }
  ```
- **Rollback:** `eas update:republish --group <previous-update-group-id>` for instant rollback. Auto-rollback on startup crash (falls back to embedded bundle).

| Change Type                   | OTA Update | Native Build Required |
| ----------------------------- | ---------- | --------------------- |
| JS code changes               | Yes        | No                    |
| Asset changes (images, fonts) | Yes        | No                    |
| New native module added       | No         | Yes                   |
| Permissions added             | No         | Yes                   |

#### Error Reporting: Sentry

```bash
npx expo install @sentry/react-native
```

```typescript
Sentry.init({
  dsn: process.env.EXPO_PUBLIC_SENTRY_DSN,
  tracesSampleRate: 0.2,
  profilesSampleRate: 0.1,
  enableAutoSessionTracking: true,
  attachScreenshot: true,
  beforeSend(event) {
    if (event.message?.includes('Network request failed')) return null; // Filter transient 3G errors
    return event;
  },
  integrations: [
    Sentry.reactNativeTracingIntegration({
      routingInstrumentation: Sentry.reactNavigationIntegration(),
    }),
  ],
});
```

**Hermes source maps:** Add `@sentry/react-native/expo` plugin to `app.json` + `SENTRY_AUTH_TOKEN` in EAS secrets. Plugin auto-uploads `.hbc.map` files and strips source maps from production.

**Crash-free targets:** US > 99.5%, Africa > 98.5% (more device diversity, OS fragmentation, memory-pressure OOM kills).

**Offline error queuing:** Sentry RN SDK caches errors in local SQLite when offline, sends on reconnect. Default: 30 events, 30 days TTL. Configure `maxCacheItems: 50` for higher tolerance.

#### Analytics & Feature Flags: PostHog (Unified Platform)

Already in the web stack — use same platform for mobile: unified analytics + feature flags + experiments, single SDK and dashboard.

```bash
npx expo install posthog-react-native
```

```typescript
export const posthog = new PostHog(process.env.EXPO_PUBLIC_POSTHOG_KEY, {
  host: process.env.EXPO_PUBLIC_POSTHOG_HOST,
  flushAt: 20, // Batch of 20 events
  flushInterval: 30, // Or every 30 seconds
  // Events persisted to AsyncStorage when offline, sent on reconnect
});
```

**Feature flags with market targeting:**

```
Flag: "offline-first-mode"
Conditions: person.market == "africa" → 100% rollout
            person.market == "us" → 0% rollout
```

**Offline flag evaluation:** Flags cached in AsyncStorage on startup. If server unreachable, cached values used. Bootstrap critical flags with defaults:

```typescript
const posthog = new PostHog(key, {
  host,
  bootstrap: { featureFlags: { 'offline-mode': true, 'new-voting-ui': false } },
});
```

**Self-hosting** addresses data residency concerns for Nigeria NDPR and South Africa POPIA.

**Key governance metrics:**

- `proposal_viewed`, `vote_cast`, `proposal_created` (target: >30% of viewers cast a vote)
- `app_cold_start` with `duration_ms`, `device_model`, `network_type`
- `offline_action_queued`, `ota_update_accepted` (market-specific)
- DAU/MAU ratio target > 0.3

#### Performance Benchmarking Commands

```bash
# Cold start measurement
adb shell am force-stop com.endao.app
adb shell am start-activity -W com.endao.app/.MainActivity  # "TotalTime" = cold start

# Memory usage (target < 150MB TOTAL PSS)
adb shell dumpsys meminfo com.endao.app

# Frame rate (target < 5% janky frames)
adb shell dumpsys gfxinfo com.endao.app
```

#### References

- [Maestro](https://maestro.mobile.dev/) — E2E testing for mobile
- [FlashList](https://shopify.github.io/flash-list/) — Performant list for React Native
- [EAS Build](https://docs.expo.dev/build/introduction/) — Cloud builds for Expo
- [EAS Update](https://docs.expo.dev/eas-update/introduction/) — OTA updates
- [Sentry React Native](https://docs.sentry.io/platforms/react-native/) — Error reporting
- [PostHog React Native](https://posthog.com/docs/libraries/react-native) — Analytics + feature flags
- [BrowserStack](https://www.browserstack.com/) — Cloud device testing
- [MobSF](https://github.com/MobSF/Mobile-Security-Framework-MobSF) — Mobile security testing

### Allinka Integration, Multi-API Architecture, SMS/USSD & PWA

#### Multi-API Architecture: BFF Pattern (Not API Gateway, Not Direct Multi-Service)

**Direct multi-service consumption** (mobile calls both EnDAO and Allinka APIs directly) creates problems: two auth flows, two error formats, two retry strategies, no data aggregation without multiple round-trips.

**API gateway** (Kong, AWS API Gateway) adds routing/rate-limiting but doesn't solve data aggregation or response shaping.

**BFF (Backend for Frontend)** is correct for this case. A single Next.js API layer sits between mobile and both backends:

```
apps/mobile (Expo)
  └─> /api/mobile/v1/*  (BFF — lives in apps/web)
        ├─> EnDAO Supabase (governance, treasury, proposals)
        └─> Allinka API (education, courses, assessments)
```

**Implementation:**

```typescript
// apps/web/src/app/api/mobile/v1/dashboard/route.ts
export async function GET(req: Request) {
  const userId = await validatePrivyToken(req);
  const [daoData, educationData] = await Promise.allSettled([
    EnDAOService.getUserDashboard(userId),
    AllinkaClient.getUserCourses(userId), // HTTP call to Allinka API
  ]);
  return Response.json({
    governance: daoData.status === 'fulfilled' ? daoData.value : null,
    education:
      educationData.status === 'fulfilled' ? educationData.value : null,
  });
}
```

**Key decisions:**

- One BFF per client type (mobile BFF), not per device OS
- `Promise.allSettled` (not `Promise.all`) — one service failing doesn't break the entire response
- BFF normalizes error formats from both APIs into single `{ success, data, error }` shape
- TanStack Query on mobile side for request deduplication with `staleTime`/`gcTime` per query key

**REST BFF over GraphQL** — team already has REST APIs, GraphQL breaks HTTP caching (critical on low-bandwidth African networks), GraphQL underperforms REST at >3,000 req/sec. REST BFF with per-client response shaping gives the same "no over-fetching" benefit.

**Per-client response optimization:**

```typescript
export async function GET(req: Request) {
  const client = req.headers.get('X-Client-Type'); // 'mobile' | 'pwa' | 'web'
  const proposal = await getProposal(id);
  if (client === 'mobile') {
    return Response.json({
      id: proposal.id,
      title: proposal.title,
      status: proposal.status,
      voteCount: proposal.votes.length,
      endsAt: proposal.endsAt,
    });
  }
  return Response.json(proposal); // Web/PWA gets full payload
}
```

**Caching strategy by resource:**

- Proposal lists: `max-age=30` (30s)
- Proposal detail: `max-age=10` (votes change frequently)
- Treasury balance: `no-cache` (always fresh)
- User profile: `max-age=300` (5 min)
- Education content (Allinka): `max-age=3600` (1 hr, rarely changes)

#### Shared Authentication / SSO

**Privy as Shared Auth Provider.** Privy JWTs are standard ES256 tokens. Any backend can independently verify them using Privy's public verification key — no network calls to Privy at verification time.

**Option A (recommended for start):** Both backends trust the same Privy app. Deploy same verification key to both services:

```typescript
import { jwtVerify, importSPKI } from 'jose';
const PRIVY_VERIFICATION_KEY = process.env.PRIVY_VERIFICATION_KEY;
const PRIVY_APP_ID = process.env.NEXT_PUBLIC_PRIVY_APP_ID;
async function validatePrivyToken(token: string) {
  const key = await importSPKI(PRIVY_VERIFICATION_KEY, 'ES256');
  const { payload } = await jwtVerify(token, key, {
    issuer: 'privy.io',
    audience: PRIVY_APP_ID,
  });
  return payload.sub; // Privy DID
}
```

**Option B (if Allinka has its own auth):** BFF performs OAuth 2.0 Token Exchange (RFC 8693) — swaps Privy token for Allinka session token server-to-server.

**Single sign-out:** `privy.logout()` on client + BFF calls Allinka's logout endpoint (if Option B). Short-lived tokens (1 hour default) ensure stale tokens expire quickly.

#### Unified Mobile Navigation: Expo Router

Tab-based separation with Expo Router's file-based routing:

```
apps/mobile/app/
  (tabs)/
    (governance)/       # EnDAO tabs
      index.tsx         # DAO dashboard
      proposals/[id].tsx
      treasury/index.tsx
    (education)/        # Allinka tabs
      index.tsx         # Course catalog
      courses/[id].tsx
      assessments/[id].tsx
    (shared)/           # Cross-platform
      profile.tsx
      notifications.tsx
    _layout.tsx         # Bottom tab bar: Home, Governance, Learning, Wallet, Profile
  _layout.tsx           # Root layout (auth gate)
```

**Deep linking:** `endao://governance/proposals/123` maps to `app/(tabs)/(governance)/proposals/[id].tsx`. Expo Router provides automatic deep linking.

**Async Routes** (bundle splitting) — each tab group loads independently so education module doesn't slow down governance.

#### SMS Integration: Africa's Talking (Not Twilio)

**Why:** 10-27x cheaper than Twilio for African markets, USSD support (Twilio has none), 27+ African countries, 80+ telco integrations.

**Approximate SMS pricing:**

| Country      | Cost/SMS      | Approx. USD   |
| ------------ | ------------- | ------------- |
| Kenya        | KES 0.80-1.50 | ~$0.006-0.012 |
| Nigeria      | NGN 2.50-4.00 | ~$0.002-0.003 |
| Uganda       | UGX 30-60     | ~$0.008-0.016 |
| Tanzania     | TZS 15-25     | ~$0.006-0.010 |
| South Africa | ZAR 0.19-0.35 | ~$0.010-0.019 |

**Two-way SMS governance commands:**

- `VOTE YES <id>` / `VOTE NO <id>` — cast vote
- `STATUS <id>` — check proposal status
- `BAL` — check treasury balance
- `PROPOSALS` — list active proposals (truncated to 160 chars)

**Character limits:** 160 chars (GSM-7), 70 chars for non-Latin scripts (UCS-2). Keep notifications under 160, include short URL for details.

**Failure handling:** Delivery reports via webhook, retry with exponential backoff (max 3 over 24 hours), fall back to push notification if SMS fails and app is installed.

#### USSD Integration for Feature Phone Users

Session-based, real-time GSM protocol — no internet required. User dials `*384*123#`, telco routes to Africa's Talking, which POSTs to webhook. Session lasts 120-180 seconds max.

**Governance USSD menu:**

```
*384*123# → Main Menu
  1. Active Proposals → List proposals
    1. #42 Budget 2026 → Vote YES / Vote NO
  2. Cast Vote
  3. Treasury Balance
  4. My Voting History
  0. Exit
```

**Implementation:**

```typescript
// POST /api/ussd/callback
export async function POST(req: Request) {
  const body = await req.formData();
  const sessionId = body.get('sessionId') as string;
  const phone = body.get('phoneNumber') as string;
  const text = body.get('text') as string; // "1*1*1" for menu path
  const parts = text.split('*').filter(Boolean);

  if (parts.length === 0) {
    return new Response(
      `CON Welcome to DAO Governance\n1. Active Proposals\n2. Cast Vote\n3. Treasury Balance\n0. Exit`,
      { headers: { 'Content-Type': 'text/plain' } }
    );
  }
  // ... deeper menu levels
}
```

**Session management:** Redis with 180s TTL keyed by `sessionId`.

**Design constraints:** Max ~182 chars/screen, session timeout 120s, text only, keep menu depth to 3-4 levels max.

**Successful USSD apps in Africa:** M-Pesa ($100B+ processed in 2024 via USSD), Moniepoint (Nigeria — 5.2B transactions), OPay (Nigeria), Mukuru (Southern Africa).

#### PWA Complement: Serwist on Existing Next.js App

**Low-effort, high-impact for Africa.** PWAs use 25-50x less storage than native apps, work offline, no Play Store dependency.

```bash
yarn add @serwist/next serwist
```

```javascript
// next.config.mjs
import withSerwistInit from '@serwist/next';
const withSerwist = withSerwistInit({
  swSrc: 'app/sw.ts',
  swDest: 'public/sw.js',
});
export default withSerwist({
  /* existing next config */
});
```

**Feature split:**

| Feature                    | PWA           | Native Only  |
| -------------------------- | ------------- | ------------ |
| View proposals, cast votes | Yes           | Yes          |
| Treasury dashboard         | Yes           | Yes          |
| Push notifications         | Yes (Android) | Yes (both)   |
| Biometric auth             | No            | Yes          |
| QR code scanning           | Limited       | Yes          |
| Offline proposal viewing   | Yes (cached)  | Yes (SQLite) |
| Background sync            | Yes (limited) | Yes (full)   |

**PWA storage limits:** ~50MB guaranteed, sufficient for caching proposals and app shell. Large media (Allinka course videos) should use native.

#### References

- [BFF Architecture Overview](https://dev.to/abdulnasirolcan/backend-for-frontend-bff-architecture-4p11)
- [Auth0: The BFF Pattern](https://auth0.com/blog/the-backend-for-frontend-pattern-bff/)
- [Privy Access Tokens](https://docs.privy.io/authentication/user-authentication/access-tokens)
- [Privy JWT-Based Auth](https://docs.privy.io/authentication/user-authentication/jwt-based-auth)
- [OAuth 2.0 Token Exchange (RFC 8693)](https://oauth.net/2/token-exchange/)
- [Expo Router Introduction](https://docs.expo.dev/router/introduction/)
- [Africa's Talking SMS API](https://africastalking.com/sms)
- [Africa's Talking USSD API](https://africastalking.com/ussd)
- [Serwist Getting Started](https://serwist.pages.dev/docs/next/getting-started)
- [Next.js PWA Guide](https://nextjs.org/docs/app/guides/progressive-web-apps)

---

## Package Vetting Results (January 30, 2026)

All 25 npm packages referenced in this plan were audited for: npm download trends, GitHub activity, maintainer count, known CVEs, supply chain incidents, and Expo 52/RN 0.76 compatibility.

### Verdict Summary

| Verdict              | Count | Packages                                                                                                                                                                                                                                                                                                                                                                                                                  |
| -------------------- | ----- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **SAFE TO USE**      | 18    | WatermelonDB, react-native-mmkv, @shopify/flash-list, react-native-netinfo, expo-localization, react-i18next, expo-local-authentication, react-native-ssl-public-key-pinning, expo-crypto, expo-secure-store, @sentry/react-native, react-native-reanimated, react-native-gesture-handler, expo-notifications, expo-background-task, babel-plugin-transform-remove-console, jest + @testing-library/react-native, Maestro |
| **USE WITH CAUTION** | 6     | posthog-react-native, @privyio/expo, flutterwave-react-native, @lovesworking/watermelondb-expo-plugin-sdk-52-plus, @expo/app-integrity, react-native-worklets                                                                                                                                                                                                                                                             |
| **DO NOT USE**       | 1     | react-native-threads                                                                                                                                                                                                                                                                                                                                                                                                      |

### Critical Actions

1. **REPLACE `react-native-threads`** → Use [`react-native-worklets`](https://github.com/nickhirakawa/react-native-worklets) (Software Mansion) for background JS execution. `react-native-threads` is abandoned (6 years, no commits), incompatible with RN 0.70+, New Architecture, and Expo.

2. **FORK `@lovesworking/watermelondb-expo-plugin-sdk-52-plus`** → Single anonymous maintainer with build-time access. Fork into `@endao/watermelondb-expo-plugin`, pin to audited commit hash, monitor upstream.

3. **PostHog supply chain context**: Directly affected by Shai-Hulud 2.0 (Nov 2025). Now uses npm trusted publisher model. For government partnerships: document the incident and remediation in security audits. Self-hosting recommended for data residency + supply chain isolation.

4. **Privy audit report**: `@privyio/expo` is closed-source (no public audit). Request audit report directly from Privy for government partnership compliance documentation.

5. **`@expo/app-integrity`**: Very new (v0.1.9). Use ONLY the official `@expo/` scoped package. Do not use community `expo-app-integrity`.

6. **`flutterwave-react-native`**: Low adoption (928 downloads/week), thin WebView wrapper. No practical alternative for M-Pesa/mobile money integration. Acceptable given Flutterwave's 400,000+ business customer base backing the company.

### Supply Chain Hardening (`.npmrc`)

```ini
# Block newly-published packages (supply chain attack window)
minimumReleaseAge=3d

# Exact versions only
save-exact=true

# Frozen lockfile in CI
# (set via yarn install --frozen-lockfile in CI scripts)
```

---

## Implementation Order (Pending Research)

1. Build infrastructure (eas.json, app.config.ts, assets, CI/CD)
2. Security foundation (certificate pinning, encrypted storage, secure sessions)
3. Offline-first data layer (WatermelonDB + sync engine)
4. Bandwidth optimization (data-saver mode, compression, connection-aware fetching)
5. Localization framework (i18next + string extraction)
6. Payment integration (Flutterwave for Africa, Stripe for US)
7. Allinka integration (shared auth, unified navigation)
8. Testing infrastructure (unit, E2E, device testing)
9. Privacy & compliance (per-jurisdiction policies, consent, audit logging)
10. Translations (French, Swahili, Arabic)
11. PWA complement
12. SMS/USSD fallbacks
13. Production hardening (Sentry, analytics, feature flags, store submissions)

---

_Research complete. Package vetting complete. Ready for implementation planning._
