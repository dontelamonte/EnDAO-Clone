# Digital Participatory Budgeting & AI in Deliberative Democracy Research

**Date**: December 6, 2025
**Purpose**: Research into digital participatory budgeting tools, AI integration in citizens' assemblies, and deliberative platform design to inform EnDAO's institutional governance features.

**Distinction from Other Research**:

- [OGP Civic Tech Research](./OGP_CIVIC_TECH_RESEARCH.md) covers direct competitors in civic engagement
- [Institutional Tools Research](./INSTITUTIONAL_TOOLS_RESEARCH.md) covers adjacent collaboration/polling tools
- This report covers **deliberative democracy infrastructure** and **AI-assisted governance**

---

## Executive Summary

Research conducted across 5 primary sources reveals critical patterns for institutional-grade deliberative governance:

| Source              | Type      | Key Insight                                                                                     |
| ------------------- | --------- | ----------------------------------------------------------------------------------------------- |
| **Stanford PB**     | Platform  | Multiple voting methods (approval, knapsack, ranked) enable context-appropriate decision-making |
| **newDemocracy**    | Tool      | Stratified random selection creates representative panels without bias                          |
| **McKinney 2024**   | Academic  | 11 AI applications across CA lifecycle with democratic/institutional goods framework            |
| **NSF Report**      | Framework | Platform lifecycle model for participatory system design                                        |
| **Demsoc Webinars** | Practice  | Support/sifting phases and voting patterns from real-world digital PB                           |

**Features Adopted for EnDAO Roadmap**:

- Support/Sifting Phase for idea narrowing (Phase 2)
- Voting Method Selection per proposal (Phase 2)
- Stratified Random Selection for committees (Phase 3)
- AI Devil's Advocate for deliberation quality (Phase 4)
- AI Aggregation for cross-group synthesis (Phase 4)
- Deliberative Quality Metrics dashboard (Phase 4)

---

## Source 1: Stanford Participatory Budgeting Platform

**URL**: https://pbstanford.org/
**License**: GNU GPL v3.0 (Open Source)
**Languages**: 17 supported

### Voting Methods Analysis

| Method                | Best For                           | EnDAO Application                            |
| --------------------- | ---------------------------------- | -------------------------------------------- |
| **Approval Voting**   | Simple yes/no on multiple options  | General proposals, feature prioritization    |
| **Knapsack Voting**   | Budget allocation with constraints | Treasury allocation, funding proposals       |
| **Ranked Choice**     | Preference ordering                | Committee elections, multi-option governance |
| **Comparison Voting** | Pairwise preference elicitation    | Complex trade-off decisions                  |

### Key Technical Features

1. **Multi-method flexibility**: Same platform supports different voting types per decision
2. **Budget constraints**: Knapsack method enforces spending limits during voting
3. **Accessibility**: 17 language support for diverse communities
4. **Open source**: Enables customization and self-hosting

### EnDAO Implementation

**Adopted as 2.18 Voting Method Selection**:

- Allow proposal creators to select voting method appropriate to decision type
- Default: Simple majority for general proposals
- Option: Knapsack for treasury allocation decisions
- Option: Ranked choice for elections and multi-option choices

---

## Source 2: newDemocracy Stratified Random Selection Tool

**URL**: https://selection.newdemocracy.com.au/
**Privacy**: Browser-based (no server storage)
**Cost**: Free

### Selection Algorithms

| Algorithm   | Purpose                           | Trade-off                                   |
| ----------- | --------------------------------- | ------------------------------------------- |
| **Simple**  | Pure random within strata         | Maximum randomness, may miss edge cases     |
| **Maximin** | Optimizes worst-represented group | Better representation, less pure randomness |

### Stratification Categories

The tool supports stratification across:

- Age groups
- Gender
- Geographic location
- Custom demographic fields

### Use Cases for DAOs

1. **Committee Formation**: Select representative working groups
2. **Jury Panels**: Deliberative panels for contentious decisions
3. **Advisory Boards**: Balanced stakeholder representation
4. **Review Committees**: Fair selection for proposal review

### EnDAO Implementation

**Adopted as 3.7 Stratified Random Selection**:

- Integrate selection algorithm for committee formation
- Support custom stratification fields (role, tenure, expertise)
- Browser-based privacy (no central storage of selection data)
- Audit trail showing selection parameters and results

---

## Source 3: McKinney 2024 - AI in Citizens' Assemblies

**Citation**: McKinney, S. (2024). "Integrating Artificial Intelligence Into Citizens' Assemblies." Journal of Deliberative Democracy, 20(1).

### The 11 AI Applications Framework

This is the most comprehensive academic framework for AI integration in deliberative democracy. Critical for EnDAO's Phase 4 AI implementation.

#### Pre-Assembly Phase

| Application                    | Function                                     | EnDAO Mapping                          |
| ------------------------------ | -------------------------------------------- | -------------------------------------- |
| **1. Participant Recruitment** | Targeted outreach, demographic balancing     | Member onboarding, diversity analytics |
| **2. Materials Preparation**   | Summarize complex topics, generate briefings | Proposal context generation            |
| **3. Expert Matching**         | Connect assemblies with relevant expertise   | Advisor recommendation system          |

#### During Assembly Phase

| Application                  | Function                                       | EnDAO Mapping                            |
| ---------------------------- | ---------------------------------------------- | ---------------------------------------- |
| **4. Real-time Translation** | Live multilingual support                      | International DAO support                |
| **5. Facilitation Support**  | Track discussions, suggest prompts             | Deliberation guidance                    |
| **6. Devil's Advocate**      | Challenge groupthink, surface counterarguments | **HIGH PRIORITY** - deliberation quality |
| **7. Sentiment Analysis**    | Monitor emotional dynamics                     | Discussion health metrics                |

#### Post-Assembly Phase

| Application                     | Function                                 | EnDAO Mapping                             |
| ------------------------------- | ---------------------------------------- | ----------------------------------------- |
| **8. Aggregation**              | Synthesize cross-group discussions       | **HIGH PRIORITY** - multi-group synthesis |
| **9. Report Generation**        | Draft recommendations from deliberations | Proposal summary generation               |
| **10. Implementation Tracking** | Monitor follow-through on decisions      | Governance accountability                 |
| **11. Evaluation**              | Assess deliberative quality metrics      | **HIGH PRIORITY** - quality dashboard     |

### Democratic Goods Framework

McKinney identifies four democratic goods that AI must preserve or enhance:

| Good                     | Definition                         | AI Risk                         | Mitigation                           |
| ------------------------ | ---------------------------------- | ------------------------------- | ------------------------------------ |
| **Inclusiveness**        | All affected voices represented    | Bias in recruitment/translation | Audit training data, human oversight |
| **Popular Control**      | Citizens retain decision authority | AI overreach, manipulation      | Human-in-the-loop requirement        |
| **Considered Judgement** | Informed, reflective decisions     | Hallucinations, misinformation  | Fact-checking, source attribution    |
| **Transparency**         | Process is open and understandable | Black-box algorithms            | Explainable AI, audit trails         |

### Institutional Goods Framework

| Good            | Definition                        | AI Benefit                         | Trade-off                     |
| --------------- | --------------------------------- | ---------------------------------- | ----------------------------- |
| **Efficiency**  | Reduce time/cost of deliberation  | Automation of routine tasks        | May sacrifice depth for speed |
| **Scalability** | Handle larger participant numbers | Process more inputs simultaneously | Quality control challenges    |

### Critical AI Concerns & Mitigations

| Concern                         | Risk                                        | Mitigation Strategy                                        |
| ------------------------------- | ------------------------------------------- | ---------------------------------------------------------- |
| **Bias**                        | AI reflects training data biases            | Diverse training data, bias audits, human review           |
| **Hallucinations**              | AI generates false information              | Fact-checking layer, source attribution, confidence scores |
| **Excessive Machine Influence** | AI shapes rather than supports deliberation | Human-in-the-loop, transparency about AI role              |
| **Privacy**                     | Sensitive discussion data exposure          | Local processing, data minimization, consent               |
| **Manipulation**                | Bad actors use AI to game process           | Detection systems, human oversight, audit trails           |

### Human-in-the-Loop Requirement

McKinney emphasizes that AI should **augment, not replace** human deliberation:

```
AI Role: Support and enhance human decision-making
Human Role: Final authority on all governance decisions
Boundary: AI can suggest, summarize, translate - but never decide
```

### EnDAO Implementation Priority

**Phase 4.7 NLP-Assisted Governance - Enhanced Scope**:

| Feature                      | Priority | Complexity | Source           |
| ---------------------------- | -------- | ---------- | ---------------- |
| Devil's Advocate             | HIGH     | Medium     | McKinney App #6  |
| Cross-Group Aggregation      | HIGH     | High       | McKinney App #8  |
| Deliberative Quality Metrics | HIGH     | Medium     | McKinney App #11 |
| Sentiment Monitoring         | Medium   | Low        | McKinney App #7  |
| Materials Summarization      | Medium   | Medium     | McKinney App #2  |
| Report Generation            | Low      | Medium     | McKinney App #9  |

---

## Source 4: NSF Workshop Report - Participatory Platforms

**Title**: "Participatory Platforms with a Public Intent"
**Source**: ASU Center for Policy Informatics, 2013
**Type**: NSF Workshop Report

### Platform Lifecycle Model

```
Planning → Development → Engagement → Execution → Outputs → Evaluation → Outcomes → Feedback Loop
    ↑                                                                                    |
    └────────────────────────── Learning/Integration/Iteration ←─────────────────────────┘
```

### Design Aspects Framework

| Aspect         | Description                             | EnDAO Application                  |
| -------------- | --------------------------------------- | ---------------------------------- |
| **Structural** | Platform architecture, data models      | Repository pattern, service layer  |
| **Procedural** | Workflow rules, process definitions     | Proposal lifecycle, voting periods |
| **Social**     | Community norms, participation patterns | Governance culture, moderation     |
| **Technical**  | Infrastructure, security, scalability   | Supabase, Safe integration         |

### Key Insights for EnDAO

1. **Feedback loops are critical**: Participants need to see impact of their input
2. **Evaluation must be built-in**: Not an afterthought
3. **Platform neutrality**: Design should not bias toward particular outcomes
4. **Iteration is expected**: Platforms evolve based on community use

---

## Source 5: Democratic Society (Demsoc) Webinars

**Source**: Digital Participatory Budgeting webinar series
**Topics**: Voting, Idea Generation/Deliberation, Introduction to Digital PB

### Support/Sifting Phase Pattern

Before final voting, successful PB processes include a **sifting phase** to narrow ideas:

```
All Ideas Submitted → Support Phase (positive voting) → Shortlist → Final Vote
        1000+              200+ supporters required           50         Winner(s)
```

**Key Mechanics**:

- **Support voting**: Members indicate interest (not final vote)
- **Threshold**: Ideas need minimum supporters to advance
- **Prevents**: Ballot fatigue from too many options
- **Enables**: Focused deliberation on viable options

### Voting Pattern Insights

| Pattern                 | Description                  | When to Use                  |
| ----------------------- | ---------------------------- | ---------------------------- |
| **Positive-only**       | Vote for options you support | Simple prioritization        |
| **Positive + Negative** | Support and oppose options   | Surfaces contested items     |
| **Ranked**              | Order preferences            | Elections, limited resources |
| **Budget allocation**   | Distribute fixed points      | Treasury decisions           |

### Tool Comparison Matrix

| Tool                   | Type        | Strengths                     | Weaknesses        |
| ---------------------- | ----------- | ----------------------------- | ----------------- |
| **Consul**             | Open Source | Full-featured, Scotland pilot | Complex setup     |
| **Participate**        | Commercial  | User-friendly                 | Less customizable |
| **Your Priorities**    | Open Source | Idea generation focus         | Limited voting    |
| **Open Active Voting** | Open Source | Multiple methods              | Less polished     |
| **D-21**               | Commercial  | Innovative voting             | Proprietary       |

### Best Practices from Practice

1. **Don't skip the sift**: Going straight to vote on 100+ ideas fails
2. **Make voting method match decision type**: Treasury != elections
3. **Time-box phases**: Open-ended leads to fatigue
4. **Show running totals carefully**: Can create bandwagon effects
5. **Mobile-first**: Most participation happens on phones

### EnDAO Implementation

**Adopted as 2.19 Support/Sifting Phase**:

- Enable two-phase proposal process: Support → Vote
- Configurable support threshold (default: 10% of members)
- Visual progress toward threshold
- Automatic promotion to voting phase when threshold met

---

## Implementation Recommendations

### Phase 2 (Q2 2026) - Added

| Feature                 | Section | Source      | Complexity |
| ----------------------- | ------- | ----------- | ---------- |
| Support/Sifting Phase   | 2.19    | Demsoc      | Low        |
| Voting Method Selection | 2.18    | Stanford PB | Medium     |

### Phase 3 (Q3-Q4 2026) - Added

| Feature                     | Section | Source       | Complexity |
| --------------------------- | ------- | ------------ | ---------- |
| Stratified Random Selection | 3.7     | newDemocracy | Medium     |

### Phase 4 (2027) - Enhanced 4.7 NLP-Assisted Governance

| Feature                      | Priority | Source       | Complexity |
| ---------------------------- | -------- | ------------ | ---------- |
| AI Devil's Advocate          | HIGH     | McKinney #6  | Medium     |
| Cross-Group Aggregation      | HIGH     | McKinney #8  | High       |
| Deliberative Quality Metrics | HIGH     | McKinney #11 | Medium     |
| Sentiment Monitoring         | Medium   | McKinney #7  | Low        |
| Materials Summarization      | Medium   | McKinney #2  | Medium     |

---

## AI Implementation Guidelines

Based on McKinney 2024 framework, EnDAO's AI features must adhere to:

### Mandatory Requirements

1. **Human-in-the-Loop**: All AI suggestions require human approval
2. **Transparency**: AI involvement clearly labeled in UI
3. **Explainability**: AI reasoning must be inspectable
4. **Audit Trail**: All AI actions logged for review
5. **Override Capability**: Humans can disable/correct AI at any point

### Quality Safeguards

1. **Bias Audits**: Regular review of AI outputs for demographic bias
2. **Hallucination Detection**: Confidence scores, source attribution
3. **Manipulation Detection**: Patterns suggesting coordinated AI misuse
4. **Privacy Protection**: Local processing where possible, data minimization

### Democratic Goods Checklist

Before deploying any AI feature, validate:

- [ ] **Inclusiveness**: Does this help or hinder diverse participation?
- [ ] **Popular Control**: Do humans retain decision authority?
- [ ] **Considered Judgement**: Does this improve or shortcut deliberation?
- [ ] **Transparency**: Is the AI's role clear and auditable?

---

## Design Principles Validated

This research validates and extends EnDAO's core design principles:

| Principle                | Validation Source | Evidence                                      |
| ------------------------ | ----------------- | --------------------------------------------- |
| **Institutional Rails**  | NSF Report        | Platform lifecycle, procedural design aspects |
| **Deliberation Quality** | McKinney 2024     | Democratic goods framework, AI safeguards     |
| **Accessibility**        | Stanford PB       | 17 languages, multiple voting methods         |
| **Transparency**         | All sources       | Audit trails, explainability requirements     |
| **Human Authority**      | McKinney 2024     | Human-in-the-loop mandate                     |

---

## Appendix: Research Sources

### Academic Papers

- McKinney, S. (2024). "Integrating Artificial Intelligence Into Citizens' Assemblies." Journal of Deliberative Democracy, 20(1). DOI: 10.16997/jdd.1651

### Reports

- ASU Center for Policy Informatics (2013). "Participatory Platforms with a Public Intent." NSF Workshop Report.

### Platforms

- [Stanford Participatory Budgeting Platform](https://pbstanford.org/)
- [newDemocracy Stratified Random Selection](https://selection.newdemocracy.com.au/)

### Webinars

- Democratic Society. "Introduction to Digital Participatory Budgeting." YouTube.
- Democratic Society. "Digital PB: Idea Generation and Deliberation." YouTube.
- Democratic Society. "Digital PB: Voting Methods and Patterns." YouTube.

### Related Tools

- [Consul](https://consulproject.org/) - Open source participation platform
- [Your Priorities](https://citizens.is/) - Idea generation platform
- [D-21](https://www.d21.me/) - Multiple approval voting

---

_Report generated as part of EnDAO product development. December 6, 2025._
