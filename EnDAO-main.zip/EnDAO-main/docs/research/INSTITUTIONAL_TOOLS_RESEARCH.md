# Institutional Tools Research Report

**Date**: December 6, 2025
**Purpose**: Research into collaboration, polling, meeting, and deliberation tools to identify features that enhance EnDAO's institutional robustness.

**Distinction from OGP Research**: The [OGP Civic Tech Research](./OGP_CIVIC_TECH_RESEARCH.md) covers direct competitors in the civic engagement space. This report covers **adjacent tools** whose features could be adopted to make EnDAO more robust as an institutional platform.

---

## Executive Summary

Research conducted on 12 platforms across 4 categories reveals patterns for institutional-grade governance tools:

| Category          | Platforms Researched               | Key Insight                                                            |
| ----------------- | ---------------------------------- | ---------------------------------------------------------------------- |
| **Deliberation**  | Deliberatorium, Delib.net, Discuto | IBIS argument mapping + evidence attachment = higher quality decisions |
| **Polling**       | Poll Everywhere, Slido, Mentimeter | Live polls + Q&A upvoting = better synchronous engagement              |
| **Collaboration** | Mural, Trello, Etherpad            | Version control + Observer role = audit-grade governance               |
| **Meetings**      | Zoom, Teams, Jitsi                 | Poll→breakout routing + transcription = structured discussions         |

**Features Adopted for EnDAO Roadmap**:

- Evidence/Document Attachment (Phase 2)
- Proposal Revision History (Phase 2)
- Observer Role (Phase 2)
- IBIS Argument Map Template (Phase 2)
- Anonymous Q&A Option (Phase 2)
- Visual Planning & Stakeholder Mapping (Phase 4)
- Live Meeting Integration (Phase 4)
- Poll-to-Breakout Routing (Phase 4)

---

## Category 1: Deliberation Tools

### Platforms: Deliberatorium, Delib.net (Citizen Space), Discuto

### Key Features Analysis

| Feature                   | Deliberatorium          | Delib.net                   | Discuto         | EnDAO Adoption             |
| ------------------------- | ----------------------- | --------------------------- | --------------- | -------------------------- |
| **IBIS Argument Mapping** | ✅ Issues→Ideas→Pro/Con | ❌                          | ❌              | Added as proposal template |
| **Evidence Attachment**   | ✅ Background docs      | ✅ File upload + moderation | ✅ Multi-format | Added to Phase 2           |
| **Moderation Workflow**   | ✅ LLM-enhanced (2025)  | ✅ Pre-publish review       | ✅ Admin panel  | Informs admin tools        |
| **API/Export**            | ❌                      | ✅ `/api/2.4/` REST         | ❌              | Future integration         |
| **Revision Audit**        | ⚠️ Implicit             | ✅ Activity logging         | ⚠️              | Added to Phase 2           |

### IBIS (Issue-Based Information System) Model

Deliberatorium uses the IBIS formalism for structured argumentation:

```
ISSUE: "Should we fund Project X?"
├── IDEA 1: "Yes, fund fully"
│   ├── PRO: "High community demand"
│   ├── PRO: "Aligns with mission"
│   └── CON: "Exceeds quarterly budget"
├── IDEA 2: "Fund partially (50%)"
│   ├── PRO: "Manages risk"
│   └── CON: "May not achieve goals"
└── IDEA 3: "Defer to next quarter"
    ├── PRO: "More time for review"
    └── CON: "Opportunity cost"
```

**EnDAO Implementation**: Added as "IBIS Argument Map" proposal template in 2.13.

### Evidence Attachment Best Practices (Delib.net)

Delib.net's file upload workflow:

1. User uploads document to proposal
2. Admin reviews before publication (optional gate)
3. Document versioned if updated during discussion
4. Final documents archived with proposal record

**EnDAO Implementation**: Added as 2.14 Evidence & Document Attachment.

### LLM-Enhanced Moderation (Deliberatorium 2025)

Recent research (Klein et al., 2025) shows LLM moderation can:

- Flag low-quality arguments before publication
- Detect toxicity in structured debates
- Suggest argument improvements

**EnDAO Implementation**: Deferred to 4.7 NLP-Assisted Governance.

---

## Category 2: Polling & Survey Tools

### Platforms: Poll Everywhere, Slido, Mentimeter

### Key Features Analysis

| Feature                      | Poll Everywhere | Slido        | Mentimeter      | EnDAO Adoption         |
| ---------------------------- | --------------- | ------------ | --------------- | ---------------------- |
| **Live Polling**             | ✅ Excellent    | ✅ Excellent | ✅ Excellent    | Phase 4 meetings       |
| **Word Clouds**              | ✅              | ✅           | ✅              | Consider for sentiment |
| **Q&A with Upvoting**        | ⚠️ Premium      | ✅ Strong    | ⚠️ Limited      | Phase 4 meetings       |
| **Anonymous Submissions**    | ✅              | ✅           | ✅ (emphasized) | Added to Phase 2       |
| **AI Sentiment Analysis**    | ❌              | ⚠️ Basic     | ✅ Insights Hub | Phase 4 NLP            |
| **Presentation Integration** | ✅ Native       | ✅ Primary   | ✅              | Partnership model      |
| **Data Export**              | ✅ XLSX/PDF     | ✅           | ✅ XLSX/CSV/PDF | Standard               |

### Anonymous Feedback Pattern

All three platforms emphasize anonymous submissions:

- **Why**: Encourages honest feedback, especially criticism
- **Research**: Anonymous respondents 40% more likely to share concerns
- **Balance**: Anonymous questions, attributed arguments

**EnDAO Implementation**: Added as 2.17 Anonymous Q&A Option (questions only, arguments remain attributed).

### Q&A Upvoting (Democratic Prioritization)

Slido's Q&A pattern:

1. Members submit questions (optionally anonymous)
2. Other members upvote important questions
3. Most-upvoted questions surfaced to facilitator
4. Prevents first-come-first-served bias

**EnDAO Implementation**: Consider for Phase 4 Live Meeting Integration.

### Sentiment Analysis (Mentimeter Insights Hub)

2025 feature using ML to:

- Detect emergent themes in open-ended responses
- Track sentiment trends across meetings
- Predict contentious topics early

**EnDAO Implementation**: Deferred to 4.7 NLP-Assisted Governance.

---

## Category 3: Collaboration Tools

### Platforms: Mural, Trello, Etherpad

### Key Features Analysis

| Feature                     | Mural                    | Trello           | Etherpad         | EnDAO Adoption   |
| --------------------------- | ------------------------ | ---------------- | ---------------- | ---------------- |
| **Real-time Collaboration** | ✅ Canvas                | ✅ Card-level    | ✅ Document      | Inform UX        |
| **Templates**               | ✅ 400+                  | ✅ Extensive     | ⚠️ Plugins       | Enhanced 2.13    |
| **Visual Planning**         | ✅ Whiteboard            | ⚠️ Kanban only   | ❌               | Added to Phase 4 |
| **Version History**         | ⚠️ Activity log          | ⚠️ Limited       | ✅ Full revision | Added to Phase 2 |
| **Observer Role**           | ✅ View/Edit/Facilitator | ✅ Observer role | ⚠️ API-based     | Added to Phase 2 |
| **Export**                  | ✅ PDF/PNG               | ✅ JSON/CSV      | ✅ Text/HTML/PDF | Standard         |

### Version History (Etherpad Model)

Etherpad provides governance-grade revision control:

- `getRevisionsCount()` - Total revisions
- `getRevisionChangeset()` - Diff between versions
- `restoreRevision()` - Revert to previous state
- `saveRevision()` - Manual checkpoint

**EnDAO Implementation**: Added as 2.15 Proposal Revision History (phased rollout due to complexity).

### Observer Role (Trello Model)

Trello's role hierarchy:
| Role | View | Comment | Edit | Admin |
|------|------|---------|------|-------|
| Observer | ✅ | ✅ | ❌ | ❌ |
| Member | ✅ | ✅ | ✅ | ❌ |
| Admin | ✅ | ✅ | ✅ | ✅ |

**Use Cases**:

- Accountants reviewing treasury
- Lawyers reviewing governance
- Advisors monitoring progress
- Regulators auditing compliance

**EnDAO Implementation**: Added as 2.16 Observer Role.

### Visual Planning (Mural Model)

Mural provides:

- Infinite whiteboard canvas
- Stakeholder mapping templates
- Process flow diagrams
- Real-time collaboration (100+ users)

**EnDAO Implementation**: Added as 4.8 Visual Planning & Stakeholder Mapping (partnership model recommended).

---

## Category 4: Meeting Platforms

### Platforms: Zoom, Microsoft Teams, Jitsi

### Key Features Analysis

| Feature                       | Zoom        | Teams             | Jitsi        | EnDAO Adoption     |
| ----------------------------- | ----------- | ----------------- | ------------ | ------------------ |
| **Recording + Transcription** | ✅ Native   | ✅ Native         | ❌ Manual    | Partnership        |
| **Poll→Breakout Routing**     | ✅ Native   | ⚠️ Requires Forms | ❌           | Added to Phase 4   |
| **Webinar/Town Hall**         | ✅ 500-10K  | ✅ Town Hall      | ⚠️ 100 free  | Partnership        |
| **E2E Encryption**            | ⚠️ Standard | ⚠️ Standard       | ✅ Full E2EE | Consider Jitsi     |
| **Self-Hosted**               | ❌          | ❌                | ✅           | Sovereignty option |
| **API/Webhooks**              | ✅ Good     | ✅ Good           | ⚠️ Moderate  | Integration        |

### Poll-to-Breakout Routing (Zoom)

Zoom's unique feature:

1. Host creates poll: "Which topic interests you?"
2. Members vote during meeting
3. Zoom auto-creates breakout rooms from results
4. Members auto-assigned to rooms matching their vote
5. Report back to main session

**EnDAO Implementation**: Added as 4.10 Poll-to-Breakout Routing.

### Meeting Transcription Archive

All platforms offer transcription:

- **Zoom**: AI transcription in 16+ languages
- **Teams**: Native transcription, separate event policies
- **Jitsi**: Requires external integration

**EnDAO Decision**: Not building in-house. Recommend as governance best practice—DAOs should archive recordings and transcripts as part of their governance records.

### Self-Hosted Option (Jitsi)

Jitsi offers:

- Full data control
- End-to-end encryption for confidential treasury discussions
- No vendor lock-in
- Open source (free or $12/month JaaS)

**EnDAO Implementation**: Recommend Jitsi for DAOs requiring sovereignty. Partnership model for standard DAOs.

### OpenTalk (Alternative Discovery)

Research surfaced OpenTalk as governance-specific alternative:

- Built-in voting/quorum during meetings
- Protocol management (meeting minutes)
- GDPR-compliant
- Good fit for EU-based DAOs

**EnDAO Implementation**: Consider for future partnership if governance-specific meeting features are prioritized.

---

## Implementation Recommendations

### Phase 2 (Q2 2026) - Added

| Feature                        | Section | Source           | Complexity |
| ------------------------------ | ------- | ---------------- | ---------- |
| Evidence & Document Attachment | 2.14    | Delib.net        | Medium     |
| Proposal Revision History      | 2.15    | Etherpad         | High       |
| Observer Role                  | 2.16    | Trello           | Low        |
| Anonymous Q&A Option           | 2.17    | Slido/Mentimeter | Low        |
| IBIS Argument Map Template     | 2.13    | Deliberatorium   | Low        |

### Phase 4 (2027) - Added

| Feature                               | Section | Source           | Implementation |
| ------------------------------------- | ------- | ---------------- | -------------- |
| Visual Planning & Stakeholder Mapping | 4.8     | Mural            | Partnership    |
| Live Meeting Integration              | 4.9     | Zoom/Teams/Jitsi | Partnership    |
| Poll-to-Breakout Routing              | 4.10    | Zoom             | Partnership    |

### Deferred (Already in Roadmap)

| Feature                 | Section | Source               |
| ----------------------- | ------- | -------------------- |
| NLP Duplicate Detection | 4.7     | Delib.net/CitizenLab |
| NLP Sentiment Analysis  | 4.7     | Mentimeter           |
| LLM Content Moderation  | 4.7     | Deliberatorium       |

### Not Adopting

| Feature                                | Reason                                           |
| -------------------------------------- | ------------------------------------------------ |
| Meeting Transcription Archive          | Recommend as best practice, not platform feature |
| Built-in Video Conferencing            | Partnership model preferred                      |
| Visual Treasury Planning (Mural-style) | Visual Planning covers this                      |

---

## Partnership Opportunities

### Video Conferencing

| Platform     | Fit                  | Partnership Model             |
| ------------ | -------------------- | ----------------------------- |
| **Zoom**     | Best for large DAOs  | API integration, co-marketing |
| **Teams**    | Best for enterprise  | Microsoft partner program     |
| **Jitsi**    | Best for sovereignty | Self-hosted recommendation    |
| **OpenTalk** | Best for governance  | Potential white-label         |

### Visual Collaboration

| Platform   | Fit                   | Partnership Model       |
| ---------- | --------------------- | ----------------------- |
| **Mural**  | Enterprise DAOs       | Integration partnership |
| **Miro**   | General collaboration | API integration         |
| **FigJam** | Design-focused DAOs   | Embed integration       |

### Live Polling

| Platform            | Fit            | Partnership Model      |
| ------------------- | -------------- | ---------------------- |
| **Slido**           | Best value     | Embed or API           |
| **Mentimeter**      | Best analytics | API for sentiment      |
| **Poll Everywhere** | Enterprise     | PowerPoint integration |

---

## Appendix: Research Sources

### Deliberation Tools

- [Deliberatorium - MIT Collaboratorium](https://www.deliberatorium.org/)
- [Klein & Majdoubi (2024) - Toxicity in Structured Debates](https://serendipolis.com/)
- [Delib.net API Documentation](https://help.delib.net/article/350-api-v2-x-developers-guide)
- [Delib.net Response Moderation](https://help.delib.net/article/107-response-publishing-what-is-moderation)
- [Discuto Platform Features](https://www.discuto.io/en/features)

### Polling Tools

- [Poll Everywhere Features](https://www.polleverywhere.com/)
- [Slido Product Features](https://www.slido.com/product)
- [Mentimeter Live Polling](https://www.mentimeter.com/features/live-polling)

### Collaboration Tools

- [Mural Features](https://www.mural.co/features)
- [Trello Feature Documentation](https://support.atlassian.com/trello/docs/)
- [Etherpad HTTP API](https://docs.etherpad.org/api/http_api.html)

### Meeting Platforms

- [Zoom Transcription Guide](https://support.zoom.com/hc/en/article?id=zm_kb&sysparm_article=KB0064927)
- [Microsoft Teams Town Hall](https://learn.microsoft.com/en-us/microsoftteams/plan-webinars)
- [Jitsi Meet GitHub](https://github.com/jitsi/jitsi-meet)
- [OpenTalk](https://opentalk.eu/en)

---

_Report generated as part of EnDAO product development. December 6, 2025._
