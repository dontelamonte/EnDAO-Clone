# Firestore Indexes for Admin Action Proposals

## Purpose

Defines required Firestore composite indexes for the Admin Action Proposals system to support efficient querying of pending proposals, proposal history, and admin governance workflows.

## Last Updated

October 3, 2025

## Required Indexes for Phase 2: Multi-Signature Approval Workflow

### Collection: `admin-action-proposals`

#### Index 1: Pending Proposals by DAO

**Purpose**: Query pending and approved proposals for a specific DAO

**Fields**:

- `daoId` (Ascending)
- `status` (Ascending)
- `createdAt` (Descending)

**Query Pattern**:

```javascript
query(
  collection(db, 'admin-action-proposals'),
  where('daoId', '==', daoId),
  where('status', 'in', ['pending', 'approved']),
  orderBy('createdAt', 'desc'),
  limit(20)
);
```

**Creation in Firebase Console**:

1. Go to Firestore → Indexes
2. Click "Create Index"
3. Collection ID: `admin-action-proposals`
4. Fields:
   - `daoId` → Ascending
   - `status` → Ascending
   - `createdAt` → Descending
5. Query scope: Collection
6. Click "Create Index"

---

## Installation Instructions

### Manual Creation (Firebase Console)

1. Open [Firebase Console](https://console.firebase.google.com)
2. Select your EnDAO project
3. Navigate to Firestore Database → Indexes
4. Create the index described above

### Automatic Creation (First Query)

When you first run `getPendingProposals()`, Firestore will provide a link to automatically create the required index. Click the link and wait for index creation to complete (usually 1-2 minutes).

### Verify Index Creation

```bash
# Check index status in Firebase Console
Firestore → Indexes → Composite

# Look for:
Collection: admin-action-proposals
Fields: daoId (ASC), status (ASC), createdAt (DESC)
Status: Enabled ✓
```

---

## Index Performance Characteristics

- **Index Size**: ~100 bytes per proposal
- **Write Latency**: +5-10ms per proposal write
- **Query Performance**: Sub-100ms for typical DAO (< 100 proposals)
- **Scaling**: Linear with proposal count per DAO

---

## Future Indexes (Not Required for Phase 2)

These indexes may be needed in future phases:

### Index 2: All Proposals by Action Type (Analytics)

**Fields**:

- `action` (Ascending)
- `createdAt` (Descending)

### Index 3: Proposals by Status (Global View)

**Fields**:

- `status` (Ascending)
- `createdAt` (Descending)

### Index 4: Proposals by Initiator (User History)

**Fields**:

- `initiatorId` (Ascending)
- `createdAt` (Descending)

---

## Maintenance Notes

- Indexes auto-update when documents change
- No manual maintenance required
- Monitor index size in Firebase Console → Usage tab
- Consider archiving old executed proposals after 2 years (future enhancement)
