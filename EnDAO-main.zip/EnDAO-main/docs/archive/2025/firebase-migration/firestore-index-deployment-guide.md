# Firestore Index Deployment Guide

## Purpose

This guide provides phased deployment instructions for Firestore composite indexes required by the EnDAO platform, minimizing disruption while ensuring optimal query performance.

## Last Updated

September 2025

## Executive Summary

The EnDAO MVP currently has **4 composite indexes** configured but requires **32 additional indexes** to support all active query patterns. This deployment guide provides a phased approach to minimize disruption.

## Current State

### ✅ Existing Indexes (Keep)

```bash
# These 3 indexes are actively used and should be retained:
1. isDiscoverable (ASC) + status (ASC) + createdAt (DESC)    # DAO discovery
2. isFeatured (ASC) + status (ASC) + createdAt (DESC)        # Featured DAOs
3. status (ASC) + createdAt (DESC)                           # Basic DAO sorting
```

### ⚠️ Potentially Unused Index (Investigate)

```bash
# This index may be legacy - investigate before removing:
4. visibility (ASC) + status (ASC) + createdAt (DESC)        # Legacy DAO filtering
```

## Deployment Strategy

### Phase 1: Critical Indexes (Deploy Immediately)

These indexes support high-frequency, user-facing queries that are currently slow or failing:

```bash
# Deploy these 6 indexes first:
firebase deploy --only firestore:indexes --project <project-id>
```

**Critical Indexes:**

1. **User DAO Membership** - `memberIds (array-contains) + createdAt (DESC)`
2. **Basic Proposals** - `daoId (ASC) + createdAt (DESC)`
3. **Proposal Status** - `daoId (ASC) + status (ASC) + createdAt (DESC)`
4. **User Vote Lookup** - `proposalId (ASC) + userId (ASC) + isDeleted (ASC)`
5. **Member Lookup** - `daoId (ASC) + userId (ASC)`
6. **DAO Activity Feed** - `daoId (ASC) + createdAt (DESC)`

**Expected Impact:**

- ✅ Fixes user DAO membership queries (critical for dashboards)
- ✅ Enables proper proposal filtering and sorting
- ✅ Fixes vote lookup performance
- ✅ Enables member management features

### Phase 2: Feature Support Indexes (Deploy Next)

These indexes support specific features and admin functionality:

**Medium Priority (Deploy Week 2):**

- Comment system indexes (4 indexes)
- Treasury activity indexes (2 indexes)
- Advanced proposal queries (3 indexes)
- Join request indexes (2 indexes)

### Phase 3: Advanced Features (Deploy Later)

**Lower Priority (Deploy Month 2):**

- Tag-based search indexes (2 indexes)
- Trending/recommendation indexes (2 indexes)
- Advanced member filtering (2 indexes)
- Activity analytics indexes (3 indexes)

## Deployment Commands

### Step 1: Backup Current Configuration

```bash
cp firestore.indexes.json firestore.indexes.backup.json
```

### Step 2: Deploy Phase 1 (Critical)

```bash
# Create a Phase 1 file with only critical indexes
cp firestore.indexes.optimized.json firestore.indexes.json

# Deploy indexes to production
# NOTE: Always review changes carefully before deploying
firebase deploy --only firestore:indexes

# When prompted "Would you like to delete these indexes?", select N (No)
# unless you have explicit approval to remove production indexes
```

### Step 3: Monitor Index Build Progress

```bash
# Check index build status
firebase firestore:indexes --project <project-id>

# Indexes build automatically - no downtime required
```

## Cost Considerations

### Index Storage Costs

- **Current**: ~4 indexes × minimal storage
- **New**: ~32 indexes × moderate storage
- **Estimated increase**: 3-5x storage costs (still minimal for this app size)

### Query Performance Gains

- User dashboard load times: **2-5 seconds → 200-500ms**
- Proposal list filtering: **3-8 seconds → 300-800ms**
- Member lookups: **1-3 seconds → 100-300ms**
- Activity feeds: **2-4 seconds → 200-400ms**

## Rollback Plan

If issues arise:

```bash
# Restore previous configuration
cp firestore.indexes.backup.json firestore.indexes.json
firebase deploy --only firestore:indexes --project <project-id>
```

**Note:** Index deletions are permanent and require rebuild time. Plan rollbacks carefully.

## Monitoring & Validation

### Post-Deployment Checks

1. **Query Performance**: Monitor Firebase console for query performance improvements
2. **Error Rates**: Check application logs for Firestore query errors
3. **User Experience**: Monitor page load times for DAO/proposal pages
4. **Cost Impact**: Monitor Firebase billing for index storage increases

### Success Metrics

- [ ] DAO dashboard loads <500ms (from 2-5s)
- [ ] Proposal filtering works without errors
- [ ] User membership queries complete <300ms
- [ ] No Firestore "missing index" errors in logs
- [ ] Activity feeds load <400ms

## Risk Mitigation

### Low Risk Deployment

- ✅ Index builds happen in background without downtime
- ✅ Existing queries continue working during index builds
- ✅ Can deploy incrementally (Phase 1, then 2, then 3)
- ✅ Can rollback index additions if needed

### Potential Issues

- ⚠️ Index builds can take 5-30 minutes for large collections
- ⚠️ Slight increase in write latency during index builds
- ⚠️ Storage cost increases (minimal for this app size)

## Next Steps

1. **Review and approve** this deployment plan
2. **Deploy Phase 1** critical indexes to production
3. **Monitor performance** improvements
4. **Deploy remaining phases** incrementally
5. **Clean up unused indexes** after validation

## Questions for Review

1. Should we investigate the `visibility` field usage before removing that index?
2. Should we deploy all indexes at once or use the phased approach?
3. Do we need additional monitoring/alerting for index build progress?
