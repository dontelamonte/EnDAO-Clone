# Firebase Authentication Flow

## Why We Use Firebase Auth (But Not For Authentication)

EnDAO uses **Privy** for all user authentication. Firebase Auth exists solely to:

1. Generate custom tokens from Privy tokens
2. Populate `request.auth` in Firestore security rules
3. Enable client-side Firestore queries with auth context

**Key Insight**: Firebase Auth is a "bridge" that allows Privy-authenticated users to access Firestore with proper security rules.

## Token Exchange Flow

```
┌──────────────────────────────────────────────────────────────────────┐
│                     Authentication Flow                              │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  1. User logs in via Privy (social, email, wallet)                   │
│                          │                                           │
│                          ▼                                           │
│  2. Client receives Privy access token                               │
│                          │                                           │
│                          ▼                                           │
│  3. Client calls /api/auth/firebase-token with Privy token           │
│                          │                                           │
│                          ▼                                           │
│  4. Server validates Privy token via Privy SDK                       │
│                          │                                           │
│                          ▼                                           │
│  5. Server generates Firebase custom token using Admin SDK           │
│                          │                                           │
│                          ▼                                           │
│  6. Client signs in: signInWithCustomToken(auth, customToken)        │
│                          │                                           │
│                          ▼                                           │
│  7. Firestore queries now have request.auth context                  │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

## Critical Files

| File                                       | Purpose                                             |
| ------------------------------------------ | --------------------------------------------------- |
| `src/lib/auth/auth-context.tsx`            | Token exchange orchestration, auth state management |
| `src/app/api/auth/firebase-token/route.ts` | Custom token generation endpoint                    |
| `src/lib/firebase-admin.ts`                | Firebase Admin SDK for server-side operations       |
| `src/lib/firebase/config.ts`               | Client-side Firebase initialization                 |
| `firestore.rules`                          | Security rules using `request.auth`                 |

## Security Rules Context

The token exchange creates a Firebase Auth user with `uid` equal to the Privy user ID. This enables security rules like:

```javascript
// firestore.rules
function isSignedIn() {
  return request.auth != null;
}

function isUser(userId) {
  return isSignedIn() && request.auth.uid == userId;
}

function isDAOAdmin(daoId) {
  return isSignedIn() &&
    request.auth.uid in get(/databases/$(database)/documents/daos/$(daoId)).data.admins;
}
```

## Firebase App Check

App Check adds an additional layer of security by verifying that requests come from our legitimate app:

```
┌─────────────────────────────────────────────────────────┐
│                   Request Verification                   │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Without App Check:                                     │
│  - Anyone with Firebase config can query Firestore      │
│  - Config is visible in client-side JS bundles          │
│                                                         │
│  With App Check:                                        │
│  - Requests must include valid App Check token          │
│  - Token proves request is from our legitimate app      │
│  - Scraped credentials are useless without the token    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

Configuration: `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` environment variable

## Common Issues & Solutions

### Issue: "User not recognized" after login

**Cause**: Token exchange didn't complete, so Firestore queries have no auth context.

**Solution**: Check auth-context.tsx for proper token exchange sequence. Ensure `signInWithCustomToken` completes before accessing Firestore.

### Issue: 500 errors on API routes

**Cause**: Firebase Admin SDK not initialized (missing env vars in Vercel).

**Solution**: Verify `FIREBASE_ADMIN_*` environment variables are set correctly:

- `FIREBASE_ADMIN_PROJECT_ID`
- `FIREBASE_ADMIN_CLIENT_EMAIL`
- `FIREBASE_ADMIN_PRIVATE_KEY` (must have `\n` properly escaped)

### Issue: Security rule denials

**Cause**: `request.auth` is null because token exchange didn't happen.

**Solution**: Ensure client calls `/api/auth/firebase-token` and waits for `signInWithCustomToken` to complete.

## Architecture Decision Record

### Why Privy + Firebase instead of just Firebase Auth?

1. **Better UX**: Privy provides social logins, email magic links, and embedded wallets
2. **Web3 Native**: Privy handles wallet connections seamlessly
3. **Firestore Advantages**: Security rules, offline support, real-time listeners
4. **Best of Both**: Privy for auth, Firebase for database

### Why not server-side Firestore everywhere?

Client-side Firestore queries are preferred because:

1. **Auth context automatic**: Token exchange populates `request.auth`
2. **Security rules enforced**: No need to manually check permissions in code
3. **Offline support**: 100MB cache enables offline access
4. **Real-time updates**: Snapshot listeners work automatically

Use server-side (Firebase Admin SDK) only when:

1. Bypassing security rules is necessary (admin operations)
2. Server-to-server communication
3. Background jobs without user context

---

_Last updated: December 5, 2025_
