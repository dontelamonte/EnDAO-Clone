# AI Agents as Governance Participants: A Concept Document

**Date**: December 6, 2025
**Status**: Exploratory Research
**Purpose**: Explore the frontier of AI agents as first-class participants in institutional governance

---

## Executive Summary

A paradigm shift is emerging: **AI agents aren't just tools that help humans govern - they're becoming actors that participate in governance themselves.**

Thanks to blockchain infrastructure, AI agents can now have:

- **Wallets** for financial autonomy
- **Identity** for accountability
- **Permissions** for scoped authority
- **Audit trails** for transparency

This document explores what this means for EnDAO's vision of "institutional rails" and how we might build infrastructure that accommodates both human and AI participants.

---

## The Current Landscape

### AI Agents with Wallets: A $13.5B Market

The convergence of AI and crypto has created a new category of **autonomous AI agents with crypto wallets**:

| Platform                                                                                           | Market Cap     | Description                                                                              |
| -------------------------------------------------------------------------------------------------- | -------------- | ---------------------------------------------------------------------------------------- |
| [Virtuals Protocol](https://decrypt.co/299356/crypto-latest-meta-ai-agent-tokens-skyrocket)        | $5.6B (agents) | 135+ tokenized agents that can learn, plan, and make on-chain transactions               |
| [ai16z / ElizaOS](https://blog.thirdweb.com/what-is-ai16z-an-introduction-to-ai-agents-in-crypto/) | $2.3B          | Open-source framework powering autonomous trading, content, and inter-agent transactions |

> "The blockchain has the potential to 'set free' AI by giving full autonomy and agency to LLM-powered agents through blockchain wallets, enabling these agents to transact like humans."
> — [a16z 2025 Crypto Predictions](https://beincrypto.com/top-crypto-predictions-a16z/)

**Why This Matters**: Traditional banking can't give AI agents accounts. Crypto wallets enable financial autonomy for non-human actors - a prerequisite for AI participation in governance.

### AI in DAO Governance Today

[Over 20,000 DAOs manage billions in assets](https://medium.com/@fyattani/ai-powered-daos-can-bots-outvote-humans-in-governance-0aac121fa02d), but face chronic problems:

- Voter participation often **below 10%**
- Vulnerability to **whale manipulation**
- Manual treasury management costs **~12.4% in potential yields annually**

AI is already being deployed to solve these problems:

| Function                | Current Projects                                                                                      | How It Works                                                     |
| ----------------------- | ----------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| **Proposal Analysis**   | [Aave x23](https://www.aragon.org/how-to/the-future-of-daos-is-powered-by-ai)                         | Summarizes forum threads, highlights arguments, flags outcomes   |
| **Treasury Management** | [Autonolas](https://markaicode.com/dao-treasury-automation-tools-2025/)                               | Multi-objective optimization for growth, liquidity, risk         |
| **Governance Layer**    | [Quack AI](https://www.ctol.digital/news/quack-ai-secures-36m-dao-governance-funding/) ($3.6M raised) | Autonomous agents analyze proposals, score risk, recommend votes |
| **Voting Delegates**    | [Various DAOs](https://www.okx.com/learn/ai-dao-proposal-revolution-governance)                       | AI learns user preferences and votes on their behalf             |

### The Hybrid Model Emerging

The consensus isn't "AI vs. humans" but **AI with humans**:

> [MakerDAO's "Governance AI"](https://medium.com/@fyattani/ai-powered-daos-can-bots-outvote-humans-in-governance-0aac121fa02d) assists in collateral decisions but requires human ratification—a hybrid model.

| Model           | Description                                            | Example                                      |
| --------------- | ------------------------------------------------------ | -------------------------------------------- |
| **AI Advisor**  | AI recommends, humans decide                           | Aave x23 summaries                           |
| **AI Delegate** | Humans delegate authority to AI with constraints       | "Vote my preferences on budgets"             |
| **AI Executor** | AI executes within pre-approved parameters             | Treasury rebalancing within DAO-voted limits |
| **AI Actor**    | AI is a full governance participant with voting rights | Emerging frontier                            |

---

## Technical Foundations

### Agent Frameworks

Several frameworks enable building AI agents, with varying levels of crypto-native support:

| Framework                                                                                                                                | Type          | Blockchain Support                      | Notes                                  |
| ---------------------------------------------------------------------------------------------------------------------------------------- | ------------- | --------------------------------------- | -------------------------------------- |
| [ElizaOS](https://elizaos.ai/)                                                                                                           | Crypto-native | Native (wallets, swaps, DAO votes)      | ~60% market share in crypto AI agents  |
| [GOAT](https://www.decentralised.co/p/ai-agent-frameworks)                                                                               | Crypto-native | Native (minting, governance, contracts) | "Game-changer for DeFi/onchain agents" |
| [LangChain](https://www.ideas2it.com/blogs/ai-agent-frameworks)                                                                          | General       | Via plugins                             | Most popular general framework         |
| [AutoGPT](https://medium.com/@dave-patten/choosing-your-ai-stack-deep-dive-into-top-agent-frameworks-2025-a13682375b43)                  | General       | Via plugins                             | Pioneered autonomous goal-pursuit      |
| [CrewAI](https://medium.com/@iamanraghuvanshi/agentic-ai-3-top-ai-agent-frameworks-in-2025-langchain-autogen-crewai-beyond-2fc3388e7dec) | Multi-agent   | Via integration                         | Role-based agent collaboration         |

### ElizaOS Capabilities

[ElizaOS](https://docs.elizaos.ai) (from ai16z) is the leading crypto-native framework:

**Core Features**:

- TypeScript-based, open-source
- Multi-model support (OpenAI, Claude, Llama, Grok)
- Character system (JSON-defined personas)
- Plugin architecture for extensibility

**Web3 Features**:

- Wallet management and transaction signing
- Swaps, bridging, DeFi interactions
- **DAO votes and governance actions**
- On-chain data analysis
- Smart contract interactions

**Platform Connectors**:

- Discord, Telegram, Twitter/X, Farcaster
- Custom API integrations

### Account Abstraction (ERC-4337)

[Account abstraction](https://www.alchemy.com/overviews/what-is-account-abstraction) enables AI agents to have "smart accounts" rather than simple wallets:

| Feature                     | Benefit for AI Agents                         |
| --------------------------- | --------------------------------------------- |
| **Programmable validation** | Custom rules for what the agent can do        |
| **Budgetary guardrails**    | Spending limits, category restrictions        |
| **Recovery mechanisms**     | Human override if agent misbehaves            |
| **Gasless transactions**    | Paymasters cover fees (better UX)             |
| **Batched operations**      | Complex multi-step actions in one transaction |

**2025 Prediction**: [Over 200M account deployments expected, with a meaningful portion being AI agents](https://www.rhinestone.dev/blog/account-abstraction-2024-1d35f811f391).

**Key Stat**: [Over half of all monthly Safe transactions on Gnosis Chain are by Olas, a decentralized network of autonomous agents](https://www.rhinestone.dev/blog/account-abstraction-2024-1d35f811f391).

---

## What AI Agent Participation Means for EnDAO

### The Opportunity

EnDAO's "institutional rails" vision naturally extends to AI participants:

| Traditional Framing                    | Extended Framing                                                    |
| -------------------------------------- | ------------------------------------------------------------------- |
| Infrastructure for human organizations | Infrastructure for **organizations with human AND AI participants** |
| Member accounts for people             | Member accounts for **any authorized actor**                        |
| Treasury controlled by humans          | Treasury with **programmatic and human controls**                   |
| Compliance for human boards            | Compliance that **accommodates AI roles**                           |

### Agent Roles in Institutional Governance

| Role                 | Function                                            | Authority Scope                | Human Oversight             |
| -------------------- | --------------------------------------------------- | ------------------------------ | --------------------------- |
| **Secretary Agent**  | Draft minutes, track action items, answer questions | Read-only governance access    | Human approves minutes      |
| **Compliance Agent** | Monitor deadlines, prepare filings, track officers  | Read governance, write filings | Human certifies submissions |
| **Treasury Agent**   | Execute approved payments, optimize yield           | Spend within voted parameters  | Humans set parameters       |
| **Delegate Agent**   | Vote on behalf of members per preferences           | Vote power delegated by humans | Revocable delegation        |
| **Analyst Agent**    | Summarize proposals, flag risks, model impacts      | Read-only, advisory output     | Humans decide               |
| **Arbiter Agent**    | Interpret bylaws, resolve routine disputes          | Escalate edge cases            | Human appeal path           |

### The Permission Model Challenge

Current EnDAO roles (Admin, Member, Observer) are insufficient for AI agents. Need:

| Dimension          | Current Model       | Agent-Ready Model                               |
| ------------------ | ------------------- | ----------------------------------------------- |
| **Identity**       | Email/SSO           | API key, verifiable credentials, agent registry |
| **Permissions**    | Role-based (coarse) | Capability-based (granular)                     |
| **Authority**      | Binary (can/can't)  | Scoped (can do X up to Y with constraints)      |
| **Accountability** | Audit trail         | Audit trail + decision explainability           |
| **Override**       | Admin revokes       | Emergency stop, human-in-the-loop triggers      |

### Delegation Infrastructure

For AI agents to participate meaningfully, humans need to delegate authority:

```
Human Member
    │
    ├── Delegates: "Vote on operational proposals per my stated preferences"
    │   └── AI Delegate Agent
    │       ├── Constraint: Only operational (not constitutional) matters
    │       ├── Constraint: Abstain if confidence < 80%
    │       └── Audit: Log reasoning for each vote
    │
    └── Delegates: "Execute approved vendor payments up to $5K"
        └── AI Treasury Agent
            ├── Constraint: Only pre-approved vendor categories
            ├── Constraint: Max $5K per transaction, $20K monthly
            └── Override: Human approval required for exceptions
```

---

## Implementation Considerations

### Phase 1: Agent-Compatible Infrastructure

**Goal**: Make EnDAO's architecture ready for non-human participants without requiring them.

| Component          | Change                                | Complexity     |
| ------------------ | ------------------------------------- | -------------- | --- |
| **Member Model**   | Add `memberType: 'human'              | 'agent'` field | Low |
| **Authentication** | Support API key auth alongside Privy  | Medium         |
| **Permissions**    | More granular capability flags        | Medium         |
| **Audit Logging**  | Add decision context/reasoning fields | Low            |

### Phase 2: Delegation Framework

**Goal**: Allow humans to delegate specific authorities to agents.

| Component                | Description                                         | Complexity |
| ------------------------ | --------------------------------------------------- | ---------- |
| **Delegation Registry**  | Who delegated what to whom, with constraints        | Medium     |
| **Constraint Language**  | Express limits (amount, category, time, confidence) | High       |
| **Revocation**           | Instant delegation removal                          | Low        |
| **Delegation Dashboard** | UI to manage agent authorities                      | Medium     |

### Phase 3: Agent Treasury Access

**Goal**: Allow agents to execute within pre-approved parameters.

| Component             | Description                                   | Complexity |
| --------------------- | --------------------------------------------- | ---------- |
| **Safe Modules**      | Custom modules for agent-controlled execution | High       |
| **Spending Policies** | Programmatic enforcement of limits            | High       |
| **Emergency Stop**    | Human override mechanism                      | Medium     |
| **Execution Logs**    | Full audit trail of agent actions             | Low        |

### Phase 4: Native Agent Hosting (Optional)

**Goal**: Allow DAOs to deploy and manage agents directly in EnDAO.

| Component                    | Description                                      | Complexity |
| ---------------------------- | ------------------------------------------------ | ---------- |
| **Agent Templates**          | Pre-built agents (Secretary, Treasurer, Analyst) | High       |
| **Agent Configuration**      | Define persona, capabilities, constraints        | High       |
| **Agent Monitoring**         | Health, performance, decision quality            | High       |
| **Multi-Agent Coordination** | Agents collaborating on complex tasks            | Very High  |

---

## Risks and Mitigations

### Technical Risks

| Risk                         | Impact                        | Mitigation                                 |
| ---------------------------- | ----------------------------- | ------------------------------------------ |
| **Agent malfunction**        | Unintended actions, fund loss | Spending limits, human approval thresholds |
| **Model hallucination**      | Incorrect decisions           | Confidence scoring, escalation triggers    |
| **Adversarial exploitation** | Gaming agent behavior         | Rate limits, anomaly detection             |
| **Key compromise**           | Agent wallet stolen           | Multi-sig requirements, spending caps      |

### Governance Risks

| Risk                      | Impact                  | Mitigation                                 |
| ------------------------- | ----------------------- | ------------------------------------------ |
| **AI voting dominance**   | Humans marginalized     | Cap agent voting power, human-only matters |
| **Delegation abdication** | Humans stop engaging    | Engagement requirements, delegation limits |
| **Accountability gaps**   | "The AI did it" defense | Clear human responsibility, audit trails   |

### Regulatory Risks

| Risk               | Impact                               | Mitigation                                     |
| ------------------ | ------------------------------------ | ---------------------------------------------- |
| **EU AI Act**      | High-risk AI governance requirements | Comply with transparency, logging requirements |
| **Fiduciary duty** | Legal responsibility unclear         | Maintain human oversight, clear liability      |
| **CTA/Compliance** | AI can't be beneficial owner         | Humans remain legally responsible              |

---

## Open Questions

1. **Can an AI agent be a "member" of a legal entity?** Probably not under current law, but it can act as an authorized representative.

2. **How do we prevent "sybil" attacks with AI agents?** Rate limits, verification, costs.

3. **What's the right default?** Opt-in agent support? Agent-ready by default?

4. **How do we handle agent-to-agent interactions?** Multi-agent coordination protocols.

5. **What's our liability model?** Clear terms that humans bear responsibility for agents they deploy/delegate to.

---

## Competitive Landscape

| Platform               | AI Agent Support                                                                             | Status                    |
| ---------------------- | -------------------------------------------------------------------------------------------- | ------------------------- |
| **Snapshot**           | None native                                                                                  | Voting only, no execution |
| **Aragon**             | [AI-powered DAOs article](https://www.aragon.org/how-to/the-future-of-daos-is-powered-by-ai) | Exploring, not shipped    |
| **Tally**              | None native                                                                                  | On-chain focused          |
| **Quack AI**           | Full AI governance layer                                                                     | New entrant, $3.6M funded |
| **Traditional boards** | None                                                                                         | Not applicable            |

**EnDAO Opportunity**: Be the first institutional governance platform with native support for AI agent participants.

---

## Appendix: Key Sources

### AI Agents in Crypto

- [What is AI16z? An Introduction to AI Agents in Crypto](https://blog.thirdweb.com/what-is-ai16z-an-introduction-to-ai-agents-in-crypto/)
- [Crypto's Latest Meta? AI Agent Tokens Skyrocket](https://decrypt.co/299356/crypto-latest-meta-ai-agent-tokens-skyrocket)
- [a16z 2025 Crypto Predictions](https://beincrypto.com/top-crypto-predictions-a16z/)

### AI in DAO Governance

- [AI-Powered DAOs: Can Bots Outvote Humans?](https://medium.com/@fyattani/ai-powered-daos-can-bots-outvote-humans-in-governance-0aac121fa02d)
- [The Future of DAOs is Powered by AI](https://www.aragon.org/how-to/the-future-of-daos-is-powered-by-ai)
- [Quack AI Secures $3.6M for DAO Governance](https://www.ctol.digital/news/quack-ai-secures-36m-dao-governance-funding/)
- [Automating DAO Treasury Management](https://markaicode.com/dao-treasury-automation-tools-2025/)

### Technical Frameworks

- [ElizaOS Documentation](https://docs.elizaos.ai)
- [ElizaOS Overview](https://elizaos.ai/)
- [Crypto-native AI Agent Frameworks](https://www.decentralised.co/p/ai-agent-frameworks)
- [Top AI Agent Frameworks in 2025](https://www.ideas2it.com/blogs/ai-agent-frameworks)

### Account Abstraction

- [What is Account Abstraction?](https://www.alchemy.com/overviews/what-is-account-abstraction)
- [Account Abstraction 2024 Review](https://www.rhinestone.dev/blog/account-abstraction-2024-1d35f811f391)
- [ERC-4337 Documentation](https://docs.erc4337.io/)

---

_Concept document created December 6, 2025. This is exploratory research, not a committed roadmap._
