# AllinDAO Payments Infrastructure Analysis

> A comprehensive analysis of payment infrastructure options for AllinDAO's Africa deployment, comparing traditional API integration versus a crypto-forward architecture.

**Last Updated**: February 2026

---

## Executive Summary

This document analyzes two approaches for building payment infrastructure to support AllinDAO's Chamber deployments in Africa:

1. **Traditional API Approach**: Integrating Flutterwave for collection and Yellow Card for stablecoin on/off-ramps
2. **Crypto-Forward Approach**: Building on Celo blockchain with native stablecoin infrastructure

**Conclusion**: The traditional API approach is unfeasible due to provider instability, regulatory uncertainty, high fees, and dependency risks. A crypto-forward stack leveraging Celo, existing Privy/Safe infrastructure, and edge-only fiat conversion offers a more resilient, cost-effective, and future-proof solution.

---

## Part 1: The Traditional API Approach

### Proposed Architecture

The initial plan proposed using established fintech APIs:

```
Member Pays (Local Currency)
       │
       ▼
┌─────────────────┐
│   Flutterwave   │  ← Collection (NGN, GHS, KES)
│   (1.4-2.9%)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   Yellow Card   │  ← Convert to USDC
│   (1-2%)        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Chamber        │  ← Hold in Safe multi-sig
│  Treasury       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   Yellow Card   │  ← Convert back to local
│   (1-2%)        │
└────────┬────────┘
         │
         ▼
    Contractor Receives (Local Currency)
```

**Total Fees**: 4-6% per transaction cycle

---

## Part 2: Why the Traditional API Approach Is Unfeasible

### Issue 1: Provider Instability

#### Flutterwave Security Incidents

| Date | Incident | Impact |
|------|----------|--------|
| Feb 2023 | ₦2.9B hack | 27 bank accounts frozen by court order |
| Oct 2023 | ₦21B ($26M) glitch | NIBSS error + inadequate controls |
| 2024 | $7.3M loss | Ongoing fraud vulnerabilities |
| Dec 2024 | Police investigation | 601 accounts frozen |
| 2024 | Kenya fraud claims | 45 accounts frozen, 2,468 claimants |

**Source**: [TechPoint Africa](https://techpoint.africa/news/flutterwave-plans-recover-lost-funds/), [Business Daily Africa](https://www.businessdailyafrica.com/bd/corporate/companies/court-freezes-45-bank-accounts-of-nigerian-flutterwave--4269150)

> Building mission-critical Chamber infrastructure on a provider with repeated security breaches and frozen accounts creates unacceptable operational risk.

#### Yellow Card Regulatory Warnings

**June 2025**: Bank of Ghana issued public notice cautioning against Yellow Card's "Yellow Pay" product.

> "It is most unfortunate that the Bank of Ghana determined to publish this notice, as Yellow Card clearly communicated the above-mentioned facts to representatives of the Bank of Ghana well in advance of issuance of the notice." — Yellow Card General Counsel

**April 2024**: Yellow Card was not included in South Africa's official list of authorized cryptocurrency companies.

**Source**: [Yellow Card Statement](https://yellowcard.io/blog/statement-regarding-bank-of-ghana-notice-of-10-jun/), [Tech In Africa](https://www.techinafrica.com/binance-and-yellow-card-not-included-in-south-africas-official-list-of-authorized-cryptocurrency-companies/)

> Central banks publicly warning against your offramp partner is a catastrophic red flag for enterprise deployment.

---

### Issue 2: Regulatory Limbo

#### Nigeria: "Legal" But Banks Won't Participate

Despite the 2023 CBN ban reversal and the 2025 Investment and Securities Act:

> "An operations staff member at a prominent Nigerian fintech told Mariblock that their company still restricts crypto-linked accounts, even a year after the CBN lifted the ban."

> "Another widely used fintech product literally greets users with a notice that reads, 'In accordance with the CBN regulations, accounts dealing with cryptocurrency transactions will be restricted.'"

**Source**: [Mariblock](https://www.mariblock.com/crypto-is-legal-in-nigeria-until-the-bank-disagrees/)

**Key Issues**:
- SEC has only issued 2 provisional licenses (Busha, Quidax)
- Banks independently restrict crypto-linked accounts
- EFCC continues freezing accounts linked to stablecoin trading
- 25% tax on crypto profits starting 2026

#### Ghana: Framework Not Yet Operational

The VASP Bill passed in 2025, but:

- Licensing rules roll out in **phases during 2026**
- Bank of Ghana still establishing its "specialised supervision unit"
- Existing VASPs must register and meet compliance standards
- No clear timeline for operational licenses

**Source**: [Mariblock](https://www.mariblock.com/ghana-passes-law-to-regulate-crypto-and-its-service-providers/), [Afriwise](https://www.afriwise.com/blog/bank-of-ghana-to-commence-regulation-of-cryptocurrency-in-september-2025)

> GCCI deployment would be building on a legal framework that doesn't fully exist yet.

---

### Issue 3: The Offramp Liquidity Problem

Despite claims that offramp infrastructure is "solved," fundamental issues persist:

> "Stablecoins were originally designed to function inside crypto markets, not to integrate seamlessly with the global banking system. That legacy still shapes today's infrastructure. **Off-ramps are treated as an edge case rather than a core feature.**"

**Source**: [PYMNTS](https://www.pymnts.com/cryptocurrency/2026/stablecoins-face-payments-challenge-with-cashing-out)

**East Africa Specific Issues**:

> "Most East African currencies lack liquid direct exchange markets. A payment from Tanzania to Rwanda might require TZS → USD → RWF conversions, with each hop adding costs and complexity."

**Source**: [YoguPay](https://yogupay.com/stablecoins-reducing-fx-friction-cross-border-transact/)

**Practical Implications**:
- Yellow Card's $3B volume is spread across 20 countries
- Local liquidity for specific corridors (GHS ↔ USDC) may be thin
- Large Chamber disbursements ($50K+) could move local markets
- Settlement times unpredictable during high volume

---

### Issue 4: Uncompetitive Fee Structure

| Transaction Path | Total Fees | Competitive Benchmark |
|------------------|------------|----------------------|
| Flutterwave + Yellow Card (round trip) | 4-6% | — |
| OPay local transfer | <1% | 4-6x cheaper |
| Mobile money direct | 1-2% | 2-3x cheaper |
| Traditional SWIFT | 3-5% | Similar cost |

**The Core Problem**: Why would a Ghana cannabis farmer pay 4% fees when they can pay 1.5% via mobile money?

The stablecoin rails only justify their cost if:
- Cross-border payments are frequent (Ghana → Nigeria)
- Currency volatility savings exceed 4% annually
- On-chain treasury transparency is a selling point

For most Chamber operations, the traditional path is cheaper.

---

### Issue 5: Integration Complexity

**What "simple API integration" actually requires**:

| Requirement | Reality |
|-------------|---------|
| Yellow Card KYC | Must collect ID documents from every member receiving disbursements |
| AML Compliance | Inherit their compliance burden — suspicious transaction reporting |
| Wallet Infrastructure | Manage stablecoin wallets, private keys, transaction signing |
| Reconciliation | Three-way reconciliation: AllinDAO system, Flutterwave, Yellow Card |
| Error Handling | What happens when Yellow Card offramp fails at 2 AM? |
| Rate Fluctuation | Quoted rate vs. execution rate — who absorbs slippage? |
| Legal Agreements | Separate contracts with each provider |
| Bank Relationships | Account setup in each target country |

**The "30 minutes to integrate" claim** applies to sandbox environments only.

---

### Issue 6: Single Points of Failure

```
Member Pays → [Flutterwave] → Convert → [Yellow Card] → Disburse
                  │                         │
            Single provider            Single provider
            If frozen: DEAD            If suspended: DEAD
```

**Catastrophic Scenarios**:

| Event | Impact | Precedent |
|-------|--------|-----------|
| Flutterwave hack | All Chamber collections halt | Has happened 3x |
| Yellow Card regulatory action | All disbursements halt | Ghana warning June 2025 |
| Nigerian EFCC investigation | Accounts frozen indefinitely | 601 accounts Dec 2024 |
| Provider decides Chamber volumes aren't worth compliance risk | Terminated without notice | Common for high-risk verticals |

**There is no "Flutterwave alternative"** with equivalent African coverage. Paystack (owned by Stripe) has narrower reach. Local alternatives lack multi-country support.

---

### Issue 7: Volume-to-Complexity Mismatch

**GCCI First Year Projections**:
- Target: ~100 licensed operators (optimistic)
- Average annual dues: $200-500
- Total transaction volume: $20,000-50,000/year

**At These Volumes**:
- Yellow Card won't prioritize integration issues
- Flutterwave enterprise support won't respond quickly
- Per-transaction fixed costs dominate economics
- Compliance overhead exceeds revenue potential

> We would be building enterprise-grade infrastructure for micro-volumes.

---

### Issue 8: Market Signal — Why Hasn't Anyone Else Done This?

If Yellow Card and Flutterwave truly solve Africa payments, why hasn't anyone built this?

**Companies That Could Have**:

| Company | Funding | What They Did Instead |
|---------|---------|----------------------|
| Chipper Cash | $250M+ | Pivoted away from B2B model |
| Eversend | $7M | Focused on consumer, not Chamber/B2B |
| AZA Finance | $15M | Treasury management only, no governance |
| Traditional Chamber software vendors | Various | None have Africa crypto rails |

**The Market Signal**: These companies did the math and realized the compliance burden, provider instability, and thin margins don't work.

---

### Issue 9: Timing Mismatch

| Dependency | Earliest Ready |
|------------|----------------|
| Ghana VASP licensing | "Phases during 2026" |
| Nigeria banks accepting crypto firms | Theoretically now, practically uncertain |
| Yellow Card Ghana regulatory clarity | Post-June 2025 resolution |
| Allinka platform ready | Unknown |
| EnDAO mobile app production-ready | Q2 2026 estimate |

**Best Case**: Everything aligns late 2026

**By Then**:
- Regulatory landscape may have changed again
- Yellow Card may have pivoted or failed
- Better solutions may exist
- First-mover advantage lost

---

## Part 3: The Crypto-Forward Alternative

### Core Principle

> Don't try to bridge traditional finance and crypto at every step. Go crypto-native internally, and only touch fiat at the edges.

```
TRADITIONAL APPROACH:
Fiat → Crypto → Fiat → Crypto → Fiat
      (fees)   (fees)   (fees)

CRYPTO-FORWARD APPROACH:
Fiat → Crypto ════════════════════ → Fiat
      (onramp)  [Native on-chain]   (offramp)
```

---

### Recommended Stack

#### Layer 1: Blockchain — Celo

| Advantage | Detail |
|-----------|--------|
| **Africa traction** | MiniPay: 11M wallets, 300M transactions |
| **Mobile-first** | Phone number → wallet mapping via SocialConnect |
| **Sub-cent fees** | $0.001 transactions, pay gas in stablecoins |
| **Ethereum L2** | Full EVM compatibility, audited infrastructure |
| **FiatConnect** | Open API standard for on/off ramps, multiple providers |

**Source**: [Celo](https://celo.org/), [MiniPay](https://press.opera.com/2025/05/13/minipay-standalone-app-ios-android/)

> Celo is the #1 Ethereum L2 with 700K+ daily active users and the #1 transport layer for USDT with 3M+ weekly active users.

#### Layer 2: Wallet Infrastructure — Privy + Safe

**EnDAO Already Uses**:
- **Privy** for authentication (now Stripe-owned, adding Bridge stablecoin integration)
- **Safe** for treasury multi-sig

**Upgrade Path**:

| Current | Upgrade To |
|---------|------------|
| Privy EOA wallets | Privy + Safe Smart Accounts (ERC-4337) |
| Safe on Ethereum/Base | Safe on Celo (sub-cent fees) |
| Manual treasury operations | Safe Modules for automation |
| No mobile signing | Passkey signers for mobile |

**Source**: [Privy Smart Wallets](https://docs.privy.io/wallets/using-wallets/evm-smart-wallets/overview), [Safe Modules](https://docs.safe.global/advanced/smart-account-modules)

#### Layer 3: Cross-Chain — Circle CCTP V2

When a Ghana Chamber needs to pay a Nigerian contractor on a different chain:

```
Ghana Treasury (USDC on Celo)
  → CCTP V2 burn (seconds)
  → CCTP V2 mint on Base/Polygon
  → Local offramp
```

**CCTP V2 Features**:
- **Fast Transfer**: Seconds, not 13-19 minutes
- **Native burn/mint**: No liquidity pools, no slippage
- **17 chains supported**: Ethereum, Base, Polygon, Stellar, Avalanche, etc.
- **$110B+ cumulative volume**: Battle-tested infrastructure

**Source**: [Circle CCTP V2](https://www.circle.com/cross-chain-transfer-protocol)

#### Layer 4: On/Off Ramps — FiatConnect + Noah

**Onramp (Fiat → Crypto)**:
- **FiatConnect**: Celo's open API standard
- **Providers**: Yellow Card, Transak, Binance, Transfi
- **Methods**: M-Pesa, MTN MoMo, Airtel Money, bank transfer

**Offramp (Crypto → Fiat)**:
- **Noah API**: MiniPay's partner for global-to-local payouts
- **Coverage**: Latin America, Africa, Asia
- **Methods**: Mobile money, bank transfer, PayPal

**Source**: [MiniPay + Noah Partnership](https://cryptonews.com/news/operas-celo-based-minipay-wallet-launches-global-to-local-stablecoin-payments-with-noah/)

#### Layer 5: Stablecoins

| Stablecoin | Use Case | Advantage |
|------------|----------|-----------|
| **USDC** | Primary treasury, cross-chain | Most liquid, CCTP V2 native |
| **cUSD** | Celo-native operations | Lowest fees, MiniPay default |
| **cNGN** | Nigeria local (future) | Avoids USD conversion, regulated |

---

### Full Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ALLINDAO CRYPTO STACK                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     MEMBER EXPERIENCE                                │    │
│  ├─────────────────────────────────────────────────────────────────────┤    │
│  │                                                                      │    │
│  │   Mobile App (Expo)              Web App (Next.js)                  │    │
│  │        │                              │                              │    │
│  │        └──────────────┬──────────────┘                              │    │
│  │                       ▼                                              │    │
│  │            ┌─────────────────────┐                                  │    │
│  │            │   Privy Embedded    │  ← Social login, email, phone    │    │
│  │            │   Wallet            │  ← Passkey authentication        │    │
│  │            └──────────┬──────────┘                                  │    │
│  │                       │                                              │    │
│  │                       ▼                                              │    │
│  │            ┌─────────────────────┐                                  │    │
│  │            │   Safe Smart        │  ← ERC-4337 Account Abstraction  │    │
│  │            │   Account           │  ← Gas sponsorship by Chamber    │    │
│  │            │   (Personal)        │  ← Session keys for dApps        │    │
│  │            └─────────────────────┘                                  │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     CHAMBER TREASURY                                 │    │
│  ├─────────────────────────────────────────────────────────────────────┤    │
│  │                                                                      │    │
│  │   ┌─────────────────────────────────────────────────────────────┐   │    │
│  │   │              Safe Multi-Sig Treasury                         │   │    │
│  │   │              (2-of-3 or 3-of-5 signers)                     │   │    │
│  │   ├─────────────────────────────────────────────────────────────┤   │    │
│  │   │                                                              │   │    │
│  │   │  MODULES (ERC-7579):                                        │   │    │
│  │   │  • Spending Limits — daily/weekly caps per signer           │   │    │
│  │   │  • Allowance — recurring payments to contractors            │   │    │
│  │   │  • Recovery — social recovery if signers lost               │   │    │
│  │   │  • Governance — proposal-based execution from EnDAO         │   │    │
│  │   │                                                              │   │    │
│  │   │  ASSETS:                                                     │   │    │
│  │   │  • USDC — primary, cross-chain via CCTP V2                  │   │    │
│  │   │  • cUSD — Celo native, lowest fees                          │   │    │
│  │   │  • cNGN — Nigeria local operations (future)                 │   │    │
│  │   │                                                              │   │    │
│  │   └─────────────────────────────────────────────────────────────┘   │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     ON/OFF RAMPS                                     │    │
│  ├─────────────────────────────────────────────────────────────────────┤    │
│  │                                                                      │    │
│  │   ONRAMP (Fiat → Crypto)           OFFRAMP (Crypto → Fiat)         │    │
│  │   ┌───────────────────┐            ┌───────────────────┐            │    │
│  │   │   FiatConnect     │            │   Noah API        │            │    │
│  │   ├───────────────────┤            ├───────────────────┤            │    │
│  │   │ • M-Pesa (Kenya)  │            │ • M-Pesa          │            │    │
│  │   │ • MTN MoMo (Ghana)│            │ • MTN MoMo        │            │    │
│  │   │ • Airtel Money    │            │ • Bank Transfer   │            │    │
│  │   │ • Bank Transfer   │            │ • PayPal          │            │    │
│  │   │ • Card (Transak)  │            │                   │            │    │
│  │   └───────────────────┘            └───────────────────┘            │    │
│  │                                                                      │    │
│  │   Providers:                       Fallback:                        │    │
│  │   Yellow Card, Transak,            Yellow Card, Paychant            │    │
│  │   Binance, Transfi                                                  │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     CROSS-CHAIN (CCTP V2)                            │    │
│  ├─────────────────────────────────────────────────────────────────────┤    │
│  │                                                                      │    │
│  │   Celo ←→ Ethereum ←→ Base ←→ Polygon ←→ Stellar ←→ Avalanche      │    │
│  │                                                                      │    │
│  │   • Native burn/mint (no liquidity pools)                           │    │
│  │   • Fast Transfer: seconds, not minutes                             │    │
│  │   • $110B+ cumulative volume                                        │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Cost Comparison

| Component | Traditional API | Crypto-Forward |
|-----------|-----------------|----------------|
| **Payment collection** | Flutterwave 1.4-2.9% | FiatConnect ~1-2% |
| **Conversion to stablecoin** | Yellow Card 1-2% | Native on Celo (sub-cent) |
| **Treasury operations** | Ethereum gas $1-5/tx | Celo gas $0.001/tx |
| **Cross-chain transfer** | Manual bridge ~0.3% | CCTP V2 (gas only) |
| **Disbursement** | Yellow Card 1-2% | Noah ~1-2% |
| **TOTAL (round trip)** | **4-6%** | **2-4%** |

**Annual Savings at Scale**:

| Annual Volume | Traditional Cost | Crypto-Forward Cost | Savings |
|---------------|------------------|---------------------|---------|
| $100,000 | $4,000-6,000 | $2,000-4,000 | $2,000+ |
| $500,000 | $20,000-30,000 | $10,000-20,000 | $10,000+ |
| $1,000,000 | $40,000-60,000 | $20,000-40,000 | $20,000+ |

---

### Risk Comparison

| Risk Factor | Traditional API | Crypto-Forward |
|-------------|-----------------|----------------|
| **Provider bankruptcy/exit** | High — single points of failure | Medium — multiple FiatConnect providers |
| **Regulatory action** | High — providers face direct scrutiny | Medium — on-chain activity harder to freeze |
| **Security breach** | High — Flutterwave track record | Low — Safe multi-sig, audited contracts |
| **Account freezing** | High — bank/EFCC can freeze instantly | Low — on-chain assets controlled by keys |
| **Fee increases** | High — no alternatives | Medium — switch providers via FiatConnect |
| **Technology obsolescence** | Medium — API-dependent | Low — open standards, EVM compatible |

---

### Implementation Phases

#### Phase 1: Foundation (Weeks 1-4)

**Objective**: Migrate treasury infrastructure to Celo

| Task | Effort | Risk |
|------|--------|------|
| Deploy Safe contracts on Celo | Low | Low |
| Add Celo network to Privy config | Low | Low |
| Test USDC/cUSD transfers on testnet | Low | Low |
| Integrate basic FiatConnect onramp | Medium | Medium |
| Document operational procedures | Low | Low |

**Deliverable**: Chamber treasury operational on Celo with basic fiat onramp

#### Phase 2: Smart Accounts (Weeks 5-8)

**Objective**: Upgrade member experience with account abstraction

| Task | Effort | Risk |
|------|--------|------|
| Upgrade member wallets to Safe Smart Accounts | Medium | Medium |
| Implement passkey signing for mobile | Medium | Low |
| Add gas sponsorship (Chamber pays member gas) | Medium | Low |
| Add session keys for recurring actions | Medium | Medium |
| Test with pilot user group | Low | Low |

**Deliverable**: Gasless, mobile-friendly member wallets

#### Phase 3: Offramp Integration (Weeks 9-12)

**Objective**: Enable fiat disbursements to members/contractors

| Task | Effort | Risk |
|------|--------|------|
| Integrate Noah API | Medium | Medium |
| Build disbursement flow: Treasury → Member → Local currency | High | Medium |
| Handle edge cases: failed transactions, refunds | High | Medium |
| Compliance documentation and audit trail | Medium | Low |
| Production testing with small amounts | Low | Medium |

**Deliverable**: End-to-end payment flow operational

#### Phase 4: Cross-Chain & Expansion (Future)

**Objective**: Multi-country, multi-chain support

| Task | Effort | Risk |
|------|--------|------|
| CCTP V2 integration | Medium | Low |
| Support USDC on Base/Ethereum for international | Medium | Low |
| Monerium integration for EU expansion (EURe + IBAN) | High | Medium |
| Additional FiatConnect providers | Medium | Low |

**Deliverable**: Global Chamber payment infrastructure

---

### What We Don't Build

| Component | Why Not |
|-----------|---------|
| **Our own stablecoin** | Use USDC/cUSD — regulated, liquid, trusted |
| **Our own offramp infrastructure** | Use FiatConnect/Noah — they have licenses and bank relationships |
| **Our own KYC system** | Providers handle this — we inherit compliance |
| **A consumer wallet app** | Not competing with OPay/MiniPay — we're B2B |
| **Custom blockchain** | Celo is purpose-built for this use case |

---

## Part 4: Strategic Implications

### For GCCI (Ghana Chamber of Cannabis Industry)

**Recommended Approach**:

1. **Phase 1 Focus**: Celo treasury with cUSD/USDC
2. **Onramp**: MTN MoMo via FiatConnect (Ghana coverage)
3. **Offramp**: Noah API when ready, Yellow Card as fallback
4. **Timeline**: Align with Ghana VASP licensing (late 2026)

**Why This Works for GCCI**:
- Cannabis industry is high-risk — traditional banking unreliable
- On-chain transparency valuable for compliance documentation
- Cross-border potential (Ghana ↔ Nigeria ↔ Pan-Africa)
- Celo's MiniPay ecosystem provides familiar UX for members

### For AllinDAO Platform Strategy

The crypto-forward stack aligns with both threads from the AllinDAO Strategy:

**Thread 1 (Service)**: Enterprise deployments get:
- Lower fees than traditional alternatives
- Regulatory resilience
- Transparent treasury auditing
- Multi-country support without per-country integrations

**Thread 2 (Platform)**: The organic individual → collective journey:
- Members get embedded wallets with social login
- No need to understand "crypto" — it's just a wallet
- Gasless transactions remove friction
- Treasury governance integrated with EnDAO proposals

---

## Part 5: Conclusion

### Summary of Findings

| Factor | Traditional API | Crypto-Forward |
|--------|-----------------|----------------|
| **Feasibility** | Unfeasible | Feasible |
| **Provider Risk** | Critical | Manageable |
| **Regulatory Risk** | High | Medium |
| **Total Fees** | 4-6% | 2-4% |
| **Operational Complexity** | High | Medium |
| **Existing Infrastructure Leverage** | None | Privy + Safe |
| **Africa Market Fit** | Weak | Strong (Celo/MiniPay) |
| **Timeline to Production** | 6-12 months | 3-6 months |

### Recommendation

**Abandon the traditional API approach.** The combination of:
- Flutterwave's security incidents
- Yellow Card's regulatory warnings
- 4-6% fee structure
- No fallback options
- Regulatory uncertainty in target markets

...makes this path unviable for enterprise Chamber deployments.

**Pursue the crypto-forward stack** leveraging:
- Existing Privy + Safe infrastructure
- Celo's Africa-focused ecosystem
- FiatConnect's multi-provider flexibility
- CCTP V2's cross-chain capability

The crypto-forward approach is not just cheaper — it's more resilient, more aligned with the target market, and builds on infrastructure we already have.

---

## Appendix A: Research Sources

### Provider Issues
- [Flutterwave Fund Recovery](https://techpoint.africa/news/flutterwave-plans-recover-lost-funds/)
- [Flutterwave Account Freeze](https://www.businessdailyafrica.com/bd/corporate/companies/court-freezes-45-bank-accounts-of-nigerian-flutterwave--4269150)
- [Yellow Card Ghana Notice](https://yellowcard.io/blog/statement-regarding-bank-of-ghana-notice-of-10-jun/)
- [Yellow Card South Africa Status](https://www.techinafrica.com/binance-and-yellow-card-not-included-in-south-africas-official-list-of-authorized-cryptocurrency-companies/)

### Regulatory
- [Nigeria Crypto Legal Status](https://www.lightspark.com/knowledge/is-crypto-legal-in-nigeria)
- [Nigeria Banks and Crypto](https://www.mariblock.com/crypto-is-legal-in-nigeria-until-the-bank-disagrees/)
- [Ghana VASP Bill](https://www.mariblock.com/ghana-passes-law-to-regulate-crypto-and-its-service-providers/)
- [Ghana Regulation Timeline](https://www.afriwise.com/blog/bank-of-ghana-to-commence-regulation-of-cryptocurrency-in-september-2025)

### Crypto Infrastructure
- [Celo Overview](https://celo.org/)
- [MiniPay Launch](https://press.opera.com/2025/05/13/minipay-standalone-app-ios-android/)
- [MiniPay + Noah Partnership](https://cryptonews.com/news/operas-celo-based-minipay-wallet-launches-global-to-local-stablecoin-payments-with-noah/)
- [Circle CCTP V2](https://www.circle.com/cross-chain-transfer-protocol)
- [Safe Smart Accounts](https://docs.safe.global/advanced/smart-account-overview)
- [Safe Modules](https://docs.safe.global/advanced/smart-account-modules)
- [Safe Passkeys](https://docs.safe.global/sdk/signers/passkeys)
- [Privy Smart Wallets](https://docs.privy.io/wallets/using-wallets/evm-smart-wallets/overview)

### Market Analysis
- [Stablecoin Offramp Challenges](https://www.pymnts.com/cryptocurrency/2026/stablecoins-face-payments-challenge-with-cashing-out)
- [East Africa FX Friction](https://yogupay.com/stablecoins-reducing-fx-friction-cross-border-transact/)
- [Yellow Card Fees](https://docs.yellowcard.engineering/docs/fees-widget)
- [Flutterwave Pricing](https://flutterwave.com/ng/support/pricing/pricing-for-receiving-payment)

---

*This document captures technical and strategic analysis. It is not legal or financial advice.*
