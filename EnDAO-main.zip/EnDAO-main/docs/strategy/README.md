# Strategy Documentation

This directory contains quick-reference summaries of EnDAO's strategic positioning, market research, and product vision. Full details are in the Obsidian vault.

## Core Documents

### Positioning & Messaging

**One-Liner**: "Shared money. Shared trust. At any scale."

**What We Do**: Enable groups to pool money, make binding decisions, and track everything transparently without requiring crypto expertise, legal entities, or single-person control.

**Key Differentiators**:

1. Protected group money (multi-sig treasury)
2. Decisions that stick (on-chain/recorded governance)
3. Works for everyone (stablecoin rails + email auth)

**Messaging Framework**:

- Tier 1 (Headlines): Zero jargon, outcome-focused
- Tier 2 (Features): Practical benefits
- Tier 3 (Docs): Full technical context

_Full positioning, competitive analysis, and market research → `obsidian/Strategy/ENDAO_RESEARCH.md` (1400+ lines)_

---

### Target Markets

**Primary Segments**:
| Segment | Pain Point | EnDAO Solution | Market Size |
|---------|-----------|----------------|-------------|
| Investment Clubs | Manual tracking, single custody | Shared treasury + proposal system | ~400K US clubs |
| Cooperatives | Fragmented governance tools | Unified treasury + democracy | ~65K US co-ops |
| Student Organizations | Fraud risk, annual chaos | Protected treasury with oversight | ~500K US orgs |
| Mutual Aid Groups | Informal, no accountability | Transparent ledger + voting | Growing |
| ROSCAs/Savings Circles | Trust limited to social circle | Global participation, no bank needed | 1B+ globally |

**Dark Horse Markets**: Diaspora hometown associations, volunteer fire departments, real estate syndications, freelancer collectives, community land trusts

_Complete market sizing, user behavior research, pricing analysis → `obsidian/Strategy/ENDAO_RESEARCH.md`_

---

### Competitive Landscape

**Direct Competitors** (Crypto/DAO):

- **Upstream**: Pivoted away from DAOs entirely (no longer a competitor)
- **Syndicate**: Strong for investment clubs, crypto-native, 99-member cap
- **Aragon**: Enterprise DAOs, complex for small groups
- **Gnosis Safe**: Our infrastructure (not competitor), treasury-only

**Adjacent Competitors** (TradFi):

- **Carta**: Equity management, requires legal entity
- **AngelList**: Accredited investors only, expensive
- **BetterInvesting**: Legacy software for investment clubs
- **HOA Management**: Property focus, not pure governance

**Market Gap**: No accessible multi-sig + governance for mainstream groups. EnDAO is alone in this space.

_Full competitive analysis, SWOT, positioning maps → `obsidian/Strategy/ENDAO_RESEARCH.md` Section 5_

---

### Marketing & Growth

**Launch Framework**:

- Phase 1: Identity (discovery & trust)
- Phase 2: Connection (relationships between DAOs)
- Phase 3: Cross-DAO Proposals (B2B transactions)
- Phase 4: Commerce (multi-DAO networks)
- Phase 5: Sovereignty (network states)

**Messaging Strategy**: Lead with outcomes ("shared treasury"), not technology ("DAO"). Progressive disclosure of complexity.

**Channels**: Instagram, Threads, X (Twitter) for early adopters; SEO for organic discovery

---

#### Current State Assessment (February 2026)

**What's Working Well**:

| Element                    | Status                                               |
| -------------------------- | ---------------------------------------------------- |
| Vertical positioning       | 6 solution pages targeting distinct segments         |
| Problem/solution framing   | Each page leads with pain points, shows EnDAO as fix |
| Jargon-free messaging      | Follows "tier 1 = no crypto words" principle         |
| SEO metadata               | Pages have keywords, descriptions, Open Graph        |
| Consistent visual identity | Brand colors, typography, card-based layouts         |

**Current Marketing Pages**:

- `/` — Landing page (hero, features, use cases)
- `/solutions` — Hub page linking to verticals
- `/solutions/entrepreneurs` — Small business/co-founder focus
- `/solutions/cooperatives` — Worker, housing, consumer co-ops
- `/solutions/student-organizations` — Fraud prevention, transitions
- `/solutions/community-groups` — HOAs, nonprofits, mutual aid
- `/solutions/savings-circles` — ROSCAs, tandas, chamas
- `/solutions/creator-collectives` — Revenue sharing, project voting

---

#### Gaps & Upgrade Opportunities

**1. Social Proof (Critical Gap)**

- Zero testimonials, case studies, or customer logos
- No "X groups use EnDAO" beyond hero counter
- Trust is everything for financial tools — biggest hole

**2. Pricing Page**

- Pricing strategy exists (`PRICING_STRATEGY.md`), no public `/pricing` page
- Users can't self-qualify or understand costs

**3. Comparison Content**

- No "EnDAO vs Loomio" or "EnDAO vs Splitwise" pages
- Missing SEO opportunity for solution-seekers
- Cooperatives FAQ mentions Loomio but doesn't go deep

**4. Discovery Funnel**

- Documented below but nothing built
- No intake quiz, no "Find your setup" wizard
- Current flow: marketing page → sign up (cold)

**5. Content Marketing / Blog**

- No `/blog` exists
- Missing thought leadership, SEO long-tail content
- Competitors dominating "how to run an investment club" searches

**6. Trust & Security Signals**

- No security badges, SOC 2 mention, audit references
- No "Protected by multi-sig" visual explainer
- Treasury product needs security credibility

**7. Interactive Elements**

- No ROI calculator ("How much could your group save?")
- No demo video or product tour
- No "See it in action" before signup

**8. Email Capture**

- No newsletter signup
- No lead magnets ("Guide to Starting a Savings Circle")
- No drip sequences for non-converting visitors

**9. Missing Pages**

- `/pricing` — Tier comparison with CTAs
- `/about` or `/team` — Builds trust, humanizes product
- `/security` — How treasury is protected
- `/how-it-works` — Visual flow from signup to first decision
- `/contact` or `/demo` — Enterprise/custom inquiries

**10. Mobile / PWA Marketing**

- Mobile app exists but no marketing around it
- No App Store / Play Store links on website
- No "Take EnDAO anywhere" messaging

---

#### Priority Roadmap

| Priority | Initiative                                 | Rationale                                   |
| -------- | ------------------------------------------ | ------------------------------------------- |
| **P0**   | Social proof (testimonials, logos)         | Trust is everything for money apps          |
| **P0**   | Pricing page                               | Users need to self-qualify                  |
| **P1**   | Security page                              | Treasury product needs security credibility |
| **P1**   | Discovery funnel implementation            | Convert more visitors to right-fit signups  |
| **P1**   | Comparison pages (vs Loomio, vs Splitwise) | SEO + decision-stage buyers                 |
| **P2**   | How it works page                          | Visual flow reduces uncertainty             |
| **P2**   | Demo video / product tour                  | Let people see before committing            |
| **P2**   | Blog infrastructure                        | Long-term SEO play                          |
| **P3**   | Lead magnets / email capture               | Nurture non-converters                      |
| **P3**   | ROI calculator                             | Interactive engagement                      |

**Strategic Shift Needed**: Current marketing is **feature-forward** ("here's what we do"). Upgrade to **outcome-forward with proof** ("here's what groups like you achieved").

---

#### Discovery & Qualification Funnel

Entry points for prospective groups:

- Website self-service ("Create a Group")
- Contact form / "Book a Demo"
- Referrals from existing DAOs
- Partner integrations

Intake evaluation captures:

- Group type (investment club, co-op, student org, etc.)
- Current treasury size / expected monthly volume
- Number of members (current and expected)
- Primary needs (treasury, voting, records, all)
- Current pain points (single-person control, lost records, fraud risk)
- Governance complexity (simple majority vs complex rules)

Recommendation logic outputs:

- Suggested tier (Starter → Community → Organization → Enterprise)
- Recommended setup (treasury config, voting thresholds, roles)
- Onboarding path (self-service vs guided setup)
- Lead score for sales prioritization

Implementation options:

- Typeform/Tally embedded flow (quick MVP)
- Custom in-app wizard (better UX, more data)
- HubSpot/CRM integration (sales pipeline)

---

#### Comparison Pages to Build

| Page                  | Target Search Intent                            | Key Differentiators                        |
| --------------------- | ----------------------------------------------- | ------------------------------------------ |
| EnDAO vs Loomio       | "loomio alternative", "loomio with treasury"    | Treasury control, not just discussion      |
| EnDAO vs Splitwise    | "splitwise for groups", "splitwise alternative" | Governance + multi-sig, not just tracking  |
| EnDAO vs Syndicate    | "syndicate alternative", "dao for non-crypto"   | No crypto knowledge required               |
| EnDAO vs Carta        | "carta alternative small groups"                | No legal entity required                   |
| EnDAO vs Venmo/PayPal | "shared account alternative"                    | True shared custody, not personal accounts |

---

#### Content Marketing Topics

**High-Intent (Bottom of Funnel)**:

- "How to set up an investment club treasury"
- "Student organization financial controls"
- "Cooperative governance software comparison"

**Educational (Middle of Funnel)**:

- "What is a ROSCA and how do savings circles work"
- "Multi-signature wallets explained for non-technical users"
- "Why your group needs financial transparency"

**Awareness (Top of Funnel)**:

- "Signs your group has outgrown Venmo"
- "The hidden risks of treasurer-controlled accounts"
- "2026 International Year of Cooperatives: Starting a co-op"

---

_Campaign details, content calendars, growth metrics → `obsidian/Strategy/ENDAO_MARKETING_STRATEGY.md` (991 lines)_

---

### UX Strategy & Flow Evaluation

#### Current Flow

```
Landing Page → Sign Up (Privy email) → Dashboard
                                         ├── Create DAO → 4-step wizard → DAO Overview
                                         └── View existing DAOs → DAO Page
                                                                    ├── (Member) → Overview, Treasury, Proposals, Members
                                                                    └── (Non-member) → Public Preview → Join
```

#### What's Working

| Element                         | Assessment                                               |
| ------------------------------- | -------------------------------------------------------- |
| Email auth (Privy)              | Zero-friction signup, no wallet required                 |
| 4-step wizard                   | Manageable cognitive load per step                       |
| Template selection              | Guides users toward appropriate setup                    |
| Treasury setup as explicit step | Important decision gets proper attention                 |
| Member vs non-member views      | Public preview protects privacy while allowing discovery |
| QR code join                    | Nice for in-person onboarding                            |

#### UX Gaps & Opportunities

**1. Empty Dashboard Problem**

- New user signs up → lands on empty dashboard with "Create DAO" button
- No guidance, no context, no value shown before commitment
- _Opportunity_: Show demo/example DAOs, "See how groups use EnDAO", or guided setup

**2. Marketing ↔ Product Mismatch**

- Marketing targets specific verticals (Student Orgs, Cooperatives, Investment Clubs)
- Templates in wizard are generic (Nonprofit, Cooperative, Business, Community Org)
- User from `/solutions/student-organizations` sees no "Student Organization" template
- _Opportunity_: Align templates to marketing verticals OR carry context from landing page

**3. Join-First vs Create-First**

- Current UX optimizes for creators, but most users arrive via **invitation**
- `/dao/[id]/join` exists but isn't prominently surfaced
- _Opportunity_: "I was invited" as equal entry point, better invitation landing pages

**4. No Time-to-First-Value Guidance**

- User creates DAO → lands on Overview → no prompts for next steps
- Missing: "Invite your first member", "Create your first proposal", "Set up treasury"
- _Opportunity_: Post-creation onboarding checklist or guided tour

**5. Treasury Step is Front-Loaded**

- Step 3 asks: "Hybrid", "Fiat only", or "Crypto only" — overwhelming for crypto-skeptic users
- What's a hybrid treasury? Can I change this later?
- _Opportunity_: Default to hybrid, make treasury config a post-creation admin setting

**6. No Progressive Disclosure**

- All complexity visible upfront (voting periods, quorum, thresholds)
- _Opportunity_: Start simple, unlock features as needed based on DAO activity/maturity

**7. No Collaborative Onboarding**

- Creating a DAO is treated as solo activity, but groups decide together
- _Opportunity_: Invite founding members during creation, "Share this draft" before finalizing

**8. Mobile Disconnect**

- Mobile app exists but no App Store links on marketing, no "Continue on mobile" prompts
- _Opportunity_: Surface mobile-first moments (voting, checking balance)

**9. No In-App Social Proof**

- No "Groups like yours" suggestions or success metrics from similar DAOs
- _Opportunity_: "20 cooperatives use EnDAO" when creating co-op template

#### UX Priority Roadmap

| Priority | Fix                                       | Impact                         |
| -------- | ----------------------------------------- | ------------------------------ |
| **P0**   | Post-creation onboarding checklist        | Reduces "now what?" confusion  |
| **P0**   | Marketing → template continuity           | Delivers on vertical promise   |
| **P1**   | Empty dashboard state with value preview  | First-impression fix           |
| **P1**   | Default treasury type, hide complexity    | Reduces abandonment            |
| **P1**   | Join-first flow parity                    | Most users arrive via invite   |
| **P2**   | Collaborative creation (founding members) | Groups should onboard together |
| **P2**   | Progressive feature disclosure            | Reduce overwhelm               |
| **P3**   | Mobile integration prompts                | Meet users where they are      |

#### Core UX Insight

**Current assumption**: Users know what they want and are ready to configure it.

**Reality for target audience**: Crypto-skeptic groups don't know what governance features they need. They just want to "manage our group's money."

**Shift needed**: From "configure your DAO" → "tell us about your group, we'll set it up for you."

This connects to the Discovery Funnel — the intake quiz isn't just marketing, it could BE the creation flow.

---

### Vision & Roadmap

**Short-term** (6-12 months): Own a vertical completely, build network effects within segment

**Medium-term** (12-24 months): Portable reputation, compliance layer, bank/fiat integrations

**Long-term**: "Stripe for community finance" - default infrastructure layer, API/white-label for platforms

_Internal vision, network evolution phases → `obsidian/Strategy/VISION_ROADMAP_INTERNAL.md`_

---

## Quick Reference

### Words We Use vs Avoid

| Use This          | Not This           |
| ----------------- | ------------------ |
| Shared treasury   | DAO treasury       |
| Group             | DAO / Organization |
| Approval required | Multi-sig          |
| Transparent       | On-chain           |
| Works globally    | Crypto-native      |

### Context-Specific Messaging

| Audience         | Lead With                                                 |
| ---------------- | --------------------------------------------------------- |
| Investment clubs | "Track contributions, vote on investments, share custody" |
| Cooperatives     | "Democratic decisions, transparent budgets"               |
| Student orgs     | "No more treasurer fraud, no more lost receipts"          |
| Mutual aid       | "Trust at scale without losing your values"               |
| ROSCAs           | "Savings circles that work with anyone, anywhere"         |

---

## Document Index

**In this directory** (slim summaries):

- This README - Quick reference for strategy
- `PRICING_STRATEGY.md` - Monetization model, fee structure, subscription tiers, upgrade triggers

**In Obsidian vault** (full details):

- `obsidian/Strategy/ENDAO_RESEARCH.md` - 1400 lines: positioning, competitive analysis, market sizing, user behavior
- `obsidian/Strategy/ENDAO_MARKETING_STRATEGY.md` - 991 lines: campaigns, growth framework, SEO strategy
- `obsidian/Strategy/UX_RESEARCH_SYNTHESIS.md` - 309 lines: user research findings
- `obsidian/Strategy/VISION_ROADMAP_INTERNAL.md` - 221 lines: long-term vision, network evolution

**Research in Obsidian**:

- `obsidian/Research/COMPETITIVE_SEO_RESEARCH.md` - 471 lines

---

_Last Updated: February 27, 2026 (UX evaluation added)_
