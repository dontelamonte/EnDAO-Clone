# EnDAO Pricing & Monetization Strategy

**Status**: Strategic Planning
**Last Updated**: February 2026
**Related**: `docs/deployment/PLATFORM_REVENUE_DEPLOYMENT.md`, `docs/features/TREASURY_TIERS.md`

---

## Executive Summary

EnDAO uses a **hybrid monetization model** combining transaction fees with subscription tiers. This approach:

- Keeps the platform accessible (generous free tier)
- Generates revenue from day one (transaction fees)
- Creates natural upgrade incentives (lower fees + advanced features at paid tiers)
- Scales with customer success (bigger orgs pay more, get more)

**Core Principle**: Governance features stay free. Operational/compliance features are gated.

---

## Current Fee Structure

### Deployed (FeeRouter Contract)

| Fee Type               | Rate | Implementation             |
| ---------------------- | ---- | -------------------------- |
| Deposit (contribution) | 5%   | FeeRouter contract on Base |
| Transfer (outflow)     | 2%   | FeeRouter contract         |

**Contract Address (Testnet)**: `0xf8786857eD04621d6e81959aAb36e422F687E4c8`
**EnDAO Safe (Testnet)**: `0x00dc44400adb57a85364c97442bd5e95faa861e7`

### Code References

- `src/lib/services/payout/payout.service.ts`: 1.5% platform fee on outflows
- `src/lib/services/donation/donation.service.ts`: `applicationFeePercent: 0` (not yet enabled)

---

## Treasury Flow Architecture

### Current Flows

```
FIAT RAIL (Stripe Connect)
─────────────────────────
Donor → Stripe (2.9%) → Admin's Connected Account → Auto-payout to Admin's Bank
                                                    ↓
                                            [EnDAO has no visibility]

CRYPTO RAIL (Gnosis Safe)
─────────────────────────
Donor → Safe Deposit → Multi-sig Treasury → Governance Approval → Recipient
                                            ↓
                                    [Full transparency + control]
```

### Proposed Flow (With Bridge Integration)

```
UNIFIED TREASURY (Fiat → Crypto via Bridge)
───────────────────────────────────────────
Donor (Card) → Stripe (2.9%) → Bridge (1.5%) → USDC → Safe
Donor (Bank) → Bridge ACH (1.5%) → USDC → Safe
Donor (Crypto) → Direct deposit → Safe
                                    ↓
                            [Single multi-sig treasury]
                                    ↓
                            Governance Approval
                                    ↓
                    ┌───────────────┴───────────────┐
                    ↓                               ↓
            Crypto Recipient                 Fiat Recipient
            (Direct from Safe)              (Safe → Bridge → Bank)
```

**Benefits of Bridge Integration**:

- Unified custody (everything in Safe)
- Full transparency (on-chain)
- True governance control
- Consistent fee structure

---

## Complete Fee Stack

### Fiat Donation → Crypto Treasury → Fiat Payout (Worst Case)

| Layer              | Fee  | Cumulative         |
| ------------------ | ---- | ------------------ |
| Stripe processing  | 2.9% | 2.9%               |
| Bridge on-ramp     | 1.5% | 4.4%               |
| EnDAO deposit fee  | 0.6% | 5.0%               |
| **In treasury**    | -    | **$95.00 of $100** |
| EnDAO transfer fee | 1.0% | 6.0%               |
| Bridge off-ramp    | 1.5% | 7.5%               |
| **To recipient**   | -    | **$92.50 of $100** |

### Crypto Donation → Crypto Payout (Best Case)

| Layer              | Fee    | Cumulative         |
| ------------------ | ------ | ------------------ |
| EnDAO deposit fee  | 2.0%   | 2.0%               |
| **In treasury**    | -      | **$98.00 of $100** |
| EnDAO transfer fee | 1.0%   | 3.0%               |
| Gas (Base L2)      | ~$0.01 | ~3.0%              |
| **To recipient**   | -      | **$97.00 of $100** |

**Positioning**: "The more crypto-native you go, the cheaper it gets."

---

## Subscription Tier Structure

### Tier Overview

| Tier             | Monthly | Annual           | Deposit Fee | Transfer Fee |
| ---------------- | ------- | ---------------- | ----------- | ------------ |
| **Starter**      | Free    | Free             | 5%          | 1.5%         |
| **Community**    | $29     | $290 (save $58)  | 3%          | 1%           |
| **Organization** | $79     | $790 (save $158) | 2%          | 0.5%         |
| **Enterprise**   | Custom  | Custom           | Negotiated  | Negotiated   |

### Tier Details

#### Starter (Free)

**For**: New groups trying EnDAO, casual friend groups, small clubs

**Soft Limits**:

- Treasury balance: Up to $10,000
- Members: Up to 15

**Fees**:

- Fiat deposit (card): 5% (Stripe + Bridge + EnDAO)
- Crypto deposit: 2%
- Transfer out: 1.5%

**Features Included**:

- Multi-sig treasury (2-of-3 default)
- Proposals & voting
- Delegation
- Basic quorum settings
- Transaction history
- Member management
- CSV export
- Basic notifications

---

#### Community ($29/month or $290/year)

**For**: Student orgs, small nonprofits, active clubs, cooperatives starting out

**Soft Limits**:

- Treasury balance: Up to $50,000
- Members: Up to 50

**Fees**:

- Fiat deposit (card): 3.5%
- Crypto deposit: 1%
- Transfer out: 1%

**Everything in Starter, plus**:

- Custom multi-sig thresholds (2-of-5, 3-of-7, etc.)
- Advanced quorum settings (supermajority, weighted)
- Full export (CSV + PDF reports)
- Email support

---

#### Organization ($79/month or $790/year)

**For**: Established nonprofits, HOAs, professional cooperatives, investment clubs

**Limits**: Unlimited treasury and members

**Fees**:

- Fiat deposit (card): 2.5%
- Crypto deposit: 0.5%
- Transfer out: 0.5%

**Everything in Community, plus**:

- Ops Wallet (day-to-day spending without full governance)
- Spending limits enforcement
- Tax compliance (W-9 collection, 1099 generation)
- Audit-ready reports (PDF)
- Read-only API access
- Priority support (email + chat)

---

#### Enterprise (Custom Pricing)

**For**: Federations, large cooperatives, chambers of commerce, white-label partners

**Limits**: Unlimited

**Fees**: Negotiated (can be 0% transaction + flat monthly)

**Everything in Organization, plus**:

- Sub-DAOs / department budgets
- White-label branding
- Custom domain
- Full API access (read + write)
- Custom integrations
- Dedicated account manager
- SLA guarantees

---

## Annual vs Monthly Pricing

### Pricing Structure (17% Annual Discount)

| Tier             | Monthly | Annual  | Effective Monthly | Savings    |
| ---------------- | ------- | ------- | ----------------- | ---------- |
| **Starter**      | Free    | Free    | Free              | -          |
| **Community**    | $29/mo  | $290/yr | $24.17/mo         | $58 (17%)  |
| **Organization** | $79/mo  | $790/yr | $65.83/mo         | $158 (17%) |
| **Enterprise**   | Custom  | Custom  | Custom            | Negotiated |

**Why 17%**: Industry standard "2 months free" discount. Easy to communicate, meaningful savings without over-discounting.

### Who Chooses What

| Customer Type | Likely Choice    | Reason                                         |
| ------------- | ---------------- | ---------------------------------------------- |
| Friend groups | Monthly          | Uncertain longevity, casual commitment         |
| Student orgs  | Annual           | Aligned with academic year, budget cycles      |
| Nonprofits    | Annual           | Fiscal year budgets, board-approved spending   |
| HOAs          | Annual           | Annual dues collection, predictable operations |
| Cooperatives  | Annual           | Established, budget-planned                    |
| New startups  | Monthly → Annual | Test first, convert after 3-6 months           |

### Comparison

| Aspect            | Monthly                   | Annual                         |
| ----------------- | ------------------------- | ------------------------------ |
| **Price**         | Full price                | 17% discount (2 months free)   |
| **Commitment**    | Low                       | High                           |
| **Cash flow**     | Predictable monthly       | Upfront lump sum               |
| **Churn risk**    | Higher (cancel anytime)   | Lower (locked in)              |
| **Customer type** | Testing, uncertain        | Committed, budget-planned      |
| **Billing**       | Stripe subscription       | Stripe subscription or invoice |
| **Refunds**       | Cancel anytime, no refund | Pro-rata refund policy         |
| **Upgrades**      | Easy mid-cycle            | Credit remaining to new tier   |
| **Downgrades**    | Immediate or end of cycle | At renewal                     |

### Pros & Cons

#### Monthly Billing

**Pros**:

- Lower barrier to entry
- Easier to try and cancel
- Matches cash flow for small orgs
- Simpler for seasonal orgs

**Cons**:

- Higher churn rate
- Less predictable revenue
- More payment processing overhead
- Customers may forget and churn accidentally

#### Annual Billing

**Pros**:

- Better cash flow (upfront payment)
- Lower churn (commitment)
- Higher lifetime value
- Customers more invested in success
- Aligns with org budget cycles (fiscal year)

**Cons**:

- Higher barrier to entry
- Refund complexity if they leave early
- Harder sell for new/uncertain groups

### Pricing Page UX

**Default to annual, show both options clearly:**

```
┌─────────────────────────────────────────────────────────────────┐
│  COMMUNITY                                                      │
│                                                                 │
│  ┌─────────────────┐  ┌─────────────────────────────────────┐  │
│  │ Monthly         │  │ Annual                    BEST VALUE │  │
│  │                 │  │ ████████████████████████████████████ │  │
│  │ $29/mo          │  │ $24.17/mo ($290 billed annually)    │  │
│  │                 │  │                                     │  │
│  │ [Choose]        │  │ [Choose] ← Save $58/year            │  │
│  └─────────────────┘  └─────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Nudges to use**:

- Pre-select annual option
- "BEST VALUE" badge on annual
- Show monthly equivalent for annual pricing
- Show annual savings in dollars
- "2 months free" messaging

### Free → Paid Upgrade Prompt

When users approach soft limits:

```
┌─────────────────────────────────────────────────────────────────┐
│  You're at 14 of 15 members on the Starter plan.               │
│                                                                 │
│  Upgrade to Community to:                                       │
│  ✓ Support up to 50 members                                    │
│  ✓ Reduce fees from 5% to 3%                                   │
│  ✓ Unlock advanced governance features                         │
│                                                                 │
│  ┌─────────────┐  ┌──────────────────────────────────────────┐ │
│  │ $29/month   │  │ $24.17/mo billed annually   RECOMMENDED  │ │
│  │             │  │ Save $58/year                            │ │
│  │ [Choose]    │  │ [Choose]                                 │ │
│  └─────────────┘  └──────────────────────────────────────────┘ │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Billing Operations

| Scenario                     | Handling                                            |
| ---------------------------- | --------------------------------------------------- |
| **Monthly → Annual**         | Credit remaining month, start annual immediately    |
| **Annual → Higher Tier**     | Pro-rata credit to new tier, charge difference      |
| **Annual Cancellation**      | Pro-rata refund for unused months (optional policy) |
| **Failed Payment (Monthly)** | 3 retry attempts, dunning emails, grace period      |
| **Failed Payment (Annual)**  | Extended grace period, high-touch outreach          |
| **Renewal**                  | Auto-renew with 14-day advance notice email         |

### Future Considerations

| Option                  | When to Consider                              |
| ----------------------- | --------------------------------------------- |
| **Quarterly billing**   | If seeing drop-off between monthly and annual |
| **Nonprofit discount**  | Additional 20% for verified 501(c)(3) orgs    |
| **Startup discount**    | First year at 50% for <1 year old orgs        |
| **Multi-year discount** | 25% for 2-year commitment (rare in SaaS)      |

---

## Upgrade Triggers

### Soft Triggers (Notifications Only)

| Trigger                     | Message                                                                               |
| --------------------------- | ------------------------------------------------------------------------------------- |
| Treasury exceeds tier limit | "Your treasury has grown to $12K. Upgrade to Community to reduce fees from 5% to 3%." |
| Member count exceeds limit  | "You now have 18 members. Community tier supports up to 50 with lower fees."          |
| High transaction volume     | "You moved $8K last month. At Organization tier, you'd have saved $160 in fees."      |

**Implementation**: Dashboard banner + email notification. No blocking.

### Hard Triggers (Feature Gates)

| Feature               | Required Tier | Block Message                                                                   |
| --------------------- | ------------- | ------------------------------------------------------------------------------- |
| Ops Wallet            | Organization  | "Ops Wallet requires Organization tier. Upgrade to enable day-to-day spending." |
| Spending Limits       | Organization  | "Spending limits require Organization tier."                                    |
| Tax Compliance (1099) | Organization  | "Tax reporting requires Organization tier."                                     |
| Audit Reports (PDF)   | Organization  | "Audit-ready reports require Organization tier."                                |
| Sub-DAOs              | Enterprise    | "Sub-DAOs require Enterprise tier."                                             |
| White-Label           | Enterprise    | "Custom branding requires Enterprise tier."                                     |
| Full API Access       | Enterprise    | "Full API access requires Enterprise tier."                                     |

---

## Feature Gate Matrix

| Feature             | Starter   | Community   | Organization | Enterprise    |
| ------------------- | --------- | ----------- | ------------ | ------------- |
| Multi-sig treasury  | ✅ 2-of-3 | ✅ Custom   | ✅ Custom    | ✅ Custom     |
| Proposals & voting  | ✅        | ✅          | ✅           | ✅            |
| Delegation          | ✅        | ✅          | ✅           | ✅            |
| Transaction history | ✅        | ✅          | ✅           | ✅            |
| Member management   | ✅ (15)   | ✅ (50)     | ✅ Unlimited | ✅ Unlimited  |
| Quorum settings     | Basic     | ✅ Advanced | ✅ Advanced  | ✅ Advanced   |
| CSV export          | ✅        | ✅          | ✅           | ✅            |
| PDF reports         | ❌        | ✅          | ✅           | ✅            |
| Ops Wallet          | ❌        | ❌          | ✅           | ✅            |
| Spending limits     | ❌        | ❌          | ✅           | ✅            |
| Tax compliance      | ❌        | ❌          | ✅           | ✅            |
| Audit reports       | ❌        | ❌          | ✅           | ✅            |
| Read-only API       | ❌        | ❌          | ✅           | ✅            |
| Sub-DAOs            | ❌        | ❌          | ❌           | ✅            |
| White-label         | ❌        | ❌          | ❌           | ✅            |
| Full API            | ❌        | ❌          | ❌           | ✅            |
| Custom domain       | ❌        | ❌          | ❌           | ✅            |
| Dedicated support   | ❌        | Email       | Email + Chat | Dedicated CSM |

---

## Enterprise & White-Label Pricing

### White-Label Tiers

| Tier             | Setup Fee | Monthly    | Includes                              |
| ---------------- | --------- | ---------- | ------------------------------------- |
| **Basic**        | $5,000    | $500/mo    | Branding, subdomain, standard support |
| **Professional** | $15,000   | $1,500/mo  | Custom domain, API, dedicated CSM     |
| **Enterprise**   | $50,000+  | $5,000+/mo | Custom features, SLA, on-prem option  |

### Identified White-Label Opportunities

- Agriculture Chamber (Ghana)
- GCCI (Guyana Chamber of Commerce)
- Credit union networks
- HOA management companies
- Cooperative federations

---

## Revenue Projections

### Scenario: 1,000 DAOs after 12 months

**Assumptions**:

- Average treasury: $15,000
- Average monthly deposits: $2,500
- Average monthly transfers: $1,500
- Tier distribution: 70% Starter, 20% Community, 8% Organization, 2% Enterprise

#### Starter (700 DAOs)

```
Deposits: $2,500 × 5% = $125/mo
Transfers: $1,500 × 1.5% = $22.50/mo
Subscription: $0
Per DAO: $147.50/mo
Total: $103,250/mo
```

#### Community (200 DAOs)

```
Deposits: $2,500 × 3% = $75/mo
Transfers: $1,500 × 1% = $15/mo
Subscription: $29/mo
Per DAO: $119/mo
Total: $23,800/mo
```

#### Organization (80 DAOs)

```
Deposits: $2,500 × 2% = $50/mo
Transfers: $1,500 × 0.5% = $7.50/mo
Subscription: $79/mo
Per DAO: $136.50/mo
Total: $10,920/mo
```

#### Enterprise (20 DAOs)

```
Subscription: ~$500/mo average
Transaction fees: ~$50/mo
Per DAO: $550/mo
Total: $11,000/mo
```

#### Total Monthly Revenue

```
Starter:      $103,250
Community:     $23,800
Organization:  $10,920
Enterprise:    $11,000
─────────────────────────
Total MRR:    $148,970
Annual Run Rate: ~$1.79M
```

---

## Competitive Positioning

| Platform      | Model        | Typical Fees     | EnDAO Advantage                       |
| ------------- | ------------ | ---------------- | ------------------------------------- |
| Venmo/PayPal  | Transaction  | 2.9%             | Multi-sig custody, governance         |
| GoFundMe      | Transaction  | ~5% + processing | Ongoing treasury, not one-time        |
| Stripe Direct | Transaction  | 2.9%             | Governance layer, transparency        |
| Carta         | Subscription | $250-2000/mo     | More accessible, crypto-native        |
| Aragon        | Token-based  | Complex          | Simpler, fiat on-ramp                 |
| Syndicate     | Hybrid       | 1% carry         | Broader use cases, not just investing |

**EnDAO's Position**: Accessible multi-sig governance for mainstream groups. More powerful than payment apps, simpler than enterprise tools.

---

## Fee Transparency (Pricing Page Copy)

### Show Users Where Fees Go

```
YOUR $100 DONATION (Starter Tier, Card Payment)
───────────────────────────────────────────────
Payment processing (Stripe)         $2.90
Currency conversion (Bridge)        $1.50
Platform fee (EnDAO)                $0.60
───────────────────────────────────────────────
Total fees                          $5.00 (5%)
DAO receives                        $95.00

💡 Upgrade to Community ($29/mo) to reduce fees to 3.5%
💡 Use crypto deposits to pay just 2%
```

---

## Implementation Roadmap

### Phase 1: Foundation (Current)

- [x] FeeRouter contract deployed (testnet)
- [x] Basic fee collection (5% deposit, 2% transfer)
- [ ] Stripe billing integration for subscriptions
- [ ] Tier selection in DAO creation flow
- [ ] Soft limit notifications

### Phase 2: Tier Differentiation

- [ ] Fee adjustment based on tier (update FeeRouter or app-layer)
- [ ] Feature gates implementation
- [ ] Upgrade prompts and flows
- [ ] Annual billing option

### Phase 3: Advanced Features

- [ ] Ops Wallet (Organization tier)
- [ ] Tax compliance (Organization tier)
- [ ] Sub-DAOs (Enterprise tier)
- [ ] White-label infrastructure (Enterprise tier)

### Phase 4: Bridge Integration

- [ ] Bridge API integration
- [ ] Unified fiat → crypto flow
- [ ] Off-ramp implementation
- [ ] Fee stack consolidation

---

## Future Considerations

### Geographic/Regional Pricing

| Consideration           | Status   | Notes                                    |
| ----------------------- | -------- | ---------------------------------------- |
| Purchasing power parity | Deferred | Should India pay same as US?             |
| Local currency billing  | Deferred | USD-only for now                         |
| Regional pricing tiers  | Deferred | Consider if international adoption grows |

**Recommendation**: Start USD-only, revisit when international is >20% of users.

---

### Paying with Crypto / From Treasury

| Scenario                                   | Status    | Notes                      |
| ------------------------------------------ | --------- | -------------------------- |
| Pay subscription with credit card          | Supported | Stripe                     |
| Pay subscription with USDC from treasury   | To Build  | On-brand, reduces friction |
| Auto-deduct subscription from DAO treasury | To Build  | "Eat your own dogfood"     |

**Opportunity**: Differentiated feature — pay EnDAO fees directly from your EnDAO treasury.

---

### Multi-DAO / Portfolio Pricing

| Scenario                      | Policy Needed          |
| ----------------------------- | ---------------------- |
| One person runs 5 DAOs        | Volume discount?       |
| Agency manages 20 client DAOs | Reseller pricing?      |
| Parent org with sub-DAOs      | Enterprise covers all? |

**Recommendation**: Add portfolio pricing for 5+ DAOs under same billing account.

---

### Free Tier Abuse Prevention

| Risk                               | Mitigation                    |
| ---------------------------------- | ----------------------------- |
| Multiple free DAOs to avoid limits | Track by user identity        |
| Stay on free with large treasury   | Soft limits only (OK for now) |
| Create new DAO at limit            | Monitor patterns              |

**Decision**: Growth > revenue protection early on. Revisit if abused.

---

### Trial Periods

| Option                        | Pros               | Cons                        |
| ----------------------------- | ------------------ | --------------------------- |
| No trial (current)            | Simple             | May lose hesitant upgraders |
| 14-day trial of paid features | Experience value   | Abuse potential             |
| First month free on annual    | Incentivize annual | Revenue delay               |

**Recommendation**: Consider 14-day Organization trial for Community users.

---

### Dormant / Seasonal Orgs

| Scenario                    | Handling                     |
| --------------------------- | ---------------------------- |
| Active 3 months/year        | Allow subscription pause?    |
| Treasury idle 6+ months     | Prompt to downgrade?         |
| Dormant with large treasury | Keep charging (their choice) |

**Options**:

- Allow 3-month pause per year
- Seasonal pricing (higher rate, shorter term)
- Do nothing (they'll self-manage)

---

### Refund Policy

| Scenario                     | Policy                             |
| ---------------------------- | ---------------------------------- |
| Cancel monthly               | No refund, cancel anytime          |
| Cancel annual after 2 months | Pro-rata minus 1 month (admin fee) |
| Org dissolves                | Pro-rata refund                    |
| Chargeback/dispute           | Case-by-case                       |

**Action**: Document refund policy before launching paid tiers.

---

### Price Changes / Grandfathering

| Scenario     | Policy                                   |
| ------------ | ---------------------------------------- |
| Raise prices | Grandfather existing for 12 months       |
| Add new tier | Existing users keep current pricing      |
| Remove tier  | Migrate to nearest tier, honor old price |

**Communication**: 60-day notice for any price changes.

---

### Support Costs / SLA Definition

| Tier         | Support           | Response Time | SLA            |
| ------------ | ----------------- | ------------- | -------------- |
| Starter      | Self-serve (docs) | N/A           | None           |
| Community    | Email             | 48 hours      | None           |
| Organization | Email + chat      | 24 hours      | 99.5% uptime   |
| Enterprise   | Dedicated CSM     | 4 hours       | 99.9% + custom |

**Question**: Cap Community support at X tickets/month?

---

### Onboarding / Professional Services

| Service                | Pricing       | Included In   |
| ---------------------- | ------------- | ------------- |
| Self-serve onboarding  | Free          | All tiers     |
| Guided onboarding call | Free          | Organization+ |
| Migration assistance   | $500 one-time | Add-on        |
| Custom training        | $200/hour     | Add-on        |
| Implementation support | Custom        | Enterprise    |

---

### Partner / Reseller Model

| Model               | Structure                    |
| ------------------- | ---------------------------- |
| Referral            | 20% of first year revenue    |
| Reseller            | 30% discount, resell at list |
| White-label partner | 70/30 revenue share          |

**Status**: Premature — revisit when demand exists.

---

### API Rate Limits / Usage Caps

| Resource              | Starter | Community | Organization | Enterprise |
| --------------------- | ------- | --------- | ------------ | ---------- |
| API calls/month       | N/A     | N/A       | 10K          | Unlimited  |
| Proposals/month       | 20      | 100       | Unlimited    | Unlimited  |
| Storage (attachments) | 1GB     | 5GB       | 25GB         | Unlimited  |
| Webhooks              | N/A     | N/A       | 5            | Unlimited  |

---

### Sales Tax / VAT

| Region | Handling                   |
| ------ | -------------------------- |
| US     | Stripe Tax (automatic)     |
| EU     | VAT via Stripe Tax         |
| Other  | Stripe Tax where available |

**Action**: Enable Stripe Tax before launching paid tiers.

---

### Enterprise Contract Requirements

| Document                           | Purpose                |
| ---------------------------------- | ---------------------- |
| MSA (Master Service Agreement)     | Standard terms         |
| DPA (Data Processing Agreement)    | GDPR compliance        |
| SLA (Service Level Agreement)      | Uptime guarantees      |
| SOC 2 report                       | Security assurance     |
| BAA (Business Associate Agreement) | Healthcare (if needed) |

**Status**: Need legal templates before Enterprise sales.

---

### Competition Response

| Threat                 | Response                                  |
| ---------------------- | ----------------------------------------- |
| Free competitor        | Emphasize security, compliance, multi-sig |
| 50% cheaper competitor | Focus on value, not price                 |
| Big tech enters space  | Move upmarket to Enterprise               |

---

### Priority Ranking

| Consideration         | Priority | Reason                  |
| --------------------- | -------- | ----------------------- |
| Refund policy         | **High** | Need before charging    |
| Grandfathering policy | **High** | Need before tier launch |
| Pay with crypto       | Medium   | Differentiator          |
| Multi-DAO pricing     | Medium   | Agency use case         |
| Trial periods         | Medium   | Conversion optimization |
| Dormant handling      | Low      | Edge case               |
| Partner model         | Low      | Premature               |
| Geographic pricing    | Low      | US focus first          |

---

## Open Questions

1. **Fee Router Upgrade**: Should tier-based fees be on-chain (FeeRouter upgrade) or app-layer?
2. **Bridge Timeline**: When to prioritize Bridge integration vs other features?
3. **Enterprise Pricing**: What's the minimum viable Enterprise deal size?
4. **Annual Incentives**: Should annual get more than 17% discount?
5. **Crypto-Only Discount**: Should crypto deposits have even lower fees to incentivize adoption?

---

## Appendix: Things We Don't Charge For

Based on strategic decisions, these remain free across all tiers:

| Item              | Reason                                   |
| ----------------- | ---------------------------------------- |
| Member joins      | Don't penalize growth                    |
| Proposal creation | Core governance, encourage participation |
| Votes cast        | Core governance                          |
| Basic reports     | Data portability is expected             |
| Multi-sig (basic) | Core value proposition                   |

---

_This document consolidates pricing strategy discussions from February 2026. Update as pricing evolves._
