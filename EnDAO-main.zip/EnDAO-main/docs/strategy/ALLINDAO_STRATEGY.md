# AllinDAO Strategy

> The intersection of Allinka and EnDAO — serving communities that need both individual empowerment and collective coordination.

**Last updated**: February 2026

---

## What Is AllinDAO

AllinDAO is the shared exploration space where Allinka and EnDAO intersect. It exists as both:

1. **A service** — bespoke solutions for clients who need capabilities from both platforms
2. **A platform vision** — the organic path from individual growth to collective governance

Both Allinka and EnDAO continue as distinct products. AllinDAO is where they combine when the use case demands it.

---

## The Problem We're Solving

The path from **meeting someone** to **building something together** to **managing shared resources** is broken for underserved communities.

- Banks won't touch them
- Formal business structures are expensive or inaccessible
- Trust networks are local and small
- When they do pool money, there's no transparency or accountability

People don't need "a DAO." They need a way to find their people, build skills, pool resources, make decisions together, and act on those decisions — without the friction of traditional institutions.

---

## Two Threads

### Thread 1: AllinDAO Service (Now)

Enterprise and institutional clients with specific needs. They come to us wanting a combination of capabilities:

- Governance + custom education + certifications (agriculture chamber example)
- Treasury + community features + market-specific payments
- Whatever their community requires

**How it works:**
- Consultative engagement: "What does your community need?"
- We build a bespoke solution using Allinka + EnDAO as the toolkit
- White-label output: they get a branded product that's theirs
- Each engagement teaches us what patterns recur

**Why it matters now:**
- Revenue while both companies find product-market fit
- Real use cases reveal what people actually need
- Builds reusable infrastructure for the platform vision

---

### Thread 2: AllinDAO Platform (Longer Term)

The organic path where individuals grow into collectives:

1. **Connect** — find your people
2. **Learn** — build skills together
3. **Pool** — share resources
4. **Decide** — agree on what to do
5. **Move** — act on it

No one tells them "you need governance software." They just... need to make a decision together and have a way to act on it. The infrastructure is there when they're ready.

**The win condition:**
A group of independent entrepreneurs who met on Allinka, learned together, and organically formed a collective that now coordinates business through shared governance and treasury. They never thought about "DAOs" — they just built something together.

**Why it's longer term:**
- Requires both platforms to mature
- Needs the bridge infrastructure (shared auth, shared profiles, cross-platform identity)
- Product-market fit for this vision is unproven

---

## How The Threads Feed Each Other

**Service → Platform:**
- Custom builds reveal what features people actually use together
- Patterns emerge: "every client needs X + Y configured this way"
- Reusable infrastructure accumulates
- Real-world validation of what combinations work

**Platform → Service:**
- Gives service engagements a coherent direction
- Prevents taking random projects that don't build toward anything
- Shared infrastructure makes custom builds faster over time

---

## What AllinDAO Is Not

- **Not a merger** — Allinka and EnDAO remain separate products with separate roadmaps
- **Not a rebrand** — existing users of either platform don't see "AllinDAO"
- **Not a product yet** — no standalone AllinDAO app or website (for now)
- **Not prescriptive** — no forced archetypes or "pick from these templates"

---

## What Both Platforms Contribute

### From Allinka
- Education / Courses / Certifications
- Mentorship network
- Social feed / Stories / Posts
- LinkaPay wallet
- Loans / Finance
- Business metrics / KPIs
- Services marketplace
- Networking / Events
- Mobile-first, offline-capable architecture
- Multi-market payment infrastructure (Flutterwave, M-Pesa, Stripe)

### From EnDAO
- Proposals and voting
- Multi-sig treasury (Gnosis Safe)
- Bounties
- Discussions
- Member roles and permissions
- Gasless execution
- 4-layer treasury protection
- Donations (fiat → crypto)
- AI features (roadmap)
- Enterprise federation (roadmap)

---

## Open Questions

### Offerings
- What does an AllinDAO service engagement actually look like?
- Pricing model: project-based? Retainer? Revenue share?
- How do we scope engagements without over-promising?

### Infrastructure
- What shared infrastructure do both threads need?
- Auth unification (Privy for both?)
- Shared user profiles across platforms?
- How do the databases relate?

### Go-to-Market
- How do we find AllinDAO Service clients?
- Is the agriculture chamber a template for outreach?
- What verticals make sense?

### Platform Path
- What's the MVP for the organic individual → collective journey?
- Which Allinka features need to exist first?
- What's the trigger that activates governance capabilities?

---

## Current State

| Platform | Status |
|----------|--------|
| **EnDAO** | Production, live at endao.ai |
| **Allinka** | In development, consolidating to Supabase-only architecture |
| **AllinDAO** | Concept stage, one potential client engagement (agriculture) |

---

## Next Steps

1. Define what an AllinDAO Service offering looks like
2. Map shared infrastructure needs
3. Identify potential service clients
4. Document the agriculture chamber engagement as a reference case

---

*This document captures strategic direction. It is not a product spec or technical architecture.*
