# CSRF Protection Quick Reference

**TL;DR**: Wrap all POST/PUT/PATCH/DELETE route handlers with `withCSRF` to add CSRF protection.

---

## Import

```typescript
import { withCSRF, withStrictCSRF } from '@/lib/middleware/csrf-validation';
```

---

## Basic Usage

### Simple Route

```typescript
// Before
export async function POST(request: NextRequest) {
  // ...
}

// After
export const POST = withCSRF(async (request: NextRequest) => {
  // CSRF validation automatic
});
```

### Route with Params

```typescript
export const POST = withCSRF(
  async (request: NextRequest, { params }: { params: { id: string } }) => {
    const daoId = params.id;
    // ...
  }
);
```

### With Schema Validation

```typescript
import { withValidation } from '@/lib/middleware/api-validation';

export const PATCH = withValidation(
  schema,
  options
)(
  withCSRF(async (request, validatedData) => {
    // Both validation and CSRF protection
  })
);
```

### With Privy Auth

```typescript
import { withPrivyAuth } from '@/lib/auth/privy-middleware-enhanced';

export const PUT = withPrivyAuth(
  withCSRF(async (request, authContext) => {
    // Both auth and CSRF protection
  })
);
```

### Admin/Treasury Routes (Strict)

```typescript
export const POST = withStrictCSRF(async (request: NextRequest) => {
  // Strict CSRF - no exclusions, validates even GET
});
```

---

## When to Use

| Use Case                                  | Middleware          |
| ----------------------------------------- | ------------------- |
| Regular mutations (POST/PUT/PATCH/DELETE) | `withCSRF`          |
| Admin operations                          | `withStrictCSRF`    |
| Treasury operations                       | `withStrictCSRF`    |
| Read-only (GET)                           | None                |
| Public webhooks                           | None (exclude path) |
| Health checks                             | None                |

---

## Custom Configuration

```typescript
export const POST = withCSRF(
  async (request: NextRequest) => {
    // ...
  },
  {
    excludePaths: ['/api/public/*'],
    excludeMethods: ['GET', 'HEAD'],
    enableLogging: false,
    errorMessage: 'Custom error message',
  }
);
```

---

## Error Response

When CSRF validation fails, clients receive:

```json
{
  "error": "CSRF Validation Failed",
  "message": "CSRF validation failed. Please refresh the page and try again.",
  "code": "CSRF_TOKEN_MISSING" | "CSRF_COOKIE_MISSING" | "CSRF_TOKEN_INVALID",
  "timestamp": "2025-12-18T10:30:00.000Z"
}
```

Status: `403 Forbidden`

---

## Client-Side Usage

```typescript
import { useCSRFAPI } from '@/lib/hooks/use-csrf';

function MyComponent() {
  const { call } = useCSRFAPI();

  const handleSubmit = async () => {
    const response = await call('/api/user/profile', {
      method: 'PATCH',
      body: JSON.stringify({ name: 'New Name' }),
    });
  };
}
```

The `useCSRFAPI` hook automatically:

- Fetches CSRF token from `/api/auth/csrf`
- Adds `X-CSRF-Token` header to requests
- Combines with Privy authentication

---

## Debugging

### Check CSRF Status

```typescript
import { getCSRFStatus } from '@/lib/middleware/csrf-validation';

const status = await getCSRFStatus(request);
console.log({
  required: status.required,
  cookiePresent: status.cookiePresent,
  headerPresent: status.headerPresent,
  valid: status.valid,
  error: status.error,
});
```

### Enable Logging

```typescript
export const POST = withCSRF(
  async (request: NextRequest) => {
    // ...
  },
  { enableLogging: true }
);
```

---

## Common Mistakes

### ❌ Wrong - Middleware not applied

```typescript
export async function POST(request: NextRequest) {
  return withCSRF(async (req) => {
    // This doesn't work!
  });
}
```

### ✅ Correct

```typescript
export const POST = withCSRF(async (request: NextRequest) => {
  // Middleware wraps handler
});
```

---

### ❌ Wrong - Middleware order

```typescript
export const POST = withCSRF(
  withValidation(schema)(async (request, data) => {
    // Wrong order!
  })
);
```

### ✅ Correct

```typescript
export const POST = withValidation(schema)(
  withCSRF(async (request, data) => {
    // Validation → CSRF → Handler
  })
);
```

---

### ❌ Wrong - Redundant validation

```typescript
export const POST = withCSRF(async (request: NextRequest) => {
  const csrfCheck = await validateAPICSRF(request); // Redundant!
  if (!csrfCheck.valid) {
    return csrfCheck.response!;
  }
});
```

### ✅ Correct

```typescript
export const POST = withCSRF(async (request: NextRequest) => {
  // CSRF validation automatic
});
```

---

## Migration Steps

1. **Import middleware**

   ```typescript
   import { withCSRF } from '@/lib/middleware/csrf-validation';
   ```

2. **Remove manual CSRF validation**

   ```typescript
   // Remove this
   const csrfValidation = await validateAPICSRF(request);
   if (!csrfValidation.valid) {
     return csrfValidation.response!;
   }
   ```

3. **Wrap handler**

   ```typescript
   // Change from
   export async function POST(request: NextRequest) { ... }

   // To
   export const POST = withCSRF(async (request: NextRequest) => { ... })
   ```

4. **Test**
   - Valid CSRF token → Request succeeds
   - Missing CSRF token → 403 error
   - Invalid CSRF token → 403 error

---

## Testing

### Unit Test

```typescript
import { POST } from '@/app/api/user/profile/route';

it('should reject requests without CSRF token', async () => {
  const request = new NextRequest('http://localhost/api/user/profile', {
    method: 'POST',
  });

  const response = await POST(request);
  expect(response.status).toBe(403);

  const data = await response.json();
  expect(data.code).toBe('CSRF_TOKEN_MISSING');
});
```

---

## Routes That Need CSRF

- ✅ All POST/PUT/PATCH/DELETE routes (mutations)
- ❌ GET/HEAD/OPTIONS routes (read-only)
- ❌ Webhook endpoints (use signature validation)
- ❌ Health checks (no state change)
- ❌ `/api/auth/csrf` (generates tokens)
- ❌ Internal cron jobs (use internal auth)

---

## Security Notes

- CSRF uses **double-submit cookie pattern**
- Tokens compared using **constant-time comparison** (timing attack prevention)
- Tokens expire after **24 hours**
- Client sends token via **X-CSRF-Token header**
- Server validates against **secure cookie**
- Works with **SameSite cookies** for defense in depth

---

## Need Help?

- 📖 [Full Guide](/docs/security/CSRF_MIDDLEWARE_GUIDE.md)
- 📝 [Migration Examples](/docs/security/CSRF_MIGRATION_EXAMPLES.md)
- 📊 [Route Audit](/docs/security/CSRF_ROUTE_AUDIT.md)
- 💻 [Implementation](/src/lib/middleware/csrf-validation.ts)

---

## Checklist

Before marking a route as complete:

- [ ] Imported `withCSRF` or `withStrictCSRF`
- [ ] Removed manual `validateAPICSRF` calls
- [ ] Wrapped handler with middleware
- [ ] Changed to `export const` pattern
- [ ] Tested with valid CSRF token
- [ ] Tested with missing CSRF token
- [ ] Tested with invalid CSRF token
- [ ] Verified error responses are correct
- [ ] Updated route audit documentation
