# CSRF Middleware Migration Examples

This document provides real-world examples of migrating existing EnDAO API routes to use the new CSRF validation middleware.

## Table of Contents

1. [Simple POST Route](#simple-post-route)
2. [Route with Schema Validation](#route-with-schema-validation)
3. [Route with Privy Auth Wrapper](#route-with-privy-auth-wrapper)
4. [Admin/Treasury Routes](#admintreasury-routes)
5. [Complex Multi-Method Routes](#complex-multi-method-routes)

---

## Simple POST Route

### Before: Manual CSRF Validation

```typescript
// src/app/api/dao/[id]/join/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { getAuthContext } from '@/lib/auth/get-auth-context';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Manual CSRF validation
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Auth check
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Handler logic
    const daoId = params.id;
    // ... join DAO logic

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to join DAO' }, { status: 500 });
  }
}
```

### After: Using withCSRF Middleware

```typescript
// src/app/api/dao/[id]/join/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withCSRF } from '@/lib/middleware/csrf-validation';
import { getAuthContext } from '@/lib/auth/get-auth-context';

export const POST = withCSRF(
  async (request: NextRequest, { params }: { params: { id: string } }) => {
    try {
      // CSRF validation automatic

      // Auth check
      const authContext = await getAuthContext(request);
      if (!authContext) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }

      // Handler logic
      const daoId = params.id;
      // ... join DAO logic

      return NextResponse.json({ success: true });
    } catch (error) {
      return NextResponse.json(
        { error: 'Failed to join DAO' },
        { status: 500 }
      );
    }
  }
);
```

**Changes:**

- Removed `validateAPICSRF` import and call
- Wrapped handler with `withCSRF`
- Changed from `async function POST` to `export const POST = withCSRF(...)`
- Cleaner, less boilerplate code

---

## Route with Schema Validation

### Before: Manual CSRF + Schema Validation

```typescript
// src/app/api/user/profile/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withValidation } from '@/lib/middleware/api-validation';
import { userProfileUpdateSchema } from '@/lib/validations/api';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { getAuthContext } from '@/lib/auth/get-auth-context';

export const PATCH = withValidation(userProfileUpdateSchema, {
  sanitize: true,
  checkSqlInjection: true,
  checkXss: true,
})(async function patchUserProfile(request: NextRequest, validatedData) {
  try {
    // Manual CSRF validation
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Auth check
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Handler logic
    const { username, notificationSettings, ...profileData } = validatedData;
    // ... update profile logic

    return NextResponse.json({
      success: true,
      data: updatedProfile,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update profile' },
      { status: 500 }
    );
  }
});
```

### After: Composing withCSRF + withValidation

```typescript
// src/app/api/user/profile/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withValidation } from '@/lib/middleware/api-validation';
import { withCSRF } from '@/lib/middleware/csrf-validation';
import { userProfileUpdateSchema } from '@/lib/validations/api';
import { getAuthContext } from '@/lib/auth/get-auth-context';

export const PATCH = withValidation(userProfileUpdateSchema, {
  sanitize: true,
  checkSqlInjection: true,
  checkXss: true,
})(
  withCSRF(async (request: NextRequest, validatedData) => {
    try {
      // CSRF validation automatic
      // Schema validation automatic (validatedData is type-safe)

      // Auth check
      const authContext = await getAuthContext(request);
      if (!authContext) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }

      // Handler logic
      const { username, notificationSettings, ...profileData } = validatedData;
      // ... update profile logic

      return NextResponse.json({
        success: true,
        data: updatedProfile,
      });
    } catch (error) {
      return NextResponse.json(
        { error: 'Failed to update profile' },
        { status: 500 }
      );
    }
  })
);
```

**Changes:**

- Removed `validateAPICSRF` import and call
- Wrapped handler with `withCSRF` inside `withValidation`
- Order: `withValidation(...)(withCSRF(...))`
- Validation happens in order: Schema → CSRF → Handler

---

## Route with Privy Auth Wrapper

### Before: Manual CSRF with Privy Wrapper

```typescript
// src/app/api/notifications/preferences/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withPrivyAuth } from '@/lib/auth/privy-middleware-enhanced';
import { validateAPICSRF } from '@/lib/security/csrf-api';

export const PUT = withPrivyAuth(async (request: NextRequest, authContext) => {
  try {
    // Manual CSRF validation
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    const { privyUserId } = authContext;
    const body = await request.json();

    // ... update notification preferences

    return NextResponse.json({
      success: true,
      data: updatedPrefs,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update preferences' },
      { status: 500 }
    );
  }
});
```

### After: Composing withCSRF + withPrivyAuth

```typescript
// src/app/api/notifications/preferences/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withPrivyAuth } from '@/lib/auth/privy-middleware-enhanced';
import { withCSRF } from '@/lib/middleware/csrf-validation';

export const PUT = withPrivyAuth(
  withCSRF(async (request: NextRequest, authContext) => {
    // CSRF validation automatic
    // Privy auth automatic (authContext available)

    const { privyUserId } = authContext;
    const body = await request.json();

    // ... update notification preferences

    return NextResponse.json({
      success: true,
      data: updatedPrefs,
    });
  })
);
```

**Changes:**

- Removed `validateAPICSRF` import and call
- Wrapped handler with `withCSRF` inside `withPrivyAuth`
- Order: `withPrivyAuth(withCSRF(...))`
- Both auth and CSRF protection applied

---

## Admin/Treasury Routes

### Before: Manual CSRF Validation

```typescript
// src/app/api/treasury/execute/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { TreasuryService } from '@/lib/services/treasury';

export async function POST(request: NextRequest) {
  try {
    // Manual CSRF validation
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    // Auth check
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Admin role check
    if (!authContext.roles?.includes('admin')) {
      return NextResponse.json(
        { error: 'Forbidden - Admin access required' },
        { status: 403 }
      );
    }

    const body = await request.json();
    // ... execute treasury transaction

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to execute transaction' },
      { status: 500 }
    );
  }
}
```

### After: Using withStrictCSRF

```typescript
// src/app/api/treasury/execute/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withStrictCSRF } from '@/lib/middleware/csrf-validation';
import { getAuthContext } from '@/lib/auth/get-auth-context';
import { TreasuryService } from '@/lib/services/treasury';

export const POST = withStrictCSRF(async (request: NextRequest) => {
  try {
    // Strict CSRF validation automatic (no exclusions)

    // Auth check
    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Admin role check
    if (!authContext.roles?.includes('admin')) {
      return NextResponse.json(
        { error: 'Forbidden - Admin access required' },
        { status: 403 }
      );
    }

    const body = await request.json();
    // ... execute treasury transaction

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to execute transaction' },
      { status: 500 }
    );
  }
});
```

**Changes:**

- Removed `validateAPICSRF` import and call
- Used `withStrictCSRF` instead of `withCSRF` (no exclusions, enhanced security)
- Suitable for sensitive admin/treasury operations
- Changed from `async function POST` to `export const POST = withStrictCSRF(...)`

---

## Complex Multi-Method Routes

### Before: Manual CSRF for Multiple Methods

```typescript
// src/app/api/dao/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateAPICSRF } from '@/lib/security/csrf-api';
import { getAuthContext } from '@/lib/auth/get-auth-context';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  // No CSRF needed for GET
  const daoId = params.id;
  // ... fetch DAO
  return NextResponse.json({ success: true, data: dao });
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Manual CSRF validation
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const daoId = params.id;
    const body = await request.json();
    // ... update DAO

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update DAO' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Manual CSRF validation
    const csrfValidation = await validateAPICSRF(request);
    if (!csrfValidation.valid) {
      return csrfValidation.response!;
    }

    const authContext = await getAuthContext(request);
    if (!authContext) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const daoId = params.id;
    // ... delete DAO

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete DAO' },
      { status: 500 }
    );
  }
}
```

### After: Using withCSRF for Mutation Methods

```typescript
// src/app/api/dao/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withCSRF } from '@/lib/middleware/csrf-validation';
import { getAuthContext } from '@/lib/auth/get-auth-context';

// GET doesn't need CSRF (read-only)
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const daoId = params.id;
  // ... fetch DAO
  return NextResponse.json({ success: true, data: dao });
}

// PATCH needs CSRF (state-changing)
export const PATCH = withCSRF(
  async (request: NextRequest, { params }: { params: { id: string } }) => {
    try {
      // CSRF validation automatic

      const authContext = await getAuthContext(request);
      if (!authContext) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }

      const daoId = params.id;
      const body = await request.json();
      // ... update DAO

      return NextResponse.json({ success: true });
    } catch (error) {
      return NextResponse.json(
        { error: 'Failed to update DAO' },
        { status: 500 }
      );
    }
  }
);

// DELETE needs CSRF (state-changing)
export const DELETE = withCSRF(
  async (request: NextRequest, { params }: { params: { id: string } }) => {
    try {
      // CSRF validation automatic

      const authContext = await getAuthContext(request);
      if (!authContext) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
      }

      const daoId = params.id;
      // ... delete DAO

      return NextResponse.json({ success: true });
    } catch (error) {
      return NextResponse.json(
        { error: 'Failed to delete DAO' },
        { status: 500 }
      );
    }
  }
);
```

**Changes:**

- Removed `validateAPICSRF` import and calls
- GET handler unchanged (no CSRF needed for read-only)
- PATCH and DELETE wrapped with `withCSRF`
- Consistent pattern across all mutation methods

---

## Advanced: Full Stack Protection

For maximum security, combine all middleware layers:

```typescript
// src/app/api/admin/users/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { withAdminValidation } from '@/lib/middleware/api-validation';
import { withStrictCSRF } from '@/lib/middleware/csrf-validation';
import { withPrivyAuth } from '@/lib/auth/privy-middleware-enhanced';
import { adminUserUpdateSchema } from '@/lib/validations/api';

export const PATCH = withAdminValidation(adminUserUpdateSchema)(
  withPrivyAuth(
    withStrictCSRF(async (request: NextRequest, authContext, validatedData) => {
      // All layers applied:
      // 1. Schema validation (adminUserUpdateSchema)
      // 2. Privy authentication (authContext available)
      // 3. Strict CSRF validation (no exclusions)

      // Additional admin role check
      if (!authContext.roles?.includes('admin')) {
        return NextResponse.json(
          { error: 'Forbidden - Admin access required' },
          { status: 403 }
        );
      }

      // Handler logic with type-safe validatedData
      // ... update user

      return NextResponse.json({ success: true });
    })
  )
);
```

**Protection Layers:**

1. `withAdminValidation` - Schema validation with strict security checks
2. `withPrivyAuth` - Privy authentication
3. `withStrictCSRF` - Strict CSRF validation
4. Role check - Additional authorization layer

---

## Migration Checklist

When migrating a route, verify:

- [ ] Removed `validateAPICSRF` import
- [ ] Removed manual CSRF validation code
- [ ] Wrapped handler with `withCSRF` or `withStrictCSRF`
- [ ] Changed from `async function` to `export const` (for HOF pattern)
- [ ] GET requests don't have CSRF validation (unless needed)
- [ ] Admin/treasury routes use `withStrictCSRF`
- [ ] Middleware composition order is correct
- [ ] Error handling still works correctly
- [ ] Tested with valid and invalid CSRF tokens
- [ ] Updated any related tests

---

## Testing After Migration

### Manual Testing

1. **Valid CSRF Token**
   - Use app normally
   - Mutation should succeed

2. **Missing CSRF Token**
   - Remove `X-CSRF-Token` header from request
   - Should receive 403 with `CSRF_TOKEN_MISSING`

3. **Invalid CSRF Token**
   - Send mismatched token in header
   - Should receive 403 with `CSRF_TOKEN_INVALID`

4. **GET Requests**
   - Should work without CSRF token
   - Read-only operations unaffected

### Automated Testing

```typescript
import { POST } from '@/app/api/dao/[id]/join/route';

describe('POST /api/dao/[id]/join', () => {
  it('should accept requests with valid CSRF token', async () => {
    const token = 'valid-csrf-token';
    const request = new NextRequest('http://localhost/api/dao/123/join', {
      method: 'POST',
      headers: {
        'X-CSRF-Token': token,
        Cookie: `csrf-token=${token}`,
      },
    });

    const response = await POST(request, { params: { id: '123' } });
    expect(response.status).toBe(200);
  });

  it('should reject requests without CSRF token', async () => {
    const request = new NextRequest('http://localhost/api/dao/123/join', {
      method: 'POST',
    });

    const response = await POST(request, { params: { id: '123' } });
    expect(response.status).toBe(403);

    const data = await response.json();
    expect(data.code).toBe('CSRF_TOKEN_MISSING');
  });
});
```

---

## Common Pitfalls

### 1. Wrong Middleware Order

```typescript
// ❌ Wrong - CSRF runs before validation
export const POST = withCSRF(
  withValidation(schema)(async (request, data) => {
    // ...
  })
);

// ✅ Correct - Validation runs before CSRF
export const POST = withValidation(schema)(
  withCSRF(async (request, data) => {
    // ...
  })
);
```

### 2. Using async function Instead of const

```typescript
// ❌ Won't work - middleware not applied
export async function POST(request: NextRequest) {
  return withCSRF(async (req) => {
    // ...
  });
}

// ✅ Correct - middleware wraps handler
export const POST = withCSRF(async (request: NextRequest) => {
  // ...
});
```

### 3. Forgetting to Remove Manual Validation

```typescript
// ❌ Redundant - validation happens twice
export const POST = withCSRF(async (request: NextRequest) => {
  const csrfValidation = await validateAPICSRF(request);
  if (!csrfValidation.valid) {
    return csrfValidation.response!;
  }
  // ...
});

// ✅ Correct - validation automatic
export const POST = withCSRF(async (request: NextRequest) => {
  // CSRF validation automatic
  // ...
});
```

---

## Summary

The new CSRF middleware provides:

- **Cleaner code** - Less boilerplate
- **Consistent patterns** - Same approach across all routes
- **Composability** - Works with existing middleware
- **Type safety** - Preserves TypeScript types
- **Security** - Constant-time comparison, detailed logging
- **Flexibility** - Inline validation or HOF pattern

Migrate routes incrementally, starting with high-priority endpoints (admin, treasury, user profile).
