# Treasury Execution Locking

## Purpose

Prevents race condition vulnerability where multiple admins simultaneously attempting to execute a treasury transaction could lead to nonce conflicts and failed transactions.

## Last Updated

November 25, 2025

## Problem Statement

### Race Condition Vulnerability

When two admins click "Execute" on a treasury proposal simultaneously:

1. **Both processes fetch the same Safe nonce N** from the blockchain
2. **Both build transactions** with nonce N
3. **First transaction succeeds** on-chain (uses nonce N)
4. **Second transaction fails** (nonce N already used, needs N+1)
5. **UI might optimistically update** for both users, showing success

This creates a poor user experience and potential confusion about transaction status.

## Solution: Execution Locking

### Architecture

Implements a **database-based mutex lock** to ensure only one execution process can proceed at a time for a given proposal.

**Key Components**:

- `TreasuryExecutionLockService` - Lock management service
- `TreasuryExecutionOrchestrator.execute()` - Integration point
- Database table: `treasury_execution_locks`

### Lock Mechanism

**Lock Acquisition (Atomic)**:

```typescript
// Database transaction ensures atomicity
const lockResult = await treasuryExecutionLockService.acquireExecutionLock(
  proposalId,
  userId,
  executionId
);

if (!lockResult.success) {
  // Another execution is in progress
  throw new Error('Another admin is already executing this transaction');
}
```

**Lock Release (Always)**:

```typescript
try {
  // Execute treasury transaction
  const result = await executeWithLock(...)
  return result
} finally {
  // CRITICAL: Always release lock, even on error
  await treasuryExecutionLockService.releaseExecutionLock(proposalId, userId)
}
```

## Implementation Details

### TreasuryExecutionLockService

**Location**: `/Users/jjones/Projects/EnDAO/src/lib/services/treasury/treasury-execution-lock.service.ts`

**Key Methods**:

1. **acquireExecutionLock(proposalId, userId, executionId)**
   - Atomically checks and sets lock using database transaction
   - Returns success/failure with lock owner info
   - Automatically clears stale locks (>5 minutes old)

2. **releaseExecutionLock(proposalId, userId)**
   - Removes lock from database
   - Best-effort (never throws)
   - Always called in finally block

3. **isLocked(proposalId)**
   - Check current lock status
   - Returns lock owner and age

4. **forceClearLock(proposalId, adminId)**
   - Admin operation to clear stuck locks
   - Logs warning for audit trail

### Lock Data Structure

```typescript
interface ExecutionLock {
  proposalId: string;
  lockedBy: string;
  lockedAt: Timestamp;
  executionId?: string;
  lockType: 'execution' | 'signature_collection';
}
```

Stored in database table: `treasury_execution_locks`

### Integration in TreasuryExecutionOrchestrator

**Before (Vulnerable)**:

```typescript
async execute(executionId, executorId, authContext) {
  // Fetch nonce (RACE CONDITION HERE)
  const nonce = await safe.getNonce()

  // Build and submit transaction
  const tx = await buildTransaction(nonce)
  return await submitTransaction(tx)
}
```

**After (Protected)**:

```typescript
async execute(executionId, executorId, authContext) {
  // 1. Acquire lock (atomic)
  const lockResult = await treasuryExecutionLockService.acquireExecutionLock(
    proposalId,
    executorId,
    executionId
  )

  if (!lockResult.success) {
    throw new Error('Another execution is in progress')
  }

  // 2. Execute with lock protection
  try {
    return await this.executeWithLock(execution, executionRef, executorId, authContext)
  } finally {
    // 3. Always release lock
    await treasuryExecutionLockService.releaseExecutionLock(proposalId, executorId)
  }
}
```

## Lock Timeout & Stale Lock Handling

**Timeout**: 5 minutes (300,000 milliseconds)

**Stale Lock Detection**:

- When acquiring lock, check existing lock age
- If lock is older than 5 minutes, consider it stale
- Automatically clear stale lock and proceed
- Log warning for audit trail

**Purpose**: Prevents deadlocks if execution process crashes or times out

## Error Handling

### Lock Acquisition Failure

```typescript
if (!lockResult.success) {
  logger.warn('Execution blocked by lock', {
    executionId,
    proposalId,
    executorId,
    lockedBy: lockResult.lockedBy,
  });

  throw new Error(
    'Another admin is already executing this transaction. Please wait.'
  );
}
```

**User Experience**: Clear error message explaining another admin is executing

### Lock Release Failure

```typescript
// Log but don't throw - lock release is best-effort
logger.error('Failed to release execution lock', {
  proposalId,
  userId,
  error,
});
```

**Rationale**: Lock release failures should not block successful execution

## Testing

### Test File

`/Users/jjones/Projects/EnDAO/src/lib/services/treasury/__tests__/treasury-execution-lock.test.ts`

### Test Coverage

1. **Basic Lock Operations**
   - Acquire lock when none exists
   - Block concurrent acquisition
   - Release lock properly
   - Check lock status

2. **Race Condition Prevention**
   - Simulate simultaneous execution attempts
   - Verify second attempt is blocked
   - Verify first executes successfully

3. **Stale Lock Handling**
   - Test timeout logic (mocked time)
   - Verify automatic cleanup

4. **Admin Operations**
   - Force clear locks
   - Audit logging

### Running Tests

```bash
yarn test -- --testPathPattern=treasury-execution-lock
```

## Monitoring & Observability

### Logging

All lock operations are logged with context:

```typescript
logger.info('Execution lock acquired', {
  proposalId,
  userId,
  executionId,
});

logger.warn('Clearing stale execution lock', {
  proposalId,
  staleLockBy: existingLock.lockedBy,
  lockAge: '320s',
});
```

### Metrics to Monitor

- **Lock acquisition failures** - Indicates concurrent execution attempts
- **Stale lock cleanups** - May indicate execution timeouts or crashes
- **Lock release failures** - Potential database connectivity issues

## Security Considerations

### Atomic Lock Acquisition

Uses Supabase PostgreSQL transactions for atomic check-and-set:

```typescript
const { data, error } = await supabase.rpc('acquire_execution_lock', {
  p_proposal_id: proposalId,
  p_locked_by: userId,
  p_execution_id: executionId,
});

if (error || !data.success) {
  return { success: false, alreadyLocked: true };
}

return { success: true };
```

**Critical**: Prevents TOCTOU (Time-of-Check-Time-of-Use) race condition

### Lock Verification

Lock release verifies ownership:

```typescript
if (lock.lockedBy !== userId) {
  logger.warn('Lock release attempted by non-owner', {
    requestedBy: userId,
    actualOwner: lock.lockedBy,
  });
  // Still allow release to prevent deadlocks
}
```

### Audit Trail

All lock operations logged for compliance:

- Lock acquisition with user ID
- Lock release with user ID
- Stale lock cleanups
- Force clear operations

## Performance Impact

**Minimal overhead**:

- Single database transaction for lock check/set (~50-100ms)
- Single database delete for lock release (~30-50ms)
- Total overhead: ~80-150ms per execution

**Trade-off**: Small latency increase for guaranteed correctness

## Future Enhancements

1. **Redis-based Locking**: Consider Redis for higher concurrency scenarios
2. **Lock Metrics Dashboard**: Real-time monitoring of lock operations
3. **Automatic Retry**: UI could auto-retry after lock is released
4. **Lock Queue**: Allow multiple admins to queue execution attempts

## Related Documentation

- [Treasury Protection System](./TREASURY_PROTECTION_SYSTEM.md)
- [Security Audit Report](./PRODUCTION_HARDENING_AUDIT.md)
- [Transaction Simulation](./TRANSACTION_SIMULATION.md)

## References

- Supabase PostgreSQL Transactions: https://supabase.com/docs/guides/database/transactions
- Distributed Locking: https://martin.kleppmann.com/2016/02/08/how-to-do-distributed-locking.html
- Safe Protocol: https://docs.safe.global/

---

Last Updated: November 25, 2025
Version: 1.0.0
Status: Production Ready
