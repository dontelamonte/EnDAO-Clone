# CSRF Protection Route Audit

This document tracks which API routes have CSRF protection implemented and which routes need migration to the new middleware.

**Last Updated**: December 18, 2025

## Quick Stats

- **Total API Routes**: ~90+ routes
- **Routes with CSRF**: 1 (manual validation)
- **Routes Needing CSRF**: ~50+ (all mutation endpoints)
- **Routes Excluded**: ~40 (GET/health/webhooks)

## Implementation Status Legend

- ✅ **Protected** - Has CSRF validation (new middleware)
- 🟡 **Manual** - Has CSRF validation (manual/legacy pattern)
- ❌ **Missing** - Needs CSRF protection
- ⚪ **N/A** - Excluded (GET/health/webhook)

---

## High Priority Routes (Treasury & Admin)

These routes handle sensitive operations and should use `withStrictCSRF`.

### Treasury Routes

| Route                                            | Method | Status     | Notes                         |
| ------------------------------------------------ | ------ | ---------- | ----------------------------- |
| `/api/treasury/execute`                          | POST   | ❌ Missing | Execute treasury transactions |
| `/api/treasury/sign`                             | POST   | ❌ Missing | Sign multi-sig transactions   |
| `/api/treasury/v2/create-safe`                   | POST   | ❌ Missing | Create new Safe wallet        |
| `/api/treasury/execution/[proposalId]`           | POST   | ❌ Missing | Execute proposal transaction  |
| `/api/treasury/execution/[proposalId]/signature` | POST   | ❌ Missing | Add signature to transaction  |
| `/api/treasury/balance`                          | GET    | ⚪ N/A     | Read-only                     |
| `/api/treasury/transactions`                     | GET    | ⚪ N/A     | Read-only                     |
| `/api/treasury/faucet`                           | POST   | ⚪ N/A     | CDP faucet (own auth)         |

### Admin Routes

| Route                            | Method         | Status     | Notes                  |
| -------------------------------- | -------------- | ---------- | ---------------------- |
| `/api/admin/refresh-analytics`   | POST           | ❌ Missing | Refresh analytics data |
| `/api/admin/system-stats`        | GET            | ⚪ N/A     | Read-only              |
| `/api/admin/proposal-statistics` | GET            | ⚪ N/A     | Read-only              |
| `/api/admin/users`               | GET/POST/PATCH | ❌ Missing | User management        |
| `/api/admin/roles`               | GET/POST/PATCH | ❌ Missing | Role management        |
| `/api/admin/members/search`      | POST           | ❌ Missing | Search members         |
| `/api/admin/dao/[id]/archive`    | POST           | ❌ Missing | Archive DAO            |
| `/api/admin/audit-logs`          | GET            | ⚪ N/A     | Read-only              |

---

## User Management Routes

| Route                           | Method    | Status     | Notes                |
| ------------------------------- | --------- | ---------- | -------------------- |
| `/api/user/profile`             | GET       | ⚪ N/A     | Read-only            |
| `/api/user/profile`             | PATCH     | 🟡 Manual  | Uses validateAPICSRF |
| `/api/user/username/claim`      | POST      | ❌ Missing | Claim username       |
| `/api/user/username/validate`   | POST      | ❌ Missing | Validate username    |
| `/api/user/onboarding-progress` | GET/PATCH | ❌ Missing | Onboarding state     |
| `/api/users/summaries`          | POST      | ❌ Missing | Bulk user data       |
| `/api/users/[username]`         | GET       | ⚪ N/A     | Read-only            |

---

## DAO Management Routes

### DAO CRUD

| Route                           | Method | Status     | Notes               |
| ------------------------------- | ------ | ---------- | ------------------- |
| `/api/dao/create`               | POST   | ❌ Missing | Create new DAO      |
| `/api/dao/search`               | POST   | ❌ Missing | Search DAOs         |
| `/api/dao/[id]`                 | GET    | ⚪ N/A     | Read-only           |
| `/api/dao/[id]`                 | PATCH  | ❌ Missing | Update DAO          |
| `/api/dao/[id]`                 | DELETE | ❌ Missing | Delete DAO          |
| `/api/dao/[id]/recover`         | POST   | ❌ Missing | Recover deleted DAO |
| `/api/dao/[id]/deletion-status` | GET    | ⚪ N/A     | Read-only           |

### DAO Membership

| Route                         | Method         | Status     | Notes                   |
| ----------------------------- | -------------- | ---------- | ----------------------- |
| `/api/dao/[id]/join`          | POST           | ❌ Missing | Join DAO                |
| `/api/dao/[id]/join/qr`       | GET            | ⚪ N/A     | QR code for joining     |
| `/api/dao/[id]/leave`         | POST           | ❌ Missing | Leave DAO               |
| `/api/dao/[id]/members`       | GET/POST/PATCH | ❌ Missing | Manage members          |
| `/api/dao/[id]/membership`    | GET            | ⚪ N/A     | Check membership        |
| `/api/dao/[id]/join-requests` | GET/POST/PATCH | ❌ Missing | Join request management |

### DAO Settings & Permissions

| Route                             | Method          | Status     | Notes                     |
| --------------------------------- | --------------- | ---------- | ------------------------- |
| `/api/dao/[id]/admin-permissions` | GET/PATCH       | ❌ Missing | Admin role management     |
| `/api/dao/[id]/treasury-access`   | GET/PATCH       | ❌ Missing | Treasury access control   |
| `/api/dao/[id]/treasury-admins`   | GET/POST/DELETE | ❌ Missing | Treasury admin management |

### DAO Data & Stats

| Route                                       | Method    | Status     | Notes                    |
| ------------------------------------------- | --------- | ---------- | ------------------------ |
| `/api/dao/[id]/stats`                       | GET       | ⚪ N/A     | Read-only                |
| `/api/dao/[id]/activities`                  | GET       | ⚪ N/A     | Read-only                |
| `/api/dao/[id]/reports`                     | GET       | ⚪ N/A     | Read-only                |
| `/api/dao/[id]/voting-power`                | GET       | ⚪ N/A     | Read-only                |
| `/api/dao/[id]/quadratic-credits`           | GET/PATCH | ❌ Missing | Quadratic voting credits |
| `/api/dao/[id]/quadratic-credits/vote-cost` | POST      | ❌ Missing | Calculate vote cost      |

---

## Proposal & Voting Routes

### Proposal CRUD

| Route                                | Method   | Status     | Notes                 |
| ------------------------------------ | -------- | ---------- | --------------------- |
| `/api/dao/[id]/proposals`            | GET/POST | ❌ Missing | List/create proposals |
| `/api/dao/[id]/proposals/history`    | GET      | ⚪ N/A     | Read-only             |
| `/api/dao/[id]/treasury-proposals`   | GET/POST | ❌ Missing | Treasury proposals    |
| `/api/proposals/[proposalId]`        | GET      | ⚪ N/A     | Read-only             |
| `/api/proposals/[proposalId]`        | PATCH    | ❌ Missing | Update proposal       |
| `/api/proposals/[proposalId]/delete` | DELETE   | ❌ Missing | Delete proposal       |

### Proposal Actions

| Route                                         | Method | Status     | Notes                   |
| --------------------------------------------- | ------ | ---------- | ----------------------- |
| `/api/proposals/[proposalId]/vote`            | POST   | ❌ Missing | Cast vote               |
| `/api/proposals/[proposalId]/approve`         | POST   | ❌ Missing | Approve proposal        |
| `/api/proposals/[proposalId]/request-changes` | POST   | ❌ Missing | Request changes         |
| `/api/proposals/[proposalId]/execute`         | POST   | ❌ Missing | Execute proposal        |
| `/api/proposals/auto-activate`                | POST   | ❌ Missing | Auto-activate proposals |

### Proposal Queries

| Route                                      | Method | Status     | Notes        |
| ------------------------------------------ | ------ | ---------- | ------------ |
| `/api/proposals/[proposalId]/can-execute`  | GET    | ⚪ N/A     | Read-only    |
| `/api/proposals/[proposalId]/can-vote`     | GET    | ⚪ N/A     | Read-only    |
| `/api/proposals/[proposalId]/permissions`  | GET    | ⚪ N/A     | Read-only    |
| `/api/proposals/[proposalId]/user-vote`    | GET    | ⚪ N/A     | Read-only    |
| `/api/proposals/[proposalId]/votes/verify` | POST   | ❌ Missing | Verify votes |

### Proposal Comments

| Route                                              | Method       | Status     | Notes                |
| -------------------------------------------------- | ------------ | ---------- | -------------------- |
| `/api/proposals/[proposalId]/comments`             | GET/POST     | ❌ Missing | Comments on proposal |
| `/api/proposals/[proposalId]/comments/[commentId]` | PATCH/DELETE | ❌ Missing | Edit/delete comment  |
| `/api/comments/[commentId]/like`                   | POST         | ❌ Missing | Like comment         |

---

## Discussion & Bounty Routes

### Discussions

| Route                                             | Method           | Status     | Notes               |
| ------------------------------------------------- | ---------------- | ---------- | ------------------- |
| `/api/dao/[id]/discussions`                       | GET/POST         | ❌ Missing | DAO discussions     |
| `/api/discussions/[id]`                           | GET/PATCH/DELETE | ❌ Missing | Manage discussion   |
| `/api/discussions/[id]/comments`                  | GET/POST         | ❌ Missing | Discussion comments |
| `/api/discussions/[id]/comments/[commentId]/like` | POST             | ❌ Missing | Like comment        |
| `/api/discussions/[id]/reactions`                 | POST             | ❌ Missing | Add reaction        |
| `/api/discussions/[id]/convert`                   | POST             | ❌ Missing | Convert to proposal |

### Bounties

| Route                      | Method         | Status     | Notes             |
| -------------------------- | -------------- | ---------- | ----------------- |
| `/api/bounty/[proposalId]` | GET/POST/PATCH | ❌ Missing | Bounty management |

---

## Delegation Routes

| Route                          | Method    | Status     | Notes              |
| ------------------------------ | --------- | ---------- | ------------------ |
| `/api/dao/[id]/delegations`    | GET/POST  | ❌ Missing | Voting delegations |
| `/api/delegations/[id]`        | GET/PATCH | ❌ Missing | Manage delegation  |
| `/api/delegations/[id]/revoke` | POST      | ❌ Missing | Revoke delegation  |

---

## Invitation Routes

| Route                          | Method | Status     | Notes               |
| ------------------------------ | ------ | ---------- | ------------------- |
| `/api/invitations/create`      | POST   | ❌ Missing | Create invitation   |
| `/api/invitations/accept`      | POST   | ❌ Missing | Accept invitation   |
| `/api/invitations/cancel`      | POST   | ❌ Missing | Cancel invitation   |
| `/api/invitations/bulk`        | POST   | ❌ Missing | Bulk invitations    |
| `/api/invitations/dao/[daoId]` | GET    | ⚪ N/A     | Read-only           |
| `/api/invitations/validate`    | POST   | ❌ Missing | Validate invitation |

---

## Notification Routes

| Route                                    | Method   | Status     | Notes              |
| ---------------------------------------- | -------- | ---------- | ------------------ |
| `/api/notifications`                     | GET      | ⚪ N/A     | Read-only          |
| `/api/notifications/preferences`         | GET      | ⚪ N/A     | Read-only          |
| `/api/notifications/preferences`         | PUT      | ❌ Missing | Update preferences |
| `/api/notifications/unsubscribe/[token]` | GET/POST | ⚪ N/A     | Email unsubscribe  |

---

## Upload Routes

| Route                  | Method | Status     | Notes               |
| ---------------------- | ------ | ---------- | ------------------- |
| `/api/upload`          | POST   | ❌ Missing | Generic file upload |
| `/api/upload/avatar`   | POST   | ❌ Missing | User avatar upload  |
| `/api/upload/dao-logo` | POST   | ❌ Missing | DAO logo upload     |

---

## Dashboard & Analytics Routes

| Route                              | Method | Status | Notes     |
| ---------------------------------- | ------ | ------ | --------- |
| `/api/dashboard`                   | GET    | ⚪ N/A | Read-only |
| `/api/dashboard/voting-statistics` | GET    | ⚪ N/A | Read-only |
| `/api/analytics/user`              | GET    | ⚪ N/A | Read-only |
| `/api/platform/stats`              | GET    | ⚪ N/A | Read-only |

---

## System & Health Routes

| Route                       | Method | Status | Notes                 |
| --------------------------- | ------ | ------ | --------------------- |
| `/api/health`               | GET    | ⚪ N/A | Health check          |
| `/api/health/observability` | GET    | ⚪ N/A | Observability metrics |
| `/api/performance/metrics`  | GET    | ⚪ N/A | Performance metrics   |
| `/api/cache/health`         | GET    | ⚪ N/A | Cache health          |
| `/api/cache/metrics`        | GET    | ⚪ N/A | Cache metrics         |

---

## Auth & Security Routes

| Route                      | Method   | Status | Notes                 |
| -------------------------- | -------- | ------ | --------------------- |
| `/api/auth/csrf`           | GET/POST | ⚪ N/A | CSRF token generation |
| `/api/auth/verify`         | GET      | ⚪ N/A | Verify auth token     |
| `/api/security/csp-report` | POST     | ⚪ N/A | CSP violation reports |

---

## Cron & Background Jobs

| Route                          | Method | Status | Notes             |
| ------------------------------ | ------ | ------ | ----------------- |
| `/api/cron/process-deletions`  | POST   | ⚪ N/A | Internal cron job |
| `/api/cron/voting-reminders`   | POST   | ⚪ N/A | Internal cron job |
| `/api/cron/snapshot-dao-stats` | POST   | ⚪ N/A | Internal cron job |

---

## Error Logging Routes

| Route         | Method | Status     | Notes             |
| ------------- | ------ | ---------- | ----------------- |
| `/api/errors` | POST   | ❌ Missing | Log client errors |
| `/api/logs`   | POST   | ❌ Missing | Log client events |

---

## Feature Flags

| Route                 | Method | Status | Notes     |
| --------------------- | ------ | ------ | --------- |
| `/api/features/flags` | GET    | ⚪ N/A | Read-only |

---

## Migration Priority

### Phase 1: Critical (Immediate)

High-security operations that should use `withStrictCSRF`:

1. **Treasury Operations** (8 routes)
   - `/api/treasury/execute`
   - `/api/treasury/sign`
   - `/api/treasury/v2/create-safe`
   - `/api/treasury/execution/*`
   - `/api/dao/[id]/treasury-access`
   - `/api/dao/[id]/treasury-admins`

2. **Admin Operations** (7 routes)
   - `/api/admin/users`
   - `/api/admin/roles`
   - `/api/admin/dao/[id]/archive`
   - `/api/admin/members/search`
   - `/api/admin/refresh-analytics`

3. **DAO Deletion/Recovery** (2 routes)
   - `/api/dao/[id]` (DELETE)
   - `/api/dao/[id]/recover`

### Phase 2: High Priority

User data and membership operations:

1. **User Profile** (1 route) - ✅ Already has manual CSRF
   - `/api/user/profile` (PATCH)

2. **DAO Membership** (5 routes)
   - `/api/dao/[id]/join`
   - `/api/dao/[id]/leave`
   - `/api/dao/[id]/members`
   - `/api/dao/[id]/join-requests`

3. **Voting** (5 routes)
   - `/api/proposals/[proposalId]/vote`
   - `/api/proposals/[proposalId]/approve`
   - `/api/proposals/[proposalId]/execute`

### Phase 3: Medium Priority

Content creation and updates:

1. **DAO Management** (3 routes)
   - `/api/dao/create`
   - `/api/dao/[id]` (PATCH)

2. **Proposals** (8 routes)
   - `/api/dao/[id]/proposals` (POST)
   - `/api/proposals/[proposalId]` (PATCH/DELETE)
   - `/api/proposals/[proposalId]/request-changes`

3. **Discussions & Comments** (10 routes)
   - `/api/discussions/*`
   - `/api/comments/*`

### Phase 4: Low Priority

Less sensitive operations:

1. **Invitations** (5 routes)
2. **Delegations** (3 routes)
3. **Uploads** (3 routes)
4. **Error Logging** (2 routes)

---

## Automated Migration Script

To help with migration, you can use this pattern to find routes that need CSRF:

```bash
# Find all POST/PUT/PATCH/DELETE handlers without withCSRF
grep -r "export async function POST\|export async function PUT\|export async function PATCH\|export async function DELETE" src/app/api/ | grep -v "withCSRF"

# Find routes with manual validateAPICSRF
grep -r "validateAPICSRF" src/app/api/
```

---

## Testing Checklist

After migrating a route, verify:

- [ ] CSRF token is required for mutations (POST/PUT/PATCH/DELETE)
- [ ] GET requests work without CSRF token
- [ ] Invalid CSRF token returns 403 with proper error code
- [ ] Missing CSRF token returns 403 with proper error code
- [ ] Valid CSRF token allows request to proceed
- [ ] Error response doesn't leak sensitive information
- [ ] Logging shows CSRF validation events

---

## Notes

- All GET requests are excluded from CSRF validation by default
- Webhook endpoints should be excluded (use signature validation instead)
- Health/metrics endpoints don't need CSRF protection
- Cron jobs should use internal authentication, not CSRF
- Admin/treasury routes should use `withStrictCSRF` for maximum security

---

## References

- [CSRF Middleware Implementation](/src/lib/middleware/csrf-validation.ts)
- [CSRF Middleware Guide](/docs/security/CSRF_MIDDLEWARE_GUIDE.md)
- [Migration Examples](/docs/security/CSRF_MIGRATION_EXAMPLES.md)
- [Existing CSRF Implementation](/src/lib/security/csrf.ts)
