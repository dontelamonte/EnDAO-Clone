# CSRF Validation Middleware Guide

## Overview

EnDAO implements CSRF (Cross-Site Request Forgery) protection using the **double-submit cookie pattern**. This guide explains how to use the server-side validation middleware in your API routes.

## Architecture

### Flow

1. **Token Generation** (`/api/auth/csrf`)
   - Server generates cryptographically secure token
   - Token stored in secure cookie (HttpOnly=false for client access)
   - Token also returned in response body and header

2. **Client-Side** (`useCSRFAPI` hook)
   - Hook fetches token from `/api/auth/csrf`
   - Token sent in `X-CSRF-Token` header with each mutation request
   - Automatically combined with Privy authentication

3. **Server-Side Validation** (This middleware)
   - Extract token from cookie (server-side)
   - Extract token from header (client-side)
   - Compare using constant-time comparison
   - Block request if mismatch (403 Forbidden)

### Security Features

- **Constant-time comparison** - Prevents timing attacks
- **Automatic method detection** - Skips GET/HEAD/OPTIONS by default
- **Path exclusions** - Skip validation for public endpoints
- **Detailed logging** - Security event monitoring
- **Integration with existing middleware** - Works with `withValidation`

## Usage Patterns

### 1. Simple API Route Protection (Recommended)

Use `withCSRF` to wrap your handler:

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { withCSRF } from '@/lib/middleware/csrf-validation';

export const POST = withCSRF(async (request: NextRequest) => {
  const body = await request.json();

  // Your handler logic here - CSRF already validated
  return NextResponse.json({ success: true, data: body });
});
```

### 2. Combined with Schema Validation

Compose `withCSRF` with `withValidation`:

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { withValidation } from '@/lib/middleware/api-validation';
import { withCSRF } from '@/lib/middleware/csrf-validation';
import { userProfileUpdateSchema } from '@/lib/validations/api';

export const PATCH = withValidation(userProfileUpdateSchema, {
  sanitize: true,
  checkSqlInjection: true,
  checkXss: true,
})(
  withCSRF(async (request, validatedData) => {
    // Both CSRF and schema validation passed
    // validatedData is type-safe and validated
    return NextResponse.json({ success: true, data: validatedData });
  })
);
```

### 3. Inline Validation (Legacy Pattern)

For complex handlers that need manual control:

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { validateCSRF } from '@/lib/middleware/csrf-validation';

export async function POST(request: NextRequest) {
  // Validate CSRF token first
  const csrfCheck = await validateCSRF(request);
  if (!csrfCheck.valid) {
    return csrfCheck.response!;
  }

  // Continue with handler logic
  const body = await request.json();
  return NextResponse.json({ success: true });
}
```

### 4. Strict CSRF for Sensitive Endpoints

Use `withStrictCSRF` for admin/treasury operations:

```typescript
import { withStrictCSRF } from '@/lib/middleware/csrf-validation';

export const DELETE = withStrictCSRF(async (request: NextRequest) => {
  // Strict validation with no exclusions
  // Even GET requests are validated for sensitive endpoints
  return NextResponse.json({ success: true });
});
```

### 5. Custom Configuration

Override default behavior with custom config:

```typescript
import { withCSRF } from '@/lib/middleware/csrf-validation';

export const POST = withCSRF(
  async (request: NextRequest) => {
    return NextResponse.json({ success: true });
  },
  {
    excludePaths: ['/api/webhook/*'],
    excludeMethods: ['GET', 'HEAD', 'OPTIONS'],
    enableLogging: false,
    errorMessage: 'Custom CSRF error message',
  }
);
```

## Configuration Options

```typescript
interface CSRFMiddlewareConfig {
  /** Skip CSRF validation for specific paths (supports wildcards) */
  excludePaths?: string[];

  /** Skip CSRF validation for specific methods */
  excludeMethods?: string[];

  /** Enable detailed logging (default: true) */
  enableLogging?: boolean;

  /** Custom error message for validation failures */
  errorMessage?: string;
}
```

### Default Configuration

```typescript
{
  excludePaths: [],
  excludeMethods: ['GET', 'HEAD', 'OPTIONS'],
  enableLogging: true,
  errorMessage: 'CSRF validation failed. Please refresh the page and try again.',
}
```

## Migration Guide

### Migrating Existing Routes

#### Before (Manual Validation)

```typescript
import { validateAPICSRF } from '@/lib/security/csrf-api';

export async function PATCH(request: NextRequest) {
  // Manual CSRF validation
  const csrfValidation = await validateAPICSRF(request);
  if (!csrfValidation.valid) {
    return csrfValidation.response!;
  }

  // Handler logic
  const body = await request.json();
  return NextResponse.json({ success: true });
}
```

#### After (Using Middleware)

```typescript
import { withCSRF } from '@/lib/middleware/csrf-validation';

export const PATCH = withCSRF(async (request: NextRequest) => {
  // CSRF validation automatic
  const body = await request.json();
  return NextResponse.json({ success: true });
});
```

### Migration with withValidation

#### Before

```typescript
export const PATCH = withValidation(
  schema,
  options
)(async function patchHandler(request, validatedData) {
  // Manual CSRF check
  const csrfValidation = await validateAPICSRF(request);
  if (!csrfValidation.valid) {
    return csrfValidation.response!;
  }

  return NextResponse.json({ success: true, data: validatedData });
});
```

#### After

```typescript
export const PATCH = withValidation(
  schema,
  options
)(
  withCSRF(async (request, validatedData) => {
    // CSRF validation automatic
    return NextResponse.json({ success: true, data: validatedData });
  })
);
```

## Endpoints That Should Have CSRF Protection

### High Priority (MUST have CSRF)

All state-changing operations should be protected:

1. **User Profile** - `/api/user/profile` (PATCH)
2. **DAO Management** - `/api/dao/*` (POST, PATCH, DELETE)
3. **Treasury Operations** - `/api/treasury/*` (POST, PATCH, DELETE)
4. **Proposals** - `/api/proposals/*` (POST, PATCH, DELETE)
5. **Voting** - `/api/proposals/*/vote` (POST)
6. **Membership** - `/api/dao/*/join`, `/api/dao/*/leave` (POST)
7. **Admin Operations** - `/api/admin/*` (POST, PATCH, DELETE)
8. **Invitations** - `/api/invitations/*` (POST, DELETE)
9. **Notifications** - `/api/notifications/preferences` (PUT, PATCH)

### Excluded Endpoints

These endpoints should NOT have CSRF validation:

1. **Read-only Operations** - All GET requests (automatic)
2. **Privy Auth** - `/api/auth/privy/*` (has own validation)
3. **Health Checks** - `/api/health/*` (no state change)
4. **Webhooks** - `/api/webhook/*` (external, use signature validation)
5. **CSRF Token Endpoint** - `/api/auth/csrf` (generates tokens)

## Error Responses

When CSRF validation fails, clients receive:

```json
{
  "error": "CSRF Validation Failed",
  "message": "CSRF validation failed. Please refresh the page and try again.",
  "code": "CSRF_TOKEN_MISSING" | "CSRF_COOKIE_MISSING" | "CSRF_TOKEN_INVALID",
  "timestamp": "2025-12-18T10:30:00.000Z"
}
```

Status Code: `403 Forbidden`

Headers:

- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `Cache-Control: no-store, no-cache, must-revalidate`

## Error Codes

| Code                  | Meaning                    | Client Action                 |
| --------------------- | -------------------------- | ----------------------------- |
| `CSRF_TOKEN_MISSING`  | No token in request header | Refresh page to get new token |
| `CSRF_COOKIE_MISSING` | No token in cookie         | Refresh page to get new token |
| `CSRF_TOKEN_INVALID`  | Token mismatch or tampered | Refresh page to get new token |

## Client-Side Integration

The client-side hook automatically handles CSRF tokens:

```typescript
import { useCSRFAPI } from '@/lib/hooks/use-csrf'

function MyComponent() {
  const { call, loading, error } = useCSRFAPI()

  const updateProfile = async () => {
    const response = await call('/api/user/profile', {
      method: 'PATCH',
      body: JSON.stringify({ name: 'New Name' }),
    })

    if (response.ok) {
      const data = await response.json()
      // Success
    }
  }

  return <button onClick={updateProfile}>Update Profile</button>
}
```

## Debugging

### Enable Debug Logging

```typescript
export const POST = withCSRF(
  async (request: NextRequest) => {
    return NextResponse.json({ success: true });
  },
  { enableLogging: true }
);
```

### Check CSRF Status

```typescript
import { getCSRFStatus } from '@/lib/middleware/csrf-validation';

const status = await getCSRFStatus(request);
console.log({
  required: status.required, // Is CSRF protection required?
  cookiePresent: status.cookiePresent, // Is token in cookie?
  headerPresent: status.headerPresent, // Is token in header?
  valid: status.valid, // Is validation passing?
  error: status.error, // Error message if any
});
```

### Common Issues

#### 1. Token Not Found in Cookie

**Cause**: User hasn't visited the app or cookies were cleared

**Solution**: Client should call `/api/auth/csrf` to get new token

#### 2. Token Not Found in Header

**Cause**: Client not using `useCSRFAPI` hook or not sending `X-CSRF-Token` header

**Solution**: Use `useCSRFAPI` hook or manually add header

#### 3. Token Mismatch

**Cause**: Cookie token and header token don't match (possible CSRF attack)

**Solution**: Refresh page to get new synchronized tokens

## Security Considerations

### Why Double-Submit Cookie Pattern?

1. **Simple to implement** - No server-side state storage needed
2. **Scalable** - Works across multiple servers/instances
3. **Defense in depth** - Combines with SameSite cookies
4. **Browser compatibility** - Works in all modern browsers

### Additional Security Layers

CSRF protection is part of a defense-in-depth strategy:

1. **SameSite Cookies** - Prevents cross-site cookie sending
2. **Origin Validation** - Check `Origin` and `Referer` headers
3. **Privy Authentication** - All routes require valid auth token
4. **Rate Limiting** - Prevents brute force attacks
5. **Input Validation** - Schema validation with XSS/SQL injection checks

### Timing Attack Prevention

The middleware uses **constant-time comparison** to prevent timing attacks:

```typescript
// Bad: Timing-vulnerable comparison
if (cookieToken === headerToken) { ... }

// Good: Constant-time comparison
function constantTimeCompare(a: string, b: string): boolean {
  if (a.length !== b.length) return false
  let result = 0
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i)
  }
  return result === 0
}
```

## Testing

### Unit Tests

```typescript
import { validateCSRF } from '@/lib/middleware/csrf-validation';
import { NextRequest } from 'next/server';

describe('CSRF Validation', () => {
  it('should pass validation with valid tokens', async () => {
    const request = new NextRequest('http://localhost/api/test', {
      method: 'POST',
      headers: {
        'X-CSRF-Token': 'valid-token',
        Cookie: 'csrf-token=valid-token',
      },
    });

    const result = await validateCSRF(request);
    expect(result.valid).toBe(true);
  });

  it('should fail validation with mismatched tokens', async () => {
    const request = new NextRequest('http://localhost/api/test', {
      method: 'POST',
      headers: {
        'X-CSRF-Token': 'token1',
        Cookie: 'csrf-token=token2',
      },
    });

    const result = await validateCSRF(request);
    expect(result.valid).toBe(false);
    expect(result.code).toBe('CSRF_TOKEN_INVALID');
  });
});
```

### Integration Tests

```typescript
import { POST } from '@/app/api/user/profile/route';

describe('POST /api/user/profile', () => {
  it('should reject requests without CSRF token', async () => {
    const request = new NextRequest('http://localhost/api/user/profile', {
      method: 'POST',
      body: JSON.stringify({ name: 'Test' }),
    });

    const response = await POST(request);
    expect(response.status).toBe(403);

    const data = await response.json();
    expect(data.code).toBe('CSRF_TOKEN_MISSING');
  });
});
```

## Performance Considerations

### Overhead

CSRF validation adds minimal overhead:

- **Token generation**: ~0.5ms (crypto.getRandomValues)
- **Token validation**: ~0.1ms (constant-time comparison)
- **Cookie parsing**: ~0.1ms (built into Next.js)

### Caching

Tokens are cached in cookies for 24 hours:

- Reduces `/api/auth/csrf` calls
- Minimizes token generation overhead
- Automatic rotation on expiry

## Audit Checklist

Use this checklist when reviewing API routes:

- [ ] All POST/PUT/PATCH/DELETE routes have CSRF protection
- [ ] GET requests don't have CSRF validation (unless strictly needed)
- [ ] Webhook endpoints are excluded from CSRF validation
- [ ] Admin/treasury routes use `withStrictCSRF` or strict config
- [ ] Error messages don't leak sensitive information
- [ ] Logging is enabled for security monitoring
- [ ] Client uses `useCSRFAPI` hook or sends `X-CSRF-Token` header
- [ ] Tokens are fetched before mutation operations

## References

- [OWASP CSRF Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html)
- [Double Submit Cookie Pattern](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html#double-submit-cookie)
- [Next.js Middleware Documentation](https://nextjs.org/docs/app/building-your-application/routing/middleware)

## Support

For questions or issues:

1. Check this guide and existing implementation in `/src/lib/middleware/csrf-validation.ts`
2. Review CSRF audit reports in `/docs/security/`
3. Contact the security team or create an issue in the repository
