/**
 * Secure Logging Examples for EnDAO MVP
 *
 * This file demonstrates proper usage of secure logging utilities
 * to prevent credential/secret leakage in development and production.
 */

import {
  createSecureLogger,
  secureLog,
  secureError,
  secureEnvLog,
  secureAddressLog,
  secureTxHashLog,
  sanitizeObject,
  devLog,
  formatErrorForLogging,
} from '@/lib/utils/secure-logging';

// ===============================================
// 1. Basic Secure Logging Examples
// ===============================================

// Create a logger for your component/service
const treasuryLogger = createSecureLogger('TreasuryService');

// ✅ Safe logging of operations
treasuryLogger.log('Treasury proposal created', {
  proposalId: 'prop_123',
  amount: '1.5',
  recipient: '0x1234...5678',
});

// ✅ Safe error logging (automatically sanitizes)
try {
  // Some operation that might fail
  throw new Error('Treasury execution failed');
} catch (error) {
  treasuryLogger.error('Treasury operation failed', error, {
    daoId: 'dao_456',
    operation: 'executeProposal',
  });
}

// ===============================================
// 2. Environment Variable Logging
// ===============================================

// ✅ Safe environment variable checking
function checkConfiguration() {
  console.log('🔧 Environment Configuration Check');
  console.log('================================');

  // These will show appropriate levels of detail based on sensitivity
  secureEnvLog('NEXT_PUBLIC_FIREBASE_PROJECT_ID'); // Shows value (public)
  secureEnvLog('FIREBASE_ADMIN_PRIVATE_KEY'); // Shows "[X chars] ***"
  secureEnvLog('NEXT_PUBLIC_PRIVY_APP_ID'); // Shows "prefix..."
  secureEnvLog('PRIVY_APP_SECRET'); // Shows "[X chars] ***"
}

// ===============================================
// 3. Address and Transaction Logging
// ===============================================

function logTreasuryOperation(safeAddress: string, txHash: string) {
  // ✅ Safe address logging (shows partial for debugging)
  secureAddressLog('Safe Address', safeAddress); // 0x1234...5678

  // ✅ Safe transaction hash logging
  secureTxHashLog('Transaction Hash', txHash); // 0x1234567890...abcdef

  // ✅ Using logger instance
  treasuryLogger.address('Treasury Safe', safeAddress);
  treasuryLogger.txHash('Execution TX', txHash);
}

// ===============================================
// 4. Object Sanitization Examples
// ===============================================

function logUserAction(userData: any, apiResponse: any) {
  // ✅ Automatic sanitization of sensitive properties
  const safeUserData = sanitizeObject(userData);
  console.log('User action:', safeUserData);

  // Example of what gets sanitized:
  const testData = {
    userId: '12345',
    email: 'user@example.com',
    apiKey: 'secret_key_12345', // → '[REDACTED]'
    password: 'user_password', // → '[REDACTED]'
    privateKey: '0xabcd...', // → '[REDACTED]'
    publicValue: 'safe_to_log', // → 'safe_to_log'
    nested: {
      secret: 'hidden_value', // → '[REDACTED]'
      safe: 'visible_value', // → 'visible_value'
    },
  };

  console.log('Sanitized data:', sanitizeObject(testData));
}

// ===============================================
// 5. Development vs Production Logging
// ===============================================

function developmentDebugging() {
  // ✅ Development-only logging (completely removed in production)
  devLog('Debug info for development only', {
    detailedState: 'This will not appear in production logs',
  });

  // ✅ Conditional detailed logging
  if (process.env.NODE_ENV !== 'production') {
    secureLog('Development debug info', {
      complexState: 'Safe to log in development',
    });
  }
}

// ===============================================
// 6. Error Handling Examples
// ===============================================

async function safeErrorHandling() {
  try {
    // Some API call or operation
    await fetch('/api/treasury/execute');
  } catch (error) {
    // ✅ Safe error logging with context
    secureError('API call failed', error, {
      endpoint: '/api/treasury/execute',
      timestamp: Date.now(),
      userId: 'user_123',
    });

    // ✅ Format error for custom handling
    const safeError = formatErrorForLogging(error);
    console.log('Formatted error:', safeError);
  }
}

// ===============================================
// 7. Configuration Validation Examples
// ===============================================

function validateTreasuryConfig() {
  console.log('🔧 Treasury Configuration Validation');
  console.log('===================================');

  // ✅ Safe configuration checking
  const requiredVars = [
    'NEXT_PUBLIC_SAFE_SERVICE_URL',
    'NEXT_PUBLIC_BASE_SEPOLIA_RPC_URL',
    'SAFE_DEPLOYER_PRIVATE_KEY',
    'NEXT_PUBLIC_GELATO_API_KEY',
  ];

  requiredVars.forEach((varName) => {
    const value = process.env[varName];
    if (value) {
      if (varName.includes('PRIVATE_KEY') || varName.includes('SECRET')) {
        console.log(`✅ ${varName}: [${value.length} characters] Configured`);
      } else if (varName.includes('API_KEY')) {
        console.log(`✅ ${varName}: Configured`);
      } else {
        // Public values can be shown safely
        console.log(`✅ ${varName}: ${value}`);
      }
    } else {
      console.log(`❌ ${varName}: Not configured`);
    }
  });
}

// ===============================================
// 8. Service Integration Examples
// ===============================================

class SecureTreasuryService {
  private logger = createSecureLogger('TreasuryService');

  async createSafe(owners: string[], threshold: number) {
    this.logger.log('Creating Safe treasury', {
      ownerCount: owners.length,
      threshold,
    });

    try {
      // Safe creation logic...
      const safeAddress = '0x1234567890123456789012345678901234567890';

      this.logger.address('Safe created', safeAddress);
      this.logger.log('Safe creation successful', {
        ownerCount: owners.length,
        threshold,
        timestamp: Date.now(),
      });

      return safeAddress;
    } catch (error) {
      this.logger.error('Safe creation failed', error, {
        ownerCount: owners.length,
        threshold,
      });
      throw error;
    }
  }

  async executeTreasuryTransaction(txData: any) {
    this.logger.log('Executing treasury transaction', {
      operation: txData.operation,
      hasValue: !!txData.value,
    });

    // Transaction execution logic with secure logging...
  }
}

// ===============================================
// 9. Testing and Debugging Examples
// ===============================================

function testSecureLogging() {
  console.log('🧪 Testing Secure Logging Utilities');
  console.log('===================================');

  // Test sensitive data redaction
  const testStrings = [
    'Private key: 0x1234567890123456789012345678901234567890123456789012345678901234',
    'API Key: sk_test_1234567890abcdef',
    'Bearer token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
    'Safe string: This should not be redacted',
  ];

  testStrings.forEach((str) => {
    console.log('Input:', str.substring(0, 50) + '...');
    secureLog('Secure output:', str);
    console.log('---');
  });
}

// ===============================================
// 10. Migration Examples (Before/After)
// ===============================================

// ❌ BEFORE: Unsafe logging
function unsafeLoggingExample() {
  const privateKey = process.env.PRIVATE_KEY;
  const apiKey = process.env.API_KEY;

  // These patterns are now eliminated:
  // console.log('Private key:', privateKey.substring(0, 10) + '...')
  // console.log('API key:', apiKey)
  // console.log('Config:', { privateKey, apiKey })
}

// ✅ AFTER: Secure logging
function safeLoggingExample() {
  const privateKey = process.env.PRIVATE_KEY;
  const apiKey = process.env.API_KEY;

  // Safe alternatives:
  secureEnvLog('PRIVATE_KEY'); // Shows "[64 chars] ***"
  secureEnvLog('API_KEY'); // Shows "sk_test***"

  console.log('Config status:', {
    hasPrivateKey: !!privateKey,
    hasApiKey: !!apiKey,
    keysConfigured: !!(privateKey && apiKey),
  });
}

export {
  treasuryLogger,
  checkConfiguration,
  logTreasuryOperation,
  SecureTreasuryService,
  testSecureLogging,
};
