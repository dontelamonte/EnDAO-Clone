# EnDAO MVP Security Guide

## Purpose

Comprehensive security guide for EnDAO MVP covering secret management, credential rotation, production hardening, secure logging practices, and transaction simulation. This consolidated document provides all essential security information in one authoritative location.

## Last Updated

October 4, 2025

---

## Table of Contents

1. [Secret Management & Protection](#secret-management--protection)
2. [Credential Rotation Requirements](#credential-rotation-requirements)
3. [Production Security Audit](#production-security-audit)
4. [Secure Logging Guidelines](#secure-logging-guidelines)
5. [Transaction Simulation](#transaction-simulation)
6. [Timing Attack Protection](#timing-attack-protection)
7. [Security Best Practices](#security-best-practices)

---

## Secret Management & Protection

### Automatic Secret Scanning

Your repository is protected with **automatic secret scanning** that runs before every commit.

#### What Gets Scanned

- ✅ **Privy secrets**: `PRIVY_APP_SECRET=...`
- ✅ **Redis credentials**: `REDIS_URL=redis://...`
- ✅ **Supabase keys**: `SUPABASE_SERVICE_ROLE_KEY=...`
- ✅ **API keys**: `API_KEY=...`, `SECRET_KEY=...`
- ✅ **Passwords**: Any password-like patterns
- ✅ **Private keys**: Cryptographic keys
- ✅ **GitHub tokens**: `ghp_...`
- ✅ **OpenAI keys**: `sk-...`

#### How It Works

**Before every commit**, the hook will:

1. Scan all staged files for secret patterns
2. **BLOCK the commit** if secrets are found
3. Show you which file contains the secret
4. Guide you to fix it properly

### Correct Way to Handle Secrets

**Step 1**: Store secrets in `.env.local` (NEVER committed)

```bash
# .env.local (local development only, in .gitignore)
PRIVY_APP_SECRET=<secret-from-privy-dashboard>
REDIS_URL=<redis-connection-string-from-upstash>
```

**Step 2**: Use examples in `.env.local.example` (safe to commit)

```bash
# .env.local.example (committed, pattern for team)
PRIVY_APP_SECRET=your_privy_app_secret_here
REDIS_URL=redis://localhost:6379
```

**Step 3**: Use environment variables in Vercel/production

```bash
# Vercel Dashboard → Settings → Environment Variables
PRIVY_APP_SECRET=<actual-secret>
REDIS_URL=<actual-url>
```

### NEVER Share Secrets In

- ❌ Chat messages (Slack, Discord, Claude Code chat)
- ❌ Email or direct messages
- ❌ Screenshots or screen recordings
- ❌ Git commits or pull requests
- ❌ Documentation files
- ❌ Code comments
- ❌ Issue trackers or bug reports

### If You Accidentally Commit a Secret

**Immediate Actions**:

1. **DO NOT** try to remove it from git history (breaks everyone's clones)
2. **Rotate the secret immediately** (generate new one, revoke old)
3. Update all environments with new secret
4. Document in credential rotation tracking

**Long-term**:

- The secret is permanently in git history
- Anyone with repo access can see it
- Best practice: Always rotate exposed secrets

---

## Credential Rotation Requirements

### Current Status

**Priority**: P1 (rotate within 1 week)
**Date Identified**: October 4, 2025

### Required Actions

#### 1. Rotate Privy App Secret (Priority: P1)

**Timeline**: Within 1 week

**Steps**:

1. Go to [Privy Dashboard](https://dashboard.privy.io)
2. Navigate to your app settings
3. Generate new App Secret
4. Update in production environment variables:
   - Vercel production environment
   - `.env.local` (local development)
5. Test authentication flow works with new secret
6. Revoke old secret in Privy dashboard

#### 2. Rotate Redis Credentials (Priority: P1)

**Timeline**: Within 1 week

**Steps**:

1. Go to [Upstash Console](https://console.upstash.com)
2. Navigate to your Redis database
3. Reset password or create new database
4. Update `REDIS_URL` in production environment variables:
   - Vercel production environment
   - `.env.local` (local development)
5. Test Redis connection works
6. Delete old database (if created new one)

### Rotation Checklist

- [ ] **Privy App Secret**
  - [ ] Generate new secret in Privy dashboard
  - [ ] Update Vercel production environment variable
  - [ ] Update local `.env.local`
  - [ ] Test authentication flow
  - [ ] Revoke old secret

- [ ] **Redis Credentials**
  - [ ] Reset password or create new database
  - [ ] Update Vercel production environment variable
  - [ ] Update local `.env.local`
  - [ ] Test Redis connection
  - [ ] Delete old database (if applicable)

- [ ] **Verification**
  - [ ] Production app still works after rotation
  - [ ] All team members have updated local `.env.local`
  - [ ] No authentication errors in production logs
  - [ ] Redis cache working correctly

### When to Rotate

- ✅ Secret found in git history (P1)
- ✅ Secret exposed publicly (P0 - immediate)
- ✅ Team member leaves (P1)
- ✅ Routine rotation (P2 - every 90 days)

---

## Production Security Audit

### Overall Security Posture: MEDIUM RISK (Improved)

**Updated Risk Score**: 6.5/10 (Medium)

- Security: 7/10 (Good)
- Architecture: 8/10 (Good)
- Web3 Integration: 7.5/10 (Good - simulation added)
- Reliability: 7/10 (Good)
- Observability: 5/10 (Needs Work)

### Critical Findings & Status

#### 1. SECRET EXPOSURE ✅ Mitigated

**Status**: Pre-commit hooks active, rotation in progress
**Action**: See [Credential Rotation Requirements](#credential-rotation-requirements)

#### 2. BUILD VALIDATION DISABLED 🟠 In Progress

**Status**: Gradual re-enablement recommended
**Action**: Enable TypeScript/ESLint checks incrementally

#### 3. CONTENT SECURITY POLICY 🟠 Requires Update

**Status**: CSP in report-only mode with `unsafe-eval`
**Action**: Implement nonce-based CSP with Privy integration

#### 4. TRANSACTION SIMULATION ✅ Implemented

**Status**: Complete pre-flight validation active
**Details**: See [Transaction Simulation](#transaction-simulation)

### Strengths

1. ✅ Excellent CSRF Protection
2. ✅ Timing Attack Protection
3. ✅ Comprehensive Supabase Row Level Security (RLS) Policies
4. ✅ Granular Rate Limiting
5. ✅ Multi-sig Treasury with Gnosis Safe
6. ✅ Treasury Protection System (4-layer security)
7. ✅ Privy Wallet Authentication
8. ✅ Transaction Simulation (NEW)

### Recommended Actions

**Week 1: Critical Fixes** (10-20 hours)

- [ ] Rotate credentials (if repo was ever public)
- [ ] Enable TypeScript checks (gradual rollout)
- [ ] Test transaction simulation thoroughly
- [ ] Begin Sentry setup for observability

**Week 2: Validation & Hardening** (15-25 hours)

- [ ] Security regression testing
- [ ] CSP enforcement with nonce support
- [ ] OWASP Top 10 validation
- [ ] Final security review

---

## Secure Logging Guidelines

### Critical Security Rules

#### Never Log These Items

1. **Private Keys** - Never log full or partial private keys

   ```javascript
   // ❌ NEVER DO THIS
   console.log('Using private key:', privateKey.substring(0, 10));

   // ✅ CORRECT
   console.log('Private key configured:', !!privateKey);
   ```

2. **API Keys & Secrets** - Never expose API keys, tokens, or secrets

   ```javascript
   // ❌ NEVER DO THIS
   console.log('API Key:', apiKey);

   // ✅ CORRECT
   console.log('API Key configured:', !!apiKey);
   console.log('Token length:', token.length, 'characters');
   ```

3. **JWT Tokens** - Never log authentication or authorization tokens
4. **User Credentials** - Never log passwords, PINs, or user secrets

### Secure Logging Utilities

#### Import and Use Secure Logging

```typescript
import {
  secureLog,
  secureError,
  secureEnvLog,
  secureAddressLog,
  createSecureLogger,
} from '@/lib/utils/secure-logging';

// Create a logger for your component/service
const logger = createSecureLogger('TreasuryService');
```

#### Environment Variable Logging

```typescript
// ✅ Safe environment variable logging
secureEnvLog('NEXT_PUBLIC_SUPABASE_URL'); // Shows value (public)
secureEnvLog('SUPABASE_SERVICE_ROLE_KEY'); // Shows existence only
secureEnvLog('API_KEY'); // Shows partial value
```

#### Address and Transaction Hash Logging

```typescript
// ✅ Safe address logging
secureAddressLog('Safe Address', safeAddress); // Shows: 0x1234...5678

// ✅ Safe transaction hash logging
logger.txHash('Transaction Hash', txHash); // Shows: 0x1234567890...abcdef
```

#### Error Logging

```typescript
try {
  // Some operation
} catch (error) {
  // ✅ Safe error logging
  secureError('Operation failed', error, {
    operation: 'createTreasury',
    userId: 'user123',
  });

  // ✅ Using logger service (automatically sanitizes)
  logger.error('Treasury creation failed', error, { daoId });
}
```

### Development Best Practices

#### 1. Use Logger Service for Structured Logging

```typescript
import { logger } from '@/lib/services/logger.service';

// Automatically sanitizes sensitive data
logger.info('User action completed', {
  action: 'createProposal',
  userId: user.id,
  proposalId: proposal.id,
});
```

#### 2. Development vs Production Logging

```typescript
import { isDetailedLoggingAllowed, devLog } from '@/lib/utils/secure-logging';

// Development-only logging (completely removed in production)
devLog('Debug info:', debugData);
```

#### 3. Safe Object Logging

```typescript
import { sanitizeObject } from '@/lib/utils/secure-logging';

// Automatically redacts sensitive properties
const safeConfig = sanitizeObject({
  apiKey: 'secret123', // → '[REDACTED]'
  publicValue: 'safe', // → 'safe'
  nested: {
    password: 'hidden', // → '[REDACTED]'
    safe: 'visible', // → 'visible'
  },
});

console.log('Config:', safeConfig);
```

### Common Mistakes to Avoid

#### 1. Partial Key Exposure

```javascript
// ❌ Still exposes sensitive data
console.log('Key preview:', key.substring(0, 8) + '...');

// ✅ No exposure
console.log('Key configured:', !!key);
```

#### 2. Error Stack Traces in Production

```javascript
// ❌ Exposes internal paths and sensitive info
console.error('Error:', error.stack);

// ✅ Sanitized error logging
import { formatErrorForLogging } from '@/lib/utils/secure-logging';
console.error('Error:', formatErrorForLogging(error));
```

#### 3. Logging Request/Response Data

```javascript
// ❌ May contain sensitive headers or body data
console.log('API Response:', response);

// ✅ Log safe metadata only
console.log('API Response:', {
  status: response.status,
  success: response.ok,
  timestamp: new Date().toISOString(),
});
```

---

## Transaction Simulation

### Overview

Pre-flight transaction validation prevents failed Safe transactions, wasted gas, and financial loss when moving to mainnet.

**Status**: ✅ Implemented (October 4, 2025)

### Features

1. **Balance Validation**: Checks Safe has sufficient ETH before attempting transfer
2. **Blacklist Protection**: Blocks transfers to burn addresses (0x0, 0xdead)
3. **Contract Detection**: Warns if recipient is a smart contract
4. **Transaction Simulation**: Uses `provider.call()` to test transaction will succeed
5. **Gas Estimation**: Estimates gas cost and warns if unusually high (>500k gas)
6. **Maximum Value Limits**: Warns for large transfers (>100 ETH)

### Integration

The simulation runs **automatically** before every transaction creation:

```typescript
// Simulation runs first
const transaction = await createTransaction(safeAddress, recipient, amount);
// ✅ Simulation passes → transaction created
// ❌ Simulation fails → error returned, no transaction created
```

### Safety Checks

#### Check 1: Sufficient Balance

```typescript
safeBalance < transferValue
→ "Insufficient balance. Safe has 0.5 ETH, trying to send 1 ETH"
```

#### Check 2: Blacklist Validation

```typescript
to === '0x0000000000000000000000000000000000000000'
→ "Recipient address is blacklisted (burn address)"
```

#### Check 3: Contract Warning

```typescript
await provider.getCode(to) !== '0x'
→ Warning: "Recipient is a smart contract - verify this is intended"
```

#### Check 4: Transaction Simulation

```typescript
await provider.call({ to, value, from: safeAddress })
→ Tests transaction execution without sending it
```

#### Check 5: Gas Estimation

```typescript
gasEstimate > 500,000
→ Warning: "High gas estimate: 750000 units"
```

#### Check 6: Large Transfer Warning

```typescript
transferValue > parseEther('100')
→ Warning: "Large transfer: 150 ETH exceeds recommended maximum of 100 ETH"
```

### Response Format

```typescript
{
  success: boolean,
  warnings: string[],       // Non-blocking warnings
  gasEstimate?: bigint,     // Estimated gas cost
  error?: string            // Blocking error
}
```

### Benefits

#### Testnet (Base Sepolia)

- ✅ Prevents wasted time from failed transactions
- ✅ Better UX (clear error messages before execution)
- ✅ Debugging aid (see exactly why transaction would fail)

#### Mainnet (Real Chain)

- ✅ **Prevents financial loss** from failed transactions ($50-500 in wasted gas)
- ✅ **Protects against scams** (blacklist validation)
- ✅ **Early detection** of insufficient funds or contract issues
- ✅ **User confidence** (know transaction will succeed before executing)

---

## Timing Attack Protection

Timing attacks exploit measurable differences in response times to infer sensitive information (e.g., valid usernames, admin status). EnDAO implements consistent timing protection on all authentication-related routes.

### When to Use Timing Protection

Use timing protection for any route that:

- Checks user credentials or tokens
- Validates user existence
- Performs authentication/authorization checks
- Returns different responses based on sensitive conditions

**Examples**:

- ✅ `/api/auth/verify` - Token validation
- ✅ `/api/auth/profile` - User lookup
- ✅ `/api/admin/check` - Admin status check
- ❌ `/api/dao/[id]/stats` - Public read-only data

### Basic Pattern

```typescript
import {
  enforceMinimumTiming,
  TIMING_DELAYS,
} from '@/lib/security/timing-protection';

export async function POST(request: NextRequest) {
  const startTime = Date.now(); // 1. Capture start time

  try {
    const result = await authenticateUser(request);

    if (!result.success) {
      // 2. Failed auth: use 2x delay
      await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 3. Successful auth: use base delay
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_SUCCESS, startTime);
    return NextResponse.json({ success: true });
  } catch (error) {
    // 4. Error path: use failure delay
    await enforceMinimumTiming(TIMING_DELAYS.AUTH_FAILURE, startTime);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
```

### Timing Constants

| Operation       | Delay                  | Reason                       |
| --------------- | ---------------------- | ---------------------------- |
| Successful auth | `AUTH_SUCCESS` (100ms) | Base delay                   |
| Failed auth     | `AUTH_FAILURE` (200ms) | 2x delay to slow brute force |
| User lookup     | `USER_LOOKUP` (150ms)  | Same for found/not found     |
| Admin check     | `ADMIN_CHECK` (100ms)  | Same for yes/no              |

### Security Checklist

Before deploying an auth-related route:

- [ ] Start time captured at function entry
- [ ] Timing protection on success path
- [ ] Timing protection on all failure paths
- [ ] Timing protection on error/exception path
- [ ] Consistent timing for different failure modes
- [ ] No early returns without timing protection

### Implementation Reference

- **Utility**: `/src/lib/security/timing-protection.ts`
- **Middleware**: `/src/middleware.ts`
- **Example Routes**: `/src/app/api/auth/verify/route.ts`, `/src/app/api/admin/check/route.ts`

---

## Security Best Practices

### Development Workflow

1. **Use environment variables** for all secrets
2. **Never hardcode** credentials in source code
3. **Template files** (`.example`) should only have examples
4. **Rotate secrets** if they appear in git history
5. **Share secrets securely** via password managers (1Password, LastPass)
6. **Review PRs** for accidental secret exposure

### Team Onboarding Checklist

When adding new team members:

- [ ] Share `.env.local.example`
- [ ] Securely share actual secrets (use password manager)
- [ ] Verify they have `.env.local` configured
- [ ] Educate about never committing secrets
- [ ] Show them this security guide

### Monitoring and Alerts

#### Log Security Monitoring

Set up alerts for:

- Log entries containing patterns like `0x[a-fA-F0-9]{64}` (private keys)
- Log entries with `password`, `secret`, `key` followed by values
- Unusual error patterns that might indicate data exposure

#### Regular Security Audits

Monthly reviews should include:

- Search for sensitive data patterns in logs
- Review new logging code for security compliance
- Verify secure logging utilities are being used
- Check for accidental credential exposure in git history

### Compliance and Standards

#### Security Standards Met

- ✅ **OWASP Logging Guidelines**: Comprehensive compliance
- ✅ **Data Protection**: No PII or sensitive data exposure
- ✅ **Production Security**: All logs production-safe
- ✅ **Development Security**: Secure development practices

#### Regular Reviews

- **Security Audit**: Quarterly comprehensive review
- **Credential Rotation**: Every 90 days or after security incident
- **Documentation Update**: After each security improvement
- **Team Training**: Ongoing security awareness

---

## Additional Resources

- [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html)
- [Gnosis Safe Documentation](https://docs.safe.global/)
- [Base Network Security](https://docs.base.org/)
- [Privy Security Best Practices](https://docs.privy.io/)

---

**Last Updated**: December 18, 2025
**Next Security Review**: March 18, 2026
**Maintained By**: Security Team
