# EnDAO Load Testing Plan

> **STATUS: DRAFT - NOT YET IMPLEMENTED**
>
> This is a planning document. The load testing infrastructure described here has not been implemented. Do not attempt to run these tests without first completing the setup checklist in the Implementation Plan section.

**Status**: Draft for Review
**Created**: December 18, 2024
**Purpose**: Comprehensive load testing suite to identify performance bottlenecks, race conditions, and system breaking points

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Environment Strategy](#environment-strategy) ⭐ NEW
3. [Research Findings & Best Practices](#research-findings--best-practices)
4. [Test Infrastructure](#test-infrastructure)
5. [Test Data Strategy](#test-data-strategy)
6. [Test Scenarios](#test-scenarios)
7. [Success Criteria & Thresholds](#success-criteria--thresholds)
8. [Implementation Plan](#implementation-plan)
9. [Risks & Considerations](#risks--considerations)
10. [Questions for Review](#questions-for-review)

---

## Executive Summary

### Goal

Create a realistic load testing suite that simulates real-world user traffic across multiple DAOs to identify:

- Performance bottlenecks
- Race conditions (especially in voting and treasury operations)
- Database connection pool exhaustion
- Notification system overload
- Audit logging performance under stress

### Approach

User journey-based testing that simulates complete flows rather than isolated API calls. This provides:

- More realistic stress patterns
- Discovery of issues in the flow between operations
- Results that directly map to user experience

### Tool

**k6** (already set up in `tests/load/`) - chosen because:

- JavaScript-based (familiar to team)
- Excellent for API load testing
- Built-in metrics, thresholds, and checks
- Can simulate complex user journeys
- Good documentation and community support

---

## Environment Strategy

### Why Not Vercel Preview Deployments for Load Testing

Vercel preview deployments (the random URLs like `endao-git-feature-xyz-team.vercel.app`) are **NOT suitable** for heavy load testing:

| Issue                     | Impact                                                                            |
| ------------------------- | --------------------------------------------------------------------------------- |
| **Shared infrastructure** | Preview deployments run on shared resources, not representative of production     |
| **Rate limiting**         | Vercel will throttle or flag your account for hammering preview URLs with 500 VUs |
| **Cost**                  | Function invocations are billed; load tests could generate significant costs      |
| **Dynamic URLs**          | URLs change per commit, complicating automation                                   |
| **Not production-like**   | Different scaling behavior than production deployments                            |

**Verdict**: Use preview deployments for functional E2E tests only (5-10 VUs max), not stress testing.

---

### Recommended: Tiered Testing Approach

| Environment                  | Purpose                                 | When to Use          | Max VUs | Cost   |
| ---------------------------- | --------------------------------------- | -------------------- | ------- | ------ |
| **Local** (`localhost:3000`) | Development, debugging, quick iteration | During development   | 50      | Free   |
| **Preview** (dynamic URL)    | Smoke tests only                        | PR checks (optional) | 10      | Low    |
| **Staging** (stable URL)     | Full load testing, realistic stress     | Before releases      | 500+    | Medium |
| **Production**               | Never for load testing                  | -                    | -       | -      |

---

### Setting Up a Stable Staging Environment

**Decision**: Use a **custom subdomain** (`staging.endao.ai`) with a dedicated `staging` branch.

#### Setup Steps

**Step 1: Create the staging branch**

```bash
# Create and push staging branch
git checkout main
git checkout -b staging
git push -u origin staging
```

**Step 2: Configure subdomain in Vercel**

1. Vercel Dashboard → Your Project → Settings → Domains
2. Click "Add Domain"
3. Enter: `staging.endao.ai`
4. Configure DNS at your domain registrar:
   - Add CNAME record: `staging` → `cname.vercel-dns.com`
5. In Vercel, assign the domain to the `staging` branch (not Production)

**Step 3: Set staging environment variables**

```bash
# Using Vercel CLI (or do via Dashboard)
vercel env add NEXT_PUBLIC_ENV staging --environment preview
vercel env add STAGING_PASSWORD <your-secret-password> --environment preview
vercel env add LOAD_TEST_SECRET <your-k6-bypass-token> --environment preview
# Add staging Supabase credentials (see Database section below)
```

**Result:** `https://staging.endao.ai` - stable URL that deploys when `staging` branch updates

---

### Securing Staging from Public Access

**Problem**: Staging URLs are public by default. We need to:

1. Block random visitors and search engines
2. Allow team members to access via browser
3. Allow k6 load tests to bypass authentication

**Solution**: Custom middleware with Basic Auth + k6 bypass header

#### Middleware Implementation

Add to your existing middleware or create new:

```typescript
// src/middleware.ts - Add staging protection

import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Add this function to your existing middleware
function handleStagingProtection(request: NextRequest): NextResponse | null {
  // Only protect staging environment
  const isStaging = process.env.NEXT_PUBLIC_ENV === 'staging';

  if (!isStaging) {
    return null; // Continue to next middleware
  }

  // Allow k6 load tests with secret header
  const bypassToken = request.headers.get('x-load-test-token');
  if (bypassToken === process.env.LOAD_TEST_SECRET) {
    return null; // Allow through
  }

  // Allow requests with valid basic auth
  const authHeader = request.headers.get('authorization');
  if (authHeader) {
    const expectedAuth =
      'Basic ' +
      Buffer.from(`staging:${process.env.STAGING_PASSWORD}`).toString('base64');

    if (authHeader === expectedAuth) {
      return null; // Allow through
    }
  }

  // Block with basic auth prompt
  return new NextResponse('Staging Environment - Authentication Required', {
    status: 401,
    headers: {
      'WWW-Authenticate': 'Basic realm="EnDAO Staging"',
      'X-Robots-Tag': 'noindex, nofollow', // Prevent search indexing
    },
  });
}

// In your main middleware function, add:
export function middleware(request: NextRequest) {
  // Check staging protection first
  const stagingResponse = handleStagingProtection(request);
  if (stagingResponse) {
    return stagingResponse;
  }

  // ... rest of your existing middleware
}

export const config = {
  matcher: [
    // Protect all routes except static files and health checks
    '/((?!_next/static|_next/image|favicon.ico|api/health).*)',
  ],
};
```

#### Environment Variables for Staging

| Variable           | Value                        | Purpose                        |
| ------------------ | ---------------------------- | ------------------------------ |
| `NEXT_PUBLIC_ENV`  | `staging`                    | Identifies staging environment |
| `STAGING_PASSWORD` | `<generate-secure-password>` | Basic auth password            |
| `LOAD_TEST_SECRET` | `<generate-secure-token>`    | k6 bypass token                |

Generate secure values:

```bash
# Generate random password
openssl rand -base64 24
# Example: K7xM2pL9qR4wN8vB3hJ6

# Generate k6 bypass token
openssl rand -hex 32
# Example: a1b2c3d4e5f6...
```

#### How Access Works

| Accessor            | Method           | Experience                                      |
| ------------------- | ---------------- | ----------------------------------------------- |
| **Browser (team)**  | Basic auth popup | Enter `staging` / `<password>` once per session |
| **k6 load tests**   | Header bypass    | Include `x-load-test-token` header              |
| **Search engines**  | Blocked          | 401 response + noindex header                   |
| **Random visitors** | Blocked          | 401 response, can't guess password              |

#### k6 Configuration for Staging

```javascript
// tests/load/user-journeys/config.js

export const CONFIG = {
  BASE_URL: __ENV.BASE_URL || 'http://localhost:3000',

  // Staging authentication
  LOAD_TEST_SECRET: __ENV.LOAD_TEST_SECRET,

  // ... rest of config
};

// Helper for authenticated requests
export function getDefaultHeaders() {
  const headers = {
    'Content-Type': 'application/json',
  };

  // Add bypass token for staging
  if (CONFIG.LOAD_TEST_SECRET) {
    headers['x-load-test-token'] = CONFIG.LOAD_TEST_SECRET;
  }

  return headers;
}
```

Running tests against staging:

```bash
k6 run -e BASE_URL=https://staging.endao.ai \
       -e LOAD_TEST_SECRET=your-secret-token \
       tests/load/user-journeys/03-voting-rush.js
```

---

### Staging Database Setup

**Decision**: Create a **separate Supabase project** for staging/load testing.

**Why separate database is required:**

- Load tests will create/delete thousands of test records
- Can't risk affecting production data
- Need to test connection pool limits without impacting real users
- Can reset database between test runs

#### Setup Steps

**Step 1: Create Supabase staging project**

```bash
# Using Supabase CLI
supabase projects create endao-staging --org-id <your-org-id>

# Note the project ref from output, e.g.: abcdefghijklmnop
```

**Step 2: Apply migrations to staging**

```bash
# Link to staging project
supabase link --project-ref <staging-project-ref>

# Push all migrations
supabase db push

# Verify tables exist
supabase db dump --schema public
```

**Step 3: Set staging environment variables in Vercel**

```bash
# Get values from Supabase Dashboard → Project Settings → API
vercel env add NEXT_PUBLIC_SUPABASE_URL https://<staging-ref>.supabase.co --environment preview
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY <staging-anon-key> --environment preview
vercel env add SUPABASE_SERVICE_ROLE_KEY <staging-service-key> --environment preview
```

**Step 4: Seed staging with test data**

```bash
# Run seed script against staging
yarn seed -- --env=staging

# Or create load test fixtures (we'll build this)
yarn load-test:setup
```

#### Cost Estimate

| Resource               | Cost           |
| ---------------------- | -------------- |
| Supabase Pro (staging) | ~$25/month     |
| Vercel (same project)  | $0 additional  |
| **Total**              | **~$25/month** |

_Note: Can use Supabase Free tier for staging if you stay under limits (500MB database, 2GB bandwidth). Load tests may exceed this._

---

### CI/CD Integration

Once staging is set up, integrate load tests into your workflow:

```yaml
# .github/workflows/load-tests.yml
name: Load Tests

on:
  # Manual trigger for full load tests
  workflow_dispatch:
    inputs:
      test_type:
        description: 'Test to run'
        required: true
        default: 'full'
        type: choice
        options:
          - smoke
          - voting-rush
          - treasury
          - full

  # Smoke tests on PRs (optional, lightweight)
  pull_request:
    branches: [main]

env:
  STAGING_URL: https://staging.endao.ai # Stable staging subdomain

jobs:
  # Lightweight smoke test for PRs
  smoke-test:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install k6
        run: |
          sudo gpg -k
          sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
          echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
          sudo apt-get update
          sudo apt-get install k6

      - name: Wait for Vercel Preview
        uses: patrickedqvist/wait-for-vercel-preview@v1.3.1
        id: vercel_preview
        with:
          token: ${{ secrets.GITHUB_TOKEN }}
          max_timeout: 300

      - name: Run Smoke Test
        run: |
          k6 run --vus 5 --duration 30s \
            -e BASE_URL=${{ steps.vercel_preview.outputs.url }} \
            tests/load/user-journeys/smoke.js

  # Full load tests (manual trigger only)
  full-load-test:
    if: github.event_name == 'workflow_dispatch'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install k6
        run: |
          sudo gpg -k
          sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
          echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
          sudo apt-get update
          sudo apt-get install k6

      - name: Setup Test Data
        run: yarn load-test:setup
        env:
          BASE_URL: ${{ env.STAGING_URL }}

      - name: Run Load Test
        env:
          LOAD_TEST_SECRET: ${{ secrets.LOAD_TEST_SECRET }}
        run: |
          case "${{ inputs.test_type }}" in
            smoke)
              k6 run -e BASE_URL=${{ env.STAGING_URL }} -e LOAD_TEST_SECRET=$LOAD_TEST_SECRET tests/load/user-journeys/smoke.js
              ;;
            voting-rush)
              k6 run -e BASE_URL=${{ env.STAGING_URL }} -e LOAD_TEST_SECRET=$LOAD_TEST_SECRET tests/load/user-journeys/03-voting-rush.js
              ;;
            treasury)
              k6 run -e BASE_URL=${{ env.STAGING_URL }} -e LOAD_TEST_SECRET=$LOAD_TEST_SECRET tests/load/user-journeys/04-treasury-operations.js
              ;;
            full)
              k6 run -e BASE_URL=${{ env.STAGING_URL }} -e LOAD_TEST_SECRET=$LOAD_TEST_SECRET tests/load/user-journeys/full-stress-test.js
              ;;
          esac

      - name: Cleanup Test Data
        if: always()
        run: yarn load-test:cleanup
        env:
          BASE_URL: ${{ env.STAGING_URL }}

      - name: Upload Results
        uses: actions/upload-artifact@v4
        with:
          name: load-test-results
          path: results/
```

---

### Running Load Tests Manually

```bash
# === LOCAL DEVELOPMENT ===
# Quick iteration, debugging (no auth needed)
k6 run tests/load/user-journeys/03-voting-rush.js
# Uses localhost:3000 by default

# === AGAINST STAGING ===
# Must include LOAD_TEST_SECRET to bypass authentication

# Single test
k6 run -e BASE_URL=https://staging.endao.ai \
       -e LOAD_TEST_SECRET=<your-token> \
       tests/load/user-journeys/03-voting-rush.js

# Full stress test
k6 run -e BASE_URL=https://staging.endao.ai \
       -e LOAD_TEST_SECRET=<your-token> \
       tests/load/user-journeys/full-stress-test.js

# Quick smoke test (lower VUs)
k6 run --vus 10 --duration 1m \
       -e BASE_URL=https://staging.endao.ai \
       -e LOAD_TEST_SECRET=<your-token> \
       tests/load/user-journeys/03-voting-rush.js

# Pro tip: Export the secret to avoid typing it repeatedly
export LOAD_TEST_SECRET=<your-token>
k6 run -e BASE_URL=https://staging.endao.ai \
       -e LOAD_TEST_SECRET=$LOAD_TEST_SECRET \
       tests/load/user-journeys/03-voting-rush.js
```

---

### Setup Checklist

Before running load tests against staging:

- [ ] **Staging Branch & Subdomain**
  - [ ] `staging` branch created from `main`
  - [ ] `staging.endao.ai` configured in Vercel
  - [ ] DNS CNAME record added at domain registrar
  - [ ] Domain verified and assigned to `staging` branch

- [ ] **Staging Protection Middleware**
  - [ ] Middleware code added to `src/middleware.ts`
  - [ ] `NEXT_PUBLIC_ENV=staging` set in Vercel
  - [ ] `STAGING_PASSWORD` set (generate with `openssl rand -base64 24`)
  - [ ] `LOAD_TEST_SECRET` set (generate with `openssl rand -hex 32`)
  - [ ] Browser access tested (basic auth prompt works)
  - [ ] k6 bypass tested (header authentication works)

- [ ] **Staging Supabase Project**
  - [ ] New Supabase project created: `endao-staging`
  - [ ] Migrations applied: `supabase db push`
  - [ ] Environment variables set in Vercel:
    - [ ] `NEXT_PUBLIC_SUPABASE_URL`
    - [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY`
    - [ ] `SUPABASE_SERVICE_ROLE_KEY`
  - [ ] RLS policies verified

- [ ] **GitHub Secrets Configured** (for CI/CD)
  - [ ] `LOAD_TEST_SECRET` - k6 bypass token
  - [ ] `STAGING_URL` - `https://staging.endao.ai`

- [ ] **Local k6 Installed**
  - [ ] `brew install k6` (macOS)
  - [ ] Or: `sudo apt-get install k6` (Linux)
  - [ ] Verify: `k6 version`

---

## Research Findings & Best Practices

### k6 Best Practices (from Grafana/k6 official docs)

| Practice                             | Implementation                                                         |
| ------------------------------------ | ---------------------------------------------------------------------- |
| **Simulate realistic user journeys** | Record actual user interactions, incorporate think time with `sleep()` |
| **Modularize test scripts**          | Break into reusable modules (helpers, config, journey-specific files)  |
| **Use SharedArray for test data**    | Load data once, share across all Virtual Users (VUs) to save memory    |
| **Set clear thresholds**             | Define pass/fail criteria aligned with SLOs                            |
| **Integrate with CI/CD**             | Automate tests to catch regressions early                              |

### Race Condition Detection

From research, k6 can detect race conditions by:

```javascript
// Example: Detecting double-booking race condition
export let options = {
  scenarios: {
    race_condition_test: {
      executor: 'shared-iterations',
      vus: 10, // Multiple users
      iterations: 20, // All trying to book same item
      maxDuration: '30s',
    },
  },
};

// Check: Should succeed once OR reject with proper error
check(response, {
  'booking successful or properly rejected': (r) =>
    r.status === 201 ||
    (r.status === 409 && r.json().error.includes('already voted')),
});
```

**Application to EnDAO:**

- Voting: Multiple users voting on same proposal simultaneously
- Treasury: Multiple signers attempting to sign same transaction
- Member operations: Concurrent role changes to same user

### Supabase/PostgreSQL Considerations

| Consideration                       | Mitigation                                                                          |
| ----------------------------------- | ----------------------------------------------------------------------------------- |
| **Connection pool limits**          | Supavisor handles pooling; test should monitor for "max connections reached" errors |
| **PostgREST API connections**       | Set pool to ~40% of total connections                                               |
| **Transaction mode for serverless** | Supports more clients but no prepared statements                                    |
| **Monitoring**                      | Track connection count, query times, pool exhaustion                                |

**Specific thresholds to watch:**

- Connection pool usage > 80% = warning
- "Max client connections reached" errors = critical failure
- Query response time p95 > 1s = investigate

### Notification System Testing

Your notification system has:

- Queue-based processing
- Circuit breaker pattern
- Rate limiting
- Bulk batching

**Test approach:**

1. **Normal load**: Gradual notification generation
2. **Spike**: Sudden burst (e.g., proposal created → 500 members notified)
3. **Sustained high load**: Test circuit breaker recovery
4. **Queue backlog**: Verify system recovers when queue clears

**Metrics to capture:**

- Queue depth over time
- Circuit breaker state changes
- Rate limit rejections
- Notification delivery latency

### Custom Metrics Pattern

```javascript
import { Counter, Rate, Trend } from 'k6/metrics';

// Custom metrics for EnDAO-specific tracking
const voteAccuracy = new Rate('vote_accuracy');
const voteLatency = new Trend('vote_latency');
const duplicateVotes = new Counter('duplicate_votes');
const treasuryErrors = new Counter('treasury_safety_violations');

// Usage in test
voteAccuracy.add(voteWasRecorded);
voteLatency.add(responseTime);
if (duplicateDetected) duplicateVotes.add(1);
```

---

## Test Infrastructure

### File Structure

```
tests/load/
├── user-journeys/
│   ├── config.js                     # Shared configuration & test data generators
│   ├── helpers.js                    # Reusable API call functions
│   │
│   │  === CORE USER JOURNEYS ===
│   ├── 01-browse-and-join.js         # New user discovery flow
│   ├── 02-proposal-lifecycle.js      # Create proposal → voting → results
│   ├── 03-voting-rush.js             # Voting deadline crunch (HIGH PRIORITY)
│   ├── 04-treasury-operations.js     # Multi-sig transaction stress (CRITICAL)
│   ├── 05-member-management.js       # Bulk invites, role changes
│   │
│   │  === SCALE TESTING ===
│   ├── 06-multi-dao-scale.js         # 100 DAOs operating in parallel
│   │
│   │  === BACKEND STRESS ===
│   ├── 07-notification-storm.js      # Notification queue overload
│   ├── 08-activity-feed-stress.js    # Activity logging under load
│   ├── 09-audit-logging-stress.js    # Audit system stress
│   │
│   │  === COMBINED CHAOS ===
│   └── full-stress-test.js           # All scenarios combined
│
├── README.md                         # How to run & interpret results
└── (existing load tests remain)
```

### config.js Contents

```javascript
// Environment configuration
export const CONFIG = {
  BASE_URL: __ENV.BASE_URL || 'http://localhost:3000',

  // Test scale settings
  SMALL_DAO_SIZE: 10,
  MEDIUM_DAO_SIZE: 50,
  LARGE_DAO_SIZE: 200,
  TOTAL_TEST_DAOS: 100,
  TOTAL_TEST_USERS: 1000,

  // Timing settings (based on best practices)
  THINK_TIME_MIN: 1,    // seconds
  THINK_TIME_MAX: 3,    // seconds
  REQUEST_TIMEOUT: '30s',

  // Thresholds
  P95_RESPONSE_TIME: 500,   // ms
  P99_RESPONSE_TIME: 1000,  // ms
  MAX_ERROR_RATE: 0.01,     // 1%
};

// Test data generators
export function generateTestDAO(index) { ... }
export function generateTestUser(index) { ... }
export function generateTestProposal(daoId) { ... }
```

### helpers.js Contents

```javascript
// Reusable API call wrappers with auth handling
export function authenticatedRequest(method, path, body, authToken) { ... }

// DAO operations
export function browseDAOs(filters) { ... }
export function joinDAO(daoId, userId) { ... }
export function getDAOMembers(daoId) { ... }

// Proposal operations
export function createProposal(daoId, proposalData) { ... }
export function castVote(daoId, proposalId, vote) { ... }
export function getProposalResults(daoId, proposalId) { ... }

// Treasury operations
export function proposeTreasuryTransaction(daoId, txData) { ... }
export function signTransaction(daoId, txId) { ... }

// Notification operations
export function getNotifications(userId) { ... }
export function markNotificationsRead(userId) { ... }

// Activity operations
export function getDAOActivities(daoId) { ... }
```

---

## Test Data Strategy

### Approach: Isolated Load Test Fixtures

**Why isolated fixtures (not existing seed data):**

1. Production seed data is too small
2. Prevents interference with existing test environments
3. Can be reliably recreated for consistent tests
4. No risk of corrupting real data

### Fixture Generation

```javascript
// Pre-test setup will create:

// DAOs (100 total)
dao-load-test-001 through dao-load-test-100
├── Small DAOs (001-030): 5-10 members each
├── Medium DAOs (031-070): 20-50 members each
└── Large DAOs (071-100): 100-200 members each

// Users (1000 total)
load-test-user-001 through load-test-user-1000
├── Distributed across DAOs
├── Various roles (owner, admin, member)
└── Pre-configured auth tokens for testing

// Proposals (500 total, distributed across DAOs)
├── Draft proposals (100)
├── Active/voting proposals (200)
├── Closed proposals (100)
└── Executed proposals (100)

// Treasury transactions (pending signatures)
├── Per DAO with multi-sig requirements
```

### Data Lifecycle

```
┌─────────────────────────────────────────────────────┐
│  BEFORE TEST: yarn load-test:setup              │
│  ├── Creates test DAOs in database                 │
│  ├── Creates test users                            │
│  ├── Creates proposals in various states           │
│  └── Sets up treasury transactions                 │
├─────────────────────────────────────────────────────┤
│  DURING TEST: k6 run ...                           │
│  ├── Uses existing fixtures                        │
│  ├── Creates additional data as part of journeys   │
│  └── Validates consistency                         │
├─────────────────────────────────────────────────────┤
│  AFTER TEST: yarn load-test:cleanup             │
│  ├── Removes all load-test-* data                  │
│  └── Generates test report                         │
└─────────────────────────────────────────────────────┘
```

---

## Test Scenarios

### Test 01: Browse & Join DAO

**Purpose**: Test discovery and onboarding under load

| Phase     | VUs    | Duration | Actions          |
| --------- | ------ | -------- | ---------------- |
| Warm-up   | 0→20   | 30s      | Gradual ramp     |
| Normal    | 20→50  | 2m       | Browse, search   |
| Peak      | 50→100 | 1m       | Join requests    |
| Sustain   | 100    | 3m       | Mixed activity   |
| Cool-down | 100→0  | 30s      | Gradual decrease |

**API Endpoints Tested:**

- `GET /api/discover` - Discovery page
- `GET /api/discover?search=...` - Search
- `GET /api/dao/[id]` - DAO detail
- `POST /api/dao/[id]/join` - Join request

**Custom Metrics:**

- `discovery_load_time` - Time to load discovery page
- `search_latency` - Search response time
- `join_success_rate` - Successful join requests

---

### Test 02: Proposal Lifecycle

**Purpose**: Test proposal creation and interaction flows

| Phase   | VUs  | Duration | Actions           |
| ------- | ---- | -------- | ----------------- |
| Warm-up | 0→25 | 30s      | Authenticate      |
| Create  | 25   | 2m       | Create proposals  |
| Edit    | 25   | 1m       | Edit drafts       |
| Submit  | 25   | 1m       | Submit for voting |
| View    | 50   | 2m       | View proposals    |

**API Endpoints Tested:**

- `POST /api/dao/[id]/proposals` - Create
- `PATCH /api/dao/[id]/proposals/[pid]` - Edit
- `GET /api/dao/[id]/proposals` - List
- `GET /api/dao/[id]/proposals/[pid]` - Detail

**Custom Metrics:**

- `proposal_creation_time` - Time to create proposal
- `draft_save_success` - Draft saves without loss
- `duplicate_proposals` - Detect accidental duplicates

---

### Test 03: Voting Rush ⚠️ HIGH PRIORITY

**Purpose**: Simulate deadline crunch where everyone votes in final hour

**Why this is critical:**

- Race conditions in vote counting
- Database lock contention
- Cache invalidation storms
- Most common production incident scenario

| Phase        | VUs     | Duration | Scenario             |
| ------------ | ------- | -------- | -------------------- |
| Early voters | 0→50    | 1m       | Gradual voting       |
| Steady       | 50      | 2m       | Normal pace          |
| Rush begins  | 50→200  | 30s      | Deadline approaching |
| Peak stress  | 200     | 2m       | Everyone voting      |
| Last second  | 200→500 | 30s      | Final spike          |
| Deadline     | 500     | 30s      | Cutoff behavior      |

**API Endpoints Tested:**

- `GET /api/dao/[id]/proposals/[pid]` - Load proposal
- `POST /api/dao/[id]/proposals/[pid]/vote` - Cast vote
- `GET /api/dao/[id]/proposals/[pid]/results` - Check results

**Custom Metrics:**

- `vote_accuracy` - Votes recorded correctly (CRITICAL)
- `duplicate_votes` - Same user voting twice (should be 0)
- `vote_latency` - Time to record vote
- `result_consistency` - Results match vote count

**Validation Checks:**

```javascript
// After all voting completes, verify:
const totalVotesExpected = uniqueVoters.length;
const totalVotesRecorded = getProposalResults().totalVotes;
check(totalVotesRecorded, {
  'no lost votes': (v) => v === totalVotesExpected,
  'no duplicate votes': (v) => v <= totalVotesExpected,
});
```

---

### Test 04: Treasury Operations 🔒 CRITICAL

**Purpose**: Stress test financial safety under load

**Why this is critical:**

- Financial safety - no double-spending
- Multi-sig coordination under stress
- Grace period enforcement
- Audit trail completeness

| Phase   | VUs | Duration | Scenario              |
| ------- | --- | -------- | --------------------- |
| View    | 10  | 1m       | Treasury dashboard    |
| Propose | 20  | 2m       | Create transactions   |
| Sign    | 30  | 3m       | Multi-sig signing     |
| Execute | 10  | 2m       | Transaction execution |

**API Endpoints Tested:**

- `GET /api/dao/[id]/treasury` - Dashboard
- `POST /api/dao/[id]/treasury/propose` - Propose transaction
- `POST /api/dao/[id]/treasury/sign` - Sign transaction
- `GET /api/dao/[id]/treasury/pending` - Pending approvals

**Custom Metrics:**

- `treasury_safety_violations` - MUST BE 0
- `double_spend_attempts` - Detected and blocked
- `signature_validation` - All signatures valid
- `grace_period_enforced` - Locks respected

**Safety Validation:**

```javascript
// Treasury safety checks
check(response, {
  'no unauthorized transactions': (r) => !r.json().unauthorizedTx,
  'signature requirements met': (r) => r.json().signaturesValid,
  'grace period enforced': (r) => r.json().gracePeriodRespected,
});
```

---

### Test 05: Member Management

**Purpose**: Test bulk admin operations

| Phase       | VUs | Duration | Scenario          |
| ----------- | --- | -------- | ----------------- |
| List        | 10  | 1m       | Load member lists |
| Invite      | 10  | 2m       | Bulk invitations  |
| Role change | 10  | 2m       | Update roles      |
| Remove      | 5   | 1m       | Member removal    |

**API Endpoints Tested:**

- `GET /api/dao/[id]/members` - List members
- `POST /api/dao/[id]/members/invite` - Bulk invite
- `PATCH /api/dao/[id]/members/[uid]/role` - Role change
- `DELETE /api/dao/[id]/members/[uid]` - Remove member

**Custom Metrics:**

- `bulk_operation_atomicity` - Batch operations complete fully
- `permission_check_latency` - Authorization overhead

---

### Test 06: Multi-DAO Scale 🏢 PLATFORM STRESS

**Purpose**: 100 DAOs operating simultaneously

**Architecture:**

```
┌──────────────────────────────────────────────────────────┐
│                    Virtual User Pool (500 VUs)           │
├──────────────────────────────────────────────────────────┤
│  DAOs 1-30:    Small (5-10 members)    → Light activity  │
│  DAOs 31-70:   Medium (20-50 members)  → Normal activity │
│  DAOs 71-100:  Large (100+ members)    → Heavy activity  │
├──────────────────────────────────────────────────────────┤
│  Activity Distribution:                                   │
│  ├── 40% Reading (dashboards, proposals)                 │
│  ├── 30% Voting                                          │
│  ├── 20% Creating content                                │
│  └── 10% Admin operations                                │
└──────────────────────────────────────────────────────────┘
```

| Phase     | VUs     | Duration | Scenario           |
| --------- | ------- | -------- | ------------------ |
| Ramp-up   | 0→500   | 5m       | Gradual user login |
| Sustained | 500     | 10m      | Normal operations  |
| Spike     | 500→800 | 2m       | Traffic spike      |
| Recovery  | 800→500 | 2m       | Spike recovery     |
| Cool-down | 500→0   | 3m       | End of day         |

**Custom Metrics:**

- `cross_dao_isolation` - DAO A's load doesn't affect DAO B
- `shared_resource_contention` - Auth, notifications handle aggregate
- `connection_pool_usage` - Database pool utilization

---

### Test 07: Notification Storm 📬

**Purpose**: Overload notification system

**Scenarios:**

1. **Bulk notification trigger**: Proposal created → notify 500 members
2. **Voting reminders**: All DAOs send reminders simultaneously
3. **Read/mark-read surge**: Users clearing notification backlog

| Phase    | Notifications/sec | Duration | Scenario               |
| -------- | ----------------- | -------- | ---------------------- |
| Normal   | 10                | 2m       | Baseline               |
| Surge    | 100               | 1m       | Proposal notifications |
| Storm    | 500               | 2m       | Mass voting reminders  |
| Recovery | 50                | 2m       | System recovery        |
| Clear    | N/A               | 2m       | Users marking read     |

**API Endpoints Tested:**

- `GET /api/notifications` - Fetch notifications
- `PATCH /api/notifications` - Mark as read
- `POST /api/notifications` (internal) - Create notifications

**Custom Metrics:**

- `notification_queue_depth` - Queue size over time
- `circuit_breaker_trips` - Times circuit breaker opened
- `rate_limit_rejections` - Rate limit enforcement
- `notification_delivery_latency` - Time from create to available

---

### Test 08: Activity Feed Stress 📋

**Purpose**: Test activity logging under heavy write load

| Phase       | VUs | Duration | Scenario                  |
| ----------- | --- | -------- | ------------------------- |
| Read-heavy  | 50  | 2m       | Feed browsing             |
| Write-heavy | 100 | 3m       | Rapid activity generation |
| Mixed       | 100 | 3m       | Realistic mix             |
| Pagination  | 50  | 2m       | Deep pagination           |

**API Endpoints Tested:**

- `GET /api/dao/[id]/activities` - Activity feed
- `GET /api/dao/[id]/activities?days=90` - Extended history

**Custom Metrics:**

- `activity_write_throughput` - Activities logged/second
- `feed_query_latency` - Time to load feed
- `pagination_degradation` - Performance on page 10 vs page 1

---

### Test 09: Audit Logging Stress 📝

**Purpose**: Test audit system under high admin activity

| Phase         | VUs (Admins) | Duration | Scenario              |
| ------------- | ------------ | -------- | --------------------- |
| Baseline      | 5            | 2m       | Normal admin work     |
| High activity | 20           | 3m       | Many admin actions    |
| Query stress  | 10           | 2m       | Audit log queries     |
| Export        | 5            | 2m       | CSV export under load |

**API Endpoints Tested:**

- `GET /api/admin/audit-logs` - Query audit logs
- `GET /api/admin/audit-logs?statsOnly=true` - Statistics
- `POST /api/admin/audit-logs/export` - Export to CSV

**Custom Metrics:**

- `audit_write_latency` - Time to record audit entry
- `audit_query_performance` - Query response times
- `export_completion_time` - Large export duration

---

### Test FULL: Combined Chaos 🔥

**Purpose**: Everything happening at once

**Duration**: 30 minutes

**Combines all scenarios with random distribution:**

```javascript
export let options = {
  scenarios: {
    browse_join: { weight: 15 },
    proposal_lifecycle: { weight: 20 },
    voting_rush: { weight: 25 },
    treasury_ops: { weight: 10 },
    member_mgmt: { weight: 10 },
    notifications: { weight: 10 },
    activity: { weight: 5 },
    audit: { weight: 5 },
  },
};
```

**Purpose:**

- Find issues that only appear when multiple subsystems stressed simultaneously
- Validate system stability under realistic mixed workload
- Test graceful degradation

---

## Success Criteria & Thresholds

### Global Thresholds

```javascript
export let options = {
  thresholds: {
    // Response time thresholds
    http_req_duration: [
      'p(50)<200', // 50% under 200ms
      'p(95)<500', // 95% under 500ms
      'p(99)<1000', // 99% under 1s
    ],

    // Error rate thresholds
    http_req_failed: ['rate<0.01'], // <1% error rate

    // Custom thresholds
    vote_accuracy: ['rate>0.99'], // >99% votes recorded
    duplicate_votes: ['count<1'], // No duplicates
    treasury_safety_violations: ['count<1'], // No safety issues
    notification_delivery_latency: ['p(95)<5000'], // <5s delivery
  },
};
```

### Per-Test Success Criteria

| Test               | PASS Criteria           | FAIL Criteria              |
| ------------------ | ----------------------- | -------------------------- |
| Browse & Join      | p95 < 500ms, <1% errors | p95 > 2s OR >5% errors     |
| Proposal Lifecycle | No data loss, p95 < 1s  | Any duplicate proposals    |
| Voting Rush        | 100% vote accuracy      | ANY lost/duplicate votes   |
| Treasury           | 0 safety violations     | ANY unauthorized tx        |
| Multi-DAO Scale    | <5% cross-DAO impact    | Cascade failures           |
| Notification Storm | Queue recovers in <5m   | Circuit breaker stuck open |
| Activity Stress    | p95 < 1s                | Write backlog > 1000       |
| Audit Logging      | No log loss             | Missing audit entries      |

---

## Implementation Plan

### Phase 1: Foundation (Day 1)

- [ ] Create `config.js` with shared configuration
- [ ] Create `helpers.js` with reusable API wrappers
- [ ] Create test data setup script
- [ ] Create test data cleanup script

### Phase 2: Critical Path Tests (Days 2-3)

- [ ] `03-voting-rush.js` - Highest risk area
- [ ] `04-treasury-operations.js` - Financial safety
- [ ] Validation scripts for race condition detection

### Phase 3: Core Journeys (Days 4-5)

- [ ] `01-browse-and-join.js`
- [ ] `02-proposal-lifecycle.js`
- [ ] `05-member-management.js`

### Phase 4: Scale & Backend (Days 6-7)

- [ ] `06-multi-dao-scale.js`
- [ ] `07-notification-storm.js`
- [ ] `08-activity-feed-stress.js`
- [ ] `09-audit-logging-stress.js`

### Phase 5: Integration & Documentation (Day 8)

- [ ] `full-stress-test.js`
- [ ] `README.md` documentation
- [ ] CI/CD integration guide

### Estimated Total: ~40 hours of development

---

## Risks & Considerations

### Technical Risks

| Risk                                | Mitigation                                                                |
| ----------------------------------- | ------------------------------------------------------------------------- |
| Load test affects production        | Use isolated fixtures, never test against prod                            |
| Local testing gives false positives | Network latency absent locally; test against staging for accurate results |
| Database connection exhaustion      | Monitor Supabase dashboard during tests                                   |
| Test data cleanup fails             | Implement idempotent cleanup, prefix all test data                        |

### Operational Risks

| Risk                            | Mitigation                                        |
| ------------------------------- | ------------------------------------------------- |
| Tests too slow to run regularly | Create "smoke" version with lower VUs for CI      |
| Results hard to interpret       | Generate HTML reports, clear pass/fail thresholds |
| Team unfamiliar with k6         | Comprehensive README, commented code              |

### What These Tests WON'T Catch

1. **Client-side performance** - k6 tests APIs, not browser rendering
2. **Real network conditions** - Local tests don't simulate latency/packet loss
3. **Third-party service failures** - Privy, Gnosis Safe outages
4. **Memory leaks over time** - Requires long-duration soak tests

---

## Questions for Review

### Decisions Made ✅

| Question                     | Decision                                                        |
| ---------------------------- | --------------------------------------------------------------- |
| Where should tests run?      | **Tiered approach**: Local for dev, staging for full load tests |
| Isolated fixtures?           | **Yes** - Create dedicated load test data, not production seed  |
| Full suite or critical only? | **Full suite** - Build all 12 files                             |
| Success criteria reasonable? | **Yes** - Approved as documented                                |
| Staging approach?            | **Custom subdomain**: `staging.endao.ai` with `staging` branch  |
| Staging security?            | **Custom middleware**: Basic auth + k6 bypass header            |
| Staging database?            | **Separate Supabase project** (~$25/mo)                         |

---

### Outstanding Questions ❓

#### Test Data & Cleanup

1. **Should cleanup be automatic** after tests, or manual (to inspect results)?
   - [ ] Automatic - Clean slate for next run
   - [ ] Manual - Review data, then run cleanup command

2. **Any specific user counts** you want to simulate?
   - Current plan: Up to 500 VUs for full stress
   - Adjust based on expected growth projections?

#### Scope

3. **Should we include WebSocket/real-time testing?**
   - More complex to implement
   - Can add later as Phase 2

4. **Any specific scenarios you've seen cause issues** that we should prioritize?

#### Access Control

5. **Who should have the staging password and k6 bypass token?**
   - Store in team password manager?
   - GitHub Secrets for CI?

---

### Implementation Checklist

#### Phase 0: Staging Environment Setup

- [ ] Create `staging` branch from `main`
- [ ] Configure `staging.endao.ai` subdomain in Vercel
- [ ] Add staging protection middleware
- [ ] Create Supabase staging project
- [ ] Apply migrations to staging database
- [ ] Set all staging environment variables
- [ ] Test browser access (basic auth)
- [ ] Test k6 bypass header

#### Phase 1: Build Test Suite

- [ ] `config.js` - Shared configuration
- [ ] `helpers.js` - API wrappers
- [ ] `03-voting-rush.js` - Critical: voting race conditions
- [ ] `04-treasury-operations.js` - Critical: financial safety
- [ ] Remaining 8 test files
- [ ] `README.md` - Documentation

#### Phase 2: CI/CD Integration

- [ ] GitHub Actions workflow
- [ ] Secrets configuration
- [ ] Smoke test on PR (optional)
- [ ] Manual full load test trigger

---

### Next Steps

Ready to proceed with:

1. **Set up staging environment** (Vercel subdomain + Supabase + middleware)
2. **Build all 12 test files**
3. **Create CI/CD workflow**

Let me know when you're ready to start, or if you have answers to the remaining questions!

---

## Appendix: How to Run Tests

### Prerequisites

```bash
# Install k6 (macOS)
brew install k6

# Or via npm (cross-platform)
yarn install -g k6
```

### Basic Usage

```bash
# Run single test
k6 run tests/load/user-journeys/03-voting-rush.js

# Run with custom base URL
k6 run -e BASE_URL=https://staging.endao.ai tests/load/user-journeys/03-voting-rush.js

# Run with lower VUs for quick check
k6 run --vus 10 --duration 1m tests/load/user-journeys/03-voting-rush.js

# Generate JSON output for analysis
k6 run --out json=results.json tests/load/user-journeys/03-voting-rush.js
```

### Full Test Suite

```bash
# Setup test data
yarn load-test:setup

# Run all tests
yarn load-test:full

# Cleanup
yarn load-test:cleanup
```

---

_This plan is ready for review. Please provide feedback on the questions above before implementation begins._
