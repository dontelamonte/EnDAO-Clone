# Manual Testing Plan - Wave 4-6 Features

## Purpose

Comprehensive manual testing checklist for Wave 4-6 features in local development environment before production deployment.

## Last Updated

October 31, 2025

---

## Prerequisites

- ✅ Local dev server running (`yarn dev`)
- ✅ Test data seeded (105 proposals, 5 DAOs, 57 members)
- ✅ Dev auth bypass enabled (`NEXT_PUBLIC_ENABLE_DEV_AUTH=true`)
- ✅ Resend domain verified (mail.endao.ai)
- ✅ Supabase Admin SDK configured

---

## Environment Setup & Testing Tools

### 🌱 Test Data Seeding Script

The seed script (`scripts/seed-test-data.ts`) creates comprehensive test data automatically, saving 15-20 minutes of manual setup.

**Quick Start**:

```bash
# First-time setup OR complete reset
yarn seed:clear

# Add more data without clearing
yarn seed

# Seed only specific types
yarn seed:daos          # Only DAOs
yarn seed:users         # Only users
yarn seed:proposals     # Only proposals
```

**What Gets Created**:

| Collection  | Count | Details                                                                   |
| ----------- | ----- | ------------------------------------------------------------------------- |
| Users       | 15    | `test-user-0` through `test-user-14` with wallets, profiles, roles        |
| DAOs        | 5     | Tech, Creative, Investment, Startup, Legacy DAOs                          |
| DAO Members | 57    | Distributed across DAOs with admin/member roles                           |
| Proposals   | 105   | 30 active, 15 draft, 10 under review, 30 passed, 10 rejected, 15 treasury |
| Votes       | 830   | Distributed across active proposals                                       |
| Comments    | 525   | Top-level and nested replies                                              |
| Activities  | 55    | Recent activities across last 30 days                                     |

**Custom Scenarios**:

```bash
# More test data
yarn seed -- --daos=10 --proposals=50 --users=20

# Specific test scenarios (future)
yarn seed -- --scenario=voting-testing
yarn seed -- --scenario=treasury-testing
```

**When to Reseed**:

- Before starting a new testing session
- After breaking test data during testing
- When you need a clean state
- Before testing specific scenarios

---

### 🔑 Dev Auth Bypass System

Instantly switch between test users **without Privy wallet connection**. Only works on localhost with `NEXT_PUBLIC_ENABLE_DEV_AUTH=true`.

**How to Use**:

1. Open http://localhost:3000
2. Look for "⚠️ DEV MODE" badge in top-left corner
3. Click to expand dev auth toolbar
4. Select any test user from the list
5. Page reloads with new user authenticated

**Available Test Users**:

- `test-user-0` - Alice Smith (`alice0@test.endao.local`)
- `test-user-1` - Bob Johnson (`bob1@test.endao.local`)
- `test-user-2` - Carol Williams (`carol2@test.endao.local`)
- ... through `test-user-14`

**Role Switching**:

Each user has different roles across different DAOs. Use the dev toolbar to:

- Test admin features (users with admin role)
- Test member features (users with member role)
- Test non-member views (users not in specific DAOs)
- Test treasury signer features (users configured as Safe owners)

**Quick Testing Workflow**:

```
1. Start as test-user-0 (admin in Tech DAO)
2. Create proposal
3. Switch to test-user-1 (member) → vote on proposal
4. Switch to test-user-2 (member) → vote on proposal
5. Switch back to test-user-0 → finalize proposal
6. Test notifications for each user
```

---

### 🧪 Other Testing Utilities

**Architecture Checks** (run before committing):

```bash
yarn check:files        # File size validation
yarn check:complexity   # Code complexity analysis
yarn analyze           # Full architecture report
```

**Test Suite**:

```bash
yarn test                   # Run all tests (82 tests)
yarn test -- --watch       # Watch mode for active development
```

**Database Scripts**:

```bash
# View all test DAOs
node scripts/find-daos.js

# Check specific proposal
node scripts/check-proposals.js

# View test users
# (Use Supabase Dashboard → Table Editor → users table)
```

**Supabase Dashboard Access**:

- View seeded data: https://app.supabase.com
- Navigate to Table Editor
- Tables: `users`, `daos`, `proposals`, `votes`, `comments`, `activities`
- Look for records with `test-` prefix

---

### 🔄 Testing Workflow

**Standard Testing Session**:

```bash
# 1. Clear and reseed data
yarn seed:clear

# 2. Start dev server (if not already running)
yarn dev

# 3. Open browser
# http://localhost:3000

# 4. Use dev auth to become test user
# Click "⚠️ DEV MODE" → Select user

# 5. Run through test scenarios
# Use checklist below

# 6. Reset data between major test scenarios
yarn seed:clear
```

**Quick Reset Between Tests**:

```bash
# Option 1: Reseed everything
yarn seed:clear

# Option 2: Manual cleanup in Supabase Dashboard
# Delete specific test data and reseed only what you need
yarn seed:proposals  # Just proposals
```

---

## Wave 4: Voting Experience & Treasury Signing

### Test 1: Vote Eligibility Badge System (6 States)

**Path**: Any DAO → Proposals → View proposal cards/details

**Test Cases**:

- [ ] **Eligible** - Member viewing active proposal
  - Expected: Green badge "You can vote"
  - User: test-user-0 (member)
  - Proposal: Active proposal in Tech DAO

- [ ] **Voting Ended** - Finalized or expired proposal
  - Expected: Gray badge "Voting ended"
  - Proposal: Any finalized/expired proposal

- [ ] **Already Voted** - After casting a vote (with `allowChangeVote=false`)
  - Expected: Blue badge "Already voted"
  - Steps: Cast vote → verify badge changes

- [ ] **Not a Member** - Non-member viewing proposal
  - Expected: Red badge "Not a member"
  - User: test-user-14 (non-member)

- [ ] **Under Review** - Warm-up period active
  - Expected: Yellow badge "Under review"
  - Proposal: Any proposal in warm-up period

- [ ] **Draft** - Proposal not yet active
  - Expected: Gray badge "Draft"
  - Proposal: Any draft proposal

**Allow Change Vote Toggle**:

- [ ] With toggle OFF: Badge shows "Already voted" after voting (permanent)
- [ ] With toggle ON: Badge shows "You can vote" even after voting (can change)

**Pass Criteria**: All 6 badge states display correctly with accurate eligibility logic

---

### Test 2: Finalization Notifications (4 Channels)

**Path**: Create proposal → Wait for finalization (or manually finalize)

**Test Cases**:

- [ ] **Toast Notification** - Real-time popup when proposal finalizes
  - Expected: Toast appears immediately with status (Passed/Rejected/Expired)
  - Trigger: Finalize any active proposal

- [ ] **In-App Notification** - Bell icon notification
  - Expected: Bell icon shows badge count
  - Click bell → See finalization notification

- [ ] **Activity Feed** - Activity tab shows event
  - Expected: Activity tab shows "Proposal finalized" entry
  - Path: DAO → Activity tab

- [ ] **Email Notification** (🆕 Resend Domain Verified)
  - Expected: Email sent to proposal creator and voters
  - Check: Real email inbox for `noreply@mail.endao.ai`
  - Verify: HTML template formatting, status (passed/rejected/expired)

**Email Test Scenarios**:

- [ ] **Passed Proposal Email**
  - Create proposal → Pass it → Check email
  - Expected: Green success theme, "Proposal Passed" subject

- [ ] **Rejected Proposal Email**
  - Create proposal → Reject it → Check email
  - Expected: Red failure theme, "Proposal Rejected" subject

- [ ] **Expired Proposal Email**
  - Let proposal expire → Check email
  - Expected: Gray neutral theme, "Proposal Expired" subject

**Pass Criteria**: All 4 notification channels fire correctly with proper formatting

---

### Test 3: Treasury Execution Progress Tracking

**Path**: DAO with Safe → Passed funding proposal → View execution status

**Test Cases**:

- [ ] **Multi-sig Progress Display**
  - Expected: See "2 of 3 signatures required" or similar
  - Shows list of signers with status (signed/pending)

- [ ] **Real-time Signature Updates**
  - Sign with one wallet → Status updates immediately
  - Shows checkmark for signed signers

- [ ] **Signer Status Display**
  - Expected: Each signer shows name, wallet address, status
  - Different colors for signed (green) vs pending (gray)

- [ ] **Execution Button**
  - Expected: Disabled until threshold met
  - Enabled when signatures >= threshold

**Pass Criteria**: Clear visibility into multi-sig status and progress

---

### Test 4: In-App Treasury Signing 🔥 CRITICAL

**Path**: DAO with Safe → Passed treasury proposal → Sign button

**Test Cases**:

- [ ] **Sign Button Visibility**
  - Expected: "Sign Transaction" button visible to Safe owners
  - Hidden for non-owners

- [ ] **Treasury Signing Modal - 6 States**
  - [ ] Loading state (spinner)
  - [ ] Ready to sign (primary CTA)
  - [ ] Signing in progress (progress indicator)
  - [ ] Success (green checkmark, confirmation)
  - [ ] Error (red alert, retry button)
  - [ ] Already signed (disabled state, checkmark)

- [ ] **Privy Wallet Integration**
  - Click "Sign Transaction"
  - Privy wallet modal opens
  - Approve signature
  - Signature recorded in database

- [ ] **Safe Protocol Kit Integration**
  - Signature format matches Safe SDK v4
  - Transaction hash generated correctly

- [ ] **Real-time Updates for Other Signers**
  - User A signs → User B sees status update immediately
  - No page refresh needed

- [ ] **Error Handling**
  - Test wallet rejection → Shows error message
  - Test network issues → Shows retry option
  - Test invalid proposal → Shows clear error

**Pass Criteria**: Smooth signing flow with all 6 UI states working, real-time updates, proper error handling

---

## Wave 5: Unified Voting Configuration

### Test 5: VotingConfigBridge Integration

**Path**: Create Proposal → Voting Settings Tab

**Test Cases**:

- [ ] **DAO Defaults Auto-Load**
  - Create new proposal
  - Expected: Voting duration, quorum, approval threshold inherit from DAO settings
  - Verify values match DAO configuration

- [ ] **All Voting Config Fields Present**
  - [ ] Voting duration (hours/days)
  - [ ] Quorum percentage
  - [ ] Approval threshold percentage
  - [ ] Allow change vote toggle
  - [ ] Continuous voting toggle

- [ ] **Form Validation**
  - Try invalid values (negative, >100%)
  - Expected: Clear validation errors

- [ ] **Edit Existing Proposal**
  - Edit proposal → Voting Settings
  - Expected: Current config loads correctly
  - Changes save properly

**Pass Criteria**: Seamless voting config integration with proper defaults and validation

---

### Test 6: Admin Override System 🔥 CRITICAL

**Path**: Edit Proposal (as admin) → Voting Settings Tab

**Test Cases**:

- [ ] **Admin Override Toggle Visibility**
  - Expected: Only visible when editing (not creating)
  - Only visible to admins

- [ ] **Yellow Warning UI**
  - Toggle "Admin Override" switch ON
  - Expected: Yellow warning banner appears
  - Clear messaging about emergency changes

- [ ] **Audit Logging**
  - Toggle override ON
  - Make config changes
  - Save proposal
  - Check console logs for audit entry
  - Verify logged: admin ID, timestamp, changes made

- [ ] **Bypass Normal Restrictions**
  - With override ON: Can change voting config on active proposal
  - Expected: No validation errors for normally restricted changes

- [ ] **Changes Persist**
  - Save with override
  - Reload page
  - Verify changes saved correctly

**Pass Criteria**: Clear warning UI, audit logging active, emergency changes work

---

## Wave 6: Claude Code Skills

### Test 7: Documentation Guardian Skill

**Path**: Create/modify any .md file in docs/

**Test Cases**:

- [ ] **New File in Wrong Location**
  - Try creating .md file in root directory
  - Expected: Skill activates and warns

- [ ] **Missing Required Sections**
  - Create file without `## Purpose` or `## Last Updated`
  - Try to commit
  - Expected: Pre-commit hook blocks with clear error

- [ ] **Placeholder Content Detection**
  - Add "TODO", "FIXME", or "TBD" to doc
  - Try to commit
  - Expected: Hook blocks unless proper context provided

**Pass Criteria**: Skill enforces documentation standards automatically

---

### Test 8: File Size Enforcer Skill

**Path**: Modify any TypeScript/React file >800 lines

**Test Cases**:

- [ ] **File Size Limit**
  - Add content to push file over 800 lines
  - Try to commit
  - Expected: Pre-commit hook blocks with file size error

- [ ] **Refactoring Suggestions**
  - Expected: Error message suggests patterns:
    - Compound components
    - Service orchestration
    - Lazy loading

**Pass Criteria**: Commit blocked for oversized files with helpful suggestions

---

## Critical Path: Full Proposal Lifecycle E2E Test

**Complete end-to-end test covering all Wave 4-6 features**:

### Setup Phase

- [ ] Create DAO with Gnosis Safe treasury
- [ ] Add 2-3 members as Safe owners
- [ ] Configure DAO voting defaults

### Proposal Creation Phase

- [ ] Create funding proposal (treasury type)
- [ ] Verify voting config inherits DAO defaults ✅ (Wave 5)
- [ ] Verify vote eligibility badge shows "Under Review" during warm-up ✅ (Wave 4)

### Voting Phase

- [ ] Wait for warm-up period or skip
- [ ] Badge changes to "Eligible" ✅ (Wave 4)
- [ ] Cast votes from multiple members
- [ ] Verify real-time vote count updates
- [ ] Test `allowChangeVote` toggle behavior ✅ (Wave 4)

### Finalization Phase

- [ ] Proposal passes threshold
- [ ] Auto-finalization occurs (or manual trigger)
- [ ] Verify 4 notification channels fire ✅ (Wave 4):
  - [ ] Toast notification
  - [ ] In-app notification (bell icon)
  - [ ] Activity feed entry
  - [ ] Email notification (check inbox) 🆕

### Treasury Execution Phase

- [ ] View multi-sig progress tracking ✅ (Wave 4)
- [ ] Click "Sign Transaction" as Safe owner
- [ ] Treasury signing modal opens ✅ (Wave 4)
- [ ] Complete Privy wallet signature
- [ ] Verify signature appears in database
- [ ] Real-time signature update for other users ✅ (Wave 4)
- [ ] Repeat for additional signers until threshold met
- [ ] Execute transaction
- [ ] Verify transaction on Base Mainnet

### Admin Override Test

- [ ] Edit active proposal as admin
- [ ] Toggle "Admin Override" ON ✅ (Wave 5)
- [ ] Verify yellow warning appears
- [ ] Change voting config
- [ ] Check console for audit log entry
- [ ] Save changes successfully

---

## Test Environment Details

### Test Accounts (via Dev Auth Bypass)

- `test-user-0` through `test-user-14`
- Emails: `alice0@test.endao.local`, `bob1@test.endao.local`, etc.
- Instant role switching without Privy wallet connection

### Test DAOs (Seeded)

1. **Tech Innovators DAO** - Active DAO for primary testing
2. **Creative Guild DAO** - For multi-DAO scenarios
3. **Investment Collective DAO** - For treasury testing
4. **Startup DAO** - New DAO testing
5. **Legacy DAO** - Large DAO (50 members) for scale testing

### Test Proposals (Seeded)

- **30 Active** - For voting testing
- **15 Draft** - For draft flow testing
- **10 Under Review** - Warm-up period testing
- **30 Passed** - Treasury execution testing
- **10 Rejected** - Notification testing
- **15 Treasury** - For signing flow with Safe data

### Email Testing (Resend)

- **From**: `noreply@mail.endao.ai`
- **Domain**: Verified ✅
- **Templates**: Passed (green), Rejected (red), Expired (gray)
- **Test with**: Real email addresses for proposal creators/voters

---

## Known Issues

- IndexedDB persistence warning (expected in Node.js, falls back to memory)
- Privy secret length warning (false positive - it's correct)
- Test suite: 82/82 passing ✅

---

## Success Criteria

All tests must pass before production deployment:

- ✅ All 6 vote eligibility badge states working
- ✅ All 4 notification channels firing (including email)
- ✅ Treasury signing flow complete with real-time updates
- ✅ VotingConfigBridge integration seamless
- ✅ Admin override system with audit logging
- ✅ Documentation skills enforcing standards
- ✅ Full E2E proposal lifecycle successful
- ✅ Email notifications delivering successfully

---

## Notes

- Use dev auth bypass for instant role switching
- Check browser console for audit logs
- Monitor Network tab for API calls
- Test in both Chrome and Safari
- Verify mobile responsiveness

---

**Next Steps After Testing**:

1. Document any bugs found
2. Fix critical issues
3. Re-test fixes
4. Deploy to Vercel preview
5. Final QA in preview environment
6. Production deployment
