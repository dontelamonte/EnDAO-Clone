# Test Patterns for EnDAO MVP

## Purpose

This document provides test patterns and guidelines for implementing tests for new features.

## Last Updated

October 2025

---

## Test Infrastructure Overview

### Test Types

1. **E2E Tests** (`tests/e2e/`)
   - Full user journey testing with Playwright
   - Cross-browser compatibility (Chrome, Firefox, Safari)
   - Mobile and desktop viewports
   - **Use for**: Complete workflows, critical user paths

2. **UX Tests** (`tests/ux/`)
   - User experience validation with Playwright
   - Performance metrics (load time, interaction latency)
   - Accessibility compliance
   - **Use for**: Feature usability, UX metrics validation

3. **Integration Tests** (`tests/integration/`)
   - API route testing, service integration
   - Supabase/PostgreSQL operations
   - Third-party integrations (Privy, Safe)
   - **Use for**: Backend logic, API contracts

4. **Unit Tests** (`tests/unit/`)
   - Component testing with Jest + React Testing Library
   - Service function testing
   - Utility function validation
   - **Use for**: Isolated component/function logic

---

## Test Configuration

### Playwright Configuration

- **File**: `playwright.config.ts`
- **Base URL**: `http://localhost:3000` (dev) or env var
- **Timeout**: 60s per test, 5s per assertion
- **Retries**: 2 on CI, 0 locally
- **Browsers**: Chrome, Firefox, Safari, Mobile Chrome/Safari

### Jest Configuration

- **File**: `jest.config.js`
- **Coverage Threshold**: 80% (branches, functions, lines, statements)
- **Environment**: `jest-environment-jsdom`
- **Setup**: `jest.setup.js` (mocks Supabase, Privy, etc.)

---

## Test Patterns

### Pattern 1: E2E Test Structure

```typescript
import { test, expect } from '@playwright/test';

test.describe('Feature Name', () => {
  test.beforeEach(async ({ page }) => {
    // Setup: Navigate to starting page
    await page.goto('/path/to/feature');
    await page.waitForLoadState('networkidle');
  });

  test('should complete primary user flow', async ({ page }) => {
    // Step 1: Arrange - verify initial state
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();

    // Step 2: Act - perform user actions
    const button = page.getByRole('button', { name: /submit/i });
    await button.click();

    // Step 3: Assert - verify outcome
    await expect(page.getByText(/success/i)).toBeVisible();
  });

  test('should handle error states', async ({ page }) => {
    // Mock network failure
    await page.route('**/api/endpoint', (route) => route.abort('failed'));

    // Trigger action
    await page.click('[data-testid="submit"]');

    // Verify error handling
    await expect(page.getByText(/error/i)).toBeVisible();
  });
});
```

**Key Points**:

- Use `test.describe()` for grouping related tests
- `beforeEach()` for common setup
- Descriptive test names with `should...`
- Arrange-Act-Assert pattern
- Use semantic selectors (`getByRole`, `getByText`) over CSS selectors

---

### Pattern 2: UX Performance Testing

```typescript
test('should measure feature performance', async ({ page }) => {
  const startTime = Date.now();

  // Perform action
  await page.fill('[data-testid="input"]', 'test value');
  await page.click('[data-testid="submit"]');

  // Wait for completion
  await expect(page.getByText('Complete')).toBeVisible();

  const duration = Date.now() - startTime;

  // Assert performance target
  expect(duration).toBeLessThan(2000); // 2s target

  console.log(`Feature completion time: ${duration}ms`);
});
```

**Key Points**:

- Measure actual user-perceived performance
- Log timings for monitoring trends
- Set realistic performance budgets
- Test on multiple viewports

---

### Pattern 3: Real-time Updates Testing

```typescript
test('should update data in real-time', async ({ page, context }) => {
  // Open feature in two browser contexts
  const page1 = page;
  const page2 = await context.newPage();

  // Navigate both to same resource
  await page1.goto('/dao/test/proposals/1');
  await page2.goto('/dao/test/proposals/1');

  // Record initial state in page1
  const initialCount = await page1.getByTestId('vote-count').textContent();

  // Perform action in page2
  await page2.click('[data-testid="vote-yes"]');
  await expect(page2.getByText('Vote submitted')).toBeVisible();

  // Verify page1 updates without refresh
  await page1.waitForTimeout(2000); // Allow real-time sync
  const updatedCount = await page1.getByTestId('vote-count').textContent();

  expect(updatedCount).not.toBe(initialCount);
});
```

**Key Points**:

- Use multiple browser contexts to simulate concurrent users
- Test real-time sync latency
- Verify no page refresh required
- Clean up contexts after test

---

### Pattern 4: Mobile Responsiveness

```typescript
test('should be mobile-friendly', async ({ page, isMobile }) => {
  if (!isMobile) return; // Skip on desktop

  // Set mobile viewport
  await page.setViewportSize({ width: 375, height: 667 });

  // Verify mobile-optimized UI
  const button = page.getByRole('button', { name: /submit/i });
  const box = await button.boundingBox();

  // Touch target should be >=44px
  expect(box?.height).toBeGreaterThanOrEqual(44);
  expect(box?.width).toBeGreaterThanOrEqual(44);

  // Verify no horizontal scroll
  const scrollWidth = await page.evaluate(() => document.body.scrollWidth);
  const clientWidth = await page.evaluate(() => document.body.clientWidth);
  expect(scrollWidth).toBeLessThanOrEqual(clientWidth);
});
```

**Key Points**:

- Use `isMobile` parameter to conditionally run mobile tests
- Validate touch target sizes (44px minimum)
- Check for unwanted horizontal scrolling
- Test swipe gestures where applicable

---

### Pattern 5: Accessibility Testing

```typescript
test('should be keyboard accessible', async ({ page }) => {
  // Navigate to interactive element with Tab
  await page.keyboard.press('Tab');

  // Verify focus visible
  const focusedElement = page.locator(':focus');
  await expect(focusedElement).toBeVisible();

  // Use Space/Enter to activate
  await page.keyboard.press('Enter');

  // Verify action triggered
  await expect(page.getByText('Success')).toBeVisible();
});

test('should have proper ARIA labels', async ({ page }) => {
  // Verify accessible names
  await expect(page.getByRole('button', { name: /submit/i })).toBeVisible();
  await expect(page.getByRole('textbox', { name: /title/i })).toBeVisible();

  // Verify ARIA attributes
  const alertBox = page.getByRole('alert');
  await expect(alertBox).toHaveAttribute('aria-live', 'polite');
});
```

**Key Points**:

- Test keyboard navigation (Tab, Arrow keys, Enter, Space)
- Verify focus indicators visible
- Check ARIA roles and labels
- Ensure screen reader compatibility

---

### Pattern 6: Error Handling and Recovery

```typescript
test('should recover from network errors', async ({ page }) => {
  // Mock API failure
  await page.route('**/api/submit', (route) => route.abort('failed'));

  // Attempt action
  await page.click('[data-testid="submit"]');

  // Verify error message
  await expect(page.getByText(/failed to submit/i)).toBeVisible();

  // Verify retry option
  const retryButton = page.getByRole('button', { name: /retry/i });
  await expect(retryButton).toBeVisible();

  // Remove mock, enable success
  await page.unroute('**/api/submit');

  // Retry should succeed
  await retryButton.click();
  await expect(page.getByText(/success/i)).toBeVisible();
});
```

**Key Points**:

- Test both error and recovery paths
- Verify user-friendly error messages
- Provide clear recovery options
- Clean up mocks after test

---

## Data Management

### Test Data Strategy

1. **Use `data-testid` attributes** for reliable element selection:

   ```tsx
   <button data-testid="submit-proposal">Submit</button>
   ```

2. **Prefer semantic selectors** when possible:

   ```typescript
   page.getByRole('button', { name: /submit/i }); // ✅ Good
   page.locator('#submit-btn'); // ❌ Avoid
   ```

3. **Mock Supabase data** consistently:

   ```typescript
   // In jest.setup.js, Supabase is already mocked
   // For specific test data, use test database or mocks
   ```

4. **Clean up test data** after tests:
   ```typescript
   test.afterEach(async () => {
     // Delete test data created during test
     await cleanup();
   });
   ```

---

## Database Testing

### Supabase Test Database (Recommended for Integration Tests)

```typescript
import { createClient } from '@supabase/supabase-js';

test.beforeAll(async () => {
  // Connect to test database
  const supabase = createClient(
    process.env.SUPABASE_TEST_URL!,
    process.env.SUPABASE_TEST_KEY!
  );
});

test('should create DAO record', async () => {
  const daoData = { name: 'Test DAO', members: [] };
  const { data, error } = await supabase
    .from('daos')
    .insert(daoData)
    .select()
    .single();

  expect(error).toBeNull();
  expect(data?.name).toBe('Test DAO');
});
```

### Mock Approach (For Unit Tests)

```typescript
// Already configured in jest.setup.js
import { getSupabaseClient } from '@/lib/supabase/client';

test('should fetch record', async () => {
  // Mock implementation
  const mockSupabase = {
    from: jest.fn().mockReturnValue({
      select: jest.fn().mockReturnValue({
        eq: jest
          .fn()
          .mockResolvedValue({ data: { name: 'Test DAO' }, error: null }),
      }),
    }),
  };

  expect(mockSupabase).toBeDefined();
});
```

---

## Performance Metrics

### Target Performance Budgets

| Metric           | Target | Test Type   |
| ---------------- | ------ | ----------- |
| Page Load (LCP)  | <2.5s  | E2E         |
| Form Submission  | <2s    | UX          |
| Real-time Update | <2s    | E2E         |
| API Response     | <500ms | Integration |
| Bundle Size      | <500KB | Build       |

### Measuring Performance

```typescript
test('should meet performance targets', async ({ page }) => {
  // Navigate and measure
  const navigationStart = Date.now();
  await page.goto('/feature');
  const navigationEnd = Date.now();

  // Get Web Vitals
  const lcp = await page.evaluate(() => {
    return new Promise((resolve) => {
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        resolve(lastEntry.startTime);
      }).observe({ entryTypes: ['largest-contentful-paint'] });
    });
  });

  expect(lcp).toBeLessThan(2500); // 2.5s LCP target
});
```

---

## Common Pitfalls to Avoid

### ❌ Don't: Use brittle selectors

```typescript
await page.click('#submit-btn-123'); // ID might change
```

### ✅ Do: Use semantic, stable selectors

```typescript
await page.getByRole('button', { name: /submit/i });
```

---

### ❌ Don't: Hardcode wait times

```typescript
await page.waitForTimeout(5000); // Flaky, slow
```

### ✅ Do: Wait for specific conditions

```typescript
await expect(page.getByText('Success')).toBeVisible();
```

---

### ❌ Don't: Test implementation details

```typescript
expect(component.state.isLoading).toBe(false); // Internal state
```

### ✅ Do: Test user-visible behavior

```typescript
await expect(page.getByTestId('spinner')).not.toBeVisible();
```

---

### ❌ Don't: Create interdependent tests

```typescript
test('step 1', () => {
  /* sets global state */
});
test('step 2', () => {
  /* depends on step 1 */
}); // Flaky!
```

### ✅ Do: Make tests independent

```typescript
test('feature works', async ({ page }) => {
  // Setup specific to this test
  await setupTestData();

  // Test complete workflow
  // ...
});
```

---

## Running Tests

### Local Development

```bash
# E2E tests (Playwright)
yarn test:e2e

# UX tests (Playwright)
yarn test:ux

# Unit tests (Jest)
yarn test

# Watch mode
yarn test -- --watch

# Specific test file
yarn test -- proposal-voting
```

### CI/CD Pipeline

Tests run automatically on:

- Pull request creation
- Commits to `development`, `staging`, `main`

**CI Environment**:

- Uses GitHub Actions
- Retries: 2 attempts
- Parallel execution disabled (workers: 1)
- Artifacts: Screenshots, videos, HTML reports

---

## Test Coverage Requirements

### Minimum Coverage Thresholds

| Category   | Threshold |
| ---------- | --------- |
| Branches   | 80%       |
| Functions  | 80%       |
| Lines      | 80%       |
| Statements | 80%       |

### Generate Coverage Report

```bash
yarn test -- --coverage
```

Report location: `coverage/lcov-report/index.html`

---

## Test Scaffolds for Wave 2

### Created Test Files

1. **`tests/e2e/dashboard-voting-stats.test.ts`**
   - Dashboard voting statistics display
   - Real-time stat updates
   - Participation rate accuracy

2. **`tests/e2e/real-time-voting.test.ts`**
   - Live vote count updates
   - Concurrent voting scenarios
   - Auto-finalize integration

3. **`tests/ux/draft-proposal-flow.test.ts`**
   - Draft auto-save functionality
   - Draft recovery and resumption
   - Draft management UX

**Status**: Scaffolds created with implementation tasks. Ready for future waves.

---

## Integration with Wave 1 Fixes

### BLOCKER-1: Auto-finalize Proposals

**Test Coverage Needed**:

- Verify auto-finalize triggers when quorum + threshold met
- Check finalized status updates in real-time
- Validate finalized proposals reflected in stats

**Test Files**:

- `tests/e2e/real-time-voting.test.ts`
- `tests/e2e/dashboard-voting-stats.test.ts`

---

### BLOCKER-2: Treasury Error Handling

**Test Coverage Needed**:

- Test Safe API failures gracefully handled
- Verify user-friendly error messages
- Check retry mechanisms work

**Test Files**:

- `tests/integration/treasury-api.test.ts` (to be created)
- `tests/e2e/treasury-proposal-flow.test.ts` (to be created)

---

### BLOCKER-3: Participation Rate

**Test Coverage Needed**:

- Validate calculation: (voters / members) \* 100
- Test with different member/voter ratios
- Verify real-time recalculation on vote

**Test Files**:

- `tests/e2e/dashboard-voting-stats.test.ts`
- `tests/unit/participation-rate.test.ts` (to be created)

---

### BLOCKER-4: Voting Config Defaults

**Test Coverage Needed**:

- Verify sensible defaults applied
- Test config persistence in drafts
- Validate edge cases (undefined values)

**Test Files**:

- `tests/ux/draft-proposal-flow.test.ts`
- `tests/unit/voting-config-defaults.test.ts` (to be created)

---

## Skill Validation Tests

### File Size Enforcer Skill

**How to Test**:

1. Create or edit a file to exceed 300 lines
2. Attempt to save
3. Verify skill provides refactoring suggestions

**Expected Behavior**:

- Warning at 300 lines
- Suggestions: Extract components, create service modules, use lazy loading

---

### Treasury Validator Skill

**How to Test**:

1. Write treasury operation code without `TreasuryAccessControlService` validation
2. Save file
3. Verify skill flags missing validation

**Expected Behavior**:

- Detects treasury operations (Safe API calls, fund transfers)
- Requires `validateTreasuryOperation()` call
- Suggests protection layer integration

---

### Test Coverage Guardian Skill

**How to Test**:

1. Create new service file (e.g., `new-feature.service.ts`)
2. Add functions without test file
3. Verify skill suggests creating test

**Expected Behavior**:

- Detects new service files
- Checks for corresponding `.test.ts` file
- Prompts to create test with scaffold

---

### Database Security Auditor Skill

**How to Test**:

1. Write Supabase query without DAO/user filter
2. Save file
3. Verify skill flags potential data leak

**Expected Behavior**:

- Detects Supabase queries
- Checks for `.eq('dao_id', ...)` or user filter
- Warns about potential unauthorized data access

---

## Resources

### Documentation

- [Playwright Docs](https://playwright.dev/)
- [Jest Docs](https://jestjs.io/)
- [React Testing Library](https://testing-library.com/react)
- [Supabase Testing](https://supabase.com/docs/guides/testing)

### Project-Specific

- **Architecture Health**: `yarn check:architecture`
- **CLAUDE.md**: `/Users/jjones/Documents/endao-mvp/CLAUDE.md`
- **Feature List**: `/Users/jjones/Documents/endao-mvp/FEATURE_FIX_LIST.md`

---

## Questions?

Contact the Test Subagent lead or refer to existing test files for examples.

**Last Updated**: October 29, 2025
