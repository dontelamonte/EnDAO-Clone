# Dev Auth Quick Start

## Purpose

Quick start guide to enable development authentication bypass in 60 seconds.

## Last Updated

October 2025

---

**Get up and running with development authentication in 60 seconds.**

## Enable Dev Auth (One Time Setup)

### Step 1: Add to .env.local

Create or edit `.env.local` in project root:

```bash
NEXT_PUBLIC_ENABLE_DEV_AUTH=true
```

### Step 2: Restart Dev Server

```bash
yarn dev
```

### Step 3: Look for Yellow Toolbar

You should see a **yellow warning banner** in the bottom-left corner saying "⚠️ DEVELOPMENT MODE ONLY".

## Quick Usage

### Login as Different Users

Click any button in the toolbar:

- **Dev Admin** - Full admin access
- **Dev Member** - Regular member
- **Dev Signer** - Treasury signer (Safe owner)
- **Dev Non-Member** - Guest/public access

Page will reload automatically and you're logged in!

### Switch Roles

Just click another user button. That's it!

### Logout

Click the red "Logout (Clear Dev Auth)" button at the bottom of the toolbar.

## Troubleshooting

### Toolbar Not Showing?

1. **Check .env.local exists** in project root
2. **Verify the flag**:
   ```bash
   cat .env.local | grep DEV_AUTH
   ```
   Should show: `NEXT_PUBLIC_ENABLE_DEV_AUTH=true`
3. **Restart dev server**:
   ```bash
   # Kill existing process
   # Then run:
   yarn dev
   ```

### Still Not Working?

Open browser console (F12) and look for:

```
⚠️ DEVELOPMENT AUTH ENABLED ⚠️
```

If you don't see this, dev auth is not active.

**Check all three conditions**:

- ✓ `NODE_ENV=development`
- ✓ Hostname is `localhost` (not `127.0.0.1` or IP address)
- ✓ `.env.local` has `NEXT_PUBLIC_ENABLE_DEV_AUTH=true`

## Common Issues

### Using 127.0.0.1 Instead of localhost

Dev auth only works on **localhost**. If your browser shows `127.0.0.1`:

1. Change URL to `http://localhost:3000`
2. Refresh page

### Accessing from Another Device

Dev auth **ONLY** works on localhost. It will **NOT** work when:

- Accessing from phone/tablet on same network
- Using LAN IP address (like `192.168.1.100`)
- Using ngrok or similar tunnels

This is intentional for security.

### Toolbar Minimized

If you only see a small yellow badge, click it to expand.

## Next Steps

Read the full guide for advanced usage:

📖 [Complete Dev Auth Guide](./dev-auth-guide.md)

## Quick Reference

**File Locations**:

- Core logic: `src/lib/dev/dev-auth.ts`
- Hook: `src/hooks/auth/use-dev-auth.ts`
- Toolbar: `src/components/dev/dev-auth-toolbar.tsx`
- Integration: `src/lib/auth/auth-context.tsx`

**Test Users**:

- `admin@test.local` - Admin role
- `member@test.local` - Member role
- `signer@test.local` - Signer role (treasury)
- `nonmember@test.local` - No role (guest)

**Wallet Addresses**:

- Admin: `0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb`
- Member: `0x1234567890123456789012345678901234567890`
- Signer: `0x9876543210987654321098765432109876543210`
- Non-member: `0xabcdefabcdefabcdefabcdefabcdefabcdefabcd`

---

**That's it! You're ready to use dev auth for rapid testing.**

_For security details, advanced usage, and troubleshooting, see the [complete guide](./dev-auth-guide.md)._
