# Development Authentication Bypass Guide

## Purpose

Guide for using the development authentication bypass system to enable rapid role switching during local development.

## Last Updated

October 2025

## Overview

The Development Auth Bypass system enables rapid role switching during local development without requiring Privy wallet authentication. This dramatically speeds up testing workflows by reducing authentication time from 30-60 seconds to instant.

**⚠️ SECURITY NOTICE**: This system is **ONLY** available in localhost development mode and is **IMPOSSIBLE** to enable in production due to multiple security layers.

## Security Architecture

### Triple-Layer Protection

The dev auth system requires **ALL THREE** conditions to be true:

1. **Environment Check**: `NODE_ENV === 'development'`
2. **Hostname Check**: Hostname must be `localhost` or `127.0.0.1`
3. **Explicit Flag**: `NEXT_PUBLIC_ENABLE_DEV_AUTH=true` in `.env.local`

If any single condition is false, dev auth is completely disabled.

### Production Safety

- **Tree-shaking**: Dev auth code is removed from production builds
- **Runtime checks**: Multiple runtime guards prevent activation
- **No network risk**: Only works on localhost, not LAN IP addresses
- **Explicit opt-in**: Requires conscious developer action to enable

## Quick Start

### 1. Enable Dev Auth

Add to your `.env.local` file (NOT `.env`):

```bash
# Enable development authentication bypass
NEXT_PUBLIC_ENABLE_DEV_AUTH=true
```

### 2. Start Development Server

```bash
yarn dev
```

### 3. Use the Toolbar

You should see a yellow "⚠️ DEVELOPMENT MODE ONLY" toolbar in the bottom-left corner.

Click any user button to instantly login as that role:

- **Dev Admin** - Full admin privileges
- **Dev Member** - Regular DAO member
- **Dev Signer (Safe Owner)** - Treasury signer role
- **Dev Non-Member** - Unauthenticated user

## Available Test Users

### Admin User

```typescript
{
  uid: 'dev-uid-admin-001',
  email: 'admin@test.local',
  displayName: 'Dev Admin',
  role: 'admin',
  wallets: ['0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb']
}
```

**Use for testing**:

- Admin panel access
- DAO management features
- Proposal moderation
- Member management

### Member User

```typescript
{
  uid: 'dev-uid-member-001',
  email: 'member@test.local',
  displayName: 'Dev Member',
  role: 'member',
  wallets: ['0x1234567890123456789012345678901234567890']
}
```

**Use for testing**:

- Regular member workflows
- Proposal creation
- Voting on proposals
- DAO participation

### Signer User (Safe Owner)

```typescript
{
  uid: 'dev-uid-signer-001',
  email: 'signer@test.local',
  displayName: 'Dev Signer (Safe Owner)',
  role: 'member',
  isSafeSigner: true,
  wallets: ['0x9876543210987654321098765432109876543210']
}
```

**Use for testing**:

- Treasury signing operations
- Multi-sig workflows
- Safe transaction approvals
- Treasury proposal execution

### Non-Member User

```typescript
{
  uid: 'dev-uid-nonmember-001',
  email: 'nonmember@test.local',
  displayName: 'Dev Non-Member',
  role: null,
  wallets: ['0xabcdefabcdefabcdefabcdefabcdefabcdefabcd']
}
```

**Use for testing**:

- Join request flows
- Public DAO viewing
- Guest access limitations
- Invitation acceptance

## Usage Workflow

### Typical Testing Session

1. **Start as Admin**: Click "Dev Admin" to test admin features
2. **Switch to Member**: Click "Dev Member" to test member experience
3. **Test Signer**: Click "Dev Signer" to test treasury operations
4. **Test Guest**: Click "Dev Non-Member" to test public access

### Page Reload Behavior

When you click a user button:

1. Selection is saved to `localStorage`
2. Page automatically reloads
3. Auth system detects dev user
4. Components render with new user state

**Persistence**: Dev auth selection persists across:

- Page reloads
- Navigation between routes
- Browser tab closure (until `localStorage` is cleared)

### Logging Out

Two ways to logout:

1. **Toolbar Logout Button**: Click "Logout (Clear Dev Auth)" button
2. **Regular Logout**: App's normal logout still works

Both trigger a page reload to clear auth state.

## Toolbar Features

### Visual Elements

- **Yellow warning banner**: Clear indication this is dev-only
- **Current user display**: Shows active dev user
- **Quick login buttons**: One-click role switching
- **User icons**: Visual differentiation of roles
  - 🛡️ Admin (Shield icon)
  - 👤 Member (User icon)
  - 👥 Signer (Users icon)
  - ❌ Non-Member (UserX icon)

### Minimize/Expand

- Click the **X** button to minimize to a small badge
- Click the badge to expand back to full toolbar

### Active State

The currently active user button:

- Shows green background
- Displays "ACTIVE" badge
- Is disabled (can't re-login as same user)

## Integration Points

### Auth Context Integration

Dev auth integrates seamlessly with `AuthProvider`:

```typescript
// In auth-context.tsx
if (CAN_USE_DEV_AUTH && getDevAuthUserObject()) {
  // Use dev user instead of Privy
  return devUser;
}

// Otherwise, use real Privy authentication
```

### Component Usage

Components use the standard `useAuth()` hook:

```typescript
import { useAuth } from '@/lib/auth/auth-context';

function MyComponent() {
  const { user, loading, isAuthenticated } = useAuth();

  // user will be dev user when dev auth is active
  // No code changes needed!
}
```

### Checking Dev Auth Status

If you need to know if dev auth is active:

```typescript
import { useDevAuth } from '@/hooks/auth/use-dev-auth'

function DevToolComponent() {
  const { isDevAuthEnabled, currentDevUser } = useDevAuth()

  if (!isDevAuthEnabled) {
    return null // Don't show dev tools
  }

  return <div>Current dev user: {currentDevUser}</div>
}
```

## Adding Custom Test Users

To add new test users, edit `/src/lib/dev/dev-auth.ts`:

```typescript
export const DEV_USERS = {
  // ... existing users ...

  customRole: {
    uid: 'dev-uid-custom-001',
    email: 'custom@test.local',
    displayName: 'Custom Role User',
    username: 'custom',
    photoURL: null,
    emailVerified: true,
    metadata: {
      creationTime: new Date().toISOString(),
      lastSignInTime: new Date().toISOString(),
    },
    customClaims: { role: 'custom', customProp: 'value' },
    privyUserId: 'dev-privy-custom-001',
    wallets: ['0x...your-test-wallet-address...'],
  },
};
```

The toolbar will automatically display the new user.

## Troubleshooting

### Toolbar Not Appearing

**Check all three security conditions**:

```bash
# 1. Environment
echo $NODE_ENV  # Must be 'development'

# 2. Hostname
# Open browser console:
console.log(window.location.hostname)  // Must be 'localhost' or '127.0.0.1'

# 3. Flag
# Check .env.local file exists and contains:
NEXT_PUBLIC_ENABLE_DEV_AUTH=true
```

**Restart dev server** after changing `.env.local`:

```bash
yarn dev
```

### Toolbar Appears but Login Doesn't Work

1. **Check browser console** for `[DEV AUTH]` logs
2. **Verify localStorage** is enabled (not in incognito mode)
3. **Clear localStorage**:
   ```javascript
   localStorage.removeItem('endao_dev_auth_user');
   ```

### Still Using Privy Authentication

Dev auth only activates when a user is selected:

1. **Click a user button** in the toolbar
2. **Wait for page reload** (automatic)
3. **Verify in console**: Look for `[DEV AUTH] Using dev auth user` log

### Production Build Shows Toolbar

**This should be impossible**, but if it happens:

1. **Verify build command**: `yarn build` (not `yarn dev`)
2. **Check NODE_ENV**: Must be 'production' in build
3. **Clear browser cache**: Might be showing cached dev build
4. **Inspect bundle**: Dev auth code should be tree-shaken out

If toolbar appears in production build, **DO NOT DEPLOY**. File a bug report immediately.

## Console Logging

Dev auth includes helpful console logs:

### Startup Logs

```
⚠️ DEVELOPMENT AUTH ENABLED ⚠️
[DEV AUTH] Environment: development
[DEV AUTH] Hostname: localhost
[DEV AUTH] Explicit enable: true
```

### User Actions

```
[DEV AUTH] Logging in as: admin
[DEV AUTH] Switched to user: admin
[DEV AUTH] Using dev auth user { displayName: 'Dev Admin' }
```

### Storage Operations

```
[DEV AUTH] Restored session: admin
[DEV AUTH] Logged out
```

## Best Practices

### Development Workflow

1. **Enable once**: Set `NEXT_PUBLIC_ENABLE_DEV_AUTH=true` once in `.env.local`
2. **Leave enabled**: Keep it on for entire dev session
3. **Switch frequently**: Don't hesitate to switch roles often
4. **Test all roles**: Verify features work for all user types

### Testing Strategy

1. **Start with admin**: Verify admin-only features
2. **Switch to member**: Test member experience
3. **Test edge cases**: Use non-member for access control
4. **Verify treasury**: Use signer for multi-sig workflows

### Security Mindset

1. **Never commit `.env.local`**: Already in `.gitignore`
2. **Document test scenarios**: Note which role for which test
3. **Verify production safety**: Occasionally test production build locally
4. **Report issues**: If dev auth behaves unexpectedly, report immediately

## Architecture Details

### File Structure

```
src/
├── lib/dev/
│   └── dev-auth.ts              # Core dev auth logic
├── hooks/auth/
│   └── use-dev-auth.ts          # Dev auth hook
├── components/dev/
│   └── dev-auth-toolbar.tsx     # Toolbar UI
└── lib/auth/
    └── auth-context.tsx         # Auth integration
```

### Security Flow

```
User clicks login button
    ↓
useDevAuth.loginAs(userType)
    ↓
setDevAuthUser(userType) → localStorage
    ↓
window.location.reload()
    ↓
AuthProvider.useEffect()
    ↓
Check CAN_USE_DEV_AUTH (triple-layer gate)
    ↓
getDevAuthUserObject() → returns test user
    ↓
setState({ user: devUser })
    ↓
Components render with dev user
```

### Integration with Privy

Dev auth sits **above** Privy in the auth flow:

```typescript
// Pseudo-code flow
if (devAuthActive) {
  return devUser; // Skip Privy entirely
}

// Otherwise, continue with Privy
return privyUser;
```

This means:

- **No Privy calls** when dev auth active
- **No wallet interactions** required
- **No network requests** for auth
- **Instant authentication** every time

## Performance Impact

### Development Mode

- **Initial load**: No impact (lazy loaded)
- **Toolbar render**: <10ms
- **Role switch**: Instant (page reload required)
- **Bundle size**: ~5KB (removed in production)

### Production Mode

- **Bundle impact**: 0KB (tree-shaken out)
- **Runtime impact**: Zero (code not present)
- **Security impact**: Zero (impossible to enable)

## Limitations

### Known Limitations

1. **Page reload required**: Role switching requires full page reload
   - **Why**: Ensures complete auth state reset
   - **Workaround**: None (this is intentional)

2. **localStorage required**: Won't work in incognito mode
   - **Why**: State persistence requires storage
   - **Workaround**: Use regular browser window

3. **No real wallet**: Can't sign real blockchain transactions
   - **Why**: Wallet addresses are mock data
   - **Workaround**: Use testnet with real Privy auth

4. **No database profile**: Dev users don't exist in Supabase
   - **Why**: Mock authentication only
   - **Workaround**: Services should handle missing profiles gracefully

### Future Enhancements

Potential improvements (not yet implemented):

- **Hot switching**: Switch roles without page reload
- **Custom user creation**: UI for creating temporary test users
- **Session recording**: Record test sessions with specific roles
- **Shared state**: Share dev auth state across browser tabs

## Support

### Getting Help

1. **Check console logs**: Most issues visible in browser console
2. **Verify security conditions**: All three layers must be true
3. **Review this guide**: Most questions answered here
4. **Ask team**: Reach out on team chat

### Reporting Issues

When reporting dev auth issues, include:

1. **Environment info**:
   - `NODE_ENV` value
   - Browser hostname
   - `.env.local` flag status

2. **Console output**:
   - All `[DEV AUTH]` log messages
   - Any error messages

3. **Steps to reproduce**:
   - What user you tried to login as
   - What happened vs. expected behavior

## Summary

Development Auth Bypass provides:

- ✅ **Instant role switching** (no wallet, no wait)
- ✅ **Multiple test users** (admin, member, signer, guest)
- ✅ **Visual toolbar** (clear, intuitive UI)
- ✅ **Triple-layer security** (impossible to enable in production)
- ✅ **Zero production impact** (tree-shaken out completely)
- ✅ **Seamless integration** (works with existing auth system)

**Start using it today to accelerate your development workflow!**

---

_Last Updated: October 31, 2025_
_Version: 1.0.0_
