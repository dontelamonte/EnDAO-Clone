# Comprehensive Codebase Review Prompt

**Purpose**: Systematic, exhaustive codebase review framework for large-scale applications.
**Last Validated**: December 2025 (EnDAO review - 37 files, 3,700+ lines analyzed)

---

## Quick Start

```bash
# Clone this prompt for your project
# Update the "Project Context" section with your stack
# Run in phases using agent delegation for efficiency
```

**Estimated Time**:

- Small codebase (<100 files): 2-4 hours
- Medium codebase (100-500 files): 1-2 days
- Large codebase (500+ files): 3-5 days with agent delegation

---

## Phase 0: Pre-Review Context Gathering

**CRITICAL**: Before flagging individual issues, check for global patterns that handle concerns at a higher level.

### Global Pattern Inventory

Check these FIRST to avoid false positives:

```markdown
## Global Pattern Checklist

### Middleware & Request Handling

- [ ] **CSRF Protection**: Check `src/middleware.ts` or `middleware/` for global CSRF handling
- [ ] **Rate Limiting**: Check for rate limit middleware (e.g., `upstash/ratelimit`, custom middleware)
- [ ] **Auth Middleware**: Check for global auth verification
- [ ] **Security Headers**: Check for CSP, CORS, X-Frame-Options in middleware

### Configuration Files

- [ ] **ESLint**: Review `eslint.config.mjs` for enforced patterns
- [ ] **TypeScript**: Review `tsconfig.json` for strict mode settings
- [ ] **Environment**: Check `.env.example` for required variables

### Architectural Patterns

- [ ] **Base Classes**: Identify service/repository base classes
- [ ] **Error Handling**: Check for global error handling patterns
- [ ] **Logging**: Identify centralized logging service
- [ ] **Caching**: Check for caching middleware/services

### Document Findings

Record global patterns found:
| Pattern | Location | Scope | Notes |
|---------|----------|-------|-------|
| CSRF | middleware.ts:24-29 | All API routes | Auto-applied |
| Rate Limit | middleware.ts:124 | Pattern-based | Uses upstash |
```

**Why This Matters**: In the December 2025 review, 35 "critical" CSRF issues and 67 "rate limiting" issues were FALSE POSITIVES because middleware handled them globally.

---

## Phase 1: Project Context Configuration

### Template - Customize for Your Project

```yaml
# PROJECT CONFIGURATION
project_name: '[Your Project]'
stack:
  framework: '[e.g., Next.js 15, Django, Rails]'
  database: '[e.g., PostgreSQL, MongoDB]'
  auth: '[e.g., Privy, NextAuth, Auth0]'
  styling: '[e.g., Tailwind, MUI, Chakra]'
  type_system: '[e.g., TypeScript strict, Python typing]'

# ARCHITECTURE PATTERNS
patterns:
  data_layer: '[Repository pattern, ORM, Direct queries]'
  service_layer: '[Service classes, Functions, None]'
  api_style: '[REST, GraphQL, tRPC]'
  state_management: '[React Query, Redux, Zustand]'

# PROJECT-SPECIFIC RULES
rules:
  browser_safe_imports: ['list patterns that should NOT be in browser code']
  admin_only_services: ['list services requiring elevated permissions']
  critical_paths: ['treasury', 'auth', 'payments'] # Areas needing extra scrutiny

# FILE SIZE STANDARDS
file_limits:
  target: 300 # Ideal max lines
  warning: 500 # Should refactor soon
  error: 800 # Blocks PR merge
  exclusions: ['*.test.ts', '*.spec.ts', 'types.ts', 'migrations/*']
```

### EnDAO Example Configuration

```yaml
project_name: 'EnDAO'
stack:
  framework: 'Next.js 15 (App Router), React 19'
  database: 'Supabase/PostgreSQL with RLS'
  auth: 'Privy (wallet-first with email fallback)'
  treasury: 'Gnosis Safe Protocol Kit v4 + ethers.js v6.15.0'
  styling: 'Tailwind CSS + shadcn/ui'
  type_system: 'TypeScript strict, @endao/shared-types monorepo'
  mobile: 'Expo ~52.0, React Native 0.76.6'

patterns:
  data_layer: 'Repository Pattern ({entity}Repository client, {entity}AdminRepository server)'
  service_layer: 'BaseService → ServiceResponse<T>'
  api_style: 'REST with CSRF protection'
  query_builders: ['proposal-query.builder.ts', 'vote-query.builder.ts']
  adapters: ['ethers/', 'safe/', 'privy/']

rules:
  browser_safe_imports:
    forbidden: ['getSupabaseAdmin()', 'AdminRepository', 'Direct service calls']
    allowed: ['getSupabaseClient()', 'useCSRFAPI()', 'API routes']
  auth_headers:
    ['x-auth-uid', 'x-auth-privy-id', 'x-auth-email', 'x-auth-wallet']
  critical_paths: ['treasury', 'voting', 'member-permissions']
```

---

## Phase 2: Review Execution

### Directory Priority Order

Work through in this order (security-critical first):

```
Priority 1 - Security Critical:
├── src/app/api/              # API routes
├── src/lib/auth/             # Auth contexts
├── src/lib/services/         # Service layer (esp. admin services)
└── middleware.ts             # Global middleware

Priority 2 - Data Layer:
├── src/lib/data/             # Repositories
├── src/lib/adapters/         # External library wrappers
└── src/lib/plugins/          # Plugin systems

Priority 3 - Application Layer:
├── src/lib/hooks/            # Global hooks
├── src/lib/utils/            # Utilities
├── src/hooks/                # Feature hooks
└── src/components/           # UI components

Priority 4 - Pages & Types:
├── src/app/                  # Pages and layouts
├── packages/shared-types/    # Type definitions
└── apps/mobile/              # Mobile app (if applicable)
```

### Per-File Analysis Checklist

For **EVERY** file, assess these categories:

#### Code Quality (20 checks)

```markdown
## Structural

- [ ] Dead code (unused functions, unreachable branches)
- [ ] Duplicated logic (copy-paste patterns)
- [ ] Deep nesting (>3 levels)
- [ ] Long functions (>50 lines)
- [ ] God files (>500 lines)
- [ ] Inconsistent naming
- [ ] Poor organization

## Type Safety

- [ ] Explicit `any` types
- [ ] Unsafe type assertions (`as unknown as`, `!`)
- [ ] Missing null checks
- [ ] Weak typing (overly broad types)
- [ ] Missing generics
- [ ] Inconsistent type imports

## Error Handling

- [ ] Uncaught promise rejections
- [ ] Silent failures (empty catch)
- [ ] Generic error messages
- [ ] Missing error boundaries
- [ ] No error propagation
```

#### Performance (15 checks)

```markdown
## React/Frontend

- [ ] Missing useMemo/useCallback
- [ ] Missing React.memo
- [ ] Inline objects causing re-renders
- [ ] Missing code splitting
- [ ] Large bundle imports

## Data Fetching

- [ ] N+1 query patterns
- [ ] Sequential fetches (should be parallel)
- [ ] Missing pagination
- [ ] Over-fetching columns
- [ ] Missing caching
- [ ] Stale cache issues

## Database

- [ ] Missing indexes
- [ ] Full table scans
- [ ] Inefficient joins
- [ ] Not using views/aggregations
```

#### Security (25 checks)

```markdown
## Auth & Access

- [ ] Missing auth checks
- [ ] Client-side only auth
- [ ] Missing permission checks
- [ ] Inconsistent auth headers

## Data Safety

- [ ] Browser code using admin imports (CRITICAL)
- [ ] Missing input validation
- [ ] SQL injection vectors
- [ ] No parameterized queries

## CSRF & XSS

- [ ] Mutations without CSRF (check global middleware first!)
- [ ] dangerouslySetInnerHTML without sanitization
- [ ] Unescaped user content

## Financial/Critical Operations

- [ ] Missing access control service
- [ ] Race conditions possible
- [ ] Floating point calculations on money
- [ ] Missing audit logging

## Secrets

- [ ] Hardcoded credentials
- [ ] Env vars in client code
- [ ] Secrets in logs/errors
```

#### Maintainability (10 checks)

```markdown
## Documentation

- [ ] Missing JSDoc on public APIs
- [ ] Outdated comments
- [ ] No usage examples

## Testing

- [ ] No unit tests for critical logic
- [ ] Missing edge case coverage
- [ ] Flaky tests

## Dependencies

- [ ] Outdated with security issues
- [ ] Circular dependencies
```

---

## Phase 3: Output Formats

### Per-File Template

```markdown
### 📄 `path/to/file.tsx` (234 lines)

**Purpose**: [Brief description]
**Complexity**: [Cyclomatic score if available]

#### Issues Found

| Severity    | Line(s) | Category    | Issue                         | Fix                 |
| ----------- | ------- | ----------- | ----------------------------- | ------------------- |
| 🔴 Critical | 123     | Security    | Using admin client in browser | Move to API route   |
| 🟡 Medium   | 45-67   | Performance | N+1 query in loop             | Use `.in()` clause  |
| 🟢 Low      | 89      | Quality     | Magic number `300`            | Extract to constant |

#### Quick Wins (<10 min)

1. [Specific fix]
2. [Specific fix]

#### Larger Refactors

1. [Fix + estimated time]
```

### Directory Summary Template

```markdown
## 📁 `src/app/api/proposals/`

**Files**: 8 | **Lines**: 1,234

| Severity    | Count | Breakdown                     |
| ----------- | ----- | ----------------------------- |
| 🔴 Critical | 5     | 3 Security, 2 Performance     |
| 🟡 Medium   | 12    | 7 Quality, 3 Security, 2 Perf |
| 🟢 Low      | 8     | 5 Maintainability, 3 Quality  |

### Patterns Observed

- ✅ All routes validate auth headers
- ❌ Inconsistent error response formats
- ❌ Missing rate limiting (NOTE: may be handled by middleware)
```

### Master Report Template

```markdown
# Codebase Review Master Report

**Project**: [Name]
**Review Date**: [Date]
**Reviewer**: [Name/AI]

## Executive Summary

**Total Issues**: X (Y critical, Z medium, W low)
**False Positives Identified**: N issues (explain why)
**True Priority Items**: M issues requiring action

## Issue Classification

### 🔴 CRITICAL - Requires Immediate Action

[List with severity justification]

### 🟡 MEDIUM - Should Address This Sprint

[List organized by category]

### 🟢 LOW - Nice to Have / Technical Debt

[List for backlog]

## False Positives Identified

| Claimed Issue                | Why It's False       | Actual Pattern      |
| ---------------------------- | -------------------- | ------------------- |
| CSRF missing on 35 endpoints | Global middleware    | middleware.ts:24-29 |
| Rate limiting missing        | Pattern-based config | middleware.ts:124   |

## Action Plan

### Phase 1: [Name] (X hours)

- [ ] Task 1
- [ ] Task 2

### Phase 2: [Name] (X hours)

- [ ] Task 1
- [ ] Task 2

## Validation Checklist

- [ ] Type check passes: `yarn type-check`
- [ ] Tests pass: `yarn test`
- [ ] Build succeeds: `yarn build`
- [ ] No new ESLint errors
```

---

## Phase 4: Session Management

### Progress Tracking Template

```markdown
## Review Progress Report

**Session**: [Date] | **Duration**: [X hours]

### Completed

| Directory              | Files | Lines | Issues |
| ---------------------- | ----- | ----- | ------ |
| src/app/api/proposals/ | 8     | 1,234 | 12     |
| src/app/api/dao/       | 6     | 892   | 8      |

### Current Position

- **Directory**: `src/app/api/admin/`
- **Last File**: `system-health/route.ts`
- **Next File**: `users/route.ts`

### Cumulative Stats

- Files Reviewed: 17
- Lines Reviewed: 2,126
- Issues Found: 45 (12 critical, 21 medium, 12 low)

### Top Patterns (So Far)

1. Browser-safety violations: 5 occurrences
2. Missing input validation: 8 occurrences
3. N+1 queries: 4 occurrences
```

### Resume Prompt Template

```markdown
Resume codebase review from: `[next file path]`

Previous context:

- Completed: [directories]
- Issues found: [count by severity]
- Top patterns: [list]
- Global patterns confirmed: [CSRF, rate limiting, etc.]
```

---

## Phase 5: Agent Delegation (Large Reviews)

For codebases >100 files, use parallel agent delegation:

### Delegation Strategy

```yaml
# Split by directory (recommended for large codebases)
agents:
  - name: 'api-reviewer'
    scope: 'src/app/api/**'
    focus: ['security', 'auth', 'validation']

  - name: 'service-reviewer'
    scope: 'src/lib/services/**'
    focus: ['patterns', 'error-handling', 'types']

  - name: 'component-reviewer'
    scope: 'src/components/**'
    focus: ['performance', 'accessibility', 'react-patterns']

  - name: 'mobile-reviewer'
    scope: 'apps/mobile/**'
    focus: ['api-usage', 'offline-patterns', 'performance']
```

### Agent Prompt Template

```markdown
Review all files in `[scope]` with focus on [focus areas].

Context:

- Project: [name]
- Stack: [brief]
- Global patterns confirmed: [list]

For each file, provide:

1. File path and line count
2. Issues found (severity, line, category, fix)
3. Quick wins vs larger refactors

Output as structured markdown for aggregation.
```

### Aggregation Process

1. Run all agents in parallel
2. Collect outputs into master report
3. De-duplicate cross-cutting issues
4. Validate false positives against global patterns
5. Prioritize by severity and impact
6. Generate action plan

---

## Appendix A: Severity Definitions

| Severity | Symbol | Definition                                               | Action Timeline |
| -------- | ------ | -------------------------------------------------------- | --------------- |
| Critical | 🔴     | Security vulnerability, data loss risk, production break | Immediate (24h) |
| Medium   | 🟡     | Performance issue, code smell, maintainability           | This sprint     |
| Low      | 🟢     | Nice to have, minor improvement, documentation           | Backlog         |

### Severity Decision Tree

```
Is it a security vulnerability?
├── Yes → 🔴 Critical
└── No → Could it cause data loss or production issues?
    ├── Yes → 🔴 Critical
    └── No → Is it a performance issue affecting users?
        ├── Yes (>50% impact) → 🔴 Critical
        ├── Yes (noticeable) → 🟡 Medium
        └── No → Is it a code quality/maintainability issue?
            ├── Yes (blocks other work) → 🟡 Medium
            └── No → 🟢 Low
```

---

## Appendix B: Common False Positive Patterns

Learn from past reviews - these often appear as issues but are handled elsewhere:

| Apparent Issue            | Common Explanation   | How to Verify                             |
| ------------------------- | -------------------- | ----------------------------------------- |
| Missing CSRF protection   | Global middleware    | Check `middleware.ts`                     |
| No rate limiting          | Pattern-based config | Check middleware configs                  |
| Hardcoded URLs            | Environment-based    | Check `.env.example`                      |
| Missing input validation  | Base class handles   | Check `BaseService`                       |
| No error handling         | Error boundary       | Check layout/providers                    |
| Console.log in production | Dev-only flag        | Check `__DEV__` or `process.env.NODE_ENV` |

---

## Appendix C: Review Checklist Summary

### Before Starting

- [ ] Read project README and CLAUDE.md
- [ ] Check global middleware
- [ ] Identify base classes and patterns
- [ ] Note file size standards
- [ ] Set up progress tracking

### During Review

- [ ] Check all 70+ criteria per file
- [ ] Document exact line numbers
- [ ] Note patterns across files
- [ ] Flag potential false positives
- [ ] Track quick wins separately

### After Review

- [ ] Validate false positives
- [ ] Group issues by pattern
- [ ] Create priority matrix
- [ ] Generate action plan with phases
- [ ] Run validation (type-check, tests, build)

---

## Version History

| Version | Date     | Changes                                                                |
| ------- | -------- | ---------------------------------------------------------------------- |
| 2.0     | Dec 2025 | Added false positive handling, agent delegation, global pattern checks |
| 1.0     | Nov 2025 | Initial comprehensive review framework                                 |

---

**Usage**: Copy this prompt, customize the Project Context section, and begin with Phase 0 (global pattern inventory).
