# EnDAO Development Tracker

**Single Source of Truth** | **Last Updated**: February 28, 2026 | **Version**: 2.4.0

## Purpose

This document is the single source of truth for all EnDAO feature implementation status. It tracks completed features, work in progress, and the backlog across web and mobile platforms.

> For strategic vision and tier descriptions, see [PLATFORM_ROADMAP.md](/PLATFORM_ROADMAP.md).

---

## Quick Status

```
Platform Completion: 88% (86 of 98 features)
Mobile Completion:   100% (25 of 25 implemented features)
Mobile-Web Parity:   41% (25 of 61 features - 36 gap)
Current Focus:       Group Management Features (Institutional Layer)
Next Up:             Decision Journal, Meeting Pipeline, Task Tracking
```

| Track                   | Status                                             |
| ----------------------- | -------------------------------------------------- |
| **Web Platform**        | Production stable, Tier 1 nearly complete          |
| **Mobile (US/Western)** | Phase 1-4 complete, ready for App Store submission |
| **Mobile (Africa PWA)** | Research complete, implementation deferred         |

---

## In Progress

| Feature | Track | Owner | Started | Notes |
| ------- | ----- | ----- | ------- | ----- |

_(No features currently in progress)_

---

## Next Up (Priority Order)

### Mobile Strategy Alignment (Pre-App Store)

| #   | Feature              | Track  | Effort | Notes                |
| --- | -------------------- | ------ | ------ | -------------------- |
| 1   | Sentry React Native  | Mobile | 1 day  | Error monitoring SDK |
| 2   | PostHog React Native | Mobile | 1 day  | Analytics SDK        |

### Shared Foundation (Both Tracks)

| #   | Feature                   | Track  | Effort   | Notes                                       |
| --- | ------------------------- | ------ | -------- | ------------------------------------------- |
| 4   | Market Config Schema      | Shared | 2 days   | `market_configs` table, DAO columns         |
| 5   | Currency Formatting       | Shared | 1 day    | `Intl.NumberFormat` utility in shared-types |
| 6   | PaymentProvider Interface | Shared | 2 days   | Abstract Stripe, prepare for Flutterwave    |
| 7   | String Externalization    | Shared | 3-5 days | Key-based system, prep for i18n             |
| 8   | Shared Validators Package | Shared | 2 days   | `@endao/shared-validators` with Zod         |

### App Store Submission

| #   | Feature              | Track  | Effort   | Blocked By               |
| --- | -------------------- | ------ | -------- | ------------------------ |
| 9   | App Store Submission | Mobile | 2-3 days | EAS config, dev accounts |

### Tier 1 Web Features (Q1 2026)

| #   | Feature                       | Track | Effort   | Blocked By | Notes                                                                                                                             |
| --- | ----------------------------- | ----- | -------- | ---------- | --------------------------------------------------------------------------------------------------------------------------------- |
| 10  | Quick Polls                   | Web   | 3-4 days | -          | -                                                                                                                                 |
| 11  | Spending Controls Enforcement | Web   | 1 week   | -          | -                                                                                                                                 |
| 12  | Social Recovery (Guardians)   | Web   | 2 weeks  | -          | -                                                                                                                                 |
| 13  | **Session Keys (ERC-7579)**   | Web   | 8 weeks  | -          | **Plan Ready**: `.claude/plans/whimsical-stirring-crystal.md` - Eliminates manual multi-sig UX, supports Privy + external wallets |

### Group Management Features (Q1-Q2 2026)

> **Plan Document**: `docs/planning/GROUP_MANAGEMENT_FEATURES_PLAN.md`
> **Goal**: Position EnDAO as institutional layer for formal organizations

| #   | Feature                   | Track | Effort   | AI-Powered   | Notes                                                                                        |
| --- | ------------------------- | ----- | -------- | ------------ | -------------------------------------------------------------------------------------------- |
| 14  | Decision Journal          | Web   | 3-4 days | ✅ Summarize | Searchable audit trail with execution status, timeline + table views                         |
| 15  | Meeting Entity & Agendas  | Web   | 5-7 days | ✅ Minutes   | `meetings` + `agenda_items` tables, meeting CRUD, agenda management                          |
| 16  | Meeting → Vote Pipeline   | Web   | 2-3 days | -            | One-click "Open Voting" from agenda items, proposal links back to meeting                    |
| 17  | Calendar Integration      | Web   | 2-3 days | -            | Add-to-Calendar buttons (Google/Outlook/Apple), .ics export for voting deadlines             |
| 18  | Task/Action Tracking      | Web   | 5-7 days | ✅ Suggest   | `tasks` table, Kanban UI, link tasks to source decisions, create tasks from passed proposals |
| 19  | Enhanced Member Directory | Web   | 2-3 days | -            | Permission visualization, custom titles (Treasurer, Secretary), "By Role" grouping           |
| 20  | Document Linking          | Web   | 2-3 days | ✅ Extract   | Validate external links (Drive/Notion/Dropbox), extract metadata, broken link handling       |

**Phase Breakdown**:

- Phase 1 (Week 1-2): Decision Journal + Meeting foundation
- Phase 2 (Week 3-4): Meeting → Vote pipeline + Calendar sync
- Phase 3 (Week 5-6): Task management with decision linking
- Phase 4 (Week 7): Member directory + Document linking + Polish

### Near-Term (Q1-Q2 2026)

| #   | Feature                     | Track | Effort   | Notes                                                                                                                   |
| --- | --------------------------- | ----- | -------- | ----------------------------------------------------------------------------------------------------------------------- |
| 21  | MFA Integration             | Web   | 1 week   | Encryption layer exists                                                                                                 |
| 22  | Auth & Loading State Audit  | Web   | 3-5 days | Audit all pages for re-render loops, memoization issues, loading state flashing; ensure stable auth patterns across app |
| 23  | Stripe Connect Verification | Web   | 1-2 days | Optional gate before enabling donations: DAO age, member count, profile complete                                        |
| 24  | Activate Merkle Voting Cron | Web   | 1 hour   | Service ready at `/api/cron/merkle-finalization`. Add CRON_SECRET + vercel.json config. See service file for docs.      |

---

## Complete (Verified)

### Web Platform

#### DAO Management

| Feature             | Status | Migration | Notes                                   |
| ------------------- | ------ | --------- | --------------------------------------- |
| DAO Creation        | ✅     | -         | Commerce/Community presets, 6 org types |
| Profile Management  | ✅     | -         | Skills, timezone, pronouns, visibility  |
| Logo Upload         | ✅     | -         | WebP conversion, security validation    |
| Member Management   | ✅     | -         | Owner/Admin/Member roles, invite flows  |
| Archive/Soft-Delete | ✅     | -         | v2.0 addition                           |
| Search & Discovery  | ✅     | -         | `/api/dao/search`                       |
| QR Code Join        | ✅     | -         | Invite code + QR scanning               |
| Delegation          | ✅     | -         | Voting power delegation                 |

#### Governance

| Feature               | Status | Migration | Notes                                                       |
| --------------------- | ------ | --------- | ----------------------------------------------------------- |
| General Proposals     | ✅     | -         | Full CRUD                                                   |
| Funding Proposals     | ✅     | -         | Treasury request with execution                             |
| Governance Proposals  | ✅     | -         | Settings/governance modifications                           |
| Bounty Proposals      | ✅     | -         | Reward-based with treasury execution                        |
| Simple Voting         | ✅     | -         | Yes/No/Abstain, configurable thresholds                     |
| Ranked Choice Voting  | ✅     | -         | Up to 10 options                                            |
| Quadratic Voting      | ✅     | -         | Credit-based                                                |
| Weighted Voting       | ✅     | -         | Token-weighted                                              |
| Cryptographic Signing | ✅     | -         | EIP-712 typed data signatures                               |
| Vote Delegation       | ✅     | -         | Full/percentage/proposal-specific                           |
| Merkle Voting         | ✅     | 103       | Tree builder, proof API, VoteRegistry on Base (0xD043...99) |
| Proposal Discussion   | ✅     | 029       | Nested comments, reactions                                  |
| Auto-Finalize         | ✅     | -         | Cron endpoint, quorum/threshold logic                       |
| Pending Approvals     | ✅     | -         | Multi-sig treasury approval queue                           |

#### Treasury

| Feature                      | Status | Migration | Notes                                          |
| ---------------------------- | ------ | --------- | ---------------------------------------------- |
| Gnosis Safe Integration      | ✅     | -         | Base Mainnet                                   |
| Transaction Signing          | ✅     | -         | Multi-sig                                      |
| Transaction History          | ✅     | -         | Full audit trail                               |
| Balance View                 | ✅     | -         | Real-time                                      |
| 4-Layer Protection           | ✅     | -         | Status > Freeze > Grace Period > Emergency     |
| 7-Day Grace Period           | ✅     | -         | Critical changes                               |
| Treasury Access Control      | ✅     | -         | `TreasuryAccessControlService`                 |
| Execution Locks              | ✅     | -         | Race condition prevention                      |
| Platform Fee Collection      | ✅     | -         | FeeRouter on Base Mainnet                      |
| Biconomy MEE                 | ✅     | -         | ERC-4337 gas sponsorship v1.1.21               |
| Hybrid Treasury Schema       | ✅     | 101       | Dual rail (fiat+crypto), off-ramp tables       |
| Hybrid Treasury Types        | ✅     | -         | TreasuryRailStatus, OfframpRequest types       |
| Financial Encryption Service | ✅     | -         | AES-256-GCM for sensitive financial data       |
| Financial Audit Log          | ✅     | -         | 7-year retention, append-only with hash        |
| MoonPay Provider             | ✅     | -         | Off-ramp API, quote, webhook handlers          |
| Provider Router Service      | ✅     | -         | Multi-provider routing, region-based           |
| HybridTreasuryService        | ✅     | -         | Unified balance, rail status, enable/disable   |
| Treasury Rails API           | ✅     | -         | GET/PATCH rails status                         |
| Off-ramp API Routes          | ✅     | -         | Initiate, list, sign, execute, cancel          |
| Payment Methods API          | ✅     | -         | GET available methods per DAO                  |
| Treasury Setup Wizard Step   | ✅     | -         | 4-step DAO creation with treasury config       |
| Admin Treasury Rails Toggle  | ✅     | -         | Enable/disable hybrid mode, rail status        |
| User Payout Preferences      | ✅     | 101       | Crypto/bank preference, wallet, notifications  |
| Payout Service               | ✅     | -         | Create, approve, execute payouts               |
| Payout API Routes            | ✅     | -         | GET/PUT preferences, GET payouts               |
| Profile Payments Tab         | ✅     | -         | Payment settings, KYC status, notifications    |
| RecurringPayoutService       | ✅     | 101       | Create, pause, resume, cancel, process due     |
| Recurring Payouts API        | ✅     | -         | CRUD + action endpoints for recurring payouts  |
| Recurring Payouts Cron       | ✅     | -         | Daily processing of due recurring payouts      |
| Recurring Payouts Admin UI   | ✅     | -         | Panel, create modal, pause/resume/cancel       |
| InvoiceService               | ✅     | 101       | Create, update, send, pay, cancel invoices     |
| Invoice API Routes           | ✅     | -         | CRUD, send, pay, status transitions            |
| Invoice Types                | ✅     | -         | Status, line items, payment terms              |
| Invoice List UI              | ✅     | -         | Sent/received tabs, status filter, actions     |
| Create Invoice Modal         | ✅     | -         | Line items, payment terms, recipient selector  |
| useInvoices Hook             | ✅     | -         | CRUD operations with CSRF protection           |
| UnifiedTreasuryDashboard     | ✅     | -         | Combined fiat+crypto balance, rail status      |
| useUnifiedTreasury Hook      | ✅     | -         | Unified balance, rails, hybrid mode actions    |
| Treasury Config Rails Toggle | ✅     | -         | Fixed enableHybrid/disableHybrid API action    |
| TaxReportingService          | ✅     | 102       | W-9 collection, $600 tracking, 1099 generation |
| DAOTaxService                | ✅     | 102       | Per-DAO tax reporting for independent DAOs     |
| Tax Info API                 | ✅     | -         | GET/PATCH W-9 info with encryption             |
| useTaxInfo Hook              | ✅     | -         | W-9 collection, submission state               |
| ProfileTaxInfoSection        | ✅     | -         | W-9 form in Profile > Payments tab             |
| Admin Tax API                | ✅     | -         | Summary, 1099s by year, export for filing      |
| useAdminTaxData Hook         | ✅     | -         | Admin tax dashboard data and actions           |
| TaxReportingPanel            | ✅     | -         | Admin dashboard tab for tax management         |

#### Notifications

| Feature              | Status | Migration | Notes                         |
| -------------------- | ------ | --------- | ----------------------------- |
| In-App Notifications | ✅     | 026, 028  | Bell icon, routing, filtering |
| Email Notifications  | ✅     | -         | Resend, 13+ presets           |
| Voting Reminders     | ✅     | -         | 24h/6h/1h before close        |
| Preferences          | ✅     | -         | Per-category, per-DAO toggles |

#### Discussions

| Feature                | Status | Migration | Notes                     |
| ---------------------- | ------ | --------- | ------------------------- |
| Discussion Creation    | ✅     | 029       | Full CRUD                 |
| Nested Comments        | ✅     | -         | Single-level threading    |
| Reactions              | ✅     | -         | Emoji reactions           |
| Discussion-to-Proposal | ✅     | -         | Convert with edit         |
| Count Tracking         | ✅     | 076       | Denormalized via triggers |

#### Meetings

| Feature               | Status | Migration | Notes                                                |
| --------------------- | ------ | --------- | ---------------------------------------------------- |
| DAO Meeting Link      | ✅     | -         | Recurring Zoom/Meet/Teams link in socialLinks JSONB  |
| Proposal Meeting Link | ✅     | -         | Optional meeting link per proposal in metadata JSONB |

> **Planned**: Full meeting entity, agenda items, meeting → vote pipeline. See Group Management Features section.

#### Donations

| Feature                      | Status | Migration | Notes                                                |
| ---------------------------- | ------ | --------- | ---------------------------------------------------- |
| Fiat-to-Crypto               | ✅     | 091       | Stripe → USDC, standalone success page               |
| Donation Config              | ✅     | -         | Per-DAO settings                                     |
| Donation Stats               | ✅     | -         | Public/private visibility                            |
| Stripe Connect               | ✅     | 094       | Express accounts, direct payouts, Donations Admin UI |
| Stripe Connect Multi-Country | ✅     | 098       | 40+ countries, country selector UI                   |
| Stablecoin Conversion        | ✅     | 095       | MoonPay/Ramp scaffolded, manual fallback             |
| Payment Method Selector      | ✅     | -         | Card vs crypto toggle in donation form               |
| Fee Breakdown Display        | ✅     | -         | Transparent fee transparency UI                      |
| usePaymentMethods Hook       | ✅     | -         | Fetch available payment methods per DAO              |
| Crypto Donation Flow         | ✅     | -         | Treasury address display, copy to donate             |

#### Administration

| Feature                  | Status | Migration | Notes                                                              |
| ------------------------ | ------ | --------- | ------------------------------------------------------------------ |
| Admin Dashboard          | ✅     | -         | Full management UI                                                 |
| Member Management        | ✅     | -         | Promote/demote/remove                                              |
| Activity Logs            | ✅     | -         | 2-year retention                                                   |
| Join Request Review      | ✅     | -         | Approve/reject flow                                                |
| Super Admin Tools        | ✅     | -         | Platform-wide controls                                             |
| Emergency Controls       | ✅     | -         | Freeze/unfreeze                                                    |
| Platform Admin Dashboard | ✅     | -         | Stats, integrity, health                                           |
| Data Integrity Endpoint  | ✅     | -         | Browser-safe API pattern                                           |
| DAO Health Score         | ✅     | -         | Weighted composite metric (member, proposal, treasury, governance) |

#### Onboarding & Help

| Feature              | Status | Migration | Notes                         |
| -------------------- | ------ | --------- | ----------------------------- |
| Onboarding Templates | ✅     | 034, 035  | 6 org types, 34 tags          |
| Guided Tours         | ✅     | 037       | 5 tours, progress persistence |
| Help Center          | ✅     | -         | Role-based docs, HelpModal    |
| Contextual Tooltips  | ✅     | -         | HelpIcon, LabelWithHelp       |

#### Reporting

| Feature              | Status | Migration | Notes                                                    |
| -------------------- | ------ | --------- | -------------------------------------------------------- |
| Report Generation    | ✅     | -         | 5 types: summary, members, proposals, treasury, activity |
| Export Formats       | ✅     | -         | CSV, JSON, PDF                                           |
| Date Range Selection | ✅     | -         | 7d, 30d, 90d, all time                                   |

#### Infrastructure

| Feature                     | Status | Migration | Notes                                                                     |
| --------------------------- | ------ | --------- | ------------------------------------------------------------------------- |
| Cursor-based Pagination     | ✅     | -         | Comments, infinite scroll                                                 |
| Mobile Backend Routes       | ✅     | 093       | Device registration, notification prefs, DAOs, proposals, voting, profile |
| CSRF Protection             | ✅     | -         | Token-based middleware                                                    |
| Rate Limiting               | ✅     | -         | Per-endpoint tiers                                                        |
| Input Validation            | ✅     | -         | Zod + SecurityValidator                                                   |
| Subscription Infrastructure | ✅     | 099       | Stripe Subscriptions API, checkout, portal, webhooks                      |

#### Billing & Subscriptions

| Feature                 | Status | Migration | Notes                                                          |
| ----------------------- | ------ | --------- | -------------------------------------------------------------- |
| Subscription Tiers      | ✅     | 105       | starter/community/organization/enterprise (aligned w/ pricing) |
| Billing Settings Page   | ✅     | -         | /dao/[id]/admin Billing tab, current plan, upgrade options     |
| Stripe Checkout Flow    | ✅     | -         | 14-day trial, annual/monthly, CSRF-protected                   |
| Tier Enforcement        | ✅     | -         | TierEnforcementService, member limits, feature gates           |
| Usage Tracking          | ✅     | 105       | dao_usage_metrics table, sync on member changes                |
| Admin Billing Dashboard | ✅     | -         | /admin/billing - MRR, subscriptions, tier overrides            |
| Billing Audit Log       | ✅     | 105       | billing_audit_log table for admin actions                      |
| Upgrade Prompts         | ✅     | -         | UpgradePrompt, SoftLimitBanner, FeatureGate components         |
| useSubscription Hook    | ✅     | -         | Client-side subscription state + checkout/portal actions       |
| Billing Email Notifs    | ✅     | -         | Welcome, trial ending, payment success/fail, cancellation      |

### Mobile App

| Feature                 | Status | Notes                                                                                                                                         |
| ----------------------- | ------ | --------------------------------------------------------------------------------------------------------------------------------------------- |
| Privy Auth              | ✅     | Email/SMS/wallet login                                                                                                                        |
| DAO List                | ✅     | Pull-to-refresh                                                                                                                               |
| DAO Detail              | ✅     | Stats, header, navigation                                                                                                                     |
| Proposal List           | ✅     | Status filtering                                                                                                                              |
| Proposal Detail         | ✅     | Full view with voting                                                                                                                         |
| User Profile (View)     | ✅     | Display only                                                                                                                                  |
| Settings                | ✅     | Basic settings screen                                                                                                                         |
| Push Notifications      | ✅     | Expo Push, deep linking, badges                                                                                                               |
| Offline Caching         | ✅     | AsyncStorage                                                                                                                                  |
| Offline Action Queue    | ✅     | Network monitoring                                                                                                                            |
| Deep Linking            | ✅     | `endao://dao/:id`                                                                                                                             |
| Theme System            | ✅     | Dark theme, slate palette                                                                                                                     |
| Dev Logger              | ✅     | Console cleanup                                                                                                                               |
| Signed Voting (EIP-712) | ✅     | Full mobile API routes, signature verification                                                                                                |
| Discussion Screens      | ✅     | List + detail screens, comments, API routes                                                                                                   |
| Profile Edit (Basic)    | ✅     | Username, display name, bio editing                                                                                                           |
| DAO Creation            | ✅     | 3-step wizard, 6 presets, API route                                                                                                           |
| Treasury View           | ✅     | Read-only balance, token list, transactions                                                                                                   |
| Member Directory        | ✅     | Paginated list, search, role badges, offline caching                                                                                          |
| Avatar Upload           | ✅     | expo-image-picker, WebP conversion, Supabase storage                                                                                          |
| DAO Logo Upload         | ✅     | Settings screen, expo-image-picker, WebP, admin-only                                                                                          |
| Activity Feed           | ✅     | Paginated feed, offline caching, emoji icons                                                                                                  |
| Treasury Signing        | ✅     | Pending signatures, Privy wallet, multi-sig flow                                                                                              |
| Admin Dashboard         | ✅     | Stats overview, member/proposal/treasury metrics                                                                                              |
| EAS Build Config        | ✅     | `eas.json`, 3 build profiles, default assets. **Needs**: Run `eas init`, replace default assets with branded versions before store submission |
| Unified Balance API     | ✅     | Mobile route for hybrid treasury combined fiat+crypto balance                                                                                 |
| Payment Methods API     | ✅     | Mobile route for available payment methods (card vs crypto)                                                                                   |
| useUnifiedTreasury Hook | ✅     | Mobile hook for fetching hybrid treasury data with caching                                                                                    |
| usePaymentMethods Hook  | ✅     | Mobile hook for fetching payment methods with caching                                                                                         |

---

## Partial / Schema Only

| Feature                   | What Exists               | What's Missing                                        | Priority |
| ------------------------- | ------------------------- | ----------------------------------------------------- | -------- |
| Spending Controls         | Type definitions          | Enforcement logic, UI, API                            | HIGH     |
| Stripe Connect Disconnect | Webhook endpoint exists   | `account.application.deauthorized` handler, UI button | MEDIUM   |
| Stripe Connect Fraud      | Basic implementation      | Radar for Platforms, risk scoring, reserve holds      | MEDIUM   |
| MFA                       | Encryption service, types | Full service, auth integration, UI                    | MEDIUM   |

---

## Mobile-Web Feature Parity Gap

**Analysis Date**: February 10, 2026 | **Gap**: 36 features

> Mobile app currently provides read-heavy functionality. These features exist on web but are missing from mobile.

### High Priority (Core UX)

| Feature                      | Web Implementation               | Mobile Effort | Notes                   |
| ---------------------------- | -------------------------------- | ------------- | ----------------------- |
| Join DAO                     | Search + join flow, invite codes | 3-4 days      | Critical for growth     |
| Leave DAO                    | Settings > Leave DAO             | 1 day         | Required for parity     |
| Create Proposal (General)    | Full wizard                      | 3-4 days      | Core governance         |
| Create Proposal (Funding)    | Treasury request with amount     | 2 days        | After general proposals |
| Create Proposal (Governance) | Settings modification            | 2 days        | After general proposals |
| Create Proposal (Bounty)     | Reward-based                     | 2 days        | After general proposals |
| Create Discussion            | Title + content form             | 2 days        | Community engagement    |
| Add Discussion Comment       | Threaded replies                 | 1 day         | After discussion detail |
| DAO Search/Discovery         | Search bar, filters              | 2-3 days      | Exploration             |

### Medium Priority (Power Features)

| Feature                  | Web Implementation         | Mobile Effort | Notes               |
| ------------------------ | -------------------------- | ------------- | ------------------- |
| Invite Members           | Generate link, QR code     | 2 days        | Admin feature       |
| QR Code Join             | Camera + join flow         | 2 days        | Needs expo-camera   |
| Member Role Management   | Promote/demote/remove      | 2-3 days      | Admin only          |
| Join Request Review      | Approve/reject queue       | 2 days        | Admin only          |
| Voting Delegation        | Delegate to another member | 2 days        | Advanced governance |
| Vote on Behalf           | Use delegated power        | 1 day         | After delegation    |
| Discussion Reactions     | Emoji reactions            | 1 day         | Engagement          |
| Discussion Pin/Archive   | Admin controls             | 1 day         | Admin feature       |
| Notification Preferences | Per-category toggles       | 2 days        | API exists          |

### Lower Priority (Admin/Advanced)

| Feature                  | Web Implementation          | Mobile Effort | Notes                 |
| ------------------------ | --------------------------- | ------------- | --------------------- |
| Report Generation        | Summary, members, proposals | 3-4 days      | Share/export          |
| Activity Logs (Full)     | Filterable history          | 2 days        | Detailed view         |
| Guided Tours             | 5 onboarding tours          | 3-4 days      | react-native-tooltip  |
| Help Center Access       | Role-based docs             | 1-2 days      | Link to web or native |
| Spending Controls Config | Limits, categories          | 2-3 days      | After web complete    |

### Treasury (Deferred - Security Review Required)

| Feature                      | Web Implementation     | Mobile Effort | Notes                |
| ---------------------------- | ---------------------- | ------------- | -------------------- |
| Create Treasury Transaction  | Initiate spending      | 3-4 days      | Security critical    |
| Execute Treasury Transaction | On-chain execution     | 2-3 days      | Biconomy integration |
| Treasury Config              | Fee settings, controls | 2 days        | Admin only           |

### Web-Only (May Remain Web-Only)

| Feature               | Reason                  |
| --------------------- | ----------------------- |
| Super Admin Dashboard | Internal tool           |
| Platform Admin        | Internal tool           |
| Full Donation Flow    | Web checkout experience |
| Stripe Connect Setup  | OAuth flow              |

---

## Backlog

### Mobile Hardening (US Track)

| Feature                   | Effort  | Notes                                            |
| ------------------------- | ------- | ------------------------------------------------ |
| expo-sqlite + Drizzle ORM | 1 week  | Replace AsyncStorage, type-safe queries          |
| MMKV Key-Value Storage    | 2 days  | Auth tokens, preferences, 30x faster             |
| Biometric Security        | 1 week  | react-native-biometrics, Keystore/Secure Enclave |
| Certificate Pinning       | 2 days  | network_security_config + SSL pinning            |
| Maestro E2E Tests         | 1 week  | Critical flow automation                         |
| Custom Sync Engine        | 2 weeks | Outbox pattern, conflict resolution              |

### Mobile Scale (US Track)

| Feature                | Effort  | Notes                            |
| ---------------------- | ------- | -------------------------------- |
| Stripe In-App Payments | 2 weeks | Contributions, membership fees   |
| EU/UK Market Configs   | 1 week  | Cookie consent, GBP/EUR markets  |
| Foldable/Large Screen  | 1 week  | Required by Google Play Aug 2026 |

### Africa Track (PWA First)

| Feature                 | Effort  | Notes                                                                 |
| ----------------------- | ------- | --------------------------------------------------------------------- |
| PWA Baseline            | 2 weeks | Serwist, manifest, app shell caching                                  |
| Flutterwave Integration | 2 weeks | MTN MoMo, Ghana first market                                          |
| Wise Business API       | 2 weeks | 50+ countries, 40+ currencies, mid-market FX, fallback for non-Stripe |
| Offline Write Queue     | 1 week  | IndexedDB queue, Background Sync                                      |
| Bandwidth Optimization  | 1 week  | Lazy-load, WebP, paginated defaults                                   |
| Touch Target Compliance | 3 days  | 56dp minimum, AAA contrast                                            |

### International Payment Rails

| Feature               | Effort  | Notes                                                        |
| --------------------- | ------- | ------------------------------------------------------------ |
| Wise Business Payouts | 2 weeks | API integration, batch payouts, 50+ countries                |
| Payment Rail Router   | 1 week  | Auto-select Stripe → Wise → Crypto-only based on DAO country |

### Tier 2: Operational Excellence (Q2-Q3 2026)

| Feature                    | Effort  | Notes                                                                |
| -------------------------- | ------- | -------------------------------------------------------------------- |
| Lazy Consensus             | 2 weeks | Auto-pass proposals unless objected; configurable timeframe (24-72h) |
| Member Wallet View         | 1 week  | Memberships, voting history                                          |
| Plain Language Abstraction | 2 weeks | Terminology mapping                                                  |
| Public API                 | 3 weeks | OpenAPI spec, developer portal                                       |
| Scheduled Reports          | 1 week  | Weekly/monthly email delivery                                        |

### Tier 3: Network Effects (Q3-Q4 2026)

**Vision: "Shared money today, sovereign networks tomorrow"** — See `docs/strategy/ENDAO_MARKETING_STRATEGY.md` for full context.

| Phase | Feature                     | Effort  | Notes                                                      |
| ----- | --------------------------- | ------- | ---------------------------------------------------------- |
| 1     | Public DAO Profiles         | 2 weeks | Verification badges, enhanced discovery, trust signals     |
| 2     | DAO Connections             | 2 weeks | Follow (one-way), Connect (two-way w/ governance approval) |
| 3     | Cross-DAO Proposals         | 4 weeks | External proposals, joint approval workflows               |
| 4     | Inter-DAO Treasury          | 4 weeks | DAO-to-DAO payments with identity, proposal-linked, escrow |
| 5     | Federation Protocol         | 6 weeks | DAO-of-DAOs, network-level governance, on-chain registry   |
| -     | Commerce vs Community Split | 2 weeks | DAO type detection, consent governance                     |
| -     | Sub-DAO Architecture        | 3 weeks | Parent-child, permission inheritance                       |

**Open Design Questions (resolve before implementation):**

| Question                 | Context                                                                                          | Options to Explore                                                                                                 |
| ------------------------ | ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| Lazy consensus mechanics | Colony-inspired auto-pass governance (see `obsidian/Research/COMPETITIVE_ANALYSIS_MASTER.md`)    | Default objection period (24h/48h/72h), who can object (any member vs quorum), per-DAO vs per-proposal-type config |
| Slug stability           | If DAO name changes, what happens to `/org/[slug]` URLs?                                         | Immutable slugs vs redirects vs allow changes with cooldown                                                        |
| DAO verification         | KYC verifies humans; what verifies an organization?                                              | Domain ownership, social proof, governance activity thresholds, third-party attestation                            |
| Trust signal calculation | Raw stats exist (members, proposals, activity) but no composite score                            | Activity tiers (dormant/active/thriving), weighted formula, decay over time                                        |
| Private DAO UX           | Mechanics exist (`isDiscoverable=false` + `joinPermission='invite-only'`) but UX clarity unclear | Onboarding flow improvements, explicit "private org" template                                                      |
| What users expect        | Need to research existing tools (LinkedIn, Slack workspaces, Discord servers)                    | Competitive UX audit before Phase 1                                                                                |

### Tier 4: Enterprise (2027+)

| Feature               | Notes                               |
| --------------------- | ----------------------------------- |
| Enterprise Dashboard  | Unified sub-DAO management          |
| Regulatory Compliance | 1099, KYC/AML                       |
| White-label           | Custom domains, branding            |
| Network Marketplace   | DAO discovery, partnership matching |

### AI Features

> **AI-Enhanced Group Management** — These features have AI components integrated into the Group Management track above.

| Feature                     | Integration Point | AI Capability                                                               | Priority |
| --------------------------- | ----------------- | --------------------------------------------------------------------------- | -------- |
| Decision Summarizer         | Decision Journal  | Auto-generate plain-language summary of what was decided and why            | HIGH     |
| Meeting Minutes Generator   | Meeting Entity    | Generate structured minutes from agenda outcomes and discussion notes       | HIGH     |
| Task Suggester              | Task Tracking     | Suggest action items from passed proposals ("This decision may require...") | MEDIUM   |
| Document Metadata Extractor | Document Linking  | Extract title, type, summary from linked documents                          | LOW      |
| Proposal Draft Assistant    | Meeting → Vote    | Pre-fill proposal from agenda item discussion                               | MEDIUM   |

#### Standalone AI Features (Deferred)

| Category             | Count | Notes                                          |
| -------------------- | ----- | ---------------------------------------------- |
| Conversational Suite | 5     | Summarizer, Translator, Q&A, Draft, Onboarding |
| Utility Suite        | 12    | Automator, Enforcer, Router, etc.              |

---

## Technical Debt

| Item                              | Impact         | Status         |
| --------------------------------- | -------------- | -------------- |
| 371 `no-explicit-any` warnings    | Code quality   | Boy Scout Rule |
| Consolidate toast implementations | UX consistency | Backlog        |
| Webhook delivery service          | Extensibility  | Schema only    |
| Audit retention tier enforcement  | Compliance     | Field only     |

---

## Architecture Refactor Progress (February 2026)

Major architecture refactor to address 14 identified issues before production user onboarding.

### Phase 1: Foundation ✅

| Item                                | Status | Notes                                                            |
| ----------------------------------- | ------ | ---------------------------------------------------------------- |
| Discriminated union ServiceResponse | ✅     | `src/lib/types/api-response.ts` - mutually exclusive data/error  |
| Error classification system         | ✅     | `src/lib/errors/error-types.ts` - standardized error codes       |
| Branded ID types                    | ✅     | `src/lib/types/branded-ids.ts` - type-safe UserId, DAOId, etc.   |
| Invoice admin repository            | ✅     | `src/lib/data/repositories/supabase/invoice-admin.repository.ts` |
| Tax admin repository                | ✅     | `src/lib/data/repositories/supabase/tax-admin.repository.ts`     |
| Payout admin repository             | ✅     | `src/lib/data/repositories/supabase/payout-admin.repository.ts`  |
| Stats admin repository              | ✅     | `src/lib/data/repositories/supabase/stats-admin.repository.ts`   |

### Phase 2: Cleanup ✅

| Item                           | Status | Notes                                                                       |
| ------------------------------ | ------ | --------------------------------------------------------------------------- |
| Deprecated services identified | ✅     | 20+ services marked @deprecated per ADR-006                                 |
| Dead code removal              | ✅     | 11 notification files deleted (no active callers found)                     |
| Pattern standardization        | ✅     | 6 key services: testability methods added (createForTesting, resetInstance) |

### Phase 3: Consolidation ✅

| Item                               | Status | Notes                                                                      |
| ---------------------------------- | ------ | -------------------------------------------------------------------------- |
| Activity service consolidation     | ✅     | 6 focused files under 500 lines each - orchestrator + specialized services |
| Notification service consolidation | ✅     | 37→27 files (27% reduction) - merged utilities, processor                  |
| Circular dependency resolution     | ✅     | 6 of 10 cycles fixed (60%) - type extraction pattern                       |
| Detection scripts added            | ✅     | `scripts/detect-circular-deps.js`, `scripts/check-repo-circular-deps.js`   |
| Treasury consolidation             | ✅     | 49→40 files (ledger 5→4, validators 2→1, orchestrators 3→1)                |

### Phase 4: Quality ✅

| Item                               | Status | Notes                                                                                               |
| ---------------------------------- | ------ | --------------------------------------------------------------------------------------------------- |
| jest-mock-extended installed       | ✅     | Type-safe mocking for tests                                                                         |
| Testable service base class        | ✅     | `src/lib/services/testable-service.base.ts`                                                         |
| Service test template              | ✅     | `src/lib/services/__tests__/service-testing.template.ts`                                            |
| Repository type errors fixed       | ✅     | Dynamic table access with type assertions                                                           |
| Supabase types updated             | ✅     | Added invoices, recurring_payouts, payout_executions                                                |
| TreasuryService testability        | ✅     | `createForTesting()`, `resetInstance()` methods                                                     |
| DAOService testability             | ✅     | DI pattern for mocking in tests                                                                     |
| ProposalService testability        | ✅     | DI pattern for mocking in tests                                                                     |
| NotificationService testability    | ✅     | DI pattern for mocking in tests                                                                     |
| UserProfileCrudService testability | ✅     | DI pattern for mocking in tests                                                                     |
| Additional service testability     | ✅     | SafeSigning, KYCStatus, ExecutionEngine, VotingEngine, TreasurySafeOrchestrator, NotificationRouter |
| API route ServiceResponse patterns | ✅     | 5 representative files fixed, pattern documented                                                    |

### Phase 5: Performance & Polish ✅

| Item                                    | Status | Notes                                                                          |
| --------------------------------------- | ------ | ------------------------------------------------------------------------------ |
| Voting engine split                     | ✅     | 774→373 lines orchestrator, +vote-casting.service.ts, +vote-audit.service.ts   |
| Invoice service split                   | ✅     | 748→261 lines (4 files: +lifecycle, +query, +mapper)                           |
| DAO crud service split                  | ✅     | 749→612 lines (mapper extracted: 150)                                          |
| DAO index.ts                            | ✅     | 861 lines - kept as orchestrator (well-structured delegation)                  |
| Activity aggregation split              | ✅     | 1263→261 lines (+metrics 267, +reports 328, +trends 363, +export 420)          |
| Large file splitting                    | ✅     | All identified files addressed                                                 |
| ServiceResponse type fixes - Core       | ✅     | Treasury (7 files), UserService, username.service, kyc-status, middleware      |
| ServiceResponse type fixes - Services   | ✅     | payout, invoice, tax, notification, DAO, conversion, donation services         |
| ServiceResponse type fixes - API Routes | ✅     | 30+ API routes fixed (treasury, mobile, dao, proposals)                        |
| ServiceResponse type fixes - Components | ✅     | bounty-panel, treasury dashboard, signing modal, error boundary                |
| Type errors remaining                   | ✅     | 0 in source, 181 in test files (lower priority)                                |
| Denormalized field - member_count       | ✅     | joinDAO/leaveDAO now use atomic RPC (increment/decrement_member_count)         |
| Denormalized field - active_proposals   | ✅     | Migration 091: dao_proposal_counts materialized view with CONCURRENTLY refresh |

**ServiceResponse Migration**: ✅ Complete (654 → 0 errors)

**Large File Splitting**: ✅ Complete

- Invoice: 748 → 261 lines (4 files: +lifecycle, +query, +mapper)
- DAO CRUD: 749 → 612 lines (mapper extracted)
- DAO Index: 861 lines (kept - well-structured orchestrator)
- Activity Aggregation: 1263 → 261 lines (4 files: +metrics, +reports, +trends, +export)

**Type Patterns Documented**: See CLAUDE.md "Type Patterns (CRITICAL)" section for fix patterns.

**Legend**: ✅ Complete | 🔄 In Progress | ⏸️ Paused | 📋 Planned

---

## Codebase Metrics

| Metric              | Value |
| ------------------- | ----- |
| Lines of TypeScript | ~252K |
| API Routes          | 140   |
| Database Migrations | 105   |
| Test Files          | 92    |
| CI/CD Workflows     | 7     |
| TypeScript Errors   | 0     |
| ESLint Errors       | 0     |

---

## Version History

| Version | Date     | Milestone                                                                                |
| ------- | -------- | ---------------------------------------------------------------------------------------- |
| v1.0.0  | Jun 2025 | Initial production launch                                                                |
| v2.0.0  | Jul 2025 | Ethers v6 migration                                                                      |
| v2.1.0  | Aug 2025 | Platform revenue system                                                                  |
| v2.2.0  | Jan 2026 | Treasury protection + enhanced security                                                  |
| v2.2.1  | Feb 2026 | Tier 1 tech debt complete                                                                |
| v2.2.3  | Feb 2026 | Donation flow fix for anonymous donors                                                   |
| v2.3.0  | Feb 2026 | Hybrid Treasury Phase A+B complete                                                       |
| v2.3.1  | Feb 2026 | Hybrid Treasury Phase C complete                                                         |
| v2.3.2  | Feb 2026 | Tax Reporting UI (W-9, Admin Dashboard)                                                  |
| v2.3.3  | Feb 2026 | Group Management Features planned (Decision Journal, Meetings, Tasks)                    |
| v2.4.0  | Feb 2026 | Subscription Billing: Stripe checkout, tier enforcement, admin dashboard, billing emails |

---

## Related Documents

| Document                                                                              | Purpose                                   |
| ------------------------------------------------------------------------------------- | ----------------------------------------- |
| [PLATFORM_ROADMAP.md](/PLATFORM_ROADMAP.md)                                           | Strategic vision, tier descriptions       |
| [TOKEN_ROADMAP.md](/TOKEN_ROADMAP.md)                                                 | EDG/TCR/TEQ token phases                  |
| [GROUP_MANAGEMENT_FEATURES_PLAN.md](/docs/planning/GROUP_MANAGEMENT_FEATURES_PLAN.md) | Group management feature specs + research |
| [MOBILE_STRATEGY.md](/docs/research/mobile/MOBILE_STRATEGY.md)                        | Mobile dual-track strategy                |
| [MOBILE_UI_UX_RESEARCH.md](/docs/mobile/MOBILE_UI_UX_RESEARCH.md)                     | UI/UX upgrade research                    |
| [PLATFORM_AUDIT.md](/docs/architecture/PLATFORM_AUDIT_2026_02.md)                     | Periodic snapshot                         |

---

## Last Updated

February 28, 2026

---

_This is the single source of truth for development status. Update this document, not others._
