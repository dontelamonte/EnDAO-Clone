# Complexity Refactoring Plan

> **Created**: December 16, 2025
> **Status**: Active
> **Priority**: Based on impact and effort analysis

## Executive Summary

Analysis of the 274 functions with cyclomatic complexity >10 identified 8 high-priority files (complexity 67-124) requiring refactoring. Most complexity is **ACCIDENTAL** (poor state organization, code duplication) rather than **JUSTIFIED** (inherent domain complexity).

## Priority Matrix

| Priority | File                           | Complexity | Classification | Effort | Reduction |
| -------- | ------------------------------ | ---------- | -------------- | ------ | --------- |
| HIGH     | enhanced-profile-page.tsx      | 124        | ACCIDENTAL     | 2-3h   | 40%       |
| HIGH     | proposal-discussion.tsx        | 92         | MIXED          | 3-4h   | 35%       |
| HIGH     | management-panel.tsx           | 88         | ACCIDENTAL     | 4-5h   | 50%       |
| HIGH     | system-dashboard-context.tsx   | 82         | ACCIDENTAL     | 5-6h   | 60%       |
| MEDIUM   | treasury-execution-context.tsx | 77         | MIXED          | 2-3h   | 30%       |
| MEDIUM   | use-dao-admin-handlers.ts      | 74         | ACCIDENTAL     | 3-4h   | 45%       |
| MEDIUM   | profile-form-context.tsx       | 72         | ACCIDENTAL     | 3-4h   | 40%       |
| MEDIUM   | use-treasury-execution.ts      | 67         | MIXED          | 3-4h   | 50%       |

## Refactoring Patterns

### Pattern 1: State Consolidation

**Problem**: Multiple useState calls for related data
**Solution**: Single nested state object with typed updater

```typescript
// BEFORE: 14 separate state slices
const [emailPlatformNotifications, setEmailPlatformNotifications] = useState({...})
const [emailDaoNotifications, setEmailDaoNotifications] = useState({...})
// ...12 more

// AFTER: Single consolidated state
const [notifications, setNotifications] = useState<NotificationPreferences>({
  email: { platform: {...}, dao: {...} },
  push: { platform: {...}, dao: {...} }
})
```

**Applies to**: enhanced-profile-page.tsx, proposal-discussion.tsx, profile-form-context.tsx

### Pattern 2: Handler Factory

**Problem**: Repetitive handler functions with identical structure
**Solution**: Generic handler factory

```typescript
// BEFORE: 6 handlers with same try/catch structure
const handleClearCache = async () => { ... }
const handleIntegrityCheck = async () => { ... }
// ...4 more identical patterns

// AFTER: Factory function
const createSystemAction = (config: SystemActionConfig) => async () => {
  state.setActionLoading(config.id)
  try {
    await config.handler()
    state.setActionResult({ action: config.successLabel, status: 'success' })
  } catch (err) {
    state.setActionResult({ action: config.errorLabel, status: 'error' })
  } finally {
    state.setActionLoading(null)
  }
}
```

**Applies to**: management-panel.tsx, use-dao-admin-handlers.ts

### Pattern 3: Service Layer Extraction

**Problem**: Business logic in React components/contexts
**Solution**: Extract to service layer

```typescript
// BEFORE: 130+ lines of business logic in provider
const searchMembers = async () => {
  // Supabase queries, type conversions, nested loops...
};

// AFTER: Thin provider delegating to service
const value = {
  memberSearchResults,
  loadMemberData: async () => {
    const results = await MemberDataService.searchMembers();
    setMemberSearchResults(results);
  },
};
```

**Applies to**: system-dashboard-context.tsx

### Pattern 4: Shared Utility Extraction

**Problem**: Duplicate code between context and hook versions
**Solution**: Extract shared utilities

```typescript
// CREATE: treasury-execution.utils.ts
export async function fetchSignatures(executionId: string) { ... }
export function convertTreasuryExecutionFromDb(row, signatures) { ... }

// BOTH files import from utils
import { fetchSignatures, convertTreasuryExecutionFromDb } from './treasury-execution.utils'
```

**Applies to**: treasury-execution-context.tsx, use-treasury-execution.ts

### Pattern 5: Custom Hook Extraction

**Problem**: Complex logic inline in components
**Solution**: Extract to focused custom hooks

```typescript
// BEFORE: Inline mention autocomplete logic (50+ lines)
// AFTER:
const { suggestions, showDropdown, handleMentionChange } =
  useMentionAutocomplete(content, daoId);
```

**Applies to**: proposal-discussion.tsx, enhanced-profile-page.tsx

## Implementation Phases

### Phase 1: Quick Wins (Week 1)

- [ ] Extract treasury utilities (2h) - Eliminates ~200 lines duplication
- [ ] Add CSRF helper function (1h) - Removes 3x repeated checks
- [ ] Consolidate notification state in profile (3h) - 40% reduction

### Phase 2: High-Impact Refactoring (Week 2)

- [ ] Create SystemAction abstraction for management panel (5h)
- [ ] Extract useMentionAutocomplete hook (3h)
- [ ] Move system-dashboard business logic to services (6h)

### Phase 3: Context/Hook Consolidation (Week 3)

- [ ] Choose hook vs context pattern for treasury execution
- [ ] Eliminate profile-form-context duplication
- [ ] Refactor use-dao-admin-handlers with decomposed functions

## Files Requiring Exemption

These files legitimately exceed limits due to their nature:

| File                        | Lines   | Reason                       | Action             |
| --------------------------- | ------- | ---------------------------- | ------------------ |
| `src/app/docs/content.tsx`  | 2,284   | Static documentation content | Add CI exemption   |
| `src/lib/supabase/types.ts` | 1,123   | Generated types              | Add CI exemption   |
| `*.test.ts`, `*.test.tsx`   | Various | Test files often large       | Add glob exemption |

## Success Metrics

| Metric                        | Current | Target | Timeline |
| ----------------------------- | ------- | ------ | -------- |
| Functions with complexity >50 | 20      | 5      | 3 weeks  |
| Functions with complexity >10 | 274     | <150   | 6 weeks  |
| Files >500 lines              | 88      | <50    | 4 weeks  |
| Average function complexity   | ~15     | <8     | 6 weeks  |

## Risk Mitigation

1. **Test Coverage**: Ensure E2E tests cover all refactored features before changes
2. **Incremental Changes**: One component at a time, PR per pattern
3. **Feature Flags**: Use flags for major refactoring if needed
4. **Rollback Plan**: Git branches allow quick revert if issues arise

---

_This plan is a living document. Update as refactoring progresses._
