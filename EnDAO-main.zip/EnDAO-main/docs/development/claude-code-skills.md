# Claude Code Skills Reference

## Purpose

Comprehensive guide for understanding and working with activated Claude Code skills in the EnDAO project. Skills provide proactive guidance during development to maintain code quality, security, and documentation standards.

## Last Updated

October 30, 2025

---

## Overview

EnDAO has **5 active Claude Code skills** that provide proactive guidance during development. These skills auto-activate based on triggers and help maintain code quality, security, and documentation standards without manual intervention.

**Skills operate in real-time** during development, providing:

- Instant feedback on code changes
- Automated validation against project standards
- Intelligent suggestions for improvements
- Prevention of common issues before commit

---

## Active Skills

### 1. Treasury Validator

**Purpose**: Validates treasury operations follow the 4-layer protection system

**Auto-Activation Triggers**:

- Modifying treasury service files (`src/lib/services/treasury/**/*`)
- Creating new treasury operations or API routes
- Working on treasury-related components
- Keywords: "treasury", "Safe", "multi-sig", "execute", "sign"

**What It Validates**:

- ✅ Layer 1: DAO status validation (must be 'active')
- ✅ Layer 2: Treasury freeze management
- ✅ Layer 3: Grace period protection (7-day window)
- ✅ Layer 4: Emergency recovery capabilities
- ✅ Complete audit trail logging
- ✅ Privy wallet authentication
- ✅ Safe SDK integration best practices

**Example Alert**:

```
🚨 TREASURY SECURITY ISSUE DETECTED

File: src/app/api/treasury/create-transaction/route.ts
Line: 45

Issue: Missing TreasuryAccessControlService.validateTreasuryOperation() call

Impact: CRITICAL - Treasury operation bypasses 4-layer protection system
Risk: Unauthorized treasury access, potential fund loss

Required Fix:
1. Add protection validation before transaction creation
2. Check DAO status (must be 'active')
3. Verify treasury not frozen
4. Check grace period status
5. Add comprehensive audit logging

Example Implementation:
const protection = await treasuryAccessControlService.validateTreasuryOperation(
  daoId, userId, 'create_transaction', authContext
)

if (!protection.success) {
  return { error: protection.data?.accessStatus.reason }
}
```

**When to Override**:

- Never bypass 4-layer protection for treasury operations
- Emergency recovery must use dedicated service methods
- All overrides require super admin privileges + audit logging

---

### 2. File Size Enforcer

**Purpose**: Enforces file size limits and suggests refactoring patterns

**Auto-Activation Triggers**:

- Creating new `.tsx` or `.ts` files
- Modifying existing files approaching size limits
- File exceeds 300 lines (warning)
- File exceeds 800 lines (error, blocks commit)
- Keywords: "refactor", "split", "extract", "organize"

**Size Standards**:

- 🎯 **Target**: <300 lines (ideal)
- ⚠️ **Warning**: 500-800 lines (suggest refactoring)
- 🚨 **Error**: >800 lines (blocks commit)
- 📊 **Functions**: <100 lines each
- 🔢 **Complexity**: <10 cyclomatic complexity

**Refactoring Patterns Suggested**:

1. **Compound Components** (for large React components)

   ```typescript
   // Before: 650-line component
   export function DAOSettings() { /* 650 lines */ }

   // After: Compound component pattern
   export function DAOSettings() {
     return (
       <DAOSettingsProvider>      // Shared context
         <SettingsHeader />       // 50 lines
         <GeneralSettings />      // 150 lines
         <GovernanceSettings />   // 150 lines
       </DAOSettingsProvider>
     )
   }
   ```

2. **Service Orchestration** (for large service files)

   ```typescript
   // Before: 850-line service
   export class ProposalService { /* 850 lines */ }

   // After: Service orchestration
   services/proposal/
   ├── index.ts              // 100 lines (orchestrator)
   ├── proposal-crud.service.ts       // 200 lines
   ├── proposal-query.service.ts      // 250 lines
   ├── proposal-voting.service.ts     // 200 lines
   └── proposal-validation.service.ts // 150 lines
   ```

3. **Lazy Loading** (for non-critical components >400 lines)

   ```typescript
   const LazyAdminPanel = lazy(() =>
     import('@/components/lazy/admin-panel')
   )

   <LazyWrapper fallback={<Skeleton />}>
     <LazyAdminPanel />
   </LazyWrapper>
   ```

**Example Alert**:

```
📏 FILE SIZE WARNING

File: src/components/dao/settings/dao-settings-content.tsx
Current: 650 lines
Target: <300 lines
Status: ⚠️ WARNING (commit will be blocked at 800 lines)

Recommended Pattern: Compound Components

Refactoring Plan:
1. Create DAOSettingsProvider context (80 lines)
2. Extract GeneralSettingsSection → general-settings.tsx (150 lines)
3. Extract GovernanceSettingsSection → governance-settings.tsx (150 lines)
4. Extract MemberManagementSection → member-management.tsx (120 lines)
5. Keep DAOSettingsContent as orchestrator (150 lines)

Result: 5 files, all <300 lines, better organization

Would you like me to perform this refactoring? (y/n)
```

**When to Override**:

- Generated files (add comment: `// @file-size-enforcer-exempt: Generated types`)
- Type definition aggregators
- Configuration files with extensive enums
- Must provide justification in comment

---

### 3. Test Coverage Guardian

**Purpose**: Ensures new features have corresponding tests

**Auto-Activation Triggers**:

- Creating new service files (`src/lib/services/**/*.ts`)
- Creating new API routes (`src/app/api/**/route.ts`)
- Creating new hooks (`src/hooks/**/*.ts`)
- Creating new components (`src/components/**/*.tsx`)
- Keywords: "implement", "create", "new feature"

**Coverage Requirements**:

- 📊 **Services**: 80% unit test coverage minimum
- 🌐 **API Routes**: 100% coverage (all endpoints must be tested)
- 🎣 **Hooks**: 70% coverage minimum
- 🎨 **Components**: 60% coverage (critical components 80%)
- 🔄 **Critical Paths**: Treasury, auth, proposals must have E2E tests

**What It Does**:

1. **Detects missing test files** when new code is created
2. **Auto-scaffolds test files** with proper structure and mocks
3. **Identifies untested functions** in existing test files
4. **Suggests test cases** for new functionality

**Test File Patterns**:

```
src/
├── lib/services/dao/
│   ├── dao-crud.service.ts
│   └── __tests__/
│       └── dao-crud.service.test.ts
├── app/api/treasury/create/
│   ├── route.ts
│   └── __tests__/
│       └── route.test.ts
├── hooks/dao/
│   ├── use-dao-admin.ts
│   └── __tests__/
│       └── use-dao-admin.test.ts
```

**Example Alert**:

```
🧪 TEST COVERAGE ALERT

File: src/lib/services/treasury/treasury-admin-management.service.ts
Status: ❌ NO TESTS FOUND
Coverage: 0%
Target: 80%

Missing Test File: src/lib/services/treasury/__tests__/treasury-admin-management.service.test.ts

Detected Functions Requiring Tests:
1. createTreasury (Lines 45-120)
2. addOwner (Lines 125-180)
3. removeOwner (Lines 185-240)
4. updateThreshold (Lines 245-290)
5. validateTreasuryOperation (Lines 295-350)

Scaffold Test File? (y/n)
```

**Auto-Scaffolded Test Template**:

```typescript
import { describe, it, expect, beforeEach, jest } from '@jest/globals';
import { TreasuryAdminService } from '../treasury-admin-management.service';

// Mock dependencies
jest.mock('@/lib/supabase/client');

describe('TreasuryAdminService', () => {
  let service: TreasuryAdminService;

  beforeEach(() => {
    service = new TreasuryAdminService();
    jest.clearAllMocks();
  });

  describe('createTreasury', () => {
    it('should create treasury with valid data', async () => {
      // TODO: Implement test
    });

    it('should validate 4-layer protection', async () => {
      // TODO: Implement test
    });
  });
});
```

**When to Override**:

- Legacy code being phased out (add comment explaining)
- Pure TypeScript types (no logic to test)
- Simple pass-through functions
- Must document why tests are not needed

---

### 4. Database Security Auditor

**Purpose**: Validates database queries for security vulnerabilities

**Auto-Activation Triggers**:

- Writing Supabase queries (`supabase.from()`, `.select()`, etc.)
- Modifying RLS policies (Row Level Security)
- Creating API routes that access database
- Keywords: "query", "where", "select", "from", "security", "RLS"

**Security Checks**:

- 🔒 **DAO Isolation**: All queries must filter by `daoId`
- 👤 **User Authorization**: Server-side permission validation
- 🚫 **Information Disclosure**: Generic error messages only
- 📝 **Audit Logging**: Sensitive operations must log
- ✅ **Input Validation**: Sanitize all user inputs
- ⚡ **Rate Limiting**: Write operations must have limits

**Common Vulnerabilities Detected**:

1. **Cross-DAO Data Leakage**

   ```typescript
   // ❌ BAD: No DAO filter
   const { data: proposals } = await supabase.from('proposals').select();

   // ✅ GOOD: Filtered by DAO
   const { data: proposals } = await supabase
     .from('proposals')
     .select()
     .eq('dao_id', daoId);
   ```

2. **Missing Authorization**

   ```typescript
   // ❌ BAD: Client-side check only
   if (user.isAdmin) {
     await deleteProposal(id);
   }

   // ✅ GOOD: Server-side validation
   const isAdmin = await adminService.validateAdmin(userId, daoId);
   if (!isAdmin) {
     throw new Error('Unauthorized');
   }
   ```

3. **Information Disclosure**

   ```typescript
   // ❌ BAD: Exposes internal errors
   catch (error) {
     return { error: error.message, stack: error.stack }
   }

   // ✅ GOOD: Generic user message
   catch (error) {
     console.error('Database error:', error)
     return { error: 'Unable to retrieve data. Please try again.' }
   }
   ```

**Example Alert**:

```
🔒 SECURITY VULNERABILITY DETECTED

File: src/lib/services/proposal/proposal-query.service.ts
Line: 45
Severity: CRITICAL

Vulnerability: Cross-DAO Data Leakage
Pattern: supabase.from('proposals').select()

Issue: Missing DAO filter allows access to proposals from all DAOs

Impact:
- Users can see proposals from DAOs they don't belong to
- Potential privacy breach
- Violates multi-tenancy isolation

Required Fix:
1. Add DAO filter to query: .eq('dao_id', daoId)
2. Verify user is DAO member before query
3. Add audit logging for proposal access

Example Implementation:
async function getProposals(daoId: string, userId: string) {
  const isMember = await verifyDAOMembership(userId, daoId)
  if (!isMember) {
    throw new Error('Unauthorized: Not a DAO member')
  }

  const { data: proposals } = await supabase
    .from('proposals')
    .select('*')
    .eq('dao_id', daoId)

  return proposals
}
```

**When to Override**:

- Super admin operations with explicit justification
- System-wide queries for analytics (must be admin-only)
- Migration scripts (must be run manually with review)
- Must document override reason + security review

---

### 5. Documentation Governance (NEW)

**Purpose**: Enforces documentation standards and prevents sprawl

**Auto-Activation Triggers**:

- Creating `.md` files in `docs/` directory
- Modifying existing documentation
- New directory creation in `docs/`
- Keywords: "document", "guide", "README", "wiki"

**What It Enforces**:

**Required Sections** (for files >10 lines):

```markdown
# Title

## Purpose

Clear explanation of document purpose

## Last Updated

October 30, 2025

---

[Content here]
```

**Naming Conventions**:

- ✅ `kebab-case.md` for guides
- ✅ `UPPERCASE_WORDS.md` for top-level docs
- ✅ `README.md` for directory overviews
- ❌ NO spaces in filenames
- ❌ NO version numbers (use git history)

**Forbidden Content**:

- ❌ TODO without context/date
- ❌ FIXME without issue reference
- ❌ "placeholder" or "template" text
- ❌ TBD, CHANGEME, XXX markers

**Approved Structure**:

```
docs/
├── api/              # API documentation
├── architecture/     # System design
├── database/         # Database guides
├── deployment/       # Setup & deployment
├── features/         # Feature docs
├── guides/           # User guides
├── security/         # Security docs
├── treasury/         # Treasury docs
├── development/      # Dev guides
└── archive/          # Historical files
```

**Decision Tree for Documentation**:

```
🤔 Do you need to create this documentation?

1. Is it implementation detail?
   → Use code comments or JSDoc

2. Is it a task or bug?
   → Create GitHub issue instead

3. Is it setup instructions?
   → Update main README.md

4. Does similar content exist?
   → Add to existing file instead

5. Is it really needed?
   → Proceed with creation (following standards)
```

**Example Alert**:

```
🚨 Documentation Governance Alert

You're attempting to create: docs/api/new-treasury-endpoint.md

⚠️  Concerns:
1. File docs/api/treasury-endpoints.md already exists (84 lines)
2. This might be better as addition to existing file
3. Creating new file increases maintenance burden

💡 Recommendations:
1. PREFERRED: Add to existing docs/api/treasury-endpoints.md
2. ALTERNATIVE: Update inline JSDoc for the endpoint
3. IF CRITICAL: Proceed but include:
   ✓ ## Purpose section
   ✓ ## Last Updated section
   ✓ Clear justification for new file

Would you like to:
A) Add to existing treasury-endpoints.md (RECOMMENDED)
B) Use code comments instead
C) Proceed with new file (I'll help format it correctly)
```

**When to Override**:

- Major new feature requiring extensive documentation
- Architecture decision records (ADRs)
- Security documentation for compliance
- Must provide justification and follow structure

---

## Skill Coordination

Skills can activate simultaneously and provide complementary guidance.

### Example: Creating Treasury Feature

```
You: "Create a new treasury transaction validation service"

🔒 Treasury Validator:
   → Ensure 4-layer protection implemented
   → Validate audit logging
   → Check Privy wallet integration

📏 File Size Enforcer:
   → Keep under 300 lines
   → Consider service orchestration pattern
   → Suggest splitting into focused services

🧪 Test Coverage Guardian:
   → I'll scaffold test file for you
   → Need 80% coverage for services
   → Include tests for all 4 protection layers

📝 Documentation Governance:
   → Add JSDoc comments to service methods
   → Update docs/treasury/architecture.md
   → Avoid creating separate documentation file
```

### Conflict Resolution Priority

When skills provide conflicting advice (rare):

1. **Security** (Treasury Validator, Database Security Auditor) takes precedence
2. **File size limits** are hard constraints (must be under 800 lines)
3. **Test coverage** is strongly recommended (can defer with justification)
4. **Documentation** standards are flexible (can override with reason)

---

## Working with Skills

### Respecting Skill Guidance

Skills are **assistive, not restrictive**:

✅ **Do**:

- Follow guidance when it makes sense
- Ask questions if guidance unclear
- Provide context for overrides
- Learn from skill patterns

❌ **Don't**:

- Blindly ignore all skill suggestions
- Override security guidance without review
- Skip tests because it's "faster"
- Create placeholder documentation

### Temporarily Disabling a Skill

If you need to bypass a skill for valid reasons:

```typescript
// @skill-ignore file-size-enforcer
// Reason: Legacy migration file, will refactor in Wave 7
// Ticket: ENDAO-456
```

**Important**: Document WHY you're ignoring the skill.

---

## Benefits

### Proactive Prevention

- ✅ Catch issues before commit
- ✅ Real-time guidance during development
- ✅ Consistent standards enforcement
- ✅ Automated best practice suggestions

### Reduced Technical Debt

- ✅ No more 1000+ line files
- ✅ All services have tests
- ✅ Documentation stays organized
- ✅ Security vulnerabilities caught early

### Security Improvements

- ✅ Treasury protection validated automatically
- ✅ Database queries secured
- ✅ XSS prevention automated
- ✅ Complete audit trails enforced

### Better Documentation

- ✅ Consistent structure across all docs
- ✅ No sprawl or duplication
- ✅ Clear alternatives suggested
- ✅ Up-to-date content tracking

---

## Testing Skills

To verify a skill is working:

1. **Trigger its activation condition**
   - Create a file in monitored location
   - Use trigger keywords
   - Modify relevant code

2. **Observe the guidance provided**
   - Should see skill alerts/suggestions
   - Guidance should be relevant
   - Actionable recommendations

3. **Follow or override as appropriate**
   - Test following the guidance
   - Test overriding with justification
   - Verify skill accepts valid overrides

### Manual Skill Testing

```bash
# List all active skills
ls -la .claude/skills/

# Verify skill definitions
cat .claude/skills/*/SKILL.md

# Test file size enforcer
# Create a file with >300 lines and observe warning

# Test test coverage guardian
# Create a service without tests and observe alert

# Test documentation governance
# Try creating docs/new-category/file.md and observe block
```

---

## Troubleshooting

### Skill Not Activating?

**Check**:

1. Trigger conditions met? (correct file type, location, keywords)
2. SKILL.md file exists in `.claude/skills/[skill-name]/`
3. Skill definition has proper frontmatter

**Solution**:

```bash
# Verify skill exists
cat .claude/skills/[skill-name]/SKILL.md

# Check file matches trigger patterns
# Example: treasury files should be in src/lib/services/treasury/
```

### Skill Giving Wrong Advice?

**Provide Context**:

- Explain your specific use case
- Share why standard guidance doesn't apply
- Request skill to consider special circumstances

**Override with Documentation**:

```typescript
// @skill-ignore [skill-name]
// Context: [Explain why this is an exception]
// Reviewed by: [Your name]
// Date: [YYYY-MM-DD]
```

### Multiple Skills Conflicting?

**Priority Order**:

1. Security guidance (always follow)
2. File size limits (hard constraint)
3. Test coverage (defer with reason)
4. Documentation (flexible with justification)

**When Unclear**:

- Ask which guidance to prioritize
- Explain your constraints
- Request skill coordination

---

## Skill Management

### Viewing Active Skills

```bash
# List all skills
ls -la /Users/jjones/Documents/endao-mvp/.claude/skills/

# Read skill configuration
cat .claude/skills/[skill-name]/SKILL.md
```

### Skill Effectiveness Metrics

Track skill impact:

- Number of issues prevented
- Test coverage improvements
- Documentation quality score
- Security vulnerabilities caught
- Average file size reduction

### Future Enhancements

Potential new skills for consideration:

- **Performance Optimization Skill** - Detect performance anti-patterns
- **Accessibility Validation Skill** - Ensure WCAG compliance
- **Component Prop Validation Skill** - TypeScript prop best practices
- **API Versioning Skill** - Ensure backward compatibility

---

## Integration Points

### Pre-Commit Hooks

Skills work alongside Git hooks (`.husky/pre-commit`):

- **Skills**: Development-time guidance
- **Hooks**: Commit-time validation
- **Both**: Enforce same standards

### CI/CD Pipeline

Skills inform CI/CD checks:

- Test coverage reports reference skill standards
- File size checks match skill limits
- Documentation validation uses skill rules

### Pull Request Reviews

Skills help reviewers:

- Highlight deviations from standards
- Suggest improvements automatically
- Reduce manual review burden
- Focus review on business logic

---

## Skill Activation Status

| Skill                     | Status    | Triggers                 | Enforcement |
| ------------------------- | --------- | ------------------------ | ----------- |
| Treasury Validator        | ✅ Active | Treasury files, keywords | Critical    |
| File Size Enforcer        | ✅ Active | Large files, new files   | Hard limit  |
| Test Coverage Guardian    | ✅ Active | New code files           | Recommended |
| Database Security Auditor | ✅ Active | Supabase queries         | Critical    |
| Documentation Governance  | ✅ Active | Doc file creation        | Enforced    |

---

## Quick Reference

### When Skills Activate

```
Creating treasury service → Treasury Validator + File Size Enforcer + Test Coverage Guardian
Writing Supabase query → Database Security Auditor
Creating documentation → Documentation Governance
Large component (>300 lines) → File Size Enforcer
New API route → Test Coverage Guardian + Database Security Auditor
```

### How to Work with Skills

```
1. Create/modify code
2. Observe skill activation
3. Read skill guidance
4. Follow or override with reason
5. Document overrides
6. Commit when compliant
```

### Getting Help

- **Skill not working**: Check trigger conditions and SKILL.md
- **Unclear guidance**: Ask for clarification or examples
- **Need override**: Document reason and review with team
- **Skill conflict**: Follow security > size > tests > docs priority

---

**Status**: 5 skills active and operational
**Last Reviewed**: October 30, 2025
**Next Review**: After 2 weeks of usage feedback

**For skill-specific details**, see individual SKILL.md files in `.claude/skills/[skill-name]/`
