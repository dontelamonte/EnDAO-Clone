# Architecture Health Report

**Generated**: December 16, 2025
**Codebase**: EnDAO Platform v2.3.0
**Total Files**: 1,008 TypeScript/TSX files

---

## Executive Summary

| Guideline                                | Health     | Score |
| ---------------------------------------- | ---------- | ----- |
| 1. Small Modules, APIs as Contracts      | Needs Work | 5/10  |
| 2. Risk Management (Dependency Wrapping) | Critical   | 3/10  |
| 3. Layered Architecture & Abstraction    | Good       | 8/10  |
| 4. Data & Domain Modeling                | Good       | 7/10  |
| 5. Plugin-Based Extensibility            | Critical   | 2/10  |
| 6. API & Format Design                   | Good       | 7/10  |
| 7. Tooling for Development               | Acceptable | 6/10  |
| 8. Migration & Integration Strategies    | Excellent  | 9/10  |
| 9. Deployment Flexibility                | Good       | 8/10  |

**Overall Score**: 55/90 (61%) - Significant refactoring needed

---

## Detailed Assessment

### 1. Core Architectural Philosophy

**Target**: Small modules (<300 lines), APIs as contracts, separation of concerns

**Current State**:

- 292 files exceed 300 lines (29% of codebase)
- 20 files exceed 800 lines (critical violations)
- Separation of concerns: Services → Repositories → Database (good)

**Critical Violations** (800+ lines):

| File                                                              | Lines | Issue                   |
| ----------------------------------------------------------------- | ----- | ----------------------- |
| `src/app/docs/content.tsx`                                        | 2,283 | Monolithic docs content |
| `src/app/dao/[id]/admin/page.tsx`                                 | 2,265 | God component           |
| `src/components/admin/system-dashboard/management-panel.tsx`      | 1,470 | Should be 5+ components |
| `src/lib/services/treasury/treasury-admin.service.ts`             | 1,461 | Needs extraction        |
| `src/components/profile/enhanced-profile-page.tsx`                | 1,416 | Should be 4+ components |
| `src/lib/supabase/types.ts`                                       | 1,122 | Generated, acceptable   |
| `src/lib/data/repositories/supabase/vote.repository.ts`           | 1,119 | Needs splitting         |
| `src/lib/services/admin/admin-governance-notification.service.ts` | 1,037 | Extract strategies      |
| `src/components/dao/create/create-dao-wizard-core.tsx`            | 997   | Split into steps        |
| `src/lib/services/dao/dao-query.service.ts`                       | 908   | Extract query builders  |

**Recommended Actions**:

1. **Immediate**: Split files >800 lines using compound component patterns
2. **Short-term**: Establish 300-line guideline in eslint-plugin-file-limits
3. **Medium-term**: Refactor remaining 272 files over 300 lines

---

### 2. Risk Management Strategies

**Target**: Wrap critical dependencies, anticipate change

**Current State**:

- No `/src/lib/wrappers` directory exists
- 16 files directly import from critical dependencies
- No abstraction layer for blockchain/wallet providers

**Direct Dependency Imports** (High Risk):

| Dependency       | Files | Risk                                  |
| ---------------- | ----- | ------------------------------------- |
| `ethers`         | 6     | SDK changes break multiple files      |
| `@safe-global/*` | 8     | Safe SDK updates require mass changes |
| `@privy-io/*`    | 4     | Auth provider lock-in                 |

**Impact Analysis**:

- Ethers v5→v6 migration required touching all 6 files manually
- Safe SDK updates ripple through treasury, signing, transactions
- Privy mobile vs web SDK differences not abstracted

**Recommended Actions**:

1. **Immediate**: Create `/src/lib/wrappers/` directory
2. **Create Wrappers**:
   - `EthersWrapper` - Abstract provider/signer access
   - `SafeWrapper` - Wrap Safe SDK operations
   - `WalletWrapper` - Abstract Privy + future wallet providers
3. **Migration Pattern**: One file at a time, maintain backward compatibility

---

### 3. Layered Architecture & Abstraction

**Target**: Platform wrappers, helper libraries, clean layers

**Current State** (Good):

```
Components → Hooks → API Routes → Services → Repositories → Database
                                     ↓
                              BaseService (112 extensions)
```

**Strengths**:

- Repository pattern with 25+ repositories
- BaseService abstraction used by 112 services
- `ServiceResponse<T>` standardized pattern
- Clear separation: client repos (RLS) vs admin repos (bypass RLS)

**Weaknesses**:

- Some services bypass repository pattern
- Direct Supabase calls in some components
- Missing platform abstraction layer (see Guideline 2)

**Recommended Actions**:

1. Audit services for direct database calls
2. Ensure all data access goes through repositories
3. Create platform abstraction for external services

---

### 4. Data & Domain Modeling

**Target**: Core primitives, primitive vs structure separation

**Current State** (Good):

**Shared Types Package** (`packages/shared-types/src/`):

- 16 type definition files
- Core types: `DAO`, `Proposal`, `Vote`, `User`
- Enums: `DAOCategory`, `OrganizationType`, `DAOTag`
- Status types: `ProposalStatus`, `VoteChoice`

**Strengths**:

- Single source of truth for domain types
- Used by both web and mobile apps
- Clear separation of concerns

**Weaknesses**:

- Some types still defined in services (not shared)
- Duplicate type definitions in some repositories
- `src/lib/supabase/types.ts` (generated) conflicts with manual types

**Recommended Actions**:

1. Move remaining domain types to shared-types
2. Generate shared-types from Supabase schema
3. Remove duplicate type definitions

---

### 5. Plugin-Based Extensibility

**Target**: Core + plugin model, extensible architecture

**Current State** (Critical - Major Gap):

- No `/src/plugins` directory
- No plugin architecture
- Voting strategies hardcoded in VotingEngineService
- Notification channels not pluggable

**Missing Plugin Points**:

| Domain                | Current            | Should Be             |
| --------------------- | ------------------ | --------------------- |
| Voting Strategies     | Hardcoded switch   | Strategy plugin       |
| Notification Channels | Hardcoded email    | Channel plugins       |
| Authentication        | Privy-coupled      | Auth provider plugins |
| Treasury Providers    | Safe-coupled       | Treasury plugins      |
| Export Formats        | Hardcoded CSV/JSON | Format plugins        |

**VotingEngineService Example**:

```typescript
// Current: Hardcoded switch
switch (proposal.votingType) {
  case 'simple':
    return calculateSimple();
  case 'ranked':
    return calculateRanked();
  case 'quadratic':
    return calculateQuadratic();
}

// Should Be: Plugin registry
const strategy = VotingStrategyRegistry.get(proposal.votingType);
return strategy.calculate(votes);
```

**Recommended Actions**:

1. **Immediate**: Create `/src/lib/plugins/` structure
2. **First Plugin**: Voting strategies (already have patterns)
3. **Second Plugin**: Notification channels
4. **Third Plugin**: Export formats

---

### 6. API & Format Design

**Target**: Small interfaces, implementation freedom

**Current State** (Good):

**Strengths**:

- `ServiceResponse<T>` used consistently (112 services)
- RESTful API routes with Zod validation
- Clear request/response shapes

**Interface Count by Service**:

- Most services: 2-5 interfaces (good)
- Some services: 10+ interfaces (too large)

**Large Interface Services** (Need Splitting):

- `treasury-admin.service.ts`: 15+ interfaces
- `notification-router.service.ts`: 12+ interfaces
- `voting-engine.service.ts`: 10+ interfaces

**Recommended Actions**:

1. Extract interface groups into `*.types.ts` files
2. Use interface composition over large flat interfaces
3. Document interface contracts in JSDoc

---

### 7. Tooling for Development

**Target**: Simulators, record/replay, dev tooling

**Current State** (Acceptable):

**Existing Tools**:

- Mock files: 6 files in `__mocks__` directories
- Jest mocking: 355 mock usages across 42 test files
- Test utils: `src/lib/test-utils.tsx`, `mock-helpers.ts`
- 950+ tests passing

**Missing Tools**:

| Tool                  | Status  | Impact                         |
| --------------------- | ------- | ------------------------------ |
| Blockchain Simulator  | Missing | Manual testing for Safe/ethers |
| Record/Replay Testing | Missing | API response caching           |
| Dev Auth Bypass       | Exists  | authenticateAs() helper        |
| Database Seeding      | Exists  | yarn seed                      |
| E2E Testing           | Good    | 13 Playwright test files       |

**Recommended Actions**:

1. Create Safe transaction simulator for testing
2. Implement API response recording for E2E tests
3. Add Privy mock for auth-free testing
4. Create treasury simulation mode

---

### 8. Migration & Integration Strategies

**Target**: Never big bang, multiple access layers

**Current State** (Excellent):

**Evidence of Good Practice**:

- Firebase → Supabase migration completed incrementally
- 37 Supabase migration files (incremental changes)
- Repository pattern allows database abstraction
- Feature flags enable progressive rollouts

**Migration History**:

1. Auth: Firebase Auth → Privy (completed)
2. Database: Firestore → Supabase (completed)
3. Types: Gradual shared-types adoption (ongoing)
4. Voting: Incremental addition of voting types (completed)

**Feature Flag System**:

```typescript
// Controlled rollouts
useDbViews: boolean;
enableWeightedVoting: boolean;
enableQuadraticVoting: boolean;
enableDelegatedVoting: boolean;
enableOnboardingHelpers: boolean;
```

---

### 9. Deployment Flexibility

**Target**: Same core, multiple frontends, scale independence

**Current State** (Good):

**Monorepo Structure**:

```
apps/
  mobile/     # Expo React Native (new)
  web/        # Next.js (to be extracted)
packages/
  shared-types/  # Shared TypeScript types
```

**Strengths**:

- Mobile app uses same API routes
- Shared types enable code sharing
- API-first design

**Weaknesses**:

- Web app not yet extracted to `apps/web`
- Some web-specific logic in shared services
- Mobile API client duplicates some web logic

**Recommended Actions**:

1. Extract web app to `apps/web` directory
2. Create shared hooks package for common patterns
3. Ensure services are frontend-agnostic

---

## Priority Refactoring Roadmap

### Phase 1: Critical (Week 1-2)

1. Create dependency wrappers (ethers, Safe, Privy)
2. Split top 5 largest files (>1,000 lines)
3. Establish file size linting rule

### Phase 2: High Priority (Week 3-4)

1. Create plugin architecture foundation
2. Extract voting strategies to plugin pattern
3. Split remaining files >800 lines

### Phase 3: Medium Priority (Month 2)

1. Implement notification channel plugins
2. Create blockchain simulator for testing
3. Move all domain types to shared-types

### Phase 4: Ongoing

1. Refactor files >300 lines as touched
2. Add plugins for new features
3. Extract web to apps/web

---

## Metrics to Track

| Metric                  | Current    | Target   |
| ----------------------- | ---------- | -------- |
| Files >800 lines        | 20         | 0        |
| Files >300 lines        | 292        | <100     |
| Direct critical imports | 16         | 0        |
| Services with plugins   | 0          | 5+       |
| Shared type coverage    | ~70%       | 95%      |
| Test coverage           | 950+ tests | Maintain |

---

## Appendix: File Size Distribution

```
0-100 lines:    ~400 files (40%)
100-200 lines:  ~200 files (20%)
200-300 lines:  ~116 files (11%)
300-500 lines:  ~180 files (18%)
500-800 lines:   ~92 files (9%)
800+ lines:      ~20 files (2%)
```

---

_Report generated from codebase analysis on December 16, 2025_
