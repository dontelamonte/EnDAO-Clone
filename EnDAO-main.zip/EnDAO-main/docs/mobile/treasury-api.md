# Mobile Treasury API Routes

## Overview

Read-only treasury API routes for the mobile app. These routes provide access to DAO treasury information including balance overview and transaction history.

**Created**: February 6, 2026
**Status**: Complete
**Location**: `src/app/api/mobile/v1/daos/[daoId]/treasury/`

## Routes

### 1. Treasury Overview

**Endpoint**: `GET /api/mobile/v1/daos/{daoId}/treasury`

**Description**: Returns treasury overview including Safe address, balance, tokens, and configuration status.

**Authentication**: Required (via Privy middleware)

**Authorization**: Must be a DAO member

**Response Schema**:
```typescript
{
  success: true,
  data: {
    address: string | null,        // Safe wallet address
    balance: string,               // Total balance (formatted)
    balanceUsd: string | null,     // USD value if available
    tokens: Array<{
      symbol: string,              // Token symbol (e.g., "USDC")
      balance: string,             // Token balance (formatted)
      balanceUsd: string | null,   // USD value if available
    }>,
    isConfigured: boolean,         // Whether treasury is set up
  }
}
```

**Example Response**:
```json
{
  "success": true,
  "data": {
    "address": "0x1234567890abcdef1234567890abcdef12345678",
    "balance": "10000",
    "balanceUsd": "10000",
    "tokens": [
      {
        "symbol": "USDC",
        "balance": "10000",
        "balanceUsd": "10000"
      }
    ],
    "isConfigured": true
  }
}
```

**Error Responses**:
- `401` - Authentication required
- `403` - Access denied (not a DAO member)
- `404` - DAO not found
- `500` - Server error

---

### 2. Transaction History

**Endpoint**: `GET /api/mobile/v1/daos/{daoId}/treasury/transactions`

**Description**: Returns paginated transaction history for the DAO treasury.

**Authentication**: Required (via Privy middleware)

**Authorization**: Must be a DAO member

**Query Parameters**:
- `limit` (optional): Number of transactions to return (default: 20, max: 100)
- `offset` (optional): Number of transactions to skip (default: 0)

**Response Schema**:
```typescript
{
  success: true,
  data: {
    transactions: Array<{
      id: string,
      type: 'incoming' | 'outgoing',
      amount: string,                      // Amount (formatted)
      tokenSymbol: string,                 // Token symbol
      from: string,                        // Sender address
      to: string,                          // Recipient address
      status: 'pending' | 'confirmed' | 'failed',
      timestamp: string,                   // ISO 8601 timestamp
      txHash: string | null,               // Blockchain transaction hash
    }>,
    hasMore: boolean,                      // Whether more transactions exist
  }
}
```

**Example Response**:
```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": "abc123",
        "type": "outgoing",
        "amount": "1000",
        "tokenSymbol": "USDC",
        "from": "0x1234...5678",
        "to": "0xabcd...ef01",
        "status": "confirmed",
        "timestamp": "2026-02-06T23:30:00.000Z",
        "txHash": "0x9876...5432"
      }
    ],
    "hasMore": true
  }
}
```

**Error Responses**:
- `400` - Invalid query parameters
- `401` - Authentication required
- `403` - Access denied (not a DAO member)
- `404` - DAO not found
- `500` - Server error

---

## Implementation Details

### Services Used

1. **DAOService** - Validates DAO exists and checks membership
2. **TreasuryService** - Fetches balance and transaction history

### Data Flow

```
Mobile App → API Route → DAOService (validate) → TreasuryService → Supabase
     ↑                                                                ↓
     └──────────────────── Response ←────────────────────────────────┘
```

### Security

- Authentication via Privy middleware (injected headers)
- Membership validation before returning data
- Read-only access (no mutations)
- Input validation for query parameters

### Type Mapping

**Transaction Types**:
- `proposal_execution` → `outgoing`
- `direct_transfer` → `outgoing`
- `admin_action` → `incoming`

**Transaction Status**:
- `completed` → `confirmed`
- `failed` → `failed`
- `pending/signing/executing` → `pending`

---

## Testing

### Manual Testing

1. **Treasury Overview**:
```bash
curl -H "x-auth-uid: <uid>" \
     -H "x-auth-privy-id: <privy-id>" \
     https://endao.ai/api/mobile/v1/daos/test-tech-innovators/treasury
```

2. **Transaction History**:
```bash
curl -H "x-auth-uid: <uid>" \
     -H "x-auth-privy-id: <privy-id>" \
     "https://endao.ai/api/mobile/v1/daos/test-tech-innovators/treasury/transactions?limit=10&offset=0"
```

### Future Enhancements

- [ ] Add transaction filtering by type, status, date range
- [ ] Add transaction search by recipient/sender
- [ ] Add real-time balance updates via WebSocket
- [ ] Add transaction detail endpoint
- [ ] Add CSV export functionality

---

## Related Files

**API Routes**:
- `/src/app/api/mobile/v1/daos/[daoId]/treasury/route.ts`
- `/src/app/api/mobile/v1/daos/[daoId]/treasury/transactions/route.ts`

**Services**:
- `/src/lib/services/treasury/index.ts`
- `/src/lib/services/treasury/treasury-operations.ts`
- `/src/lib/services/treasury/transaction-manager.ts`

**Types**:
- `/src/lib/services/treasury/types.ts`
- `@endao/shared-types` (DAO types)
