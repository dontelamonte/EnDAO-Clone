# Mobile UI/UX Upgrade Research

**Date**: February 10, 2026 | **Status**: Research Complete | **Priority**: HIGH

## Purpose

Research document for upgrading the EnDAO mobile app's visual design and user experience to complement the polished web application. Provides recommendations for icon libraries, animation frameworks, and design system enhancements.

---

## Executive Summary

The EnDAO mobile app currently uses basic React Native StyleSheet with heavy emoji usage for icons. This document presents research findings on modern mobile UI/UX best practices and recommendations for upgrading the mobile experience to complement the polished web application.

**Key Recommendations**:

1. Replace emojis with Lucide React Native icons (1,500+ professional icons)
2. Add micro-animations with Moti library (simple, performant)
3. Enhance theme system with shadows, elevation, gradients
4. Consider NativeWind for Tailwind parity with web

---

## Current State Analysis

### Emoji Usage Inventory

| Component          | Current Emoji Icons                              |
| ------------------ | ------------------------------------------------ |
| `EmptyState.tsx`   | `'📭'` (default)                                 |
| `ActivityItem.tsx` | `'👋', '📝', '🗳️', '✅', '❌', '🔄', '⚙️', '💰'` |
| Screens/tabs       | Various contextual emojis                        |

### Current Theme (`theme.ts`)

```typescript
// Basic slate color palette
colors: {
  background: '#0f172a',
  surface: '#1e293b',
  surfaceLight: '#334155',
  primary: '#3b82f6',
  // ...
}

// Basic spacing (xs:4 to xxl:32)
// Basic font sizes (xs:12 to xxxl:32)
// No shadows, elevation, or animation definitions
```

### Current Issues

1. **Inconsistent visual language** - Emojis vary by platform/OS version
2. **No visual hierarchy** - Flat design without depth cues
3. **No motion design** - Static UI feels unpolished
4. **Basic styling** - Missing modern design elements (shadows, gradients, blur)

---

## UI Component Libraries Comparison

### Option 1: NativeWind (Recommended for EnDAO)

**Best for**: Teams with Tailwind experience, web/mobile consistency

| Aspect             | Details                        |
| ------------------ | ------------------------------ |
| **Approach**       | Tailwind CSS for React Native  |
| **Bundle Size**    | Minimal (compile-time)         |
| **Learning Curve** | Low (if using Tailwind on web) |
| **Dark Mode**      | Built-in class support         |
| **Web Parity**     | Excellent - same class names   |

```tsx
// Example: Before and after
// Before (current)
<View style={styles.card}>
  <Text style={styles.title}>Title</Text>
</View>

// After (NativeWind)
<View className="bg-slate-800 rounded-xl p-4 shadow-lg">
  <Text className="text-white text-lg font-semibold">Title</Text>
</View>
```

**Pros**:

- Same Tailwind classes as web codebase
- Compile-time processing (no runtime overhead)
- Excellent dark mode support
- Active development (v4 stable)

**Cons**:

- Requires build configuration changes
- Some Tailwind features unavailable in RN

### Option 2: Gluestack UI v3

**Best for**: Accessibility-first apps, comprehensive component library

| Aspect            | Details                             |
| ----------------- | ----------------------------------- |
| **Approach**      | Unstyled primitives + styling layer |
| **Components**    | 50+ accessible components           |
| **Accessibility** | WCAG AA built-in                    |
| **Performance**   | Tree-shakeable                      |

**Pros**:

- Best-in-class accessibility
- Pre-built complex components (modals, sheets, etc.)
- Works with NativeWind

**Cons**:

- Larger bundle than NativeWind alone
- Learning new component API

### Option 3: Tamagui

**Best for**: Performance-critical apps, design systems

| Aspect          | Details                      |
| --------------- | ---------------------------- |
| **Approach**    | Compile-time optimization    |
| **Performance** | Fastest (compiles to native) |
| **Bundle Size** | Optimized at compile time    |

**Pros**:

- Superior performance
- Cross-platform (web + native)
- Design tokens

**Cons**:

- Steeper learning curve
- Complex setup
- Different paradigm from current codebase

### Recommendation

**NativeWind** as primary styling solution because:

1. Web codebase already uses Tailwind
2. Minimal learning curve for team
3. Same utility classes improve code consistency
4. Can add Gluestack components incrementally for complex UI

---

## Icon Library: Lucide React Native

Replace all emoji icons with [lucide-react-native](https://lucide.dev/).

### Why Lucide?

| Feature              | Benefit                   |
| -------------------- | ------------------------- |
| **1,500+ icons**     | Comprehensive coverage    |
| **Tree-shakeable**   | Only bundle used icons    |
| **Consistent style** | Professional 24x24 grid   |
| **Customizable**     | Size, color, stroke width |
| **TypeScript**       | Full type support         |

### Migration Example

```tsx
// Before (emoji)
const ACTIVITY_ICONS = {
  member_joined: '👋',
  proposal_created: '📝',
  vote_cast: '🗳️',
};

// After (Lucide)
import { UserPlus, FileText, Vote } from 'lucide-react-native';

const ACTIVITY_ICONS = {
  member_joined: UserPlus,
  proposal_created: FileText,
  vote_cast: Vote,
};

// Usage
const IconComponent = ACTIVITY_ICONS[activity.type];
<IconComponent size={20} color={colors.primary} />;
```

### Icon Mapping for EnDAO

| Context          | Emoji | Lucide Icon         |
| ---------------- | ----- | ------------------- |
| Member joined    | 👋    | `UserPlus`          |
| Proposal created | 📝    | `FileText`          |
| Vote cast        | 🗳️    | `Vote`              |
| Proposal passed  | ✅    | `CheckCircle`       |
| Proposal failed  | ❌    | `XCircle`           |
| Settings changed | ⚙️    | `Settings`          |
| Treasury         | 💰    | `Wallet` or `Coins` |
| Empty state      | 📭    | `Inbox`             |
| Discussion       | 💬    | `MessageSquare`     |
| Members          | 👥    | `Users`             |
| Activity         | 📊    | `Activity`          |
| Admin            | 🛡️    | `Shield`            |

---

## Animation Library: Moti

[Moti](https://moti.fyi/) is built on Reanimated 3 and provides a declarative animation API.

### Why Moti?

| Feature                 | Benefit                       |
| ----------------------- | ----------------------------- |
| **Simple API**          | Declarative, React-like       |
| **Performance**         | Runs on native thread         |
| **Reduced boilerplate** | 60% less code than Reanimated |
| **Skeleton support**    | Built-in loading skeletons    |

### Animation Patterns for EnDAO

```tsx
import { MotiView, AnimatePresence } from 'moti';

// Fade in on mount
<MotiView
  from={{ opacity: 0, translateY: 20 }}
  animate={{ opacity: 1, translateY: 0 }}
  transition={{ type: 'timing', duration: 300 }}
>
  <Card />
</MotiView>;

// Loading skeleton
import { Skeleton } from 'moti/skeleton';

<Skeleton colorMode="dark" width={200} height={20} />;

// List item stagger
{
  items.map((item, index) => (
    <MotiView
      key={item.id}
      from={{ opacity: 0, translateX: -20 }}
      animate={{ opacity: 1, translateX: 0 }}
      transition={{ delay: index * 50 }}
    >
      <ListItem {...item} />
    </MotiView>
  ));
}
```

### Recommended Animation Locations

| Screen/Component   | Animation Type        |
| ------------------ | --------------------- |
| Screen transitions | Fade + slide          |
| List items         | Staggered fade-in     |
| Card press         | Scale feedback (0.98) |
| Loading states     | Skeleton pulse        |
| Empty states       | Subtle bounce on icon |
| Success actions    | Check mark animation  |
| Error states       | Shake animation       |
| Pull to refresh    | Custom indicator      |

---

## Enhanced Theme System

### Proposed Theme Enhancements

```typescript
export const theme = {
  colors: {
    // Keep existing slate palette
    background: '#0f172a',
    surface: '#1e293b',
    surfaceLight: '#334155',
    primary: '#3b82f6',
    primaryLight: '#60a5fa',
    secondary: '#8b5cf6',
    success: '#22c55e',
    warning: '#f59e0b',
    error: '#ef4444',
    text: '#f8fafc',
    textSecondary: '#94a3b8',
    border: '#475569',
  },

  // NEW: Shadows for elevation
  shadows: {
    sm: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.2,
      shadowRadius: 2,
      elevation: 2,
    },
    md: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.25,
      shadowRadius: 8,
      elevation: 4,
    },
    lg: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.3,
      shadowRadius: 16,
      elevation: 8,
    },
  },

  // NEW: Border radii
  radii: {
    sm: 4,
    md: 8,
    lg: 12,
    xl: 16,
    xxl: 24,
    full: 9999,
  },

  // NEW: Animation durations
  animation: {
    fast: 150,
    normal: 300,
    slow: 500,
  },

  // NEW: Opacity levels
  opacity: {
    disabled: 0.5,
    muted: 0.7,
    overlay: 0.8,
  },
};
```

---

## Design Patterns & Best Practices

### Touch Targets

| Platform | Minimum Size | Recommended               |
| -------- | ------------ | ------------------------- |
| iOS      | 44x44 pt     | 48x48 pt                  |
| Android  | 48x48 dp     | 56x56 dp                  |
| EnDAO    | 48x48        | Consistent both platforms |

### Color Contrast

WCAG AA compliance requires:

- **Normal text**: 4.5:1 contrast ratio
- **Large text (18pt+)**: 3:1 contrast ratio
- **UI elements**: 3:1 contrast ratio

Current EnDAO palette meets these requirements.

### 60-30-10 Color Rule

| Percentage | Usage              | EnDAO Application              |
| ---------- | ------------------ | ------------------------------ |
| 60%        | Primary/background | `#0f172a` (slate-900)          |
| 30%        | Secondary          | `#1e293b` (slate-800) surfaces |
| 10%        | Accent             | `#3b82f6` (blue-500) CTAs      |

### Typography Hierarchy

```typescript
const typography = {
  hero: { fontSize: 32, fontWeight: '700', lineHeight: 40 },
  h1: { fontSize: 24, fontWeight: '700', lineHeight: 32 },
  h2: { fontSize: 20, fontWeight: '600', lineHeight: 28 },
  h3: { fontSize: 18, fontWeight: '600', lineHeight: 24 },
  body: { fontSize: 16, fontWeight: '400', lineHeight: 24 },
  bodySmall: { fontSize: 14, fontWeight: '400', lineHeight: 20 },
  caption: { fontSize: 12, fontWeight: '400', lineHeight: 16 },
};
```

---

## Implementation Phases

### Phase 1: Foundation (1-2 days)

1. Install dependencies:

   ```bash
   cd apps/mobile
   yarn add lucide-react-native moti react-native-reanimated
   # Optional: yarn add nativewind tailwindcss
   ```

2. Update theme.ts with shadows, radii, animation tokens

3. Create `Icon` wrapper component for consistent Lucide usage

### Phase 2: Icon Migration (1 day)

1. Create icon mapping constants
2. Update EmptyState component
3. Update ActivityItem component
4. Update remaining screens

### Phase 3: Animation Integration (1-2 days)

1. Add MotiView wrappers to list screens
2. Implement loading skeletons
3. Add press feedback to touchable elements
4. Implement staggered list animations

### Phase 4: Polish (1-2 days)

1. Apply shadow system to cards
2. Add subtle gradients where appropriate
3. Implement consistent spacing using theme
4. Add empty state animations

### Phase 5: NativeWind (Optional, 2-3 days)

1. Configure NativeWind in Expo
2. Gradually migrate StyleSheet to className
3. Align with web Tailwind utilities

---

## Dependencies to Add

```json
{
  "dependencies": {
    "lucide-react-native": "^0.445.0",
    "moti": "^0.30.0",
    "react-native-reanimated": "~3.16.0"
  },
  "devDependencies": {
    "nativewind": "^4.0.0",
    "tailwindcss": "^3.4.0"
  }
}
```

**Note**: `react-native-reanimated` is already installed in the mobile app (required by Expo). Verify version compatibility before updating.

---

## Success Metrics

| Metric            | Before | Target                   |
| ----------------- | ------ | ------------------------ |
| Emoji icons       | 12+    | 0                        |
| Animated screens  | 0      | 8+                       |
| Shadows/elevation | 0      | All cards                |
| Loading skeletons | 0      | All lists                |
| Touch feedback    | Basic  | All interactive elements |

---

## References

- [Lucide Icons](https://lucide.dev/) - Icon library
- [Moti Documentation](https://moti.fyi/) - Animation library
- [NativeWind](https://www.nativewind.dev/) - Tailwind for React Native
- [Gluestack UI](https://gluestack.io/) - Accessible components
- [Material Design 3](https://m3.material.io/) - Design guidelines
- [Apple HIG](https://developer.apple.com/design/human-interface-guidelines/) - iOS guidelines

---

## Related Documents

| Document                                                           | Purpose                 |
| ------------------------------------------------------------------ | ----------------------- |
| [DEVELOPMENT_TRACKER.md](/docs/development/DEVELOPMENT_TRACKER.md) | Implementation tracking |
| [MOBILE_STRATEGY.md](/docs/research/mobile/MOBILE_STRATEGY.md)     | Mobile product strategy |

---

## Last Updated

February 10, 2026
