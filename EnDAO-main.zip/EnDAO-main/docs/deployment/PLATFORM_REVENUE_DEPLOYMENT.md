# EnDAO Platform Revenue Deployment Guide

## Overview

This guide provides deployment procedures for the EnDAO platform revenue infrastructure.

**Current Status**: ✅ **DEPLOYED TO BASE SEPOLIA TESTNET**  
See [DEPLOYMENT_STATUS.md](./DEPLOYMENT_STATUS.md) for current deployment details.

## Deployment Architecture

1. **EnDAO Gnosis Safe** - Multi-signature wallet for platform revenue collection
2. **FeeRouter Contract** - Smart contract implementing 5% contribution, 2% transfer fees
3. **UI Integration** - Frontend components for deposit flows with fee transparency

## Current Deployment (Base Sepolia)

✅ **Production Ready Components**:

- EnDAO Safe: `0x00dc44400adb57a85364c97442bd5e95faa861e7`
- FeeRouter Contract: `0xf8786857eD04621d6e81959aAb36e422F687E4c8`
- Treasury activity tracking service
- Deposit flow UI with fee display
- Database revenue logging (Supabase)

🔄 **Next Phase**:

- Base mainnet deployment (pending testing completion)
- 2-of-2 multi-sig upgrade (add Donte as co-signer)

## Prerequisites

### For Development/Testing

- Node.js 20+ installed
- Test ETH on Base Sepolia (get from [Base Sepolia Faucet](https://www.alchemy.com/faucets/base-sepolia))
- Access to deployed testnet contracts

### For Mainnet Deployment

- Real ETH on Base mainnet
- Hardware wallet for production keys
- Team approval and security review completion

## Current Environment Configuration

### Testnet (Base Sepolia) - Active

```bash
# .env.local - Current Production Settings
ENDAO_SAFE_ADDRESS=0x00dc44400adb57a85364c97442bd5e95faa861e7
NEXT_PUBLIC_FEE_ROUTER_ADDRESS=0xf8786857eD04621d6e81959aAb36e422F687E4c8
NEXT_PUBLIC_NETWORK=base-sepolia

# .env.safe - Safe Configuration
CEO_WALLET_ADDRESS=0xadd0f0675C8d9392773D04C81952855a82Ef2903
NETWORK=base-sepolia
```

### Key Addresses

- **Justin's Wallet (CEO)**: `0xadd0f0675C8d9392773D04C81952855a82Ef2903`
- **Deployer Wallet**: `0x014CEb3822270B3Dcc0B10aA9E24946C76F0893b`

## Deployment Procedures

### Current Status: Testnet Deployed ✅

The EnDAO Safe and FeeRouter are already deployed to Base Sepolia. For reference or future mainnet deployment:

**Deploy EnDAO Safe**:

```bash
# Configure environment
export NETWORK=base-sepolia  # or 'base' for mainnet
export CEO_WALLET_ADDRESS=0xadd0f0675C8d9392773D04C81952855a82Ef2903

# Deploy Safe (1-of-1, will upgrade to 2-of-2 later)
ts-node scripts/setup-endao-safe.ts
```

**Deploy FeeRouter Contract**:

```bash
# Set EnDAO Safe address in environment
export ENDAO_SAFE_ADDRESS=0x00dc44400adb57a85364c97442bd5e95faa861e7

# Deploy FeeRouter
ts-node scripts/deploy-fee-router.ts
```

## Testing the Deployed System

### Current Testnet System Testing

**Active Contracts on Base Sepolia**:

- EnDAO Safe: `0x00dc44400adb57a85364c97442bd5e95faa861e7`
- FeeRouter: `0xf8786857eD04621d6e81959aAb36e422F687E4c8`

**Test Deposit Flow**:

```bash
# Start development environment
yarn dev

# Navigate to any DAO with treasury
# Click "Deposit Funds"
# Send small test amount (0.001 ETH)
# Verify:
# - 5% fee goes to EnDAO Safe
# - 95% goes to DAO Safe
# - Transaction appears in database logs
```

### Future Mainnet Deployment

```bash
# When ready for mainnet (requires team approval)
export NETWORK=base
export ENDAO_SAFE_ADDRESS=<NEW_MAINNET_SAFE>

# Deploy to Base mainnet
ts-node scripts/deploy-fee-router.ts

# Verify contract
npx hardhat verify --network base <CONTRACT_ADDRESS> "<SAFE_ADDRESS>"
```

## Frontend Configuration

### Current Production Settings (Base Sepolia)

```bash
# .env.local - Active Configuration
NEXT_PUBLIC_NETWORK=base-sepolia
NEXT_PUBLIC_FEE_ROUTER_ADDRESS=0xf8786857eD04621d6e81959aAb36e422F687E4c8
ENDAO_SAFE_ADDRESS=0x00dc44400adb57a85364c97442bd5e95faa861e7

# RPC Configuration
NEXT_PUBLIC_BASE_SEPOLIA_RPC_URL=https://sepolia.base.org
```

### Future Mainnet Configuration

```bash
# .env.local - Future Production
NEXT_PUBLIC_NETWORK=base
NEXT_PUBLIC_FEE_ROUTER_ADDRESS=<MAINNET_FEE_ROUTER>
ENDAO_SAFE_ADDRESS=<MAINNET_SAFE>
NEXT_PUBLIC_BASE_RPC_URL=https://mainnet.base.org
```

## Deployment Status Checklist

### Testnet Deployment ✅ COMPLETE

- [x] Justin's wallet configured as Safe owner
- [x] EnDAO Safe deployed to Base Sepolia
- [x] FeeRouter deployed and verified on Base Sepolia
- [x] Frontend configured with contract addresses
- [x] Environment variables set for testnet

### Testing & Validation 🔄 IN PROGRESS

- [ ] End-to-end deposit flow testing
- [ ] Revenue collection verification in Safe
- [ ] Database treasury activity logging
- [ ] Fee calculation accuracy (5% / 2%)
- [ ] Multi-DAO testing across different treasury configurations

### Mainnet Deployment ⏳ PENDING

- [ ] Complete testnet testing validation
- [ ] Security review and team approval
- [ ] Base mainnet ETH funding
- [ ] Deploy Safe to Base mainnet
- [ ] Deploy FeeRouter to Base mainnet
- [ ] Production environment configuration
- [ ] Add Donte as second Safe signer (2-of-2 upgrade)

## Troubleshooting

### Common Issues

**Issue**: Safe not appearing in Safe app

- **Solution**: Ensure using correct network prefix (base-sepolia:) in URL

**Issue**: Insufficient gas for deployment

- **Solution**: Ensure deployer wallet has sufficient ETH

**Issue**: Transaction failing

- **Solution**: Check network configuration and contract addresses

**Issue**: Frontend not connecting to contracts

- **Solution**: Verify environment variables and network settings

## Security Notes

⚠️ **NEVER**:

- Commit private keys to git
- Use mainnet keys on testnet
- Deploy without testing
- Share Safe owner keys

✅ **ALWAYS**:

- Test on testnet first
- Verify contracts on BaseScan
- Use hardware wallets for mainnet
- Monitor Safe for unusual activity

## Planned Upgrades

### Phase 2: Multi-Signature Upgrade

Upgrade from 1-of-1 to 2-of-2 Safe:

1. **Add Donte as Safe owner** (requires current owner signature)
2. **Change threshold to 2** (both founders required for transactions)
3. **Test multi-signature workflows**
4. **Update documentation** with new signing process

### Phase 3: Advanced Fee Management

Implement additional revenue features:

1. **Safe Guard modules** for programmatic enforcement
2. **Automated treasury transfers** with fee collection
3. **Revenue analytics dashboard** for platform metrics
4. **Multi-token support** beyond ETH

## Support

For deployment issues:

1. Check deployment logs
2. Verify all addresses
3. Review transaction on BaseScan
4. Contact team for help

## Quick Links

- **EnDAO Safe**: https://app.safe.global/home?safe=base-sepolia:0x00dc44400adb57a85364c97442bd5e95faa861e7
- **FeeRouter Contract**: https://sepolia.basescan.org/address/0xf8786857eD04621d6e81959aAb36e422F687E4c8
- **Deployment Status**: [DEPLOYMENT_STATUS.md](./DEPLOYMENT_STATUS.md)
- **Treasury Documentation**: [treasury/README.md](./treasury/README.md)

---

**Status**: ✅ Testnet Complete | 🔄 Testing in Progress | ⏳ Mainnet Pending  
**Last Updated**: August 26, 2025  
**Version**: 1.1.0 (Post-Sepolia Deployment)

For current deployment status, see [DEPLOYMENT_STATUS.md](./DEPLOYMENT_STATUS.md)
