# Setup Guide

## Purpose

This guide provides step-by-step instructions for setting up the EnDAO development environment, including all required dependencies, environment variables, and configuration.

## Last Updated

September 2025

## Prerequisites

- Node.js 18+
- Git
- Supabase project
- Privy account

## Quick Start

1. **Clone and Install**

```bash
git clone https://github.com/yourusername/endao-mvp.git
cd endao-mvp
yarn install
```

2. **Environment Variables**
   Create `.env.local`:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# Privy
NEXT_PUBLIC_PRIVY_APP_ID=
PRIVY_APP_SECRET=

# Base Network
NEXT_PUBLIC_BASE_SEPOLIA_RPC_URL=https://sepolia.base.org
SAFE_DEPLOYER_PRIVATE_KEY=

# Redis (optional)
REDIS_URL=
```

3. **Run Development Server**

```bash
yarn dev
```

Visit http://localhost:3000

## Environments

### Local Development

- Branch: `development`
- URL: http://localhost:3000
- Manual start with `yarn dev`

### Vercel Preview (Development)

- Branch: `development`
- Auto-deploys on push to development branch
- URL: Auto-generated preview URLs from Vercel
- Used for testing features before production

### Vercel Production

- Branch: `main`
- URL: https://endao.ai
- Deployed when changes merged to main branch

## Common Commands

### Development Commands

```bash
yarn dev          # Start development server
yarn build        # Build for production
yarn lint         # Run ESLint
yarn type-check   # Check TypeScript
yarn test            # Run tests
```

### Architecture Monitoring

```bash
# File size and complexity analysis
yarn check:files        # Check file sizes against thresholds
yarn check:complexity   # Analyze code complexity
yarn check:architecture # Run both file size and complexity checks

# Architecture health reports
yarn analyze            # Generate comprehensive architecture report
yarn analyze:html       # Generate visual HTML dashboard

# Quality monitoring (runs automatically in CI)
yarn architecture-health # Complete architecture health check
```

### Code Quality Commands

```bash
# Linting with architectural rules
yarn lint:fix           # Auto-fix linting issues
yarn lint:architecture  # Check architectural ESLint rules

# Pre-commit validation
yarn pre-commit         # Run pre-commit checks manually
```

## Deployment

Vercel automatically deploys on git push:

```bash
git checkout development
git add .
git commit -m "feat: your feature"
git push origin development
```

## Architecture Monitoring Setup

### Code Quality Standards

The project enforces architectural standards through automated tools:

- **File Size Limits**: 500 lines (warning), 800 lines (error)
- **Function Complexity**: Max 10 cyclomatic complexity
- **Nesting Depth**: Max 4 levels of nesting
- **Function Parameters**: Max 4 parameters per function

### ESLint Configuration

Architecture rules are enforced through ESLint:

```javascript
// Automatically configured in eslint.config.mjs
'max-lines': ['warn', { max: 500, skipBlankLines: true, skipComments: true }]
'max-lines-per-function': ['warn', { max: 100, skipBlankLines: true, skipComments: true }]
'complexity': ['warn', { max: 10 }]
'max-depth': ['warn', { max: 4 }]
'max-params': ['warn', { max: 4 }]
```

### Pre-commit Hooks

Pre-commit hooks prevent architectural regression:

- Files exceeding 800 lines are blocked from commits
- Clear error messages guide developers to refactoring tools
- Automatic architecture checks run on every commit

### Development Workflow

#### Daily Development

```bash
# Before starting work - check current architecture health
yarn analyze

# During development - validate changes
yarn check:architecture

# Before committing - ensure quality standards
yarn pre-commit
```

#### Weekly Architecture Review

```bash
# Generate stakeholder-friendly HTML report
yarn analyze:html

# Open reports/architecture-report.html in browser
# Review quality trends and hotspots
```

#### Refactoring Large Files

When encountering files exceeding size limits:

1. **Analyze the file**:

   ```bash
   yarn check:files -- --file src/path/to/large-file.tsx
   ```

2. **Get specific recommendations**:

   ```bash
   yarn analyze -- --detailed --file src/path/to/large-file.tsx
   ```

3. **Apply refactoring patterns** (see docs/REFACTORING_GUIDE.md)

4. **Validate improvements**:
   ```bash
   yarn check:architecture
   ```

## Troubleshooting

### Common Issues

**Port already in use**: Kill process on port 3000
**Supabase errors**: Check environment variables and database connection
**Build failures**: Run `yarn type-check`

### Architecture Issues

**File size errors**: Use `yarn check:files` for specific recommendations
**Complexity warnings**: Use `yarn check:complexity` for detailed analysis
**Pre-commit failures**: Run `yarn pre-commit` to see specific issues

### Architecture Tools Not Working

**Scripts not found**: Ensure all dependencies are installed with `yarn install`
**Permission errors**: Check that scripts/ directory has execute permissions
**Report generation fails**: Check that reports/ directory exists and is writable
