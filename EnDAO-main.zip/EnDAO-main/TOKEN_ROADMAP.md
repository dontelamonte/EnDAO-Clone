# EnDAO Token Architecture Roadmap

**Document Purpose**: Economic infrastructure roadmap for the EnDAO token ecosystem
**Target Audience**: Engineering, Treasury, Legal, Strategic Planning
**Status**: Strategic Planning Document
**Last Updated**: December 6, 2025

---

## Executive Summary

This document outlines the 4-phase token architecture for EnDAO's economic layer. Unlike platform features (see [PLATFORM_ROADMAP.md](./PLATFORM_ROADMAP.md)), these tokens represent **opt-in economic primitives** that enable:

1. **Protocol Governance** (EDG) - Stakeholder decision-making and fee discounts
2. **Payment Infrastructure** (TCR) - Fiat-bridged labor marketplace payments
3. **Labor Equity** (TEQ) - Soulbound membership equity based on work contribution

**Critical Note**: This roadmap documents economic infrastructure architecture for planning purposes only. All technical specifications, valuation methodologies, regulatory strategies, and legal entity structures **require validation by qualified legal counsel, certified public accountants, securities law specialists, and compliance experts** before implementation.

Nothing in this document constitutes legal advice, tax advice, or investment advice.

---

## Table of Contents

1. [Token Philosophy](#token-philosophy)
2. [Token Phase 0: Revenue Infrastructure (LIVE)](#token-phase-0-revenue-infrastructure-live)
3. [Token Phase 1: EDG Governance Token](#token-phase-1-edg-governance-token)
4. [Token Phase 2: TCR Payment & TEQ Equity](#token-phase-2-tcr-payment--teq-equity)
5. [Token Phase 3: Advanced Marketplace](#token-phase-3-advanced-marketplace)
6. [Token → Platform Integration](#token--platform-integration)
7. [Legal-Technical Bridge](#legal-technical-bridge)
8. [Risk Assessment](#risk-assessment)
9. [Related Documents](#related-documents)

---

## Token Philosophy

### Core Principles

**Separation of Concerns**:

- Platform governance (EDG) ≠ DAO governance (existing proposal system)
- Payment utility (TCR) ≠ Equity ownership (TEQ)
- **Opt-in participation**: DAOs can use EnDAO without touching tokens

**Labor-Value Alignment**:

- TEQ equity minted based on verified hours × market rates (no speculative valuation)
- **Cost-Plus methodology** replaces complex "Health Score" metrics
- Anti-gaming controls prevent inflation abuse

**Regulatory Compliance First**:

- Wyoming DUNA entity structure (backup: Delaware PBC + 501(c)(3))
- 1099-DA tax reporting for TCR transactions
- Soulbound TEQ prevents securities classification (non-transferable)

**The Portability Test**:

- Core features remain free and exportable
- Can a DAO leave EnDAO with their governance history, treasury records, and member data?
- If yes → utility. If no → rent seeking.

**Reference**: See [MASTER_IMPLEMENTATION_SPEC.md](./docs/MASTER_IMPLEMENTATION_SPEC.md) §7.3 for portability implementation.

---

### Anti-Gaming Framework

The token system includes multiple layers of protection against economic abuse:

| Attack Vector       | Control Mechanism        | Implementation                                  | Reference        |
| ------------------- | ------------------------ | ----------------------------------------------- | ---------------- |
| **Rate Inflation**  | LaborOracle rate caps    | Max $500/hr ceiling, governance-controlled      | MASTER_SPEC §2.4 |
| **Hour Inflation**  | Weekly hour caps         | Max 60 hrs/week per contributor                 | MASTER_SPEC §2.4 |
| **Phantom Work**    | Attestation requirements | Supervisor verification via EAS above $5,000/mo | MASTER_SPEC §2.5 |
| **Sybil Attacks**   | Identity verification    | KYC for TCR bridge access ($10K threshold)      | MASTER_SPEC §2.2 |
| **Emergency Abuse** | Governance freeze        | ENDAO vote can pause TEQ minting                | MASTER_SPEC §2.3 |
| **Quality Gaming**  | Quality multipliers      | 0.8x - 1.2x based on client ratings             | MASTER_SPEC §2.4 |

**LaborOracle Controls (Technical Implementation)**:

```solidity
// contracts/LaborOracle.sol
struct JobType {
    uint256 ratePerHour;         // In USD cents (e.g., 10000 = $100/hr)
    uint256 maxRateCap;          // Anti-gaming: absolute ceiling
    uint256 maxHoursPerWeek;     // Anti-gaming: prevent over-reporting
    bool requiresAttestation;    // Requires EAS attestation
    bool isActive;
}

// Weekly hour tracking prevents gaming
mapping(address => mapping(uint256 => uint256)) public weeklyHours;

function calculateEquityValue(
    address contributor,
    uint256 jobTypeId,
    uint256 hoursWorked
) external returns (uint256 equityValue) {
    JobType storage job = jobTypes[jobTypeId];
    require(job.isActive, "Job type inactive");

    // Anti-gaming: Check weekly hour cap
    uint256 currentWeek = block.timestamp / 1 weeks;
    uint256 newWeeklyTotal = weeklyHours[contributor][currentWeek] + hoursWorked;
    require(newWeeklyTotal <= job.maxHoursPerWeek, "Exceeds weekly cap");

    weeklyHours[contributor][currentWeek] = newWeeklyTotal;

    // Calculate: hours × rate (in cents) / 100 = USD value
    equityValue = (hoursWorked * job.ratePerHour) / 100;

    return equityValue;
}
```

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.4 for full LaborOracle specification.

---

### Fee Distribution Architecture

**Revenue Model Philosophy**: "Utility, not rent seeking"

Platform sustainability through transparent, on-chain fee collection and distribution.

**Fee Structure**:

| Fee Type             | Rate | Applied To                     | Purpose                |
| -------------------- | ---- | ------------------------------ | ---------------------- |
| **Contribution Fee** | 5%   | Inbound DAO deposits           | Platform operations    |
| **Transfer Fee**     | 2%   | Treasury-to-treasury transfers | Infrastructure costs   |
| **Marketplace Fee**  | 3%   | TCR service payments           | Marketplace operations |
| **Volume-Based Fee** | 0.5% | Above $10K/month threshold     | Scaling costs          |

**Fee Distribution (Post-EDG Launch)**:

```
┌─────────────────────────────────────────────────────────────────┐
│                     PROTOCOL REVENUE SOURCES                     │
├─────────────────────────────────────────────────────────────────┤
│  1. DAO Contribution Fees (5%)    │  FeeRouter.sol               │
│  2. DAO Transfer Fees (2%)        │  FeeRouter.sol               │
│  3. TCR Marketplace Fees (3%)     │  ServiceMarketplace.sol      │
│  4. Volume-Based Fees (0.5%)      │  Above $10K/mo threshold     │
│  5. Premium Subscriptions ($50+)  │  Tiered access (Phase 2)     │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
         ┌────────────────────────────┐
         │   FeeRouter Distribution   │
         │   (On-Chain, Transparent)  │
         └────────────┬───────────────┘
                      │
         ┌────────────┴────────────┬──────────────────┐
         ▼                         ▼                  ▼
  ┌──────────────┐        ┌──────────────┐   ┌──────────────┐
  │   DUNA       │ 70%    │  LP Rewards  │20%│ Development  │10%
  │   Treasury   │        │  (EDG/ETH)   │   │    Fund      │
  └──────┬───────┘        └──────────────┘   └──────────────┘
         │
         │ Governance-Controlled Allocation
         ▼
  ┌──────────────────────────────────┐
  │  TEQ Redemption Pool (40%)       │
  │  Team Compensation (30%)         │
  │  Infrastructure (20%)            │
  │  Community Grants (10%)          │
  └──────────────────────────────────┘
```

**Smart Contract Implementation**:

```solidity
// contracts/FeeRouterV2.sol
contract FeeRouterV2 is FeeRouter {
    uint256 public constant TREASURY_SHARE = 70;      // 70%
    uint256 public constant LP_SHARE = 20;            // 20%
    uint256 public constant DEVELOPMENT_SHARE = 10;   // 10%

    address public treasuryAddress;
    address public lpRewardsAddress;
    address public developmentAddress;

    function distributeFees(uint256 amount) external {
        uint256 treasuryAmount = (amount * TREASURY_SHARE) / 100;
        uint256 lpAmount = (amount * LP_SHARE) / 100;
        uint256 devAmount = amount - treasuryAmount - lpAmount;

        tcr.transfer(treasuryAddress, treasuryAmount);      // → DUNA Treasury
        tcr.transfer(lpRewardsAddress, lpAmount);           // → LP Staking
        tcr.transfer(developmentAddress, devAmount);        // → Core Team

        emit FeesDistributed(treasuryAmount, lpAmount, devAmount);
    }
}
```

**EDG Staker Fee Discounts**:

| EDG Staked | Contribution Fee | Transfer Fee   | Annual Savings (on $100K inflow) |
| ---------- | ---------------- | -------------- | -------------------------------- |
| 0          | 5.0%             | 2.0%           | $0                               |
| 10,000     | 2.5% (50% off)   | 1.0% (50% off) | $3,500                           |
| 50,000     | 0% (100% off)    | 0% (100% off)  | $7,000                           |

**Transparency Requirements**:

- All fee distribution transactions on-chain (Base Mainnet)
- Quarterly financial reports published by DUNA
- EDG governance can audit and adjust distribution percentages
- Real-time dashboard showing fee collection and allocation

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §7.1-7.2 for revenue model details.

---

## Token Phase 0: Revenue Infrastructure (LIVE)

### Current State (Production)

| Component                | Status           | Network      | Address                                      |
| ------------------------ | ---------------- | ------------ | -------------------------------------------- |
| **FeeRouter.sol**        | ✅ LIVE          | Base Mainnet | `0xf8786857eD04621d6e81959aAb36e422F687E4c8` |
| **Platform Fees**        | ✅ LIVE          | -            | 5% contribution / 2% transfer                |
| **Tiered Subscriptions** | 🟡 Schema exists | Firestore    | Not enforced                                 |

### FeeRouter.sol (Live Contract)

**Purpose**: Transparent, on-chain fee collection for platform sustainability

**Fee Structure**:

- **Contribution Fee**: 5% on inbound deposits to DAO treasuries
- **Transfer Fee**: 2% on treasury-to-treasury transfers
- **Zero fees**: On internal DAO operations (proposals, voting, member management)

**Revenue Safe**:

- All fees route to: `0x00dc44400adb57a85364c97442bd5e95faa861e7` (Base Mainnet)
- Gnosis Safe 2-of-3 multi-sig controlled by core team
- Transparent transaction history on BaseScan

**Key Features**:

- Gnosis Safe integration via `onERC721Received` hook
- Automated fee calculation and routing
- Zero-knowledge fee enforcement (no governance vote required for standard rates)
- Treasury transparency (all fees visible on-chain)

**Example Fee Calculation**:

```
User contributes $1,000 to DAO treasury:
→ FeeRouter captures 5% = $50
→ DAO receives $950
→ $50 routes to EnDAO Revenue Safe
```

**Reference**: See live contract on [BaseScan](https://basescan.org/address/0xf8786857eD04621d6e81959aAb36e422F687E4c8).

---

### Tiered Subscriptions (Planned)

**Current Status**: Schema exists in Firestore `dao` collection, not enforced
**Priority**: High (enables API revenue, enterprise features)

**Proposed Tiers**:

| Tier           | Monthly Price | Treasury Cap | Fee Rate    | Features                                |
| -------------- | ------------- | ------------ | ----------- | --------------------------------------- |
| **Free**       | $0            | Up to $10K   | 5% / 2%     | 1 DAO, core governance                  |
| **Growth**     | $50           | Up to $100K  | 3.5% / 1.5% | Unlimited DAOs, priority support        |
| **Business**   | $200          | Up to $1M    | 2% / 1%     | Read-only API, custom roles             |
| **Enterprise** | Custom        | Unlimited    | 1% / 0.5%   | Full API, white-label, compliance tools |

**Revenue Opportunity**:

- 1,000 DAOs × 20% paid tier adoption = 200 subscriptions
- Average tier: $125/month
- Annual subscription revenue: **$300K**

**Use Cases by Tier**:

| Tier       | Target User                  | Example                                    |
| ---------- | ---------------------------- | ------------------------------------------ |
| Free       | Community groups, hobbyists  | Book club with $500 treasury               |
| Growth     | Small businesses, nonprofits | HOA with $50K annual budget                |
| Business   | Established organizations    | 501(c)(3) nonprofit with $500K budget      |
| Enterprise | Large networks, federations  | Cooperative network with multiple chapters |

**Implementation Requirements**:

1. Stripe billing integration
2. Subscription management UI
3. API key generation service
4. Usage monitoring and throttling
5. Downgrade/upgrade flows

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §7.1 for revenue streams.

---

## Token Phase 1: EDG Governance Token

### EDG Token Overview

**Purpose**: Protocol-level governance and fee discounts

**Technical Specification**:

- **Standard**: ERC-20Votes + ERC-4626 (staking vault)
- **Total Supply**: 1,000,000,000 EDG (1 billion, fixed)
- **Transferable**: ✅ Yes
- **Network**: Base Mainnet
- **Launch**: Phase 1 (following Social Recovery + Audit)

**Why EDG First?**
EDG enables protocol governance before the marketplace exists. Holders can vote on:

- Treasury allocation decisions
- Rate setting for LaborOracle
- Committee (Sub-DAO) admission
- Protocol parameter changes
- Emergency governance freezes

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.1, §2.6.1, §10.1.4 for full specification.

---

### EDG Token Distribution

| Allocation              | Amount | %   | Vesting               | Cliff     | Purpose                    |
| ----------------------- | ------ | --- | --------------------- | --------- | -------------------------- |
| **Team & Founders**     | 100M   | 10% | 48 months             | 12 months | Core team incentive        |
| **Early Contributors**  | 150M   | 15% | 24 months             | 6 months  | Pre-launch contributors    |
| **Community Treasury**  | 250M   | 25% | Governance-controlled | None      | DAO-voted initiatives      |
| **Protocol Reserves**   | 200M   | 20% | 60 months             | 24 months | Strategic reserves         |
| **Ecosystem Growth**    | 150M   | 15% | 36 months             | None      | Partnerships, integrations |
| **Liquidity Provision** | 100M   | 10% | Immediate             | None      | DEX liquidity              |
| **Airdrops & Rewards**  | 50M    | 5%  | 12 months             | None      | Community rewards          |

**Vesting Implementation**:

```solidity
// contracts/EDGVesting.sol
contract EDGVesting is AccessControl {
    struct VestingSchedule {
        uint256 totalAmount;
        uint256 startTime;
        uint256 cliffDuration;
        uint256 vestingDuration;
        uint256 releasedAmount;
        bool revocable;
        bool revoked;
    }

    function vestedAmount(address beneficiary) public view returns (uint256) {
        VestingSchedule storage schedule = schedules[beneficiary];

        if (schedule.revoked) {
            return schedule.releasedAmount;
        }

        uint256 elapsed = block.timestamp - schedule.startTime;

        // Before cliff: 0
        if (elapsed < schedule.cliffDuration) {
            return 0;
        }

        // After full vesting: 100%
        if (elapsed >= schedule.vestingDuration) {
            return schedule.totalAmount;
        }

        // Linear vesting after cliff
        return (schedule.totalAmount * elapsed) / schedule.vestingDuration;
    }
}
```

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.6.1 for vesting details.

---

### EDG Governance Rights

**What EDG Holders Vote On**:

| Category                | Examples                                                 | Impact                |
| ----------------------- | -------------------------------------------------------- | --------------------- |
| **Fee Parameters**      | Contribution fee rate (0-10%), Transfer fee rate (0-5%)  | Platform revenue      |
| **Treasury Allocation** | Protocol spending, development budgets, grants           | Resource distribution |
| **Protocol Upgrades**   | Contract deployments, feature rollouts, integrations     | Platform evolution    |
| **Marketplace Rules**   | Service categories, rate caps, dispute resolution        | Economic policy       |
| **Token Economics**     | TCR peg mechanisms, TEQ redemption windows               | Economic stability    |
| **Emergency Actions**   | Circuit breakers, security responses, governance freezes | Risk management       |

**Governance Process**:

- **Proposal Creation**: Requires 100,000 EDG (0.1% of supply)
- **Voting Period**: 7 days
- **Quorum**: 4% of total voting power must participate
- **Pass Threshold**: 66% of votes cast must approve (supermajority)
- **Timelock**: 48 hours after passing before execution (except emergencies)

**Voting Power Calculation**:

```typescript
// Voting power = (balance + staked) × multiplier + delegated - delegatedAway
interface VotingPowerCalculation {
  edgBalance: bigint; // Raw EDG balance
  stakedBalance: bigint; // EDG in vault
  delegatedPower: bigint; // Power delegated from others
  delegatedAway: bigint; // Power delegated to others
  totalVotingPower: bigint; // Final calculation
  percentageOfTotal: number; // % of total voting power
}

// Staking multiplier: 1.5x for staked tokens
const stakingMultiplier = 150n; // 1.5x in basis points
const rawPower = balance + (staked * stakingMultiplier) / 100n;
const totalVotingPower = rawPower + delegated - delegatedAway;
```

**Quadratic Voting (Phase 3)**:

```
Quadratic Voting Power = sqrt(totalVotingPower)
```

- Reduces whale influence
- Enables more democratic decision-making
- Optional governance module

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.7.1 for voting integration.

---

### EDG Staking Vault (Fee Discounts)

**Purpose**: Incentivize long-term holding through utility (fee reductions)

**Technical Implementation**:

```solidity
// contracts/EDGVault.sol - ERC-4626 Staking Vault
contract EDGVault is ERC4626 {
    uint256 public constant GOLD_THRESHOLD = 50_000 ether;   // 50,000 EDG
    uint256 public constant SILVER_THRESHOLD = 10_000 ether; // 10,000 EDG

    function getDiscountTier(address user) public view returns (uint256) {
        uint256 balance = balanceOf(user);
        if (balance >= GOLD_THRESHOLD) return 100;  // 100% fee discount
        if (balance >= SILVER_THRESHOLD) return 50; // 50% fee discount
        return 0;
    }

    function calculateDiscountedFee(address user, uint256 baseFee)
        external view returns (uint256)
    {
        uint256 discount = getDiscountTier(user);
        return (baseFee * (100 - discount)) / 100;
    }
}
```

**Discount Tiers**:

| Tier       | Staked EDG Required | Contribution Fee | Transfer Fee   | Savings on $100K Inflow |
| ---------- | ------------------- | ---------------- | -------------- | ----------------------- |
| **None**   | 0                   | 5.0%             | 2.0%           | $0                      |
| **Silver** | 10,000 EDG          | 2.5% (50% off)   | 1.0% (50% off) | $3,500                  |
| **Gold**   | 50,000 EDG          | 0% (100% off)    | 0% (100% off)  | $7,000                  |

**Example ROI Calculation**:

```
DAO with $100K annual treasury inflow:
→ Baseline fees: $5K contribution + $2K transfer = $7K total

Gold Tier (50K EDG staked):
→ Fee savings: $7K/year
→ If EDG market price = $0.10
→ 50K EDG × $0.10 = $5K investment
→ ROI: 40% annually (from fee savings alone)
```

**Staking Properties**:

- **Non-custodial**: You retain ownership (ERC-4626 shares)
- **No lock-up**: Unstake anytime, no penalty
- **No rewards**: Discount is the utility (no inflationary token rewards)
- **Transferable**: ERC-4626 shares can be sold (secondary market for fee discounts)

**Integration with FeeRouter**:

```solidity
// FeeRouterV2.sol checks EDGVault before calculating fees
function calculateFee(address payer, uint256 amount, uint256 baseFeeBps)
    public view returns (uint256 fee, uint256 discount)
{
    uint256 discountTier = edgVault.getDiscountTier(payer);

    // Gold: 100% discount, Silver: 50% discount
    uint256 discountedFeeBps = baseFeeBps * (100 - discountTier) / 100;
    fee = (amount * discountedFeeBps) / 10000;
    discount = (amount * baseFeeBps / 10000) - fee;

    return (fee, discount);
}
```

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.1 for EDGVault specification.

---

### EDG Liquidity Strategy

**DEX Liquidity Pools**:

| Pool     | Platform          | Allocation | Initial TVL Target | APR Strategy             |
| -------- | ----------------- | ---------- | ------------------ | ------------------------ |
| EDG/ETH  | Uniswap V3 (Base) | 40M EDG    | $5M                | Liquidity mining rewards |
| EDG/USDC | Uniswup V3 (Base) | 30M EDG    | $3M                | Liquidity mining rewards |
| EDG/TCR  | Aerodrome (Base)  | 30M EDG    | $2M                | Liquidity mining rewards |

**Liquidity Mining Incentives**:

```solidity
// contracts/LiquidityMining.sol
contract LiquidityMining is Ownable {
    IERC20 public edgToken;
    IERC20 public lpToken;

    uint256 public rewardRate;           // EDG per second
    uint256 public totalSupply;          // Total LP tokens staked

    function earned(address account) public view returns (uint256) {
        return (
            balances[account] * (rewardPerToken() - userRewardPerTokenPaid[account]) / 1e18
        ) + rewards[account];
    }

    function stake(uint256 amount) external updateReward(msg.sender) {
        totalSupply += amount;
        balances[msg.sender] += amount;
        lpToken.transferFrom(msg.sender, address(this), amount);
        emit Staked(msg.sender, amount);
    }

    function getReward() external updateReward(msg.sender) {
        uint256 reward = rewards[msg.sender];
        if (reward > 0) {
            rewards[msg.sender] = 0;
            edgToken.transfer(msg.sender, reward);
            emit RewardPaid(msg.sender, reward);
        }
    }
}
```

**Initial Liquidity Provision**:

- 100M EDG (10% of total supply) allocated to DEX liquidity
- Paired with USDC/ETH from treasury or fundraising
- Gradual liquidity deployment (prevent manipulation)

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.6.4 for liquidity strategy.

---

## Token Phase 2: TCR Payment & TEQ Equity

### TCR (TimeCredits) Payment Token

**Purpose**: Stablecoin-pegged payment utility for labor marketplace

**Technical Specification**:

- **Standard**: ERC-20 + ERC-2612 (permit for gasless approvals)
- **Supply Model**: Elastic (mint on deposit, burn on withdrawal)
- **Peg**: 1 TCR = $1.00 USD
- **Transferable**: ✅ Yes
- **Network**: Base Mainnet
- **Launch**: Phase 2 (following EDG deployment)

**Why TCR?**

- **Fiat bridge**: Users buy TCR with credit card/bank transfer (no crypto knowledge required)
- **Stable pricing**: No volatility risk for service providers
- **Atomic payments**: TCR payment + TEQ equity minting in single transaction
- **Platform revenue**: 3% fee on marketplace transactions

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.2, §2.6.2 for full specification.

---

### TCR Mint/Burn Mechanics

**MINT FLOW (Fiat → TCR)**:

```
1. User deposits $100 USDC via Stripe/Circle
2. Bridge service verifies deposit
3. Mints 100 TCR to user's wallet
4. TCR Supply: +100
```

**BURN FLOW (TCR → Fiat)**:

```
1. User initiates withdrawal of 100 TCR
2. Smart contract burns 100 TCR from user's wallet
3. Bridge service releases $100 USDC to user's bank/wallet
4. TCR Supply: -100
```

**Collateralization**:

| Collateral Type     | Ratio | Accepted Assets                  | Risk Level |
| ------------------- | ----- | -------------------------------- | ---------- |
| **Fiat Reserves**   | 100%  | USD (bank), USDC, USDT           | Low        |
| **Stablecoin**      | 100%  | USDC, DAI, FRAX                  | Low        |
| **Volatile Assets** | 150%  | ETH, BTC (with Chainlink oracle) | Medium     |

**Bridge Service Architecture**:

```typescript
// src/lib/services/bridge/tcr-bridge.service.ts
interface BridgeConfig {
  minDepositAmount: number; // $10 minimum
  maxDepositAmount: number; // $100,000 per transaction
  dailyLimit: number; // $1,000,000 per day
  kycThreshold: number; // $10,000 requires KYC
  processingTime: {
    ach: number; // 3-5 business days
    wire: number; // 1-2 business days
    stablecoin: number; // < 1 minute
  };
}

class TCRBridgeService {
  async initiateDeposit(
    userId: string,
    amount: number,
    paymentMethod: 'ach' | 'wire' | 'stablecoin'
  ): Promise<DepositRequest> {
    // Validate user and KYC
    const user = await this.userService.getUser(userId);
    if (amount >= this.config.kycThreshold && !user.kycVerified) {
      throw new Error('KYC required for deposits over $10,000');
    }

    // Check daily limits
    const todayVolume = await this.getDailyVolume(userId);
    if (todayVolume + amount > this.config.dailyLimit) {
      throw new Error('Daily limit exceeded');
    }

    // Create deposit request
    const request = await this.createDepositRequest({
      userId,
      amount,
      paymentMethod,
      status: 'pending',
      estimatedCompletion: this.estimateCompletion(paymentMethod),
    });

    return request;
  }

  async confirmDeposit(requestId: string): Promise<void> {
    const request = await this.getRequest(requestId);

    // Verify funds received
    await this.verifyFundsReceived(request);

    // Mint TCR to user's wallet
    const userWallet = await this.walletService.getUserWallet(request.userId);
    await this.tcrContract.mint(userWallet, request.amount * 1e18);

    // Record for compliance (1099-DA)
    await this.complianceService.recordMint({
      userId: request.userId,
      amount: request.amount,
      source: request.paymentMethod,
      timestamp: new Date(),
    });
  }
}
```

**Processing Times**:

- **Stablecoin deposits**: < 1 minute (on-chain confirmation)
- **ACH deposits**: 3-5 business days (bank clearing)
- **Wire deposits**: 1-2 business days (bank clearing)

**Bridge Security**:

- Multi-sig controls on minting authority
- Rate limiting on withdrawals
- Daily/monthly volume caps
- KYC/AML compliance via Stripe/Circle

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.6.2 for bridge architecture.

---

### TEQ (Time-Equity Protocol) Soulbound Token

**Purpose**: Non-transferable equity minted based on verified labor contribution

**Technical Specification**:

- **Standard**: ERC-20 (modified for soulbound) + ERC-20Votes
- **Supply Model**: Inflationary (no hard cap, labor-backed)
- **Transferable**: ❌ No (blocks all transfers except mint/burn)
- **Votable**: ✅ Yes (governance voting within DAOs, if enabled)
- **Network**: Base Mainnet
- **Launch**: Phase 2 (following ServiceMarketplace deployment)

**Why Soulbound?**

- Prevents speculation (cannot trade equity for short-term gain)
- Aligns with "equity for contributors, not investors" philosophy
- Securities law compliance (no secondary market = not a security)
- Encourages long-term participation

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.3-2.5, §2.6.3 for full specification.

---

### Soulbound Implementation

```solidity
// contracts/TEQ.sol
contract TEQ is ERC20, ERC20Votes, AccessControl {
    error Soulbound();
    bytes32 public constant CONTROLLER_ROLE = keccak256("CONTROLLER_ROLE");

    // Track cumulative labor value for each holder
    mapping(address => uint256) public cumulativeLaborValueUSD;

    constructor() ERC20("Time-Equity Protocol", "TEQ") ERC20Permit("TEQ") {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    function mint(address to, uint256 amount, uint256 laborValueUSD)
        external onlyRole(CONTROLLER_ROLE)
    {
        cumulativeLaborValueUSD[to] += laborValueUSD;
        _mint(to, amount);
        emit EquityMinted(to, amount, laborValueUSD, cumulativeLaborValueUSD[to]);
    }

    // SOULBOUND: Block all transfers
    function _update(address from, address to, uint256 value)
        internal override(ERC20, ERC20Votes)
    {
        // Allow mint (from == 0) and burn (to == 0), block transfers
        if (from != address(0) && to != address(0)) {
            revert Soulbound();
        }
        super._update(from, to, value);
    }

    event EquityMinted(
        address indexed to,
        uint256 amount,
        uint256 laborValueUSD,
        uint256 cumulative
    );
}
```

**Key Properties**:

- `mint()`: Only ServiceMarketplace can mint (CONTROLLER_ROLE)
- `_update()`: Reverts on transfer attempts (soulbound enforcement)
- `cumulativeLaborValueUSD`: Tracks total labor value for redemption calculations
- `ERC20Votes`: Enables DAO governance participation (if DAO opts in)

---

### Cost-Plus Valuation (LaborOracle)

**Valuation Model**: `TEQ Minted = Hours Worked × Market Rate × Quality Multiplier`

**Components**:

- **Hours Worked**: 1-60 hours per week (verified by EAS attestation)
- **Market Rate**: $50-500/hr (governance-controlled, job type specific)
- **Quality Multiplier**: 0.8x - 1.2x (based on client rating)

**LaborOracle Job Types (Initial Beta)**:

| Job Type ID | Category      | Base Rate | Max Cap | Max Hours/Week | Attestation Required |
| ----------- | ------------- | --------- | ------- | -------------- | -------------------- |
| 1           | General Labor | $50/hr    | $75/hr  | 40             | No                   |
| 2           | Skilled Trade | $75/hr    | $125/hr | 40             | Above $2,500/mo      |
| 3           | Professional  | $100/hr   | $200/hr | 40             | Above $5,000/mo      |
| 4           | Executive     | $150/hr   | $300/hr | 30             | Always               |
| 5           | Advisory      | $200/hr   | $500/hr | 20             | Always               |

**Example Calculation**:

```
Frontend Developer works 40 hours in Week 1:
- Job Type: Professional (ID=3, $100/hr base, $200/hr cap)
- Hours: 40 hours
- Quality Rating: 4.5/5.0 → Quality Multiplier: 1.1x
- TEQ Minted: 40 hrs × $100/hr × 1.1 = $4,400 worth of equity
- ServiceMarketplace mints 4,400 TEQ to developer
```

**LaborOracle Contract**:

```solidity
// contracts/LaborOracle.sol
contract LaborOracle is AccessControl {
    bytes32 public constant UPDATER_ROLE = keccak256("UPDATER_ROLE");

    struct JobType {
        uint256 ratePerHour;         // In USD cents (e.g., 10000 = $100/hr)
        uint256 maxRateCap;          // Anti-gaming: absolute ceiling
        uint256 maxHoursPerWeek;     // Anti-gaming: prevent over-reporting
        bool requiresAttestation;    // Requires EAS attestation
        bool isActive;
    }

    mapping(uint256 => JobType) public jobTypes;
    mapping(address => mapping(uint256 => uint256)) public weeklyHours;

    function calculateEquityValue(
        address contributor,
        uint256 jobTypeId,
        uint256 hoursWorked
    ) external returns (uint256 equityValue) {
        JobType storage job = jobTypes[jobTypeId];
        require(job.isActive, "Job type inactive");

        // Anti-gaming: Check weekly hour cap
        uint256 currentWeek = block.timestamp / 1 weeks;
        uint256 newWeeklyTotal = weeklyHours[contributor][currentWeek] + hoursWorked;
        require(newWeeklyTotal <= job.maxHoursPerWeek, "Exceeds weekly cap");

        weeklyHours[contributor][currentWeek] = newWeeklyTotal;

        // Calculate: hours × rate (in cents) / 100 = USD value
        equityValue = (hoursWorked * job.ratePerHour) / 100;

        return equityValue;
    }
}
```

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.4 for LaborOracle specification.

---

### ServiceMarketplace (Double-Dip Compensation)

**Purpose**: Labor marketplace where workers receive BOTH payment (TCR) AND equity (TEQ)

**The "Double-Dip" Flow**:

```
1. Client creates job
   → Deposits 1,000 TCR to escrow
   → Specifies job type (Professional), estimated hours (10)

2. Provider accepts job
   → Completes 10 hours of work
   → Submits for client approval

3. Client approves completion
   → ServiceMarketplace executes atomically:

   a) PAY PROVIDER IN TCR:
      - Base payout: 1,000 TCR
      - Protocol fee (3%): 30 TCR
      - EDG discount (Gold tier): -30 TCR (100% fee waived)
      - Provider receives: 1,000 TCR (no fee due to discount)

   b) SEND FEE TO TREASURY:
      - 0 TCR (waived due to Gold tier EDG staking)

   c) MINT EQUITY (TEQ):
      - LaborOracle.calculateEquityValue(provider, jobTypeId=3, hours=10)
      - 10 hrs × $100/hr = $1,000 equity value
      - Mint 1,000 TEQ to provider

RESULT: Provider receives 1,000 TCR + 1,000 TEQ
```

**Smart Contract Implementation**:

```solidity
// contracts/ServiceMarketplace.sol
contract ServiceMarketplace is ReentrancyGuard, AccessControl {
    IERC20 public tcr;
    TEQ public teq;
    LaborOracle public laborOracle;
    EDGVault public edgVault;
    address public treasury;
    uint256 public protocolFeeBps = 300; // 3%

    struct Job {
        address client;
        address provider;
        uint256 amount;          // TCR amount
        uint256 jobTypeId;
        uint256 hoursWorked;
        JobStatus status;
    }

    enum JobStatus { Created, InProgress, Completed, Disputed, Cancelled }

    mapping(uint256 => Job) public jobs;
    uint256 public nextJobId;

    function completeJob(uint256 jobId, uint256 actualHours)
        external nonReentrant
    {
        Job storage job = jobs[jobId];
        require(msg.sender == job.client, "Only client");
        require(job.status == JobStatus.InProgress, "Invalid status");

        job.hoursWorked = actualHours;
        job.status = JobStatus.Completed;

        // Calculate fee with EDG discount
        uint256 baseFee = (job.amount * protocolFeeBps) / 10000;
        uint256 actualFee = edgVault.calculateDiscountedFee(job.client, baseFee);
        uint256 payout = job.amount - actualFee;

        // THE DOUBLE-DIP:
        // 1. Pay provider in TCR
        tcr.transfer(job.provider, payout);

        // 2. Send fee to treasury
        if (actualFee > 0) {
            tcr.transfer(treasury, actualFee);
        }

        // 3. Calculate and mint equity (TEQ)
        uint256 equityValue = laborOracle.calculateEquityValue(
            job.provider,
            job.jobTypeId,
            actualHours
        );
        teq.mint(job.provider, equityValue * 1e18, equityValue);

        emit JobCompleted(jobId, payout, equityValue, actualFee);
    }

    event JobCompleted(
        uint256 indexed jobId,
        uint256 payout,
        uint256 equityValue,
        uint256 fee
    );
}
```

**Job Lifecycle**:

1. `Created` - Client deposits TCR to escrow
2. `InProgress` - Provider accepts job
3. `Completed` - Client approves, TCR + TEQ distributed
4. `Disputed` - Escalated to arbitration (Phase 3)
5. `Cancelled` - Refund to client

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.5 for ServiceMarketplace specification.

---

### TEQ Redemption Mechanics

**Liquidity Events** (How TEQ Holders Exit):

| Mechanism                    | Process                                           | Frequency                     |
| ---------------------------- | ------------------------------------------------- | ----------------------------- |
| **Treasury Buybacks**        | DUNA votes to buy back TEQ at Cost-Plus valuation | As needed (governance vote)   |
| **Dividend Distribution**    | DUNA distributes surplus revenue proportionally   | Quarterly (if surplus exists) |
| **Annual Redemption Window** | 30-day window for holders to request redemption   | Once per year (March 1-31)    |

**Redemption Window Economics**:

```typescript
// src/lib/services/teq/redemption.service.ts
interface RedemptionWindow {
  windowId: string;
  startDate: Date;
  endDate: Date;
  redemptionRate: number; // TCR per TEQ
  maxRedemptionPool: number; // Total TCR available
  totalRequested: number;
  status: 'upcoming' | 'active' | 'processing' | 'complete';
}

class TEQRedemptionService {
  async createRedemptionWindow(
    year: number,
    redemptionPoolTCR: number
  ): Promise<RedemptionWindow> {
    // Calculate redemption rate based on:
    // 1. Total TEQ supply
    // 2. Available redemption pool
    // 3. Historical redemption demand

    const teqSupply = await this.teqContract.totalSupply();
    const historicalDemand = await this.getHistoricalDemandRate();

    // Base rate: pool / (supply × expected demand rate)
    const expectedDemand = (Number(teqSupply) / 1e18) * historicalDemand;
    const redemptionRate = redemptionPoolTCR / expectedDemand;

    const window: RedemptionWindow = {
      windowId: `redemption-${year}`,
      startDate: new Date(`${year}-03-01`),
      endDate: new Date(`${year}-03-31`),
      redemptionRate: Math.min(redemptionRate, 1.0), // Cap at 1:1
      maxRedemptionPool: redemptionPoolTCR,
      totalRequested: 0,
      status: 'upcoming',
    };

    return window;
  }
}
```

**Example Redemption**:

```
TEQ Total Supply: 10,000,000 TEQ
Redemption Pool: $3,000,000 TCR
Historical Demand: 40% request redemption
Expected Demand: 10M × 40% = 4M TEQ
Redemption Rate: $3M / 4M = $0.75 TCR per TEQ

If redemption rate < 1:1, holders may choose to hold for future windows.
```

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.6.3 for redemption economics.

---

## Token Phase 3: Advanced Marketplace

### Features Unlocked

**DAO-to-DAO Service Contracts**:

- DAO A hires DAO B for project
- Multi-party escrow in ServiceMarketplace
- Multi-sig approval required (both DAOs)
- TEQ equity split among DAO B contributors based on work contribution

**Dispute Resolution System**:

- Arbiter Agent (AI-assisted, human oversight)
- Evidence submission (IPFS + on-chain hash)
- Multi-sig arbitration panel (EDG-staked arbiters)
- Appeal mechanism (escalate to DUNA governance)
- Failed quality = voided TEQ (contributor keeps TCR but forfeits equity)

**Recurring Service Agreements**:

- Monthly retainer contracts
- Auto-renewal with cancellation notice
- Streaming payments (Sablier integration)
- Performance-based bonuses (Quality Multiplier > 1.0x)

**Reputation System**:

- On-chain provider ratings (EAS attestations)
- Client satisfaction scores (weighted by TCR volume)
- Dispute history transparency
- TEQ weighting based on reputation (future)

**Cross-DAO Marketplace**:

```
DAO A (needs web development)
    ↓ Creates job listing (10,000 TCR)
DAO B (provides web dev services)
    ↓ Accepts job, completes work
ServiceMarketplace executes:
    - Transfer 9,700 TCR to DAO B (97%)
    - Transfer 300 TCR to protocol (3% fee)
    - Mint TEQ to DAO B contributors (split by work contribution)
```

---

## Token → Platform Integration

### How Tokens Interact with Platform Primitives

| Platform Feature    | EDG Integration                         | TCR Integration                | TEQ Integration                   |
| ------------------- | --------------------------------------- | ------------------------------ | --------------------------------- |
| **DAO Creation**    | None (platform operates without tokens) | Optional: TCR treasury tier    | Optional: TEQ-weighted voting     |
| **Proposals**       | EDG governance for protocol changes     | None                           | TEQ voting power (if DAO enables) |
| **Treasury**        | EDG discount on FeeRouter fees          | TCR as payment method          | None                              |
| **Voting**          | EDG-weighted protocol governance        | None                           | TEQ-weighted DAO governance       |
| **Member Profiles** | Show EDG balance, staking tier          | Show TCR earnings, job history | Show TEQ equity, labor stats      |
| **Notifications**   | Governance vote alerts                  | TCR payment/withdrawal status  | TEQ minting confirmations         |
| **Reporting**       | EDG voting power dashboard              | TCR transaction ledger         | TEQ equity accumulation chart     |

### Integration with DAO-to-DAO Relationships (Phase 3+)

**Sub-DAO Budget Allocation**:

```
Parent DAO (has 1M TCR treasury)
    ↓ Allocates 100K TCR budget to Sub-DAO
Sub-DAO (receives 100K TCR)
    ↓ Pays contributors via ServiceMarketplace
Contributors earn TCR + TEQ
```

**Cross-DAO Service Contracts**:

```
Organization A needs legal services
    ↓ Creates job (5,000 TCR)
Law Firm DAO accepts
    ↓ Multiple attorneys work on case
ServiceMarketplace distributes:
    - 4,850 TCR to Law Firm DAO (97%)
    - 150 TCR to protocol (3%)
    - TEQ minted to each attorney proportionally
```

### Member Profile Integration

**Extended User Profile Schema**:

```typescript
// src/types/user.ts - Token integration fields
interface UserProfile {
  // Existing fields...
  uid: string;
  displayName?: string;
  avatar?: string;
  bio?: string;

  // Token integration fields
  walletAddresses: {
    primary: string; // Main wallet for token holdings
    privy?: string; // Privy embedded wallet
    external?: string[]; // Additional connected wallets
  };

  tokenBalances?: {
    edg: string; // Cached EDG balance
    teq: string; // Cached TEQ balance
    tcr: string; // Cached TCR balance
    lastUpdated: Timestamp;
  };

  vestingSchedules?: {
    edg?: {
      totalAmount: string;
      vestedAmount: string;
      nextVestDate: Timestamp;
    };
  };

  laborStats?: {
    totalHoursWorked: number;
    totalTCREarned: string;
    totalTEQEarned: string;
    averageHourlyRate: number;
    jobTypes: Record<number, number>; // jobTypeId -> hours
  };
}
```

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §2.7.3 for profile integration.

---

## Legal-Technical Bridge

### Wyoming DUNA Entity Structure

**Primary Path**: Wyoming DUNA (Decentralized Unincorporated Nonprofit Association)

**Entity Architecture**:

```
┌────────────────────────────────────────────────────────┐
│         Wyoming DUNA (Decentralized Unincorporated     │
│         Nonprofit Association)                         │
│                                                        │
│  Legal Recognition: Nonprofit, DAO-native structure    │
│  Tax Treatment: Pass-through to members               │
│  Governance: On-chain binding (EDG votes = legal votes)│
└────────────────────────┬───────────────────────────────┘
                         │
          ┌──────────────┴──────────────┐
          ▼                             ▼
  ┌───────────────────┐        ┌────────────────────┐
  │  DUNA Treasury    │        │  Authorized        │
  │  (Gnosis Safe)    │        │  Committees        │
  │                   │        │  (Sub-DAOs)        │
  │  Holds: TCR, ETH  │        │                    │
  │  Governed by: EDG │        │  Governed by: TEQ  │
  └───────────────────┘        └────────────────────┘
```

**Technical-Legal Mapping**:

| On-Chain Component        | Wyoming DUNA Equivalent     | Legal Enforceability                  |
| ------------------------- | --------------------------- | ------------------------------------- |
| **EDG Token Vote**        | Binding Member Vote         | ✅ Legally binding (per DUNA statute) |
| **TEQ Token Balance**     | Membership Interest         | ✅ Ownership stake (non-transferable) |
| **TCR Transaction**       | Commercial Contract         | ✅ Subject to 1099-DA reporting       |
| **Smart Contract Code**   | Operating Agreement Exhibit | ✅ Referenced in bylaws               |
| **ServiceMarketplace**    | DAO Commercial Activity     | ✅ Taxable revenue                    |
| **Sub-DAO (Gnosis Safe)** | Authorized Committee        | ✅ Delegated authority                |

**Formation Milestones**:

| Milestone                 | Activities                                                      | Dependencies                      |
| ------------------------- | --------------------------------------------------------------- | --------------------------------- |
| **DUNA Formation**        | File with Wyoming Secretary of State, draft operating agreement | Legal counsel engagement          |
| **EDG Deployment**        | Deploy governance token, establish voting mechanisms            | DUNA formation, audit completion  |
| **First Governance Vote** | Ratify operating agreement on-chain (binding vote)              | EDG distribution complete         |
| **TEQ Deployment**        | Deploy labor equity token, establish membership ledger          | ServiceMarketplace live           |
| **Tax-Exempt Status**     | IRS 501(c)(3) application (if pursuing nonprofit status)        | DUNA operational, 1+ year history |

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §8.1-8.2 for entity strategy.

---

### Tax Reporting (1099-DA)

**TCR Transactions Trigger Tax Reporting**:

```typescript
// src/lib/services/tax/1099-da.service.ts
interface Form1099DA {
  taxYear: number;
  payerInfo: {
    name: string;
    tin: string;
    address: string;
  };
  recipientInfo: {
    name: string;
    tin: string;
    address: string;
  };
  transactions: Array<{
    date: Date;
    description: string;
    grossProceeds: number;
    costBasis: number;
    gainLoss: number;
    shortLongTerm: 'short' | 'long';
  }>;
  totalGrossProceeds: number;
  totalCostBasis: number;
  totalGainLoss: number;
}

class TaxReportingService {
  async generate1099DA(userId: string, taxYear: number): Promise<Form1099DA> {
    // Aggregate all TCR transactions for user
    const transactions = await this.getUserTransactions(userId, taxYear);

    // Calculate cost basis (FIFO method)
    const processed = this.calculateCostBasis(transactions);

    // Generate form
    return this.buildForm(userId, taxYear, processed);
  }
}
```

**Reporting Thresholds**:

- TCR recipients: >$600/year requires 1099-DA
- ServiceMarketplace automatically generates forms
- Users download from tax reporting dashboard
- Integration with TaxBit/CoinTracker for multi-platform reporting

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §8.3 for tax reporting implementation.

---

### Backup Path: Delaware PBC + 501(c)(3) Foundation

**If Wyoming DUNA proves unworkable**:

| Entity                                        | Purpose                                  | Tax Treatment        |
| --------------------------------------------- | ---------------------------------------- | -------------------- |
| **Delaware PBC** (Public Benefit Corporation) | Commercial activity (ServiceMarketplace) | C-Corp taxation      |
| **501(c)(3) Foundation**                      | Ecosystem grants, public goods           | Tax-exempt nonprofit |

**Trade-offs**:

- **Wyoming DUNA**: DAO-native, simpler structure, pass-through taxation, limited precedent
- **Delaware PBC + Foundation**: Traditional recognition, complex tax, established precedent

**Decision Point**: Evaluate regulatory clarity and legal counsel recommendations before choosing path.

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md §8.1 for backup entity strategy.

---

## Risk Assessment

### Economic Risks

| Risk                           | Impact | Likelihood | Mitigation                                                   |
| ------------------------------ | ------ | ---------- | ------------------------------------------------------------ |
| **TCR De-Pegging**             | High   | Medium     | 100% collateralization, oracle monitoring, circuit breakers  |
| **TEQ Over-Inflation**         | High   | Medium     | LaborOracle rate caps, weekly hour limits, governance freeze |
| **EDG Liquidity Crisis**       | Medium | Low        | Multi-pool strategy, liquidity mining, treasury backstop     |
| **Fee Revenue Shortfall**      | Medium | Medium     | Tiered subscriptions, volume-based fees, premium services    |
| **Redemption Pool Exhaustion** | High   | Medium     | Annual window, pro-rata allocation, governance reserves      |

### Technical Risks

| Risk                    | Impact   | Likelihood | Mitigation                                                      |
| ----------------------- | -------- | ---------- | --------------------------------------------------------------- |
| **Smart Contract Bug**  | Critical | Low        | Multi-firm audits, bug bounty, gradual rollout, emergency pause |
| **Bridge Hack**         | Critical | Medium     | Multi-sig controls, rate limiting, insurance, cold storage      |
| **Oracle Manipulation** | High     | Low        | Chainlink + fallback oracles, anomaly detection                 |
| **Governance Attack**   | High     | Low        | Timelock delays, veto mechanism, quadratic voting (Phase 3)     |

### Regulatory Risks

| Risk                          | Impact   | Likelihood | Mitigation                                                  |
| ----------------------------- | -------- | ---------- | ----------------------------------------------------------- |
| **Securities Classification** | Critical | Medium     | Legal opinions, Reg D/A+ compliance, soulbound design (TEQ) |
| **MSB Registration**          | Medium   | Medium     | FinCEN registration, state licensing if needed              |
| **Tax Treatment Uncertainty** | Medium   | High       | 1099-DA reporting, DUNA pass-through, CPA partnership       |
| **Wyoming DUNA Invalidation** | High     | Low        | Delaware PBC + Foundation backup plan                       |

**Reference**: See MASTER_IMPLEMENTATION_SPEC.md for risk management strategies throughout.

---

## Token Launch Checklist

### Pre-Launch Requirements

**Legal Structure**:

- [ ] Engage DAO-specialized legal counsel
- [ ] File Wyoming DUNA formation documents
- [ ] Draft operating agreement with smart contract exhibits
- [ ] Obtain securities law opinion (EDG, TCR, TEQ)

**Smart Contract Development**:

- [ ] Implement EDG.sol (ERC-20Votes + vesting)
- [ ] Implement EDGVault.sol (ERC-4626 staking)
- [ ] Implement TCR.sol (ERC-20 + permit)
- [ ] Update FeeRouter.sol (EDG discount integration)
- [ ] Implement TEQ.sol (Soulbound + Votes)
- [ ] Implement LaborOracle.sol (rate management)
- [ ] Implement ServiceMarketplace.sol (Double-Dip)

**Security Audits**:

- [ ] Engage 2+ audit firms (Trail of Bits, OpenZeppelin, Certora)
- [ ] Address all critical and high-severity findings
- [ ] Launch bug bounty program (Immunefi)
- [ ] Conduct economic security review (tokenomics attack vectors)

**Infrastructure**:

- [ ] Deploy TCR bridge service (Stripe/Circle integration)
- [ ] Set up KYC provider (Persona, Jumio, Synaps)
- [ ] Configure oracle infrastructure (Chainlink Price Feeds)
- [ ] Implement 1099-DA tax reporting system

---

### Launch Phases

**Phase 1: EDG + TCR**

- [ ] Deploy EDG token to Base Mainnet
- [ ] Deploy EDGVault staking contract
- [ ] Deploy TCR token to Base Mainnet
- [ ] Update FeeRouter with EDG discount logic
- [ ] Establish DEX liquidity pools (Uniswap V3, Aerodrome)
- [ ] Begin liquidity mining rewards
- [ ] Launch TCR bridge (USDC on-ramp/off-ramp)
- [ ] Activate tiered fee discounts

**Phase 2: TEQ + ServiceMarketplace**

- [ ] Deploy LaborOracle with initial job types
- [ ] Deploy TEQ token to Base Mainnet
- [ ] Deploy ServiceMarketplace contract
- [ ] Launch beta marketplace (invite-only, 10-50 providers)
- [ ] Collect feedback, iterate on job types and rates
- [ ] Public marketplace launch

**Phase 3: Advanced Features**

- [ ] DAO-to-DAO service contracts
- [ ] Dispute resolution system
- [ ] Recurring service agreements
- [ ] Reputation system (EAS attestations)
- [ ] Annual TEQ redemption window

---

### Success Metrics

**Economic Metrics**:

| Metric                 | Phase 1 Target | Phase 2 Target | Measurement                       |
| ---------------------- | -------------- | -------------- | --------------------------------- |
| **TCR Supply**         | $1M - $5M      | $50M - $100M   | Total TCR minted via bridge       |
| **TEQ Holders**        | 100 - 500      | 5,000 - 10,000 | Unique addresses with TEQ balance |
| **Marketplace Volume** | $500K          | $25M           | Cumulative TCR transacted         |
| **EDG Staking Rate**   | 20% - 30%      | 40% - 50%      | % of total supply staked          |
| **Fee Revenue**        | $50K - $200K   | $2M - $5M      | Annual protocol fees collected    |

**Adoption Metrics**:

| Metric                       | Phase 1 Target | Phase 2 Target   | Measurement                          |
| ---------------------------- | -------------- | ---------------- | ------------------------------------ |
| **Active Providers**         | 50 - 200       | 2,000 - 5,000    | Monthly active marketplace providers |
| **Jobs Completed**           | 500 - 2,000    | 50,000 - 100,000 | Total marketplace jobs               |
| **DAOs Using TCR**           | 10 - 50        | 500 - 1,000      | DAOs with TCR in treasury            |
| **Governance Participation** | 5% - 10%       | 15% - 25%        | % of EDG voting on proposals         |

**Health Metrics** (Monitoring Thresholds):

| Metric                       | Target Range        | Red Flag Threshold         | Response                  |
| ---------------------------- | ------------------- | -------------------------- | ------------------------- |
| **TCR Peg Stability**        | $0.98 - $1.02       | Below $0.95 or above $1.05 | Activate circuit breaker  |
| **Bridge Collateralization** | 100% - 120%         | Below 95%                  | Pause withdrawals         |
| **TEQ Inflation Rate**       | 10% - 30% annually  | Above 50% annually         | Governance freeze vote    |
| **Redemption Demand**        | 20% - 40% of supply | Above 60%                  | Emergency pool allocation |
| **Average Job Size**         | $500 - $5,000       | Below $100 or above $50K   | Anti-gaming investigation |

---

## Related Documents

- **[PLATFORM_ROADMAP.md](./PLATFORM_ROADMAP.md)** - Platform features and primitives roadmap
- **[MASTER_IMPLEMENTATION_SPEC.md](./docs/MASTER_IMPLEMENTATION_SPEC.md)** - Detailed technical specifications
- **[ROADMAP.md](./ROADMAP.md)** - High-level product roadmap (index)
- **[CLAUDE.md](./CLAUDE.md)** - Engineering guide and codebase documentation

---

## Version History

| Version | Date       | Changes                                                                                                                                                        | Author           |
| ------- | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------- |
| 2.0     | 2025-12-06 | Complete rewrite based on MASTER_IMPLEMENTATION_SPEC.md, added 4-phase structure, anti-gaming framework, fee distribution architecture, legal-technical bridge | Engineering Team |
| 1.0     | 2025-12-06 | Initial roadmap                                                                                                                                                | Engineering Team |

---

## Important Legal Disclaimer

⚠️ **Critical Notice**: This document describes economic infrastructure architecture for **planning purposes only**.

All token designs, valuation methodologies, regulatory strategies, and legal entity structures **require validation by qualified professionals** before implementation:

- **Legal Counsel**: Securities law, DAO formation, regulatory compliance
- **Certified Public Accountants**: Tax treatment, 1099-DA reporting, entity taxation
- **Securities Law Specialists**: Howey test analysis, exemptions, registration requirements
- **Compliance Experts**: KYC/AML, FinCEN registration, MSB licensing

**Nothing in this document constitutes**:

- Legal advice, tax advice, or investment advice
- A solicitation to purchase securities
- A guarantee of regulatory approval or legal enforceability
- A commitment to implement any features described herein

**Regulatory Context**:

- Token launches are subject to federal securities laws, state money transmission regulations, tax reporting requirements, and international regulations that vary by jurisdiction.
- The Wyoming DUNA statute is novel and lacks extensive legal precedent.
- SEC guidance on DAOs and token classifications continues to evolve.
- Stablecoin regulations are under active development in the U.S. and internationally.

**Consult appropriate professionals before proceeding with any token-related development, deployment, or legal entity formation.**

The EnDAO project makes no representations regarding the regulatory status, legal enforceability, or tax treatment of any tokens, smart contracts, or legal structures described in this document.
