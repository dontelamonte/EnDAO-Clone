# EnDAO MVP Architecture Guidelines

> **Version**: 2.3.0
> **Last Updated**: December 2025
> **Status**: Production - Post-Refactoring
> **Owner/Maintainer**: Development Team

## Purpose

This document establishes the architectural principles and patterns that must be followed for all new development and refactoring in the EnDAO platform, ensuring consistency, maintainability, and scalability.

## Last Updated

December 2025

## Table of Contents

- [Overview](#overview)
- [Service Layer Architecture](#service-layer-architecture)
- [Component Architecture Patterns](#component-architecture-patterns)
- [Error Handling Standards](#error-handling-standards)
- [Data Model Standards](#data-model-standards)
- [Code Quality Standards](#code-quality-standards)
- [Migration Guidelines](#migration-guidelines)

## Overview

EnDAO follows a **modular, domain-driven architecture** with strict separation of concerns. This document establishes the architectural principles and patterns that must be followed for all new development and refactoring.

### Core Architectural Principles

1. **Separation of Concerns**: Each module has a single, well-defined responsibility
2. **Composition Over Inheritance**: Prefer composition patterns over deep inheritance
3. **Dependency Inversion**: Depend on abstractions, not concretions
4. **Single Source of Truth**: Each piece of data has one authoritative source
5. **Error Boundary Isolation**: Failures in one module don't cascade to others

## Service Layer Architecture

### Base Service Pattern

All business logic services **MUST** extend the `BaseService` class and follow the standardized patterns.

#### Service Structure

```typescript
// ✅ CORRECT: Consistent service structure
export class DAOCrudService extends BaseService {
  private static instance: DAOCrudService;

  private constructor() {
    super('DAOCrudService');
  }

  static getInstance(): DAOCrudService {
    if (!DAOCrudService.instance) {
      DAOCrudService.instance = new DAOCrudService();
    }
    return DAOCrudService.instance;
  }

  async createDAO(data: CreateDAOFormData): Promise<ServiceResponse<DAO>> {
    return this.safeExecute(async () => {
      // Business logic here
      return createdDAO;
    }, 'createDAO');
  }
}
```

#### Service Response Pattern

All service methods **MUST** return `ServiceResponse<T>` with standardized error handling:

```typescript
interface ServiceResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  code?: string
  timestamp?: Date
}

// ✅ CORRECT: Using safeExecute wrapper
async createItem(data: ItemData): Promise<ServiceResponse<Item>> {
  return this.safeExecute(async () => {
    // Validation
    const validation = this.validateData(data, [
      ValidationRules.required('name'),
      ValidationRules.email('email')
    ])

    if (!validation.isValid) {
      throw new Error(validation.errors.join(', '))
    }

    // Business logic
    const item = await this.performCreation(data)
    return item
  }, 'createItem')
}

// ❌ INCORRECT: Direct error handling
async createItem(data: ItemData): Promise<Item | null> {
  try {
    return await this.performCreation(data)
  } catch (error) {
    console.error(error) // Inconsistent error handling
    return null
  }
}
```

#### Validation Framework

Use the built-in validation framework for consistent data validation:

```typescript
// ✅ CORRECT: Using validation framework
const validation = this.validateData(formData, [
  ValidationRules.required('name'),
  ValidationRules.email('email'),
  ValidationRules.minLength('description', 10),
  ValidationRules.maxLength('name', 100),
]);

if (!validation.isValid) {
  return {
    success: false,
    error: validation.errors.join(', '),
    code: 'VALIDATION_ERROR',
  };
}
```

## Component Architecture Patterns

### Compound Component Pattern

For components exceeding 300 lines, **MUST** be refactored using the compound component pattern.

#### Before: Monolithic Component (❌)

```typescript
// ❌ AVOID: Large monolithic component
export function DAOSettings({ dao }: { dao: DAO }) {
  const [generalData, setGeneralData] = useState(...)
  const [governanceData, setGovernanceData] = useState(...)
  const [membershipData, setMembershipData] = useState(...)

  // 400+ lines of mixed concerns
  return (
    <div>
      {/* General settings UI - 150 lines */}
      {/* Governance settings UI - 150 lines */}
      {/* Membership settings UI - 150 lines */}
    </div>
  )
}
```

#### After: Compound Component Pattern (✅)

```typescript
// ✅ CORRECT: Compound component with shared context
export function DAOSettings({ dao }: { dao: DAO }) {
  return (
    <DAOSettingsProvider dao={dao}>
      <DAOSettingsHeader />
      <DAOGeneralSettings />
      <DAOGovernanceSettings />
      <DAOMembershipSettings />
    </DAOSettingsProvider>
  )
}

// Context provider for shared state
const DAOSettingsProvider = ({ children, dao }: { children: ReactNode, dao: DAO }) => {
  const [settings, setSettings] = useState(dao.settings)
  const [isLoading, setIsLoading] = useState(false)

  return (
    <DAOSettingsContext.Provider value={{ settings, setSettings, isLoading, setIsLoading }}>
      {children}
    </DAOSettingsContext.Provider>
  )
}

// Individual focused components
const DAOGeneralSettings = () => {
  const { settings, updateSettings } = useDAOSettings()

  // 100-150 lines focused on general settings only
  return <form>...</form>
}
```

### Hook Composition Pattern

For hooks exceeding 200 lines, **MUST** be decomposed into specialized hooks.

#### Before: Monolithic Hook (❌)

```typescript
// ❌ AVOID: 776-line hook handling multiple concerns
export function useTreasuryAdmin(daoId: string) {
  // Data loading logic - 200 lines
  // Action handlers - 300 lines
  // Status calculation - 276 lines

  return {
    /* everything mixed together */
  };
}
```

#### After: Composed Hooks (✅)

```typescript
// ✅ CORRECT: Specialized hooks with clear responsibilities
export function useTreasuryAdmin(daoId: string) {
  // Data management
  const dataHook = useTreasuryAdminData({ daoId });

  // Execution status
  const statusHook = useProposalExecutionStatus({
    daoId,
    currentAdmin: dataHook.currentAdmin,
  });

  // Actions
  const actionsHook = useTreasuryActions({
    daoId,
    currentAdmin: dataHook.currentAdmin,
    onDataUpdate: dataHook.refreshData,
  });

  return {
    ...dataHook,
    ...statusHook,
    ...actionsHook,
  };
}
```

### Service Orchestration Pattern

For complex business logic, separate into orchestrators and specific services:

```typescript
// ✅ CORRECT: Service orchestration
export class DAOService extends BaseService {
  private crudService = DAOCrudService.getInstance();
  private memberService = DAOMemberService.getInstance();
  private auditService = AuditLogService.getInstance();

  async createDAO(
    data: CreateDAOFormData,
    userId: string
  ): Promise<ServiceResponse<DAO>> {
    return this.safeExecute(async () => {
      // Orchestrate multiple services
      const daoResult = await this.crudService.create(data);
      if (!daoResult.success) throw new Error(daoResult.error);

      await this.memberService.addFounder(daoResult.data!.id, userId);
      await this.auditService.logDAOCreation(daoResult.data!.id, userId);

      return daoResult.data!;
    }, 'createDAO');
  }
}
```

### Sub-Service Specialization Pattern

For services exceeding 300 lines, split into specialized sub-services by concern:

```typescript
// ✅ CORRECT: Main orchestrator delegates to sub-services
// src/lib/services/proposal/index.ts
export class ProposalServiceOrchestrator extends BaseService {
  private operationsService = ProposalOperationsService.getInstance();
  private votingEngine = VotingEngineService.getInstance();
  private executionEngine = ExecutionEngineService.getInstance();

  // CRUD operations delegate to operations service
  async createProposal(
    daoId: string,
    data: CreateProposalFormData
  ): Promise<ServiceResponse<Proposal>> {
    return this.operationsService.createProposal(daoId, data);
  }

  // Voting operations delegate to voting engine
  async castVote(
    proposalId: string,
    voteData: VoteData
  ): Promise<ServiceResponse<Vote>> {
    return this.votingEngine.castOrChangeVote(proposalId, voteData);
  }
}

// ✅ CORRECT: Specialized sub-service with single responsibility
// src/lib/services/proposal/voting/voting-engine.service.ts
export class VotingEngineService extends BaseService {
  async castOrChangeVote(
    proposalId: string,
    voteData: VoteData
  ): Promise<ServiceResponse<Vote>> {
    return this.safeExecute(async () => {
      // Focused voting logic only
    }, 'castOrChangeVote');
  }
}
```

**Sub-Service Directory Structure:**

```
src/lib/services/proposal/
├── index.ts                    # Orchestrator - exports main service
├── crud/                       # CRUD operations
│   ├── proposal-operations.service.ts
│   └── proposal-validation.service.ts
├── voting/                     # Voting operations
│   ├── voting-engine.service.ts
│   └── vote-counting.service.ts
├── execution/                  # Execution operations
│   ├── execution-engine.service.ts
│   └── execution-validation.service.ts
├── query/                      # Query operations
│   └── proposal-query-operations.service.ts
├── subscription/               # Real-time subscriptions
│   └── proposal-subscription.service.ts
└── shared/                     # Shared types and utilities
    ├── proposal-types.ts
    └── proposal-audit.service.ts
```

### Adapter Pattern

For external dependencies, isolate version-specific implementations behind stable interfaces:

```typescript
// ✅ CORRECT: Adapter interface (packages/shared-types/src/adapters/)
export interface SigningAdapter {
  signMessage(message: string): Promise<string>;
  signTypedData(
    domain: TypedDataDomain,
    types: Record<string, TypedDataField[]>,
    value: Record<string, unknown>
  ): Promise<string>;
}

// ✅ CORRECT: Platform-specific implementation (src/lib/adapters/privy/)
export class PrivySigningAdapter implements SigningAdapter {
  constructor(private wallets: ConnectedWallet[]) {}

  async signMessage(message: string): Promise<string> {
    const wallet = this.wallets[0];
    const provider = await wallet.getEthersProvider();
    const signer = await provider.getSigner();
    return signer.signMessage(message);
  }
}
```

**Adapter Categories:**

- **Ethers Adapter**: ethers.js v6 provider/signer abstraction
- **Safe Adapter**: Safe Protocol Kit v4 multi-sig operations
- **Privy Adapter**: Authentication, signing, wallet management

## Error Handling Standards

### Error Boundary Usage

All major feature areas **MUST** be wrapped with error boundaries:

```typescript
// ✅ CORRECT: Error boundary usage
import { ErrorBoundary, ServiceErrorDisplay } from '@/components/ui/error-boundary'

export function DAODashboard({ daoId }: { daoId: string }) {
  return (
    <ErrorBoundary
      fallback={({ error, resetErrorBoundary }) => (
        <ServiceErrorDisplay
          error={error.message}
          title="DAO Dashboard Error"
          onRetry={resetErrorBoundary}
        />
      )}
    >
      <DAOContent daoId={daoId} />
    </ErrorBoundary>
  )
}
```

### Service Error Display

Use the standardized `ServiceErrorDisplay` component for consistent error presentation:

```typescript
// ✅ CORRECT: Service error handling
const { data, error, isLoading } = useQuery({
  queryFn: () => daoService.getDAO(daoId),
  queryKey: ['dao', daoId]
})

if (error) {
  return (
    <ServiceErrorDisplay
      error={error}
      title="Failed to Load DAO"
      onRetry={() => refetch()}
    />
  )
}
```

### Error Code Standards

All service errors **MUST** include standardized error codes:

```typescript
// Error code format: SERVICE_ERROR_TYPE
const ERROR_CODES = {
  // Database errors (Supabase/PostgreSQL)
  DB_PERMISSION_DENIED: 'DB_PERMISSION_DENIED',
  DB_NOT_FOUND: 'DB_NOT_FOUND',
  DB_CONNECTION_ERROR: 'DB_CONNECTION_ERROR',
  RLS_VIOLATION: 'RLS_VIOLATION',

  // Business logic errors
  DAO_NOT_FOUND: 'DAO_NOT_FOUND',
  MEMBER_LIMIT_REACHED: 'MEMBER_LIMIT_REACHED',
  INSUFFICIENT_PERMISSIONS: 'INSUFFICIENT_PERMISSIONS',

  // Validation errors
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  INVALID_INPUT: 'INVALID_INPUT',
} as const;
```

## Data Model Standards

### Visibility Model Migration

The legacy `visibility` field has been **DEPRECATED**. All new code **MUST** use the new visibility model:

```typescript
// ❌ DEPRECATED: Legacy visibility
interface LegacyDAO {
  visibility: 'public' | 'private';
}

// ✅ CURRENT: New visibility model
interface DAO {
  isDiscoverable: boolean; // Show on discover page
  joinPermission: 'open' | 'request' | 'invite-only'; // Who can join
}

// Migration mapping
const migrationMap = {
  public: { isDiscoverable: true, joinPermission: 'open' },
  private: { isDiscoverable: false, joinPermission: 'invite-only' },
};
```

### Query Patterns

Use the new visibility model in all queries (Supabase/PostgreSQL):

```typescript
// ✅ CORRECT: New model queries via repository pattern
const discoverableDAOs = await supabase
  .from('daos')
  .select('*')
  .eq('is_discoverable', true)
  .eq('status', 'active');

const openDAOs = await supabase
  .from('daos')
  .select('*')
  .eq('join_permission', 'open')
  .eq('is_discoverable', true);

// ✅ CORRECT: Using repository pattern (preferred)
const result = await daoRepository.findDiscoverable({ status: 'active' });

// ❌ INCORRECT: Legacy visibility queries
const publicDAOs = await supabase
  .from('daos')
  .select('*')
  .eq('visibility', 'public'); // DEPRECATED field
```

## Code Quality Standards

### File Size Limits

**Strict enforcement** of file size limits with architectural solutions (enforced by CI):

| Threshold  | Action  | Enforcement         |
| ---------- | ------- | ------------------- |
| ≤300 lines | Target  | Ideal file size     |
| >300 lines | Info    | Consider splitting  |
| >500 lines | Warning | Refactor soon       |
| >800 lines | Error   | **Blocks PR merge** |

**Architectural Solutions by File Type:**

| File Type  | Solution Pattern                                 |
| ---------- | ------------------------------------------------ |
| Components | Compound components, extract to child components |
| Hooks      | Hook composition, split by concern               |
| Services   | Orchestrator/facade pattern, sub-services        |
| Utilities  | Module separation, focused exports               |

Check locally with: `npm run check:files`

### Code Complexity Limits

- **Cyclomatic Complexity**: <10 per function
- **Cognitive Complexity**: <15 per function
- **Nesting Depth**: <4 levels
- **Function Length**: <50 lines

### Performance Standards

| Metric      | Target | Error Threshold |
| ----------- | ------ | --------------- |
| Bundle Size | <500KB | >1MB            |
| LCP         | <2.5s  | >4s             |
| FID         | <100ms | >300ms          |
| CLS         | <0.1   | >0.25           |

## Migration Guidelines

### Existing Code Refactoring

When refactoring existing oversized files:

1. **Identify Concerns**: List all responsibilities of the current component/hook
2. **Extract Interfaces**: Define clear interfaces between concerns
3. **Create Specialized Modules**: Extract each concern into focused modules
4. **Compose Main Module**: Create a composition that orchestrates the specialized modules
5. **Test Integration**: Ensure the refactored version maintains all functionality
6. **Update Imports**: Update all dependent code to use new interfaces

### Legacy Support

During migration periods:

```typescript
// ✅ CORRECT: Backwards compatibility during migration
interface DAOSearchFilters {
  // New model (preferred)
  isDiscoverable?: boolean;
  joinPermission?: DAOJoinPermission;

  // Legacy support (temporary)
  /** @deprecated Use isDiscoverable and joinPermission instead */
  visibility?: DAOVisibility;
}

// Handle both old and new formats
function normalizeFilters(filters: DAOSearchFilters): NormalizedFilters {
  if (filters.visibility) {
    // Map legacy to new model
    const mapped = mapLegacyVisibility(filters.visibility);
    return { ...filters, ...mapped };
  }

  return filters;
}
```

### Testing Requirements

All architectural changes **MUST** include:

1. **Unit Tests**: Test individual modules in isolation
2. **Integration Tests**: Test composed modules work together
3. **Regression Tests**: Ensure existing functionality is preserved
4. **Performance Tests**: Validate performance characteristics

## Anti-Patterns to Avoid

### ❌ Component Anti-Patterns

```typescript
// ❌ AVOID: Mixed concerns in one component
function DAODashboard() {
  // Data fetching
  const [dao, setDAO] = useState()
  const [members, setMembers] = useState()
  const [proposals, setProposals] = useState()

  // Business logic
  const handleCreateProposal = () => { /* 50 lines */ }
  const handleInviteMember = () => { /* 40 lines */ }
  const handleUpdateDAO = () => { /* 60 lines */ }

  // Rendering multiple concerns
  return (
    <div>
      {/* DAO info - 100 lines */}
      {/* Member management - 150 lines */}
      {/* Proposal management - 200 lines */}
    </div>
  )
}

// ❌ AVOID: Prop drilling
function Parent() {
  return <Child dao={dao} member={member} settings={settings} />
}
function Child({ dao, member, settings }) {
  return <GrandChild dao={dao} member={member} settings={settings} />
}
```

### ❌ Service Anti-Patterns

```typescript
// ❌ AVOID: Direct Supabase calls in components
function DAOComponent() {
  useEffect(() => {
    const fetchDAO = async () => {
      const { data } = await supabase
        .from('daos')
        .select('*')
        .eq('id', daoId)
        .single();
      setDAO(data); // Direct database call bypasses service layer
    };
    fetchDAO();
  }, []);
}

// ✅ CORRECT: Use hooks that call service layer
function DAOComponent() {
  const { data: dao, isLoading, error } = useDAO(daoId);
  // ...
}

// ❌ AVOID: Inconsistent error handling
async function updateDAO(data: any) {
  try {
    await supabase.from('daos').update(data).eq('id', daoId);
    return { success: true };
  } catch (error) {
    console.log(error); // Inconsistent with other services
    return null; // Different return format
  }
}

// ❌ AVOID: God services (too many responsibilities)
class DAOService {
  // DAO CRUD - 200 lines
  createDAO() {}
  updateDAO() {}

  // Member management - 300 lines
  addMember() {}
  removeMember() {}

  // Proposal management - 400 lines
  createProposal() {}
  voteOnProposal() {}

  // Treasury management - 500 lines
  initiatePayout() {}
  signTransaction() {}
}
```

## Enforcement

### Pre-commit Hooks

The following checks are enforced automatically:

- File size limits (blocks commits >800 lines)
- ESLint rules (complexity, style)
- TypeScript compilation
- Architecture compliance checks

### Code Review Requirements

All PRs **MUST**:

1. Follow architectural patterns documented here
2. Include architectural decision records (ADRs) for significant changes
3. Pass all quality gates
4. Demonstrate the single responsibility principle
5. Include appropriate error boundaries and service error handling

### Quality Metrics

Monitor and maintain:

- Average file size <250 lines
- Code coverage >80% for critical paths
- Performance budgets within limits
- Zero architectural violations in new code

---

## Conclusion

This architecture ensures EnDAO remains maintainable and scalable as it grows. **All new development MUST follow these patterns**. When refactoring existing code, prioritize the most complex and frequently-changed areas first.

For questions about architectural decisions, refer to the Architecture Decision Records (ADRs) in `/docs/architecture/decisions/` or consult with the technical team.
