/**
 * Common types used across the application
 */

/**
 * ISO 8601 date string type alias for documentation purposes
 * All date fields in the application use ISO 8601 format: "2025-12-17T21:45:00.000Z"
 */
export type ISODateString = string;

// Common database field types
export interface BaseDocument {
  id: string;
  createdAt: string; // ISO 8601
  updatedAt?: string; // ISO 8601
}

// Common pagination types
export interface PaginationOptions {
  limit?: number;
  offset?: number;
  cursor?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    total: number;
    hasMore: boolean;
    nextCursor?: string;
  };
}

// Common API response types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

// Common status types
export type Status = 'active' | 'inactive' | 'pending' | 'deleted' | 'archived';

// Common priority levels
export type Priority = 'low' | 'medium' | 'high' | 'critical';

// Common visibility levels
export type Visibility = 'public' | 'private' | 'members' | 'admins';

// Common sort options
export interface SortOptions {
  field: string;
  direction: 'asc' | 'desc';
}

// Common filter options
export interface FilterOptions {
  status?: Status[];
  priority?: Priority[];
  visibility?: Visibility[];
  dateRange?: {
    start: Date;
    end: Date;
  };
  search?: string;
}

// Common validation result
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings?: string[];
}

// Common operation result
export interface OperationResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  warnings?: string[];
}

// File upload types
export interface FileUpload {
  file: File;
  url?: string;
  progress?: number;
  error?: string;
}

export interface UploadOptions {
  maxSize?: number;
  allowedTypes?: string[];
  quality?: number;
}

// Network and loading states
export type LoadingState = 'idle' | 'loading' | 'success' | 'error';

export interface AsyncState<T = unknown> {
  data?: T;
  loading: boolean;
  error?: string;
}

// Common form field types
export interface FormField<T = unknown> {
  value: T;
  error?: string;
  touched: boolean;
  dirty: boolean;
}

export interface FormState<T = Record<string, unknown>> {
  values: T;
  errors: Partial<Record<keyof T, string>>;
  touched: Partial<Record<keyof T, boolean>>;
  dirty: boolean;
  submitting: boolean;
  valid: boolean;
}

// Common event types
export interface EventMetadata {
  timestamp: string; // ISO 8601
  userId?: string;
  sessionId?: string;
  userAgent?: string;
  ip?: string;
}

// Common configuration types
export interface FeatureFlag {
  enabled: boolean;
  rolloutPercentage?: number;
  conditions?: Record<string, unknown>;
}

export interface AppConfig {
  features: Record<string, FeatureFlag>;
  limits: Record<string, number>;
  settings: Record<string, unknown>;
}

// Utility types
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

// Environment and system types
export type Environment = 'development' | 'staging' | 'production';

export interface SystemInfo {
  environment: Environment;
  version: string;
  buildTime: string;
  features: string[];
}

// Error handling types
export interface ErrorContext {
  component?: string;
  action?: string;
  userId?: string;
  sessionId?: string;
  metadata?: Record<string, unknown>;
}

export interface ApplicationError extends Error {
  code: string;
  context?: ErrorContext;
  retryable?: boolean;
}

// Audit and compliance types
export interface AuditTrail {
  id: string;
  action: string;
  resourceType: string;
  resourceId: string;
  userId: string;
  timestamp: string; // ISO 8601
  changes?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

// Security types
export interface SecurityContext {
  userId: string;
  roles: string[];
  permissions: string[];
  sessionId: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface AccessControl {
  read: boolean;
  write: boolean;
  delete: boolean;
  admin: boolean;
}

// Performance monitoring types
// Note: Renamed to avoid conflict with performance.ts PerformanceMetric
export interface SimpleMetric {
  name: string;
  value: number;
  unit: string;
  timestamp: string; // ISO 8601
  tags?: Record<string, string>;
}

export interface HealthCheck {
  service: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  latency?: number;
  error?: string;
  timestamp: string; // ISO 8601
}
