/**
 * Invoice Types
 *
 * Types for invoice management between users and DAOs.
 */

// ============================================================================
// Enums and Constants
// ============================================================================

export type InvoiceStatus =
  | 'draft'
  | 'sent'
  | 'viewed'
  | 'paid'
  | 'overdue'
  | 'cancelled'
  | 'disputed';

export type InvoiceIssuerType = 'user' | 'dao';
export type InvoiceRecipientType = 'user' | 'dao' | 'external';

export type PaymentTerms =
  | 'due_on_receipt'
  | 'net_15'
  | 'net_30'
  | 'net_45'
  | 'net_60';

// ============================================================================
// Line Items
// ============================================================================

export interface InvoiceLineItem {
  id: string;
  description: string;
  quantity: number;
  unit: 'hours' | 'days' | 'units' | 'flat';
  rate: number;
  amount: number;
}

// ============================================================================
// Invoice Types
// ============================================================================

export interface Invoice {
  id: string;
  invoiceNumber: string;

  // Issuer (who created the invoice)
  issuerType: InvoiceIssuerType;
  issuerUserId?: string;
  issuerDaoId?: string;

  // Recipient (who owes the payment)
  recipientType: InvoiceRecipientType;
  recipientUserId?: string;
  recipientDaoId?: string;
  recipientEmail?: string;
  recipientName?: string;

  // Invoice details
  title: string;
  description?: string;
  lineItems: InvoiceLineItem[];
  subtotal: number;
  taxAmount: number;
  totalAmount: number;
  currency: string;

  // Dates
  issueDate: string;
  dueDate: string;

  // Status
  status: InvoiceStatus;

  // Payment info
  paymentMethod?: string;
  paymentReference?: string;
  paidAt?: string;
  paidAmount?: number;

  // Additional info
  notes?: string;
  terms?: string;
  attachments?: InvoiceAttachment[];

  // Timestamps
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceAttachment {
  id: string;
  name: string;
  url: string;
  size: number;
  type: string;
}

// ============================================================================
// Input Types
// ============================================================================

export interface CreateInvoiceInput {
  // Recipient
  recipientType: InvoiceRecipientType;
  recipientUserId?: string;
  recipientDaoId?: string;
  recipientEmail?: string;
  recipientName?: string;

  // Details
  title: string;
  description?: string;
  lineItems: Omit<InvoiceLineItem, 'id'>[];
  taxAmount?: number;
  currency: string;

  // Dates
  dueDate: string;

  // Additional
  notes?: string;
  terms?: string;
  paymentTerms?: PaymentTerms;
}

export interface UpdateInvoiceInput {
  title?: string;
  description?: string;
  lineItems?: Omit<InvoiceLineItem, 'id'>[];
  taxAmount?: number;
  dueDate?: string;
  notes?: string;
  terms?: string;
}

// ============================================================================
// Filter Types
// ============================================================================

export interface InvoiceFilters {
  status?: InvoiceStatus;
  issuerType?: InvoiceIssuerType;
  recipientType?: InvoiceRecipientType;
  dateFrom?: string;
  dateTo?: string;
  minAmount?: number;
  maxAmount?: number;
}

// ============================================================================
// Summary Types
// ============================================================================

export interface InvoiceSummary {
  totalInvoices: number;
  totalAmount: number;
  paidAmount: number;
  pendingAmount: number;
  overdueAmount: number;
  byStatus: Record<InvoiceStatus, number>;
}
