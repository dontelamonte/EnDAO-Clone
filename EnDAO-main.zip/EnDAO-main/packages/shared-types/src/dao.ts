// Import treasury types
import type { DAOTaxEntityType, TreasuryRailStatus } from './treasury';

// Re-export for consumers
export type { DAOTaxEntityType, TreasuryRailStatus };

/**
 * DAO Categories for classification and filtering
 * Simplified to two main categories with tags for specificity
 */
export type DAOCategory = 'Community' | 'Commerce';

/**
 * Organization Type for template-based onboarding
 * Used to pre-populate settings during DAO creation
 * Fully editable after creation in DAO settings
 */
export type OrganizationType =
  | 'nonprofit'
  | 'cooperative'
  | 'business'
  | 'community_org'
  | 'social_org'
  | 'general';

/**
 * DAO Member Roles with increasing permissions
 */
export type MemberRole = 'member' | 'admin';

/**
 * Treasury Type for DAO fund management
 * - fiat: Uses Stripe Connect for direct bank deposits
 * - crypto: Uses Gnosis Safe for on-chain treasury
 * - stablecoin: Fiat donations converted to USDC on-chain
 */
export type TreasuryType = 'fiat' | 'crypto' | 'stablecoin';

/**
 * Stripe Connect onboarding status
 */
export type StripeConnectStatus =
  | 'not_started'
  | 'pending'
  | 'active'
  | 'restricted';

/**
 * Countries supported by Stripe Connect Express accounts
 * https://docs.stripe.com/connect/express-accounts#supported-countries
 */
export const STRIPE_CONNECT_COUNTRIES = [
  'AU', // Australia
  'AT', // Austria
  'BE', // Belgium
  'BR', // Brazil
  'BG', // Bulgaria
  'CA', // Canada
  'HR', // Croatia
  'CY', // Cyprus
  'CZ', // Czech Republic
  'DK', // Denmark
  'EE', // Estonia
  'FI', // Finland
  'FR', // France
  'DE', // Germany
  'GR', // Greece
  'HK', // Hong Kong
  'HU', // Hungary
  'IE', // Ireland
  'IT', // Italy
  'JP', // Japan
  'LV', // Latvia
  'LT', // Lithuania
  'LU', // Luxembourg
  'MT', // Malta
  'MX', // Mexico
  'NL', // Netherlands
  'NZ', // New Zealand
  'NO', // Norway
  'PL', // Poland
  'PT', // Portugal
  'RO', // Romania
  'SG', // Singapore
  'SK', // Slovakia
  'SI', // Slovenia
  'ES', // Spain
  'SE', // Sweden
  'CH', // Switzerland
  'TH', // Thailand
  'GB', // United Kingdom
  'US', // United States
] as const;

export type StripeConnectCountry = (typeof STRIPE_CONNECT_COUNTRIES)[number];

/**
 * Human-readable country names for Stripe Connect
 */
export const STRIPE_CONNECT_COUNTRY_NAMES: Record<
  StripeConnectCountry,
  string
> = {
  AU: 'Australia',
  AT: 'Austria',
  BE: 'Belgium',
  BR: 'Brazil',
  BG: 'Bulgaria',
  CA: 'Canada',
  HR: 'Croatia',
  CY: 'Cyprus',
  CZ: 'Czech Republic',
  DK: 'Denmark',
  EE: 'Estonia',
  FI: 'Finland',
  FR: 'France',
  DE: 'Germany',
  GR: 'Greece',
  HK: 'Hong Kong',
  HU: 'Hungary',
  IE: 'Ireland',
  IT: 'Italy',
  JP: 'Japan',
  LV: 'Latvia',
  LT: 'Lithuania',
  LU: 'Luxembourg',
  MT: 'Malta',
  MX: 'Mexico',
  NL: 'Netherlands',
  NZ: 'New Zealand',
  NO: 'Norway',
  PL: 'Poland',
  PT: 'Portugal',
  RO: 'Romania',
  SG: 'Singapore',
  SK: 'Slovakia',
  SI: 'Slovenia',
  ES: 'Spain',
  SE: 'Sweden',
  CH: 'Switzerland',
  TH: 'Thailand',
  GB: 'United Kingdom',
  US: 'United States',
};

/**
 * DAO Status indicating the operational state
 * - active: DAO is fully operational
 * - inactive: DAO is paused but can be reactivated
 * - frozen: DAO is emergency paused - all operations suspended
 * - archived: DAO is archived but preserved
 * - pending_deletion: DAO is in 7-day grace period before deletion
 * - deleted: DAO has been permanently deleted
 */
export type DAOStatus =
  | 'active'
  | 'inactive'
  | 'frozen'
  | 'archived'
  | 'pending_deletion'
  | 'deleted';

/**
 * DAO Join Permission settings - controls who can join the DAO
 */
export type DAOJoinPermission = 'open' | 'request' | 'invite-only';

/**
 * DAO Visibility settings (DEPRECATED - use isDiscoverable and joinPermission instead)
 */
export type DAOVisibility = 'public' | 'private';

/**
 * Social media links for the DAO
 */
export interface DAOSocialLinks {
  website?: string;
  discord?: string;
  twitter?: string;
  telegram?: string;
  github?: string;
  linkedin?: string;
  tiktok?: string;
  instagram?: string;
  facebook?: string;
  meetingLink?: string; // Recurring Zoom, Meet, or Teams link
}

/**
 * DAO Funds information (simplified for non-crypto users)
 */
export interface DAOFunds {
  balance?: number;
  currency?: string;
  lastUpdated?: string; // ISO 8601
}

/**
 * DAO Statistics for display and analytics
 */
export interface DAOStats {
  memberCount: number;
  activeProposals: number;
  totalProposals: number;
  totalVotes: number;
  fundsBalance?: number;
  lastActivityAt?: string; // ISO 8601
}

/**
 * DAO Settings for configuration
 */
export interface DAOSettings {
  isPublic: boolean;
  requireApprovalToJoin: boolean;
  requireProposalForAdminPromotion: boolean;
  allowPublicProposals: boolean;
  allowMemberInvites: boolean;
  enableProposalDrafts: boolean;
  // Removed: minimumTokensToJoin - not needed for non-crypto DAOs
  votingPeriodDays: number;
  minimumVotingPeriod: number; // in hours
  maximumVotingPeriod: number; // in hours
  quorumPercentage: number; // 0-100
  passThreshold: number; // 0-100
  allowAnonymousVoting: boolean;
  // Simplified: removed vote weighting, treasury, and token options for non-crypto users

  // Voting Period Configuration
  enableContinuousVoting?: boolean; // Allow proposals without time limits (default: false)

  // Voting Cycle Configuration (NEW)
  votingCycleType: 'continuous' | 'quarterly' | 'monthly' | 'custom';
  votingCycleFrequency?: number; // Days between cycles (for custom)
  nextVotingCycleDate?: Date; // Next scheduled voting date
  allowEmergencyProposals: boolean; // Allow urgent proposals outside cycles

  // Membership duration requirements (in days)
  minDaysToCreateProposal: number; // Default: 0 for testing, typically 7
  minDaysToVote: number; // Default: 0, can vote immediately
  minDaysToDelegate: number; // Default: 30, for future delegation feature

  // Proposal Approval Workflow (NEW - Wave 3)
  proposalApproval?: {
    mode: 'auto' | 'timed_review' | 'manual_approval';
    reviewDurationHours: 24 | 48 | 72; // Only used when mode = 'timed_review'
  };
}

/**
 * Main DAO interface representing a decentralized autonomous organization
 */
export interface DAO {
  id: string;
  name: string;
  description: string;
  slug: string;
  category: DAOCategory;
  organizationType?: OrganizationType; // Template-based classification (default: 'general')
  status: DAOStatus;

  // New improved visibility model
  isDiscoverable: boolean; // Show on discover page (default: true)
  joinPermission: DAOJoinPermission; // Who can join the DAO

  // Deprecated - for backward compatibility
  visibility?: DAOVisibility;

  // Visual identity
  logoUrl?: string;
  bannerUrl?: string;
  colors?: {
    primary?: string;
    secondary?: string;
    accent?: string;
  };

  // Social and external links
  socialLinks: DAOSocialLinks;

  // Fund management information (simplified)
  funds?: DAOFunds;

  // Statistics and metrics
  stats: DAOStats;

  // Configuration and settings
  settings: DAOSettings;

  // Ownership and management
  createdBy: string; // User ID of creator
  admins: string[]; // User IDs of admins

  // Timestamps
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  lastActivityAt?: string; // ISO 8601

  // Search and discovery
  tags: string[];
  keywords: string[];

  // Membership
  memberIds: string[]; // Array of member user IDs for quick lookup
  maxMembers?: number;

  // Featured status
  isFeatured: boolean;
  isVerified: boolean;

  // Archive status for hiding DAOs without deleting
  isArchived?: boolean;
  archivedAt?: string;
  archivedReason?: string;

  // Treasury Type and Stripe Connect fields
  treasuryType: TreasuryType; // How the DAO handles funds
  country?: StripeConnectCountry; // DAO's country for Stripe Connect
  stripeConnectAccountId?: string; // For fiat treasury DAOs
  stripeConnectStatus?: StripeConnectStatus; // Onboarding status

  // Hybrid Treasury fields (both fiat + crypto)
  hybridTreasuryEnabled?: boolean; // When true, accepts both fiat and crypto
  fiatRailStatus?: TreasuryRailStatus; // Status of fiat rail (Stripe Connect)
  cryptoRailStatus?: TreasuryRailStatus; // Status of crypto rail (Gnosis Safe)

  // Tax Entity settings
  taxEntityType?: DAOTaxEntityType; // 'platform' (default) or 'independent'
  taxProfileId?: string; // Reference to DAO tax profile (for independent DAOs)

  // Gnosis Safe Treasury fields (for blockchain treasury)
  safeAddress?: string;
  safeOwners?: string[];
  safeThreshold?: number;
  treasuryEnabled?: boolean;
  treasuryCreatedAt?: Date;

  // Active Wallet fields (Privy delegated actions)
  activeWalletAddress?: string;
  activeWalletCreatedAt?: string; // ISO 8601
  walletCreationStatus?: 'pending' | 'created' | 'failed' | 'none';
  walletGovernanceConfig?: Record<string, unknown>; // Reserved for future treasury settings

  // Convenience properties (computed from stats)
  memberCount: number;
  activeProposals: number;
  totalProposals: number;
  treasuryValue: number;
  website?: string;
  twitter?: string;
  discord?: string;

  // Deletion tracking fields
  pendingDeletionSince?: string; // ISO 8601
  recoveredAt?: string; // ISO 8601
  recoveredBy?: string;

  // Emergency freeze fields
  frozenAt?: string;
  frozenBy?: string;
  frozenReason?: string;
  resumedAt?: string;
  resumedBy?: string;

  // Governance Settings (Admin Permission Safeguards)
  governanceSettings?: {
    requireMultiSigForCritical: boolean; // Default: true when admins.length >= 2
    multiSigThreshold: number; // Default: 2 (2-of-N approval)
    enableAuditLog: boolean; // Default: true
    auditRetentionTier: 'free' | 'premium' | 'enterprise'; // Default: 'free'
    // Advanced Voting Settings (Phase 6.4)
    votingSystem?: 'simple' | 'weighted' | 'quadratic'; // Default: 'simple'
    enableDelegation?: boolean; // Default: false
    quadraticCreditsPerMember?: number; // Default: 100
  };

  // Metadata
  version: string;
  metadata?: Record<string, unknown>;
}

/**
 * DAO Member relationship interface
 */
export interface DAOMember {
  id: string;
  daoId: string;
  userId: string;
  role: MemberRole;

  // Membership details
  joinedAt: string; // ISO 8601
  invitedBy?: string;
  approvedBy?: string;
  approvedAt?: string; // ISO 8601

  // Member status
  isActive: boolean;

  // Participation metrics
  proposalsCreated: number;
  votesSubmitted: number;
  lastActivityAt?: string; // ISO 8601

  // Permissions
  permissions: string[];

  // Token holdings (if applicable)
  tokenBalance?: number;
  votingWeight?: number;

  // Metadata
  joinReason?: string;
  notes?: string;
  metadata?: Record<string, unknown>;
}

/**
 * DAO Member with populated user profile data
 * This is what components should use for display
 */
export interface DAOMemberWithProfile extends DAOMember {
  user: {
    id: string;
    username?: string;
    displayName: string;
    email: string;
    avatarUrl?: string;
    firstName?: string;
    lastName?: string;
    isActive: boolean;
  };
}

/**
 * DAO Invitation interface for managing join requests
 */
export interface DAOInvitation {
  id: string;
  daoId: string;
  invitedUserId: string;
  invitedBy: string;

  // Invitation details
  message?: string;
  role: MemberRole;

  // Status
  status: 'pending' | 'accepted' | 'rejected' | 'expired';

  // Timestamps
  createdAt: string; // ISO 8601
  expiresAt?: string; // ISO 8601
  respondedAt?: string; // ISO 8601

  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * DAO Join Request interface for approval-based DAOs
 */
export interface DAOJoinRequest {
  id: string;
  daoId: string;
  userId: string;

  // Request details
  message?: string;
  walletAddress?: string;

  // Status
  status: 'pending' | 'approved' | 'rejected';

  // Review information
  reviewedBy?: string;
  reviewedAt?: string; // ISO 8601
  reviewNotes?: string;

  // Timestamps
  createdAt: string; // ISO 8601

  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * DAO Activity interface for tracking actions
 */
export interface DAOActivity {
  id: string;
  daoId: string;
  userId: string;

  // Activity details
  type:
    | 'member_joined'
    | 'member_left'
    | 'member_removed'
    | 'proposal_created'
    | 'proposal_voted'
    | 'role_changed'
    | 'settings_updated'
    | 'treasury_action'
    | 'other';
  title: string;
  description?: string;

  // Related entities
  relatedId?: string; // ID of related entity (proposal, member, etc.)
  relatedType?: string; // Type of related entity

  // Metadata
  data?: Record<string, unknown>;

  // Timestamps
  createdAt: string; // ISO 8601

  // Visibility
  isPublic: boolean;
}

/**
 * DAO Creation form data interface
 */
export interface CreateDAOFormData extends Record<string, unknown> {
  name: string;
  description: string;
  slug: string;
  category: DAOCategory;
  organizationType?: OrganizationType; // Template-based classification

  // New improved visibility model
  isDiscoverable: boolean;
  joinPermission: DAOJoinPermission;

  // Deprecated - for backward compatibility
  visibility?: DAOVisibility;

  socialLinks: Partial<DAOSocialLinks>;
  settings: Partial<DAOSettings>;
  tags: string[];
  logoUrl?: string;
  bannerUrl?: string;

  // Active Wallet Configuration
  createActiveWallet?: boolean; // Default: true
  walletGovernancePreset?: 'active_defi' | 'conservative' | 'community';

  // Treasury Configuration
  treasuryType?: TreasuryType;
  hybridTreasuryEnabled?: boolean;
}

/**
 * DAO Update form data interface
 */
export interface UpdateDAOFormData extends Partial<CreateDAOFormData> {
  id: string;
}

/**
 * DAO Search filters interface
 */
export interface DAOSearchFilters extends Record<string, unknown> {
  query?: string;
  category?: DAOCategory;
  organizationType?: OrganizationType;
  status?: DAOStatus;

  // Visibility model
  isDiscoverable?: boolean;
  joinPermission?: DAOJoinPermission;

  minMembers?: number;
  maxMembers?: number;
  tags?: string[];
  isFeatured?: boolean;
  isVerified?: boolean;
  hasActiveTreasury?: boolean;
  sortBy?:
    | 'name'
    | 'memberCount'
    | 'createdAt'
    | 'lastActivityAt'
    | 'proposalCount';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

/**
 * DAO List response interface
 */
export interface DAOListResponse {
  daos: DAO[];
  total: number;
  hasMore: boolean;
  nextOffset?: number;
}

/**
 * DAO Member List response interface
 */
export interface DAOMemberListResponse {
  members: DAOMember[];
  total: number;
  hasMore: boolean;
  nextOffset?: number;
}

/**
 * Admin Audit Types
 * Re-exported from admin service for convenience
 */
export type {
  AdminAuditRecord,
  AdminAuditLogParams,
} from '@/lib/services/admin/types/audit.types';
export { AdminActionType } from '@/lib/services/admin/types/audit.types';

/**
 * Admin Action Proposal Types
 * Re-exported from admin service for convenience
 * Note: Renamed ProposalStatus to AdminProposalStatus to avoid conflict with proposal.ts ProposalStatus
 */
export type {
  AdminActionProposal,
  CreateProposalParams,
  ApproveProposalParams,
} from '@/lib/services/admin/types/proposal.types';
export {
  ProposalStatus as AdminProposalStatus,
  ActionTier,
} from '@/lib/services/admin/types/proposal.types';
