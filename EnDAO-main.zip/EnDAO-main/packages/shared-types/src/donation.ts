/**
 * Donation Types
 *
 * Types for the fiat-to-crypto donation feature enabling non-crypto users
 * to donate to DAOs via credit/debit card with automatic crypto conversion.
 */

// ============================================================================
// ENUMS AND CONSTANTS
// ============================================================================

/**
 * Donation lifecycle status
 */
export type DonationStatus =
  | 'pending' // Initial state
  | 'payment_processing' // Stripe checkout started
  | 'payment_completed' // Stripe payment succeeded
  | 'converting' // Fiat to crypto conversion in progress
  | 'sending' // Crypto transfer initiated
  | 'completed' // Successfully delivered to destination
  | 'failed' // Any step failed
  | 'refunded'; // Payment refunded

/**
 * Where donations are sent
 */
export type DonationDestinationType = 'treasury' | 'wallet';

/**
 * Donor privacy choice
 */
export type DonorVisibility = 'anonymous' | 'name_only' | 'full';

// ============================================================================
// DONATION CONFIGURATION
// ============================================================================

/**
 * Donation configuration for a DAO
 */
export interface DonationConfig {
  id: string;
  daoId: string;
  isEnabled: boolean;
  destinationType: DonationDestinationType;
  minDonationUsd: number;
  maxDonationUsd: number;
  suggestedAmounts: number[];
  donationMessage: string | null;
  showDonorList: boolean;
  allowAnonymous: boolean;
  createdAt: string;
  updatedAt: string;
}

/**
 * Input for creating/updating donation configuration
 */
export interface DonationConfigInput {
  isEnabled?: boolean;
  destinationType?: DonationDestinationType;
  minDonationUsd?: number;
  maxDonationUsd?: number;
  suggestedAmounts?: number[];
  donationMessage?: string | null;
  showDonorList?: boolean;
  allowAnonymous?: boolean;
}

/**
 * Database row for donation_configs table
 */
export interface DonationConfigRow {
  id: string;
  dao_id: string;
  is_enabled: boolean;
  destination_type: string;
  min_donation_usd: number;
  max_donation_usd: number;
  suggested_amounts: number[];
  donation_message: string | null;
  show_donor_list: boolean;
  allow_anonymous: boolean;
  created_at: string;
  updated_at: string;
}

// ============================================================================
// DONATION
// ============================================================================

/**
 * Individual donation record
 */
export interface Donation {
  id: string;
  daoId: string;
  donorUserId: string | null;
  donorName: string | null;
  donorEmail: string | null;
  visibility: DonorVisibility;
  fiatAmount: number;
  fiatCurrency: string;
  cryptoAmount: number | null;
  cryptoCurrency: string;
  destinationAddress: string;
  destinationType: DonationDestinationType;
  chainId: number;
  stripeSessionId: string | null;
  stripePaymentIntentId: string | null;
  txHash: string | null;
  status: DonationStatus;
  errorMessage: string | null;
  metadata: Record<string, unknown>;
  // Conversion fields
  conversionProvider: string | null;
  conversionId: string | null;
  conversionStatus: string | null;
  conversionInitiatedAt: string | null;
  conversionCompletedAt: string | null;
  conversionRate: number | null;
  conversionFeeUsd: number | null;
  createdAt: string;
  updatedAt: string;
}

/**
 * Database row for donations table
 */
export interface DonationRow {
  id: string;
  dao_id: string;
  donor_user_id: string | null;
  donor_name: string | null;
  donor_email: string | null;
  visibility: string;
  fiat_amount: number;
  fiat_currency: string;
  crypto_amount: number | null;
  crypto_currency: string;
  destination_address: string;
  destination_type: string;
  chain_id: number;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  tx_hash: string | null;
  status: string;
  error_message: string | null;
  metadata: Record<string, unknown>;
  // Conversion fields
  conversion_provider: string | null;
  conversion_id: string | null;
  conversion_status: string | null;
  conversion_initiated_at: string | null;
  conversion_completed_at: string | null;
  conversion_rate: number | null;
  conversion_fee_usd: number | null;
  created_at: string;
  updated_at: string;
}

/**
 * Input for creating a new donation
 */
export interface CreateDonationInput {
  daoId: string;
  amount: number;
  donorName?: string;
  donorEmail?: string;
  visibility?: DonorVisibility;
}

/**
 * Response from initiating a donation
 */
export interface InitiateDonationResponse {
  donationId: string;
  checkoutUrl: string;
}

// ============================================================================
// PUBLIC DONATION DISPLAY
// ============================================================================

/**
 * Public donation info (sanitized for display)
 */
export interface PublicDonation {
  id: string;
  createdAt: string;
  visibility: DonorVisibility;
  donorName?: string;
  fiatAmount?: number;
  fiatCurrency?: string;
}

// ============================================================================
// DONATION STATISTICS
// ============================================================================

/**
 * Aggregate donation statistics for a DAO
 */
export interface DonationStats {
  totalDonations: number;
  totalAmountUsd: number;
  donorCount: number;
  averageDonation: number;
  recentDonations: PublicDonation[];
}

// ============================================================================
// WEBHOOK EVENTS
// ============================================================================

/**
 * Stripe webhook event record
 */
export interface DonationWebhookEvent {
  id: string;
  stripeEventId: string;
  eventType: string;
  donationId: string | null;
  processedAt: string;
  payload: Record<string, unknown>;
}

/**
 * Database row for donation_webhook_events table
 */
export interface DonationWebhookEventRow {
  id: string;
  stripe_event_id: string;
  event_type: string;
  donation_id: string | null;
  processed_at: string;
  payload: Record<string, unknown>;
}

// ============================================================================
// DESTINATION RESOLUTION
// ============================================================================

/**
 * Resolved donation destination
 */
export interface DonationDestination {
  address: string;
  chainId: number;
  type: DonationDestinationType;
  network: string;
}

// ============================================================================
// STRIPE ONRAMP
// ============================================================================

/**
 * Stripe onramp session parameters
 */
export interface OnrampSessionParams {
  amount: number;
  currency: string;
  destinationAddress: string;
  destinationNetwork: string;
  donationId: string;
  successUrl: string;
  cancelUrl: string;
}

/**
 * Stripe onramp session response
 */
export interface OnrampSessionResponse {
  sessionId: string;
  clientSecret: string;
  url: string;
}

/**
 * Stripe onramp session status
 */
export type OnrampSessionStatus =
  | 'initialized'
  | 'pending'
  | 'fulfillment_processing'
  | 'fulfillment_complete'
  | 'cancelled'
  | 'failed';

// ============================================================================
// MAPPERS
// ============================================================================

/**
 * Map database row to DonationConfig
 */
export function mapDonationConfigRow(row: DonationConfigRow): DonationConfig {
  return {
    id: row.id,
    daoId: row.dao_id,
    isEnabled: row.is_enabled,
    destinationType: row.destination_type as DonationDestinationType,
    minDonationUsd: Number(row.min_donation_usd),
    maxDonationUsd: Number(row.max_donation_usd),
    suggestedAmounts: row.suggested_amounts?.map(Number) ?? [
      10, 25, 50, 100, 250,
    ],
    donationMessage: row.donation_message,
    showDonorList: row.show_donor_list,
    allowAnonymous: row.allow_anonymous,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/**
 * Map database row to Donation
 */
export function mapDonationRow(row: DonationRow): Donation {
  return {
    id: row.id,
    daoId: row.dao_id,
    donorUserId: row.donor_user_id,
    donorName: row.donor_name,
    donorEmail: row.donor_email,
    visibility: row.visibility as DonorVisibility,
    fiatAmount: Number(row.fiat_amount),
    fiatCurrency: row.fiat_currency,
    cryptoAmount: row.crypto_amount ? Number(row.crypto_amount) : null,
    cryptoCurrency: row.crypto_currency,
    destinationAddress: row.destination_address,
    destinationType: row.destination_type as DonationDestinationType,
    chainId: row.chain_id,
    stripeSessionId: row.stripe_session_id,
    stripePaymentIntentId: row.stripe_payment_intent_id,
    txHash: row.tx_hash,
    status: row.status as DonationStatus,
    errorMessage: row.error_message,
    metadata: row.metadata ?? {},
    // Conversion fields
    conversionProvider: row.conversion_provider,
    conversionId: row.conversion_id,
    conversionStatus: row.conversion_status,
    conversionInitiatedAt: row.conversion_initiated_at,
    conversionCompletedAt: row.conversion_completed_at,
    conversionRate: row.conversion_rate ? Number(row.conversion_rate) : null,
    conversionFeeUsd: row.conversion_fee_usd
      ? Number(row.conversion_fee_usd)
      : null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

/**
 * Sanitize donation for public display based on visibility
 */
export function sanitizeDonationForPublic(
  donation: Donation
): PublicDonation | null {
  // Anonymous donations should not be included in public lists
  if (donation.visibility === 'anonymous') {
    return null;
  }

  const base: PublicDonation = {
    id: donation.id,
    createdAt: donation.createdAt,
    visibility: donation.visibility,
  };

  // Name shown for 'name_only' and 'full'
  if (donation.donorName) {
    base.donorName = donation.donorName;
  }

  // Amount ONLY shown for 'full' visibility
  if (donation.visibility === 'full') {
    base.fiatAmount = donation.fiatAmount;
    base.fiatCurrency = donation.fiatCurrency;
  }

  return base;
}
