/**
 * Extended DAO Activity Types
 * Extends the basic types from dao.ts with more specific activity types
 */
export type ExtendedDAOActivityType =
  | 'member_joined'
  | 'member_left'
  | 'member_removed'
  | 'member_promoted'
  | 'member_demoted'
  | 'proposal_created'
  | 'proposal_voted'
  | 'proposal_updated'
  | 'proposal_executed'
  | 'proposal_finalized'
  | 'vote_cast'
  | 'vote_changed'
  | 'role_changed'
  | 'settings_updated'
  | 'treasury_action'
  | 'treasury_withdrawal'
  | 'treasury_deposit'
  | 'dao_created'
  | 'dao_updated'
  | 'invitation_sent'
  | 'invitation_accepted'
  | 'other';

/**
 * Activity Impact Levels
 */
export type ActivityImpact = 'low' | 'medium' | 'high';

/**
 * Extended Activity Data
 * Flexible data structure for different activity types
 */
export interface ActivityData {
  proposalId?: string;
  userId?: string;
  targetUserId?: string;
  amount?: number;
  currency?: string;
  oldValue?: unknown;
  newValue?: unknown;
  reason?: string;
  vote?: 'for' | 'against' | 'abstain';
  oldRole?: string;
  newRole?: string;
  removedBy?: string;
  title?: string;
  metadata?: Record<string, unknown>;
  [key: string]: unknown;
}

/**
 * Activity Feed Item
 * Simplified view for displaying in activity feeds
 */
export interface ActivityFeedItem {
  id: string;
  type: ExtendedDAOActivityType;
  title: string;
  description: string;
  userId: string;
  userName?: string; // Denormalized for display
  userAvatar?: string; // Denormalized for display
  daoId: string;
  daoName?: string; // Denormalized for display
  timestamp: Date;
  impact: ActivityImpact;
}
