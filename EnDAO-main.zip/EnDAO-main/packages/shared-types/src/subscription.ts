/**
 * Subscription Types
 *
 * Platform subscription infrastructure for DAO premium tiers.
 */

/**
 * Subscription tiers available on the platform
 * - starter: Free tier for small groups getting started
 * - community: $29/mo for active groups needing more flexibility
 * - organization: $79/mo for established orgs with complex governance
 * - enterprise: Custom pricing for large organizations and white-label
 */
export type SubscriptionTier =
  | 'starter'
  | 'community'
  | 'organization'
  | 'enterprise';

/**
 * Subscription status from Stripe
 */
export type SubscriptionStatus =
  | 'active'
  | 'canceled'
  | 'incomplete'
  | 'incomplete_expired'
  | 'past_due'
  | 'paused'
  | 'trialing'
  | 'unpaid';

/**
 * Simplified subscription status for DAO display
 */
export type DAOSubscriptionStatus =
  | 'active'
  | 'canceled'
  | 'past_due'
  | 'trialing'
  | 'none';

/**
 * Stripe customer record
 */
export interface StripeCustomer {
  id: string;
  daoId: string;
  stripeCustomerId: string;
  email?: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * Subscription record
 */
export interface Subscription {
  id: string;
  daoId: string;
  stripeSubscriptionId: string;
  stripeCustomerId: string;
  stripePriceId: string;
  status: SubscriptionStatus;
  tier: SubscriptionTier;
  currentPeriodStart?: string;
  currentPeriodEnd?: string;
  cancelAtPeriodEnd: boolean;
  canceledAt?: string;
  trialStart?: string;
  trialEnd?: string;
  /** Stripe Entitlement lookup keys - dynamically defines enabled features */
  entitlements?: string[];
  /** Whether customer is tax exempt */
  taxExempt?: boolean;
  /** Customer tax IDs (VAT, GST, etc.) */
  taxIds?: TaxId[];
  metadata?: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

/**
 * Customer tax ID (VAT, GST, etc.)
 */
export interface TaxId {
  type: string; // e.g., 'eu_vat', 'gb_vat', 'au_abn'
  value: string;
  country?: string;
}

/**
 * Subscription event for audit/debugging
 */
export interface SubscriptionEvent {
  id: string;
  stripeEventId: string;
  eventType: string;
  stripeSubscriptionId?: string;
  stripeCustomerId?: string;
  daoId?: string;
  data?: Record<string, unknown>;
  processedAt: string;
  createdAt: string;
}

/**
 * Tier feature limits and capabilities
 */
export interface TierFeatures {
  tier: SubscriptionTier;
  name: string;
  description: string;
  priceMonthly: number; // in cents
  priceYearly: number; // in cents
  features: {
    maxMembers: number | 'unlimited';
    maxProposalsPerMonth: number | 'unlimited';
    maxStorageGB: number;
    customBranding: boolean;
    prioritySupport: boolean;
    apiAccess: boolean;
    advancedAnalytics: boolean;
    ssoIntegration: boolean;
    auditLogs: boolean;
    whiteLabel: boolean;
  };
}

/**
 * Tier configuration - defines what each tier includes
 * Prices match pricing page and strategy doc
 */
export const TIER_FEATURES: Record<SubscriptionTier, TierFeatures> = {
  starter: {
    tier: 'starter',
    name: 'Starter',
    description: 'For small groups getting started with shared finances',
    priceMonthly: 0,
    priceYearly: 0,
    features: {
      maxMembers: 10,
      maxProposalsPerMonth: 'unlimited',
      maxStorageGB: 1,
      customBranding: false,
      prioritySupport: false,
      apiAccess: false,
      advancedAnalytics: false,
      ssoIntegration: false,
      auditLogs: false,
      whiteLabel: false,
    },
  },
  community: {
    tier: 'community',
    name: 'Community',
    description: 'For active groups needing more flexibility and control',
    priceMonthly: 2900, // $29/month
    priceYearly: 28800, // $24/month billed annually ($288/year, ~17% discount)
    features: {
      maxMembers: 50,
      maxProposalsPerMonth: 'unlimited',
      maxStorageGB: 10,
      customBranding: true,
      prioritySupport: true,
      apiAccess: false,
      advancedAnalytics: true,
      ssoIntegration: false,
      auditLogs: true,
      whiteLabel: false,
    },
  },
  organization: {
    tier: 'organization',
    name: 'Organization',
    description: 'For established organizations with complex governance needs',
    priceMonthly: 7900, // $79/month
    priceYearly: 79200, // $66/month billed annually ($792/year, ~17% discount)
    features: {
      maxMembers: 200,
      maxProposalsPerMonth: 'unlimited',
      maxStorageGB: 50,
      customBranding: true,
      prioritySupport: true,
      apiAccess: true,
      advancedAnalytics: true,
      ssoIntegration: false,
      auditLogs: true,
      whiteLabel: false,
    },
  },
  enterprise: {
    tier: 'enterprise',
    name: 'Enterprise',
    description:
      'For large organizations, networks, and white-label deployments',
    priceMonthly: 0, // Custom pricing
    priceYearly: 0, // Custom pricing
    features: {
      maxMembers: 'unlimited',
      maxProposalsPerMonth: 'unlimited',
      maxStorageGB: 'unlimited' as unknown as number, // Unlimited
      customBranding: true,
      prioritySupport: true,
      apiAccess: true,
      advancedAnalytics: true,
      ssoIntegration: true,
      auditLogs: true,
      whiteLabel: true,
    },
  },
};

/**
 * Lookup keys for Stripe prices
 * These must match the lookup_key set in Stripe Dashboard
 */
export const STRIPE_PRICE_LOOKUP_KEYS = {
  community_monthly: 'community_monthly',
  community_yearly: 'community_yearly',
  organization_monthly: 'organization_monthly',
  organization_yearly: 'organization_yearly',
  enterprise_monthly: 'enterprise_monthly',
  enterprise_yearly: 'enterprise_yearly',
} as const;

export type StripePriceLookupKey =
  (typeof STRIPE_PRICE_LOOKUP_KEYS)[keyof typeof STRIPE_PRICE_LOOKUP_KEYS];

/**
 * Stripe Entitlement lookup keys
 * Define features that can be dynamically enabled/disabled via Stripe Dashboard
 * These must match the lookup_key set in Stripe Entitlements
 */
export const STRIPE_ENTITLEMENT_KEYS = {
  // Core features
  advancedAnalytics: 'advanced-analytics',
  apiAccess: 'api-access',
  prioritySupport: 'priority-support',
  customBranding: 'custom-branding',
  auditLogs: 'audit-logs',

  // Premium features
  ssoIntegration: 'sso-integration',
  whiteLabel: 'white-label',
  unlimitedMembers: 'unlimited-members',
  unlimitedProposals: 'unlimited-proposals',

  // Add-ons (can be sold separately)
  smsNotifications: 'sms-notifications',
  webhookIntegrations: 'webhook-integrations',
  customDomain: 'custom-domain',
} as const;

export type StripeEntitlementKey =
  (typeof STRIPE_ENTITLEMENT_KEYS)[keyof typeof STRIPE_ENTITLEMENT_KEYS];

/**
 * Feature flags for tier-gated functionality
 */
export interface TierFeatureFlags {
  /** Can create ops wallet for routine expenses */
  opsWallet: boolean;
  /** Can generate tax compliance reports (1099s) */
  taxCompliance: boolean;
  /** Can customize multi-sig thresholds */
  customMultiSig: boolean;
  /** Can set custom voting periods */
  customVotingPeriods: boolean;
  /** Can create emergency proposals */
  emergencyProposals: boolean;
  /** Can create sub-groups/hierarchies */
  subGroups: boolean;
  /** Can use custom domain */
  customDomain: boolean;
  /** Can set recurring contributions */
  recurringContributions: boolean;
  /** Can export reports (CSV/PDF) */
  exportReports: boolean;
}

/**
 * Feature flags by tier
 */
export const TIER_FEATURE_FLAGS: Record<SubscriptionTier, TierFeatureFlags> = {
  starter: {
    opsWallet: false,
    taxCompliance: false,
    customMultiSig: false,
    customVotingPeriods: false,
    emergencyProposals: false,
    subGroups: false,
    customDomain: false,
    recurringContributions: false,
    exportReports: false,
  },
  community: {
    opsWallet: false,
    taxCompliance: false,
    customMultiSig: false,
    customVotingPeriods: true,
    emergencyProposals: false,
    subGroups: false,
    customDomain: false,
    recurringContributions: true,
    exportReports: true,
  },
  organization: {
    opsWallet: true,
    taxCompliance: true,
    customMultiSig: true,
    customVotingPeriods: true,
    emergencyProposals: true,
    subGroups: false,
    customDomain: false,
    recurringContributions: true,
    exportReports: true,
  },
  enterprise: {
    opsWallet: true,
    taxCompliance: true,
    customMultiSig: true,
    customVotingPeriods: true,
    emergencyProposals: true,
    subGroups: true,
    customDomain: true,
    recurringContributions: true,
    exportReports: true,
  },
};

/**
 * Transaction fee rates by tier (in basis points, 100 = 1%)
 */
export const TIER_TRANSACTION_FEES: Record<
  SubscriptionTier,
  { contributionFee: number; transferFee: number }
> = {
  starter: { contributionFee: 500, transferFee: 200 }, // 5% contribution, 2% transfer
  community: { contributionFee: 300, transferFee: 150 }, // 3% contribution, 1.5% transfer
  organization: { contributionFee: 200, transferFee: 100 }, // 2% contribution, 1% transfer
  enterprise: { contributionFee: 0, transferFee: 0 }, // Custom
};

/**
 * Billing cycle options
 */
export type BillingCycle = 'monthly' | 'yearly';

/**
 * Input for creating a checkout session
 */
export interface CreateCheckoutInput {
  daoId: string;
  tier: Exclude<SubscriptionTier, 'starter'>; // Can't buy starter
  billingCycle: BillingCycle;
  successUrl: string;
  cancelUrl: string;
}

/**
 * Subscription with DAO context for display
 */
export interface SubscriptionWithDAO extends Subscription {
  daoName: string;
  daoSlug: string;
}

/**
 * Usage limits and current usage for a DAO
 */
export interface TierUsage {
  tier: SubscriptionTier;
  members: {
    current: number;
    limit: number | 'unlimited';
    percentUsed: number;
    isAtLimit: boolean;
    isNearLimit: boolean; // >80%
  };
  /** Days remaining in trial, null if not trialing */
  trialDaysRemaining: number | null;
}

/**
 * Upgrade required error response
 */
export interface UpgradeRequiredError {
  code: 'UPGRADE_REQUIRED';
  message: string;
  requiredTier: SubscriptionTier;
  feature: string;
}
