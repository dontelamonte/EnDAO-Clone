/**
 * Type definitions for DAO discovery and filtering
 */

import type { DAO, DAOCategory as DAOCategoryType } from './dao';

/**
 * DAO category information for discovery UI
 * Note: Renamed from DAOCategory to avoid conflict with dao.ts DAOCategory type
 */
export interface DAOCategoryInfo {
  name: string;
  slug: string;
  count: number;
  description?: string;
  icon?: string;
  color?: string;
}

/**
 * Search filters for DAO discovery
 */
export interface SearchFilters {
  searchQuery: string;
  selectedCategory: string;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  tags?: string[];
  memberRange?: {
    min: number;
    max: number;
  };
  fundingRange?: {
    min: number;
    max: number;
  };
  activityLevel?: 'low' | 'medium' | 'high';
  isActive?: boolean;
}

/**
 * Pagination state for discovery
 */
export interface PaginationState {
  page: number;
  hasMore: boolean;
  itemsPerPage: number;
  total?: number;
}

/**
 * DAO discovery data with enhanced information
 */
export interface EnhancedDAO extends Omit<DAO, 'category'> {
  memberCount: number;
  proposalCount: number;
  treasuryValue: number;
  activityScore: number;
  recentActivity: ActivityIndicator[];
  category: DAOCategoryType;
  tags: string[];
  joinStatus?: 'member' | 'pending' | 'not_member';
  featuredRank?: number;
  trending?: boolean;
}

/**
 * Activity indicator for DAO discovery
 */
export interface ActivityIndicator {
  type: 'proposal' | 'vote' | 'treasury' | 'member_join' | 'governance';
  timestamp: number;
  title: string;
  description?: string;
  participants?: number;
  value?: number;
}

/**
 * Featured DAO with ranking
 */
export interface FeaturedDAO extends EnhancedDAO {
  featuredReason: string;
  featuredUntil?: number;
  promotionScore: number;
}

/**
 * DAO discovery metrics
 */
export interface DiscoveryMetrics {
  totalDAOs: number;
  activeDAOs: number;
  categoryCounts: Record<string, number>;
  averageMembers: number;
  totalTreasuryValue: number;
  newDAOsThisWeek: number;
  trendingDAOs: string[];
}

/**
 * Search result with metadata
 */
export interface SearchResult<T = EnhancedDAO> {
  items: T[];
  total: number;
  page: number;
  itemsPerPage: number;
  hasMore: boolean;
  filters: SearchFilters;
  metadata: {
    searchTime: number;
    fromCache: boolean;
    suggestedFilters?: Partial<SearchFilters>;
    relatedCategories?: DAOCategoryType[];
  };
}

/**
 * DAO recommendation engine data
 */
export interface DAORecommendation {
  dao: EnhancedDAO;
  score: number;
  reasons: RecommendationReason[];
  confidence: number;
}

/**
 * Recommendation reason
 */
export interface RecommendationReason {
  type:
    | 'interest_match'
    | 'activity_level'
    | 'size_preference'
    | 'category_match'
    | 'trending';
  weight: number;
  description: string;
  metadata?: Record<string, unknown>;
}

/**
 * User preferences for DAO discovery
 */
export interface DiscoveryPreferences {
  userId: string;
  preferredCategories: string[];
  memberSizePreference: 'small' | 'medium' | 'large' | 'any';
  activityLevelPreference: 'low' | 'medium' | 'high' | 'any';
  treasurySizePreference: 'startup' | 'established' | 'enterprise' | 'any';
  interests: string[];
  hideJoinedDAOs: boolean;
  showTrendingFirst: boolean;
  customFilters?: Record<string, unknown>;
}

/**
 * DAO join request data for discovery UI
 * Note: Renamed to avoid conflict with dao.ts DAOJoinRequest
 */
export interface DiscoveryJoinRequest {
  id: string;
  daoId: string;
  userId: string;
  status: 'pending' | 'approved' | 'rejected' | 'cancelled';
  requestedAt: number;
  processedAt?: number;
  processedBy?: string;
  message?: string;
  responseMessage?: string;
}

/**
 * Discovery view mode
 */
export type DiscoveryViewMode = 'grid' | 'list' | 'table';

/**
 * Sort options for DAOs
 */
export type DAOSortOption =
  | 'name'
  | 'created_at'
  | 'member_count'
  | 'treasury_value'
  | 'activity_score'
  | 'proposal_count'
  | 'trending_score'
  | 'featured_rank';

/**
 * Filter facets for advanced filtering
 */
export interface FilterFacets {
  categories: Array<{
    key: string;
    label: string;
    count: number;
  }>;
  memberRanges: Array<{
    key: string;
    label: string;
    min: number;
    max: number;
    count: number;
  }>;
  activityLevels: Array<{
    key: string;
    label: string;
    count: number;
  }>;
  tags: Array<{
    key: string;
    label: string;
    count: number;
  }>;
}

/**
 * Discovery context state
 */
export interface DiscoveryState {
  viewMode: DiscoveryViewMode;
  isLoading: boolean;
  error: string | null;
  filters: SearchFilters;
  pagination: PaginationState;
  selectedDAOs: string[];
  preferences?: DiscoveryPreferences;
}

/**
 * DAO interaction tracking
 */
export interface DAOInteraction {
  type: 'view' | 'click' | 'join_request' | 'share' | 'bookmark';
  daoId: string;
  userId: string;
  timestamp: number;
  metadata?: Record<string, unknown>;
  sessionId?: string;
}

/**
 * Discovery analytics event
 */
export interface DiscoveryAnalyticsEvent {
  event:
    | 'search'
    | 'filter'
    | 'sort'
    | 'view_change'
    | 'dao_click'
    | 'join_request';
  timestamp: number;
  userId?: string;
  sessionId: string;
  data: {
    query?: string;
    filters?: Partial<SearchFilters>;
    daoId?: string;
    viewMode?: DiscoveryViewMode;
    resultCount?: number;
    position?: number;
  };
}

/**
 * Performance tracking for discovery
 */
export interface DiscoveryPerformanceMetrics {
  searchTime: number;
  renderTime: number;
  totalDAOs: number;
  filteredDAOs: number;
  cacheHitRate: number;
  apiCalls: number;
  timestamp: number;
}

/**
 * Type guard for enhanced DAO
 */
export function isEnhancedDAO(dao: unknown): dao is EnhancedDAO {
  if (typeof dao !== 'object' || dao === null) return false;

  const d = dao as Record<string, unknown>;
  return (
    'id' in d &&
    'memberCount' in d &&
    'proposalCount' in d &&
    'treasuryValue' in d &&
    'activityScore' in d &&
    typeof d.memberCount === 'number' &&
    typeof d.proposalCount === 'number' &&
    typeof d.treasuryValue === 'number' &&
    typeof d.activityScore === 'number'
  );
}

/**
 * Type guard for search result
 */
export function isSearchResult(result: unknown): result is SearchResult {
  if (typeof result !== 'object' || result === null) return false;

  const r = result as Record<string, unknown>;
  return (
    'items' in r &&
    'total' in r &&
    'page' in r &&
    'itemsPerPage' in r &&
    'hasMore' in r &&
    'filters' in r &&
    'metadata' in r &&
    Array.isArray(r.items) &&
    typeof r.total === 'number' &&
    typeof r.page === 'number' &&
    typeof r.itemsPerPage === 'number' &&
    typeof r.hasMore === 'boolean'
  );
}

/**
 * Type guard for DAO category info
 */
export function isDAOCategoryInfo(
  category: unknown
): category is DAOCategoryInfo {
  if (typeof category !== 'object' || category === null) return false;

  const c = category as Record<string, unknown>;
  return (
    'name' in c &&
    'slug' in c &&
    'count' in c &&
    typeof c.name === 'string' &&
    typeof c.slug === 'string' &&
    typeof c.count === 'number'
  );
}

/**
 * Type guard for search filters
 */
export function isSearchFilters(filters: unknown): filters is SearchFilters {
  if (typeof filters !== 'object' || filters === null) return false;

  const f = filters as Record<string, unknown>;
  return (
    'searchQuery' in f &&
    'selectedCategory' in f &&
    'sortBy' in f &&
    'sortOrder' in f &&
    typeof f.searchQuery === 'string' &&
    typeof f.selectedCategory === 'string' &&
    typeof f.sortBy === 'string' &&
    ['asc', 'desc'].includes(f.sortOrder as string)
  );
}
