/**
 * Type definitions for performance monitoring and optimization
 *
 * This is the CANONICAL source for all performance-related types.
 * Other services/utilities should import from here.
 */

// ============================================================================
// Core Metric Types
// ============================================================================

/**
 * Unit types for performance measurements
 */
export type PerformanceUnit = 'ms' | 'bytes' | 'count' | 'percent' | 'score';

/**
 * Categories for organizing performance metrics
 */
export type PerformanceCategory =
  | 'load'
  | 'runtime'
  | 'interaction'
  | 'memory'
  | 'network'
  | 'api'
  | 'auth';

/**
 * Performance metric data point (comprehensive version)
 * Used for detailed tracking with categorization
 */
export interface PerformanceMetric {
  name: string;
  value: number;
  unit: PerformanceUnit;
  timestamp: number;
  category?: PerformanceCategory;
  tags?: Record<string, string | number>;
  context?: Record<string, unknown>;
}

/**
 * Simplified performance metric for service-level tracking
 * Compatible with PerformanceService
 */
export interface SimplePerformanceMetric {
  name: string;
  value: number;
  unit: PerformanceUnit;
  timestamp: number;
  context?: Record<string, unknown>;
}

/**
 * Performance measurement result
 */
export interface PerformanceMeasurement {
  name: string;
  startTime: number;
  endTime: number;
  duration: number;
  marks: PerformanceMark[];
  metrics: PerformanceMetric[];
}

/**
 * Performance mark for tracking specific points
 */
export interface PerformanceMark {
  name: string;
  timestamp: number;
  details?: Record<string, unknown>;
}

/**
 * Web Vitals metrics
 */
export interface WebVitalsMetrics {
  LCP: number; // Largest Contentful Paint
  FID: number; // First Input Delay
  CLS: number; // Cumulative Layout Shift
  TTFB: number; // Time to First Byte
  FCP: number; // First Contentful Paint
  INP?: number; // Interaction to Next Paint
}

/**
 * Performance budget thresholds
 */
export interface PerformanceBudget {
  metrics: {
    LCP: { good: number; needs_improvement: number };
    FID: { good: number; needs_improvement: number };
    CLS: { good: number; needs_improvement: number };
    TTFB: { good: number; needs_improvement: number };
    bundleSize: { warning: number; error: number };
    loadTime: { target: number; maximum: number };
  };
  resources: {
    maxBundleSize: number;
    maxImageSize: number;
    maxCssSize: number;
    maxJsSize: number;
  };
}

/**
 * Performance report data
 */
export interface PerformanceReport {
  id: string;
  timestamp: number;
  url: string;
  userAgent: string;
  connection?: {
    effectiveType: string;
    downlink: number;
    rtt: number;
  };
  vitals: WebVitalsMetrics;
  measurements: PerformanceMeasurement[];
  resourceTimings: ResourceTiming[];
  warnings: PerformanceWarning[];
  score: number; // Overall performance score 0-100
}

/**
 * Resource timing information
 */
export interface ResourceTiming {
  name: string;
  type: 'script' | 'stylesheet' | 'image' | 'font' | 'fetch' | 'navigation';
  startTime: number;
  duration: number;
  transferSize: number;
  encodedBodySize: number;
  decodedBodySize: number;
  responseStatus?: number;
}

/**
 * Performance warning
 */
export interface PerformanceWarning {
  type:
    | 'budget_exceeded'
    | 'slow_metric'
    | 'large_resource'
    | 'inefficient_operation';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  metric?: string;
  value?: number;
  threshold?: number;
  suggestion?: string;
}

/**
 * Cache performance metrics
 */
export interface CacheMetrics {
  hits: number;
  misses: number;
  hitRate: number;
  totalRequests: number;
  averageResponseTime: number;
  cacheSize: number;
  evictions: number;
}

/**
 * Batch processing metrics
 */
export interface BatchMetrics<T> {
  batchSize: number;
  processingTime: number;
  itemsProcessed: number;
  errors: number;
  successRate: number;
  averageItemTime: number;
  results: T[];
}

/**
 * Virtual scrolling performance data
 */
export interface VirtualScrollMetrics {
  totalItems: number;
  visibleItems: number;
  renderTime: number;
  scrollPosition: number;
  itemHeight: number;
  containerHeight: number;
  bufferedItems: number;
}

/**
 * Optimization result
 */
export interface OptimizationResult {
  operation: string;
  before: PerformanceMetric;
  after: PerformanceMetric;
  improvement: number; // Percentage improvement
  successful: boolean;
  details?: Record<string, unknown>;
}

/**
 * Performance monitoring configuration
 */
export interface PerformanceConfig {
  enableTracking: boolean;
  sampleRate: number; // 0-1, percentage of sessions to track
  bufferSize: number;
  reportingInterval: number;
  enableWebVitals: boolean;
  enableResourceTiming: boolean;
  enableLongTasks: boolean;
  budgets: PerformanceBudget;
}

/**
 * Long task performance entry
 */
export interface LongTaskEntry {
  name: string;
  startTime: number;
  duration: number;
  attribution: Array<{
    name: string;
    entryType: string;
    startTime: number;
    duration: number;
    containerType: string;
    containerSrc: string;
    containerId: string;
    containerName: string;
  }>;
}

/**
 * Memory usage information
 */
export interface MemoryUsage {
  used: number;
  total: number;
  limit: number;
  percentage: number;
  timestamp: number;
}

/**
 * Network information for performance context
 */
export interface NetworkInfo {
  effectiveType: '2g' | '3g' | '4g' | 'slow-2g';
  downlink: number;
  rtt: number;
  saveData: boolean;
}

/**
 * Performance observer entry types
 */
export type PerformanceEntryType =
  | 'navigation'
  | 'resource'
  | 'mark'
  | 'measure'
  | 'paint'
  | 'longtask'
  | 'layout-shift'
  | 'largest-contentful-paint'
  | 'first-input';

/**
 * Type guard for performance metric
 */
export function isPerformanceMetric(
  value: unknown
): value is PerformanceMetric {
  if (typeof value !== 'object' || value === null) return false;

  const v = value as Record<string, unknown>;
  return (
    'name' in v &&
    'value' in v &&
    'timestamp' in v &&
    typeof v.name === 'string' &&
    typeof v.value === 'number' &&
    typeof v.timestamp === 'number'
  );
}

/**
 * Type guard for Web Vitals metrics
 */
export function isWebVitalsMetrics(value: unknown): value is WebVitalsMetrics {
  if (typeof value !== 'object' || value === null) return false;

  const v = value as Record<string, unknown>;
  return (
    'LCP' in v &&
    'FID' in v &&
    'CLS' in v &&
    typeof v.LCP === 'number' &&
    typeof v.FID === 'number' &&
    typeof v.CLS === 'number'
  );
}

/**
 * Type guard for performance report
 */
export function isPerformanceReport(
  value: unknown
): value is PerformanceReport {
  if (typeof value !== 'object' || value === null) return false;

  const v = value as Record<string, unknown>;
  return (
    'id' in v &&
    'timestamp' in v &&
    'vitals' in v &&
    'measurements' in v &&
    typeof v.id === 'string' &&
    typeof v.timestamp === 'number' &&
    isWebVitalsMetrics(v.vitals) &&
    Array.isArray(v.measurements)
  );
}

// ============================================================================
// Web Vitals Service Types (for real-time tracking)
// ============================================================================

/**
 * Web Vital metric from web-vitals library
 * Used by PerformanceService for real-time Core Web Vitals tracking
 */
export interface WebVitalsMetric {
  name: 'CLS' | 'FCP' | 'FID' | 'LCP' | 'TTFB' | 'INP';
  value: number;
  delta: number;
  id: string;
  navigationType: string;
}

// ============================================================================
// Performance Monitoring & Alerting Types
// ============================================================================

/**
 * Threshold configuration for performance alerts
 */
export interface PerformanceThreshold {
  warning: number;
  error: number;
}

/**
 * Predefined performance metric thresholds
 */
export interface PerformanceThresholds {
  api_response_time: PerformanceThreshold;
  page_load_time: PerformanceThreshold;
  database_operations_per_page: PerformanceThreshold;
  memory_usage: PerformanceThreshold;
}

/**
 * Performance alert triggered when thresholds are exceeded
 */
export interface PerformanceAlert {
  level: 'warning' | 'error';
  metric: string;
  value: number;
  threshold: PerformanceThreshold;
  context?: Record<string, unknown>;
  timestamp: string;
  url?: string;
  requestId?: string;
}

/**
 * Performance trend direction
 */
export type PerformanceTrend = 'improving' | 'stable' | 'degrading';

/**
 * Performance insights for a specific metric
 */
export interface PerformanceInsight {
  count: number;
  min: number;
  max: number;
  median: number;
  p95: number;
  p99: number;
  average: number;
  trend: PerformanceTrend;
  threshold?: PerformanceThreshold;
}

// ============================================================================
// Authentication Performance Types
// ============================================================================

/**
 * Authentication performance metrics
 * Used for tracking auth operation performance
 */
export interface AuthPerformanceMetrics {
  operation: string;
  duration: number;
  success: boolean;
  targetAchieved: boolean;
  timestamp: Date;
  phases?: AuthPerformancePhase[];
  error?: string;
}

/**
 * Phase timing within an auth operation
 */
export interface AuthPerformancePhase {
  name: string;
  duration: number;
}

/**
 * Auth performance statistics
 */
export interface AuthPerformanceStats {
  averageTime: number;
  successRate: number;
  targetAchievementRate: number;
  fastestTime: number;
  slowestTime: number;
  totalOperations: number;
}
