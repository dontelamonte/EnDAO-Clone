// Core types
export * from './common';
export * from './user';
export * from './dao';
export * from './proposal';
export * from './admin';
export * from './tags';

// Domain-specific types
export * from './safe';
export * from './audit';
export * from './cache';
export * from './discovery';
export * from './performance';
export * from './super-admin';
export * from './activity';
export * from './vote-signature';
export * from './donation';
export * from './device.types';
export * from './subscription';
export * from './treasury';
// Additional invoice types not in treasury
export type {
  UpdateInvoiceInput,
  InvoiceFilters,
  InvoiceSummary,
} from './invoice';

// Adapter interfaces
export * from './adapters';

// Common types
export interface PaginationParams {
  limit?: number;
  offset?: number;
  cursor?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  hasMore: boolean;
  nextCursor?: string;
  nextOffset?: number;
}

export interface SortParams {
  sortBy: string;
  sortOrder: 'asc' | 'desc';
}

export interface SearchParams {
  query?: string;
  filters?: Record<string, unknown>;
}

export interface TimeRange {
  startDate?: Date;
  endDate?: Date;
}

export interface APIResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: string;
}

export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;

  // Extended user information
  bio?: string;
  location?: string;
  website?: string;
  socialLinks?: {
    twitter?: string;
    github?: string;
    linkedin?: string;
    discord?: string;
  };

  // Preferences
  preferences?: {
    notifications?: {
      email: boolean;
      browser: boolean;
      mobile: boolean;
    };
    privacy?: {
      profilePublic: boolean;
      showEmail: boolean;
      showActivity: boolean;
    };
    theme?: 'light' | 'dark' | 'system';
  };

  // Statistics
  stats?: {
    daosJoined: number;
    proposalsCreated: number;
    votesSubmitted: number;
    lastActiveAt?: string;
  };
}

export interface NotificationPreferences {
  email: boolean;
  browser: boolean;
  mobile: boolean;
  frequency: 'immediate' | 'daily' | 'weekly' | 'never';
}

export interface Notification {
  id: string;
  userId: string;
  type:
    | 'proposal_created'
    | 'vote_cast'
    | 'member_joined'
    | 'role_changed'
    | 'dao_updated'
    | 'mention'
    | 'system';
  title: string;
  message: string;

  // Related entities
  relatedId?: string;
  relatedType?: 'dao' | 'proposal' | 'user' | 'vote';

  // Status
  isRead: boolean;
  isArchived: boolean;

  // Metadata
  data?: Record<string, unknown>;

  // Timestamps
  createdAt: string;
  readAt?: string;

  // Actions
  actions?: Array<{
    label: string;
    action: string;
    url?: string;
    primary?: boolean;
  }>;
}

export interface Activity {
  id: string;
  userId: string;
  type: string;
  title: string;
  description?: string;

  // Related entities
  relatedId?: string;
  relatedType?: string;

  // Context
  daoId?: string;
  proposalId?: string;

  // Metadata
  data?: Record<string, unknown>;

  // Timestamps
  createdAt: string;

  // Visibility
  isPublic: boolean;
}

export interface ErrorDetails {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  timestamp: string;
  requestId?: string;
}

export interface LoadingState {
  isLoading: boolean;
  error?: string | null;
  lastUpdated?: string;
}

export interface FormState<T = Record<string, unknown>> {
  data: T;
  errors: Partial<Record<keyof T, string>>;
  isSubmitting: boolean;
  isValid: boolean;
  isDirty: boolean;
  touchedFields: Partial<Record<keyof T, boolean>>;
}

export interface TableColumn<T = Record<string, unknown>> {
  key: keyof T;
  label: string;
  sortable?: boolean;
  filterable?: boolean;
  render?: (_value: unknown, _row: T) => React.ReactNode;
  width?: string;
  align?: 'left' | 'center' | 'right';
}

export interface FilterOption {
  value: string | number | boolean;
  label: string;
  count?: number;
}

export interface ChartDataPoint {
  label: string;
  value: number;
  color?: string;
  metadata?: Record<string, unknown>;
}

export interface ChartData {
  labels: string[];
  datasets: Array<{
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
  }>;
}

export interface ConfirmationModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'default' | 'destructive' | 'warning';
  onConfirm: () => void;
  onCancel: () => void;
}

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
  createdAt: string;
}

// Utility types
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type RequiredKeys<T, K extends keyof T> = T & Required<Pick<T, K>>;
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

// Event types
export interface CustomEvent<T = unknown> {
  type: string;
  payload: T;
  timestamp: string;
  source?: string;
}

// WebSocket types
export interface WebSocketMessage<T = unknown> {
  type: string;
  payload: T;
  timestamp: string;
  id?: string;
}

export interface WebSocketConnection {
  isConnected: boolean;
  isConnecting: boolean;
  error?: string;
  lastHeartbeat?: string;
  reconnectAttempts: number;
}

// File upload types
export interface FileUpload {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  url?: string;
  uploadProgress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
}

// Feature flags
export interface FeatureFlags {
  enableAdvancedSearch: boolean;
  enableRealTimeUpdates: boolean;
  enableVoteDelegation: boolean;
  enableProposalTemplates: boolean;
  enableTreasuryIntegration: boolean;
  enableGovernanceTokens: boolean;
  enableMultiSignature: boolean;
  enableAnalytics: boolean;
  enableNotifications: boolean;
  enableMobileApp: boolean;
}

// App configuration
export interface AppConfig {
  name: string;
  version: string;
  environment: 'development' | 'staging' | 'production';
  apiUrl: string;
  wsUrl: string;
  features: FeatureFlags;
  limits: {
    maxDAOsPerUser: number;
    maxProposalsPerDAO: number;
    maxVotesPerProposal: number;
    maxMembersPerDAO: number;
    maxFileSizeBytes: number;
    maxDescriptionLength: number;
    maxTitleLength: number;
  };
}
