/**
 * Admin role types and permissions system
 */

export type AdminRole = 'super_admin' | 'admin';

export interface AdminPermissions {
  // User management
  canManageUsers: boolean;
  canDeleteUsers: boolean;
  canViewUserData: boolean;
  canExportUserData: boolean;

  // DAO management
  canManageDAOs: boolean;
  canArchiveDAOs: boolean;
  canViewDAOStats: boolean;
  canModerateContent: boolean;

  // System management
  canAccessSystemLogs: boolean;
  canManageAdmins: boolean;
  canRunDataIntegrity: boolean;
  canViewAnalytics: boolean;

  // Content moderation
  canModerateProposals: boolean;
  canModerateComments: boolean;
  canBanUsers: boolean;
}

export interface AdminUser {
  id: string;
  email: string;
  displayName?: string;
  role: AdminRole;
  permissions: AdminPermissions;
  createdAt: string; // ISO 8601
  createdBy: string;
  lastLoginAt?: string; // ISO 8601
  isActive: boolean;
  notes?: string;
}

// Default permissions for each role
export const ADMIN_ROLE_PERMISSIONS: Record<AdminRole, AdminPermissions> = {
  super_admin: {
    canManageUsers: true,
    canDeleteUsers: true,
    canViewUserData: true,
    canExportUserData: true,
    canManageDAOs: true,
    canArchiveDAOs: true,
    canViewDAOStats: true,
    canModerateContent: true,
    canAccessSystemLogs: true,
    canManageAdmins: true,
    canRunDataIntegrity: true,
    canViewAnalytics: true,
    canModerateProposals: true,
    canModerateComments: true,
    canBanUsers: true,
  },
  admin: {
    canManageUsers: true,
    canDeleteUsers: false, // Cannot delete users, only super admin
    canViewUserData: true,
    canExportUserData: true,
    canManageDAOs: true,
    canArchiveDAOs: true,
    canViewDAOStats: true,
    canModerateContent: true,
    canAccessSystemLogs: false,
    canManageAdmins: false, // Cannot manage other admins
    canRunDataIntegrity: true,
    canViewAnalytics: true,
    canModerateProposals: true,
    canModerateComments: true,
    canBanUsers: true,
  },
};

// Helper function to get permissions for a role
export function getPermissionsForRole(role: AdminRole): AdminPermissions {
  return ADMIN_ROLE_PERMISSIONS[role];
}

// Helper function to check if user has specific permission
export function hasPermission(
  adminUser: AdminUser | null,
  permission: keyof AdminPermissions
): boolean {
  if (!adminUser || !adminUser.isActive) {
    return false;
  }

  return adminUser.permissions[permission];
}
