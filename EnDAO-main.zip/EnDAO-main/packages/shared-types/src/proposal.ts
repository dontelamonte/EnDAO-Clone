import { MemberRole } from './dao';

/**
 * Proposal Types for categorization
 * 4-type system with bounty support
 */
export type ProposalType =
  | 'general' // General decisions and community matters
  | 'funding' // Budget allocation, expenses, and funding requests
  | 'governance' // Changes to organization rules, bylaws, or policies
  | 'bounty'; // Task-based rewards with treasury payout on completion

/**
 * Proposal Status throughout its lifecycle
 */
export type ProposalStatus =
  | 'draft'
  | 'under_review' // NEW: 24-hour warm-up period for admin review
  | 'active'
  | 'passed'
  | 'rejected'
  | 'expired'
  | 'executed'
  | 'cancelled'
  | 'deleted'
  | 'archived';

/**
 * Vote Options for different voting systems
 */
export type VoteOption = 'for' | 'against' | 'abstain';

/**
 * Vote Type alias for backward compatibility
 */
export type VoteType = VoteOption;

/**
 * Proposal Priority levels - Simplified to 3 tiers
 */
export type ProposalPriority = 'low' | 'normal' | 'urgent';

/**
 * Proposal Execution Method
 */
export type ProposalExecutionMethod = 'none' | 'general' | 'treasury';

/**
 * Bounty Status for bounty-type proposals
 * Lifecycle: voting → live (accepting applications) → claimed (selected) → submitted → approved/rejected → paid
 */
export type BountyStatus =
  | 'voting' // Bounty proposal is being voted on
  | 'live' // Voting passed, accepting applications
  | 'claimed' // Admin selected an applicant, they're working on it
  | 'submitted' // Claimer submitted work for review
  | 'approved' // Admin approved the submission
  | 'rejected' // Admin rejected the submission (bounty reopens for applications)
  | 'paid' // Treasury payout completed
  | 'cancelled'; // Bounty was cancelled

/**
 * Bounty Application - Simple, universal format
 * Works for any type of bounty (design, dev, writing, etc.)
 */
export interface BountyApplication {
  id: string; // Auto-generated application ID
  userId: string; // Applicant's user ID
  userName?: string; // Display name
  userAvatar?: string; // Profile image URL

  // Simple, universal fields
  message: string; // Why they're a good fit, their approach, etc.
  portfolioUrl?: string; // Optional link to relevant work

  // Timestamps
  appliedAt: string; // ISO 8601

  // Status tracking
  status: 'pending' | 'selected' | 'rejected';
  rejectedReason?: string; // Optional: why admin rejected this application
}

/**
 * Voting system types
 * Currently supported: 'simple', 'ranked'
 * Future systems: 'weighted', 'quadratic'
 */
export type VotingSystem = 'simple' | 'ranked' | 'weighted' | 'quadratic';

/**
 * Proposal voting configuration
 */
export interface ProposalVotingConfig {
  system: VotingSystem;
  allowDelegation: boolean;
  requireMinimumTokens: boolean;
  minimumTokens?: number;
  quorumPercentage: number; // 0-100
  passThreshold: number; // 0-100
  allowChangeVote: boolean;
  hideVotesUntilEnd: boolean;
  enableComments: boolean;
  options?: string[]; // For ranked choice voting
}

/**
 * Proposal option for multi-choice proposals
 */
export interface ProposalOption {
  id: string;
  title: string;
  description?: string;
  voteCount: number;
  votePercentage: number;
  tokenWeight?: number;
  isWinning?: boolean;
}

/**
 * Proposal voting results
 */
export interface ProposalVotingResults {
  totalVotes: number;
  totalTokensVoted?: number;
  totalEligibleVoters: number;
  quorumReached: boolean;
  passed: boolean;

  // Simple voting results
  forVotes?: number;
  againstVotes?: number;
  abstainVotes?: number;

  // Multi-choice results
  options?: ProposalOption[];

  // Ranked choice results (option name -> vote count)
  optionVotes?: Record<string, number>;

  // Weighted voting results
  totalTokenWeight?: number;
  forTokenWeight?: number;
  againstTokenWeight?: number;
  abstainTokenWeight?: number;

  // Participation metrics
  participationRate: number;
  quorumPercentage: number;
  winningPercentage: number;

  // Timestamps
  finalizedAt?: string; // ISO 8601
}

/**
 * Proposal metadata for rich content
 */
export interface ProposalMetadata {
  // Rich content
  content?: string; // Rich text content
  attachments?: string[]; // URLs to attachments
  images?: string[]; // URLs to images
  links?: string[]; // External links
  meetingLink?: string; // Optional meeting link for proposal discussion

  // Formatting
  formatting?: 'markdown' | 'html' | 'plain';

  // Discussion
  allowComments: boolean;
  allowReactions: boolean;

  // Execution details
  executionAddress?: string;

  // Treasury-specific fields (future: Gnosis Safe)
  treasuryAmount?: number;
  treasuryRecipient?: string;
  treasuryReason?: string;
  treasuryCurrency?: string; // 'ETH', 'USDC', etc.
  executionData?: string;
  gasLimit?: number;

  // Membership-specific fields
  targetUserId?: string; // User to add/remove/change role
  targetUserEmail?: string; // Email for new member
  targetRole?: MemberRole; // New role for role change
  membershipAction?: 'add' | 'remove' | 'promote' | 'demote';

  // Settings-specific fields
  settingKey?: string; // Which setting to change
  settingValue?: string | number | boolean | Record<string, unknown>; // New value for the setting
  settingPreviousValue?: string | number | boolean | Record<string, unknown>; // Store previous value for rollback

  // Bounty-specific fields
  bountyReward?: number; // Reward amount in treasury currency
  bountyCurrency?: string; // Currency for reward (ETH, USDC, etc.)
  bountyDeadline?: string; // ISO 8601 - Optional deadline for bounty completion
  bountyRequirements?: string; // Detailed requirements for completion
  bountyDeliverables?: string[]; // List of expected deliverables
  bountySkills?: string[]; // Required skills or tags
  bountyMaxClaimants?: number; // Max concurrent claimants (default: 1)

  // Additional metadata
  customFields?: Record<string, unknown>;
}

/**
 * Proposal discussion thread
 */
export interface ProposalDiscussion {
  id: string;
  proposalId: string;
  userId: string;

  // Content
  content: string;
  formatting?: 'markdown' | 'html' | 'plain';

  // Threading
  parentId?: string; // For replies
  threadDepth: number;

  // Reactions
  reactions: Record<string, string[]>; // emoji -> userIds

  // Moderation
  isHidden: boolean;
  isEdited: boolean;
  editedAt?: string; // ISO 8601
  hiddenBy?: string;
  hiddenReason?: string;

  // Timestamps
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
}

/**
 * Main Proposal interface
 */
export interface Proposal {
  id: string;
  daoId: string;

  // Basic information
  title: string;
  description: string;
  type: ProposalType;
  priority: ProposalPriority;
  status: ProposalStatus;

  // Proposal content and metadata
  metadata: ProposalMetadata;

  // Voting configuration
  votingConfig: ProposalVotingConfig;

  // Voting results
  results: ProposalVotingResults;

  // Timeline
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  startTime: string; // ISO 8601
  endTime: string; // ISO 8601
  executionTime?: string; // ISO 8601

  // Warm-up period fields (NEW)
  submittedAt?: string; // ISO 8601 - When proposal was first submitted
  warmUpEndsAt?: string; // ISO 8601 - When 24-hour warm-up period ends

  // Creator information
  createdBy: string;
  createdByUsername?: string;
  createdByName?: string;
  createdByRole: MemberRole;

  // Approval workflow
  requiresApproval: boolean;
  approvedBy?: string;
  approvedAt?: string; // ISO 8601

  // Execution
  executionMethod: ProposalExecutionMethod;
  isExecutable: boolean;
  executedBy?: string;
  executedAt?: string; // ISO 8601
  executionTxHash?: string;
  executionError?: string; // Store error if execution fails
  executionDetails?: {
    action: string; // What was done
    result: string; // Outcome
    affectedUsers?: string[]; // Users affected by execution
    changes?: Record<string, unknown>; // What changed
  };

  // Discussion
  discussionCount: number;
  lastDiscussionAt?: string; // ISO 8601

  // Visibility and access
  isPublic: boolean;
  allowedRoles: MemberRole[];

  // Features
  isPinned: boolean;
  isFeatured: boolean;

  // Snapshots for historical data
  snapshotBlockNumber?: number;
  snapshotTimestamp?: string; // ISO 8601

  // Tags and categorization
  tags: string[];

  // Version control
  version: string;
  previousVersionId?: string;

  // Deletion tracking (for soft delete)
  deletedAt?: string; // ISO 8601
  deletedBy?: string;

  // Metadata
  customData?: Record<string, unknown>;

  // Gnosis Safe Treasury Transaction fields
  treasuryTransaction?: {
    id?: string;
    safeTxHash?: string;
    recipientAddress?: string;
    amount?: string;
    status?: 'pending' | 'executed' | 'failed';
    executedAt?: Date;
    txHash?: string;
  };

  // Treasury Execution Status (Multi-sig signature tracking)
  executionStatus?: {
    status:
      | 'pending'
      | 'collecting_signatures'
      | 'executing'
      | 'completed'
      | 'failed';
    safeTxHash?: string; // Gnosis Safe transaction hash
    signaturesCollected: number;
    signaturesRequired: number;
    signedBy: string[]; // Array of user IDs who have signed
    pendingSigners: string[]; // Array of user IDs who need to sign
    lastUpdated: string; // ISO 8601
    error?: string; // If status is 'failed'
    completedAt?: string; // ISO 8601 - When status became 'completed'
  };

  // Bounty-specific tracking (for type: 'bounty')
  bounty?: {
    status: BountyStatus;

    // Applications (users apply, admin selects)
    applications?: BountyApplication[];
    applicationCount?: number; // Quick count for display

    // Selected applicant (after admin selection)
    claimedBy?: string; // User ID of selected applicant
    claimedByName?: string; // Display name of selected applicant
    claimedAt?: string; // ISO 8601 - When admin selected them

    // Work submission
    submissionUrl?: string; // Link to work submission (PR, doc, etc.)
    submissionNotes?: string; // Notes from worker
    submittedAt?: string; // ISO 8601

    // Admin review
    reviewedBy?: string; // Admin who approved/rejected
    reviewedAt?: string; // ISO 8601
    reviewNotes?: string; // Admin feedback

    // Payout tracking
    payoutTxHash?: string; // Treasury payout transaction hash
    paidAt?: string; // ISO 8601

    // For future multi-claimant bounties (not used in application mode)
    claims?: Array<{
      userId: string;
      userName?: string;
      claimedAt: string; // ISO 8601
      submissionUrl?: string;
      submissionNotes?: string;
      submittedAt?: string; // ISO 8601
      status: 'claimed' | 'submitted' | 'approved' | 'rejected' | 'paid';
      reviewedBy?: string;
      reviewedAt?: string; // ISO 8601
      reviewNotes?: string;
      payoutTxHash?: string;
      paidAt?: string; // ISO 8601
    }>;
  };
}

/**
 * Vote interface for individual votes
 */
export interface Vote {
  id: string;
  proposalId: string;
  daoId: string;
  userId: string;

  // Vote details
  option: VoteOption | string; // Can be custom option for multi-choice
  optionIndex?: number; // For multi-choice proposals
  rankedOptions?: string[]; // For ranked choice voting

  // Voting power
  tokenWeight?: number;
  votingPower: number;

  // Delegation
  isDelegated: boolean;
  delegatedFrom?: string;
  delegatedTo?: string;

  // Vote metadata
  reason?: string;
  confidence?: number; // 1-10 scale

  // Vote change tracking
  isChanged?: boolean;
  previousOption?: VoteOption | string;
  changeCount?: number;

  // Timestamps
  createdAt: string; // ISO 8601
  updatedAt?: string; // ISO 8601
  votedAt: string; // ISO 8601

  // Verification
  signature?: string;
  blockNumber?: number;
  txHash?: string;

  // Privacy
  isPrivate: boolean;

  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * Vote delegation interface
 */
export interface VoteDelegation {
  id: string;
  daoId: string;
  delegatorId: string;
  delegateeId: string;

  // Delegation scope
  proposalIds?: string[]; // If empty, applies to all proposals
  proposalTypes?: ProposalType[];

  // Delegation power
  tokenAmount?: number;
  percentage?: number; // 0-100

  // Status
  isActive: boolean;

  // Timestamps
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  expiresAt?: string; // ISO 8601

  // Metadata
  reason?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Proposal template for common proposal types
 */
export interface ProposalTemplate {
  id: string;
  daoId: string;
  name: string;
  description: string;
  type: ProposalType;

  // Template structure
  titleTemplate: string;
  descriptionTemplate: string;
  fields: Array<{
    name: string;
    type: 'text' | 'number' | 'date' | 'select' | 'multiselect' | 'textarea';
    label: string;
    placeholder?: string;
    required: boolean;
    options?: string[];
    validation?: string;
  }>;

  // Default voting config
  defaultVotingConfig: Partial<ProposalVotingConfig>;

  // Usage
  usageCount: number;
  isPublic: boolean;

  // Timestamps
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  createdBy: string;
}

/**
 * Proposal creation form data
 */
export interface CreateProposalFormData {
  title: string;
  description: string;
  type: ProposalType;
  priority: ProposalPriority;

  // Funding (for treasury proposals)
  fundingAmount?: number;
  fundingCurrency?: string; // ETH, USDC, etc.
  fundingRecipient?: string; // Wallet address

  // Bounty (for bounty proposals)
  bountyReward?: number; // Reward amount
  bountyCurrency?: string; // ETH, USDC, etc.
  bountyDeadline?: Date; // Optional deadline
  bountyRequirements?: string; // Detailed requirements
  bountyDeliverables?: string[]; // Expected deliverables
  bountySkills?: string[]; // Required skills/tags

  // Cost and Timeline
  estimatedCost?: number;
  estimatedCostCurrency?: string; // USD, EUR, etc.
  proposedTimeline?: string; // e.g., "2 weeks", "3 months"
  completionDate?: Date;

  // Voting configuration
  votingSystem: VotingSystem;
  votingDuration: number; // in days
  quorumPercentage: number;
  passThreshold: number;
  allowChangeVote?: boolean;
  hideVotesUntilEnd?: boolean;
  enableContinuousVoting?: boolean;
  allowDelegation?: boolean;
  requireMinimumTokens?: boolean;
  minimumTokens?: number;

  // Options for multi-choice proposals
  options?: string[];

  // Execution
  executionMethod: ProposalExecutionMethod;

  // Metadata
  content?: string;
  attachments?: string[];
  tags?: string[];
  metadata?: Partial<ProposalMetadata>;

  // Scheduling
  startTime?: Date;

  // Execution
  executionAddress?: string;
  executionData?: string;

  // Visibility
  isPublic: boolean;
  allowedRoles: MemberRole[];
}

/**
 * Proposal update form data
 */
export interface UpdateProposalFormData extends Partial<CreateProposalFormData> {
  id: string;
}

/**
 * Proposal search filters
 */
export interface ProposalSearchFilters {
  query?: string;
  type?: ProposalType;
  status?: ProposalStatus;
  priority?: ProposalPriority;
  createdBy?: string;
  tags?: string[];
  startDate?: Date;
  endDate?: Date;
  hasVoted?: boolean;
  isPinned?: boolean;
  isActive?: boolean;
  sortBy?: 'title' | 'createdAt' | 'endTime' | 'voteCount' | 'priority';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

/**
 * Proposal list response
 */
export interface ProposalListResponse {
  proposals: Proposal[];
  total: number;
  hasMore: boolean;
  nextOffset?: number;
}

/**
 * Vote list response
 */
export interface VoteListResponse {
  votes: Vote[];
  total: number;
  hasMore: boolean;
  nextOffset?: number;
}

/**
 * Proposal statistics
 */
export interface ProposalStats {
  totalProposals: number;
  activeProposals: number;
  passedProposals: number;
  rejectedProposals: number;
  executedProposals: number;
  totalVotes: number;
  averageParticipation: number;
  averageQuorum: number;
  proposalsByType: Record<ProposalType, number>;
  proposalsByStatus: Record<ProposalStatus, number>;
  topVoters: Array<{
    userId: string;
    voteCount: number;
    participationRate: number;
  }>;
}

/**
 * Proposal Draft interface for save/resume functionality
 * Wave 2 Feature: Draft Auto-Save
 */
export interface ProposalDraft {
  id: string; // Auto-generated draft ID
  daoId: string;
  userId: string;

  // Draft metadata
  title?: string;
  lastSaved: string; // ISO 8601
  createdAt: string; // ISO 8601

  // Full form data snapshot
  formData: Partial<CreateProposalFormData>;

  // Options for ranked voting
  options?: string[];

  // Draft version for conflict resolution
  version: number;

  // Device tracking for multi-device scenarios
  deviceId?: string;
  lastSyncedAt?: string; // ISO 8601

  // Metadata
  autoSaved: boolean; // Was this auto-saved or manually saved?
  daoName?: string; // For display in draft list
}
