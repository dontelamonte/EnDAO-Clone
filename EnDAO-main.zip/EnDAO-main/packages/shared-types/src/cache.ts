/**
 * Type definitions for cache middleware and caching systems
 */

import type { NextRequest } from 'next/server';
import type { AuthContext } from '@/lib/auth/get-auth-context';

/**
 * Cache entry with metadata
 */
export interface CacheEntry<T = unknown> {
  data: T;
  timestamp: number;
  ttl: number;
  key: string;
  tags?: string[];
  metadata?: Record<string, unknown>;
}

/**
 * Cache statistics
 */
export interface CacheStats {
  hits: number;
  misses: number;
  hitRate: number;
  totalRequests: number;
  size: number;
  maxSize: number;
  evictions: number;
  averageResponseTime: number;
  lastAccess: number;
}

/**
 * Cache configuration
 */
export interface CacheConfig {
  ttl: number;
  maxSize: number;
  enableMetrics: boolean;
  enableCompression: boolean;
  keyPrefix?: string;
  tags?: string[];
}

/**
 * Cache invalidation options
 */
export interface CacheInvalidationOptions {
  user?: boolean;
  dao?: string;
  userDao?: {
    uid: string;
    daoId: string;
  };
  tags?: string[];
  pattern?: string;
}

/**
 * Request-level cache interface
 */
export interface RequestCache {
  get<T>(key: string): T | null;
  set<T>(key: string, value: T): void;
  has(key: string): boolean;
  clear(): void;
  getStats(): {
    size: number;
    duration: number;
    hitRate: number;
    totalRequests: number;
  };
}

/**
 * Cache middleware options
 */
export interface CacheMiddlewareOptions {
  enableRequestCache?: boolean;
  autoInvalidate?: CacheInvalidationOptions;
  warmupAfterRequest?: string[];
  ttl?: number;
  maxSize?: number;
  tags?: string[];
}

/**
 * Permission cache entry
 */
export interface PermissionCacheEntry {
  userId: string;
  permission: string;
  hasPermission: boolean;
  timestamp: number;
  ttl: number;
  context?: Record<string, unknown>;
}

/**
 * Role cache entry
 */
export interface RoleCacheEntry {
  userId: string;
  daoId?: string;
  role: string;
  timestamp: number;
  ttl: number;
  systemRole?: boolean;
}

/**
 * Cache health status
 */
export interface CacheHealthStatus {
  status: 'healthy' | 'degraded' | 'error';
  hitRate: number;
  totalRequests: number;
  cacheSize: number;
  breakdown: {
    systemRoles: {
      hitRate: number;
      size: number;
    };
    daoRoles: {
      hitRate: number;
      size: number;
    };
    permissions: {
      hitRate: number;
      size: number;
    };
  };
  warnings?: string[];
  errors?: string[];
}

/**
 * Cache metrics by category
 */
export interface CacheMetricsByCategory {
  overall: CacheStats;
  systemRoles: CacheStats;
  daoRoles: CacheStats;
  permissions: CacheStats;
  requestLevel: CacheStats;
}

/**
 * Cache operation result
 */
export interface CacheOperationResult<T = unknown> {
  success: boolean;
  data?: T;
  fromCache: boolean;
  cacheKey: string;
  responseTime: number;
  error?: string;
}

/**
 * Cache warming configuration
 */
export interface CacheWarmupConfig {
  userIds: string[];
  daoIds?: string[];
  permissions?: string[];
  batchSize?: number;
  delay?: number;
  priority?: 'low' | 'normal' | 'high';
}

/**
 * Cache eviction policy
 */
export type CacheEvictionPolicy =
  | 'lru' // Least Recently Used
  | 'lfu' // Least Frequently Used
  | 'fifo' // First In, First Out
  | 'ttl' // Time To Live based
  | 'size'; // Size based

/**
 * Cache storage backend
 */
export interface CacheStorage<T = unknown> {
  get(key: string): Promise<CacheEntry<T> | null>;
  set(key: string, entry: CacheEntry<T>): Promise<boolean>;
  delete(key: string): Promise<boolean>;
  clear(): Promise<boolean>;
  keys(pattern?: string): Promise<string[]>;
  size(): Promise<number>;
  cleanup(): Promise<number>; // Returns number of entries removed
}

/**
 * Batch cache operation
 */
export interface BatchCacheOperation<T = unknown> {
  type: 'get' | 'set' | 'delete';
  key: string;
  value?: T;
  ttl?: number;
}

/**
 * Batch cache result
 */
export interface BatchCacheResult<T = unknown> {
  success: boolean;
  results: Array<{
    key: string;
    success: boolean;
    data?: T;
    error?: string;
  }>;
  totalOperations: number;
  successfulOperations: number;
  responseTime: number;
}

/**
 * Cache compression options
 */
export interface CacheCompressionOptions {
  algorithm: 'gzip' | 'deflate' | 'brotli';
  level: number; // Compression level
  threshold: number; // Minimum size to compress (bytes)
}

/**
 * Cache monitoring event
 */
export interface CacheMonitoringEvent {
  type: 'hit' | 'miss' | 'set' | 'delete' | 'evict' | 'expire';
  key: string;
  timestamp: number;
  responseTime?: number;
  size?: number;
  ttl?: number;
  metadata?: Record<string, unknown>;
}

/**
 * Cache key generator function
 */
export type CacheKeyGenerator = (
  context: AuthContext,
  ...params: unknown[]
) => string;

/**
 * Permission check function with caching
 */
export type CachedPermissionCheck = (
  authContext: AuthContext
) => Promise<boolean>;

/**
 * Cache strategy configuration
 */
export interface CacheStrategy {
  policy: CacheEvictionPolicy;
  ttl: number;
  maxSize: number;
  warmup?: CacheWarmupConfig;
  compression?: CacheCompressionOptions;
  monitoring?: {
    enableMetrics: boolean;
    enableEvents: boolean;
    sampleRate: number;
  };
}

/**
 * Type guard for cache entry
 */
export function isCacheEntry<T>(value: unknown): value is CacheEntry<T> {
  if (typeof value !== 'object' || value === null) return false;

  const v = value as Record<string, unknown>;
  return (
    'data' in v &&
    'timestamp' in v &&
    'ttl' in v &&
    'key' in v &&
    typeof v.timestamp === 'number' &&
    typeof v.ttl === 'number' &&
    typeof v.key === 'string'
  );
}

/**
 * Type guard for cache stats
 */
export function isCacheStats(value: unknown): value is CacheStats {
  if (typeof value !== 'object' || value === null) return false;

  const v = value as Record<string, unknown>;
  return (
    'hits' in v &&
    'misses' in v &&
    'hitRate' in v &&
    'totalRequests' in v &&
    typeof v.hits === 'number' &&
    typeof v.misses === 'number' &&
    typeof v.hitRate === 'number' &&
    typeof v.totalRequests === 'number'
  );
}

/**
 * Type guard for request cache
 */
export function isRequestCache(value: unknown): value is RequestCache {
  if (typeof value !== 'object' || value === null) return false;

  const v = value as Record<string, unknown>;
  return (
    'get' in v &&
    'set' in v &&
    'has' in v &&
    'clear' in v &&
    typeof v.get === 'function' &&
    typeof v.set === 'function' &&
    typeof v.has === 'function' &&
    typeof v.clear === 'function'
  );
}
