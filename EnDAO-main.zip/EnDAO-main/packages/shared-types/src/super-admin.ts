import { DAO, DAOMember, MemberRole } from './dao';
import { UserProfile, UserSummary } from './user';

/**
 * Super Admin specific types for cross-DAO member management
 */

export interface SuperAdminPermissions {
  canManageAllDAOs: boolean;
  canManageAllUsers: boolean;
  canManageSystemSettings: boolean;
  canViewSystemAnalytics: boolean;
  canPerformDataIntegrityOperations: boolean;
  canExportSystemData: boolean;
}

export interface MemberSearchFilters {
  role?: MemberRole | 'no-dao-memberships';
  daoIds?: string[];
  joinedAfter?: Date;
  joinedBefore?: Date;
  isActive?: boolean;
  hasPermissions?: string[];
}

export interface GlobalMemberSearchResult {
  user: UserProfile;
  memberships: Array<{
    dao: DAO;
    membership: DAOMember;
  }>;
  totalDAOs: number;
  totalAdminRoles: number;
}

export interface BulkMemberOperation {
  type: 'add' | 'remove' | 'promote' | 'demote' | 'transfer';
  daoId: string;
  userId: string;
  targetRole?: MemberRole;
  reason?: string;
}

export interface BulkOperationResult {
  operation: BulkMemberOperation;
  success: boolean;
  error?: string;
}

export interface CrossDAOMemberStats {
  totalMembers: number;
  totalActiveMembers: number;
  totalAdmins: number;
  averageMembersPerDAO: number;
  topActiveDAOs: Array<{
    dao: DAO;
    memberCount: number;
    adminCount: number;
  }>;
  memberDistribution: Record<MemberRole, number>;
}

export interface MemberManagementAction {
  id: string;
  type: 'add' | 'remove' | 'promote' | 'demote' | 'transfer';
  daoId: string;
  daoName: string;
  userId: string;
  userName: string;
  userEmail: string;
  currentRole?: MemberRole;
  targetRole?: MemberRole;
  reason?: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  error?: string;
  createdAt: Date;
  completedAt?: Date;
}

export interface SuperAdminMemberFilters {
  searchQuery: string;
  selectedDAOs: string[];
  selectedRoles: MemberRole[];
  joinedDateRange: {
    start?: Date;
    end?: Date;
  };
  isActive?: boolean;
  sortBy: 'userName' | 'joinedAt' | 'daoCount' | 'adminRoles';
  sortOrder: 'asc' | 'desc';
}

export interface MemberActionRequest {
  type: 'add' | 'remove' | 'promote' | 'demote';
  daoId: string;
  userId: string;
  targetRole?: MemberRole;
  reason?: string;
}

export interface SuperAdminDashboardStats {
  systemHealth: {
    totalDAOs: number;
    activeDAOs: number;
    totalUsers: number;
    activeUsers: number;
    totalMemberships: number;
    systemErrors: number;
  };
  memberStats: CrossDAOMemberStats;
  recentActivity: Array<{
    id: string;
    type: string;
    description: string;
    timestamp: Date;
    adminId: string;
    adminName: string;
  }>;
  alerts: Array<{
    id: string;
    type: 'warning' | 'error' | 'info';
    title: string;
    description: string;
    timestamp: Date;
    isRead: boolean;
  }>;
}

export interface DAOMemberManagementView {
  dao: DAO;
  members: Array<{
    user: UserProfile;
    membership: DAOMember;
    canPromote: boolean;
    canDemote: boolean;
    canRemove: boolean;
  }>;
  totalMembers: number;
  adminCount: number;
  memberCount: number;
  pendingInvites: number;
}

export interface GlobalMemberSearchOptions {
  query: string;
  filters: MemberSearchFilters;
  pagination: {
    limit: number;
    offset: number;
  };
  sortBy: 'relevance' | 'name' | 'joinedAt' | 'daoCount';
  sortOrder: 'asc' | 'desc';
}

export interface SuperAdminActivity {
  id: string;
  type:
    | 'member_added'
    | 'member_removed'
    | 'role_changed'
    | 'bulk_operation'
    | 'dao_archived'
    | 'system_action';
  adminId: string;
  adminName: string;
  targetUserId?: string;
  targetUserName?: string;
  daoId?: string;
  daoName?: string;
  description: string;
  metadata: Record<string, unknown>;
  timestamp: Date;
  impact: 'low' | 'medium' | 'high';
}

export interface MemberConsistencyIssue {
  id: string;
  type:
    | 'duplicate_membership'
    | 'invalid_role'
    | 'orphaned_member'
    | 'permission_mismatch';
  severity: 'critical' | 'warning' | 'info';
  daoId: string;
  daoName: string;
  userId: string;
  userName: string;
  userEmail: string;
  description: string;
  detectedAt: Date;
  resolvedAt?: Date;
  resolution?: string;
  autoResolvable: boolean;
}

export interface SuperAdminNotification {
  id: string;
  type:
    | 'member_issue'
    | 'dao_issue'
    | 'system_alert'
    | 'bulk_operation_complete';
  title: string;
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: Date;
  isRead: boolean;
  actionRequired: boolean;
  actionUrl?: string;
  metadata: Record<string, unknown>;
}

export interface CrossDAOUserProfile {
  user: UserProfile;
  memberships: Array<{
    dao: DAO;
    membership: DAOMember;
    joinedAt: Date;
    role: MemberRole;
    isActive: boolean;
    permissions: string[];
  }>;
  stats: {
    totalDAOs: number;
    adminRoles: number;
    memberRoles: number;
    totalActivities: number;
    lastActiveAt: Date;
  };
  flags: {
    hasIssues: boolean;
    isHighActivity: boolean;
    hasMultipleAdminRoles: boolean;
    hasInactiveRoles: boolean;
  };
}
