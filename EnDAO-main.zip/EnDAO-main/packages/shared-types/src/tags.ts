/**
 * Unified Tag System for EnDAO
 *
 * 34 tags across 5 categories, max 10 per DAO
 * Used in: wizard, admin settings, discover filters
 */

// Tag categories with their available tags
export const DAO_TAG_CATEGORIES = {
  purpose: [
    'Mission-Driven',
    'For-Profit',
    'Member-Owned',
    'Community-Led',
    'Volunteer-Run',
  ],
  sector: [
    'Technology',
    'Healthcare',
    'Education',
    'Finance',
    'Real Estate',
    'Legal',
    'Creative Arts',
    'Agriculture',
    'Manufacturing',
    'Retail',
  ],
  activity: [
    'Investing',
    'Advocacy',
    'Networking',
    'Events',
    'Services',
    'Research',
    'Grants',
    'Fundraising',
  ],
  communityType: [
    'Professional',
    'Neighborhood',
    'Alumni',
    'Faith-Based',
    'Cultural',
    'Academic',
  ],
  scale: ['Local', 'Regional', 'National', 'International', 'Startup'],
} as const;

// Human-readable category labels for UI
export const TAG_CATEGORY_LABELS: Record<
  keyof typeof DAO_TAG_CATEGORIES,
  string
> = {
  purpose: 'Purpose',
  sector: 'Sector',
  activity: 'Activity',
  communityType: 'Community Type',
  scale: 'Scale',
};

// Flatten all tags into a single array (34 total)
export const ALL_DAO_TAGS = Object.values(DAO_TAG_CATEGORIES).flat();

// Type for a valid DAO tag
export type DAOTag = (typeof ALL_DAO_TAGS)[number];

// Maximum tags allowed per DAO
export const MAX_TAGS_PER_DAO = 10;

// Popular tags shown prominently in UI (12 tags from various categories)
export const POPULAR_TAGS: readonly DAOTag[] = [
  'Mission-Driven',
  'For-Profit',
  'Member-Owned',
  'Community-Led',
  'Technology',
  'Healthcare',
  'Education',
  'Finance',
  'Local',
  'Professional',
  'Networking',
  'Events',
] as const;

// Type guard to check if a string is a valid tag
export function isValidDAOTag(tag: string): tag is DAOTag {
  return ALL_DAO_TAGS.includes(tag as DAOTag);
}

// Get category for a given tag
export function getTagCategory(
  tag: DAOTag
): keyof typeof DAO_TAG_CATEGORIES | null {
  for (const [category, tags] of Object.entries(DAO_TAG_CATEGORIES)) {
    if ((tags as readonly string[]).includes(tag)) {
      return category as keyof typeof DAO_TAG_CATEGORIES;
    }
  }
  return null;
}

// Validate tags array (returns valid tags only, up to max)
export function validateTags(tags: string[]): DAOTag[] {
  return tags.filter(isValidDAOTag).slice(0, MAX_TAGS_PER_DAO);
}
