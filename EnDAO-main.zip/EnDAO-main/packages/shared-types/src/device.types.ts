/**
 * Mobile Device Types
 *
 * Types for push notification device registration and mobile notification preferences.
 */

// ============================================================================
// Device Types
// ============================================================================

export type DevicePlatform = 'ios' | 'android';

export interface UserDevice {
  id: string;
  userId: string;
  pushToken: string;
  platform: DevicePlatform;
  deviceName: string | null;
  appVersion: string | null;
  isActive: boolean;
  lastUsedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface RegisterDeviceInput {
  pushToken: string;
  platform: DevicePlatform;
  deviceName?: string;
  appVersion?: string;
}

export interface UserDeviceRow {
  id: string;
  user_id: string;
  push_token: string;
  platform: string;
  device_name: string | null;
  app_version: string | null;
  is_active: boolean;
  last_used_at: string | null;
  created_at: string;
  updated_at: string;
}

// ============================================================================
// Mobile Notification Preferences Types
// ============================================================================

export interface MobileNotificationPrefs {
  id: string;
  userId: string;
  enabled: boolean;
  proposalCreated: boolean;
  voteReminders: boolean;
  votingEnded: boolean;
  membershipUpdates: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface MobileNotificationPrefsInput {
  enabled?: boolean;
  proposalCreated?: boolean;
  voteReminders?: boolean;
  votingEnded?: boolean;
  membershipUpdates?: boolean;
}

export interface MobileNotificationPrefsRow {
  id: string;
  user_id: string;
  enabled: boolean;
  proposal_created: boolean;
  vote_reminders: boolean;
  voting_ended: boolean;
  membership_updates: boolean;
  created_at: string;
  updated_at: string;
}

// ============================================================================
// Mappers
// ============================================================================

export function mapUserDeviceRow(row: UserDeviceRow): UserDevice {
  return {
    id: row.id,
    userId: row.user_id,
    pushToken: row.push_token,
    platform: row.platform as DevicePlatform,
    deviceName: row.device_name,
    appVersion: row.app_version,
    isActive: row.is_active,
    lastUsedAt: row.last_used_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function mapMobileNotificationPrefsRow(
  row: MobileNotificationPrefsRow
): MobileNotificationPrefs {
  return {
    id: row.id,
    userId: row.user_id,
    enabled: row.enabled,
    proposalCreated: row.proposal_created,
    voteReminders: row.vote_reminders,
    votingEnded: row.voting_ended,
    membershipUpdates: row.membership_updates,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

// ============================================================================
// Default Preferences
// ============================================================================

export const DEFAULT_MOBILE_NOTIFICATION_PREFS: Omit<
  MobileNotificationPrefs,
  'id' | 'userId' | 'createdAt' | 'updatedAt'
> = {
  enabled: true,
  proposalCreated: true,
  voteReminders: true,
  votingEnded: true,
  membershipUpdates: true,
};
