/**
 * Core user profile stored in Supabase users table
 * This is the single source of truth for user data
 */
export interface UserProfile extends Record<string, unknown> {
  id: string; // Internal UID (for compatibility)
  privyUserId?: string; // Privy user ID - primary identifier
  email: string;
  displayName: string;

  // Username (permanent, cannot be changed)
  username?: string;
  usernameSetAt?: string; // ISO 8601

  // Profile information
  firstName?: string;
  lastName?: string;
  bio?: string;
  avatarUrl?: string;
  pronouns?: string;
  location?: string;
  skills?: string[];

  // Contact & Social
  website?: string;
  twitter?: string;
  linkedin?: string;
  github?: string;
  discord?: string;
  instagram?: string;
  facebook?: string;
  tiktok?: string;

  // Preferences
  timezone?: string;
  language?: string;
  emailNotifications?: boolean;
  pushNotifications?: boolean;

  // Metadata
  createdAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
  lastLoginAt?: string; // ISO 8601
  isActive: boolean;

  // Privacy settings
  profileVisibility: 'public' | 'dao-members' | 'private';
  showEmail: boolean;
  showSocials: boolean;

  // Privy wallet integration
  wallets?: string[]; // Array of wallet addresses
  primaryWallet?: string; // Main wallet address

  // New fields for intelligent routing
  profileSetupComplete?: boolean;
  profileCompletionScore?: number;
}

/**
 * Extended user profile with computed fields and aggregated data
 */
export interface EnhancedUserProfile extends UserProfile {
  // DAO participation
  daoCount: number;
  ownedDAOsCount: number;
  totalProposalsCreated: number;
  totalVotesSubmitted: number;

  // Reputation metrics
  reputationScore: number;
  participationRate: number;

  // Recent activity
  lastActivityAt?: string; // ISO 8601
  recentDAOs: Array<{
    id: string;
    name: string;
    role: string;
  }>;
}

/**
 * User profile creation/update payload
 */
export interface UserProfileInput {
  displayName: string;
  username?: string; // Can be changed (releases old username)
  firstName?: string;
  lastName?: string;
  bio?: string;
  avatarUrl?: string;
  pronouns?: string;
  location?: string;
  skills?: string[];
  website?: string;
  twitter?: string;
  linkedin?: string;
  github?: string;
  discord?: string;
  instagram?: string;
  facebook?: string;
  tiktok?: string;
  timezone?: string;
  language?: string;
  emailNotifications?: boolean;
  pushNotifications?: boolean;
  profileVisibility?: 'public' | 'dao-members' | 'private';
  showEmail?: boolean;
  showSocials?: boolean;
  profileSetupComplete?: boolean;
  profileCompletionScore?: number;
}

/**
 * User lookup result with minimal profile data for lists/dropdowns
 */
export interface UserSummary {
  id: string;
  username?: string;
  displayName: string;
  email: string;
  avatarUrl?: string;
  isActive: boolean;
}

/**
 * Bulk user lookup response
 */
export interface UserLookupResponse {
  users: Record<string, UserSummary>;
  notFound: string[];
}

/**
 * User Preferences
 */
export interface UserPreferences {
  // Notifications
  emailNotifications: boolean;
  pushNotifications: boolean;
  notificationSettings: NotificationSettings;

  // Privacy
  profileVisibility: 'public' | 'dao-members' | 'private';
  showEmail: boolean;
  showSocials: boolean;
  privacySettings: PrivacySettings;

  // UI/Display
  language: string;
  timezone: string;
  uiSettings: UISettings;
}

/**
 * Notification Settings
 */
export interface NotificationSettings {
  proposalCreated: boolean;
  proposalStatusChanged: boolean;
  votingStarted: boolean;
  votingEnded: boolean;
  membershipApproved: boolean;
  membershipRejected: boolean;
  daoUpdates: boolean;
  weeklyDigest: boolean;
  securityAlerts: boolean;
}

/**
 * Privacy Settings
 */
export interface PrivacySettings {
  showProfile: boolean;
  showActivity: boolean;
  showVotingHistory: boolean;
  allowDirectMessages: boolean;
  showOnlineStatus: boolean;
}

/**
 * UI Settings
 */
export interface UISettings {
  theme: 'light' | 'dark' | 'system';
  compactMode: boolean;
  showTooltips: boolean;
  enableAnimations: boolean;
  dateFormat: 'relative' | 'absolute';
  numberFormat: 'standard' | 'compact';
}


/**
 * User Activity Types
 */
export type ActivityType =
  | 'login'
  | 'logout'
  | 'profile_update'
  | 'profile_view'
  | 'dao_join'
  | 'dao_leave'
  | 'dao_view'
  | 'proposal_create'
  | 'proposal_view'
  | 'proposal_vote'
  | 'proposal_comment'
  | 'member_invite'
  | 'member_view'
  | 'role_change'
  | 'settings_update'
  | 'wallet_connect'
  | 'wallet_disconnect'
  | 'treasury_view'
  | 'treasury_transaction';

/**
 * User Activity Record
 */
export interface UserActivity {
  id: string;
  userId: string;
  type: ActivityType;
  timestamp: string; // ISO 8601
  daoId?: string;
  proposalId?: string;
  targetUserId?: string;
  details: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string; // ISO 8601
}

/**
 * User Activity Summary
 */
export interface UserActivitySummary {
  totalActivities: number;
  activityByType: Record<string, number>;
  activityByDAO: Record<string, number>;
  mostActiveDay: string;
  averageActivitiesPerDay: number;
  lastActivity: Date | null;
  timespan: {
    days: number;
    startDate: Date;
    endDate: Date;
  };
}
