/**
 * Type definitions for audit logging system
 */

/**
 * Audit log entry
 */
export interface AuditLogEntry {
  id: string;
  timestamp: number;
  userId?: string;
  sessionId?: string;
  eventType: string;
  eventCategory: 'success' | 'failure' | 'info' | 'warning' | 'error';
  resourceId?: string;
  resourceType?: string;
  details: AuditLogDetails;
  beforeState?: Record<string, unknown>;
  afterState?: Record<string, unknown>;
  correlationId?: string;
  ipAddress?: string;
  userAgent?: string;
}

/**
 * Audit log details with flexible structure
 */
export interface AuditLogDetails {
  action?: string;
  result?: string;
  error?: string;
  metadata?: Record<string, unknown>;
  changes?: Record<string, unknown>;
  affectedUsers?: string[];
  executorUserId?: string;
  type?: string;
  status?: string;
  [key: string]: unknown;
}

/**
 * Audit log query parameters
 */
export interface AuditLogQuery {
  resourceId?: string;
  userId?: string;
  eventTypes?: string[];
  eventCategories?: Array<'success' | 'failure' | 'info' | 'warning' | 'error'>;
  startDate?: number;
  endDate?: number;
  limit?: number;
  offset?: number;
  sortBy?: 'timestamp' | 'eventType' | 'userId';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Audit log search result
 */
export interface AuditLogSearchResult {
  entries: AuditLogEntry[];
  total: number;
  hasMore: boolean;
  query: AuditLogQuery;
}

/**
 * Proposal execution audit details
 */
export interface ProposalExecutionAuditDetails extends AuditLogDetails {
  proposalId: string;
  proposalType: string;
  proposalTitle?: string;
  executorUserId: string;
  executionStatus: 'scheduled' | 'in_progress' | 'completed' | 'failed';
  executionResult?: {
    success: boolean;
    message: string;
    details?: Record<string, unknown>;
  };
}

/**
 * Type guard for audit log entry
 */
export function isAuditLogEntry(entry: unknown): entry is AuditLogEntry {
  if (typeof entry !== 'object' || entry === null) return false;

  const e = entry as Record<string, unknown>;
  return (
    'id' in e &&
    'timestamp' in e &&
    'eventType' in e &&
    'eventCategory' in e &&
    'details' in e &&
    typeof e.id === 'string' &&
    typeof e.timestamp === 'number' &&
    typeof e.eventType === 'string' &&
    ['success', 'failure', 'info', 'warning', 'error'].includes(
      e.eventCategory as string
    )
  );
}

/**
 * Type guard for audit log search result
 */
export function isAuditLogSearchResult(
  result: unknown
): result is AuditLogSearchResult {
  if (typeof result !== 'object' || result === null) return false;

  const r = result as Record<string, unknown>;
  return (
    'entries' in r &&
    'total' in r &&
    'hasMore' in r &&
    Array.isArray(r.entries) &&
    typeof r.total === 'number' &&
    typeof r.hasMore === 'boolean'
  );
}
