/**
 * Treasury types for hybrid treasury functionality
 * Supports both fiat (Stripe Connect) and crypto (Gnosis Safe) rails
 */

// ============================================================================
// Treasury Rail Types
// ============================================================================

/**
 * Status of a treasury rail (fiat or crypto)
 */
export type TreasuryRailStatus = 'inactive' | 'active' | 'pending';

/**
 * Treasury configuration for a DAO
 */
export interface TreasuryRailsStatus {
  hybridEnabled: boolean;
  fiat: {
    status: TreasuryRailStatus;
    stripeAccountId?: string;
    stripeStatus?: 'not_started' | 'pending' | 'active' | 'restricted';
  };
  crypto: {
    status: TreasuryRailStatus;
    safeAddress?: string;
    chainId?: number;
  };
}

/**
 * Unified balance across both treasury rails
 */
export interface UnifiedTreasuryBalance {
  totalUsdValue: number;
  lastUpdated: string; // ISO 8601

  fiatBalance: {
    available: number;
    pending: number;
    currency: string;
    stripeAccountId?: string;
  } | null;

  cryptoBalance: {
    totalUsdValue: number;
    safeAddress: string;
    chainId: number;
    assets: CryptoAsset[];
  } | null;
}

export interface CryptoAsset {
  symbol: string;
  name: string;
  balance: string; // Wei/smallest unit as string
  decimals: number;
  usdValue: number;
  contractAddress?: string; // null for native token
}

// ============================================================================
// Conversion Types (On-ramp / Off-ramp)
// ============================================================================

/**
 * Direction of treasury conversion
 */
export type ConversionDirection = 'fiat_to_crypto' | 'crypto_to_fiat';

/**
 * Status of a treasury conversion
 */
export type ConversionStatus =
  | 'pending'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'refunded';

/**
 * Treasury conversion record
 */
export interface TreasuryConversion {
  id: string;
  daoId: string;
  direction: ConversionDirection;

  // Source
  sourceAmount: number;
  sourceCurrency: string;

  // Target
  targetAmount?: number;
  targetCurrency: string;

  // Provider
  provider: string;
  providerTransactionId?: string;

  status: ConversionStatus;

  // On-ramp specific
  stripePaymentIntentId?: string;
  destinationAddress?: string;
  destinationChainId?: number;
  txHash?: string;

  // Off-ramp specific
  sourceTxHash?: string;
  sourceAddress?: string;
  bankPayoutId?: string;

  // Fees
  conversionRate?: number;
  providerFeeAmount?: number;
  platformFeeAmount?: number;
  networkFeeAmount?: number;

  // Audit
  initiatedBy?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

// ============================================================================
// Off-ramp Request Types (Multi-sig approval)
// ============================================================================

/**
 * Status of an off-ramp request
 */
export type OfframpRequestStatus =
  | 'pending_signatures'
  | 'approved'
  | 'executing'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled';

/**
 * Off-ramp request requiring multi-sig approval
 */
export interface OfframpRequest {
  id: string;
  daoId: string;

  // Amount
  amountCrypto: number;
  cryptoCurrency: string;
  chainId: number;

  // Source
  sourceAddress: string;
  safeTxHash?: string;

  // Multi-sig
  signaturesRequired: number;
  signaturesCollected: OfframpSignature[];

  status: OfframpRequestStatus;

  // KYC
  kycVerified: boolean;
  offrampProvider?: string;
  providerTransactionId?: string;

  // Amounts
  estimatedFiatAmount?: number;
  actualFiatAmount?: number;
  feeAmount?: number;

  // Audit
  requestedBy?: string;
  approvedAt?: string;
  executedAt?: string;
  completedAt?: string;
  failureReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface OfframpSignature {
  signer: string;
  signature: string;
  signedAt: string;
}

/**
 * Input for creating an off-ramp request
 */
export interface CreateOfframpRequestInput {
  daoId: string;
  amountCrypto: number;
  cryptoCurrency: string;
  chainId: number;
  sourceAddress: string;
  safeTxHash?: string;
  signaturesRequired: number;
  requestedBy?: string;
  estimatedFiatAmount?: number;
  offrampProvider?: string;
}

// ============================================================================
// Payout Types
// ============================================================================

/**
 * Preferred payout method for a user
 */
export type PayoutMethod = 'crypto_wallet' | 'bank_offramp';

/**
 * Preferred cryptocurrency for payouts
 */
export type PayoutCryptoCurrency = 'USDC' | 'ETH' | 'DAI' | 'USDT';

/**
 * Off-ramp KYC status (tracked locally, KYC handled by provider)
 */
export type OfframpKYCStatus = 'none' | 'pending' | 'verified' | 'rejected';

/**
 * User payout preferences
 */
export interface UserPayoutPreferences {
  id: string;
  userId: string;

  // Payout method
  preferredMethod: PayoutMethod;

  // Crypto settings
  walletAddress?: string; // Custom wallet (null = use Privy wallet)
  preferredCryptoCurrency: PayoutCryptoCurrency;

  // Off-ramp settings
  offrampProvider?: string;
  offrampKYCStatus: OfframpKYCStatus;
  offrampProviderUserId?: string;

  // Billing info
  billingDisplayName?: string;
  billingCompanyName?: string;
  billingAddressLine1?: string;
  billingAddressLine2?: string;
  billingCity?: string;
  billingState?: string;
  billingPostalCode?: string;
  billingCountry?: string;

  // Invoice defaults
  defaultInvoicePaymentTerms: PaymentTerms;
  defaultInvoiceNotes?: string;
  defaultInvoiceLateFeePercent: number;

  // Notifications
  notifyOnPaymentReceived: boolean;
  notifyOnInvoicePaid: boolean;
  notifyWeeklySummary: boolean;

  createdAt: string;
  updatedAt: string;
}

export interface UserPayoutPreferencesInput {
  preferredMethod?: PayoutMethod;
  walletAddress?: string;
  preferredCryptoCurrency?: PayoutCryptoCurrency;
  billingDisplayName?: string;
  billingCompanyName?: string;
  billingAddressLine1?: string;
  billingAddressLine2?: string;
  billingCity?: string;
  billingState?: string;
  billingPostalCode?: string;
  billingCountry?: string;
  defaultInvoicePaymentTerms?: PaymentTerms;
  defaultInvoiceNotes?: string;
  defaultInvoiceLateFeePercent?: number;
  notifyOnPaymentReceived?: boolean;
  notifyOnInvoicePaid?: boolean;
  notifyWeeklySummary?: boolean;
}

// ============================================================================
// DAO Payout Types
// ============================================================================

/**
 * Source type for a DAO payout
 */
export type PayoutSourceType =
  | 'bounty'
  | 'grant'
  | 'salary'
  | 'expense'
  | 'invoice'
  | 'other';

/**
 * Status of a DAO payout
 */
export type PayoutStatus =
  | 'pending'
  | 'approved'
  | 'executing'
  | 'completed'
  | 'failed'
  | 'cancelled';

/**
 * DAO payout record
 */
export interface DAOPayout {
  id: string;
  daoId: string;

  // Recipient
  recipientUserId?: string;
  recipientWalletAddress?: string;
  recipientEmail?: string;

  // Amount
  amount: number;
  currency: string;
  usdValueAtPayout?: number;

  // Method
  payoutMethod: PayoutMethod;

  // Source
  sourceType: PayoutSourceType;
  sourceId?: string;
  sourceDescription?: string;

  // Fees
  platformFeeAmount?: number;
  platformFeePercent?: number;
  providerFeeAmount?: number;
  networkFeeAmount?: number;

  status: PayoutStatus;

  // Execution
  safeTxHash?: string;
  blockchainTxHash?: string;
  offrampTransactionId?: string;

  // Tax tracking
  taxableEvent: boolean;
  requires1099: boolean;
  w9Collected: boolean;
  taxYear?: number;

  // Audit
  initiatedBy?: string;
  approvedBy?: string;
  createdAt: string;
  approvedAt?: string;
  executedAt?: string;
  completedAt?: string;
  failureReason?: string;
  updatedAt: string;
}

export interface CreatePayoutInput {
  daoId: string;
  recipientUserId?: string;
  recipientWalletAddress?: string;
  recipientEmail?: string;
  amount: number;
  currency: string;
  payoutMethod?: PayoutMethod;
  sourceType: PayoutSourceType;
  sourceId?: string;
  sourceDescription?: string;
}

// ============================================================================
// Recurring Payout Types
// ============================================================================

/**
 * Frequency for recurring payouts
 */
export type RecurringPayoutFrequency =
  | 'weekly'
  | 'biweekly'
  | 'monthly'
  | 'quarterly';

/**
 * Status of a recurring payout schedule
 */
export type RecurringPayoutStatus =
  | 'active'
  | 'paused'
  | 'completed'
  | 'cancelled';

/**
 * Category for recurring payouts
 */
export type RecurringPayoutCategory = 'salary' | 'grant' | 'vendor' | 'other';

/**
 * Recurring payout schedule
 */
export interface RecurringPayout {
  id: string;
  daoId: string;

  // Recipient
  recipientUserId?: string;
  recipientWalletAddress?: string;
  recipientEmail?: string;

  // Payment details
  amount: number;
  currency: string;
  payoutMethod: PayoutMethod;

  // Schedule
  frequency: RecurringPayoutFrequency;
  startDate: string; // ISO date
  endDate?: string; // ISO date, null = indefinite
  nextPayoutDate: string; // ISO date

  status: RecurringPayoutStatus;

  // Metadata
  title: string;
  description?: string;
  category?: RecurringPayoutCategory;

  // Tracking
  totalPaid: number;
  payoutsCompleted: number;
  payoutsRemaining?: number; // null = indefinite

  // Settings
  requiresApprovalEachTime: boolean;
  autoExecute: boolean;

  // Audit
  createdBy?: string;
  pausedAt?: string;
  pausedBy?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  cancellationReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateRecurringPayoutInput {
  daoId: string;
  recipientUserId?: string;
  recipientWalletAddress?: string;
  recipientEmail?: string;
  amount: number;
  currency: string;
  payoutMethod?: PayoutMethod;
  frequency: RecurringPayoutFrequency;
  startDate: string;
  endDate?: string;
  title: string;
  description?: string;
  category?: RecurringPayoutCategory;
  payoutsRemaining?: number;
  requiresApprovalEachTime?: boolean;
  autoExecute?: boolean;
}

/**
 * Execution status for a recurring payout instance
 */
export type RecurringPayoutExecutionStatus =
  | 'pending'
  | 'executing'
  | 'completed'
  | 'failed'
  | 'skipped';

export interface RecurringPayoutExecution {
  id: string;
  recurringPayoutId: string;
  payoutId?: string;
  scheduledDate: string;
  executedAt?: string;
  status: RecurringPayoutExecutionStatus;
  errorMessage?: string;
  createdAt: string;
}

// ============================================================================
// Invoice Types
// ============================================================================

/**
 * Invoice payment terms
 */
export type PaymentTerms =
  | 'due_on_receipt'
  | 'net_15'
  | 'net_30'
  | 'net_45'
  | 'net_60';

/**
 * Invoice status
 */
export type InvoiceStatus =
  | 'draft'
  | 'sent'
  | 'viewed'
  | 'paid'
  | 'overdue'
  | 'cancelled'
  | 'disputed';

/**
 * Party type for invoice
 */
export type InvoicePartyType = 'user' | 'dao' | 'external';

/**
 * Invoice line item
 */
export interface InvoiceLineItem {
  description: string;
  quantity: number;
  unit: string; // hours, flat, items, etc.
  rate: number;
  amount: number;
}

/**
 * Invoice record
 */
export interface Invoice {
  id: string;
  invoiceNumber: string;

  // Issuer
  issuerType: InvoicePartyType;
  issuerUserId?: string;
  issuerDaoId?: string;

  // Recipient
  recipientType: InvoicePartyType;
  recipientUserId?: string;
  recipientDaoId?: string;
  recipientEmail?: string;
  recipientName?: string;

  // Details
  title: string;
  description?: string;
  lineItems: InvoiceLineItem[];

  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  currency: string;

  // Dates
  issueDate: string; // ISO date
  dueDate: string; // ISO date

  status: InvoiceStatus;

  // Payment
  paymentMethod?: string;
  paymentReference?: string;
  paidAt?: string;
  paidAmount?: number;

  // Metadata
  notes?: string;
  terms?: string;
  attachments: InvoiceAttachment[];

  sentAt?: string;
  viewedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceAttachment {
  name: string;
  url: string;
  type: string;
  size: number;
}

export interface CreateInvoiceInput {
  issuerType: InvoicePartyType;
  issuerUserId?: string;
  issuerDaoId?: string;
  recipientType: InvoicePartyType;
  recipientUserId?: string;
  recipientDaoId?: string;
  recipientEmail?: string;
  recipientName?: string;
  title: string;
  description?: string;
  lineItems: InvoiceLineItem[];
  taxRate?: number;
  currency?: string;
  dueDate: string;
  notes?: string;
  terms?: string;
}

// ============================================================================
// Tax Types
// ============================================================================

/**
 * Tax ID type for W-9
 */
export type TaxIdType = 'ssn' | 'ein' | 'itin';

/**
 * 1099 form status
 */
export type Form1099Status =
  | 'pending'
  | 'generated'
  | 'sent'
  | 'filed'
  | 'corrected';

/**
 * User tax information (W-9)
 */
export interface UserTaxInfo {
  id: string;
  userId: string;
  country: string;
  taxIdType?: TaxIdType;
  // Note: taxId is encrypted and not exposed to client
  taxIdLastFour?: string; // Last 4 digits for display

  // W-9 info
  legalName: string;
  businessName?: string;
  taxClassification?: string;

  // Address
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  postalCode?: string;

  // Signature
  w9SignedAt?: string;

  // Verification
  verifiedAt?: string;

  createdAt: string;
  updatedAt: string;
}

export interface UserTaxInfoInput {
  country: string;
  taxIdType?: TaxIdType;
  taxId?: string; // Only sent for updates, never returned
  legalName: string;
  businessName?: string;
  taxClassification?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  postalCode?: string;
}

/**
 * 1099 tax report
 */
export interface TaxReport1099 {
  id: string;
  taxYear: number;
  userId: string;
  totalAmountUsd: number;
  formType: string;
  status: Form1099Status;
  generatedAt?: string;
  sentAt?: string;
  filedAt?: string;
  createdAt: string;

  // For DAO-issued 1099s (when taxEntityType = 'independent')
  daoId?: string;
  issuedByDao?: boolean;
}

// ============================================================================
// DAO Tax Entity Types
// ============================================================================

/**
 * How the DAO handles tax reporting
 * - 'platform': EnDAO aggregates and issues 1099s (default)
 * - 'independent': DAO is a separate legal entity, issues own 1099s
 */
export type DAOTaxEntityType = 'platform' | 'independent';

/**
 * DAO tax profile for independent DAOs that issue their own 1099s
 */
export interface DAOTaxProfile {
  id: string;
  daoId: string;

  // Payer info (for 1099 forms)
  payerName: string;
  payerEinLastFour?: string; // Last 4 of EIN for display
  payerAddressLine1: string;
  payerAddressLine2?: string;
  payerCity: string;
  payerState: string;
  payerPostalCode: string;
  payerCountry: string;

  // Legal entity info
  legalEntityType?:
    | 'llc'
    | 'corporation'
    | 'nonprofit'
    | 'partnership'
    | 'other';
  stateOfIncorporation?: string;

  // Verification
  verifiedAt?: string;
  verifiedBy?: string;

  createdAt: string;
  updatedAt: string;
}

export interface DAOTaxProfileInput {
  payerName: string;
  payerEin?: string; // Full EIN, encrypted on storage
  payerAddressLine1: string;
  payerAddressLine2?: string;
  payerCity: string;
  payerState: string;
  payerPostalCode: string;
  payerCountry?: string;
  legalEntityType?:
    | 'llc'
    | 'corporation'
    | 'nonprofit'
    | 'partnership'
    | 'other';
  stateOfIncorporation?: string;
}

// ============================================================================
// Financial Audit Types
// ============================================================================

/**
 * Category of financial audit event
 */
export type FinancialAuditCategory =
  | 'payout'
  | 'conversion'
  | 'offramp'
  | 'invoice'
  | 'tax_info'
  | 'recurring_payout'
  | 'fee'
  | 'refund';

/**
 * Financial audit log entry
 */
export interface FinancialAuditLog {
  id: string;
  eventType: string;
  eventCategory: FinancialAuditCategory;
  entityType: string;
  entityId: string;
  actorId?: string;
  action: string;
  details: Record<string, unknown>;
  amountUsd?: number;
  riskScore: number;
  riskFactors: string[];
  requiresReview: boolean;
  createdAt: string;
}

// ============================================================================
// Payment Method Types (for donation flow)
// ============================================================================

export type DonationPaymentMethod = 'card' | 'crypto';

export interface AvailablePaymentMethod {
  method: DonationPaymentMethod;
  enabled: boolean;
  displayName: string;
  description: string;
  processingTime: string;
  fees: {
    platformFeePercent: number;
    processorFeePercent: number;
    processorFeeFixed?: number;
    networkFeeEstimate?: number;
  };
}

export interface PaymentMethodsResponse {
  daoId: string;
  methods: AvailablePaymentMethod[];
  defaultMethod: DonationPaymentMethod;
}

// ============================================================================
// Fee Types
// ============================================================================

export interface FeeBreakdown {
  grossAmount: number;
  platformFee: number;
  platformFeePercent: number;
  processorFee: number;
  processorName: string;
  networkFee?: number;
  netAmount: number;
}

/**
 * Platform fee rates
 */
export const PLATFORM_FEE_RATES = {
  DEPOSIT: 0.05, // 5% on all incoming funds
  OUTFLOW: 0.015, // 1.5% on all outgoing funds
  DAO_TO_DAO: 0, // 0% for DAO-to-DAO transfers
} as const;

// ============================================================================
// Provider Types
// ============================================================================

export type ConversionProvider = 'moonpay' | 'transak' | 'ramp';

export interface ProviderQuote {
  provider: ConversionProvider;
  sourceAmount: number;
  sourceCurrency: string;
  targetAmount: number;
  targetCurrency: string;
  exchangeRate: number;
  fees: {
    providerFee: number;
    networkFee?: number;
  };
  expiresAt: string;
}

export interface ProviderAvailability {
  provider: ConversionProvider;
  supportedCountries: string[];
  supportsOnramp: boolean;
  supportsOfframp: boolean;
}
