/**
 * Type definitions for Gnosis Safe API integration
 * Provides comprehensive typing for Safe SDK, API Kit, and transaction handling
 */

import type { EthSafeTransaction } from '@safe-global/protocol-kit';

// Re-export with the legacy name for backward compatibility
export type SafeTransaction = EthSafeTransaction;

/**
 * Safe transaction response from Safe API Kit
 */
export interface SafeMultisigTransaction {
  safe: string;
  to: string;
  value: string;
  data: string | null;
  operation: number;
  gasToken: string;
  safeTxGas: number;
  baseGas: number;
  gasPrice: string;
  refundReceiver: string;
  nonce: number;
  executionDate: string | null;
  submissionDate: string;
  modified: string;
  blockNumber: number | null;
  transactionHash: string | null;
  safeTxHash: string;
  executor: string | null;
  isExecuted: boolean;
  isSuccessful: boolean | null;
  ethGasPrice: string | null;
  gasUsed: number | null;
  fee: string | null;
  origin: string | null;
  dataDecoded: SafeDataDecoded | null;
  confirmationsRequired: number;
  confirmations: SafeConfirmation[];
  trusted: boolean;
  signatures: string | null;
}

/**
 * Safe transaction confirmation
 */
export interface SafeConfirmation {
  owner: string;
  submissionDate: string;
  transactionHash: string | null;
  signature: string;
  signatureType: string;
}

/**
 * Safe data decoded information
 */
export interface SafeDataDecoded {
  method: string;
  parameters: SafeParameter[];
}

/**
 * Safe parameter in decoded data
 */
export interface SafeParameter {
  name: string;
  type: string;
  value: string | SafeParameter[];
}

/**
 * Safe transaction history response
 */
export interface SafeTransactionListResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: SafeMultisigTransaction[];
}

/**
 * Safe balance information
 */
export interface SafeBalanceResponse {
  tokenAddress: string | null;
  token: SafeToken | null;
  balance: string;
  ethValue: string;
  timestamp: string;
  fiatBalance: string;
  fiatConversion: string;
  fiatCode: string;
}

/**
 * Safe token information
 */
export interface SafeToken {
  type: 'ERC20' | 'ERC721' | 'NATIVE_TOKEN';
  address: string;
  name: string;
  symbol: string;
  decimals: number;
  logoUri: string | null;
}

/**
 * Safe information from API
 */
export interface SafeInfo {
  address: string;
  nonce: number;
  threshold: number;
  owners: string[];
  masterCopy: string;
  modules: string[];
  fallbackHandler: string;
  guard: string | null;
  version: string;
}

/**
 * Safe creation transaction data
 */
export interface SafeCreationInfo {
  created: string;
  creator: string;
  transactionHash: string;
  factoryAddress: string;
  masterCopy: string;
  setupData: string;
  dataDecoded: SafeDataDecoded | null;
}

/**
 * Treasury signature for multi-sig proposals
 */
export interface TreasurySignature {
  signer: string;
  signature: string;
  signedAt: string;
  signerAddress: string;
}

/**
 * Treasury transaction execution result
 */
export interface TreasuryExecutionResult {
  success: boolean;
  transactionHash?: string;
  safeTxHash: string;
  executedAt: string;
  gasUsed?: number;
  gasPrice?: string;
  error?: string;
}

/**
 * Safe transaction creation parameters
 */
export interface SafeTransactionParams {
  to: string;
  value: string;
  data?: string;
  operation?: number;
  safeTxGas?: number;
  baseGas?: number;
  gasPrice?: string;
  gasToken?: string;
  refundReceiver?: string;
  nonce?: number;
}

/**
 * Safe owner information
 */
export interface SafeOwnerInfo {
  address: string;
  isOwner: boolean;
  threshold: number;
  ownerIndex?: number;
}

/**
 * Safe deployment configuration
 */
export interface SafeDeploymentConfig {
  owners: string[];
  threshold: number;
  saltNonce?: string;
  version?: string;
  fallbackHandler?: string;
  paymentToken?: string;
  payment?: string;
  paymentReceiver?: string;
}

/**
 * Safe transaction status
 */
export type SafeTransactionStatus =
  | 'pending'
  | 'awaiting_confirmations'
  | 'awaiting_execution'
  | 'executed'
  | 'cancelled'
  | 'failed';

/**
 * Safe transaction with status
 */
export interface SafeTransactionWithStatus extends SafeMultisigTransaction {
  status: SafeTransactionStatus;
  requiredConfirmations: number;
  currentConfirmations: number;
}

/**
 * Safe API error response
 */
export interface SafeApiError {
  detail: string;
  code?: string;
  field?: string;
}

/**
 * Safe service response wrapper
 */
export interface SafeServiceResponse<T> {
  success: boolean;
  data?: T;
  error?: SafeApiError;
}

/**
 * Type guard for Safe transaction
 */
export function isSafeTransaction(
  transaction: unknown
): transaction is SafeMultisigTransaction {
  return (
    typeof transaction === 'object' &&
    transaction !== null &&
    'safe' in transaction &&
    'to' in transaction &&
    'value' in transaction &&
    'safeTxHash' in transaction
  );
}

/**
 * Type guard for Safe transaction list response
 */
export function isSafeTransactionListResponse(
  response: unknown
): response is SafeTransactionListResponse {
  if (typeof response !== 'object' || response === null) return false;

  const r = response as Record<string, unknown>;
  return 'count' in r && 'results' in r && Array.isArray(r.results);
}

/**
 * Type guard for Safe confirmation
 */
export function isSafeConfirmation(
  confirmation: unknown
): confirmation is SafeConfirmation {
  return (
    typeof confirmation === 'object' &&
    confirmation !== null &&
    'owner' in confirmation &&
    'signature' in confirmation &&
    'submissionDate' in confirmation
  );
}
