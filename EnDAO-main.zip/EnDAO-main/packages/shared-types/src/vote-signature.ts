/**
 * Vote Signature Types for Hybrid Voting
 *
 * Supports both EIP-712 typed signatures and personal_sign fallback
 * for cryptographic vote verification with wallet addresses.
 */

/**
 * EIP-712 Domain for EnDAO vote signatures
 */
export const VOTE_SIGNATURE_DOMAIN = {
  name: 'EnDAO',
  version: '1',
  // chainId and verifyingContract should be added at runtime based on network
} as const;

/**
 * EIP-712 Type definitions for vote signatures
 */
export const VOTE_SIGNATURE_TYPES = {
  Vote: [
    { name: 'proposalId', type: 'string' },
    { name: 'daoId', type: 'string' },
    { name: 'choice', type: 'string' },
    { name: 'voter', type: 'address' },
    { name: 'strength', type: 'uint256' },
    { name: 'timestamp', type: 'uint256' },
    { name: 'nonce', type: 'string' },
  ],
} as const;

/**
 * Vote message structure for EIP-712 signing
 */
export interface VoteMessage {
  /** Proposal ID being voted on */
  proposalId: string;

  /** DAO ID containing the proposal */
  daoId: string;

  /** Vote choice: 'for' | 'against' | 'abstain' */
  choice: string;

  /** Voter's wallet address */
  voter: string;

  /** Vote strength for quadratic voting (1-10) */
  strength: number;

  /** Unix timestamp when vote was created */
  timestamp: number;

  /** Unique nonce to prevent replay attacks */
  nonce: string;
}

/**
 * Signature type options
 */
export type SignatureType = 'eip712' | 'personal_sign';

/**
 * Signed vote with cryptographic proof
 */
export interface SignedVote {
  /** Vote message containing all vote data */
  message: VoteMessage;

  /** Cryptographic signature (hex string) */
  signature: string;

  /** Wallet address that signed the vote */
  walletAddress: string;

  /** Type of signature used */
  signatureType: SignatureType;
}

/**
 * Vote signature history record for audit trail
 */
export interface VoteSignatureHistory {
  /** Unique signature history ID */
  id: string;

  /** Associated vote ID */
  voteId: string;

  /** Wallet address that signed */
  walletAddress: string;

  /** Signature (hex string) */
  signature: string;

  /** Signature type */
  signatureType: SignatureType;

  /** Message hash */
  messageHash: string;

  /** Vote choice */
  voteChoice: string;

  /** Vote strength (if quadratic) */
  voteStrength?: number;

  /** When the vote was signed */
  signedAt: string;

  /** When this history record was created */
  createdAt: string;
}

/**
 * Creates a human-readable message string for personal_sign fallback
 *
 * Used when EIP-712 is not supported by the wallet.
 * Format is deterministic to allow signature verification.
 *
 * @param message - Vote message to convert to string
 * @returns Formatted message string for personal_sign
 */
export function createVoteMessageString(message: VoteMessage): string {
  const lines = [
    'EnDAO Vote Signature',
    '',
    `Proposal: ${message.proposalId}`,
    `DAO: ${message.daoId}`,
    `Choice: ${message.choice}`,
    `Voter: ${message.voter}`,
    `Strength: ${message.strength}`,
    `Timestamp: ${message.timestamp}`,
    `Nonce: ${message.nonce}`,
  ];

  return lines.join('\n');
}

/**
 * Vote signature verification result
 */
export interface VoteSignatureVerification {
  /** Whether the signature is valid */
  valid: boolean;

  /** Recovered signer address (if valid) */
  signer?: string;

  /** Error message (if invalid) */
  error?: string;

  /** Message hash used for verification */
  messageHash?: string;
}

/**
 * Extended Vote type with signature fields
 */
export interface VoteWithSignature {
  /** Vote ID */
  id: string;

  /** Proposal ID */
  proposalId: string;

  /** User ID who cast the vote */
  userId: string;

  /** Vote choice */
  choice: 'for' | 'against' | 'abstain';

  /** Wallet address (if signed) */
  walletAddress?: string;

  /** Cryptographic signature (if signed) */
  signature?: string;

  /** Signature type (if signed) */
  signatureType?: SignatureType;

  /** Message hash (if signed) */
  messageHash?: string;

  /** When vote was signed (if signed) */
  signedAt?: string;

  /** Vote strength for quadratic voting */
  voteStrength?: number;

  /** When vote was created */
  createdAt: string;

  /** When vote was last updated */
  updatedAt: string;
}
