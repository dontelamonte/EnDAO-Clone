/**
 * Wallet Adapter Interface
 * Abstracts wallet provider access for web and mobile
 */

export type WalletType = 'embedded' | 'external' | 'unknown';

export interface WalletInfo {
  address: string;
  type: WalletType;
  chainId?: number;
  isConnected: boolean;
}

export interface WalletAdapter {
  /**
   * Get connected wallet info
   * @returns Wallet information or null if not connected
   */
  getWallet(): WalletInfo | null;

  /**
   * Check if wallet is connected
   * @returns True if wallet is connected
   */
  isConnected(): boolean;

  /**
   * Get wallet address (lowercase)
   * @returns Wallet address in lowercase or null if not connected
   */
  getAddress(): string | null;
}
