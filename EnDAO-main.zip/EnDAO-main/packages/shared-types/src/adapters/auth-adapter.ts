/**
 * Auth Adapter Interface
 * Abstracts authentication provider
 */

export interface AuthUser {
  id: string;
  email?: string;
  walletAddress?: string;
  isAuthenticated: boolean;
}

export interface AuthAdapter {
  /**
   * Get current authenticated user
   * @returns User info or null if not authenticated
   */
  getUser(): AuthUser | null;

  /**
   * Check if user is authenticated
   * @returns True if user is authenticated
   */
  isAuthenticated(): boolean;

  /**
   * Get access token for API calls
   * @returns Promise resolving to access token or null if not available
   */
  getAccessToken(): Promise<string | null>;

  /**
   * Logout the user
   * @returns Promise that resolves when logout is complete
   */
  logout(): Promise<void>;
}
