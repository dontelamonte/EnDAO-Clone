/**
 * Signing Adapter Interface
 * Shared between web and mobile for consistent signature handling
 */

export interface SignedMessage {
  signature: string;
  messageHash?: string;
}

export interface EIP712Domain {
  name: string;
  version: string;
  chainId?: number;
  verifyingContract?: string;
}

export interface EIP712Type {
  name: string;
  type: string;
}

export interface SigningAdapter {
  /**
   * Sign a message using personal_sign
   * @param message - The message to sign
   * @returns Promise resolving to signed message with signature
   */
  signMessage(message: string): Promise<SignedMessage>;

  /**
   * Sign typed data using EIP-712
   * @param domain - EIP-712 domain separator
   * @param types - Type definitions for the message
   * @param message - The message data to sign
   * @param primaryType - The primary type name
   * @returns Promise resolving to signed message with signature
   */
  signTypedData<T extends Record<string, unknown>>(
    domain: EIP712Domain,
    types: Record<string, EIP712Type[]>,
    message: T,
    primaryType: string
  ): Promise<SignedMessage>;

  /**
   * Check if signing is available
   * @returns True if the adapter can sign messages
   */
  isSigningAvailable(): boolean;

  /**
   * Get the signer's address
   * @returns The signer's Ethereum address or null if not available
   */
  getSignerAddress(): string | null;
}
