---
name: documentation-guardian
description: Enforces EnDAO documentation governance framework preventing sprawl, duplication, and quality issues. Validates file naming, required sections, placement, and content standards. Use when creating or modifying documentation files.
allowed-tools: Read, Grep, Glob, Edit
---

# Documentation Guardian

## Purpose

Maintains EnDAO's documentation quality and prevents documentation sprawl by enforcing the comprehensive governance framework defined in `docs/DOCUMENTATION_GOVERNANCE.md`.

## Last Updated

October 31, 2025

## Documentation Standards

### Required Sections

Every documentation file must include:

```markdown
# Document Title

## Purpose

[Clear explanation of document purpose]

## Last Updated

[Date of last significant update]

[Main content sections...]
```

### Optional but Recommended Sections

- **Audience**: Who should read this document
- **Table of Contents**: For documents >500 words
- **Related Documents**: Cross-references to related documentation
- **Changelog**: For significant documents with frequent updates

## File Naming Conventions

### Directory Names

- **Format**: `lowercase-with-hyphens`
- **Examples**: `architecture`, `api-reference`, `security-guidelines`
- **Avoid**: camelCase, snake_case, spaces, special characters

### File Names

**Major Documentation** (UPPERCASE_WORDS.md):

- `README.md`
- `ARCHITECTURE.md`
- `DEPLOYMENT_GUIDE.md`
- `CLAUDE.md`
- `CONTRIBUTING.md`

**Specific Topics** (lowercase-with-hyphens.md):

- `setup-development.md`
- `api-authentication.md`
- `firestore-index-deployment-guide.md`

**Architecture Decision Records** (numbered):

- `001-decision-title.md`
- `002-next-decision.md`

**Avoid**:

- Spaces in names
- Version numbers in names
- Special characters
- Dates in names (use git history)

## Approved Documentation Structure

```
/
├── README.md                   # Project overview
├── CLAUDE.md                   # AI assistant context
├── ARCHITECTURE.md             # System design
├── CHANGELOG.md                # Version history
├── CONTRIBUTING.md             # Contribution guidelines
│
└── docs/                       # All project documentation
    ├── api/                    # API documentation
    ├── architecture/           # System design & patterns
    ├── database/              # Database guides
    ├── deployment/            # Setup and deployment
    ├── features/              # Feature documentation
    ├── guides/                # User guides
    ├── security/              # Security documentation
    ├── treasury/              # Treasury system documentation
    └── archive/               # Historical files
```

## Validation Rules

### Rule 1: File Naming Validation

**Check**:

- Directory names are lowercase-with-hyphens
- Major docs use UPPERCASE_WORDS.md
- Specific topics use lowercase-with-hyphens.md
- No spaces, version numbers, or dates in names
- ADRs use 3-digit numbering (001-title.md)

**Action**:

```
❌ NAMING VIOLATION

File: docs/API Reference v2.md
Issue: Contains spaces and version number

Correct Name: docs/api/API_REFERENCE.md
Pattern: Major documentation → UPPERCASE_WORDS.md

Auto-Fix Available: Yes
```

### Rule 2: Required Sections Validation

**Check**:

- `# Document Title` present
- `## Purpose` section exists
- `## Last Updated` section exists
- Content is not placeholder text

**Action**:

```
❌ MISSING REQUIRED SECTIONS

File: docs/features/new-feature.md
Missing:
- ## Purpose
- ## Last Updated

Add these sections before the file can be committed.

Template Available: Yes
```

### Rule 3: Placement Validation

**Check**:

- File is in correct directory for its topic
- Directory exists in approved structure
- No documentation files in src/ (except component/service-specific READMEs)
- No scattered documentation outside docs/

**Action**:

```
⚠️ INCORRECT PLACEMENT

File: src/components/dao/TREASURY_GUIDE.md
Issue: General documentation in code directory

Correct Location: docs/treasury/treasury-guide.md
Reason: General guides belong in docs/, not src/

Move Required: Yes
```

### Rule 4: Duplicate Content Detection

**Check**:

- Topic not already covered in existing documentation
- No overlapping content with other files
- Proper cross-referencing to canonical sources

**Action**:

```
❌ DUPLICATE CONTENT DETECTED

New File: docs/api/authentication-guide.md
Existing: docs/api/authentication.md

Overlap: 85% content similarity

Recommended Action:
1. Update existing docs/api/authentication.md
2. Add new content to existing file
3. Do not create duplicate file

Update Existing: Yes
```

### Rule 5: Placeholder Content Detection

**Check**:

- No "TODO" sections without context
- No "FIXME" or "TBD" markers
- No template content left unchanged
- No "[Insert content here]" placeholders

**Blocked Words** (case-insensitive):

- "TODO" (without specific task)
- "FIXME" (without explanation)
- "TBD"
- "[INSERT"
- "TEMPLATE"
- "PLACEHOLDER"

**Action**:

```
❌ PLACEHOLDER CONTENT

File: docs/guides/deployment.md
Line 42: "## Configuration - TODO: Add configuration steps"
Line 58: "[INSERT DEPLOYMENT STEPS HERE]"

Blocked: Documentation with placeholder content cannot be committed

Complete Content Required: Yes
```

### Rule 6: Quality Standards Validation

**Check**:

- Clear, concise writing
- Proper markdown formatting
- Code blocks with language specified
- Relative links (not absolute)
- No broken internal links

**Action**:

````
⚠️ QUALITY ISSUES

File: docs/api/endpoints.md

Issues:
1. Code block missing language identifier (line 34)
2. Absolute link to internal doc (line 56): /docs/api/auth.md
3. Broken link to non-existent file (line 72)

Recommended Fixes:
1. Add ```typescript to code block
2. Change to relative link: ./auth.md
3. Update link or remove reference

Auto-Fix Available: Partial
````

## Validation Workflow

### Pre-Creation Checklist

Before creating any documentation:

1. **Need Assessment**
   - [ ] Explicit user request OR critical system change
   - [ ] No existing documentation covers this topic
   - [ ] Information doesn't belong in code comments
   - [ ] Target audience identified

2. **Content Analysis**
   - [ ] No overlapping content in existing docs
   - [ ] Canonical location identified
   - [ ] Information is accurate and complete
   - [ ] Alternative actions considered

3. **Placement Strategy**
   - [ ] Correct directory based on approved hierarchy
   - [ ] Proper file name following conventions
   - [ ] Related documents identified for cross-referencing
   - [ ] Maintenance ownership planned

4. **Quality Validation**
   - [ ] All required sections included
   - [ ] Style guidelines followed
   - [ ] No placeholder content
   - [ ] Proper formatting and links

### Alternative Actions (Before Creating Documentation)

When documentation should NOT be created, suggest:

1. **Code Comments**
   - Add docstrings to functions and classes
   - Use inline comments for complex logic
   - Explain non-obvious implementations

2. **Update Existing Documentation**
   - Add to relevant existing files
   - Update outdated sections
   - Improve existing documentation quality

3. **GitHub Issues**
   - Track feature requests as issues
   - Document bugs in issue tracker
   - Use issue forms for consistent reporting

4. **README Updates**
   - Quick start instructions
   - Setup procedures
   - Common troubleshooting

## Auto-Actions

### 1. Pre-Save Validation

When saving any `.md` file:

1. **Validate file name** against conventions
2. **Check required sections** exist
3. **Scan for placeholder content**
4. **Verify placement** in approved hierarchy
5. **Generate validation report**

### 2. Duplicate Detection

When creating new documentation:

1. **Search existing files** for similar content
2. **Calculate content similarity** percentage
3. **Identify overlapping topics**
4. **Suggest update instead of create**

### 3. Quality Enforcement

Enforce quality standards:

1. **Markdown formatting** validation
2. **Link integrity** checking
3. **Code block** language identifiers
4. **Relative paths** for internal links

## Activation Triggers

This skill activates when:

- Creating new `.md` files
- Modifying existing `.md` files in docs/
- User mentions: document, write docs, create guide
- Pre-commit hook for documentation files
- Explicit skill invocation

## Validation Output Format

```
📚 DOCUMENTATION VALIDATION

File: docs/treasury/in-app-signing.md
Status: ✅ VALID

Checks Passed:
✅ File naming convention (lowercase-with-hyphens.md)
✅ Required sections present (Purpose, Last Updated)
✅ Proper placement (docs/treasury/)
✅ No duplicate content detected
✅ No placeholder content
✅ Quality standards met

Ready to Commit: Yes
```

```
📚 DOCUMENTATION VALIDATION

File: docs/API Guide v2.md
Status: ❌ BLOCKED

Issues Found:
❌ Invalid file name (contains spaces and version number)
   → Correct: docs/api/API_REFERENCE.md

❌ Missing required section: ## Purpose

❌ Placeholder content detected
   → Line 45: "TODO: Add authentication examples"
   → Line 67: "[INSERT API ENDPOINTS HERE]"

❌ Duplicate content (78% similarity)
   → Existing file: docs/api/endpoints.md
   → Recommendation: Update existing file instead

Auto-Fix Available: Partial (file rename only)
Manual Fixes Required: 3

Ready to Commit: No
```

## Integration with Pre-Commit Hooks

Works with existing script:

```bash
scripts/docs/validate-docs.sh    # Documentation validation script
```

### Pre-Commit Workflow

1. **Detect new/modified .md files**
2. **Run validation checks**
3. **Block commit if issues found**
4. **Provide clear error messages**
5. **Suggest fixes or alternatives**

## Common Violations & Fixes

### Violation 1: Creating Unnecessary READMEs

```
❌ Bad: Creating README.md for every component
File: src/components/button/README.md

✅ Good: Only create READMEs for complex, reusable components
Suggestion: Add docstring to component instead
```

### Violation 2: Documentation with Placeholders

```
❌ Bad: Committing incomplete documentation
File: docs/guides/deployment.md
Content: "## Steps - TODO: Write deployment steps"

✅ Good: Complete documentation before committing
Action: Finish content or save as draft (not committed)
```

### Violation 3: Duplicating Existing Content

```
❌ Bad: Creating new API docs when API.md exists
New: docs/api/new-endpoints.md
Existing: docs/api/endpoints.md (covers same topic)

✅ Good: Update existing documentation
Action: Add new content to docs/api/endpoints.md
```

### Violation 4: Poor File Naming

```
❌ Bad: Spaces and version numbers
File: docs/Treasury System Guide v2.1 FINAL.md

✅ Good: Follow naming conventions
Correct: docs/treasury/treasury-system-guide.md
```

### Violation 5: Wrong Placement

```
❌ Bad: General docs in code directories
File: src/lib/services/AUTHENTICATION.md

✅ Good: Proper hierarchy placement
Correct: docs/features/user-authentication.md
```

## Exemptions

Some files may be exempt from certain rules:

- **Generated files**: Auto-generated API docs (mark with comment)
- **Third-party docs**: External documentation (place in docs/external/)
- **Legal files**: PRIVACY_POLICY.md, TERMS_OF_SERVICE.md (root level)

**Mark exemptions** with comment:

```markdown
<!-- @documentation-guardian-exempt: Auto-generated API reference -->
```

## Success Criteria

✅ All new documentation follows naming conventions
✅ All required sections present
✅ No placeholder content in committed files
✅ Proper placement in approved hierarchy
✅ No duplicate content
✅ Quality standards met
✅ Clear refactoring path for violations

## Enforcement Actions

### Warning Level

- Naming issues (auto-fixable)
- Minor quality issues
- Missing optional sections

**Action**: Display warning, allow commit with user confirmation

### Error Level

- Missing required sections
- Placeholder content
- Duplicate content (>70% similarity)
- Wrong directory placement

**Action**: Block commit, require fixes

### Critical Level

- Security-sensitive placeholder content
- Broken deployment instructions
- Incorrect legal documentation

**Action**: Block commit, require immediate fixes

## Documentation Templates

### Standard Document Template

```markdown
# Document Title

## Purpose

[1-2 sentences explaining why this document exists and what problem it solves]

## Last Updated

[Month Year]

## Content

[Main documentation content...]

## Related Documents

- [Link to related doc](./related-doc.md)
- [Another related doc](../category/other-doc.md)
```

### Feature Documentation Template

```markdown
# Feature Name

## Purpose

[Explain what this feature does and why it exists]

## Last Updated

[Month Year]

## User Flow

1. User action
2. System response
3. Result

## Technical Implementation

[High-level technical overview]

## API Reference

[If applicable, link to API documentation]

## Configuration

[Required configuration or environment variables]

## Testing

[How to test this feature]

## Related Documents

- [Related feature](./related-feature.md)
- [API Reference](../api/endpoints.md)
```

## Maintenance

### Regular Reviews

- **Weekly**: Check for new documentation violations
- **Monthly**: Review documentation quality metrics
- **Quarterly**: Audit documentation hierarchy and archival candidates

### Metrics Tracking

- Documentation creation rate
- Violation rate per category
- Auto-fix success rate
- Documentation coverage
- Update frequency

---

**Integration**: Works with `scripts/docs/validate-docs.sh` and pre-commit hooks
**Enforcement**: Automatic validation on commit, manual skill invocation
**Quality Gates**: Blocks commits with critical violations
