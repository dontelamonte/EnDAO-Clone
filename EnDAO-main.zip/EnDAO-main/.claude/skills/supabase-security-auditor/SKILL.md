---
name: supabase-security-auditor
description: Audits Supabase RLS policies and validates data access patterns for EnDAO. Ensures proper authentication, authorization, and data isolation between DAOs. Use when working with Supabase queries, RLS policies, user data access, or database operations.
allowed-tools: Read, Grep, mcp__supabase__get_advisors, mcp__supabase__execute_sql, mcp__supabase__list_tables
---

# Supabase Security Auditor

## Purpose

Prevents security vulnerabilities in Supabase queries and operations by validating authentication, authorization, RLS policies, and data isolation patterns.

## Last Updated

January 7, 2026

## Security Principles

### 1. Defense in Depth

- **Client-side validation**: Basic checks for UX
- **RLS policies**: Database-level enforcement (PRIMARY)
- **Server-side validation**: API route authorization
- **Service-level validation**: Business logic checks

### 2. Zero Trust

- Never trust client-provided data
- Always validate user identity via `auth.uid()`
- Verify permissions on every operation
- Use `getSupabaseAdmin()` only when RLS bypass is intentional

### 3. Data Isolation

- DAO data must be isolated by dao_id
- User data must be isolated by user_id
- No cross-DAO data leakage
- Proper multi-tenancy enforcement via RLS

## Supabase Client Usage

### Client Types

```typescript
// Browser-safe client (respects RLS)
import { getSupabaseClient } from '@/lib/supabase/client';
const supabase = getSupabaseClient();

// Admin client (bypasses RLS - SERVER ONLY)
import { getSupabaseAdmin } from '@/lib/supabase/admin';
const adminClient = getSupabaseAdmin(); // DANGER: Use only in API routes
```

### CRITICAL: Never use admin client in browser code

```typescript
// BAD: Admin client in browser component
'use client';
import { getSupabaseAdmin } from '@/lib/supabase/admin';
// This WILL fail and is a security anti-pattern

// GOOD: Use regular client, rely on RLS
'use client';
import { getSupabaseClient } from '@/lib/supabase/client';
```

## Security Checks

### 1. RLS Policy Validation

All tables must have proper RLS policies:

#### CRITICAL: Missing RLS

```sql
-- BAD: Table without RLS enabled
CREATE TABLE proposals (
  id uuid PRIMARY KEY,
  dao_id uuid REFERENCES daos(id),
  title text
);
-- No RLS = anyone can read/write!

-- GOOD: RLS enabled with proper policies
CREATE TABLE proposals (
  id uuid PRIMARY KEY,
  dao_id uuid REFERENCES daos(id),
  title text
);

ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "proposals_select"
  ON proposals FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM dao_members dm
      WHERE dm.dao_id = proposals.dao_id
        AND dm.user_id = (SELECT auth.uid())
    )
  );
```

### 2. Auth Context Validation

All queries must properly reference auth context:

#### BAD: Missing auth.uid() check

```typescript
// BAD: No user validation in RLS policy
async function getProposals(daoId: string) {
  const { data } = await supabase
    .from('proposals')
    .select('*')
    .eq('dao_id', daoId);
  return data;
}
```

#### GOOD: RLS handles authorization

```typescript
// GOOD: RLS policy validates user is DAO member
async function getProposals(daoId: string) {
  const { data, error } = await supabase
    .from('proposals')
    .select('*')
    .eq('dao_id', daoId);

  if (error) {
    // RLS violation returns error, not empty data
    console.error('Query failed:', error.message);
    throw new Error('Unable to retrieve proposals');
  }
  return data;
}
```

### 3. Admin Operations Validation

Admin operations must validate permissions server-side:

#### BAD: Client-side admin check

```typescript
// BAD: Client-side check can be bypassed
if (user.role === 'admin') {
  await supabase.from('proposals').delete().eq('id', proposalId);
}
```

#### GOOD: Server-side validation + RLS

```typescript
// API Route (server-side)
export async function DELETE(request: NextRequest) {
  const userId = request.headers.get('x-auth-uid');
  const { proposalId, daoId } = await request.json();

  // Server-side admin validation
  const isAdmin = await adminService.validateAdmin(userId, daoId);
  if (!isAdmin) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  // Use admin client for validated operations
  const adminClient = getSupabaseAdmin();
  await adminClient.from('proposals').delete().eq('id', proposalId);
}
```

### 4. RLS Policy Performance

Use optimized auth patterns:

#### BAD: Slow auth pattern

```sql
-- BAD: auth.jwt() called for every row
CREATE POLICY "slow_policy"
  ON proposals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM dao_members
      WHERE user_id = (auth.jwt() ->> 'sub')::uuid
    )
  );
```

#### GOOD: Optimized auth pattern

```sql
-- GOOD: Wrapped in SELECT for query plan caching
CREATE POLICY "fast_policy"
  ON proposals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM dao_members
      WHERE user_id = (SELECT auth.uid())
        AND dao_id = proposals.dao_id
    )
  );
```

### 5. Service Role Usage

Service role bypasses RLS - use carefully:

```typescript
// GOOD: Admin client for system operations
// API route for cron job - no user context
export async function POST(request: NextRequest) {
  // Verify cron secret
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Service role for background jobs
  const adminClient = getSupabaseAdmin();
  await adminClient.from('notifications').insert({ ... });
}
```

## Common Vulnerabilities

### 1. Cross-DAO Data Leakage

**Vulnerability**: Missing dao_id filter in RLS policy
**Impact**: Users can access data from other DAOs
**Fix**: Always include dao_id check in RLS policies

```sql
-- GOOD: DAO isolation in policy
CREATE POLICY "proposals_select"
  ON proposals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM dao_members dm
      WHERE dm.dao_id = proposals.dao_id
        AND dm.user_id = (SELECT auth.uid())
    )
  );
```

### 2. RLS Bypass via Admin Client

**Vulnerability**: Using admin client in browser code
**Impact**: Complete RLS bypass
**Fix**: Only use admin client in server-side code

### 3. Overly Permissive Policies

**Vulnerability**: `USING (true)` or `WITH CHECK (true)`
**Impact**: Anyone can read/write data
**Fix**: Always check user permissions in policies

### 4. Missing Policy on New Tables

**Vulnerability**: Forgetting to add RLS to new tables
**Impact**: Data exposed to all authenticated users
**Fix**: Always enable RLS and add policies in migrations

### 5. Privilege Escalation

**Vulnerability**: Client-side admin checks without server validation
**Impact**: Users can bypass admin checks by modifying client code
**Fix**: Always validate permissions server-side

### 6. Information Disclosure

**Vulnerability**: Exposing internal error details
**Impact**: Attackers learn about system internals
**Fix**: Return generic error messages, log details server-side

## Detection Patterns

### Vulnerable Query Patterns

```typescript
// Search for these patterns in code
const vulnerablePatterns = [
  /getSupabaseAdmin\(\).*'use client'/, // Admin in browser
  /\.from\(['"].*['"]\)\.select\(\)\.then/, // No error handling
];
```

### Vulnerable RLS Patterns

```sql
-- Flag these in migrations
USING (true)           -- Allows all access
WITH CHECK (true)      -- Allows all writes
-- Without auth.uid() check
```

## Activation Triggers

This skill activates when:

- Working with Supabase queries (`supabase.from()`)
- Working with RLS policies
- Creating migrations with new tables
- Creating API routes that access database
- User mentions: security, RLS, authorization
- Working on files in `src/lib/services/`
- Working on files in `src/app/api/`
- Working on files in `supabase/migrations/`

## Output Format

### When RLS Issue Detected

```
SUPABASE SECURITY VULNERABILITY DETECTED

File: supabase/migrations/099_new_feature.sql
Severity: CRITICAL

Vulnerability: Table without RLS policies
Table: feature_settings

Issue: Table created without RLS enabled or policies defined

Impact:
- Any authenticated user can read/write all rows
- No data isolation between DAOs
- Privacy breach risk

Required Fix:
1. Enable RLS on table
2. Add SELECT policy for authorized users
3. Add INSERT/UPDATE/DELETE policies with proper checks

Example:
ALTER TABLE feature_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "feature_settings_select"
  ON feature_settings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM dao_members dm
      WHERE dm.dao_id = feature_settings.dao_id
        AND dm.user_id = (SELECT auth.uid())
    )
  );
```

### When Admin Client Misuse Detected

```
SUPABASE SECURITY ISSUE

File: src/components/dao/treasury-panel.tsx
Severity: CRITICAL

Issue: Admin client used in client component

Current Code:
'use client';
import { getSupabaseAdmin } from '@/lib/supabase/admin';

Problem:
- Admin client bypasses ALL RLS policies
- Should NEVER be used in browser code
- Complete security bypass

Required Fix:
- Use getSupabaseClient() instead
- Move admin operations to API routes
- Rely on RLS for authorization
```

## Success Criteria

- All tables have RLS enabled
- All tables have appropriate policies for CRUD operations
- Policies use optimized auth patterns `(SELECT auth.uid())`
- Admin client only used in server-side code
- No `USING (true)` policies without documentation
- DAO data properly isolated by dao_id
- User data properly isolated by user_id
- Error messages are generic and safe
- Sensitive operations have audit logging

## MCP Integration

Use Supabase MCP tools for validation:

```typescript
// Check security advisor for issues
mcp__supabase__get_advisors({ type: 'security' });

// List tables to verify RLS status
mcp__supabase__list_tables({ schemas: ['public'] });

// Query to check RLS policies
mcp__supabase__execute_sql({
  query: `
    SELECT tablename, policyname, permissive, roles, cmd, qual
    FROM pg_policies
    WHERE schemaname = 'public'
    ORDER BY tablename;
  `,
});
```
