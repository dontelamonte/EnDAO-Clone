---
name: file-size-enforcer
description: Enforces EnDAO file size standards (target 300 lines, max 800 lines) and suggests refactoring patterns including compound components, service orchestration, and lazy loading. Use when creating or modifying React components, services, or any TypeScript files.
allowed-tools: Read, Grep, Glob, Edit
---

# File Size Enforcer

## Purpose

Maintains EnDAO's architecture standards by preventing file size violations and automatically suggesting appropriate refactoring patterns.

## Last Updated

October 29, 2025

## File Size Standards

### Targets

- **Target**: <300 lines (ideal)
- **Warning**: 500 lines (suggest refactoring)
- **Error**: 800 lines (blocks commit)
- **Functions**: <100 lines
- **Cyclomatic Complexity**: <10

### Measurement

- Count lines excluding:
  - Blank lines
  - Comment-only lines
  - Import statements
- Include:
  - Code lines
  - JSX/TSX markup
  - Type definitions

## Refactoring Patterns

### Pattern 1: Compound Components

**When to use**: Large React components (>300 lines) with multiple sections

**Structure**:

```typescript
// ✅ GOOD: Compound component pattern
// dao-settings.tsx (200 lines)
export function DAOSettings() {
  return (
    <DAOSettingsProvider>      // Shared context
      <SettingsHeader />       // 50 lines
      <GeneralSettings />      // 150 lines
      <GovernanceSettings />   // 150 lines
    </DAOSettingsProvider>
  )
}

// general-settings.tsx (150 lines) - Extracted
export function GeneralSettings() {
  const { dao, updateDAO } = useDAOSettings()
  // Component logic here
}
```

**Benefits**:

- Each file <300 lines
- Clear separation of concerns
- Shared state via context
- Easy to test individually

### Pattern 2: Service Orchestration

**When to use**: Large service files (>300 lines) with multiple responsibilities

**Structure**:

```typescript
// ✅ GOOD: Service orchestration pattern
// services/dao/index.ts (100 lines) - Orchestrator
export class DAOService {
  constructor(
    private crud: DAOCrudService,
    private query: DAOQueryService,
    private validation: DAOValidationService
  ) {}

  async createDAO(data) {
    await this.validation.validateCreate(data);
    return this.crud.create(data);
  }
}

// dao-crud.service.ts (150 lines)
// dao-query.service.ts (200 lines)
// dao-validation.service.ts (100 lines)
```

**Benefits**:

- Single responsibility per file
- Easier to test
- Clear dependency structure
- Better code organization

### Pattern 3: Lazy Loading

**When to use**: Non-critical components (>400 lines) or heavy features

**Structure**:

```typescript
// ✅ GOOD: Lazy loading pattern
// components/lazy/admin-panel.tsx (created)
export function AdminPanel() {
  // Complex admin logic here (500 lines)
}

// Usage in parent component
import { lazy } from 'react'
import { LazyWrapper } from '@/components/lazy/lazy-wrapper'

const LazyAdminPanel = lazy(() =>
  import('@/components/lazy/admin-panel')
)

export function AdminPage() {
  return (
    <LazyWrapper fallback={<Skeleton />}>
      <LazyAdminPanel />
    </LazyWrapper>
  )
}
```

**Benefits**:

- Reduced initial bundle size
- Faster page load
- On-demand loading
- Better performance

## Auto-Actions

### 1. Pre-Save Check

When saving any `.tsx` or `.ts` file:

1. **Count lines** (excluding comments/blanks)
2. **Identify large functions** (>100 lines)
3. **Calculate complexity** (if possible)
4. **Generate refactoring plan** if over threshold

### 2. Refactoring Suggestions

#### For Components (>300 lines):

```
📏 FILE SIZE WARNING

File: src/components/dao/settings/dao-settings-content.tsx
Current: 650 lines
Target: <300 lines
Status: ⚠️ WARNING (commit will be blocked at 800 lines)

Recommended Pattern: Compound Components

Refactoring Plan:
1. Create DAOSettingsProvider context (80 lines)
   - Move shared state and logic
   - Provide to child components

2. Extract GeneralSettingsSection → general-settings.tsx (150 lines)
   - Lines 45-195 from original file
   - Use useDAOSettings() hook for state

3. Extract GovernanceSettingsSection → governance-settings.tsx (150 lines)
   - Lines 196-346 from original file
   - Use useDAOSettings() hook for state

4. Extract MemberManagementSection → member-management.tsx (120 lines)
   - Lines 347-467 from original file
   - Use useDAOSettings() hook for state

5. Keep DAOSettingsContent as orchestrator (150 lines)
   - Layout and section coordination
   - Context provider wrapper

Result: 5 files, all <300 lines, better organization

Would you like me to perform this refactoring? (y/n)
```

#### For Services (>300 lines):

```
📏 FILE SIZE WARNING

File: src/lib/services/proposal.service.ts
Current: 850 lines
Target: <300 lines
Status: 🚨 ERROR (blocks commit)

Recommended Pattern: Service Orchestration

Refactoring Plan:
1. Create proposal/ directory structure
2. Extract CRUD operations → proposal-crud.service.ts (200 lines)
   - createProposal, updateProposal, deleteProposal
3. Extract queries → proposal-query.service.ts (250 lines)
   - getProposal, listProposals, searchProposals
4. Extract voting logic → proposal-voting.service.ts (200 lines)
   - castVote, finalizeProposal, calculateResults
5. Extract validation → proposal-validation.service.ts (150 lines)
   - validateProposal, validateVote, checkQuorum
6. Create orchestrator → index.ts (100 lines)
   - Coordinates all services
   - Single export point

Result: 5 files, all <300 lines, clear separation

Would you like me to perform this refactoring? (y/n)
```

#### For Non-Critical Components (>400 lines):

```
📏 FILE SIZE WARNING

File: src/components/admin/audit-log-viewer.tsx
Current: 520 lines
Target: <300 lines
Status: ⚠️ WARNING

Recommended Pattern: Lazy Loading + Compound Components

Refactoring Plan:
1. Move to components/lazy/admin/ (lazy loading)
2. Apply compound pattern:
   - AuditLogProvider (50 lines)
   - AuditLogFilters (100 lines)
   - AuditLogTable (200 lines)
   - AuditLogDetails (120 lines)
   - AuditLogViewer orchestrator (50 lines)

Result: Lazy loaded, 5 files all <300 lines

Would you like me to perform this refactoring? (y/n)
```

### 3. Function Size Analysis

Identify large functions (>100 lines):

```
🔍 LARGE FUNCTION DETECTED

File: src/lib/services/treasury/treasury-admin.service.ts
Function: processTreasuryTransaction (Lines 120-280, 160 lines)

Recommended Refactoring:
1. Extract validation logic → validateTransaction (40 lines)
2. Extract Safe SDK integration → createSafeTransaction (50 lines)
3. Extract signature collection → collectSignatures (40 lines)
4. Keep main orchestration → processTreasuryTransaction (30 lines)

Result: 4 focused functions, all <100 lines
```

## File Analysis Algorithm

```typescript
function analyzeFile(filePath: string): FileAnalysis {
  const content = readFile(filePath);
  const lines = content.split('\n');

  // Count non-empty, non-comment lines
  const codeLines = lines.filter((line) => {
    const trimmed = line.trim();
    return (
      trimmed &&
      !trimmed.startsWith('//') &&
      !trimmed.startsWith('/*') &&
      !trimmed.startsWith('*') &&
      !trimmed.startsWith('import')
    );
  }).length;

  // Identify large functions
  const functions = extractFunctions(content);
  const largeFunctions = functions.filter((fn) => fn.lines > 100);

  // Determine file type
  const fileType = determineFileType(filePath);

  // Calculate refactoring complexity
  const complexity = calculateComplexity(content);

  return {
    filePath,
    codeLines,
    largeFunctions,
    fileType,
    complexity,
    status: getStatus(codeLines),
    recommendation: getRecommendation(fileType, codeLines, complexity),
  };
}

function getStatus(lines: number): Status {
  if (lines >= 800) return 'ERROR';
  if (lines >= 500) return 'WARNING';
  if (lines >= 300) return 'NOTICE';
  return 'OK';
}

function getRecommendation(type, lines, complexity) {
  if (type === 'component' && lines > 300) {
    return 'COMPOUND_COMPONENTS';
  }
  if (type === 'service' && lines > 300) {
    return 'SERVICE_ORCHESTRATION';
  }
  if (type === 'component' && lines > 400 && !isCriticalPath) {
    return 'LAZY_LOADING';
  }
  return 'NONE';
}
```

## Activation Triggers

This skill activates when:

- Creating new `.tsx` or `.ts` files
- Modifying existing `.tsx` or `.ts` files
- User mentions: refactor, split, extract, organize
- File size exceeds 300 lines during edit
- User commits changes to large files

## Integration with Architecture Checks

Works with existing yarn scripts:

```bash
yarn check:files         # Manual file size check
yarn check:complexity    # Complexity analysis
yarn check:architecture  # Full architecture check
```

## Exemptions

Some files may legitimately exceed limits:

- Generated files (e.g., `generated.d.ts`)
- Type definition aggregators
- Configuration files with extensive enums
- Third-party library integrations

**Mark exemptions** with comment:

```typescript
// @file-size-enforcer-exempt: Generated type definitions
```

## Success Criteria

✅ All new files <300 lines
✅ All functions <100 lines
✅ Cyclomatic complexity <10
✅ Clear refactoring path for large files
✅ Compound components used for large UI
✅ Service orchestration for complex logic
✅ Lazy loading for non-critical features

## Output Format

```
📊 FILE SIZE ANALYSIS

File: src/components/dao/proposals/create-proposal-form.tsx
Lines: 420 (excluding imports/comments)
Status: ⚠️ WARNING
Target: <300 lines

Large Functions:
1. handleSubmit (Lines 85-195, 110 lines) → Extract to useProposalSubmit hook
2. renderStepContent (Lines 220-340, 120 lines) → Extract step components

Recommended Pattern: Compound Components + Custom Hooks

Estimated Effort: 2 hours
Files to Create: 5
Final Size: All <300 lines

Auto-Refactor Available: Yes
```
