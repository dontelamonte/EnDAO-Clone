---
name: test-coverage-guardian
description: Ensures new features have corresponding tests for EnDAO. Detects missing tests for API routes, services, hooks, and components. Auto-scaffolds test files with proper structure. Use when implementing new features, modifying business logic, or creating new files.
allowed-tools: Read, Grep, Glob, Write
---

# Test Coverage Guardian

## Purpose

Maintains test coverage standards by detecting missing tests, scaffolding test files automatically, and ensuring critical paths have comprehensive test coverage.

## Last Updated

October 29, 2025

## Coverage Requirements

### By File Type

- **Services**: 80% unit test coverage minimum
- **API Routes**: 100% coverage (all endpoints must be tested)
- **Hooks**: 70% coverage minimum
- **Components**: 60% coverage (critical components 80%)
- **Critical Paths**: Treasury, auth, proposals must have E2E tests

### Critical Paths Requiring E2E Tests

1. **Treasury Operations**
   - Create treasury
   - Propose transaction
   - Sign transaction
   - Execute transaction
   - Grace period deletion → freeze → recovery

2. **Authentication Flow**
   - Privy wallet connection
   - User profile creation
   - Session management
   - Logout/reconnect

3. **Proposal Lifecycle**
   - Create proposal
   - Vote on proposal
   - Proposal finalization
   - Proposal execution

4. **DAO Management**
   - Create DAO
   - Join DAO
   - Member management
   - DAO deletion with grace period

## Test File Patterns

### File Location Convention

```
src/
├── lib/services/dao/
│   ├── dao-crud.service.ts
│   └── __tests__/
│       └── dao-crud.service.test.ts
├── app/api/treasury/create/
│   ├── route.ts
│   └── __tests__/
│       └── route.test.ts
├── hooks/dao/
│   ├── use-dao-admin.ts
│   └── __tests__/
│       └── use-dao-admin.test.ts
└── components/dao/settings/
    ├── dao-settings-content.tsx
    └── __tests__/
        └── dao-settings-content.test.tsx
```

## Auto-Actions

### 1. Detect Missing Tests

When new file created or modified:

1. **Check for corresponding test file**
   - Services: `__tests__/{name}.test.ts` in same directory
   - API routes: `__tests__/route.test.ts` in route directory
   - Hooks: `__tests__/{name}.test.ts` in hooks directory
   - Components: `__tests__/{name}.test.tsx` in component directory

2. **If test file missing**
   - Notify developer
   - Offer to scaffold test file
   - Provide test template based on file type

3. **If test file exists but outdated**
   - Detect new functions/methods without tests
   - Suggest adding test cases
   - Show uncovered code paths

### 2. Auto-Scaffold Test Files

Generate test scaffolds with proper structure:

#### Service Test Template

```typescript
// __tests__/dao-crud.service.test.ts
import { describe, it, expect, beforeEach, jest } from '@jest/globals';
import { DAOCrudService } from '../dao-crud.service';
import { db } from '@/lib/firebase/firestore';

// Mock Firebase
jest.mock('@/lib/firebase/firestore', () => ({
  db: {
    collection: jest.fn(),
    doc: jest.fn(),
  },
}));

describe('DAOCrudService', () => {
  let service: DAOCrudService;

  beforeEach(() => {
    service = new DAOCrudService();
    jest.clearAllMocks();
  });

  describe('createDAO', () => {
    it('should create a new DAO with valid data', async () => {
      // Arrange
      const mockDAOData = {
        name: 'Test DAO',
        description: 'Test description',
        creatorId: 'user123',
      };

      const mockDocRef = { id: 'dao123' };
      (db.collection as jest.Mock).mockReturnValue({
        add: jest.fn().mockResolvedValue(mockDocRef),
      });

      // Act
      const result = await service.createDAO(mockDAOData);

      // Assert
      expect(result.success).toBe(true);
      expect(result.data.id).toBe('dao123');
      expect(db.collection).toHaveBeenCalledWith('daos');
    });

    it('should handle validation errors', async () => {
      // TODO: Implement test
    });

    it('should handle database errors', async () => {
      // TODO: Implement test
    });
  });

  describe('updateDAO', () => {
    it('should update existing DAO', async () => {
      // TODO: Implement test
    });
  });

  describe('deleteDAO', () => {
    it('should soft delete DAO', async () => {
      // TODO: Implement test
    });
  });
});
```

#### API Route Test Template

```typescript
// app/api/treasury/create/__tests__/route.test.ts
import { NextRequest } from 'next/server';
import { POST } from '../route';
import { getServerSession } from 'next-auth';
import { treasuryAdminService } from '@/lib/services/treasury';

jest.mock('next-auth');
jest.mock('@/lib/services/treasury');

describe('POST /api/treasury/create', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should create treasury with valid request', async () => {
    // Arrange
    const mockSession = {
      user: { id: 'user123', walletAddress: '0x123' },
    };
    (getServerSession as jest.Mock).mockResolvedValue(mockSession);

    const mockRequest = new NextRequest(
      'http://localhost/api/treasury/create',
      {
        method: 'POST',
        body: JSON.stringify({
          daoId: 'dao123',
          owners: ['0x123', '0x456'],
          threshold: 2,
        }),
      }
    );

    const mockResult = {
      success: true,
      data: { safeAddress: '0xSafe123' },
    };
    (treasuryAdminService.createTreasury as jest.Mock).mockResolvedValue(
      mockResult
    );

    // Act
    const response = await POST(mockRequest);
    const data = await response.json();

    // Assert
    expect(response.status).toBe(200);
    expect(data.success).toBe(true);
    expect(data.data.safeAddress).toBe('0xSafe123');
  });

  it('should return 401 if not authenticated', async () => {
    // Arrange
    (getServerSession as jest.Mock).mockResolvedValue(null);

    const mockRequest = new NextRequest(
      'http://localhost/api/treasury/create',
      {
        method: 'POST',
      }
    );

    // Act
    const response = await POST(mockRequest);

    // Assert
    expect(response.status).toBe(401);
  });

  it('should return 400 with invalid request body', async () => {
    // TODO: Implement test
  });

  it('should handle treasury creation errors', async () => {
    // TODO: Implement test
  });
});
```

#### Hook Test Template

```typescript
// hooks/dao/__tests__/use-dao-admin.test.ts
import { renderHook, waitFor } from '@testing-library/react';
import { useDAOAdmin } from '../use-dao-admin';
import { daoAdminService } from '@/lib/services/dao';

jest.mock('@/lib/services/dao');

describe('useDAOAdmin', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should fetch DAO admin status', async () => {
    // Arrange
    const mockResult = {
      success: true,
      data: { isAdmin: true, permissions: ['manage_members'] },
    };
    (daoAdminService.checkAdminStatus as jest.Mock).mockResolvedValue(
      mockResult
    );

    // Act
    const { result } = renderHook(() => useDAOAdmin('dao123', 'user123'));

    // Assert
    await waitFor(() => {
      expect(result.current.isAdmin).toBe(true);
      expect(result.current.permissions).toContain('manage_members');
    });
  });

  it('should handle loading state', () => {
    // TODO: Implement test
  });

  it('should handle errors', async () => {
    // TODO: Implement test
  });
});
```

#### Component Test Template

```typescript
// components/dao/settings/__tests__/dao-settings-content.test.tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { DAOSettingsContent } from '../dao-settings-content'
import { useDAOSettings } from '@/hooks/dao/use-dao-settings'

jest.mock('@/hooks/dao/use-dao-settings')

describe('DAOSettingsContent', () => {
  const mockUpdateDAO = jest.fn()

  beforeEach(() => {
    jest.clearAllMocks()
    ;(useDAOSettings as jest.Mock).mockReturnValue({
      dao: {
        id: 'dao123',
        name: 'Test DAO',
        description: 'Test description'
      },
      updateDAO: mockUpdateDAO,
      loading: false
    })
  })

  it('should render DAO settings', () => {
    // Act
    render(<DAOSettingsContent daoId="dao123" />)

    // Assert
    expect(screen.getByText('Test DAO')).toBeInTheDocument()
    expect(screen.getByText('Test description')).toBeInTheDocument()
  })

  it('should update DAO name', async () => {
    // Arrange
    render(<DAOSettingsContent daoId="dao123" />)

    // Act
    const nameInput = screen.getByLabelText('DAO Name')
    fireEvent.change(nameInput, { target: { value: 'Updated DAO' } })
    fireEvent.click(screen.getByText('Save Changes'))

    // Assert
    await waitFor(() => {
      expect(mockUpdateDAO).toHaveBeenCalledWith({
        name: 'Updated DAO'
      })
    })
  })

  it('should handle loading state', () => {
    // TODO: Implement test
  })

  it('should handle errors', () => {
    // TODO: Implement test
  })
})
```

### 3. Detect Untested Code

Identify functions/methods without tests:

```typescript
// Analyze service file
function analyzeTestCoverage(filePath: string): CoverageAnalysis {
  const sourceCode = readFile(filePath);
  const testFile = findTestFile(filePath);

  if (!testFile) {
    return {
      hasCoverage: false,
      recommendation: 'CREATE_TEST_FILE',
    };
  }

  const testCode = readFile(testFile);

  // Extract function/method names from source
  const sourceFunctions = extractFunctions(sourceCode);

  // Extract test cases from test file
  const testedFunctions = extractTestedFunctions(testCode);

  // Find untested functions
  const untestedFunctions = sourceFunctions.filter(
    (fn) => !testedFunctions.includes(fn)
  );

  return {
    hasCoverage: true,
    coverage: (testedFunctions.length / sourceFunctions.length) * 100,
    untestedFunctions,
    recommendation:
      untestedFunctions.length > 0 ? 'ADD_TEST_CASES' : 'COVERAGE_OK',
  };
}
```

## Critical Path Validation

### Treasury Operations E2E Test

```typescript
// e2e/treasury-operations.test.ts
describe('Treasury Operations Flow', () => {
  it('should complete full treasury lifecycle', async () => {
    // 1. Create DAO
    const dao = await createTestDAO();

    // 2. Create treasury
    const treasury = await createTreasury(dao.id);

    // 3. Propose transaction
    const proposal = await proposeTransaction(dao.id, treasury.address);

    // 4. Collect signatures
    await signTransaction(proposal.id, owner1);
    await signTransaction(proposal.id, owner2);

    // 5. Execute transaction
    const result = await executeTransaction(proposal.id);
    expect(result.success).toBe(true);

    // 6. Verify transaction in ledger
    const ledger = await getTreasuryLedger(dao.id);
    expect(ledger.transactions).toHaveLength(1);
  });

  it('should handle grace period deletion flow', async () => {
    // 1. Create DAO with treasury
    const dao = await createTestDAO();
    const treasury = await createTreasury(dao.id);

    // 2. Initiate deletion
    await initiateDAODeletion(dao.id);

    // 3. Verify treasury frozen
    const treasuryStatus = await getTreasuryStatus(dao.id);
    expect(treasuryStatus.frozen).toBe(true);

    // 4. Attempt transaction (should fail)
    const txResult = await proposeTransaction(dao.id, treasury.address);
    expect(txResult.success).toBe(false);
    expect(txResult.error).toContain('frozen');

    // 5. Recover DAO
    await recoverDAO(dao.id);

    // 6. Verify treasury unfrozen
    const recoveredStatus = await getTreasuryStatus(dao.id);
    expect(recoveredStatus.frozen).toBe(false);
  });
});
```

## Activation Triggers

This skill activates when:

- Creating new service files
- Creating new API routes
- Creating new hooks
- Creating new components
- Modifying business logic
- User mentions: test, coverage, testing
- Committing code without tests
- Running `yarn test` or `yarn test:coverage`

## Output Format

### When Missing Tests Detected

```
🧪 TEST COVERAGE ALERT

File: src/lib/services/treasury/treasury-admin-management.service.ts
Status: ❌ NO TESTS FOUND
Coverage: 0%
Target: 80%

Missing Test File: src/lib/services/treasury/__tests__/treasury-admin-management.service.test.ts

Detected Functions Requiring Tests:
1. createTreasury (Lines 45-120)
2. addOwner (Lines 125-180)
3. removeOwner (Lines 185-240)
4. updateThreshold (Lines 245-290)
5. validateTreasuryOperation (Lines 295-350)

Scaffold Test File? (y/n)
```

### When Tests Outdated

```
🧪 TEST COVERAGE WARNING

File: src/lib/services/dao/dao-crud.service.ts
Test File: src/lib/services/dao/__tests__/dao-crud.service.test.ts
Status: ⚠️ TESTS OUTDATED
Coverage: 60% (below 80% target)

Recently Added Functions Without Tests:
1. archiveDAO (Lines 450-480) - Added in last commit
2. restoreDAO (Lines 485-515) - Added in last commit

Recommended Test Cases:
1. should archive DAO successfully
2. should validate admin permissions before archive
3. should restore archived DAO
4. should validate DAO status before restore

Add Test Cases? (y/n)
```

### When Critical Path Missing E2E Test

```
🧪 CRITICAL PATH ALERT

Feature: Grace Period Deletion System
Status: ❌ NO E2E TESTS
Risk: HIGH - Critical treasury protection feature

Required E2E Test Scenarios:
1. Initiate deletion → Treasury frozen
2. Attempt transaction during grace period → Blocked
3. Recover DAO → Treasury unfrozen
4. Complete deletion after grace period → Treasury frozen permanently

Create E2E Test Suite? (y/n)
```

## Success Criteria

✅ All new services have 80%+ test coverage
✅ All API routes have 100% test coverage
✅ All hooks have 70%+ test coverage
✅ Critical components have 80%+ test coverage
✅ All critical paths have E2E tests
✅ Test files follow naming convention
✅ Tests include arrange-act-assert structure
✅ Mocks properly configured for Firebase/Privy
