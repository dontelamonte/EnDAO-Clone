---
name: treasury-validator
description: Validates treasury transactions for EnDAO including Safe integration, signature requirements, 4-layer protection checks, and audit trail compliance. Use when user mentions treasury, transactions, Safe, multi-sig, spending, deletion, grace period, or DAO status.
allowed-tools: Read, Grep, Bash
---

# Treasury Transaction Validator

## Purpose

Validates all treasury transaction implementations against EnDAO's 4-layer protection system to prevent unauthorized access, data leaks, and security vulnerabilities.

## Last Updated

October 29, 2025

## 4-Layer Protection System

### Layer 1: DAO Status Validation

- **Check**: DAO must be in 'active' status
- **Blocked Statuses**: 'deleted', 'archived', 'pending_deletion'
- **Validation**: Verify `TreasuryAccessControlService.validateTreasuryOperation()` called

### Layer 2: Treasury Freeze Management

- **Check**: Treasury must not be frozen
- **Auto-Freeze**: Triggered during DAO deletion process
- **Validation**: Verify freeze status checked before operations

### Layer 3: Grace Period Protection

- **Check**: 7-day grace period during DAO deletion
- **Protection**: Treasury automatically frozen during grace period
- **Recovery**: DAO can be recovered before grace period expires
- **Validation**: Verify grace period status checked

### Layer 4: Emergency Recovery

- **Check**: Super admin override capabilities
- **Validation**: Verify emergency recovery operations have proper audit logging

## Validation Checklist

When reviewing treasury-related code, verify:

1. **Authorization Check**

   ```typescript
   const result = await treasuryAccessControlService.validateTreasuryOperation(
     daoId,
     userId,
     operation,
     authContext
   );
   if (!result.success) {
     return { error: result.data?.accessStatus.reason };
   }
   ```

2. **DAO Status Validation**
   - Verify DAO is 'active' status
   - Block operations on 'deleted', 'archived', 'pending_deletion' DAOs

3. **Treasury Freeze Check**
   - Verify treasury is not frozen
   - Check `dao.treasuryFrozen` flag

4. **Grace Period Protection**
   - Verify grace period status checked
   - Block treasury access during deletion grace period

5. **Audit Trail Logging**

   ```typescript
   await auditLogService.logTreasuryOperation({
     operation,
     daoId,
     userId,
     metadata,
     status: 'success' | 'failed',
   });
   ```

6. **Privy Wallet Authentication**
   - Verify user has connected wallet
   - Validate wallet ownership

7. **Safe SDK Integration**
   - Verify transaction formatting correct
   - Check multi-sig threshold validation

8. **Error Handling**
   - Detailed error messages with specific reasons
   - No exposure of internal system details
   - User-friendly error messages

## Files to Monitor

### Service Layer

- `src/lib/services/treasury/treasury-access-control.service.ts` - Gateway for all treasury operations
- `src/lib/services/treasury/dao-soft-delete.service.ts` - Grace period deletion management
- `src/lib/services/treasury/treasury-notification.service.ts` - Alert system
- `src/lib/services/treasury/treasury-recovery.service.ts` - Emergency recovery
- `src/lib/services/treasury/treasury-admin-management.service.ts` - Admin operations

### API Routes

- `src/app/api/treasury/*/route.ts` - All treasury API endpoints

### Frontend Components

- `src/components/dao/treasury/**/*.tsx` - Treasury UI components
- `src/components/dao/settings/dao-settings-content.tsx` - DAO deletion UI
- `src/hooks/treasury/` - Treasury-related hooks

## Auto-Actions

When detecting treasury-related code changes:

1. **Pre-Change Validation**
   - Check if file is in treasury service/API/component paths
   - Verify 4-layer protection compliance in existing code
   - Identify potential security gaps

2. **During Review**
   - Flag missing `validateTreasuryOperation()` calls
   - Flag missing audit logging
   - Flag inadequate error handling
   - Flag missing DAO status checks

3. **Post-Change Validation**
   - Verify all protection layers implemented
   - Check audit trail completeness
   - Validate error messages are user-friendly
   - Ensure no internal details exposed

## Common Security Issues

### ❌ CRITICAL: Missing Authorization

```typescript
// BAD: No authorization check
async function createTransaction(daoId, amount) {
  const tx = await safe.createTransaction({ to, value: amount });
  return tx;
}
```

### ✅ GOOD: Proper Authorization

```typescript
// GOOD: Full 4-layer protection
async function createTransaction(daoId, userId, amount, authContext) {
  // Layer 1-4: Comprehensive validation
  const protection =
    await treasuryAccessControlService.validateTreasuryOperation(
      daoId,
      userId,
      'create_transaction',
      authContext
    );

  if (!protection.success) {
    await auditLogService.logTreasuryOperation({
      operation: 'create_transaction',
      daoId,
      userId,
      status: 'failed',
      reason: protection.data?.accessStatus.reason,
    });
    return { error: protection.data?.accessStatus.reason };
  }

  const tx = await safe.createTransaction({ to, value: amount });

  await auditLogService.logTreasuryOperation({
    operation: 'create_transaction',
    daoId,
    userId,
    status: 'success',
    metadata: { transactionId: tx.id, amount },
  });

  return { success: true, data: tx };
}
```

### ❌ CRITICAL: Missing DAO Status Check

```typescript
// BAD: No DAO status validation
const dao = await getDAO(daoId);
// Proceeds without checking if DAO is deleted/archived
```

### ✅ GOOD: DAO Status Validation

```typescript
// GOOD: Validate DAO status before operations
const dao = await getDAO(daoId);
if (['deleted', 'archived', 'pending_deletion'].includes(dao.status)) {
  return {
    error: `Treasury operations blocked: DAO is ${dao.status}`,
  };
}
```

### ❌ CRITICAL: No Audit Logging

```typescript
// BAD: Treasury operation without audit trail
await safe.proposeTransaction(tx);
return { success: true };
```

### ✅ GOOD: Comprehensive Audit Logging

```typescript
// GOOD: Complete audit trail
try {
  await safe.proposeTransaction(tx);
  await auditLogService.logTreasuryOperation({
    operation: 'propose_transaction',
    daoId,
    userId,
    status: 'success',
    metadata: { transactionId: tx.id },
  });
  return { success: true };
} catch (error) {
  await auditLogService.logTreasuryOperation({
    operation: 'propose_transaction',
    daoId,
    userId,
    status: 'failed',
    metadata: { error: error.message },
  });
  throw error;
}
```

## Testing Requirements

When treasury code is modified, verify:

1. **Unit Tests**
   - Test each protection layer independently
   - Test authorization failures
   - Test audit logging completeness

2. **Integration Tests**
   - Test full deletion → freeze → recovery flow
   - Test emergency recovery operations
   - Test notification delivery

3. **Security Tests**
   - Test unauthorized access attempts
   - Test DAO status bypass attempts
   - Test grace period enforcement

## Activation Triggers

This skill activates when:

- User mentions: treasury, transactions, Safe, multi-sig, spending
- User mentions: deletion, grace period, freeze, recovery
- User mentions: DAO status, archive, delete
- Working on files in `src/lib/services/treasury/`
- Working on files in `src/app/api/treasury/`
- Working on treasury-related components

## Output Format

When validation issues found:

```
🚨 TREASURY SECURITY ISSUE DETECTED

File: src/app/api/treasury/create-transaction/route.ts
Line: 45

Issue: Missing TreasuryAccessControlService.validateTreasuryOperation() call

Impact: CRITICAL - Treasury operation bypasses 4-layer protection system
Risk: Unauthorized treasury access, potential fund loss

Required Fix:
1. Add protection validation before transaction creation
2. Check DAO status (must be 'active')
3. Verify treasury not frozen
4. Check grace period status
5. Add comprehensive audit logging

Example Implementation:
[Show code example from this document]
```

## Success Criteria

✅ All treasury operations validate through TreasuryAccessControlService
✅ All 4 protection layers checked before operations
✅ Complete audit trail for all treasury operations
✅ User-friendly error messages with specific reasons
✅ No internal system details exposed in errors
✅ Proper Privy wallet authentication
✅ Safe SDK integration follows best practices
