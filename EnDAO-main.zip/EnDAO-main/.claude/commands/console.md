# Check Chrome DevTools Console

Check the Chrome DevTools console for errors, warnings, and logs.

## Usage

```bash
/console                    # Show all recent console messages
/console --errors           # Show only errors
/console --warnings         # Show only warnings
/console --clean            # Show only errors and warnings (filter out logs)
/console --full             # Show all messages including preserved (last 3 navigations)
```

## Description

Uses Chrome DevTools MCP to read browser console output. Helpful for debugging:

- React errors and warnings
- Network failures (401, 404, etc.)
- JavaScript exceptions
- Dev auth issues
- API response errors

## Default Behavior

Shows recent console messages with clear formatting, highlighting:

- 🔴 Errors (critical issues)
- 🟡 Warnings (potential problems)
- 🔵 Info/Logs (normal output)

---

Execute the console check based on the flags provided:

1. If `--errors` flag: Show only error messages
2. If `--warnings` flag: Show only warning messages
3. If `--clean` flag: Show errors and warnings only (filter out info/log)
4. If `--full` flag: Include preserved messages from last 3 navigations
5. Default: Show all recent console messages with type filtering

Use the `mcp__chrome-devtools__list_console_messages` tool with appropriate filters.

Format output clearly with:

- Message type indicators (ERROR, WARN, LOG, etc.)
- Message count summary
- Easy-to-scan formatting
- Highlight critical issues at the top

After showing messages, provide a brief summary:

- Total messages by type
- Critical issues to address
- Current console health status (clean/warnings/errors)
